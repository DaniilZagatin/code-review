"""Разбор табличных и HTML-образов результата (`progress/tabular_reader.py`).

Без сети и без сторонних пакетов: .xlsx собирается тут же из минимального XML
(это zip с XML), .csv/.html — обычные строки. Проверяем, что данные доходят до
слайдов в Markdown и что бандл-страница отклоняется понятной ошибкой, а не
выдаётся за разобранный образ результата.
"""

import io
import tempfile
import unittest
import zipfile
from pathlib import Path

from pko.errors import PkoError
from pko.progress.tabular_reader import read_document

_CONTENT_TYPES = (
    '<?xml version="1.0" encoding="UTF-8"?>'
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    '<Default Extension="xml" ContentType="application/xml"/>'
    '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
    '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
    '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
    '</Types>'
)
_WORKBOOK = (
    '<?xml version="1.0" encoding="UTF-8"?>'
    '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
    '<sheets><sheet name="Реестр" sheetId="1" r:id="rId1"/></sheets></workbook>'
)
_WB_RELS = (
    '<?xml version="1.0" encoding="UTF-8"?>'
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
    '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>'
    '</Relationships>'
)


def _make_xlsx(path: Path, header: list[str], rows: list[list[str]]) -> None:
    strings: list[str] = []
    index: dict[str, int] = {}

    def sid(text: str) -> int:
        if text not in index:
            index[text] = len(strings)
            strings.append(text)
        return index[text]

    def col(n: int) -> str:
        s = ""
        n += 1
        while n:
            n, rem = divmod(n - 1, 26)
            s = chr(65 + rem) + s
        return s

    sheet_rows = []
    for r_i, row in enumerate([header, *rows], start=1):
        cells = "".join(
            f'<c r="{col(c_i)}{r_i}" t="s"><v>{sid(val)}</v></c>'
            for c_i, val in enumerate(row)
        )
        sheet_rows.append(f'<row r="{r_i}">{cells}</row>')
    sheet = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<sheetData>' + "".join(sheet_rows) + '</sheetData></worksheet>'
    )
    sst_items = "".join(f'<si><t>{s}</t></si>' for s in strings)
    sst = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f'<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="{len(strings)}" uniqueCount="{len(strings)}">'
        + sst_items + '</sst>'
    )
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", _CONTENT_TYPES)
        z.writestr("_rels/.rels",
                   '<?xml version="1.0" encoding="UTF-8"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                   '</Relationships>')
        z.writestr("xl/workbook.xml", _WORKBOOK)
        z.writestr("xl/_rels/workbook.xml.rels", _WB_RELS)
        z.writestr("xl/worksheets/sheet1.xml", sheet)
        z.writestr("xl/sharedStrings.xml", sst)


class TabularReaderTest(unittest.TestCase):
    def setUp(self) -> None:
        self.dir = Path(tempfile.mkdtemp(prefix="pko-tab-"))

    def test_xlsx_becomes_markdown_slides(self):
        p = self.dir / "reestr.xlsx"
        _make_xlsx(p, ["Клиентский путь", "Инициатива", "ПШЕ"],
                   [["Ипотека", "E2E ипотека", "12"], ["ОСАГО", "NRT-оффер", "6"]])
        slides = read_document(p)
        self.assertTrue(slides)
        text = "\n".join(s.raw_text for s in slides)
        self.assertIn("Клиентский путь", text)
        self.assertIn("Ипотека", text)
        self.assertIn("| --- |", text)  # Markdown-таблица
        self.assertIn("Реестр", text)   # имя листа в заголовке

    def test_xlsx_paginates_large_sheets(self):
        p = self.dir / "big.xlsx"
        rows = [[f"path{i}", f"init{i}", str(i)] for i in range(95)]
        _make_xlsx(p, ["A", "B", "C"], rows)
        slides = read_document(p)
        self.assertEqual(len(slides), 3)  # 95 строк / 40 на слайд
        self.assertIn("часть 1 из 3", slides[0].raw_text)

    def test_csv_becomes_table(self):
        p = self.dir / "paths.csv"
        p.write_text("Путь,Инициатива\nИпотека,E2E\nОСАГО,NRT\n", encoding="utf-8")
        slides = read_document(p)
        self.assertIn("Ипотека", slides[0].raw_text)
        self.assertIn("| Инициатива |", slides[0].raw_text)

    def test_html_text_is_extracted_without_scripts(self):
        p = self.dir / "or.html"
        p.write_text(
            "<html><body><h1>Обслуживание Key Clients</h1>"
            "<p>Идеи и сделки на всю группу за минуты</p>"
            "<script>var secret=1</script></body></html>",
            encoding="utf-8",
        )
        text = read_document(p)[0].raw_text
        self.assertIn("Key Clients", text)
        self.assertNotIn("secret", text)

    def test_bundled_app_html_is_rejected(self):
        p = self.dir / "app.html"
        p.write_text(
            "<html><body><div id='__bundler_loading'>Unpacking...</div>"
            "<noscript>This page requires JavaScript to display.</noscript>"
            "<script>var data=atob('....')</script></body></html>",
            encoding="utf-8",
        )
        with self.assertRaises(PkoError):
            read_document(p)


if __name__ == "__main__":
    unittest.main()

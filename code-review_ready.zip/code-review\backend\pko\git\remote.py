"""Подготовка локального зеркала репозитория (`git clone --mirror`).

Зеркало, а не рабочее дерево: анализу нужен только доступ к деревьям на
коммитах (`git ls-tree`/`git show`), рабочая копия с чекаутом была бы лишней.
Зеркала складываются в кеш (`DEFAULT_CACHE_ROOT`), повторный прогон того же
репозитория переиспользует каталог и только доскачивает новое.

Идентичность зеркала (`mirror_path`) включает пользователя, хост, порт и проект,
а не только имя репозитория: репозитории с одинаковым именем с разных серверов,
портов или под разными учётками не должны попадать в один каталог. Перед
использованием существующего зеркала его `origin` сверяется с запрошенной
ссылкой — каталог, случайно указывающий на другой remote, не берётся молча.

Клон идёт от имени пользователя его же git/SSH: PKO не хранит учётные данные.
"""

from __future__ import annotations

import hashlib
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path

from pko.errors import GitError
from pko.git.url import RepoRef, parse_repo_url

# Куда складывать зеркала. Переопределяется переменной окружения PKO_GIT_CACHE.
DEFAULT_CACHE_ROOT = Path(
    os.environ.get("PKO_GIT_CACHE", str(Path.home() / ".cache" / "pko" / "mirrors"))
)


@dataclass(frozen=True)
class MirrorInfo:
    """Итог подготовки зеркала: где лежит и что с ним сделали."""

    path: Path
    created: bool
    fetched: bool


def mirror_path(ref: RepoRef, cache_root: Path) -> Path:
    """Детерминированный путь к зеркалу. Идентичность — user+host+port+project+repo.

    Хеш идентичности разводит зеркала, у которых совпало только имя репозитория
    (другой сервер/порт/учётка), и заодно делает имя каталога безопасным
    независимо от символов в ссылке. Само имя `.git`-каталога человекочитаемо.
    """
    identity = "\0".join([
        ref.user, ref.host, str(ref.port or ""), ref.project, ref.repo,
    ])
    digest = hashlib.sha1(identity.encode("utf-8")).hexdigest()[:16]
    return Path(cache_root) / digest / ref.mirror_dirname


def _git(args: list[str], timeout: int, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=str(cwd) if cwd is not None else None,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
    )


def _origin_url(dest: Path, timeout: int) -> str:
    proc = _git(["config", "--get", "remote.origin.url"], timeout=timeout, cwd=dest)
    return proc.stdout.strip()


def ensure_mirror(
    source: str,
    cache_root: Path | None = None,
    fetch: bool = True,
    timeout: int = 900,
) -> MirrorInfo:
    """Гарантировать свежее зеркало `source` в кеше и вернуть путь к нему."""
    ref = parse_repo_url(source)
    cache_root = Path(cache_root or DEFAULT_CACHE_ROOT).expanduser()
    dest = mirror_path(ref, cache_root)

    if dest.exists():
        origin = _origin_url(dest, timeout)
        if origin and origin.strip().rstrip("/") != source.strip().rstrip("/"):
            raise GitError(
                "Зеркало в кеше принадлежит другому remote.",
                hint=f"каталог {dest} указывает на {origin!r}, а запрошено {source!r}; "
                     "удалите каталог или укажите другой --cache-root",
            )
        if fetch:
            proc = _git(["remote", "update", "--prune"], timeout=timeout, cwd=dest)
            if proc.returncode != 0:
                raise GitError(
                    "Не удалось обновить зеркало репозитория.",
                    hint=(proc.stderr.strip() or str(dest))[:500],
                )
            return MirrorInfo(path=dest, created=False, fetched=True)
        return MirrorInfo(path=dest, created=False, fetched=False)

    dest.parent.mkdir(parents=True, exist_ok=True)
    proc = _git(["clone", "--mirror", source, str(dest)], timeout=timeout)
    if proc.returncode != 0:
        raise GitError(
            "Не удалось склонировать репозиторий.",
            hint=(proc.stderr.strip() or source)[:500],
        )
    return MirrorInfo(path=dest, created=True, fetched=True)

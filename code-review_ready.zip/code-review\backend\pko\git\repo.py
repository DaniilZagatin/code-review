"""Чтение git-репозитория на зафиксированном коммите — только чтение.

`GitRepo` оборачивает локальный путь (рабочий клон или зеркало из
`remote.ensure_mirror`) и даёт ровно то, что нужно экстракторам и сопоставлению
плана с кодом:

    default_branch()      → ветка по умолчанию (origin/HEAD, иначе master/main)
    resolve(ref)          → полный SHA коммита ветки/тега/сокращённого хеша
    files(sha)            → список путей в дереве коммита (рекурсивно)
    read_text(sha, path)  → текст файла на этом коммите (None — нет файла/бинарь)

Все обращения к git идут через `run`, и он пропускает только читающие
подкоманды: `checkout`/`reset`/`commit`/`push` и любая другая, меняющая
репозиторий, отклоняются с `GitError`. Так гарантия «PKO ничего не меняет в
анализируемом репозитории» задаётся в одном месте, а не держится на дисциплине
вызовов. Коммит фиксируется явно (`resolve` → `sha`), дальше всё читается по
этому `sha`, поэтому два обращения к одному дереву не разъедутся.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from pko.errors import GitError

# Разрешены только читающие подкоманды. Перечень — allowlist, а не «запретный
# список»: неизвестная подкоманда блокируется по умолчанию, потому что доказать
# безопасность списком того, что точно читает, надёжнее, чем перечислить всё,
# что может писать.
_READONLY_SUBCOMMANDS = frozenset({
    "rev-parse", "ls-tree", "show", "cat-file", "symbolic-ref",
    "for-each-ref", "show-ref", "log", "rev-list", "ls-files",
    "describe", "name-rev", "diff-tree",
})


class GitRepo:
    def __init__(self, path: "str | Path", timeout: int = 900) -> None:
        self.path = Path(path)
        self.timeout = timeout
        if not self.path.exists():
            raise GitError(
                f"Локальный репозиторий не найден: {self.path}",
                hint="проверьте путь или ссылку на репозиторий",
            )

    def run(self, *args: str, timeout: int | None = None) -> subprocess.CompletedProcess[str]:
        """Выполнить читающую git-подкоманду. Мутирующая/неизвестная — `GitError`."""
        subcommand = args[0] if args else ""
        if subcommand not in _READONLY_SUBCOMMANDS:
            raise GitError(
                f"Git-подкоманда {subcommand or '(пусто)'!r} запрещена: GitRepo только читает.",
                hint="доступны rev-parse, ls-tree, show, symbolic-ref, for-each-ref и другие читающие",
            )
        return subprocess.run(
            ["git", *args],
            cwd=str(self.path),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout or self.timeout,
        )

    def default_branch(self) -> str:
        """Ветка по умолчанию: origin/HEAD у зеркала, иначе текущая HEAD, иначе master/main."""
        for args in (
            ("symbolic-ref", "--quiet", "--short", "refs/remotes/origin/HEAD"),
            ("symbolic-ref", "--quiet", "--short", "HEAD"),
        ):
            proc = self.run(*args)
            name = proc.stdout.strip()
            if proc.returncode == 0 and name:
                return name.split("/", 1)[-1] if name.startswith("origin/") else name

        for candidate in ("master", "main"):
            if self.run("rev-parse", "--verify", "--quiet", f"{candidate}^{{commit}}").returncode == 0:
                return candidate

        proc = self.run("for-each-ref", "--count=1", "--format=%(refname:short)", "refs/heads")
        first = proc.stdout.strip().splitlines()
        if first:
            return first[0]
        raise GitError(
            "Не удалось определить ветку по умолчанию.",
            hint=f"в репозитории {self.path} не найдено ни одной ветки",
        )

    def resolve(self, ref: str) -> str:
        """Полный SHA коммита для ветки/тега/сокращённого хеша."""
        proc = self.run("rev-parse", "--verify", f"{ref}^{{commit}}")
        if proc.returncode == 0 and proc.stdout.strip():
            return proc.stdout.strip()
        # У зеркала ветки лежат как есть; у рабочего клона ветка remote — origin/<ref>.
        proc = self.run("rev-parse", "--verify", f"origin/{ref}^{{commit}}")
        if proc.returncode == 0 and proc.stdout.strip():
            return proc.stdout.strip()
        raise GitError(
            f"Не найдена ревизия: {ref}",
            hint=(proc.stderr.strip() or f"проверьте имя ветки/коммита в {self.path}")[:300],
        )

    def files(self, sha: str) -> list[str]:
        """Пути всех файлов в дереве коммита (рекурсивно, без каталогов)."""
        proc = self.run("ls-tree", "-r", "--name-only", "-z", sha)
        if proc.returncode != 0:
            raise GitError(
                f"Не удалось прочитать дерево коммита {sha[:8]}.",
                hint=(proc.stderr.strip() or str(self.path))[:300],
            )
        return [p for p in proc.stdout.split("\0") if p]

    def read_text(self, sha: str, path: str) -> str | None:
        """Текст файла на коммите. `None` — файла нет или он бинарный."""
        proc = self.run("show", f"{sha}:{path}")
        if proc.returncode != 0:
            return None
        text = proc.stdout
        # Бинарь: NUL внутри — не текст, читать как исходник нельзя.
        if "\x00" in text:
            return None
        return text

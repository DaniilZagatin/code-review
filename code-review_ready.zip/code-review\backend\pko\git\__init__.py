"""Read-only git-обвязка PKO.

Единственный слой доступа к git во всём проекте: разбор ссылки
(`url.parse_repo_url`), подготовка зеркала (`remote.ensure_mirror`) и чтение
дерева на зафиксированном коммите (`repo.GitRepo`). Все операции — только
чтение: ни одна команда не меняет рабочее дерево анализируемого репозитория
(мы клонируем `--mirror`, читаем через `git show`/`git ls-tree`), поэтому
сравнение плана с кодом всегда указывает на воспроизводимую версию, а не на то,
что случайно лежало в рабочей копии.

Обёртка над системным `git` (subprocess), без сторонних зависимостей — как и
остальной PKO. Клон делается от имени пользователя по его уже настроенному
git/SSH (`pko serve` — локальный инструмент, см. `web/app.py`).
"""

from __future__ import annotations

from pko.git.remote import DEFAULT_CACHE_ROOT, MirrorInfo, ensure_mirror, mirror_path
from pko.git.repo import GitRepo
from pko.git.url import RepoRef, parse_repo_url

__all__ = [
    "DEFAULT_CACHE_ROOT",
    "MirrorInfo",
    "ensure_mirror",
    "mirror_path",
    "GitRepo",
    "RepoRef",
    "parse_repo_url",
]

#!/usr/bin/env bash
# PKO progress — установка и запуск на Linux/macOS.
#   chmod +x run.sh && ./run.sh
# Делает venv, ставит зависимости, при первом запуске создаёт .env и
# останавливается, чтобы вписать доступ к LLM; при повторном — поднимает сервис.
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
  echo "Создаю виртуальное окружение .venv…"
  python3 -m venv .venv
fi
PY=./.venv/bin/python

echo "Ставлю зависимости…"
"$PY" -m pip install --upgrade pip >/dev/null
"$PY" -m pip install -r requirements.txt
"$PY" -m pip install -e .

if [ ! -f .env ]; then
  cp .env.example .env
  echo
  echo "Создан .env. Впишите в него доступ к вашему LLM:"
  echo "  PKO_ASSEMBLER_BASE_URL, PKO_ASSEMBLER_MODEL, PKO_ASSEMBLER_API_KEY"
  echo "Затем запустите ./run.sh ещё раз."
  exit 0
fi

echo
echo "PKO progress: http://127.0.0.1:8000"
exec ./.venv/bin/pko serve --host 127.0.0.1 --port 8000

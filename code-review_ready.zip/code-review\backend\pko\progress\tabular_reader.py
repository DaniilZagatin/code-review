"""Чтение табличных и HTML-образов результата в слайды.

Образ результата приходит не только в PPTX/PDF: часто это выгрузка реестра
инициатив в Excel (клиентский путь, инициатива, ресурс/ПШЕ, эффект, вехи
PoC/MVP/демо) или HTML-таймлайн. Эти форматы несут больше структурированного
контекста, чем слайд, поэтому агент по ним анализирует детальнее — знает ресурс,
эффект и сроки, а не только тексты этапов.

Разбор — только на стандартной библиотеке (`zipfile`+`xml` для .xlsx, `csv`,
`html.parser`), без сторонних зависимостей: .xlsx — это zip с XML, читать его
через тяжёлый пакет ради нескольких листов незачем, тот же принцип, что и у
`util/yamlmini.py`.

Каждый источник превращается в один или несколько `Slide(raw_text=...)`
(Markdown), со сквозной нумерацией их проставляет вызывающий
(`pipeline._load_slides_from_all`).
"""

from __future__ import annotations

import csv as _csv
import io
import re
import zipfile
from html.parser import HTMLParser
from pathlib import Path
from xml.etree import ElementTree as ET

from pko.errors import PkoError
from pko.progress.pptx_reader import Slide

# Больше строк в одном слайде агенту читать тяжело, а нумерация слайдов должна
# оставаться осмысленной ссылкой на источник — поэтому крупные таблицы режем на
# слайды по столько строк данных (не считая строку заголовка, она повторяется).
_ROWS_PER_SLIDE = 40

_XLSX_SUFFIXES = (".xlsx",)
_CSV_SUFFIXES = (".csv", ".tsv")
_HTML_SUFFIXES = (".html", ".htm")
SUPPORTED_SUFFIXES = _XLSX_SUFFIXES + _CSV_SUFFIXES + _HTML_SUFFIXES

_SSML = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def is_tabular_or_html(path: Path) -> bool:
    return path.suffix.lower() in SUPPORTED_SUFFIXES


def read_document(path: Path) -> list[Slide]:
    """Разобрать .xlsx/.csv/.tsv/.html в список слайдов с Markdown-текстом."""
    suffix = path.suffix.lower()
    if suffix in _XLSX_SUFFIXES:
        return _read_xlsx(path)
    if suffix in _CSV_SUFFIXES:
        return _read_csv(path, delimiter="\t" if suffix == ".tsv" else ",")
    if suffix in _HTML_SUFFIXES:
        return _read_html(path)
    raise PkoError(
        f"Формат не поддерживается табличным читателем: {path.name}",
        hint=f"допустимы {', '.join(SUPPORTED_SUFFIXES)}",
    )


# --- xlsx ---------------------------------------------------------------
def _col_index(cell_ref: str) -> int:
    letters = re.match(r"[A-Z]+", cell_ref or "A").group(0)
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n


def _read_xlsx(path: Path) -> list[Slide]:
    try:
        zf = zipfile.ZipFile(path)
    except zipfile.BadZipFile as exc:
        raise PkoError(
            f"Не удалось открыть Excel-файл: {path.name}",
            hint="ожидается .xlsx (Excel 2007+); старый .xls не поддерживается — пересохраните как .xlsx",
        ) from exc

    with zf:
        shared = _shared_strings(zf)
        sheets = _sheet_paths(zf)
        slides: list[Slide] = []
        for title, sheet_path in sheets:
            rows = _sheet_rows(zf, sheet_path, shared)
            rows = [r for r in rows if any(c.strip() for c in r)]
            if not rows:
                continue
            slides.extend(_rows_to_slides(title, rows))
    if not slides:
        raise PkoError(
            f"В Excel-файле нет данных: {path.name}",
            hint="проверьте, что в книге есть заполненный лист",
        )
    return slides


def _shared_strings(zf: zipfile.ZipFile) -> list[str]:
    try:
        root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    out: list[str] = []
    for si in root.findall(_SSML + "si"):
        out.append("".join(t.text or "" for t in si.iter(_SSML + "t")))
    return out


def _sheet_paths(zf: zipfile.ZipFile) -> list[tuple[str, str]]:
    """(имя листа, путь к sheetN.xml) в порядке книги."""
    names = zf.namelist()
    wb = zf.read("xl/workbook.xml").decode("utf-8", "replace")
    rels_raw = zf.read("xl/_rels/workbook.xml.rels").decode("utf-8", "replace")
    rid_to_target = dict(
        re.findall(r'Id="([^"]+)"[^>]*Target="([^"]+)"', rels_raw)
    )
    out: list[tuple[str, str]] = []
    for m in re.finditer(r'<sheet[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"', wb):
        name, rid = m.group(1), m.group(2)
        target = rid_to_target.get(rid, "")
        target = target.lstrip("/")
        candidate = target if target.startswith("xl/") else "xl/" + target
        if candidate in names:
            out.append((name, candidate))
    if not out:  # запасной путь: единственный лист
        for n in names:
            if n.startswith("xl/worksheets/") and n.endswith(".xml"):
                out.append(("Лист", n))
                break
    return out


def _sheet_rows(zf: zipfile.ZipFile, sheet_path: str, shared: list[str]) -> list[list[str]]:
    root = ET.fromstring(zf.read(sheet_path))
    rows: list[list[str]] = []
    for row in root.iter(_SSML + "row"):
        cells: dict[int, str] = {}
        for c in row.findall(_SSML + "c"):
            idx = _col_index(c.get("r", "A"))
            cells[idx] = _cell_value(c, shared)
        if cells:
            width = max(cells)
            rows.append([cells.get(i, "") for i in range(1, width + 1)])
    return rows


def _cell_value(c: ET.Element, shared: list[str]) -> str:
    t = c.get("t")
    v = c.find(_SSML + "v")
    inline = c.find(_SSML + "is")
    if t == "s" and v is not None and v.text is not None:
        try:
            return shared[int(v.text)]
        except (ValueError, IndexError):
            return ""
    if inline is not None:
        return "".join(x.text or "" for x in inline.iter(_SSML + "t"))
    if v is not None and v.text is not None:
        return v.text
    return ""


def _rows_to_slides(sheet_title: str, rows: list[list[str]]) -> list[Slide]:
    header = rows[0]
    body = rows[1:] or []
    width = max(len(r) for r in rows)
    header = _padded(header, width)

    slides: list[Slide] = []
    if not body:  # только заголовок — одна таблица
        return [_slide_from_table(sheet_title, header, [], 1, 1)]
    total_pages = (len(body) + _ROWS_PER_SLIDE - 1) // _ROWS_PER_SLIDE
    for page, start in enumerate(range(0, len(body), _ROWS_PER_SLIDE), start=1):
        chunk = [_padded(r, width) for r in body[start:start + _ROWS_PER_SLIDE]]
        slides.append(_slide_from_table(sheet_title, header, chunk, page, total_pages))
    return slides


def _padded(row: list[str], width: int) -> list[str]:
    return list(row) + [""] * (width - len(row))


def _md_cell(text: str) -> str:
    return " ".join((text or "").replace("|", "\\|").split())


def _slide_from_table(title: str, header: list[str], body: list[list[str]],
                      page: int, total: int) -> Slide:
    head = "| " + " | ".join(_md_cell(h) for h in header) + " |"
    sep = "| " + " | ".join("---" for _ in header) + " |"
    lines = [head, sep]
    for r in body:
        lines.append("| " + " | ".join(_md_cell(c) for c in r) + " |")
    caption = f"# Лист «{title}»" + (f" (часть {page} из {total})" if total > 1 else "")
    raw = caption + "\n\n" + "\n".join(lines)
    return Slide(number=1, heading=None, shapes=[], raw_text=raw)


# --- csv ----------------------------------------------------------------
def _read_csv(path: Path, delimiter: str) -> list[Slide]:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    rows = [row for row in _csv.reader(io.StringIO(text), delimiter=delimiter) if any(c.strip() for c in row)]
    if not rows:
        raise PkoError(f"Пустой CSV-файл: {path.name}", hint="нужна хотя бы строка заголовка и одна строка данных")
    return _rows_to_slides(path.stem, rows)


# --- html ---------------------------------------------------------------
class _TextExtractor(HTMLParser):
    _SKIP = {"script", "style", "noscript", "head", "template", "svg"}
    _BLOCK = {"p", "div", "section", "article", "li", "tr", "br", "h1", "h2",
              "h3", "h4", "h5", "h6", "table", "ul", "ol", "header", "footer"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._parts: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag in self._SKIP:
            self._skip_depth += 1
        elif tag in self._BLOCK:
            self._parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in self._SKIP and self._skip_depth:
            self._skip_depth -= 1
        elif tag in self._BLOCK:
            self._parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self._skip_depth == 0 and data.strip():
            self._parts.append(data)

    def text(self) -> str:
        raw = "".join(self._parts)
        lines = [ln.strip() for ln in raw.splitlines()]
        return "\n".join(ln for ln in lines if ln)


# Признаки одностраничного приложения/бандла, где контент собирается скриптом из
# упакованных данных, а в самой разметке видимого текста почти нет.
_BUNDLER_MARKERS = ("__bundler", "requires javascript", "enable javascript",
                    "you need to enable javascript")


def _read_html(path: Path) -> list[Slide]:
    html = path.read_text(encoding="utf-8", errors="replace")
    parser = _TextExtractor()
    parser.feed(html)
    text = parser.text()

    low = html.lower()
    looks_bundled = any(m in low for m in _BUNDLER_MARKERS)
    if len(text.strip()) < 12 or (looks_bundled and len(text.strip()) < 200):
        # Не притворяемся, что разобрали: даём понятную ошибку, а сам файл
        # кладётся в справочные данные проекта (data/reference/), откуда заранее
        # собранный текстовый справочник и попадает в анализ.
        raise PkoError(
            f"В HTML почти нет текста: {path.name}",
            hint="похоже на приложение, где содержимое собирается скриптом; "
                 "приложите текстовый образ результата (.pptx/.pdf/.xlsx) или "
                 "используйте заранее собранный справочник data/reference/",
        )
    return [Slide(number=1, heading=None, shapes=[], raw_text=text)]

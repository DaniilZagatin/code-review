# PKO progress — установка и запуск на Windows (PowerShell).
#   Правый клик → «Выполнить с помощью PowerShell», либо:  ./run.ps1
# Делает venv, ставит зависимости, при первом запуске создаёт .env и
# останавливается, чтобы вписать доступ к LLM; при повторном — поднимает сервис.
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

if (-not (Test-Path ".venv")) {
    Write-Host "Создаю виртуальное окружение .venv…"
    python -m venv .venv
}
$py = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"

Write-Host "Ставлю зависимости…"
& $py -m pip install --upgrade pip | Out-Null
& $py -m pip install -r requirements.txt
& $py -m pip install -e .

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host ""
    Write-Host "Создан .env. Впишите в него доступ к вашему LLM:" -ForegroundColor Yellow
    Write-Host "  PKO_ASSEMBLER_BASE_URL, PKO_ASSEMBLER_MODEL, PKO_ASSEMBLER_API_KEY"
    Write-Host "Затем запустите ./run.ps1 ещё раз." -ForegroundColor Yellow
    exit 0
}

Write-Host ""
Write-Host "PKO progress: http://127.0.0.1:8000" -ForegroundColor Green
& (Join-Path $PSScriptRoot ".venv\Scripts\pko.exe") serve --host 127.0.0.1 --port 8000

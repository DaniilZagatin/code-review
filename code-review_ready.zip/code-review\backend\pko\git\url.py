"""Разбор SSH-ссылки на репозиторий в структуру `RepoRef`.

Поддерживаются две формы, которые реально приходят от Bitbucket:

    ssh://git@host:7999/PROJECT/repo.git      (SSH с портом — основной путь Bitbucket)
    git@host:PROJECT/repo.git                 (scp-подобная короткая форма)

HTTPS сознательно отклоняется: клон идёт от имени пользователя по его ключу
(`pko serve` — локальный инструмент), а HTTPS потребовал бы логин/пароль или
токен, которые PKO не хранит и не подставляет. Пользователю подсказываем перейти
на `ssh://`.

Из ссылки нужны: `host`, `port`, `user` — они задают идентичность зеркала в кеше
(`remote.mirror_path`), чтобы репозитории с одним именем, но с разных серверов,
портов или под разными учётками не смешивались в одном каталоге; `project`/`repo`
— человекочитаемое имя и короткое имя для ссылки на реализацию в отчёте.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from pko.errors import UrlError

# ssh://[user@]host[:port]/PATH
_SSH_RE = re.compile(
    r"^ssh://(?:(?P<user>[^@/]+)@)?(?P<host>[^:/]+)(?::(?P<port>\d+))?/(?P<path>.+?)/?$",
    re.IGNORECASE,
)
# [user@]host:PATH (scp-подобная форма, без порта)
_SCP_RE = re.compile(r"^(?:(?P<user>[^@/]+)@)?(?P<host>[^:/]+):(?P<path>.+?)/?$")

_HINT = "используйте SSH: ssh://git@host:7999/PROJECT/repo.git или git@host:PROJECT/repo.git"


@dataclass(frozen=True)
class RepoRef:
    """Разобранная ссылка. `user`/`port` участвуют в идентичности зеркала."""

    host: str
    port: int | None
    user: str
    project: str
    repo: str

    @property
    def slug(self) -> str:
        return f"{self.project}/{self.repo}" if self.project else self.repo

    @property
    def mirror_dirname(self) -> str:
        return f"{self.repo}.git"


def parse_repo_url(source: str) -> RepoRef:
    """Разобрать SSH-ссылку. HTTPS/пустое/traversal — `UrlError` с подсказкой."""
    s = (source or "").strip()
    if not s:
        raise UrlError("Пустая ссылка на репозиторий.", hint=_HINT)

    if s.lower().startswith(("http://", "https://")):
        raise UrlError(
            f"HTTPS-ссылка не поддерживается: {source!r}",
            hint="перейдите на ssh:// — " + _HINT,
        )

    m = _SSH_RE.match(s)
    if m:
        port = int(m.group("port")) if m.group("port") else None
    else:
        if "://" in s:
            raise UrlError(f"Неизвестная схема ссылки: {source!r}", hint=_HINT)
        m = _SCP_RE.match(s)
        if not m:
            raise UrlError(f"Не удалось разобрать ссылку: {source!r}", hint=_HINT)
        port = None

    user = m.group("user") or ""
    host = m.group("host")
    path = m.group("path")

    parts = [p for p in path.split("/") if p]
    # Обход каталога в пути → отказ: имя пошло бы в путь кеша (`mirror_path`),
    # и `..`/`.` вырвались бы за пределы каталога зеркал.
    if any(seg in ("..", ".") for seg in parts):
        raise UrlError(
            f"Недопустимый путь в ссылке: {source!r}",
            hint="в пути репозитория не должно быть '..' или '.'",
        )
    if parts and parts[-1].lower().endswith(".git"):
        parts[-1] = parts[-1][:-4]

    repo = parts[-1] if parts else ""
    project = parts[-2] if len(parts) >= 2 else ""
    if not repo:
        raise UrlError(f"В ссылке нет имени репозитория: {source!r}", hint=_HINT)

    return RepoRef(host=host, port=port, user=user, project=project, repo=repo)

import boto3

UPLOAD_TIMEOUT = 15


def save(key: str, payload: bytes) -> None:
    """Положить наблюдение в объектное хранилище."""
    client = boto3.client("s3")
    client.put_object(Bucket="observations", Key=key, Body=payload)

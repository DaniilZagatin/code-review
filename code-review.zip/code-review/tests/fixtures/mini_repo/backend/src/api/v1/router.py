from fastapi import APIRouter

router = APIRouter(prefix="/api/v1")


@router.post("/tasks")
async def start_task(payload: dict) -> dict:
    """Поставить задачу в обработку."""
    return {"id": "t-1"}


@router.get("/tasks/{task_id}")
async def get_task(task_id: str) -> dict:
    """Получить состояние задачи."""
    return {"id": task_id, "status": "RUNNING"}

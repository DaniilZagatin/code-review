import sqlalchemy

QUERY_TEMPLATE = "SELECT employee_id, department FROM hr_headcount WHERE dt = :dt"

SQL_TIMEOUT_SECONDS = 60
MAX_RETRIES = 2


def execute(sql: str):
    """Выполнить запрос к аналитической базе."""
    return []

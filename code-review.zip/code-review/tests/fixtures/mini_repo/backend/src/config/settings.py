from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    api_port: int = 8000
    db_max_rows: int = 10000
    sql_timeout: int = 30
    llm_api_key: str = "секрет-не-должен-попасть-в-отчёт"
    allowed_tables: list[str] = ["hr_headcount", "hr_positions", "hr_kpi"]


settings = Settings()

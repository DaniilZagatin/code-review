from langgraph.graph import StateGraph


def build_graph():
    builder = StateGraph(dict)
    builder.add_node("plan", plan_step)
    builder.add_node("search_schema", search_schema_step)
    builder.add_node("run_sql", run_sql_step)
    builder.add_node("synthesize", synthesize_step)
    builder.add_edge("plan", "search_schema")
    builder.add_edge("search_schema", "run_sql")
    builder.add_edge("run_sql", "synthesize")
    return builder


def plan_step(state):
    return state


def search_schema_step(state):
    return state


def run_sql_step(state):
    return state


def synthesize_step(state):
    return state

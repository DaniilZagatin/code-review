def search_schema(query: str) -> list[str]:
    """Найти подходящие таблицы по описанию."""
    return []


def run_query(sql: str, timeout: int = 60, max_rows: int = 10000) -> list[dict]:
    """Выполнить SQL-запрос на чтение."""
    return []


def save_observation(text: str) -> None:
    """Сохранить наблюдение в долговременную память."""
    return None

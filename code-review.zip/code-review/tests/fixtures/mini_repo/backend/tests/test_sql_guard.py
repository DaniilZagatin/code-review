def test_forbidden_update_is_rejected():
    """Изменяющий запрос должен быть отклонён."""
    assert True


def test_timeout_limit_applied():
    assert True

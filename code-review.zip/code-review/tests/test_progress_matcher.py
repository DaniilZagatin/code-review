"""Единый агент (`run_agent`): текст слайдов -> карта клиентского пути +
вердикты по этапам, по одному `submit_stage` на этап, до `finish`.

Транспорт подменяется тем же способом, что и в остальных LLM-тестах:
`ChatClient._request` отдаёт по одному заготовленному ответу на каждый ход
сессии. Путь/строка/якорь проверяются на настоящей фикстуре `mini_repo`.
"""

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from fixture_support import ensure_fixture, scripted_responses
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.errors import PkoError
from pko.progress import matcher
from pko.progress.matcher import (
    DEFAULT_MAX_STEPS,
    MAX_USER_STAGES,
    derive_progress,
    find_unclaimed_paths,
    load_system_prompt,
    parse_stage_titles,
    run_agent,
)
from pko.progress.pptx_reader import Slide, SlideShape
from pko.progress.schema import (
    EvidenceRef,
    ItemVerdict,
    ProjectSummary,
    StageCapability,
)
from pko.report.guard import check_business_language, has_business_subject

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")

SLIDES = [
    Slide(number=1, heading="Задачи спринта", shapes=[
        SlideShape(text="Постановка задач в обработку\n"
                        "API, который принимает задачу и ставит её в очередь",
                   left=0.5, top=1.2, width=4.0, height=2.2),
        SlideShape(text="Биллинг подписок\nСписание средств за подписку по расписанию",
                   left=4.8, top=1.2, width=4.0, height=2.2),
    ]),
]

ROUTER_EVIDENCE = [{"path": "backend/src/api/v1/router.py", "line": 7,
                    "basis": "функция start_task ставит задачу в обработку"}]

# Формулировки-образцы: проходят оба сторожа (нет путей, нет технической
# лексики) и укладываются в 4-16 слов — то, чего агент и должен добиваться.
CAPABILITY_OK = "Клиент ставит задачу в обработку без обращения к сотруднику"
CAPABILITY_OTHER = "Банк списывает оплату по подписке без участия сотрудника"
STAGE_SUMMARY_OK = "Клиент передаёт задачу в работу самостоятельно"


def _call(name: str, args: dict, call_id: str | None = None) -> dict:
    return {
        "id": call_id or f"call_{name}",
        "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }


def tool_call(name: str, **args) -> dict:
    """Один ход с одним вызовом инструмента — нативный `tool_calls`."""
    return {"content": None, "tool_calls": [_call(name, args)]}


def parallel_tool_calls(*calls: tuple[str, dict]) -> dict:
    """Один ход с несколькими вызовами инструментов разом."""
    return {"content": None, "tool_calls": [
        _call(name, args, call_id=f"call_{i}_{name}") for i, (name, args) in enumerate(calls)
    ]}


def cap(capability: str = CAPABILITY_OK, availability: str = "AVAILABLE",
        who_acts: str = "AGENT", limit: str = "") -> dict:
    """Одна бизнес-возможность этапа в контракте `submit_stage.capabilities`."""
    return {"capability": capability, "availability": availability,
            "who_acts": who_acts, "limit": limit}


def _normalize_capabilities(capabilities):
    """Строка → одна доступная возможность с этим текстом; список dict'ов — как есть.

    Держит короткими те call sites, которым важен не состав возможностей, а
    сам факт принятого/отклонённого вердикта."""
    if isinstance(capabilities, str):
        return [cap(capability=capabilities)]
    return list(capabilities)


def stage_args(item_id: str, status: str, capabilities=CAPABILITY_OK,
               stage_summary: str = STAGE_SUMMARY_OK,
               evidence: list[dict] | None = None,
               execution_mode: str = "", execution_type: str = "",
               completion_status: str = "", objects_found: list[dict] | None = None,
               technical_notes: str = "") -> dict:
    return {
        "item_id": item_id,
        "stage_summary": stage_summary,
        "capabilities": _normalize_capabilities(capabilities),
        "stage_status": status,
        "evidence": evidence or [],
        "execution_mode": execution_mode,
        "execution_type": execution_type,
        "completion_status": completion_status,
        "objects_found": objects_found or [],
        "technical_notes": technical_notes,
    }


def submit(item_id: str, status: str, capabilities=CAPABILITY_OK, **kwargs) -> dict:
    """Один ход с одним `submit_stage` — вердикт по этапу целиком."""
    return tool_call("submit_stage", **stage_args(item_id, status, capabilities, **kwargs))


def finish() -> dict:
    return tool_call("finish")


def summary_call(
    conclusion: str, risks: list[str] | None = None, priorities: list[str] | None = None,
) -> dict:
    return tool_call(
        "submit_summary",
        conclusion=conclusion,
        risks=risks or [],
        priorities=priorities or [],
    )


def plan_call(*entries, project_title: str = "Тестовый проект",
              client: str = "клиент сервиса", client_goal: str = "передать задачу в работу") -> dict:
    """submit_plan со списком этапов. Каждая entry — кортеж
    (item_id, title, source_slide) либо готовый dict с этими полями."""
    items = []
    for e in entries:
        if isinstance(e, dict):
            items.append(e)
        else:
            item_id, title, source_slide = e
            items.append({"item_id": item_id, "title": title, "source_slide": source_slide})
    return tool_call("submit_plan", project_title=project_title, client=client,
                     client_goal=client_goal, items=items)


def malformed(text: str) -> dict:
    """Ход без вызова инструмента вообще — единственный вид «неразобранного» хода теперь."""
    return {"content": text}


class MatcherAgentTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.repo = GitRepo(ensure_fixture())
        cls.sha = cls.repo.resolve("master")
        cls.tree = Tree.at(cls.repo, cls.sha)

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)

    def _run(self, *answers, slides=SLIDES, max_steps=DEFAULT_MAX_STEPS, on_verdict=None,
             on_plan=None, on_summary=None, stages=None):
        ChatClient._create = scripted_responses(*answers)
        return run_agent(
            slides, self.tree, SPEC, client=self.client, max_steps=max_steps,
            on_verdict=on_verdict, on_plan=on_plan, on_summary=on_summary,
            stages=stages,
        )

    def test_no_spec_returns_empty_with_note(self):
        result = run_agent(SLIDES, self.tree, spec=None)
        self.assertFalse(result.usable)
        self.assertIn("не настроен", result.notes[0])

    def test_no_content_slides_returns_empty_with_note(self):
        empty_slide = Slide(number=1, heading=None, shapes=[])
        result = run_agent([empty_slide], self.tree, SPEC, client=self.client)
        self.assertFalse(result.usable)
        self.assertIn("нет текстовых фигур", result.notes[0])

    def test_full_session_submit_then_finish(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач в обработку", 1),
                      ("billing", "Биллинг подписок", 1)),
            tool_call("list_files", glob="*.py"),
            tool_call("read_file", path="backend/src/api/v1/router.py"),
            submit("tasks-api", "DONE", CAPABILITY_OK, evidence=ROUTER_EVIDENCE),
            submit("billing", "NOT_STARTED",
                   [cap(CAPABILITY_OTHER, availability="NOT_AVAILABLE", who_acts="HUMAN")]),
            summary_call(
                "Постановка задач работает, оплата по подписке пока за сотрудником.",
                risks=["Списание по подписке остаётся ручным — объём подписчиков ограничен временем сотрудника"],
                priorities=["Передать списание по подписке агенту — снять ручную работу с сотрудника"],
            ),
            finish(),
        )
        self.assertEqual(result.source, "llm")
        self.assertEqual(len(result.items), 2)
        by_id = {v.item_id: v for v in result.verdicts}
        self.assertEqual(by_id["tasks-api"].status, "DONE")
        self.assertTrue(by_id["tasks-api"].is_grounded)
        self.assertTrue(by_id["tasks-api"].evidence[0].verified)
        self.assertEqual(by_id["tasks-api"].capabilities[0].capability, CAPABILITY_OK)
        self.assertEqual(by_id["tasks-api"].stage_summary, STAGE_SUMMARY_OK)
        self.assertEqual(by_id["billing"].status, "NOT_STARTED")
        self.assertEqual(by_id["billing"].capabilities[0].availability, "NOT_AVAILABLE")
        self.assertEqual(result.summary_source, "llm")
        self.assertEqual(result.client, "клиент сервиса")
        self.assertEqual(result.client_goal, "передать задачу в работу")

    def test_invalid_submit_is_rejected_and_can_be_resubmitted(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("ghost", "DONE"),
            submit("tasks-api", "NOT_STARTED"),
            finish(),
        )
        self.assertEqual(len(result.items), 1)
        self.assertEqual(result.items[0].id, "tasks-api")

    def test_on_verdict_fires_once_per_accepted_submission_only(self):
        seen: list[tuple[str, str]] = []
        self._run(
            plan_call(("tasks-api", "Постановка задач в обработку", 1),
                      ("billing", "Биллинг подписок", 1)),
            submit("ghost", "DONE"),
            tool_call("list_files", glob="*.py"),
            submit("tasks-api", "DONE", CAPABILITY_OK, evidence=ROUTER_EVIDENCE),
            submit("billing", "NOT_STARTED",
                   [cap(CAPABILITY_OTHER, availability="NOT_AVAILABLE")]),
            finish(),
            on_verdict=lambda item, verdict: seen.append((item.id, verdict.status)),
        )
        # "ghost" (item_id нет в плане) отклонён — колбэк по нему не зовётся;
        # list_files — не submit_stage, тоже мимо колбэка.
        self.assertEqual(seen, [("tasks-api", "DONE"), ("billing", "NOT_STARTED")])

    def test_stage_without_capabilities_is_rejected(self):
        # Вердикт без единой бизнес-возможности не принимается: пустой список
        # означал бы этап, о котором отчёту нечего сказать руководителю.
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            tool_call("submit_stage", **{**stage_args("tasks-api", "DONE"), "capabilities": []}),
            submit("tasks-api", "DONE", CAPABILITY_OK),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(result.verdicts[0].capabilities[0].capability, CAPABILITY_OK)

    def test_stage_without_summary_is_rejected(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "DONE", stage_summary=""),
            submit("tasks-api", "DONE"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(result.verdicts[0].stage_summary, STAGE_SUMMARY_OK)

    def test_resubmitting_same_item_id_updates_the_verdict(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            submit("tasks-api", "DONE", CAPABILITY_OK, evidence=ROUTER_EVIDENCE),
            finish(),
        )
        self.assertEqual(len(result.items), 1)
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(result.verdicts[0].status, "DONE")

    def test_progress_is_derived_from_execution_mode_not_from_model(self):
        # Готовность считает код по режиму исполнения и статусу завершения:
        # AUTO(100) + UNCONFIRMED(-30) = 70, ASSIST(50) + ACHIEVED(0) = 50.
        result = self._run(
            plan_call(("auto", "Автоматический этап", 1),
                      ("assist", "Этап с подсказкой", 1)),
            submit("auto", "PARTIAL", execution_mode="AUTO", completion_status="UNCONFIRMED"),
            submit("assist", "PARTIAL", execution_mode="ASSIST", completion_status="ACHIEVED"),
            finish(),
        )
        by_id = {v.item_id: v for v in result.verdicts}
        self.assertEqual(by_id["auto"].progress, 70)
        self.assertEqual(by_id["assist"].progress, 50)

    def test_progress_falls_back_to_capability_availability(self):
        # Режим не определён — готовность считается по доступности возможностей:
        # AVAILABLE(100) и NOT_AVAILABLE(0) дают 50.
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "PARTIAL", [
                cap(CAPABILITY_OK, availability="AVAILABLE"),
                cap(CAPABILITY_OTHER, availability="NOT_AVAILABLE"),
            ]),
            finish(),
        )
        self.assertEqual(result.verdicts[0].progress, 50)

    def test_fabricated_evidence_path_is_not_verified_but_kept(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "DONE", CAPABILITY_OK, evidence=[
                {"path": "backend/src/billing_service.py", "line": 1, "basis": "x"},
            ]),
            finish(),
        )
        verdict = result.verdicts[0]
        self.assertEqual(len(verdict.evidence), 1)
        self.assertFalse(verdict.evidence[0].verified)
        self.assertFalse(verdict.is_grounded)
        self.assertIn("без единой подтверждённой ссылки", " ".join(result.notes))

    def test_capability_naming_a_nonexistent_file_is_rejected_then_resubmitted(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "DONE",
                   "Клиент видит свои задачи в billing_service.py каждый день",
                   evidence=ROUTER_EVIDENCE),
            submit("tasks-api", "DONE", CAPABILITY_OK, evidence=ROUTER_EVIDENCE),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(result.verdicts[0].capabilities[0].capability, CAPABILITY_OK)
        self.assertTrue(result.verdicts[0].evidence[0].verified)

    def test_technical_capability_is_rejected_until_strikes_run_out(self):
        # Два отклонения по языку, на третий раз вердикт принимается, но текст
        # заменён пометкой — этап не теряется из-за формулировки.
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "DONE", "Реализован приём задач через очередь обработки"),
            submit("tasks-api", "DONE", "Эндпоинт постановки задачи полностью готов к работе"),
            submit("tasks-api", "DONE", "Модуль обработки задач подключён и работает штатно"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertIn("отклонён сторожем", result.verdicts[0].capabilities[0].capability)
        self.assertIn("отклонений по языку", " ".join(result.notes))

    def test_too_short_capability_is_rejected(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "DONE", "Задачи принимаются"),
            submit("tasks-api", "DONE", CAPABILITY_OK),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(result.verdicts[0].capabilities[0].capability, CAPABILITY_OK)

    def test_stops_after_repeated_identical_tool_call(self):
        result = self._run(
            tool_call("search", pattern="x"),
            tool_call("search", pattern="x"),
            tool_call("search", pattern="x"),
            finish(),
        )
        self.assertFalse(result.usable)
        self.assertIn("одинаковых вызова", " ".join(result.notes))

    def test_stops_at_step_budget(self):
        result = self._run(
            tool_call("list_files"),
            tool_call("read_file", path="backend/src/api/v1/router.py"),
            tool_call("search", pattern="a"),
            max_steps=3,
        )
        self.assertFalse(result.usable)
        self.assertIn("бюджет шагов", " ".join(result.notes))

    def test_budget_exhausted_still_returns_already_submitted_verdicts(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "DONE", CAPABILITY_OK, evidence=ROUTER_EVIDENCE),
            tool_call("search", pattern="a"),
            max_steps=3,
        )
        self.assertTrue(result.usable)
        self.assertEqual(result.verdicts[0].status, "DONE")
        self.assertIn("бюджет шагов", " ".join(result.notes))

    def test_finish_immediately_without_any_submission(self):
        result = self._run(finish())
        self.assertFalse(result.usable)
        self.assertIn("не отправлены", " ".join(result.notes))

    def test_tolerates_a_few_malformed_responses_then_recovers(self):
        result = self._run(
            malformed("извините, не могу помочь"),
            malformed("и снова не JSON"),
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE", who_acts="HUMAN")]),
            finish(),
        )
        self.assertEqual(result.verdicts[0].status, "NOT_STARTED")

    def test_gives_up_after_too_many_malformed_responses(self):
        result = self._run(malformed("x"), malformed("y"), malformed("z"), malformed("w"))
        self.assertFalse(result.usable)
        self.assertIn("не вызвал инструмент", " ".join(result.notes))

    def test_parallel_tool_calls_in_one_turn_both_execute(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач в обработку", 1)),
            parallel_tool_calls(
                ("list_files", {"glob": "*.py"}),
                ("search", {"pattern": "start_task"}),
            ),
            submit("tasks-api", "DONE", CAPABILITY_OK, evidence=ROUTER_EVIDENCE),
            finish(),
        )
        self.assertEqual(result.verdicts[0].status, "DONE")
        self.assertTrue(result.verdicts[0].evidence[0].verified)

    def test_stage_and_finish_in_the_same_turn(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            parallel_tool_calls(
                ("submit_stage", stage_args("tasks-api", "DONE", evidence=ROUTER_EVIDENCE)),
                ("finish", {}),
            ),
        )
        self.assertTrue(result.usable)
        self.assertEqual(result.verdicts[0].status, "DONE")

    def test_invalid_tool_arguments_json_does_not_crash_and_lets_model_recover(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            {"content": None, "tool_calls": [{
                "id": "call_bad",
                "type": "function",
                "function": {"name": "read_file", "arguments": "{not valid json"},
            }]},
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
        )
        self.assertEqual(result.verdicts[0].status, "NOT_STARTED")

    def test_verdict_before_plan_is_rejected(self):
        # submit_stage до submit_plan отклоняется; после плана — принимается.
        result = self._run(
            submit("tasks-api", "DONE", CAPABILITY_OTHER, evidence=ROUTER_EVIDENCE),
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "DONE", CAPABILITY_OK, evidence=ROUTER_EVIDENCE),
            finish(),
        )
        self.assertTrue(result.usable)
        self.assertEqual(len(result.verdicts), 1)
        # принят именно второй вердикт (после плана), не первый.
        self.assertEqual(result.verdicts[0].capabilities[0].capability, CAPABILITY_OK)

    def test_on_plan_fires_once_with_plan_items(self):
        seen: list[list[str]] = []
        self._run(
            plan_call(("tasks-api", "Постановка задач", 1),
                      ("billing", "Биллинг подписок", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            submit("billing", "NOT_STARTED",
                   [cap(CAPABILITY_OTHER, availability="NOT_AVAILABLE")]),
            finish(),
            on_plan=lambda plan: seen.append([it.id for it in plan]),
        )
        self.assertEqual(seen, [["tasks-api", "billing"]])

    def test_plan_is_carried_in_agent_result(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1),
                      ("billing", "Биллинг подписок", 1),
                      project_title="Редизайн сервиса"),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
        )
        plan_ids = [it.id for it in result.plan]
        self.assertEqual(plan_ids, ["tasks-api", "billing"])
        self.assertEqual(result.project_title, "Редизайн сервиса")

    def test_invalid_plan_is_rejected_then_can_be_resubmitted(self):
        # битый source_slide валит весь план; агент перенанизывает план и идёт дальше.
        result = self._run(
            tool_call("submit_plan", project_title="x", client="клиент", items=[
                {"item_id": "tasks-api", "title": "Постановка задач", "source_slide": 99},
            ]),
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
        )
        self.assertTrue(result.usable)
        self.assertEqual(len(result.plan), 1)
        self.assertEqual(result.plan[0].source_slide, 1)

    def test_restored_stage_with_slide_zero_is_accepted_and_marked(self):
        # Этапов на слайде нет — агент собирает путь по опорной карте и ставит
        # source_slide: 0. Такой этап принимается, но помечается как
        # реконструкция и отдельно называется в notes.
        result = self._run(
            plan_call(("first-contact", "Первичный контакт", 0),
                      ("tasks-api", "Постановка задач", 1)),
            submit("first-contact", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
        )
        by_id = {it.id: it for it in result.plan}
        self.assertTrue(by_id["first-contact"].restored)
        self.assertFalse(by_id["tasks-api"].restored)
        self.assertIn("восстановленных агентом", " ".join(result.notes))

    def test_user_stages_become_the_plan_verbatim(self):
        # Этапы задал человек. Агент вернул их с другим регистром и лишними
        # пробелами — план принимается (сравнение нестрогое), но в отчёт идёт
        # авторская редакция человека, а не редакция модели.
        result = self._run(
            plan_call(("contact", "первичный   КОНТАКТ", 0),
                      ("issue", "Выдача", 0)),
            submit("contact", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
            stages=["Первичный контакт", "Выдача"],
        )
        self.assertEqual([it.title for it in result.plan], ["Первичный контакт", "Выдача"])
        self.assertEqual([it.origin for it in result.plan], ["user", "user"])
        self.assertEqual([it.source_slide for it in result.plan], [0, 0])
        # origin="user" — это не реконструкция: предупреждения в notes нет.
        self.assertNotIn("восстановленных агентом", " ".join(result.notes))

    def test_plan_that_renames_a_user_stage_is_rejected(self):
        result = self._run(
            plan_call(("contact", "Первое касание", 0)),
            plan_call(("contact", "Первичный контакт", 0)),
            submit("contact", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
            stages=["Первичный контакт"],
        )
        self.assertTrue(result.usable)
        self.assertEqual([it.title for it in result.plan], ["Первичный контакт"])

    def test_plan_with_wrong_number_of_user_stages_is_rejected(self):
        result = self._run(
            plan_call(("contact", "Первичный контакт", 0)),
            plan_call(("contact", "Первичный контакт", 0), ("issue", "Выдача", 0)),
            submit("contact", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
            stages=["Первичный контакт", "Выдача"],
        )
        self.assertTrue(result.usable)
        self.assertEqual(len(result.plan), 2)

    def test_user_stage_titles_skip_the_language_guard(self):
        # Название придумал человек — отклонять его за чужой выбор слов
        # неправильно, даже если в нём техническое слово. Проверка языка
        # остаётся на текстах, которые пишет сам агент.
        result = self._run(
            plan_call(("api", "Интеграция с бюро", 0)),
            submit("api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
            stages=["Интеграция с бюро"],
        )
        self.assertEqual([it.title for it in result.plan], ["Интеграция с бюро"])

    def test_plan_with_technical_description_is_rejected(self):
        result = self._run(
            tool_call("submit_plan", project_title="x", client="клиент", items=[
                {"item_id": "tasks-api", "title": "Постановка задач", "source_slide": 1,
                 "description": "Эндпоинт приёма задачи и запись в базу данных"},
            ]),
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
        )
        self.assertTrue(result.usable)
        self.assertEqual(len(result.plan), 1)
        self.assertEqual(result.plan[0].description, "")

    def test_empty_plan_is_rejected(self):
        result = self._run(
            tool_call("submit_plan", project_title="x", client="клиент", items=[]),
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
        )
        self.assertTrue(result.usable)

    def test_summary_is_accepted_after_verdicts(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            summary_call("Проект пока не даёт клиенту результата."),
            finish(),
        )
        self.assertEqual(result.summary.conclusion, "Проект пока не даёт клиенту результата.")
        self.assertEqual(result.summary_source, "llm")

    def test_on_summary_fires_on_accepted_summary(self):
        seen: list[ProjectSummary] = []
        self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            summary_call("Проект пока не даёт клиенту результата."),
            finish(),
            on_summary=lambda s: seen.append(s),
        )
        [s] = seen
        self.assertEqual(s.conclusion, "Проект пока не даёт клиенту результата.")
        self.assertEqual(s.risks, [])

    def test_summary_naming_a_nonexistent_path_is_rejected(self):
        # submit_summary с выдуманным путём отклоняется сторожем; summary пуст.
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            summary_call("Сделано в nonexistent/file.py."),
            finish(),
        )
        self.assertIsNone(result.summary)
        self.assertEqual(result.summary_source, "none")

    def test_summary_with_technical_language_is_rejected(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            summary_call("Не реализована интеграция сервиса списаний."),
            finish(),
        )
        self.assertIsNone(result.summary)

    def test_summary_without_verdicts_still_accepted(self):
        # submit_summary формально возможен и без вердиктов (allowed_paths пуст).
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            summary_call("Данных для оценки пока нет."),
            finish(),
        )
        self.assertEqual(result.summary.conclusion, "Данных для оценки пока нет.")

    def test_no_summary_yields_empty_summary_and_note(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            finish(),
        )
        self.assertIsNone(result.summary)
        self.assertEqual(result.summary_source, "none")
        self.assertIn("Общий вывод не сформирован", " ".join(result.notes))

    def test_summary_is_normalised_to_contract_limits(self):
        # Контракт: conclusion — до 3 предложений и 60 слов, risks/priorities —
        # до 3 пунктов по 140 символов. Нормализация обрезает детерминированно,
        # без отклонения, и по границе слова — а не посреди него.
        long_risk = ("Решение по обращению принимает сотрудник вручную, поэтому объём "
                     "обращений ограничен его рабочим временем, а срок запуска сервиса "
                     "оказывается под угрозой уже сейчас")
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "NOT_STARTED",
                   [cap(CAPABILITY_OK, availability="NOT_AVAILABLE")]),
            summary_call(
                "Первое предложение. Второе предложение. Третье предложение. Четвёртое лишнее.",
                risks=[long_risk, "Второй риск сформулирован коротко", "Третий риск",
                       "Четвёртый риск должен отсечься"],
                priorities=["Первый шаг", "Второй шаг", "Третий шаг", "Лишний четвёртый шаг"],
            ),
            finish(),
        )
        self.assertEqual(result.summary.conclusion,
                         "Первое предложение. Второе предложение. Третье предложение.")
        self.assertEqual(len(result.summary.risks), 3)
        self.assertLessEqual(len(result.summary.risks[0]), 141)
        self.assertTrue(result.summary.risks[0].endswith("…"))
        # обрезано по границе слова: хвост не рвёт слово пополам
        self.assertTrue(long_risk.startswith(result.summary.risks[0][:-1]))
        self.assertEqual(result.summary.risks[1], "Второй риск сформулирован коротко")
        self.assertEqual(result.summary.priorities,
                         ["Первый шаг", "Второй шаг", "Третий шаг"])

    def test_standard_fields_are_carried_onto_verdict(self):
        # Классификация стандарта (режим/тип/статус завершения/объекты)
        # переносится на итоговый ItemVerdict и видна в to_dict.
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "DONE", CAPABILITY_OK,
                   evidence=ROUTER_EVIDENCE,
                   execution_mode="AUTO", execution_type="REACTIVE_ACTION",
                   completion_status="ACHIEVED",
                   objects_found=[{"kind": "BBB", "path": "backend/src/api/v1/router.py",
                                   "line": 7, "basis": "start_task"}],
                   technical_notes="найден BBB"),
            finish(),
        )
        v = result.verdicts[0]
        self.assertEqual(v.execution_mode, "AUTO")
        self.assertEqual(v.execution_type, "REACTIVE_ACTION")
        self.assertEqual(v.completion_status, "ACHIEVED")
        self.assertEqual(v.progress, 100)
        self.assertEqual(len(v.objects_found), 1)
        self.assertEqual(v.objects_found[0].kind, "BBB")
        d = v.to_dict()
        self.assertEqual(d["execution_mode"], "AUTO")
        self.assertEqual(d["objects_found"][0]["kind"], "BBB")
        self.assertEqual(d["capabilities"][0]["capability"], CAPABILITY_OK)
        self.assertEqual(d["stage_summary"], STAGE_SUMMARY_OK)

    def test_invalid_execution_mode_rejects_stage(self):
        # Явный, но неизвестный enum-элемент отклоняет вердикт целиком.
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "DONE", execution_mode="BANANA"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 0)

    def test_invalid_availability_rejects_stage(self):
        result = self._run(
            plan_call(("tasks-api", "Постановка задач", 1)),
            submit("tasks-api", "DONE", [cap(CAPABILITY_OK, availability="MAYBE")]),
            submit("tasks-api", "DONE", CAPABILITY_OK),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)

    def test_reasoning_content_is_carried_in_chat_result(self):
        # reasoning_content (thinking) сохраняется в ChatResult для анализа,
        # не подменяет text/tool_calls.
        from pko.llm.client import ChatClient
        from pko.llm.registry import ModelSpec
        from fixture_support import make_openai_response

        spec = ModelSpec(role="matcher", base_url="https://stub.local/v1",
                         model="stub", api_key="x")
        client = ChatClient(spec=spec, use_cache=False)
        original = ChatClient._create
        msg = {"content": "ответ", "reasoning_content": "разбор задачи"}
        ChatClient._create = lambda self, p, extra_body=None: make_openai_response(msg)
        try:
            result = client.chat(messages=[{"role": "user", "content": "hi"}])
        finally:
            ChatClient._create = original
        self.assertEqual(result.text, "ответ")
        self.assertEqual(result.reasoning_content, "разбор задачи")


class SystemPromptTest(unittest.TestCase):
    """Сборка системного промпта из трёх редактируемых файлов.

    Тест на пропажу — не формальность: правила языка однажды уже грузились по
    вычисленному пути, файла там не оказалось, `OSError` глушился, и весь
    языковой блок молча не доходил до модели. Молчаливой деградации быть не
    должно."""

    def test_all_three_parts_are_loaded(self):
        prompt, missing = load_system_prompt()
        self.assertEqual(missing, [])
        # Протокол, язык и справочник вместе дают заметный объём: пустой или
        # обрезанный файл провалит проверку раньше, чем прогон на живой модели.
        self.assertGreater(len(prompt), 5000)

    def test_missing_part_is_reported_not_swallowed(self):
        with tempfile.TemporaryDirectory() as empty:
            with mock.patch.object(matcher, "_PROMPT_DIR", Path(empty)):
                prompt, missing = load_system_prompt()
        self.assertEqual(missing, list(matcher._PROMPT_PARTS))
        # Прогон не падает: работает минимальный промпт, но пропажа названа.
        self.assertTrue(prompt)

    def test_missing_part_reaches_the_run_notes(self):
        with tempfile.TemporaryDirectory() as empty:
            with mock.patch.object(matcher, "_PROMPT_DIR", Path(empty)):
                ChatClient._create = scripted_responses(finish())
                result = run_agent(SLIDES, self.tree, SPEC, client=self.client)
        self.assertIn("Части системного промпта не найдены", " ".join(result.notes))

    @classmethod
    def setUpClass(cls):
        cls.repo = GitRepo(ensure_fixture())
        cls.tree = Tree.at(cls.repo, cls.repo.resolve("master"))

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)


class StageTitlesTest(unittest.TestCase):
    """Разбор этапов, заданных человеком: и текстом из формы, и списком из CLI."""

    def test_text_is_split_by_lines_and_cleaned(self):
        self.assertEqual(
            parse_stage_titles("Первичный контакт\n\n  Сборка   предложения \nВыдача\n"),
            ["Первичный контакт", "Сборка предложения", "Выдача"],
        )

    def test_list_form_is_accepted_as_is(self):
        self.assertEqual(parse_stage_titles(["Первый", " Второй "]), ["Первый", "Второй"])

    def test_empty_input_means_stages_are_not_set(self):
        self.assertEqual(parse_stage_titles(None), [])
        self.assertEqual(parse_stage_titles(""), [])
        self.assertEqual(parse_stage_titles("   \n\n "), [])

    def test_too_many_stages_is_rejected(self):
        with self.assertRaises(PkoError) as ctx:
            parse_stage_titles("\n".join(f"Этап {i}" for i in range(MAX_USER_STAGES + 1)))
        self.assertIn("Слишком много этапов", ctx.exception.message)

    def test_overlong_title_is_rejected(self):
        with self.assertRaises(PkoError) as ctx:
            parse_stage_titles("Этап " + "о" * 80)
        self.assertIn("длиннее", ctx.exception.message)


class DeriveProgressTest(unittest.TestCase):
    """Готовность этапа считает код, а не модель — по таблице справочника."""

    def test_mode_sets_the_base_value(self):
        self.assertEqual(derive_progress("AUTO", "ACHIEVED", []), 100)
        self.assertEqual(derive_progress("CONFIRM", "ACHIEVED", []), 75)
        self.assertEqual(derive_progress("ASSIST", "ACHIEVED", []), 50)
        self.assertEqual(derive_progress("HUMAN_ONLY", "ACHIEVED", []), 25)

    def test_completion_status_corrects_the_base_value(self):
        self.assertEqual(derive_progress("AUTO", "CORRECTLY_HANDLED", []), 80)
        self.assertEqual(derive_progress("AUTO", "UNCONFIRMED", []), 70)
        # ниже нуля не опускается
        self.assertEqual(derive_progress("HUMAN_ONLY", "UNCONFIRMED", []), 0)

    def test_without_mode_falls_back_to_capability_availability(self):
        caps = [
            StageCapability(availability="AVAILABLE", capability="a"),
            StageCapability(availability="LIMITED", capability="b"),
        ]
        self.assertEqual(derive_progress("", "", caps), 75)
        self.assertEqual(derive_progress("", "", []), 0)


class BusinessLanguageGuardTest(unittest.TestCase):
    """Лексический сторож: отклоняет техническую речь, но не трогает
    двусмысленные слова с законным банковским значением."""

    def test_technical_wording_is_flagged(self):
        for text in (
            "Реализован эндпоинт постановки задачи",
            "В коде не найдено модели скоринга",
            "Отсутствует интеграция сервиса списаний",
            "Покрытие тестами модуля оценки около шестидесяти процентов",
        ):
            with self.subTest(text=text):
                self.assertTrue(check_business_language(text))

    def test_business_wording_passes(self):
        for text in (
            "Клиент открывает счёт онлайн без визита в отделение",
            "Клиент подтверждает операцию кодом из сообщения",
            "Держатель карты получает страховое покрытие по поездке",
            "Менеджер видит класс обслуживания клиента заранее",
        ):
            with self.subTest(text=text):
                self.assertEqual(check_business_language(text), [])

    def test_business_subject_detection(self):
        self.assertTrue(has_business_subject("Клиент оформляет заявку онлайн"))
        self.assertFalse(has_business_subject("Документы принимаются и проверяются автоматически"))


class UnclaimedPathsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        repo = GitRepo(ensure_fixture())
        sha = repo.resolve("master")
        cls.tree = Tree.at(repo, sha)
        from pko.extractors.runner import extract_all

        cls.extraction = extract_all(cls.tree)

    def test_paths_without_verified_evidence_are_reported_as_unclaimed(self):
        verdict_with_evidence = ItemVerdict(
            item_id="tasks-api", status="DONE",
            capabilities=[StageCapability(availability="AVAILABLE", capability=CAPABILITY_OK)],
        )
        verdict_with_evidence.evidence.append(
            EvidenceRef(path="backend/src/api/v1/router.py", line=7,
                       basis="start_task", verified=True, reason="ok")
        )
        groups = find_unclaimed_paths(self.extraction, [verdict_with_evidence])
        claimed_paths = {p for g in groups for p in g.example_paths}
        self.assertNotIn("backend/src/api/v1/router.py", claimed_paths)
        self.assertGreater(len(groups), 0)

    def test_no_verdicts_means_everything_is_unclaimed(self):
        groups = find_unclaimed_paths(self.extraction, [])
        total_files = sum(g.file_count for g in groups)
        self.assertGreater(total_files, 0)


if __name__ == "__main__":
    unittest.main()

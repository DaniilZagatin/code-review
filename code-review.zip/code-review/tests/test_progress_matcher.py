"""Единый агент (`run_agent`): образ результата -> клиентский путь + оценка
этапов по материалам -> вердикт.

Транспорт подменяется тем же способом, что и в остальных LLM-тестах:
`ChatClient._create` отдаёт по одному заготовленному ответу на каждый ход
сессии. Путь/строка/якорь проверяются на настоящей фикстуре `mini_repo`.

Главный инвариант, который здесь проверяется: **тексты пути не пишет модель**.
Названия этапов и буллиты приходят один раз, в `submit_plan`, и в вердикт не
пересылаются — `submit_stage` шлёт только статусы по позициям, а код сверяет
их количество с принятым путём.
"""

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from fixture_support import ensure_fixture, scripted_responses
from pko.errors import PkoError
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress import matcher
from pko.progress.matcher import (
    DEFAULT_MAX_STEPS,
    MAX_USER_STAGES,
    find_unclaimed_paths,
    load_system_prompt,
    parse_stage_titles,
    run_agent,
)
from pko.progress.pptx_reader import Slide, SlideShape
from pko.progress.schema import CriterionVerdict, EvidenceRef, ItemVerdict
from pko.report.guard import check_business_language, is_restatement

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")

SLIDES = [
    Slide(number=1, heading="Клиентский путь", shapes=[
        SlideShape(text="Постановка задачи\nКлиент передаёт задачу в работу",
                   left=0.5, top=1.2, width=4.0, height=2.2),
        SlideShape(text="Оплата подписки\nСписание за подписку по расписанию",
                   left=4.8, top=1.2, width=4.0, height=2.2),
    ]),
]

ROUTER_EVIDENCE = [{"path": "backend/src/api/v1/router.py", "line": 7,
                    "basis": "функция start_task ставит задачу в обработку"}]

# Буллиты «из образа результата» — их текст агент копирует, а не сочиняет.
BULLETS = ["Определены источники обращений", "Подтверждена скорость обработки"]

CONTEXT = {
    "client_path_name": "Постановка задачи в работу",
    "project_name": "Приём обращений",
    "client": "сотрудник поддержки, которому нужно быстро передать задачу дальше",
    "before": "задача пересылается вручную и теряется между сменами",
    "after": "задача попадает исполнителю сразу и видна обеим сторонам",
}

# Обоснование и списки намеренно не пересекаются: сторож `is_restatement`
# отклоняет пункт, собранный из слов вывода, и фикстура обязана это выдержать.
CONCLUSION = ("Ключевая ценность подтверждена: задача доходит до исполнителя без ручной "
              "пересылки. До запуска остаётся закрыть измеримость результата.")
RISKS = [
    "Нетиповые обращения уходят к дежурному — очередь на входе сохраняется",
    "Владелец качества данных не назначен — расхождения всплывают уже у клиента",
]
PRIORITIES = [
    "Назначить владельца качества данных — расхождения будут ловиться до клиента",
    "Передать типовые обращения агенту — снять очередь на входе",
]


def _call(name: str, args: dict, call_id: str | None = None) -> dict:
    return {
        "id": call_id or f"call_{name}",
        "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }


def tool_call(name: str, **args) -> dict:
    return {"content": None, "tool_calls": [_call(name, args)]}


def parallel_tool_calls(*calls: tuple[str, dict]) -> dict:
    return {"content": None, "tool_calls": [
        _call(name, args, call_id=f"call_{i}_{name}") for i, (name, args) in enumerate(calls)
    ]}


def stage(item_id: str, title: str, source_slide: int = 1,
          criteria: list[str] | None = None, description: str = "") -> dict:
    """Этап пути в контракте `submit_plan.items` — тексты как в образе результата."""
    return {
        "item_id": item_id, "title": title, "description": description,
        "criteria": BULLETS if criteria is None else criteria,
        "source_slide": source_slide,
    }


def plan_call(*stages, **context) -> dict:
    args = {**CONTEXT, **context, "items": list(stages)}
    return tool_call("submit_plan", **args)


def criterion(applicable: bool = True, status: str = "done",
              evidence: list[dict] | None = None) -> dict:
    return {"applicable": applicable, "status": status, "evidence": evidence or []}


def stage_args(item_id: str, applicable: bool = True,
               criteria: list[dict] | None = None) -> dict:
    if criteria is None:
        criteria = [criterion(status="done", evidence=ROUTER_EVIDENCE),
                    criterion(status="planned")]
    return {"item_id": item_id, "applicable": applicable, "criteria": criteria}


def rate(item_id: str, applicable: bool = True, criteria: list[dict] | None = None) -> dict:
    return tool_call("submit_stage", **stage_args(item_id, applicable, criteria))


def summary_call(decision: str = "PIVOT", readiness: int = 55,
                 conclusion: str = CONCLUSION,
                 risks: list[str] | None = None,
                 priorities: list[str] | None = None) -> dict:
    return tool_call(
        "submit_summary", decision=decision, readiness=readiness, conclusion=conclusion,
        risks=RISKS if risks is None else risks,
        priorities=PRIORITIES if priorities is None else priorities,
    )


def finish() -> dict:
    return tool_call("finish")


def malformed(text: str) -> dict:
    return {"content": text}


class MatcherAgentTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.repo = GitRepo(ensure_fixture())
        cls.sha = cls.repo.resolve("master")
        cls.tree = Tree.at(cls.repo, cls.sha)

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)

    def _run(self, *answers, slides=SLIDES, max_steps=DEFAULT_MAX_STEPS, on_verdict=None,
             on_plan=None, on_summary=None, stages=None):
        ChatClient._create = scripted_responses(*answers)
        return run_agent(
            slides, self.tree, SPEC, client=self.client, max_steps=max_steps,
            on_verdict=on_verdict, on_plan=on_plan, on_summary=on_summary, stages=stages,
        )

    def test_no_spec_returns_empty_with_note(self):
        result = run_agent(SLIDES, self.tree, spec=None)
        self.assertFalse(result.usable)
        self.assertIn("не настроен", result.notes[0])

    def test_no_content_slides_returns_empty_with_note(self):
        result = run_agent([Slide(number=1, heading=None, shapes=[])], self.tree, SPEC,
                           client=self.client)
        self.assertFalse(result.usable)
        self.assertIn("нет текстовых фигур", result.notes[0])

    def test_full_session(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи"),
                      stage("billing", "Оплата подписки")),
            tool_call("read_file", path="backend/src/api/v1/router.py"),
            rate("intake"),
            rate("billing", applicable=False,
                 criteria=[criterion(applicable=False), criterion(applicable=False)]),
            summary_call(),
            finish(),
        )
        self.assertEqual(result.source, "llm")
        self.assertEqual(len(result.items), 2)
        by_id = {v.item_id: v for v in result.verdicts}
        # Этап применим, один буллит done, второй planned -> (1 + 0) / 2 = 50%.
        self.assertEqual(by_id["intake"].percent(), 50)
        self.assertTrue(by_id["intake"].criteria[0].evidence[0].verified)
        # Неприменимый этап в картину не входит вовсе.
        self.assertIsNone(by_id["billing"].percent())
        self.assertEqual(result.readiness, 55)
        self.assertEqual(result.summary.decision, "PIVOT")
        self.assertEqual(result.context["client_path_name"], CONTEXT["client_path_name"])
        self.assertEqual(result.context["before"], CONTEXT["before"])

    def test_plan_keeps_bullet_texts_verbatim(self):
        # Тексты буллитов живут в плане и в вердикт не пересылаются — значит
        # переформулировать их модели просто нечем.
        result = self._run(
            plan_call(stage("intake", "Постановка задачи",
                            criteria=["Первый буллет как в образе", "Второй буллет"])),
            rate("intake", criteria=[criterion(status="done", evidence=ROUTER_EVIDENCE),
                                     criterion(status="partial", evidence=ROUTER_EVIDENCE)]),
            finish(),
        )
        [item] = result.plan
        self.assertEqual(item.criteria, ["Первый буллет как в образе", "Второй буллет"])
        self.assertEqual(item.to_dict()["criteria"], item.criteria)

    def test_stage_with_wrong_number_of_ratings_is_rejected(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),           # 2 буллита
            rate("intake", criteria=[criterion()]),                     # прислана 1 оценка
            rate("intake"),                                             # корректно
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(len(result.verdicts[0].criteria), 2)

    def test_unknown_status_for_applicable_criterion_is_rejected(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake", criteria=[criterion(status="почти"), criterion(status="planned")]),
            rate("intake"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(result.verdicts[0].criteria[0].status, "done")

    def test_non_applicable_criterion_drops_status_and_evidence(self):
        # Чужой пункт не должен ни портить картину, ни улучшать её: статус
        # игнорируется, ссылки не собираются.
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake", criteria=[
                criterion(applicable=False, status="done", evidence=ROUTER_EVIDENCE),
                criterion(status="done", evidence=ROUTER_EVIDENCE),
            ]),
            finish(),
        )
        verdict = result.verdicts[0]
        self.assertEqual(verdict.criteria[0].status, "")
        self.assertEqual(verdict.criteria[0].evidence, [])
        # В расчёт идёт только применимый буллет.
        self.assertEqual(verdict.percent(), 100)

    def test_stage_without_applicable_criteria_has_no_percent(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake", criteria=[criterion(applicable=False), criterion(applicable=False)]),
            finish(),
        )
        self.assertIsNone(result.verdicts[0].percent())

    def test_fabricated_evidence_is_kept_unverified_and_noted(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake", criteria=[
                criterion(status="done", evidence=[{"path": "нет/такого.py", "line": 1, "basis": "x"}]),
                criterion(status="planned"),
            ]),
            finish(),
        )
        verdict = result.verdicts[0]
        self.assertFalse(verdict.criteria[0].evidence[0].verified)
        self.assertFalse(verdict.criteria[0].is_grounded)
        self.assertIn("без единой подтверждённой ссылки", " ".join(result.notes))

    def test_planned_criterion_needs_no_evidence(self):
        # «Запланировано» — утверждение об отсутствии, подтверждать нечем.
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake", criteria=[criterion(status="planned"), criterion(status="planned")]),
            finish(),
        )
        self.assertNotIn("без единой подтверждённой ссылки", " ".join(result.notes))

    def test_stage_before_plan_is_rejected(self):
        result = self._run(
            rate("intake"),
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)

    def test_unrated_stage_is_named_in_notes(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи"),
                      stage("billing", "Оплата подписки")),
            rate("intake"),
            finish(),
        )
        self.assertIn("Оплата подписки", " ".join(result.notes))

    def test_readiness_is_clamped_and_contradiction_is_noted(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            summary_call(readiness=250),
            finish(),
        )
        self.assertEqual(result.readiness, 100)

    def test_zero_readiness_with_visible_progress_is_noted(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            summary_call(readiness=0),
            finish(),
        )
        self.assertEqual(result.readiness, 0)
        self.assertIn("расходится с оценкой этапов", " ".join(result.notes))

    def test_high_readiness_with_blocker_is_noted(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake", criteria=[criterion(status="blocked", evidence=ROUTER_EVIDENCE),
                                     criterion(status="done", evidence=ROUTER_EVIDENCE)]),
            summary_call(readiness=90, decision="GO"),
            finish(),
        )
        self.assertIn("блокирующих факторов", " ".join(result.notes))

    def test_unknown_decision_is_rejected(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            summary_call(decision="МОЖЕТ БЫТЬ"),
            summary_call(decision="NO GO"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "NO GO")

    def test_no_go_hyphen_form_is_accepted(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            summary_call(decision="no-go"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "NO GO")

    def test_summary_needs_at_least_two_risks_and_actions(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            summary_call(risks=["Единственный риск без пары"]),
            summary_call(),
            finish(),
        )
        self.assertEqual(result.summary.risks, RISKS)

    def test_technical_language_in_summary_is_rejected(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            summary_call(conclusion="Не реализована интеграция сервиса списаний."),
            summary_call(),
            finish(),
        )
        self.assertEqual(result.summary.conclusion, CONCLUSION)

    def test_risk_that_restates_the_conclusion_is_rejected(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            summary_call(risks=["Задача доходит до исполнителя без ручной пересылки, ценность подтверждена",
                                "Второй риск про очередь на входе у дежурного"]),
            summary_call(),
            finish(),
        )
        self.assertEqual(result.summary.risks, RISKS)

    def test_technical_language_in_context_rejects_the_plan(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи"),
                      before="обращения складываются в базу данных через эндпоинт"),
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            finish(),
        )
        self.assertTrue(result.usable)
        self.assertEqual(result.context["before"], CONTEXT["before"])

    def test_stage_titles_are_not_language_checked(self):
        # Название этапа — слова команды из образа результата: отклонять его
        # за чужой выбор лексики нельзя, даже если там техническое слово.
        result = self._run(
            plan_call(stage("api", "Интеграция с бюро")),
            rate("api"),
            finish(),
        )
        self.assertEqual(result.plan[0].title, "Интеграция с бюро")

    def test_user_stages_become_the_plan_verbatim(self):
        result = self._run(
            plan_call(stage("contact", "первичный   КОНТАКТ", source_slide=0),
                      stage("issue", "Выдача", source_slide=0)),
            rate("contact"),
            finish(),
            stages=["Первичный контакт", "Выдача"],
        )
        self.assertEqual([it.title for it in result.plan], ["Первичный контакт", "Выдача"])
        self.assertEqual([it.origin for it in result.plan], ["user", "user"])

    def test_plan_that_renames_a_user_stage_is_rejected(self):
        result = self._run(
            plan_call(stage("contact", "Первое касание", source_slide=0)),
            plan_call(stage("contact", "Первичный контакт", source_slide=0)),
            rate("contact"),
            finish(),
            stages=["Первичный контакт"],
        )
        self.assertEqual([it.title for it in result.plan], ["Первичный контакт"])

    def test_invalid_plan_is_rejected_then_resubmitted(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи", source_slide=99)),
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            finish(),
        )
        self.assertTrue(result.usable)
        self.assertEqual(result.plan[0].source_slide, 1)

    def test_empty_plan_is_rejected(self):
        result = self._run(
            tool_call("submit_plan", **{**CONTEXT, "items": []}),
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            finish(),
        )
        self.assertTrue(result.usable)

    def test_callbacks_fire_on_accepted_calls(self):
        plans: list[list[str]] = []
        verdicts: list[tuple[str, int | None]] = []
        summaries: list[str] = []
        self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            summary_call(),
            finish(),
            on_plan=lambda plan: plans.append([p.id for p in plan]),
            on_verdict=lambda item, v: verdicts.append((item.id, v.percent())),
            on_summary=lambda s: summaries.append(s.decision),
        )
        self.assertEqual(plans, [["intake"]])
        self.assertEqual(verdicts, [("intake", 50)])
        self.assertEqual(summaries, ["PIVOT"])

    def test_stops_after_repeated_identical_tool_call(self):
        result = self._run(
            tool_call("search", pattern="x"),
            tool_call("search", pattern="x"),
            tool_call("search", pattern="x"),
            finish(),
        )
        self.assertFalse(result.usable)
        self.assertIn("одинаковых вызова", " ".join(result.notes))

    def test_stops_at_step_budget(self):
        result = self._run(
            tool_call("list_files"),
            tool_call("search", pattern="a"),
            max_steps=2,
        )
        self.assertFalse(result.usable)
        self.assertIn("бюджет шагов", " ".join(result.notes))

    def test_budget_exhausted_keeps_accepted_verdicts(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            tool_call("search", pattern="a"),
            max_steps=3,
        )
        self.assertTrue(result.usable)
        self.assertIn("бюджет шагов", " ".join(result.notes))

    def test_tolerates_a_few_malformed_responses(self):
        result = self._run(
            malformed("извините"),
            malformed("и снова"),
            plan_call(stage("intake", "Постановка задачи")),
            rate("intake"),
            finish(),
        )
        self.assertTrue(result.usable)

    def test_gives_up_after_too_many_malformed_responses(self):
        result = self._run(malformed("x"), malformed("y"), malformed("z"), malformed("w"))
        self.assertFalse(result.usable)
        self.assertIn("не вызвал инструмент", " ".join(result.notes))

    def test_invalid_tool_arguments_json_does_not_crash(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            {"content": None, "tool_calls": [{
                "id": "bad", "type": "function",
                "function": {"name": "read_file", "arguments": "{not valid json"},
            }]},
            rate("intake"),
            finish(),
        )
        self.assertTrue(result.usable)

    def test_stage_and_finish_in_the_same_turn(self):
        result = self._run(
            plan_call(stage("intake", "Постановка задачи")),
            parallel_tool_calls(("submit_stage", stage_args("intake")), ("finish", {})),
        )
        self.assertTrue(result.usable)


class SystemPromptTest(unittest.TestCase):
    """Сборка системного промпта из редактируемых файлов.

    Тест на пропажу — не формальность: правила языка однажды уже грузились по
    вычисленному пути, файла там не оказалось, `OSError` глушился, и весь
    языковой блок молча не доходил до модели."""

    def test_both_parts_are_loaded(self):
        prompt, missing = load_system_prompt()
        self.assertEqual(missing, [])
        self.assertGreater(len(prompt), 4000)

    def test_missing_part_is_reported_not_swallowed(self):
        with tempfile.TemporaryDirectory() as empty:
            with mock.patch.object(matcher, "_PROMPT_DIR", Path(empty)):
                prompt, missing = load_system_prompt()
        self.assertEqual(missing, list(matcher._PROMPT_PARTS))
        self.assertTrue(prompt)


class StageTitlesTest(unittest.TestCase):
    """Разбор этапов, заданных человеком: и текстом из формы, и списком из CLI."""

    def test_text_is_split_by_lines_and_cleaned(self):
        self.assertEqual(
            parse_stage_titles("Первичный контакт\n\n  Сборка   предложения \nВыдача\n"),
            ["Первичный контакт", "Сборка предложения", "Выдача"],
        )

    def test_list_form_is_accepted_as_is(self):
        self.assertEqual(parse_stage_titles(["Первый", " Второй "]), ["Первый", "Второй"])

    def test_empty_input_means_stages_are_not_set(self):
        self.assertEqual(parse_stage_titles(None), [])
        self.assertEqual(parse_stage_titles("   \n\n "), [])

    def test_too_many_stages_is_rejected(self):
        with self.assertRaises(PkoError) as ctx:
            parse_stage_titles("\n".join(f"Этап {i}" for i in range(MAX_USER_STAGES + 1)))
        self.assertIn("Слишком много этапов", ctx.exception.message)

    def test_overlong_title_is_rejected(self):
        with self.assertRaises(PkoError) as ctx:
            parse_stage_titles("Этап " + "о" * 80)
        self.assertIn("длиннее", ctx.exception.message)


class StagePercentTest(unittest.TestCase):
    """Готовность этапа: вес применимых буллитов, делённый на их число.

    Та же формула, что в шаблоне дашборда, — иначе цифра в офлайн-отчёте и на
    веб-экране разойдётся."""

    def _verdict(self, *pairs):
        return ItemVerdict(
            item_id="a", applicable=True,
            criteria=[CriterionVerdict(applicable=a, status=s) for a, s in pairs],
        )

    def test_weights(self):
        self.assertEqual(self._verdict((True, "done"), (True, "done")).percent(), 100)
        self.assertEqual(self._verdict((True, "done"), (True, "planned")).percent(), 50)
        self.assertEqual(self._verdict((True, "partial"), (True, "partial")).percent(), 50)
        self.assertEqual(self._verdict((True, "blocked"), (True, "done")).percent(), 50)
        self.assertEqual(self._verdict((True, "planned"), (True, "blocked")).percent(), 0)

    def test_non_applicable_criteria_leave_the_denominator(self):
        self.assertEqual(self._verdict((True, "done"), (False, "")).percent(), 100)

    def test_stage_without_applicable_criteria_is_grey(self):
        self.assertIsNone(self._verdict((False, ""), (False, "")).percent())

    def test_non_applicable_stage_is_grey(self):
        verdict = self._verdict((True, "done"))
        verdict.applicable = False
        self.assertIsNone(verdict.percent())


class BusinessLanguageGuardTest(unittest.TestCase):
    """Лексический сторож: отклоняет техническую речь, но не трогает
    двусмысленные слова с законным банковским значением."""

    def test_technical_wording_is_flagged(self):
        for text in (
            "Реализован эндпоинт постановки задачи",
            "В коде не найдено модели скоринга",
            "Отсутствует интеграция сервиса списаний",
        ):
            with self.subTest(text=text):
                self.assertTrue(check_business_language(text))

    def test_business_wording_passes(self):
        for text in (
            "Клиент открывает счёт онлайн без визита в отделение",
            "Клиент подтверждает операцию кодом из сообщения",
            "Держатель карты получает страховое покрытие по поездке",
        ):
            with self.subTest(text=text):
                self.assertEqual(check_business_language(text), [])

    def test_restatement_detection(self):
        thesis = "Клиент ставит задачу в обработку без обращения к сотруднику"
        self.assertTrue(is_restatement(
            "Клиент ставит задачу в обработку, обращаться к сотруднику не нужно", thesis))
        self.assertFalse(is_restatement(
            "Срочные обращения по-прежнему разбирает дежурный сотрудник отделения", thesis))


class UnclaimedPathsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        repo = GitRepo(ensure_fixture())
        cls.tree = Tree.at(repo, repo.resolve("master"))
        from pko.extractors.runner import extract_all

        cls.extraction = extract_all(cls.tree)

    def test_paths_without_verified_evidence_are_reported(self):
        verdict = ItemVerdict(item_id="a", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="done", evidence=[
                EvidenceRef(path="backend/src/api/v1/router.py", line=7,
                            basis="start_task", verified=True, reason="ok"),
            ]),
        ])
        groups = find_unclaimed_paths(self.extraction, [verdict])
        claimed = {p for g in groups for p in g.example_paths}
        self.assertNotIn("backend/src/api/v1/router.py", claimed)

    def test_no_verdicts_means_everything_is_unclaimed(self):
        groups = find_unclaimed_paths(self.extraction, [])
        self.assertGreater(sum(g.file_count for g in groups), 0)


if __name__ == "__main__":
    unittest.main()

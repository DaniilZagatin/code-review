"""Заготовки вызовов агента для сквозных тестов (CLI, веб, пайплайн, vision).

Раньше каждый из этих тестов держал собственную копию сценария «план →
оценка → вердикт». Контракт агента менялся — и правок требовали четыре файла
сразу, причём молча: тест с устаревшим вызовом не падал, а просто переставал
доходить до вердикта и проверял пустую модель. Здесь один сценарий на всех;
детально контракт разбирается в `test_progress_matcher.py`.
"""

import json

CLIENT_PATH_NAME = "Постановка задачи в работу"
PROJECT_NAME = "Редизайн платёжного сервиса"
CLIENT = "сотрудник поддержки, которому нужно быстро передать задачу дальше"
BEFORE = "задача пересылается вручную и теряется между сменами"
AFTER = "задача попадает исполнителю сразу и видна обеим сторонам"

STAGE_ID = "tasks-api"
STAGE_TITLE = "Постановка задач"
STAGE_DESCRIPTION = "Клиент передаёт задачу в работу и видит её статус без звонка"
BULLETS = ["Определены источники обращений", "Подтверждена скорость обработки"]

CONCLUSION = ("Ключевая ценность подтверждена: задача доходит до исполнителя без ручной "
              "пересылки. До запуска остаётся закрыть измеримость результата.")
RISKS = [
    "Нетиповые обращения уходят к дежурному — очередь на входе сохраняется",
    "Владелец качества данных не назначен — расхождения всплывают уже у клиента",
]
PRIORITIES = [
    "Назначить владельца качества данных — расхождения будут ловиться до клиента",
    "Передать типовые обращения агенту — снять очередь на входе",
]

ROUTER_EVIDENCE = [{"path": "backend/src/api/v1/router.py", "line": 7,
                    "basis": "функция start_task ставит задачу в обработку"}]


def tool_call(call_id: str, name: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": call_id, "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


def plan_args(item_id: str = STAGE_ID, title: str = STAGE_TITLE, source_slide: int = 2,
              bullets: list[str] | None = None, **overrides) -> dict:
    args = {
        "client_path_name": CLIENT_PATH_NAME,
        "project_name": PROJECT_NAME,
        "client": CLIENT,
        "before": BEFORE,
        "after": AFTER,
        "items": [{
            "item_id": item_id, "title": title, "description": STAGE_DESCRIPTION,
            "criteria": BULLETS if bullets is None else bullets,
            "source_slide": source_slide,
        }],
    }
    args.update(overrides)
    return args


def stage_args(item_id: str = STAGE_ID, applicable: bool = True,
               statuses: list[str] | None = None,
               evidence: list[dict] | None = None) -> dict:
    statuses = statuses or ["done", "planned"]
    criteria = []
    for index, status in enumerate(statuses):
        row: dict = {"applicable": True, "status": status}
        if status != "planned":
            row["evidence"] = ROUTER_EVIDENCE if evidence is None else evidence
        criteria.append(row)
    return {"item_id": item_id, "applicable": applicable, "criteria": criteria}


def summary_args(decision: str = "PIVOT", readiness: int = 55) -> dict:
    return {"decision": decision, "readiness": readiness, "conclusion": CONCLUSION,
            "risks": list(RISKS), "priorities": list(PRIORITIES)}


def full_session(**kwargs) -> list[dict]:
    """Полный сценарий: путь → оценка этапа → вердикт → finish."""
    return [
        tool_call("call_plan", "submit_plan", **plan_args(**kwargs.get("plan", {}))),
        tool_call("call_stage", "submit_stage", **stage_args(**kwargs.get("stage", {}))),
        tool_call("call_summary", "submit_summary", **summary_args(**kwargs.get("summary", {}))),
        tool_call("call_finish", "finish"),
    ]

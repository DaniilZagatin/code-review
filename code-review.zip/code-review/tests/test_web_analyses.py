"""Веб API `pko progress`: `POST /api/analyses` -> SSE-прогресс -> `GET /api/analyses/{id}`.

Заменяет собой прежний `test_web_app.py` (тестировал синхронный `POST
/api/progress`+`GET /` — оба маршрута удалены вместе со старой страницей
`frontend/index.html`, см. README/план). `TestClient` синхронный, без реального
порта; фоновый поток задачи (`web.analyses._execute`) успевает завершиться до
того, как `GET .../events` дочитает поток до конца — тест только это и ждёт.

LLM подменяется тем же способом, что и в `test_progress_cli.py`: скриптованный
`ChatClient._request` + `DEFAULT_CACHE_DIR` во временном каталоге.
"""

import json
import os
import tempfile
import threading
import time
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

import pko.llm.client as client_module
import pko.web.app as app_module
from fixture_support import ensure_fixture, scripted_responses
from pko.llm.client import ChatClient
from pko.web import analyses
from pko.web.app import app
from test_progress_pptx import build_sample_deck

ENV_KEYS = ("PKO_ASSEMBLER_BASE_URL", "PKO_ASSEMBLER_MODEL", "PKO_ASSEMBLER_API_KEY")


def _tool_call(call_id: str, name: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": call_id, "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


def _parse_sse(text: str) -> list[dict]:
    events = []
    for line in text.splitlines():
        if line.startswith("data: "):
            events.append(json.loads(line[len("data: "):]))
    return events


class WebAnalysesTest(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.plan_path = Path(self.tmp.name) / "plan.pptx"
        build_sample_deck(self.plan_path)

        self._original_cache_dir = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = Path(self.tmp.name) / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._original_cache_dir)

        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)

        self._original_env = {k: os.environ.get(k) for k in ENV_KEYS}
        os.environ.update({
            "PKO_ASSEMBLER_BASE_URL": "https://stub.local/v1",
            "PKO_ASSEMBLER_MODEL": "stub-model",
            "PKO_ASSEMBLER_API_KEY": "x",
        })

        def _restore_env():
            for k, v in self._original_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

        self.addCleanup(_restore_env)

    def _create(self, repository: str = "", branch: str = "", plan_path: Path | None = None,
                extra_files: dict[str, bytes] | None = None, stages: str = "",
                plan_copies: int = 1):
        plan_path = plan_path or self.plan_path
        data = plan_path.read_bytes()
        upload_files = [
            ("presentation", (f"{i}-{plan_path.name}", data, "application/octet-stream"))
            for i in range(1, plan_copies + 1)
        ]
        for name, blob in (extra_files or {}).items():
            upload_files.append(("files", (name, blob, "application/octet-stream")))
        return self.client.post(
            "/api/analyses",
            files=upload_files,
            data={"repository": repository, "branch": branch, "stages": stages},
        )

    def test_full_run_streams_events_then_ready_analysis(self):
        plan_answer = _tool_call(
            "call_plan", "submit_plan",
            project_title="Редизайн платёжного сервиса",
            client="клиент платёжного сервиса",
            items=[{"item_id": "tasks-api", "title": "Постановка задач",
                    "source_slide": 2}],
        )
        stage_answer = _tool_call(
            "call_stage", "submit_stage",
            item_id="tasks-api",
            stage_summary="Клиент передаёт задачу в работу самостоятельно",
            capabilities=[{
                "capability": "Клиент ставит задачу в обработку без обращения к сотруднику",
                "availability": "AVAILABLE", "who_acts": "AGENT",
                "detail": "Нетиповые обращения по-прежнему разбирает специалист отделения",
            }],
            stage_status="DONE",
            evidence=[{"path": "backend/src/api/v1/router.py", "line": 7,
                       "basis": "функция start_task ставит задачу в обработку"}],
            execution_mode="AUTO", execution_type="REACTIVE_ACTION",
            completion_status="ACHIEVED", objects_found=[], technical_notes="",
        )
        summary_answer = _tool_call(
            "call_summary", "submit_summary",
            conclusion="Клиент ставит задачи в работу самостоятельно.",
            risks=["Результат этапа не измеряется — вклад в обслуживание клиентов не виден"],
            priorities=["Начать измерять результат этапа — увидеть эффект для клиентов"],
        )
        finish_answer = _tool_call("call_finish", "finish")
        ChatClient._create = scripted_responses(
            plan_answer, stage_answer, summary_answer, finish_answer,
        )

        create_resp = self._create(repository=str(ensure_fixture()))
        self.assertEqual(create_resp.status_code, 200, create_resp.text)
        body = create_resp.json()
        self.assertEqual(body["status"], "PROCESSING")
        analysis_id = body["analysis_id"]

        events_resp = self.client.get(f"/api/analyses/{analysis_id}/events")
        self.assertEqual(events_resp.status_code, 200)
        events = _parse_sse(events_resp.text)
        self.assertEqual([e["type"] for e in events], [
            "phase", "phase", "presentation_parsed", "plan_ready",
            "claim_verified", "summary_ready", "analysis_ready",
        ])
        self.assertEqual(events[0]["phase"], "materials_loading")
        self.assertEqual(events[1]["phase"], "materials_ready")
        self.assertEqual(events[3], {
            "type": "plan_ready", "item_count": 1,
            "items": [{"title": "Постановка задач", "source_slide": 2, "origin": "slide"}],
        })
        self.assertEqual(events[4], {
            "type": "claim_verified", "title": "Постановка задач", "status": "DONE",
            "progress": 100, "execution_mode": "AUTO", "execution_type": "REACTIVE_ACTION",
            "completion_status": "ACHIEVED", "object_kinds": [],
        })
        self.assertEqual(events[5]["type"], "summary_ready")
        self.assertIn("самостоятельно", events[5]["text"])

        get_resp = self.client.get(f"/api/analyses/{analysis_id}")
        self.assertEqual(get_resp.status_code, 200)
        result = get_resp.json()
        self.assertEqual(result["status"], "READY")
        self.assertEqual(result["counts"]["DONE"], 1)
        self.assertEqual(result["readiness"], 1.0)
        [item] = result["items"]
        self.assertEqual(item["title"], "Постановка задач")
        self.assertEqual(item["status"], "DONE")
        self.assertEqual(item["label"], "Сделано")
        self.assertEqual(item["color"], "green")
        self.assertEqual(item["pct"], 100)
        # Контракт фронта не менялся: assessment остаётся списком
        # status/text/comment. Изменилось то, что за ним стоит — бизнес-
        # возможность вместо выполненной задачи, а комментарий пишет модель:
        # код больше не склеивает его из шаблонной подписи who_acts.
        self.assertEqual(item["assessment"], [{
            "status": "done",
            "text": "Клиент ставит задачу в обработку без обращения к сотруднику",
            "comment": "Нетиповые обращения по-прежнему разбирает специалист отделения",
        }])
        # Описание в карточке — то, что агент написал после разбора материалов,
        # а не только вычитал со слайда.
        self.assertEqual(item["description"], "Клиент передаёт задачу в работу самостоятельно")
        # Бизнес-контракт: никаких путей к файлам/тестов/технических деталей
        # в этом JSON нет вообще.
        self.assertNotIn("evidence", item)
        self.assertNotIn("backend/src/api/v1/router.py", get_resp.text)
        # Общий вывод reporter'а по всем этапам — отдельное поле, не внутри item.
        # Контракт `ProjectSummary` (conclusion/risks/priorities): агент заполняет
        # три независимых поля, фронт рендерит три колонки без парсинга.
        self.assertEqual(result["summary"], {
            "conclusion": "Клиент ставит задачи в работу самостоятельно.",
            "risks": ["Результат этапа не измеряется — вклад в обслуживание клиентов не виден"],
            "priorities": ["Начать измерять результат этапа — увидеть эффект для клиентов"],
        })
        # Название проекта в шапку берётся из содержания презентации (заголовок
        # первого непустого слайда), не из имени файла/репозитория.
        self.assertEqual(result["meta"]["title"], "Редизайн платёжного сервиса")

    def test_events_stream_sends_heartbeat_while_agent_is_slow(self):
        # Реальный шаг агента (не скриптованный LLM в этих тестах) может
        # занимать до ChatClient.timeout (120с) — без heartbeat простаивающее
        # SSE-соединение рискует быть закрытым прокси с более коротким
        # idle-таймаутом. Здесь эмулируем "медленный шаг" напрямую через
        # AnalysisJob, без реального пайплайна: интервал heartbeat уменьшен,
        # событие приходит позже него, но раньше, чем тест устанет ждать.
        job = analyses.AnalysisJob(id="an_slow_test")
        analyses._JOBS[job.id] = job
        self.addCleanup(analyses._JOBS.pop, job.id, None)

        original_heartbeat = app_module._HEARTBEAT_SECONDS
        app_module._HEARTBEAT_SECONDS = 0.05
        self.addCleanup(setattr, app_module, "_HEARTBEAT_SECONDS", original_heartbeat)

        def deliver_after_delay():
            time.sleep(0.2)
            job.events.put({"type": "analysis_ready"})

        threading.Thread(target=deliver_after_delay, daemon=True).start()

        resp = self.client.get(f"/api/analyses/{job.id}/events")
        self.assertEqual(resp.status_code, 200)
        self.assertIn(": keepalive\n\n", resp.text)
        events = _parse_sse(resp.text)
        self.assertEqual(events, [{"type": "analysis_ready"}])

    def test_files_only_analysis_runs_without_any_repository(self):
        plan_answer = _tool_call(
            "call_plan", "submit_plan",
            project_title="Обучение модели",
            client="аналитик подразделения",
            items=[{"item_id": "model", "title": "Обучение модели", "source_slide": 1}],
        )
        stage_answer = _tool_call(
            "call_stage", "submit_stage", item_id="model",
            stage_summary="Аналитик получает готовую оценку без ручного разбора",
            capabilities=[{
                "capability": "Аналитик получает оценку по обращению без ручного разбора",
                "availability": "AVAILABLE", "who_acts": "AGENT",
                "detail": "Нетиповые обращения по-прежнему разбирает сотрудник отделения",
            }],
            stage_status="DONE", evidence=[],
            execution_mode="", execution_type="", completion_status="",
            objects_found=[], technical_notes="",
        )
        finish_answer = _tool_call("call_finish", "finish")
        ChatClient._create = scripted_responses(plan_answer, stage_answer, finish_answer)

        create_resp = self._create(extra_files={"metrics.json": b'{"roc_auc": 0.88}'})
        self.assertEqual(create_resp.status_code, 200, create_resp.text)
        analysis_id = create_resp.json()["analysis_id"]

        events = _parse_sse(self.client.get(f"/api/analyses/{analysis_id}/events").text)
        self.assertEqual(events[-1]["type"], "analysis_ready")
        self.assertEqual(events[0]["phase"], "materials_loading")

        result = self.client.get(f"/api/analyses/{analysis_id}").json()
        self.assertEqual(result["status"], "READY")
        # Без репозитория meta["repo"] пусто; название проекта для шапки
        # фронт берёт из meta["title"] (заголовок слайда), не из repo.
        self.assertEqual(result["meta"]["repo"], "")

    def test_repository_and_files_together_are_merged_into_one_analysis(self):
        plan_answer = _tool_call(
            "call_plan", "submit_plan",
            project_title="Редизайн платёжного сервиса",
            client="клиент платёжного сервиса",
            items=[{"item_id": "tasks-api", "title": "Постановка задач",
                    "source_slide": 2}],
        )
        stage_answer = _tool_call(
            "call_stage", "submit_stage", item_id="tasks-api",
            stage_summary="Клиент передаёт задачу в работу самостоятельно",
            capabilities=[{
                "capability": "Клиент ставит задачу в обработку без обращения к сотруднику",
                "availability": "AVAILABLE", "who_acts": "AGENT",
                "detail": "Нетиповые обращения по-прежнему разбирает сотрудник отделения",
            }],
            stage_status="DONE",
            evidence=[{"path": "metrics.json", "line": 1, "basis": "roc_auc в metrics.json"}],
            execution_mode="", execution_type="", completion_status="",
            objects_found=[], technical_notes="",
        )
        finish_answer = _tool_call("call_finish", "finish")
        ChatClient._create = scripted_responses(plan_answer, stage_answer, finish_answer)

        create_resp = self._create(
            repository=str(ensure_fixture()),
            extra_files={"metrics.json": b'{"roc_auc": 0.9}'},
        )
        self.assertEqual(create_resp.status_code, 200, create_resp.text)
        analysis_id = create_resp.json()["analysis_id"]
        self.client.get(f"/api/analyses/{analysis_id}/events")  # дождаться завершения

        result = self.client.get(f"/api/analyses/{analysis_id}").json()
        self.assertEqual(result["status"], "READY")
        # Репозиторий остался источником имени/коммита — файлы дополняют, не подменяют его.
        self.assertNotEqual(result["meta"]["repo"], "")

    def test_neither_repository_nor_files_still_runs_against_an_empty_workspace(self):
        # Не ошибка запроса: агент получает пустой снимок материалов и сам
        # решает, что писать в вердикт — здесь он честно отчитывается, что
        # подтверждения не нашёл (тот же путь, что и "в репозитории пусто").
        plan_answer = _tool_call(
            "call_plan", "submit_plan",
            project_title="Редизайн платёжного сервиса",
            client="клиент платёжного сервиса",
            items=[{"item_id": "tasks-api", "title": "Постановка задач",
                    "source_slide": 2}],
        )
        stage_answer = _tool_call(
            "call_stage", "submit_stage", item_id="tasks-api",
            stage_summary="Клиент передаёт задачу в работу самостоятельно",
            capabilities=[{
                "capability": "Клиент ставит задачу в обработку без обращения к сотруднику",
                "availability": "NOT_AVAILABLE", "who_acts": "HUMAN",
                "detail": "Каждое обращение разбирает сотрудник — объём упирается в его рабочий день",
            }],
            stage_status="NOT_STARTED", evidence=[],
            execution_mode="", execution_type="", completion_status="",
            objects_found=[], technical_notes="",
        )
        finish_answer = _tool_call("call_finish", "finish")
        ChatClient._create = scripted_responses(plan_answer, stage_answer, finish_answer)

        create_resp = self._create()
        self.assertEqual(create_resp.status_code, 200, create_resp.text)
        analysis_id = create_resp.json()["analysis_id"]

        events = _parse_sse(self.client.get(f"/api/analyses/{analysis_id}/events").text)
        self.assertEqual(events[-1]["type"], "analysis_ready")

        result = self.client.get(f"/api/analyses/{analysis_id}").json()
        self.assertEqual(result["status"], "READY")
        self.assertEqual(result["meta"]["repo"], "")
        [item] = result["items"]
        self.assertEqual(item["status"], "NOT_STARTED")

    def test_stages_from_the_form_become_the_plan(self):
        # Третий источник этапов: человек задал их в форме. Агент обязан
        # вернуть ровно их — план помечается origin="user", номера слайда у
        # таких этапов нет.
        plan_answer = _tool_call(
            "call_plan", "submit_plan",
            project_title="Редизайн платёжного сервиса",
            client="клиент платёжного сервиса",
            items=[
                {"item_id": "contact", "title": "Первичный контакт", "source_slide": 0},
                {"item_id": "issue", "title": "Выдача", "source_slide": 0},
            ],
        )

        def stage(item_id):
            return _tool_call(
                f"call_{item_id}", "submit_stage", item_id=item_id,
                stage_summary="Клиент проходит этап без обращения к сотруднику",
                capabilities=[{
                    "capability": "Клиент проходит этап без обращения к сотруднику",
                    "availability": "AVAILABLE", "who_acts": "AGENT",
                "detail": "Нетиповые обращения по-прежнему разбирает сотрудник отделения",
                }],
                stage_status="DONE", evidence=[],
                execution_mode="", execution_type="", completion_status="",
                objects_found=[], technical_notes="",
            )

        ChatClient._create = scripted_responses(
            plan_answer, stage("contact"), stage("issue"), _tool_call("call_finish", "finish"),
        )

        create_resp = self._create(
            repository=str(ensure_fixture()),
            stages="Первичный контакт\nВыдача\n",
        )
        self.assertEqual(create_resp.status_code, 200, create_resp.text)
        analysis_id = create_resp.json()["analysis_id"]

        events = _parse_sse(self.client.get(f"/api/analyses/{analysis_id}/events").text)
        plan_ready = next(e for e in events if e["type"] == "plan_ready")
        self.assertEqual(plan_ready["items"], [
            {"title": "Первичный контакт", "source_slide": 0, "origin": "user"},
            {"title": "Выдача", "source_slide": 0, "origin": "user"},
        ])

        result = self.client.get(f"/api/analyses/{analysis_id}").json()
        self.assertEqual(result["status"], "READY")
        self.assertEqual([i["title"] for i in result["items"]],
                         ["Первичный контакт", "Выдача"])

    def test_too_many_stages_is_a_clean_400_before_the_job_starts(self):
        create_resp = self._create(
            repository=str(ensure_fixture()),
            stages="\n".join(f"Этап {i}" for i in range(1, 15)),
        )
        self.assertEqual(create_resp.status_code, 400)
        self.assertIn("этапов", create_resp.json()["message"].lower())

    def test_several_presentation_files_are_accepted(self):
        # Образ результата из двух файлов — валидный вход; слайды склеиваются,
        # meta.plan_source перечисляет оба.
        plan_answer = _tool_call(
            "call_plan", "submit_plan",
            project_title="Редизайн платёжного сервиса",
            client="клиент платёжного сервиса",
            project_summary="Клиент проводит платежи сам, а отделение перестаёт быть узким местом",
            items=[{"item_id": "tasks-api", "title": "Постановка задач", "source_slide": 2}],
        )
        stage_answer = _tool_call(
            "call_stage", "submit_stage", item_id="tasks-api",
            stage_summary="Клиент передаёт задачу в работу самостоятельно",
            capabilities=[{
                "capability": "Клиент ставит задачу в обработку без обращения к сотруднику",
                "availability": "AVAILABLE", "who_acts": "AGENT",
                "detail": "Нетиповые обращения по-прежнему разбирает специалист отделения",
            }],
            stage_status="DONE", evidence=[],
            execution_mode="", execution_type="", completion_status="",
            objects_found=[], technical_notes="",
        )
        ChatClient._create = scripted_responses(
            plan_answer, stage_answer, _tool_call("call_finish", "finish"),
        )

        create_resp = self._create(repository=str(ensure_fixture()), plan_copies=2)
        self.assertEqual(create_resp.status_code, 200, create_resp.text)
        analysis_id = create_resp.json()["analysis_id"]
        self.client.get(f"/api/analyses/{analysis_id}/events")

        result = self.client.get(f"/api/analyses/{analysis_id}").json()
        self.assertEqual(result["status"], "READY")
        self.assertIn("1-plan.pptx", result["meta"]["plan_source"])
        self.assertIn("2-plan.pptx", result["meta"]["plan_source"])
        # Описание проекта от агента едет в шапку вместо статичной фразы.
        self.assertEqual(
            result["meta"]["description"],
            "Клиент проводит платежи сам, а отделение перестаёт быть узким местом",
        )

    def test_analysis_without_presentation_is_a_clean_400(self):
        resp = self.client.post(
            "/api/analyses",
            files=[("files", ("metrics.json", b"{}", "application/octet-stream"))],
            data={"repository": "", "branch": "", "stages": ""},
        )
        self.assertEqual(resp.status_code, 400)
        self.assertIn("образ результата", resp.json()["message"].lower())

    def test_thinking_flag_is_forwarded_to_get_spec(self):
        # Переключатель thinking с формы пробрасывается в get_spec и имеет
        # приоритет над env PKO_THINKING (см. web/app.py::create_analysis).
        captured: list[bool | None] = []

        def fake_get_spec(role, thinking=None, **_):
            if role == "matcher":
                captured.append(thinking)
            return object()  # значение не важно — create_analysis ниже подменён

        def fake_create_analysis(**_):
            return analyses.AnalysisJob(id="an_thinking_test")

        self.addCleanup(setattr, app_module, "get_spec", app_module.get_spec)
        self.addCleanup(setattr, analyses, "create_analysis", analyses.create_analysis)
        app_module.get_spec = fake_get_spec
        analyses.create_analysis = fake_create_analysis

        with open(self.plan_path, "rb") as fh:
            self.client.post(
                "/api/analyses",
                files=[("presentation", (self.plan_path.name, fh, "application/octet-stream"))],
                data={"repository": "", "branch": "", "thinking": "true"},
            )
        with open(self.plan_path, "rb") as fh:
            self.client.post(
                "/api/analyses",
                files=[("presentation", (self.plan_path.name, fh, "application/octet-stream"))],
                data={"repository": "", "branch": ""},
            )

        self.assertEqual(captured, [True, False])

    def test_unknown_analysis_id_is_a_clean_400_not_a_500(self):
        resp = self.client.get("/api/analyses/an_doesnotexist")
        self.assertEqual(resp.status_code, 400)
        self.assertTrue(resp.json()["message"])

        events_resp = self.client.get("/api/analyses/an_doesnotexist/events")
        self.assertEqual(events_resp.status_code, 400)

    def test_dashboard_html_endpoint_returns_selfcontained_html(self):
        # Тот же прогон, что в test_full_run...: READY-анализ с одним пунктом
        # DONE и структурированным summary. Эндпоинт dashboard.html отдаёт
        # самодостаточный HTML из того же job.result — данные агента в нём, но
        # никаких путей к файлам/тестов (как и в _dashboard_json).
        plan_answer = _tool_call(
            "call_plan", "submit_plan",
            project_title="Редизайн платёжного сервиса",
            client="клиент платёжного сервиса",
            items=[{"item_id": "tasks-api", "title": "Постановка задач",
                    "source_slide": 2}],
        )
        stage_answer = _tool_call(
            "call_stage", "submit_stage",
            item_id="tasks-api",
            stage_summary="Клиент передаёт задачу в работу самостоятельно",
            capabilities=[{
                "capability": "Клиент ставит задачу в обработку без обращения к сотруднику",
                "availability": "AVAILABLE", "who_acts": "AGENT",
                "detail": "Нетиповые обращения по-прежнему разбирает специалист отделения",
            }],
            stage_status="DONE",
            evidence=[{"path": "backend/src/api/v1/router.py", "line": 7,
                       "basis": "функция start_task ставит задачу в обработку"}],
            execution_mode="AUTO", execution_type="REACTIVE_ACTION",
            completion_status="ACHIEVED", objects_found=[], technical_notes="",
        )
        summary_answer = _tool_call(
            "call_summary", "submit_summary",
            conclusion="Клиент ставит задачи в работу самостоятельно.",
            risks=["Результат этапа не измеряется — вклад в обслуживание клиентов не виден"],
            priorities=["Начать измерять результат этапа — увидеть эффект для клиентов"],
        )
        finish_answer = _tool_call("call_finish", "finish")
        ChatClient._create = scripted_responses(
            plan_answer, stage_answer, summary_answer, finish_answer,
        )

        analysis_id = self._create(repository=str(ensure_fixture())).json()["analysis_id"]
        # Дождаться завершения фонового потока.
        self.client.get(f"/api/analyses/{analysis_id}/events")

        resp = self.client.get(f"/api/analyses/{analysis_id}/dashboard.html")
        self.assertEqual(resp.status_code, 200, resp.text)
        self.assertIn("text/html", resp.headers["content-type"])
        # Самодостаточный HTML из шаблона + данные агента.
        self.assertIn("window.__DATA__", resp.text)
        self.assertIn("Редизайн платёжного сервиса", resp.text)
        self.assertIn("Клиент ставит задачу в обработку", resp.text)
        self.assertIn("Начать измерять результат этапа", resp.text)
        # Бизнес-контракт: путей к файлам репозитория в дашборде нет.
        self.assertNotIn("backend/src/api/v1/router.py", resp.text)

    def test_dashboard_html_for_processing_or_unknown_is_a_clean_400(self):
        # Неизвестный id — тот же чистый 400, что у GET .../analyses/{id}.
        self.assertEqual(
            self.client.get("/api/analyses/an_doesnotexist/dashboard.html").status_code, 400,
        )

    def test_non_pptx_filename_is_rejected_synchronously(self):
        bad = Path(self.tmp.name) / "plan.txt"
        bad.write_text("не презентация", encoding="utf-8")
        resp = self._create(repository=str(ensure_fixture()), plan_path=bad)
        self.assertEqual(resp.status_code, 400)
        self.assertIn(".pptx", resp.json()["message"])

    def test_missing_llm_config_is_a_clean_400_before_any_job_is_created(self):
        for k in ENV_KEYS:
            os.environ.pop(k, None)
        resp = self._create(repository=str(ensure_fixture()))
        self.assertEqual(resp.status_code, 400)
        self.assertIn("LLM", resp.json()["message"])

    def test_nonexistent_repo_surfaces_as_error_event_and_error_status(self):
        ChatClient._create = scripted_responses(json.dumps({}))
        missing = str(Path(self.tmp.name) / "no-such-repo")
        analysis_id = self._create(repository=missing).json()["analysis_id"]

        events = _parse_sse(self.client.get(f"/api/analyses/{analysis_id}/events").text)
        self.assertEqual(events[-1]["type"], "error")
        self.assertTrue(events[-1]["message"])

        result = self.client.get(f"/api/analyses/{analysis_id}")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.json()["status"], "ERROR")


if __name__ == "__main__":
    unittest.main()

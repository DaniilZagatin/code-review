"""`run_progress` — сквозная сборка ProgressModel, с фокусом на `on_event`.

Остальное поведение пайплайна (сборка ProgressModel/ошибка при неюзабельном
результате) уже покрыто `tests/test_progress_cli.py`/`tests/test_web_analyses.py`
через CLI и веб-эндпоинт соответственно — здесь только колбэк живого
прогресса, напрямую через `run_progress`, без CLI/HTTP обвязки.
"""

import json
import tempfile
import unittest
from pathlib import Path

import pko.llm.client as client_module
from fixture_support import ensure_fixture, scripted_responses
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress.pipeline import run_progress
from pko.progress.target_repo import TargetRepo, load_target
from test_progress_pptx import build_sample_deck

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")


def _tool_call(call_id: str, name: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": call_id, "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


class RunProgressOnEventTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        tmp_path = Path(self.tmp.name)

        self.plan_path = tmp_path / "plan.pptx"
        build_sample_deck(self.plan_path)

        repo = GitRepo(ensure_fixture())
        self.target: TargetRepo = load_target(repo, "master")

        self._original_cache_dir = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = tmp_path / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._original_cache_dir)

        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)

    def test_on_event_receives_phases_and_claims_in_order(self):
        plan_answer = _tool_call(
            "call_plan", "submit_plan",
            project_title="Редизайн платёжного сервиса",
            client="клиент платёжного сервиса",
            client_goal="передать задачу в работу без обращения к сотруднику",
            items=[{"item_id": "tasks-api", "title": "Постановка задач",
                    "source_slide": 2}],
        )
        stage_answer = _tool_call(
            "call_stage", "submit_stage",
            item_id="tasks-api",
            stage_summary="Клиент передаёт задачу в работу самостоятельно",
            capabilities=[{
                "capability": "Клиент ставит задачу в обработку без обращения к сотруднику",
                "availability": "AVAILABLE", "who_acts": "AGENT", "limit": "",
            }],
            stage_status="DONE",
            evidence=[{"path": "backend/src/api/v1/router.py", "line": 7,
                       "basis": "функция start_task ставит задачу в обработку"}],
            execution_mode="AUTO", execution_type="REACTIVE_ACTION",
            completion_status="ACHIEVED", objects_found=[], technical_notes="",
        )
        summary_answer = _tool_call(
            "call_summary", "submit_summary",
            conclusion="Клиент ставит задачи в работу самостоятельно.",
            risks=["Результат этапа не измеряется — вклад в обслуживание клиентов не виден"],
            priorities=["Начать измерять результат этапа — увидеть эффект для клиентов"],
        )
        finish_answer = _tool_call("call_finish", "finish")
        ChatClient._create = scripted_responses(
            plan_answer, stage_answer, summary_answer, finish_answer,
        )

        events: list[tuple[str, dict]] = []
        model = run_progress(
            self.plan_path, "demo-repo", self.target, SPEC,
            on_event=lambda kind, data: events.append((kind, data)),
        )

        self.assertEqual([kind for kind, _ in events], [
            "presentation_parsed", "plan_ready", "claim_verified", "summary_ready",
        ])
        self.assertGreater(events[0][1]["slide_count"], 0)
        self.assertEqual(events[1][1]["item_count"], 1)
        self.assertEqual(events[1][1]["items"][0]["title"], "Постановка задач")
        self.assertEqual(events[2][1], {
            "title": "Постановка задач", "status": "DONE", "progress": 100,
            "execution_mode": "AUTO", "execution_type": "REACTIVE_ACTION",
            "completion_status": "ACHIEVED", "object_kinds": [],
        })
        self.assertEqual(events[3][1]["text"], "Клиент ставит задачи в работу самостоятельно.")
        # sanity: колбэк — побочный эффект, сама модель собирается как обычно.
        self.assertEqual(model.counts()["DONE"], 1)
        self.assertEqual(model.summary.conclusion, "Клиент ставит задачи в работу самостоятельно.")
        self.assertEqual(
            model.summary.risks,
            ["Результат этапа не измеряется — вклад в обслуживание клиентов не виден"],
        )
        self.assertEqual(model.summary_source, "llm")
        self.assertEqual(model.meta["title"], "Редизайн платёжного сервиса")
        # Кто клиент — едет в meta рядом с названием проекта.
        self.assertEqual(model.meta["client"], "клиент платёжного сервиса")

    def test_without_on_event_behaves_exactly_as_before(self):
        plan_answer = _tool_call(
            "call_plan", "submit_plan",
            project_title="Редизайн платёжного сервиса",
            client="клиент платёжного сервиса",
            items=[{"item_id": "tasks-api", "title": "Постановка задач",
                    "source_slide": 2}],
        )
        stage_answer = _tool_call(
            "call_stage", "submit_stage", item_id="tasks-api",
            stage_summary="Клиент передаёт задачу в работу самостоятельно",
            capabilities=[{
                "capability": "Клиент ставит задачу в обработку без обращения к сотруднику",
                "availability": "NOT_AVAILABLE", "who_acts": "HUMAN", "limit": "",
            }],
            stage_status="NOT_STARTED", evidence=[],
            execution_mode="", execution_type="", completion_status="",
            objects_found=[], technical_notes="",
        )
        summary_answer = _tool_call(
            "call_summary", "submit_summary",
            conclusion="Клиент пока не может передать задачу без сотрудника.",
        )
        finish_answer = _tool_call("call_finish", "finish")
        ChatClient._create = scripted_responses(
            plan_answer, stage_answer, summary_answer, finish_answer,
        )

        model = run_progress(self.plan_path, "demo-repo", self.target, SPEC)
        self.assertEqual(model.counts()["NOT_STARTED"], 1)
        self.assertEqual(model.summary.conclusion,
                         "Клиент пока не может передать задачу без сотрудника.")


if __name__ == "__main__":
    unittest.main()

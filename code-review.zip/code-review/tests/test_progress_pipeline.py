"""`run_progress` — сквозная сборка ProgressModel, с фокусом на `on_event`.

Остальное поведение пайплайна (сборка модели/ошибка при неюзабельном
результате) уже покрыто `tests/test_progress_cli.py`/`tests/test_web_analyses.py`
через CLI и веб-эндпоинт соответственно — здесь только колбэк живого
прогресса, напрямую через `run_progress`, без CLI/HTTP обвязки, и склейка
нескольких файлов образа результата.
"""

import re
import tempfile
import unittest
from pathlib import Path

import pko.llm.client as client_module
from agent_script import (
    CLIENT,
    CLIENT_PATH_NAME,
    CONCLUSION,
    PROJECT_NAME,
    RISKS,
    STAGE_TITLE,
    full_session,
    tool_call,
)
from fixture_support import ensure_fixture, scripted_responses
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress.pipeline import run_progress
from pko.progress.target_repo import TargetRepo, load_target
from test_progress_pptx import build_sample_deck

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")


class RunProgressOnEventTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        tmp_path = Path(self.tmp.name)

        self.plan_path = tmp_path / "plan.pptx"
        build_sample_deck(self.plan_path)

        repo = GitRepo(ensure_fixture())
        self.target: TargetRepo = load_target(repo, "master")

        self._original_cache_dir = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = tmp_path / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._original_cache_dir)

        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)

    def test_on_event_receives_phases_and_claims_in_order(self):
        ChatClient._create = scripted_responses(*full_session())

        events: list[tuple[str, dict]] = []
        model = run_progress(
            self.plan_path, "demo-repo", self.target, SPEC,
            on_event=lambda kind, data: events.append((kind, data)),
        )

        self.assertEqual([kind for kind, _ in events], [
            "presentation_parsed", "plan_ready", "claim_verified", "summary_ready",
        ])
        self.assertGreater(events[0][1]["slide_count"], 0)
        self.assertEqual(events[1][1]["item_count"], 1)
        self.assertEqual(events[1][1]["items"][0], {
            "title": STAGE_TITLE, "source_slide": 2, "origin": "materials", "criteria": 2,
        })
        # Один буллит done, второй planned -> (1 + 0) / 2 = 50%.
        self.assertEqual(events[2][1], {
            "title": STAGE_TITLE, "applicable": True, "percent": 50, "criteria": 2,
        })
        self.assertEqual(events[3][1]["decision"], "PIVOT")

        # sanity: колбэк — побочный эффект, сама модель собирается как обычно.
        self.assertEqual(model.readiness, 55)
        self.assertEqual(model.summary.decision, "PIVOT")
        self.assertEqual(model.summary.conclusion, CONCLUSION)
        self.assertEqual(model.summary.risks, RISKS)
        self.assertEqual(model.summary_source, "llm")
        # Шапку дашборда пишет агент — она едет в meta как есть.
        self.assertEqual(model.meta["client_path_name"], CLIENT_PATH_NAME)
        self.assertEqual(model.meta["project_name"], PROJECT_NAME)
        self.assertEqual(model.meta["client"], CLIENT)
        self.assertEqual(model.criterion_counts()["done"], 1)

    def test_without_on_event_behaves_exactly_as_before(self):
        ChatClient._create = scripted_responses(
            *full_session(stage={"statuses": ["planned", "planned"]},
                          summary={"decision": "NO GO", "readiness": 10})
        )
        model = run_progress(self.plan_path, "demo-repo", self.target, SPEC)
        self.assertEqual(model.readiness, 10)
        self.assertEqual(model.summary.decision, "NO GO")
        self.assertEqual(model.verdicts[0].percent(), 0)

    def test_several_plan_files_are_merged_with_continuous_numbering(self):
        # Образ результата из двух файлов: слайды склеиваются в один список со
        # сквозной нумерацией, а имя файла попадает в текст каждого слайда —
        # иначе «слайд 1» из двух документов сделал бы ссылку неоднозначной.
        second = Path(self.tmp.name) / "инициативы.pptx"
        build_sample_deck(second)

        captured: list[str] = []
        original_chat = ChatClient.chat

        def spy(self, messages, **kwargs):
            captured.append(messages[1]["content"])
            return original_chat(self, messages, **kwargs)

        self.addCleanup(setattr, ChatClient, "chat", original_chat)
        ChatClient.chat = spy

        ChatClient._create = scripted_responses(tool_call("call_finish", "finish"))
        with self.assertRaises(Exception):
            # Оценок нет — пайплайн честно падает; нас интересует то, что
            # уехало в промпт, и оно уже собрано к этому моменту.
            run_progress([self.plan_path, second], "demo-repo", self.target, SPEC)

        brief = captured[0]
        self.assertIn("(plan.pptx)", brief)
        self.assertIn("(инициативы.pptx)", brief)
        # Нумерация сквозная и без коллизий: все слайды второго файла идут
        # после слайдов первого. Пропуски допустимы — пустые слайды номер
        # сохраняют, но в промпт не попадают.
        pairs = [(int(n), name) for n, name in re.findall(r"Слайд (\d+) \(([^)]+)\)", brief)]
        numbers = [n for n, _ in pairs]
        self.assertEqual(numbers, sorted(numbers))
        self.assertEqual(len(numbers), len(set(numbers)))
        first = [n for n, name in pairs if name == "plan.pptx"]
        second_nums = [n for n, name in pairs if name == "инициативы.pptx"]
        self.assertTrue(first and second_nums)
        self.assertLess(max(first), min(second_nums))

    def test_single_plan_file_keeps_slide_headers_clean(self):
        # При единственном файле имя не подставляется: оно ничего не различает
        # и только засоряет промпт.
        captured: list[str] = []
        original_chat = ChatClient.chat

        def spy(self, messages, **kwargs):
            captured.append(messages[1]["content"])
            return original_chat(self, messages, **kwargs)

        self.addCleanup(setattr, ChatClient, "chat", original_chat)
        ChatClient.chat = spy

        ChatClient._create = scripted_responses(tool_call("call_finish", "finish"))
        with self.assertRaises(Exception):
            run_progress(self.plan_path, "demo-repo", self.target, SPEC)

        self.assertNotIn("(plan.pptx)", captured[0])
        self.assertIn("Слайд 1", captured[0])


if __name__ == "__main__":
    unittest.main()

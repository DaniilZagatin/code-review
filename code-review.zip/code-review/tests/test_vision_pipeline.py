"""Vision-путь: PDF/изображение → PNG → Markdown → text-агент.

Покрывает:
  * `Slide.raw_text` — распознанный текст делает слайд не-пустым и отдаётся
    `render_slide` как есть (без группировки по координатам);
  * `VisionClient.recognize` — картинка уходит инлайном как `image_url`,
    `enable_thinking=False` в payload, content возвращается;
  * `slide_renderer` — рендер PDF→PNG через pdftoppm (мок subprocess: успех,
    отсутствие бинар, ненулевой код);
  * `pipeline._load_slides` — .png через vision, .pdf без vision-спека →
    понятная ошибка, неподдерживаемый суффикс → ошибка;
  * `cli progress` с PNG-входом — сквозной прогон: vision + matcher подменены,
    отчёт собирается.
"""

import json
import os
import subprocess
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import pko.llm.client as client_module
from fixture_support import ensure_fixture
from pko import cli
from pko.errors import PkoError
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec, get_spec
from pko.llm.vision_client import VisionClient
from pko.progress.pipeline import _load_slides
from pko.progress.pptx_reader import Slide, render_slide
from pko.progress.slide_renderer import render_pdf_first_page

ENV_KEYS = ("PKO_ASSEMBLER_BASE_URL", "PKO_ASSEMBLER_MODEL", "PKO_ASSEMBLER_API_KEY",
            "PKO_VISION_BASE_URL", "PKO_VISION_MODEL", "PKO_VISION_API_KEY")

VISION_SPEC = ModelSpec(role="vision", base_url="https://vision-stub.local/v1",
                        model="qwen-omni", api_key="x")


def _png_bytes() -> bytes:
    """Минимальный валидный PNG (1×1) — без Pillow, чистый хекс."""
    return bytes.fromhex(
        "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
        "0000000a49444154789c63000100000500010137b3318a0000000049454e44ae"
        "426082"
    )


# ── Slide.raw_text ────────────────────────────────────────────────────────────


class SlideRawTextTest(unittest.TestCase):
    def test_raw_text_makes_slide_non_empty(self):
        slide = Slide(number=1, heading=None, shapes=[], raw_text="# План")
        self.assertFalse(slide.is_empty)

    def test_slide_without_text_and_raw_text_is_empty(self):
        self.assertTrue(Slide(number=1, heading=None, shapes=[]).is_empty)

    def test_render_slide_returns_raw_text_verbatim(self):
        markdown = "# Задачи\n\n| A | B |\n|---|---|\n| 1 | 2 |"
        slide = Slide(number=2, heading="Спринт", shapes=[], raw_text=markdown)
        rendered = render_slide(slide)
        self.assertIn("Слайд 2: Спринт", rendered)
        self.assertIn(markdown, rendered)
        # координатной группировки быть не должно — текст уже распознан
        self.assertNotIn("Строка", rendered)


# ── VisionClient.recognize ───────────────────────────────────────────────────


class VisionClientTest(unittest.TestCase):
    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)

    def test_recognize_sends_image_inline_and_returns_content(self):
        captured: list[tuple[dict, dict | None]] = []

        from fixture_support import make_openai_response

        def _create(self, payload, extra_body=None):
            captured.append((payload, extra_body))
            return make_openai_response({"content": "# Распознано"})

        ChatClient._create = _create
        client = VisionClient(spec=VISION_SPEC)
        result = client.recognize(_png_bytes(), mime="image/png")

        self.assertEqual(result, "# Распознано")
        # один запрос, vision-эндпоинт
        self.assertEqual(len(captured), 1)
        payload, extra_body = captured[0]
        self.assertEqual(payload["model"], "qwen-omni")
        # thinking выключен — рассуждение не нужно, content надёжнее
        self.assertEqual(extra_body, {"chat_template_kwargs": {"enable_thinking": False}})
        # картинка ушла инлайном как data-URL
        user_content = payload["messages"][1]["content"]
        self.assertEqual(user_content[0]["type"], "text")
        self.assertEqual(user_content[1]["type"], "image_url")
        self.assertTrue(user_content[1]["image_url"]["url"].startswith("data:image/png;base64,"))
        self.assertEqual(user_content[1]["image_url"]["detail"], "high")

    def test_recognize_raises_on_empty_content(self):
        from fixture_support import make_openai_response

        def _create(self, payload, extra_body=None):
            return make_openai_response({"content": ""})

        ChatClient._create = _create
        with self.assertRaises(PkoError) as ctx:
            VisionClient(spec=VISION_SPEC).recognize(_png_bytes())
        # _text_of поднимает LlmError при пустом content — типичный сигнал,
        # что эндпоинт текстовый, не vision (картинка дошла, но content пуст).
        self.assertIn("пустой ответ", ctx.exception.message)


# ── slide_renderer (pdftoppm) ─────────────────────────────────────────────────


class SlideRendererTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.pdf = Path(self.tmp.name) / "slide.pdf"
        self.pdf.write_bytes(b"%PDF-1.4 fake")

    def _patch_run(self, returncode=0, stderr="", png_bytes=_png_bytes()):
        """Мок subprocess.run: пишет PNG-файл рядом с префиксом, возвращает proc."""
        real_run = subprocess.run

        def fake_run(cmd, *args, **kwargs):
            # pdftoppm prefix — последний аргумент; дописываем .png
            prefix = cmd[-1]
            Path(str(prefix) + ".png").write_bytes(png_bytes)
            return types.SimpleNamespace(returncode=returncode, stderr=stderr, stdout="")

        return patch("pko.progress.slide_renderer.subprocess.run", side_effect=fake_run)

    def test_render_returns_png_bytes_on_success(self):
        with self._patch_run():
            out = render_pdf_first_page(self.pdf)
        self.assertTrue(out.startswith(b"\x89PNG"))

    def test_missing_pdftoppm_raises_pko_error(self):
        with patch("pko.progress.slide_renderer.subprocess.run",
                   side_effect=FileNotFoundError("pdftoppm")):
            with self.assertRaises(PkoError) as ctx:
                render_pdf_first_page(self.pdf)
        self.assertIn("pdftoppm не установлен", ctx.exception.message)

    def test_nonzero_returncode_raises_pko_error_with_stderr(self):
        with self._patch_run(returncode=1, stderr="broken pdf"):
            with self.assertRaises(PkoError) as ctx:
                render_pdf_first_page(self.pdf)
        self.assertIn("Рендер PDF не удался", ctx.exception.message)
        self.assertIn("broken pdf", ctx.exception.hint)

    def test_missing_pdf_file_raises_before_subprocess(self):
        with self.assertRaises(PkoError) as ctx:
            render_pdf_first_page(Path(self.tmp.name) / "nope.pdf")
        self.assertIn("PDF не найден", ctx.exception.message)


# ── pipeline._load_slides ────────────────────────────────────────────────────


class LoadSlidesTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        # PNG-вход — vision-путь без рендера (не требует pdftoppm)
        self.png_path = Path(self.tmp.name) / "slide.png"
        self.png_path.write_bytes(_png_bytes())
        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)

    def test_png_uses_vision_and_produces_raw_text_slide(self):
        from fixture_support import make_openai_response

        def _create(self, payload, extra_body=None):
            return make_openai_response({"content": "# Распознанный слайд"})

        ChatClient._create = _create
        slides = _load_slides(self.png_path, VISION_SPEC, vision_client=None)

        self.assertEqual(len(slides), 1)
        self.assertFalse(slides[0].is_empty)
        self.assertIn("Распознанный слайд", slides[0].raw_text)
        self.assertEqual(slides[0].number, 1)

    def test_pdf_without_vision_spec_raises(self):
        pdf = Path(self.tmp.name) / "plan.pdf"
        pdf.write_bytes(b"%PDF-1.4 fake")
        with self.assertRaises(PkoError) as ctx:
            _load_slides(pdf, vision_spec=None, vision_client=None)
        self.assertIn("vision-модель не настроена", ctx.exception.message)

    def test_unsupported_suffix_raises(self):
        bad = Path(self.tmp.name) / "plan.docx"
        bad.write_bytes(b"x")
        with self.assertRaises(PkoError) as ctx:
            _load_slides(bad, VISION_SPEC, vision_client=None)
        self.assertIn("Неподдерживаемый формат", ctx.exception.message)

    def test_injected_vision_client_is_used(self):
        """vision_client из теста не ходит в сеть — инъекция для детерминизма."""
        calls: list[bytes] = []

        class _StubClient(VisionClient):
            def recognize(self, image_bytes, mime="image/png", **kw):
                calls.append(image_bytes)
                return "# из заглушки"

        stub = _StubClient(spec=VISION_SPEC)
        slides = _load_slides(self.png_path, VISION_SPEC, vision_client=stub)
        self.assertEqual(len(calls), 1)
        self.assertIn("из заглушк", slides[0].raw_text)


# ── cli progress с PNG-входом (сквозной) ──────────────────────────────────────


def _tool_call(call_id: str, name: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": call_id, "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


class CliPngProgressTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        tmp_path = Path(self.tmp.name)

        # PNG-план вместо PPTX — vision-путь
        self.plan_path = tmp_path / "slide.png"
        self.plan_path.write_bytes(_png_bytes())
        self.out_dir = tmp_path / "out"

        self._original_cache_dir = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = tmp_path / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._original_cache_dir)

        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)

        self._original_env = {k: os.environ.get(k) for k in ENV_KEYS}
        os.environ.update({
            "PKO_ASSEMBLER_BASE_URL": "https://stub.local/v1",
            "PKO_ASSEMBLER_MODEL": "stub-model",
            "PKO_ASSEMBLER_API_KEY": "x",
            "PKO_VISION_BASE_URL": "https://vision-stub.local/v1",
            "PKO_VISION_MODEL": "qwen-omni",
            "PKO_VISION_API_KEY": "x",
        })

        def _restore_env():
            for k, v in self._original_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

        self.addCleanup(_restore_env)

    def test_png_plan_produces_report(self):
        # vision: один вызов → Markdown слайда; matcher: submit_plan →
        # submit_stage → submit_summary → finish.
        # Порядок: vision первым (в _load_slides), потом matcher (4 вызова).
        vision_answer = {"content": "# Шаблон\n| Этап | Сделано |\n|---|---|"}
        plan = _tool_call("c0", "submit_plan",
                          project_title="Клиентский путь",
                          client="клиент сервиса",
                          items=[
            {"item_id": "op", "title": "Образ результата", "source_slide": 1},
        ])
        stage = _tool_call("c1", "submit_stage", item_id="op",
                           stage_summary="Клиент получает результат этапа самостоятельно",
                           capabilities=[{
                               "capability": "Клиент получает результат этапа без участия сотрудника",
                               "availability": "AVAILABLE", "who_acts": "AGENT", "limit": "",
                           }],
                           stage_status="DONE",
                           evidence=[{"path": "backend/src/api/v1/router.py", "line": 7,
                                      "basis": "функция start_task"}],
                           execution_mode="AUTO", execution_type="REACTIVE_ACTION",
                           completion_status="ACHIEVED", objects_found=[],
                           technical_notes="")
        summary = _tool_call("c2", "submit_summary",
                             conclusion="Клиент получает результат этапа самостоятельно.")
        finish = _tool_call("c3", "finish")

        answers = [vision_answer, plan, stage, summary, finish]
        queue = list(answers)

        from fixture_support import make_openai_response

        def _create(self, payload, extra_body=None):
            item = queue.pop(0) if queue else {"content": None}
            return make_openai_response(item)

        ChatClient._create = _create

        exit_code = cli.main([
            "progress", str(self.plan_path),
            "--repo-path", str(ensure_fixture()),
            "--out", str(self.out_dir),
        ])

        self.assertEqual(exit_code, 0)
        model = json.loads((self.out_dir / "progress_model.json").read_text("utf-8"))
        self.assertEqual(model["counts"]["DONE"], 1)
        html = (self.out_dir / "progress_report.html").read_text("utf-8")
        self.assertIn("Образ результата", html)


if __name__ == "__main__":
    unittest.main()

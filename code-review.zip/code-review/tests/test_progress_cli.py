"""`pko progress` из командной строки — сквозной прогон с заглушенным LLM.

Транспорт подменяется тем же способом, что и в остальных LLM-тестах. Кеш
дополнительно уводится во временный каталог: `cmd_progress` строит `ChatClient`
внутри `run_agent` без инъекции тестового клиента, поэтому без этого прогон
писал бы в реальный `~/.pko/llm-cache`.
"""

import json
import os
import tempfile
import unittest
from pathlib import Path

import pko.llm.client as client_module
from agent_script import BULLETS, CONCLUSION, STAGE_TITLE, full_session
from fixture_support import ensure_fixture, scripted_responses
from pko import cli
from pko.llm.client import ChatClient
from test_progress_pptx import build_sample_deck

ENV_KEYS = ("PKO_ASSEMBLER_BASE_URL", "PKO_ASSEMBLER_MODEL", "PKO_ASSEMBLER_API_KEY")


class ProgressCliTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        tmp_path = Path(self.tmp.name)

        self.plan_path = tmp_path / "plan.pptx"
        build_sample_deck(self.plan_path)
        self.out_dir = tmp_path / "out"

        # Кеш ChatClient — во временный каталог, а не в реальный ~/.pko/llm-cache.
        self._original_cache_dir = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = tmp_path / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._original_cache_dir)

        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)

        self._original_env = {k: os.environ.get(k) for k in ENV_KEYS}
        os.environ.update({
            "PKO_ASSEMBLER_BASE_URL": "https://stub.local/v1",
            "PKO_ASSEMBLER_MODEL": "stub-model",
            "PKO_ASSEMBLER_API_KEY": "x",
        })

        def _restore_env():
            for k, v in self._original_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

        self.addCleanup(_restore_env)

    def test_full_run_produces_report_and_model(self):
        # Единый агент: submit_plan → submit_stage → submit_summary → finish.
        ChatClient._create = scripted_responses(*full_session())

        exit_code = cli.main([
            "progress", str(self.plan_path),
            "--repo-path", str(ensure_fixture()),
            "--out", str(self.out_dir),
        ])

        self.assertEqual(exit_code, 0)
        report = self.out_dir / "progress_report.html"
        model_json = self.out_dir / "progress_model.json"
        self.assertTrue(report.exists())
        self.assertTrue(model_json.exists())

        model = json.loads(model_json.read_text(encoding="utf-8"))
        self.assertEqual(model["readiness"], 55)
        self.assertEqual(model["summary"]["decision"], "PIVOT")
        self.assertEqual(model["summary"]["conclusion"], CONCLUSION)
        self.assertEqual(model["summary_source"], "llm")
        # Один буллит done, второй planned -> 50% по этапу.
        self.assertEqual(model["verdicts"][0]["percent"], 50)
        self.assertEqual(model["criterion_counts"]["done"], 1)
        # Тексты буллитов хранятся в пути, а не в оценке: переформулировать их
        # модели нечем.
        self.assertEqual(model["items"]["tasks-api"]["criteria"], BULLETS)

        html = report.read_text(encoding="utf-8")
        self.assertIn(STAGE_TITLE, html)
        self.assertIn(BULLETS[0], html)

    def test_missing_plan_file_fails_before_touching_repo(self):
        exit_code = cli.main([
            "progress", str(Path(self.tmp.name) / "does-not-exist.pptx"),
            "--repo-path", str(ensure_fixture()),
            "--out", str(self.out_dir),
        ])
        self.assertEqual(exit_code, 1)
        self.assertFalse(self.out_dir.exists())


if __name__ == "__main__":
    unittest.main()

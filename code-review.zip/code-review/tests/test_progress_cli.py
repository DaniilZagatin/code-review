"""`pko progress` из командной строки — сквозной прогон с заглушенным LLM.

Транспорт подменяется тем же способом, что и в остальных LLM-тестах. Кеш
дополнительно уводится во временный каталог: `cmd_progress` строит `ChatClient`
внутри `run_agent` без инъекции тестового клиента, поэтому без этого прогон
писал бы в реальный `~/.pko/llm-cache`.
"""

import json
import os
import tempfile
import unittest
from pathlib import Path

import pko.llm.client as client_module
from fixture_support import ensure_fixture, scripted_responses
from pko import cli
from pko.llm.client import ChatClient
from test_progress_pptx import build_sample_deck

ENV_KEYS = ("PKO_ASSEMBLER_BASE_URL", "PKO_ASSEMBLER_MODEL", "PKO_ASSEMBLER_API_KEY")


def _tool_call(call_id: str, name: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": call_id, "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


class ProgressCliTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        tmp_path = Path(self.tmp.name)

        self.plan_path = tmp_path / "plan.pptx"
        build_sample_deck(self.plan_path)
        self.out_dir = tmp_path / "out"

        # Кеш ChatClient — во временный каталог, а не в реальный ~/.pko/llm-cache.
        self._original_cache_dir = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = tmp_path / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._original_cache_dir)

        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)

        self._original_env = {k: os.environ.get(k) for k in ENV_KEYS}
        os.environ.update({
            "PKO_ASSEMBLER_BASE_URL": "https://stub.local/v1",
            "PKO_ASSEMBLER_MODEL": "stub-model",
            "PKO_ASSEMBLER_API_KEY": "x",
        })

        def _restore_env():
            for k, v in self._original_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

        self.addCleanup(_restore_env)

    def test_full_run_produces_report_and_model(self):
        # Единый агент: submit_plan → submit_stage → submit_summary → finish.
        plan_answer = _tool_call(
            "call_plan", "submit_plan",
            project_title="Редизайн платёжного сервиса",
            client="клиент платёжного сервиса",
            items=[{"item_id": "tasks-api", "title": "Постановка задач",
                    "source_slide": 2}],
        )
        stage_answer = _tool_call(
            "call_stage", "submit_stage",
            item_id="tasks-api",
            stage_summary="Клиент передаёт задачу в работу самостоятельно",
            capabilities=[{
                "capability": "Клиент ставит задачу в обработку без обращения к сотруднику",
                "availability": "AVAILABLE", "who_acts": "AGENT", "limit": "",
            }],
            stage_status="DONE",
            evidence=[{"path": "backend/src/api/v1/router.py", "line": 7,
                       "basis": "функция start_task ставит задачу в обработку"}],
            execution_mode="AUTO", execution_type="REACTIVE_ACTION",
            completion_status="ACHIEVED", objects_found=[], technical_notes="",
        )
        summary_answer = _tool_call(
            "call_summary", "submit_summary",
            conclusion="Клиент ставит задачи в работу самостоятельно.",
        )
        finish_answer = _tool_call("call_finish", "finish")
        ChatClient._create = scripted_responses(
            plan_answer, stage_answer, summary_answer, finish_answer,
        )

        exit_code = cli.main([
            "progress", str(self.plan_path),
            "--repo-path", str(ensure_fixture()),
            "--out", str(self.out_dir),
        ])

        self.assertEqual(exit_code, 0)
        report = self.out_dir / "progress_report.html"
        model_json = self.out_dir / "progress_model.json"
        self.assertTrue(report.exists())
        self.assertTrue(model_json.exists())

        model = json.loads(model_json.read_text(encoding="utf-8"))
        self.assertEqual(model["counts"]["DONE"], 1)
        self.assertEqual(model["progress_ratio"], 1.0)
        self.assertEqual(model["summary_source"], "llm")
        self.assertEqual(model["summary"]["conclusion"],
                         "Клиент ставит задачи в работу самостоятельно.")
        # Готовность считает код по режиму исполнения: AUTO + ACHIEVED = 100.
        self.assertEqual(model["verdicts"][0]["progress"], 100)
        self.assertEqual(
            model["verdicts"][0]["capabilities"][0]["capability"],
            "Клиент ставит задачу в обработку без обращения к сотруднику",
        )

        # Раздел с постатусными карточками (и путём/строкой evidence в HTML)
        # убран из отчёта — эти данные по-прежнему в JSON-модели (проверено
        # выше), в HTML теперь только то, что уходит в дашборд «Путь».
        html = report.read_text(encoding="utf-8")
        self.assertIn("Постановка задач", html)
        self.assertIn("Клиент ставит задачу в обработку", html)

    def test_missing_plan_file_fails_before_touching_repo(self):
        exit_code = cli.main([
            "progress", str(Path(self.tmp.name) / "does-not-exist.pptx"),
            "--repo-path", str(ensure_fixture()),
            "--out", str(self.out_dir),
        ])
        self.assertEqual(exit_code, 1)
        self.assertFalse(self.out_dir.exists())


if __name__ == "__main__":
    unittest.main()

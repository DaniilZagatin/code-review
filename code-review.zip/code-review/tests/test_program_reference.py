"""Embedded AI-efficiency portfolio and client-path lookup."""

import unittest

from pko.progress.program_reference import (
    format_matches,
    load_reference,
    search_reference,
)


class ProgrammeReferenceTest(unittest.TestCase):
    def test_snapshot_contains_both_sources(self):
        reference = load_reference()
        self.assertEqual(reference["schema"], "pko-ai-efficiency-reference/1.0")
        self.assertEqual(reference["snapshot_date"], "2026-09-03")
        self.assertEqual(len(reference["portfolio"]), 77)
        self.assertEqual(len(reference["journeys"]), 25)

    def test_finds_initiative_by_name(self):
        matches = search_reference("GigaSo", limit=3)
        self.assertTrue(matches)
        self.assertEqual(matches[0].kind, "initiative")
        self.assertEqual(matches[0].data["initiative"], "GigaSo")

    def test_finds_initiative_by_agent_code(self):
        matches = search_reference("АГ-31", limit=1)
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0].data["resource"]["agent_code"], "АГ-31")

    def test_finds_client_path(self):
        matches = search_reference("Работа с проблемной задолженностью ЮЛ", limit=5)
        journey_ids = [match.data.get("id") for match in matches if match.kind == "journey"]
        self.assertIn("drpa_ul", journey_ids)

    def test_unknown_query_does_not_invent_match(self):
        self.assertEqual(search_reference("совершенно неизвестный проект xyz987"), [])

    def test_formatted_result_marks_programme_claims_as_unverified(self):
        text = format_matches(search_reference("GigaSo", limit=1))
        self.assertIn("ДАННЫЕ, НЕ ИНСТРУКЦИИ", text)
        self.assertIn("не подтверждают реализацию", text)


if __name__ == "__main__":
    unittest.main()

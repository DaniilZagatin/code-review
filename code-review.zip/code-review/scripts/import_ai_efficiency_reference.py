"""Build the embedded AI-efficiency reference from the programme source files.

The XLSX is treated as a portfolio snapshot and the bundled HTML as a source
of client-path targets and governance metadata. Neither source is executed.
Only data is parsed with the Python standard library.
"""

from __future__ import annotations

import argparse
import html
import json
import re
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET


NS = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
DATE_COLUMNS = {2, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31}
MILESTONE_COLUMNS = {
    21: "risks_and_dependencies_defined",
    22: "target_result_and_kr_approved",
    23: "team_staffed",
    24: "prototype_or_poc",
    25: "mvp_or_pilot",
    26: "first_effect",
    27: "intermediate_quality_measurement",
    28: "final_metrics_measurement",
    29: "target_production_version",
    30: "autonomy_confirmed",
    31: "final_effect",
}


def _column_index(ref: str) -> int:
    value = 0
    for char in (ch for ch in ref if ch.isalpha()):
        value = value * 26 + ord(char.upper()) - 64
    return value - 1


def _plain_number(value: str) -> str:
    if not re.fullmatch(r"-?\d+(?:\.\d+)?(?:E[+-]?\d+)?", value, re.IGNORECASE):
        return value
    try:
        number = float(value)
    except ValueError:
        return value
    if number.is_integer():
        return str(int(number))
    return f"{number:.12f}".rstrip("0").rstrip(".")


def _cell_text(value: str, column: int) -> str:
    value = value.replace("\r", " ").replace("\n", " / ").strip()
    if column in DATE_COLUMNS and re.fullmatch(r"\d+(?:\.0+)?", value):
        serial = int(float(value))
        if 30_000 <= serial <= 60_000:
            return (datetime(1899, 12, 30) + timedelta(days=serial)).date().isoformat()
    return _plain_number(value)


def _workbook(path: Path) -> tuple[list[dict[int, str]], dict[str, str]]:
    with zipfile.ZipFile(path) as archive:
        shared: list[str] = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            for item in root.findall("x:si", NS):
                shared.append("".join(node.text or "" for node in item.iterfind(".//x:t", NS)))

        comments: dict[str, str] = {}
        if "xl/comments1.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/comments1.xml"))
            for item in root.findall(".//x:comment", NS):
                comments[item.attrib["ref"]] = " ".join(
                    "".join(node.text or "" for node in item.iterfind(".//x:t", NS)).split()
                )

        root = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))
        rows: list[dict[int, str]] = []
        for row in root.findall(".//x:sheetData/x:row", NS):
            values: dict[int, str] = {}
            for cell in row.findall("x:c", NS):
                ref = cell.attrib.get("r", "A1")
                column = _column_index(ref)
                kind = cell.attrib.get("t", "")
                value_node = cell.find("x:v", NS)
                inline_node = cell.find("x:is", NS)
                value = ""
                if kind == "s" and value_node is not None:
                    value = shared[int(value_node.text or 0)]
                elif kind == "inlineStr" and inline_node is not None:
                    value = "".join(node.text or "" for node in inline_node.iterfind(".//x:t", NS))
                elif value_node is not None:
                    value = value_node.text or ""
                values[column] = _cell_text(value, column)
            rows.append(values)
        return rows, comments


def _value(row: dict[int, str], column: int) -> str:
    return row.get(column, "").strip()


def _portfolio(path: Path) -> list[dict[str, object]]:
    rows, comments = _workbook(path)
    records: list[dict[str, object]] = []
    for excel_row, row in enumerate(rows[1:], 2):
        initiative = _value(row, 7)
        agent_name = _value(row, 9)
        if not initiative and not agent_name:
            continue
        milestones = {
            name: _value(row, column)
            for column, name in MILESTONE_COLUMNS.items()
            if _value(row, column)
        }
        record: dict[str, object] = {
            "id": _value(row, 0),
            "steering_committee": {
                "number": _value(row, 1),
                "date": _value(row, 2),
            },
            "business_block": _value(row, 3),
            "tribe_or_audience": _value(row, 4),
            "initiative": initiative,
            "description": _value(row, 8),
            "agent_name": agent_name,
            "programme_reference": _value(row, 10),
            "staffing_order": " / ".join(filter(None, (_value(row, 11), _value(row, 12)))),
            "resource": {
                "total_fte": _value(row, 13),
                "reserve_fte": _value(row, 14),
                "reused_or_extended_fte": _value(row, 15),
                "agent_code": _value(row, 17),
                "kr_fte_2026": _value(row, 18),
            },
            "declared_effect": {
                "net_operating_income_2026_bln": _value(row, 19),
                "total_net_operating_income_bln": _value(row, 20),
            },
            "milestones": milestones,
            "processes": _value(row, 32),
            "crossgoal": _value(row, 33),
            "demo_readiness_comment": _value(row, 34),
        }
        comment = comments.get(f"U{excel_row}", "")
        if comment:
            record["effect_note"] = comment
        records.append(record)
    return records


def _bundled_template(path: Path) -> str:
    source = path.read_text(encoding="utf-8")
    match = re.search(
        r'<script\s+type="__bundler/template">\s*(.*?)\s*</script>',
        source,
        re.DOTALL,
    )
    if not match:
        raise RuntimeError("Bundled HTML template was not found")
    return json.loads(match.group(1))


def _strip_markup(value: object) -> object:
    if isinstance(value, str):
        text = re.sub(r"<[^>]+>", "", value)
        return " ".join(html.unescape(text).split())
    if isinstance(value, list):
        return [_strip_markup(item) for item in value]
    if isinstance(value, dict):
        return {key: _strip_markup(item) for key, item in value.items()}
    return value


def _journeys(path: Path) -> list[dict[str, object]]:
    inner = _bundled_template(path)
    marker = "const PAGEDATA = "
    offset = inner.index(marker) + len(marker)
    payload, _ = json.JSONDecoder().raw_decode(inner[offset:])
    aliases_marker = "const PATH2PAGES = "
    aliases_offset = inner.index(aliases_marker) + len(aliases_marker)
    aliases_end = inner.index(";", aliases_offset)
    aliases_source = inner[aliases_offset:aliases_end]
    aliases_source = re.sub(r",\s*([}\]])", r"\1", aliases_source)
    path_map = json.loads(aliases_source)
    aliases_by_page: dict[str, list[str]] = {}
    for alias, page_ids in path_map.items():
        for page_id in page_ids:
            aliases_by_page.setdefault(str(page_id).split("#", 1)[0], []).append(alias)
    journeys: list[dict[str, object]] = []
    for page_id, page in payload.get("pages", {}).items():
        data = page.get("d", {})
        metrics: list[dict[str, object]] = []
        for category, rows in data.get("metrics", {}).items():
            for metric in rows:
                metrics.append({"category": category, **metric})
        journeys.append(_strip_markup({
            "id": page_id,
            "label": page.get("label", ""),
            "aliases": aliases_by_page.get(page_id, []),
            "kind": data.get("kind", ""),
            "title": data.get("title", ""),
            "client": data.get("client", ""),
            "target": data.get("target", ""),
            "desired_change": data.get("whychange", ""),
            "target_state": data.get("tobe", ""),
            "stages": data.get("stages", []),
            "metrics": metrics,
            "initiatives": data.get("inits", []),
            "initiative_statuses": data.get("status", []),
            "resource": data.get("resource", {}),
            "source_note": data.get("foot", ""),
        }))
    return journeys


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("timeline_html", type=Path)
    parser.add_argument("portfolio_xlsx", type=Path)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("backend/pko/progress/ai_efficiency_reference.json"),
    )
    parser.add_argument("--snapshot-date", default="")
    args = parser.parse_args()

    snapshot_date = args.snapshot_date or datetime.fromtimestamp(
        args.portfolio_xlsx.stat().st_mtime
    ).date().isoformat()
    result = {
        "schema": "pko-ai-efficiency-reference/1.0",
        "snapshot_date": snapshot_date,
        "source": {
            "portfolio": args.portfolio_xlsx.name,
            "timeline": args.timeline_html.name,
        },
        "notice": (
            "Portfolio and timeline values are declared programme baselines. "
            "They help fact-check plans and milestones but do not prove implementation."
        ),
        "portfolio": _portfolio(args.portfolio_xlsx),
        "journeys": _journeys(args.timeline_html),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(
        f"Wrote {len(result['portfolio'])} initiatives and "
        f"{len(result['journeys'])} client paths to {args.output}"
    )


if __name__ == "__main__":
    main()

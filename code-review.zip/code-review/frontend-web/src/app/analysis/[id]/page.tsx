import { AnalysisView } from "@/components/analysis/AnalysisView";
import { FloatingBackButton } from "@/components/analysis/FloatingBackButton";

export default async function AnalysisPage(props: PageProps<"/analysis/[id]">) {
  const { id } = await props.params;
  return (
    <div className="flex-1 px-6 py-10">
      <FloatingBackButton />
      <div className="mx-auto w-full max-w-[1600px]">
        <AnalysisView key={id} analysisId={id} />
      </div>
    </div>
  );
}

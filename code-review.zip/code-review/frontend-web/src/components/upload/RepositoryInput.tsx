"use client";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export interface RepositoryInputProps {
  repository: string;
  onRepositoryChange: (value: string) => void;
  branch: string;
  onBranchChange: (value: string) => void;
}

// SSH-ключ здесь сознательно не запрашивается: доступ к репозиторию идёт
// через SSH-agent, уже настроенный на машине с `pko serve`
// (backend/pko/web/app.py), а не через ключ, переданный с этой формы.
export function RepositoryInput({
  repository,
  onRepositoryChange,
  branch,
  onBranchChange,
}: RepositoryInputProps) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-start">
      <div className="flex-1">
        <Label htmlFor="repository" className="sr-only">Репозиторий</Label>
        <Input
          id="repository"
          placeholder="git@host:project/repo.git или локальный путь"
          value={repository}
          onChange={(e) => onRepositoryChange(e.target.value)}
          className="h-10 text-sm"
        />
      </div>
      <div className="sm:w-44">
        <Label htmlFor="branch" className="sr-only">Ветка</Label>
        <Input
          id="branch"
          placeholder="ветка"
          value={branch}
          onChange={(e) => onBranchChange(e.target.value)}
          className="h-10 text-sm"
        />
      </div>
    </div>
  );
}

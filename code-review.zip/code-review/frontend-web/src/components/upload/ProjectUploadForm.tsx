"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { createAnalysis, ApiError } from "@/lib/api";
import { FileDropzone } from "./FileDropzone";
import { RepositoryInput } from "./RepositoryInput";
import { StagesInput, parseStages, MAX_STAGES, MAX_STAGE_CHARS } from "./StagesInput";

// Репозиторий и файлы проекта — два независимых необязательных источника
// evidence, не выбор одного из вариантов: можно указать репозиторий, можно
// загрузить файлы (в том числе ZIP — распаковывается на бэкенде), можно и
// то, и другое сразу — тогда файлы дополняют репозиторий, а не подменяют его
// (backend/pko/web/analyses.py::create_analysis). Оба можно оставить
// пустыми — это не ошибка: агент получает пустой снимок материалов и сам
// решает по каждому пункту плана, что писать в вердикт.
export function ProjectUploadForm() {
  const router = useRouter();
  const [presentation, setPresentation] = useState<File[]>([]);
  const [repository, setRepository] = useState("");
  const [branch, setBranch] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [stages, setStages] = useState("");
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState<{ message: string; hint: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const stageTitles = parseStages(stages);
  const stagesValid =
    stageTitles.length <= MAX_STAGES &&
    stageTitles.every((t) => t.length <= MAX_STAGE_CHARS);
  const canSubmit = presentation.length > 0 && stagesValid && !submitting;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit) return;
    setSubmitting(true);
    setError(null);
    try {
      const { analysis_id } = await createAnalysis(
        presentation[0], repository, branch, files, thinking, stages,
      );
      router.push(`/analysis/${analysis_id}`);
    } catch (err) {
      setError(err instanceof ApiError ? { message: err.message, hint: err.hint } : {
        message: "Не удалось отправить запрос.", hint: String(err),
      });
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6 rounded-2xl border border-border bg-card p-7">
      <div>
        <h2 className="text-base font-semibold mb-2.5">Образ результата</h2>
        <FileDropzone
          files={presentation}
          onChange={setPresentation}
          accept=".pptx,.pdf,.bmp,.jpeg,.jpg,.png,.tif,.tiff"
          label="Прикрепите образ результата в форматах .pptx, .pdf или изображение"
          hint=".pptx, .pdf или изображение"
        />
      </div>
      <div>
        <h2 className="text-base font-semibold mb-1">Этапы клиентского пути</h2>
        <p className="text-muted-foreground text-xs mb-2.5">
          Необязательно. Заполните, если этапов нет в презентации или вы хотите задать их сами —
          агент возьмёт ровно эти названия и не станет придумывать свои.
        </p>
        <StagesInput value={stages} onChange={setStages} />
      </div>
      <div>
        <h2 className="text-base font-semibold mb-2.5">Репозиторий</h2>
        <RepositoryInput
          repository={repository}
          onRepositoryChange={setRepository}
          branch={branch}
          onBranchChange={setBranch}
        />
      </div>
      <div>
        <h2 className="text-base font-semibold mb-2.5">Файлы проекта</h2>
        <FileDropzone
          files={files}
          onChange={setFiles}
          multiple
          label="Перетащите файлы сюда"
          hint="код, ZIP-архив, метрики, отчёты — что угодно, чем можно подтвердить готовность"
        />
      </div>
      <div className="flex items-center justify-between gap-3.5">
        <div className="min-w-0">
          <h2 className="text-base font-semibold">Режим рассуждения (thinking)</h2>
          <p className="text-muted-foreground text-xs mt-1">
            Цепочка рассуждений модели: медленнее, но детальнее. По умолчанию выключен.
          </p>
        </div>
        <Button
          type="button"
          variant={thinking ? "default" : "outline"}
          aria-pressed={thinking}
          onClick={() => setThinking((v) => !v)}
          className="h-10 shrink-0 px-4 text-sm"
        >
          {thinking ? "Включён" : "Выключен"}
        </Button>
      </div>
      {error && (
        <div className="rounded-lg bg-destructive/10 text-destructive text-sm p-3.5 whitespace-pre-wrap">
          {error.message}
          {error.hint ? `\n${error.hint}` : ""}
        </div>
      )}
      <Button type="submit" disabled={!canSubmit} className="self-start h-11 px-5 text-sm">
        {submitting ? "Отправляем…" : "Начать анализ"}
      </Button>
    </form>
  );
}

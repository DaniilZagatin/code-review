"use client";

import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

// Зеркало лимитов бэкенда (backend/pko/progress/matcher.py::parse_stage_titles).
// Проверка здесь — не замена серверной, а способ не гонять человека на
// круг: тот же отказ он получил бы после отправки формы, но на секунду позже
// и без подсветки поля.
export const MAX_STAGES = 12;
export const MAX_STAGE_CHARS = 60;

export function parseStages(value: string): string[] {
  return value
    .split("\n")
    .map((line) => line.trim().replace(/\s+/g, " "))
    .filter(Boolean);
}

export interface StagesInputProps {
  value: string;
  onChange: (value: string) => void;
}

// Третий источник этапов клиентского пути рядом с двумя прежними: этапы
// названы в презентации, агент собирает их сам по опорной карте — или их
// задаёт здесь человек. Заданные тут этапы для агента обязательны: он не
// переименовывает, не переставляет и не дополняет их
// (backend/pko/progress/matcher.py::_accept_plan), и в отчёт они идут в
// авторской редакции, а не в пересказе модели.
export function StagesInput({ value, onChange }: StagesInputProps) {
  const titles = parseStages(value);
  const tooMany = titles.length > MAX_STAGES;
  const tooLong = titles.find((t) => t.length > MAX_STAGE_CHARS);
  const invalid = tooMany || Boolean(tooLong);

  return (
    <div>
      <Label htmlFor="stages" className="sr-only">Этапы клиентского пути</Label>
      <textarea
        id="stages"
        rows={5}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        aria-invalid={invalid || undefined}
        placeholder={"Первичный контакт\nСборка предложения\nОформление\nВыдача"}
        className={cn(
          "w-full min-w-0 resize-y rounded-lg border border-input bg-transparent px-3 py-2.5",
          "text-sm leading-6 transition-colors outline-none placeholder:text-muted-foreground",
          "focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50",
          "aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20",
          "dark:bg-input/30",
        )}
      />
      <p className={cn("text-xs mt-1.5", invalid ? "text-destructive" : "text-muted-foreground")}>
        {tooMany
          ? `Этапов ${titles.length} — больше ${MAX_STAGES} ряд на дашборде не читается.`
          : tooLong
            ? `Название «${tooLong}» длиннее ${MAX_STAGE_CHARS} символов — нужно 2–4 слова.`
            : titles.length > 0
              ? `Этапов: ${titles.length}. Агент возьмёт ровно их, в этом порядке.`
              : "По одному этапу в строке. Пусто — этапы возьмутся из презентации."}
      </p>
    </div>
  );
}

"use client";

import { useRouter } from "next/navigation";

// Плавающая круглая кнопка «назад» — фиксирована справа вверху, вне потока
// контента. остаётся видимой при прокрутке страницы.
export function FloatingBackButton() {
  const router = useRouter();
  return (
    <button
      type="button"
      onClick={() => router.push("/")}
      aria-label="Новый анализ"
      title="Новый анализ"
      className="fixed top-4 right-4 z-50 size-11 rounded-full border border-border bg-card text-foreground shadow-md hover:bg-muted hover:text-primary flex items-center justify-center transition-colors cursor-pointer"
    >
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" />
        <path d="M12 8l-4 4 4 4M8 12h8" />
      </svg>
    </button>
  );
}

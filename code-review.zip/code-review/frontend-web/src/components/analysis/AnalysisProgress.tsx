"use client";

import { useEffect, useMemo, useState } from "react";
import type { AnalysisEvent } from "@/lib/types";

// Сменяющиеся сообщения для фазы обхода пунктов (под текущим пунктом).
// Бэкенд не шлёт поинструментных событий — это контекстные подсказки, которые
// циклически сменяют друг друга, давая живую обратную связь, пока агент
// работает над пунктом молча (между claim_verified событиями).
const ITEM_MESSAGES = [
  "Ищем реализацию в материалах проекта…",
  "Читаем найденные файлы…",
  "Сверяемся с описанием этапа…",
  "Оцениваем готовность…",
];

// Порядок этапов для пошагового режима: если события прилетают пачкой и
// «сырой» stage перепрыгивает через несколько ступеней, UI проходит их по
// одной с минимальной задержкой — иначе переход выглядит мгновенным и
// анимация не успевает проиграться.
const STAGE_ORDER: (StageKey | "done")[] = [
  "materials", "parse", "agent_wait", "plan", "agent", "summary", "done",
];
const MIN_STAGE_DWELL_MS = 650;

// Этапы пайплайна с весами для полосы прогресса. Веса фиксированы — число
// пунктов плана заранее неизвестно, поэтому агентная фаза получает один блок,
// а внутри него показываем счётчик проверенных пунктов (без точного %).
// Сумма весов = 100.
const STAGES = [
  { key: "materials", weight: 10 },
  { key: "parse", weight: 10 },
  { key: "agent_wait", weight: 10 },
  { key: "plan", weight: 15 },
  { key: "agent", weight: 35 },
  { key: "summary", weight: 20 },
] as const;

type StageKey = (typeof STAGES)[number]["key"];

function currentStage(events: AnalysisEvent[]): StageKey | "done" {
  if (events.some((e) => e.type === "analysis_ready")) return "done";
  if (events.some((e) => e.type === "summary_ready")) return "summary";
  if (events.some((e) => e.type === "claim_verified")) return "agent";
  if (events.some((e) => e.type === "plan_ready")) return "plan";
  if (events.some((e) => e.type === "presentation_parsed")) return "agent_wait";
  if (events.some((e) => e.type === "phase" && e.phase === "materials_ready")) return "parse";
  return "materials";
}

export function AnalysisProgress({
  events,
  onComplete,
}: {
  events: AnalysisEvent[];
  onComplete?: () => void;
}) {
  const rawStage = currentStage(events);

  const STAGE_LABELS: Record<StageKey | "done", string> = {
    materials: "Чтение материалов проекта",
    parse: "Чтение образа результата",
    agent_wait: "Ожидание агента",
    plan: "Составление плана",
    agent: "Сопоставление с материалами проекта",
    summary: "Формирование выводов",
    done: "Готово",
  };

  function stageLabel(key: StageKey | "done"): string {
    return STAGE_LABELS[key] ?? "Анализируем";
  }

  // Пошаговый режим: показываем этапы по одному с минимальной задержкой, чтобы
  // переход был плавным, даже если бэкенд прислал несколько событий разом.
  // Идём только вперёд по STAGE_ORDER — шагаем к сырой stage по одной ступени
  // каждые MIN_STAGE_DWELL_MS. Назад (ошибка/сброс) — без задержки (delay 0).
  // setState — только внутри setTimeout (async), не синхронно в effect.
  const [stage, setStage] = useState<StageKey | "done">(rawStage);
  useEffect(() => {
    if (rawStage === stage) return;
    const fromIdx = STAGE_ORDER.indexOf(stage);
    const toIdx = STAGE_ORDER.indexOf(rawStage);
    const goingForward = toIdx > fromIdx;
    const delay = goingForward ? MIN_STAGE_DWELL_MS : 0;
    const nextStage = goingForward ? STAGE_ORDER[fromIdx + 1] : rawStage;
    const t = setTimeout(() => {
      setStage(nextStage);
    }, delay);
    return () => clearTimeout(t);
  }, [rawStage, stage]);

  // Когда пошаговая анимация досчитала до «Готово» — задерживаем переключение
  // на дашборд ещё на короткую паузу, чтобы финальный кадр прогресса был виден
  // (иначе при быстром ответе бэкенда экран 3 появлялся мгновенно). Ошибки
  // переключаются сразу — там анимация прогресса не доходит до done.
  useEffect(() => {
    if (stage !== "done" || !onComplete) return;
    const t = setTimeout(onComplete, 900);
    return () => clearTimeout(t);
  }, [stage, onComplete]);

  // Прогресс: сумма весов завершённых этапов + половина текущего (индикация
  // «в работе»). Готово = 100.
  const completedWeight = STAGES
    .filter((s) => STAGES.indexOf(s) < STAGES.findIndex((s2) => s2.key === stage))
    .reduce((sum, s) => sum + s.weight, 0);
  const currentWeight = stage === "done" ? 0 : (STAGES.find((s) => s.key === stage)?.weight ?? 0);
  const pct = stage === "done" ? 100 : completedWeight + Math.round(currentWeight / 2);

  const stageIndex = stage === "done" ? STAGES.length : STAGES.findIndex((s) => s.key === stage);

  // Сменяющиеся сообщения зависят от этапа. useMemo — стабильная ссылка, чтобы
  // interval-effect не перезапускался каждый рендер. Когда stage меняется,
  // массив пересоздаётся → effect перезапускается с новыми сообщениями.
  const messages = useMemo<string[]>(() => {
    if (stage === "materials") return ["Подключаем материалы проекта…", "Обрабатываем файлы…"];
    if (stage === "parse") return ["Разбираем образ результата…", "Извлекаем этапы пути…"];
    if (stage === "agent_wait") return ["Подключаемся к модели…", "Агент начинает работу…"];
    if (stage === "plan") return ["Анализируем слайды…", "Выделяем этапы пути…"];
    if (stage === "agent") return ITEM_MESSAGES;
    if (stage === "summary") return ["Обобщаем результаты по всем этапам…", "Формируем общий вывод…"];
    if (stage === "done") return ["Анализ завершён"];
    return [];
  }, [stage]);

  // Циклически меняем сообщение каждые 2.5с. index ограничен длиной массива.
  const [msgIndex, setMsgIndex] = useState(0);
  useEffect(() => {
    if (messages.length <= 1) return;
    const t = setInterval(() => {
      setMsgIndex((prev) => (prev + 1) % messages.length);
    }, 2500);
    return () => clearInterval(t);
  }, [messages]);
  const currentMsg = messages[Math.min(msgIndex, messages.length - 1)] ?? "";

  return (
    <div className="rounded-xl border border-border bg-card p-8 flex flex-col gap-6">
      {/* Заголовок + сменяющаяся строка текущей активности в один ряд:
          слева «Анализируем проект»/этап, справа — живое сообщение. */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          {stage !== "done" && (
            <span
              className="size-5 rounded-full border-2 border-primary border-t-transparent animate-spin shrink-0"
              aria-hidden
            />
          )}
          <div>
            <h1 className="text-lg font-semibold">
              {stage === "done" ? "Анализ завершён" : "Анализируем проект"}
            </h1>
            {/* Плавный переход названия этапа: opacity+translate, чтобы при смене
                не было резкого скачка, даже если события прилетают мгновенно. */}
            <p
              key={stage}
              className="text-muted-foreground text-sm mt-0.5 transition-stage-label"
            >
              {stageLabel(stage)}
            </p>
          </div>
        </div>
        {currentMsg && (
          <p
            key={currentMsg}
            className="text-muted-foreground text-sm text-right transition-stage-label shrink-0 max-w-[45%]"
          >
            {currentMsg}
          </p>
        )}
      </div>

      {/* Полоса прогресса */}
      <div>
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-1.5">
          <span>Прогресс</span>
          <span className="tabular-nums">{pct}%</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full rounded-full bg-primary transition-all duration-500"
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>

      {/* Ступени этапов — цвет и маркер переходят плавно, не скачком. */}
      <ol className="flex flex-col gap-2 text-sm">
        {STAGES.map((s, i) => {
          const isDone = i < stageIndex || stage === "done";
          const isCurrent = i === stageIndex && stage !== "done";
          return (
            <li
              key={s.key}
              className={
                "transition-colors duration-500 " +
                (isDone ? "text-foreground" :
                 isCurrent ? "text-primary font-medium" :
                 "text-muted-foreground")
              }
            >
              <span
                key={isDone ? "done" : isCurrent ? "current" : "pending"}
                className="transition-stage-marker"
              >
                {isDone ? "✓" : isCurrent ? "●" : "○"}
              </span>{" "}
              {stageLabel(s.key)}
            </li>
          );
        })}
      </ol>
    </div>
  );
}

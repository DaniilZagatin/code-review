"use client";

import { useCallback, useState } from "react";
import { useAnalysisEvents } from "@/hooks/useAnalysisEvents";
import { useAnalysis } from "@/hooks/useAnalysis";
import { AnalysisProgress } from "./AnalysisProgress";
import { Dashboard } from "@/components/dashboard/Dashboard";

function ErrorBox({ message, hint }: { message: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <p className="text-destructive font-medium">{message}</p>
      {hint && <p className="text-muted-foreground text-sm mt-1">{hint}</p>}
    </div>
  );
}

// Экран прогресса и dashboard — один роут (app/analysis/[id]/page.tsx), не
// отдельный переход страницы: SSE (`useAnalysisEvents`) переключает состояние
// на READY/ERROR, после чего подтягивается сам результат (`useAnalysis`).
// Переключение на дашборд задерживается, пока пошаговая анимация прогресса не
// досчитает до «Готово» (см. AnalysisProgress::onComplete) — иначе при быстром
// ответе бэкенда результаты появлялись мгновенно, перечёркивая прогресс.
// Ошибки переключаются сразу, без ожидания анимации.
export function AnalysisView({ analysisId }: { analysisId: string }) {
  const { events, done } = useAnalysisEvents(analysisId);
  const { data, error } = useAnalysis(analysisId, done);
  const [progressDone, setProgressDone] = useState(false);
  const handleProgressComplete = useCallback(() => setProgressDone(true), []);

  // Ошибка пришла по SSE или в ответе GET — показываем сразу, не ждём анимации.
  const isErrored = !!(error || (data && data.status === "ERROR"));
  const showResults = !!(done && data && (progressDone || isErrored));

  if (!showResults) {
    return <AnalysisProgress events={events} onComplete={handleProgressComplete} />;
  }
  if (error) {
    return <ErrorBox message="Не удалось получить результат анализа." hint={String(error)} />;
  }
  if (data.status === "ERROR") {
    return <ErrorBox message={data.message} hint={data.hint} />;
  }
  if (data.status !== "READY") {
    // PROCESSING при showResults не ожидается, но TS-безопасно показать прогресс.
    return <AnalysisProgress events={events} onComplete={handleProgressComplete} />;
  }
  return <Dashboard analysis={data} analysisId={analysisId} />;
}

"use client";

import { useEffect, useState } from "react";
import type { AnalysisResult, StageItem } from "@/lib/types";
import { Spotlight } from "./Spotlight";
import { cn } from "@/lib/utils";
import { Download } from "lucide-react";
import "./dashboard.css";

const STATUS_MAP: Record<string, { color: string; fallback: string }> = {
  green: { color: "var(--green)", fallback: "Сделано" },
  amber: { color: "var(--amber)", fallback: "Частично" },
  red: { color: "var(--red)", fallback: "Не начато" },
  purple: { color: "var(--purple)", fallback: "Неясно" },
};

function safeColor(item: StageItem): string {
  if (STATUS_MAP[item.color] && item.color !== "purple") return item.color;
  return item.pct >= 80 ? "green" : item.pct >= 40 ? "amber" : "red";
}

function downloadName(meta: AnalysisResult["meta"]): string {
  const base = (meta.title || meta.repo || "project")
    .replace(/[^A-Za-z0-9А-Яа-я]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "project";
  return `pko-dashboard-${base}.html`;
}

function Gauge({ readiness }: { readiness: number }) {
  const pct = Math.round(readiness * 100);
  const r = 88;
  const c = 2 * Math.PI * r;
  const [offset, setOffset] = useState(c);
  useEffect(() => {
    requestAnimationFrame(() => setOffset(c * (1 - readiness)));
  }, [readiness, c]);

  return (
    <div className="gauge-wrap">
      <div className="gauge-halo" />
      <svg className="gauge-svg" viewBox="0 0 220 220">
        <defs>
          <linearGradient id="gaugeGradient" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--primary)" />
            <stop offset="62%" stopColor="var(--primary-2)" />
            <stop offset="100%" stopColor="var(--green)" />
          </linearGradient>
        </defs>
        <circle className="gauge-track" cx="110" cy="110" r={r} />
        <circle
          className="gauge-progress"
          cx="110" cy="110" r={r}
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="gauge-center">
        <div className="gauge-value">{pct}%</div>
        <div className="gauge-caption">готовность</div>
      </div>
    </div>
  );
}

// Счётчики статусов, а не фильтр. Фильтрация — инструмент аналитика: она
// прячет часть пути, а первому лицу нужен путь целиком, и в статике
// (скриншот, PDF) интерактив всё равно теряется. Разбивка по статусам при
// этом остаётся — она и была тем, ради чего на панель смотрят.
function StatusCounters({ items }: { items: StageItem[] }) {
  const countColor = (c: string) => items.filter((x) => safeColor(x) === c).length;
  const defs: [string, string, number, string][] = [
    ["all", "Всего", items.length, "var(--primary)"],
    ["green", "Сделано", countColor("green"), "var(--green)"],
    ["amber", "Частично", countColor("amber"), "var(--amber)"],
    ["red", "Не начато", countColor("red"), "var(--red)"],
  ];
  return (
    <div className="filterbar">
      {defs.map(([key, label, count, color]) => (
        <span key={key} className="filter-btn">
          <i className="filter-dot" style={{ ["--dot" as string]: color }} />
          <span>{label} · {count}</span>
        </span>
      ))}
    </div>
  );
}

function StagePuzzle({
  item, index, total, selected, onClick,
}: {
  item: StageItem;
  index: number;
  total: number;
  selected: boolean;
  onClick: () => void;
}) {
  const color = safeColor(item);
  const pct = Math.max(0, Math.min(100, item.pct));

  return (
    <button
      type="button"
      className={cn(
        "stage-card",
        index === 0 && "first-child",
        index === total - 1 && "last-child",
        total === 1 && "only-child",
        selected && "selected",
      )}
      style={{
        ["--status" as string]: STATUS_MAP[color].color,
        // Готовность этапа — заливка самой фигуры слева направо. Раньше на её
        // месте были сегментные полоски по числу возможностей: они кодировали
        // не проценты, а состав оценки, и без легенды читались как непонятно
        // что. Заливка говорит то же самое, что и шкала в шапке, и не требует
        // расшифровки.
        ["--pct" as string]: String(pct),
        ["--delay" as string]: `${index * 48}ms`,
        zIndex: total - index,
      }}
      aria-label={`${item.title}. Готовность ${pct}%`}
      onClick={onClick}
    >
      <div className="stage-name">{item.title}</div>
      <div className="stage-pct">{pct}%</div>
    </button>
  );
}

function SummarySection({ summary }: { summary: AnalysisResult["summary"] }) {
  if (!summary) return null;
  const risks = summary.risks || [];
  const priorities = summary.priorities || [];
  return (
    <section className="summary-wrap">
      <div className="summary-main">
        <article className="conclusion-card">
          {/* Обычный заголовок, а не вертикальная микроподпись сбоку: это
              главный вывод отчёта, и он должен читаться первым. */}
          <h2 className="summary-title">Итог анализа</h2>
          <div className="conclusion-text">{summary.conclusion}</div>
        </article>
      </div>
      <div className="summary-stack">
        <article className="list-card">
          <div className="list-head">
            <div className="list-title">
              <span className="list-icon" style={{ ["--icon" as string]: "var(--red)", ["--icon-soft" as string]: "var(--red-soft)" }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 9v4" /><path d="M12 17h.01" /><path d="M10.3 3.6 2.1 17.2a2 2 0 0 0 1.7 3h16.4a2 2 0 0 0 1.7-3L13.7 3.6a2 2 0 0 0-3.4 0Z" />
                </svg>
              </span>
              <span>Ключевые риски</span>
            </div>
            <span className="list-count">{risks.length}</span>
          </div>
          <div className="smart-list">
            {/* Маркеры, не номера: нумерация обещает очередь, а у рисков её
                нет — они ранжированы по важности, но не выполняются подряд.
                У шагов ниже очередь осмысленна, там номера остаются. */}
            {risks.length === 0 ? <div className="smart-text">Нет пунктов.</div> : risks.map((t, i) => (
              <div key={i} className="smart-item" style={{ ["--item-color" as string]: "var(--red)" }}>
                <span className="smart-dot-marker" aria-hidden="true" />
                <div className="smart-text">{t}</div>
              </div>
            ))}
          </div>
        </article>
        <article className="list-card">
          <div className="list-head">
            <div className="list-title">
              <span className="list-icon" style={{ ["--icon" as string]: "var(--primary)", ["--icon-soft" as string]: "var(--primary-soft)" }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14" /><path d="m13 6 6 6-6 6" />
                </svg>
              </span>
              <span>Что сделать в первую очередь</span>
            </div>
            <span className="list-count">{priorities.length}</span>
          </div>
          <div className="smart-list">
            {priorities.length === 0 ? <div className="smart-text">Нет пунктов.</div> : priorities.map((t, i) => (
              <div key={i} className="smart-item" style={{ ["--item-color" as string]: "var(--primary)" }}>
                <span className="smart-num">{String(i + 1).padStart(2, "0")}</span>
                <div className="smart-text">{t}</div>
              </div>
            ))}
          </div>
        </article>
      </div>
    </section>
  );
}

const ICONS = {
  sun: "M12 3v2 M12 19v2 M3 12h2 M19 12h2 m5.64 5.64 1.42-1.42 m16.94 16.94 1.42-1.42 m5.64 18.36 1.42-1.42 m16.94 7.06 1.42-1.42 M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z",
  moon: "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z",
};

function ThemeToggle({ theme, onToggle }: { theme: string; onToggle: () => void }) {
  const dark = theme === "dark";
  return (
    <button
      type="button"
      className="icon-btn"
      aria-label="Переключить тему"
      onClick={onToggle}
    >
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        {(dark ? ICONS.sun.split(" M") : ICONS.moon.split(" M")).map((d, i) => (
          <path key={i} d={i === 0 ? d : "M" + d} />
        ))}
      </svg>
    </button>
  );
}

export function Dashboard({ analysis, analysisId }: { analysis: AnalysisResult; analysisId: string }) {
  const { meta, readiness, items, summary } = analysis;
  const title = meta.title || meta.repo || "Проект";
  const [selected, setSelected] = useState<number | null>(null);
  const [theme, setTheme] = useState(() => {
    try {
      const saved = localStorage.getItem("readiness-theme");
      if (saved === "light" || saved === "dark") return saved;
    } catch { /* noop */ }
    return "light";
  });

  // data-theme на корневом div дашборда, НЕ на <html> — иначе тёмная тема
  // ломает экраны 1 и 2 (переменные dashboard.css перезаписывают globals.css).
  const themeAttrs = { "data-theme": theme };

  useEffect(() => {
    try { localStorage.setItem("readiness-theme", theme); } catch { /* noop */ }
  }, [theme]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSelected(null);
      if (selected !== null && e.key === "ArrowRight" && selected < items.length - 1) setSelected(selected + 1);
      if (selected !== null && e.key === "ArrowLeft" && selected > 0) setSelected(selected - 1);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [selected, items.length]);

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      document.documentElement.style.setProperty("--mx", `${(e.clientX / window.innerWidth * 100).toFixed(1)}%`);
      document.documentElement.style.setProperty("--my", `${(e.clientY / window.innerHeight * 100).toFixed(1)}%`);
    };
    document.addEventListener("pointermove", onMove, { passive: true });
    return () => document.removeEventListener("pointermove", onMove);
  }, []);

  return (
    <div className="dashboard-root" {...themeAttrs}>
      <div className="ambient" aria-hidden="true" />
      <div className="noise" aria-hidden="true" />

      <header className="topbar">
        <div className="top-actions">
          <ThemeToggle theme={theme} onToggle={() => setTheme(theme === "dark" ? "light" : "dark")} />
        </div>
      </header>

      <main className="shell">
        <section className="hero">
          <div className="hero-grid">
            <div>
              <div className="eyebrow">
                <span className="eyebrow-dot" />
                <span>Анализ готовности проекта</span>
              </div>
              <h1>{title}</h1>
              {/* Подзаголовок — описание проекта от агента (о чём он и зачем).
                  Фолбэк описывает сам дашборд и нужен только тогда, когда
                  агент описания не прислал: раньше эта фраза стояла здесь
                  всегда и первым же абзацем не сообщала читателю ничего о
                  проекте. */}
              <p className="hero-sub">
                {meta.description
                  || "Интерактивная карта готовности: от общей картины до конкретных этапов, рисков и следующих действий."}
              </p>
            </div>
            <Gauge readiness={readiness} />
          </div>
        </section>

        {/* Вывод идёт до детализации: первому лицу нужен порядок
            «заголовок → готовность → вывод», а этапы — уже подробности. */}
        <SummarySection summary={summary} />

        <section className="section">
          <div className="section-head">
            <div>
              <h2 className="section-title">Клиентский путь</h2>
              <p className="section-note">Нажмите на этап — откроются готовность, описание и оценка модели.</p>
            </div>
            <StatusCounters items={items} />
          </div>
          {items.length === 0 ? (
            <div className="empty">Этапы проекта пока не найдены.</div>
          ) : (
            <div className="journey-viewport">
              <div className="journey">
                {items.map((item, i) => (
                  <StagePuzzle
                    key={i}
                    item={item}
                    index={i}
                    total={items.length}
                    selected={selected === i}
                    onClick={() => setSelected(selected === i ? null : i)}
                  />
                ))}
              </div>
            </div>
          )}
        </section>

        <div className="download-bar">
          <a
            href={`/api/analyses/${analysisId}/dashboard.html`}
            download={downloadName(meta)}
            className="download-btn"
          >
            <Download className="size-4" aria-hidden="true" />
            Скачать дашборд
          </a>
        </div>
      </main>

      <Spotlight
        items={items}
        selected={selected}
        onClose={() => setSelected(null)}
        onNavigate={setSelected}
      />
    </div>
  );
}

"use client";

import { useEffect, useState } from "react";
import type { AnalysisResult, AssessmentItem, StageItem } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Download } from "lucide-react";
import "./dashboard.css";

// Веб-экран результатов — тот же дашборд, что и скачиваемый HTML
// (`backend/pko/render/dashboard_template.html`), только на React. Данные,
// расчёты и разметка совпадают намеренно: руководство не должно видеть две
// разные эстетики от одного инструмента. Стили перенесены из шаблона
// скриптом, а логика — этим файлом; расхождение здесь означает баг, а не
// вариант дизайна.
//
// Процент и цвет этапа не приходят с бэкенда: их считает сам экран по
// применимым буллитам, ровно как шаблон. Общая готовность, наоборот, приходит
// готовой — это оценка модели, а не среднее.

const STATUS_COLOR: Record<string, string> = {
  green: "var(--green)",
  amber: "var(--amber)",
  red: "var(--red)",
  purple: "var(--na)",
};

type CriterionKey = "done" | "partial" | "planned" | "blocked" | "na";

const CRITERION: Record<CriterionKey, { color: string; label: string; icon: string }> = {
  done: { color: "var(--green)", label: "Выполнено", icon: "✓" },
  partial: { color: "var(--purple)", label: "В работе", icon: "" },
  planned: { color: "var(--text-3)", label: "Запланировано", icon: "" },
  blocked: { color: "var(--red)", label: "Блокирующий фактор", icon: "×" },
  na: { color: "var(--na)", label: "Не относится", icon: "—" },
};

function criterionKey(item: AssessmentItem): CriterionKey {
  if (item.applicable !== true) return "na";
  const raw = String(item.status || "").toLowerCase();
  if (raw === "done") return "done";
  if (raw === "partial") return "partial";
  if (raw === "blocked") return "blocked";
  return "planned";
}

// Готовность этапа: вес применимых буллитов, делённый на их число.
// `null` — этап не про эту инициативу либо в нём нет ни одного применимого
// пункта: тогда он серый и в картину не входит.
function stagePercent(item: StageItem): number | null {
  if (item.applicable !== true) return null;
  const applicable = (item.assessment || []).filter((x) => x && x.applicable === true);
  if (!applicable.length) return null;
  const score = applicable.reduce((sum, x) => {
    const key = criterionKey(x);
    return sum + (key === "done" ? 1 : key === "partial" ? 0.5 : 0);
  }, 0);
  return Math.round((score / applicable.length) * 100);
}

function stageColor(item: StageItem): string {
  const p = stagePercent(item);
  if (p === null) return "purple";
  return p >= 80 ? "green" : p >= 40 ? "amber" : "red";
}

function formatDate(value?: string): string {
  if (!value) return "";
  const d = new Date(value);
  if (isNaN(d.getTime())) return String(value);
  try {
    return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "short", year: "numeric" });
  } catch {
    return String(value);
  }
}

function downloadName(meta: AnalysisResult["meta"]): string {
  const base = (meta.project_name || meta.client_path_name || meta.repo || "project")
    .replace(/[^A-Za-z0-9А-Яа-я]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "project";
  return `pko-dashboard-${base}.html`;
}

function Gauge({ percent }: { percent: number }) {
  const r = 88;
  const c = 2 * Math.PI * r;
  const [offset, setOffset] = useState(c);
  useEffect(() => {
    const id = requestAnimationFrame(() => setOffset(c * (1 - percent / 100)));
    return () => cancelAnimationFrame(id);
  }, [percent, c]);

  return (
    <div className="gauge-wrap">
      <div className="gauge-halo" />
      <svg className="gauge-svg" viewBox="0 0 220 220">
        <defs>
          <linearGradient id="gaugeGradient" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--primary)" />
            <stop offset="62%" stopColor="var(--primary-2)" />
            <stop offset="100%" stopColor="var(--green)" />
          </linearGradient>
        </defs>
        <circle className="gauge-track" cx="110" cy="110" r={r} />
        <circle
          className="gauge-progress"
          cx="110" cy="110" r={r}
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="gauge-center">
        <div className="gauge-value">{percent}%</div>
        <div className="gauge-caption">готовность</div>
      </div>
    </div>
  );
}

function StatusLegend() {
  const defs: [CriterionKey, string][] = [
    ["done", "Реализовано"],
    ["partial", "В работе"],
    ["planned", "Запланировано"],
    ["blocked", "Блокирующий фактор"],
    ["na", "Не относится"],
  ];
  return (
    <div className="status-legend">
      {defs.map(([key, label]) => (
        <span key={key} className="legend-item">
          <i
            className={cn("legend-mark", key)}
            style={{ ["--legend" as string]: CRITERION[key].color }}
          >
            {CRITERION[key].icon}
          </i>
          <span>{label}</span>
        </span>
      ))}
    </div>
  );
}

function StageCard({ item, index }: { item: StageItem; index: number }) {
  const color = stageColor(item);
  const percent = stagePercent(item);
  const criteria = item.assessment || [];

  return (
    <article
      className={cn("stage-card", color === "purple" && "na")}
      style={{
        ["--status" as string]: STATUS_COLOR[color],
        ["--delay" as string]: `${index * 48}ms`,
      }}
      aria-label={`${item.title}. ${percent === null ? "Не относится к проекту" : `Готовность ${percent}%`}`}
    >
      <div className="stage-top">
        <span className="stage-index">{String(index + 1).padStart(2, "0")}</span>
        <span className="stage-pct">{percent === null ? "Не относится" : `${percent}%`}</span>
      </div>
      <h3 className="stage-name">{item.title || "Без названия"}</h3>
      <p className="stage-description">{item.description || "Описание этапа не указано."}</p>
      <div className="criteria-list">
        {criteria.length === 0 && <div className="empty">Критерии не заданы</div>}
        {criteria.map((criterion, i) => {
          // Этап целиком неприменим — значит и все его пункты серые, что бы
          // ни стояло у них в статусе.
          const key = item.applicable !== true ? "na" : criterionKey(criterion);
          const state = CRITERION[key];
          return (
            <div
              key={i}
              className={cn("criterion", key)}
              style={{ ["--bullet" as string]: state.color }}
              aria-label={state.label}
            >
              <span className="criterion-state">{state.icon}</span>
              <div className="criterion-text">{criterion.text || "Без описания"}</div>
            </div>
          );
        })}
      </div>
    </article>
  );
}

const ICON_ALERT = [
  "M12 9v4", "M12 17h.01",
  "M10.3 3.6 2.1 17.2a2 2 0 0 0 1.7 3h16.4a2 2 0 0 0 1.7-3L13.7 3.6a2 2 0 0 0-3.4 0Z",
];
const ICON_ARROW = ["M5 12h14", "m13 6 6 6-6 6"];

function Icon({ paths }: { paths: string[] }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"
         strokeLinecap="round" strokeLinejoin="round">
      {paths.map((d, i) => <path key={i} d={d} />)}
    </svg>
  );
}

function ListCard({ title, items, tone }: { title: string; items: string[]; tone: "risk" | "priority" }) {
  const isRisk = tone === "risk";
  const color = isRisk ? "var(--red)" : "var(--primary)";
  return (
    <article className="list-card">
      <div className="list-head">
        <div className="list-title">
          <span
            className="list-icon"
            style={{
              ["--icon" as string]: color,
              ["--icon-soft" as string]: isRisk ? "var(--red-soft)" : "var(--primary-soft)",
            }}
          >
            <Icon paths={isRisk ? ICON_ALERT : ICON_ARROW} />
          </span>
          <span>{title}</span>
        </div>
        <span className="list-count">{items.length}</span>
      </div>
      <div className="smart-list">
        {items.length === 0 ? (
          <div className="smart-text">Нет пунктов.</div>
        ) : (
          items.map((text, i) => (
            <div key={i} className="smart-item" style={{ ["--item-color" as string]: color }}>
              <span className="smart-num">{String(i + 1).padStart(2, "0")}</span>
              <div className="smart-text">{text}</div>
            </div>
          ))
        )}
      </div>
    </article>
  );
}

const SUN = ["M12 3v2", "M12 19v2", "M3 12h2", "M19 12h2", "m5.64 5.64 1.42-1.42",
             "m16.94 16.94 1.42-1.42", "m5.64 18.36 1.42-1.42", "m16.94 7.06 1.42-1.42",
             "M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z"];
const MOON = ["M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z"];

export function Dashboard({ analysis, analysisId }: { analysis: AnalysisResult; analysisId: string }) {
  const { meta, readiness, items, summary } = analysis;
  const pathName = meta.client_path_name || "Клиентский путь";
  const projectName = meta.project_name || meta.repo || "Название проекта";
  const percent = Math.max(0, Math.min(100, Math.round(readiness)));

  // Решение приходит от модели. Резервный вывод по проценту — на случай, если
  // поле не дошло: шаблон делает ровно так же, и расходиться им нельзя.
  const rawDecision = String(meta.decision || "").toUpperCase().replace("NO-GO", "NO GO");
  const decision = ["GO", "PIVOT", "NO GO"].includes(rawDecision)
    ? rawDecision
    : percent >= 80 ? "GO" : percent >= 40 ? "PIVOT" : "NO GO";
  const decisionClass = decision === "GO" ? "go" : decision === "NO GO" ? "no-go" : "pivot";
  const decisionColor =
    decisionClass === "go" ? "var(--green)" : decisionClass === "no-go" ? "var(--red)" : "var(--amber)";

  const [theme, setTheme] = useState(() => {
    try {
      const saved = localStorage.getItem("readiness-theme");
      if (saved === "light" || saved === "dark") return saved;
    } catch { /* noop */ }
    return "light";
  });

  useEffect(() => {
    try { localStorage.setItem("readiness-theme", theme); } catch { /* noop */ }
  }, [theme]);

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      document.documentElement.style.setProperty("--mx", `${(e.clientX / window.innerWidth * 100).toFixed(1)}%`);
      document.documentElement.style.setProperty("--my", `${(e.clientY / window.innerHeight * 100).toFixed(1)}%`);
    };
    document.addEventListener("pointermove", onMove, { passive: true });
    return () => document.removeEventListener("pointermove", onMove);
  }, []);

  return (
    <div className="dashboard-root" data-theme={theme}>
      <div className="ambient" aria-hidden="true" />
      <div className="noise" aria-hidden="true" />

      <main className="shell">
        <header className="topbar">
          <div className="top-actions">
            <button
              type="button"
              className="icon-btn"
              aria-label="Переключить тему"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            >
              <Icon paths={theme === "dark" ? SUN : MOON} />
            </button>
          </div>
        </header>

        <section className="hero">
          <div className="hero-grid">
            <div className="hero-content">
              <div className="eyebrow">
                <span className="eyebrow-dot" />
                <span>Автономный анализ проекта</span>
              </div>
              <h1>{pathName}</h1>
              <div className="project-name">{projectName}</div>
              <div className="project-story">
                <div className="story-block story-client">
                  <span className="story-label">Клиент</span>
                  <strong className="story-value">{meta.client || "Клиент проекта не указан"}</strong>
                </div>
                <div className="story-block story-change">
                  <span className="story-label">Было → стало</span>
                  <strong className="story-value">
                    {(meta.before || "Исходное состояние не указано")} → {(meta.after || "Целевое состояние не указано")}
                  </strong>
                </div>
              </div>
            </div>

            <div className="hero-side">
              <div className="hero-side-card gauge-card">
                <Gauge percent={percent} />
              </div>
              <div
                className="hero-side-card verdict-card"
                style={{ ["--decision" as string]: decisionColor }}
              >
                <div className="verdict-label">Оценка ИИ по клиентскому пути</div>
                <div className={cn("decision-badge", decisionClass)}>{decision}</div>
                <div className="verdict-guide">
                  GO — развивать · PIVOT — скорректировать · NO GO — остановить
                </div>
                <p className="verdict-copy">
                  {summary?.conclusion || "Общий вывод пока не сформирован."}
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="section-head">
            <div>
              <h2 className="section-title">Клиентский путь</h2>
              <p className="section-note">
                Этапы пути и статус ключевых результатов внутри каждого этапа.
              </p>
            </div>
            <StatusLegend />
          </div>
          {items.length === 0 ? (
            <div className="empty">Этапы проекта пока не найдены.</div>
          ) : (
            <div className="journey-viewport">
              <div className="journey" style={{ ["--stage-count" as string]: String(items.length) }}>
                {items.map((item, i) => <StageCard key={i} item={item} index={i} />)}
              </div>
            </div>
          )}
        </section>

        {summary && (
          <section className="summary-wrap">
            <ListCard title="Риски" items={summary.risks || []} tone="risk" />
            <ListCard title="Что важно делать" items={summary.priorities || []} tone="priority" />
          </section>
        )}

        <footer className="footer">
          <span>
            <span className="footer-dot" />
            Автономный анализ проекта
          </span>
          <a
            href={`/api/analyses/${analysisId}/dashboard.html`}
            download={downloadName(meta)}
            className="download-btn"
          >
            <Download className="size-4" aria-hidden="true" />
            Скачать дашборд
          </a>
          <span>{meta.generated_at ? `Обновлено ${formatDate(meta.generated_at)}` : ""}</span>
        </footer>
      </main>
    </div>
  );
}

"use client";

import { useCallback, useEffect, useState } from "react";
import type { AnalysisResult, StageItem } from "@/lib/types";
import { Spotlight } from "./Spotlight";
import { cn } from "@/lib/utils";
import { Download } from "lucide-react";
import "./dashboard.css";

const STATUS_MAP: Record<string, { color: string; fallback: string }> = {
  green: { color: "var(--green)", fallback: "Сделано" },
  amber: { color: "var(--amber)", fallback: "Частично" },
  red: { color: "var(--red)", fallback: "Не начато" },
  purple: { color: "var(--purple)", fallback: "Неясно" },
};

function safeColor(item: StageItem): string {
  if (STATUS_MAP[item.color] && item.color !== "purple") return item.color;
  return item.pct >= 80 ? "green" : item.pct >= 40 ? "amber" : "red";
}

function downloadName(meta: AnalysisResult["meta"]): string {
  const base = (meta.title || meta.repo || "project")
    .replace(/[^A-Za-z0-9А-Яа-я]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "project";
  return `pko-dashboard-${base}.html`;
}

function Gauge({ readiness }: { readiness: number }) {
  const pct = Math.round(readiness * 100);
  const r = 88;
  const c = 2 * Math.PI * r;
  const [offset, setOffset] = useState(c);
  useEffect(() => {
    requestAnimationFrame(() => setOffset(c * (1 - readiness)));
  }, [readiness, c]);

  return (
    <div className="gauge-wrap">
      <div className="gauge-halo" />
      <svg className="gauge-svg" viewBox="0 0 220 220">
        <defs>
          <linearGradient id="gaugeGradient" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--primary)" />
            <stop offset="62%" stopColor="var(--primary-2)" />
            <stop offset="100%" stopColor="var(--green)" />
          </linearGradient>
        </defs>
        <circle className="gauge-track" cx="110" cy="110" r={r} />
        <circle
          className="gauge-progress"
          cx="110" cy="110" r={r}
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="gauge-center">
        <div className="gauge-value">{pct}%</div>
        <div className="gauge-caption">готовность</div>
      </div>
    </div>
  );
}

function FilterBar({
  items, activeFilter, onFilter,
}: {
  items: StageItem[];
  activeFilter: string;
  onFilter: (f: string) => void;
}) {
  const countColor = (c: string) => items.filter((x) => safeColor(x) === c).length;
  const defs: [string, string, number, string][] = [
    ["all", "Все", items.length, "var(--primary)"],
    ["green", "Сделано", countColor("green"), "var(--green)"],
    ["amber", "Частично", countColor("amber"), "var(--amber)"],
    ["red", "Не начато", countColor("red"), "var(--red)"],
  ];
  return (
    <div className="filterbar">
      {defs.map(([key, label, count, color]) => (
        <button
          key={key}
          type="button"
          className={cn("filter-btn", activeFilter === key && "active")}
          onClick={() => onFilter(key)}
        >
          <i className="filter-dot" style={{ ["--dot" as string]: color }} />
          <span>{label} · {count}</span>
        </button>
      ))}
    </div>
  );
}

function StagePuzzle({
  item, index, total, selected, filtered, onClick,
}: {
  item: StageItem;
  index: number;
  total: number;
  selected: boolean;
  filtered: boolean;
  onClick: () => void;
}) {
  const color = safeColor(item);
  const assessment = (item.assessment || []).slice(0, 5);
  const statusKey = (s: string) => {
    const r = s.toLowerCase();
    if (r === "done" || r === "completed") return "done";
    if (r === "partial") return "partial";
    return "not_started";
  };

  return (
    <button
      type="button"
      className={cn(
        "stage-card",
        index === 0 && "first-child",
        index === total - 1 && "last-child",
        total === 1 && "only-child",
        selected && "selected",
        filtered && "filtered",
      )}
      style={{
        ["--status" as string]: STATUS_MAP[color].color,
        ["--delay" as string]: `${index * 48}ms`,
        zIndex: total - index,
      }}
      aria-label={`${item.title}. Готовность ${item.pct}%`}
      onClick={onClick}
    >
      <div className="stage-name">{item.title}</div>
      <div className="criteria-preview">
        <div className="criteria-dots">
          {assessment.map((a, i) => (
            <span key={i} className={cn("criteria-dot", statusKey(a.status))} />
          ))}
          {Array.from({ length: Math.max(0, 5 - assessment.length) }).map((_, i) => (
            <span key={`e${i}`} className="criteria-dot empty" />
          ))}
        </div>
      </div>
    </button>
  );
}

function SummarySection({ summary }: { summary: AnalysisResult["summary"] }) {
  if (!summary) return null;
  const risks = summary.risks || [];
  const priorities = summary.priorities || [];
  return (
    <section className="summary-wrap">
      <div className="summary-main">
        <article className="conclusion-card">
          <div className="summary-overline">Итог</div>
          <div className="conclusion-text">{summary.conclusion}</div>
        </article>
      </div>
      <div className="summary-stack">
        <article className="list-card">
          <div className="list-head">
            <div className="list-title">
              <span className="list-icon" style={{ ["--icon" as string]: "var(--red)", ["--icon-soft" as string]: "var(--red-soft)" }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 9v4" /><path d="M12 17h.01" /><path d="M10.3 3.6 2.1 17.2a2 2 0 0 0 1.7 3h16.4a2 2 0 0 0 1.7-3L13.7 3.6a2 2 0 0 0-3.4 0Z" />
                </svg>
              </span>
              <span>Ключевые риски</span>
            </div>
            <span className="list-count">{risks.length}</span>
          </div>
          <div className="smart-list">
            {risks.length === 0 ? <div className="smart-text">Нет пунктов.</div> : risks.map((t, i) => (
              <div key={i} className="smart-item" style={{ ["--item-color" as string]: "var(--red)" }}>
                <span className="smart-num">{String(i + 1).padStart(2, "0")}</span>
                <div className="smart-text">{t}</div>
              </div>
            ))}
          </div>
        </article>
        <article className="list-card">
          <div className="list-head">
            <div className="list-title">
              <span className="list-icon" style={{ ["--icon" as string]: "var(--primary)", ["--icon-soft" as string]: "var(--primary-soft)" }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 12h14" /><path d="m13 6 6 6-6 6" />
                </svg>
              </span>
              <span>Следующий лучший шаг</span>
            </div>
            <span className="list-count">{priorities.length}</span>
          </div>
          <div className="smart-list">
            {priorities.length === 0 ? <div className="smart-text">Нет пунктов.</div> : priorities.map((t, i) => (
              <div key={i} className="smart-item" style={{ ["--item-color" as string]: "var(--primary)" }}>
                <span className="smart-num">{String(i + 1).padStart(2, "0")}</span>
                <div className="smart-text">{t}</div>
              </div>
            ))}
          </div>
        </article>
      </div>
    </section>
  );
}

const ICONS = {
  sun: "M12 3v2 M12 19v2 M3 12h2 M19 12h2 m5.64 5.64 1.42-1.42 m16.94 16.94 1.42-1.42 m5.64 18.36 1.42-1.42 m16.94 7.06 1.42-1.42 M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z",
  moon: "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z",
};

function ThemeToggle({ theme, onToggle }: { theme: string; onToggle: () => void }) {
  const dark = theme === "dark";
  return (
    <button
      type="button"
      className="icon-btn"
      aria-label="Переключить тему"
      onClick={onToggle}
    >
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        {(dark ? ICONS.sun.split(" M") : ICONS.moon.split(" M")).map((d, i) => (
          <path key={i} d={i === 0 ? d : "M" + d} />
        ))}
      </svg>
    </button>
  );
}

export function Dashboard({ analysis, analysisId }: { analysis: AnalysisResult; analysisId: string }) {
  const { meta, readiness, items, summary } = analysis;
  const title = meta.title || meta.repo || "Проект";
  const [selected, setSelected] = useState<number | null>(null);
  const [activeFilter, setActiveFilter] = useState("all");
  const [theme, setTheme] = useState(() => {
    try {
      const saved = localStorage.getItem("readiness-theme");
      if (saved === "light" || saved === "dark") return saved;
    } catch { /* noop */ }
    return "light";
  });

  // data-theme на корневом div дашборда, НЕ на <html> — иначе тёмная тема
  // ломает экраны 1 и 2 (переменные dashboard.css перезаписывают globals.css).
  const themeAttrs = { "data-theme": theme };

  useEffect(() => {
    try { localStorage.setItem("readiness-theme", theme); } catch { /* noop */ }
  }, [theme]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSelected(null);
      if (selected !== null && e.key === "ArrowRight" && selected < items.length - 1) setSelected(selected + 1);
      if (selected !== null && e.key === "ArrowLeft" && selected > 0) setSelected(selected - 1);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [selected, items.length]);

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      document.documentElement.style.setProperty("--mx", `${(e.clientX / window.innerWidth * 100).toFixed(1)}%`);
      document.documentElement.style.setProperty("--my", `${(e.clientY / window.innerHeight * 100).toFixed(1)}%`);
    };
    document.addEventListener("pointermove", onMove, { passive: true });
    return () => document.removeEventListener("pointermove", onMove);
  }, []);

  const handleFilter = useCallback((f: string) => setActiveFilter(f), []);

  return (
    <div className="dashboard-root" {...themeAttrs}>
      <div className="ambient" aria-hidden="true" />
      <div className="noise" aria-hidden="true" />

      <header className="topbar">
        <div className="top-actions">
          <ThemeToggle theme={theme} onToggle={() => setTheme(theme === "dark" ? "light" : "dark")} />
        </div>
      </header>

      <main className="shell">
        <section className="hero">
          <div className="hero-grid">
            <div>
              <div className="eyebrow">
                <span className="eyebrow-dot" />
                <span>Анализ готовности проекта</span>
              </div>
              <h1>{title}</h1>
              <p className="hero-sub">
                Интерактивная карта готовности: от общей картины до конкретных этапов, рисков и следующих действий.
              </p>
            </div>
            <Gauge readiness={readiness} />
          </div>
        </section>

        <section className="section">
          <div className="section-head">
            <div>
              <h2 className="section-title">Клиентский путь</h2>
              <p className="section-note">Нажмите на этап — откроются готовность, описание и оценка модели.</p>
            </div>
            <FilterBar items={items} activeFilter={activeFilter} onFilter={handleFilter} />
          </div>
          {items.length === 0 ? (
            <div className="empty">Этапы проекта пока не найдены.</div>
          ) : (
            <div className="journey-viewport">
              <div className="journey">
                {items.map((item, i) => (
                  <StagePuzzle
                    key={i}
                    item={item}
                    index={i}
                    total={items.length}
                    selected={selected === i}
                    filtered={activeFilter !== "all" && safeColor(item) !== activeFilter}
                    onClick={() => setSelected(selected === i ? null : i)}
                  />
                ))}
              </div>
            </div>
          )}
        </section>

        <SummarySection summary={summary} />

        <div className="download-bar">
          <a
            href={`/api/analyses/${analysisId}/dashboard.html`}
            download={downloadName(meta)}
            className="download-btn"
          >
            <Download className="size-4" aria-hidden="true" />
            Скачать дашборд
          </a>
        </div>
      </main>

      <Spotlight
        items={items}
        selected={selected}
        onClose={() => setSelected(null)}
        onNavigate={setSelected}
      />
    </div>
  );
}

"use client";

import { useState } from "react";
import type { StageItem } from "@/lib/types";
import { cn } from "@/lib/utils";

const STATUS_MAP: Record<string, { color: string; fallback: string }> = {
  green: { color: "var(--green)", fallback: "Сделано" },
  amber: { color: "var(--amber)", fallback: "Частично" },
  red: { color: "var(--red)", fallback: "Не начато" },
  purple: { color: "var(--purple)", fallback: "Неясно" },
};

function safeColor(item: StageItem): string {
  if (STATUS_MAP[item.color] && item.color !== "purple") return item.color;
  return item.pct >= 80 ? "green" : item.pct >= 40 ? "amber" : "red";
}

const ASSESSMENT_ICONS: Record<string, { icon: string; color: string }> = {
  done: { icon: "✓", color: "var(--green)" },
  partial: { icon: "◐", color: "var(--amber)" },
  not_started: { icon: "○", color: "var(--red)" },
};

function statusKey(s: string): keyof typeof ASSESSMENT_ICONS {
  const r = s.toLowerCase();
  if (r === "done" || r === "completed") return "done";
  if (r === "partial") return "partial";
  return "not_started";
}

function AssessmentRow({ item, index, stageIndex }: { item: StageItem["assessment"][0]; index: number; stageIndex: number }) {
  const [open, setOpen] = useState(false);
  const st = ASSESSMENT_ICONS[statusKey(item.status)];
  const hasComment = !!(item.comment && item.comment.trim());

  return (
    <div className={cn("assessment-item", open && "open")} style={{ ["--bullet" as string]: st.color }}>
      <button
        type="button"
        className="assessment-row"
        aria-expanded={open}
        aria-controls={hasComment ? `assessment-comment-${stageIndex}-${index}` : undefined}
        onClick={hasComment ? () => setOpen(!open) : undefined}
        style={hasComment ? undefined : { cursor: "default" }}
      >
        <span className="assessment-state">{st.icon}</span>
        <div className="assessment-row-text">{item.text}</div>
      </button>
      {hasComment && (
        <div className="assessment-comment-wrap" id={`assessment-comment-${stageIndex}-${index}`}>
          <div className="assessment-comment-clip">
            <div className="assessment-comment">{item.comment}</div>
          </div>
        </div>
      )}
    </div>
  );
}

export function Spotlight({
  items, selected, onClose, onNavigate,
}: {
  items: StageItem[];
  selected: number | null;
  onClose: () => void;
  onNavigate: (i: number) => void;
}) {
  if (selected === null) {
    return (
      <>
        <div className="spotlight-backdrop" />
        <aside className="spotlight" role="dialog" aria-modal="true" aria-label="Детали этапа" />
      </>
    );
  }

  const item = items[selected];
  if (!item) return null;
  const color = safeColor(item);
  const p = item.pct;
  const assessment = (item.assessment || []).slice(0, 5);

  return (
    <>
      <div className={cn("spotlight-backdrop", "open")} onClick={onClose} />
      <aside
        className={cn("spotlight", "open")}
        role="dialog"
        aria-modal="true"
        aria-label="Детали этапа"
        style={{ ["--status" as string]: STATUS_MAP[color].color }}
      >
        <div className="spotlight-inner">
          <div className="spotlight-top">
            <div className="spotlight-step">
              Этап {String(selected + 1).padStart(2, "0")} / {String(items.length).padStart(2, "0")}
            </div>
            <button type="button" className="close-btn" aria-label="Закрыть" onClick={onClose}>×</button>
          </div>

          <div className="spotlight-status">
            <i />
            <span>{item.label || STATUS_MAP[color].fallback}</span>
          </div>

          <h2 className="spotlight-title">{item.title}</h2>

          <div className="spotlight-meter">
            <div className="small-ring" style={{ ["--p" as string]: String(p) }}>
              <strong>{p}%</strong>
            </div>
            <div className="meter-copy">
              <b>Текущая готовность этапа</b>
              <span>{item.description || item.title}</span>
            </div>
          </div>

          <section className="spot-section">
            <div className="spot-label">Оценка модели</div>
            <div className="assessment-list">
              {assessment.length === 0 ? (
                <div className="spot-copy">Для этого этапа оценка модели пока не сформирована.</div>
              ) : (
                assessment.map((a, i) => (
                  <AssessmentRow key={i} item={a} index={i} stageIndex={selected} />
                ))
              )}
            </div>
          </section>

          <div className="spot-nav">
            <button
              type="button"
              disabled={selected === 0}
              onClick={() => onNavigate(selected - 1)}
            >
              ← Предыдущий
            </button>
            <button
              type="button"
              disabled={selected === items.length - 1}
              onClick={() => onNavigate(selected + 1)}
            >
              Следующий →
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}

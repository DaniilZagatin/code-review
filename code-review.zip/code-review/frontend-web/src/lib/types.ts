// Зеркало JSON-контракта backend/pko/web/analyses.py::_dashboard_json и
// событий SSE из backend/pko/web/app.py::stream_analysis_events.
//
// Контракт задаёт шаблон дашборда (backend/pko/render/dashboard_template.html):
// веб-экран и скачиваемый HTML читают одни и те же данные, поэтому типы здесь
// повторяют его поля один в один. Процент и цвет этапа в контракт не входят —
// их считает сам шаблон (и, зеркально, компонент дашборда) по применимым
// буллитам, чтобы цифра не могла разойтись с тем, что под ней нарисовано.

// Один буллит этапа — дословный текст из образа результата плюс оценка.
// `applicable` приходит только у пунктов, относящихся к анализируемой
// инициативе: у остальных полей нет вовсе, они серые и в расчёт не входят.
export interface AssessmentItem {
  text: string;
  applicable?: boolean;
  status?: "done" | "partial" | "planned" | "blocked";
}

export interface StageItem {
  title: string;
  description: string;
  applicable?: boolean;
  assessment: AssessmentItem[];
}

export interface AnalysisMeta {
  repo: string;
  branch: string;
  commit: string;
  plan_source: string;
  generated_at: string;
  // Шапка дашборда: название клиентского пути (крупный заголовок), название
  // инициативы под ним, кто клиент и что меняется в его опыте.
  client_path_name?: string;
  project_name?: string;
  client?: string;
  before?: string;
  after?: string;
  decision?: "GO" | "PIVOT" | "NO GO";
}

export interface ProjectSummary {
  conclusion: string;
  risks: string[];
  priorities: string[];
}

export interface AnalysisResult {
  status: "READY";
  meta: AnalysisMeta;
  // Целостная оценка модели 0..100, а не среднее по этапам.
  readiness: number;
  items: StageItem[];
  summary?: ProjectSummary;
}

export interface AnalysisPending {
  status: "PROCESSING";
}

export interface AnalysisFailed {
  status: "ERROR";
  message: string;
  hint: string;
}

export type Analysis = AnalysisResult | AnalysisPending | AnalysisFailed;

export interface CreateAnalysisResponse {
  analysis_id: string;
  status: "PROCESSING";
}

export interface ApiErrorBody {
  message: string;
  hint: string;
}

// События SSE (`GET /api/analyses/{id}/events`).
export type PhaseName = "materials_loading" | "materials_ready";

export type AnalysisEvent =
  | { type: "phase"; phase: PhaseName; label: string }
  | { type: "presentation_parsed"; slide_count: number }
  | {
      type: "plan_ready";
      item_count: number;
      // `origin` — откуда взят этап: "materials" (скопирован из образа
      // результата) или "user" (задан в форме загрузки).
      items: {
        title: string;
        source_slide: number;
        origin: "materials" | "user";
        criteria: number;
      }[];
    }
  | {
      type: "claim_verified";
      title: string;
      applicable: boolean;
      percent: number | null;
      criteria: number;
    }
  | { type: "summary_ready"; text: string; decision: string }
  | { type: "analysis_ready" }
  | { type: "error"; message: string; hint: string };

// Зеркало JSON-контракта backend/pko/web/analyses.py::_dashboard_json и
// событий SSE из backend/pko/web/app.py::stream_analysis_events. Значения
// `color`/`status` — те же строки, что и в backend/pko/render/progress_report.py
// (STATUS_LABELS): "green"/"amber"/"red"/"purple", "DONE"/"PARTIAL"/
// "NOT_STARTED"/"UNCLEAR".

// Один буллет executive-чеклиста этапа. `status` — состояние этого тезиса
// (done/partial/not_started → иконка ✓/◐/○), не статус этапа целиком.
// `comment` — executive-обоснование (раскрывается по клику в spotlight).
export interface AssessmentItem {
  status: "done" | "partial" | "not_started";
  text: string;
  comment: string;
}

export interface StageItem {
  title: string;
  description: string;
  status: "DONE" | "PARTIAL" | "NOT_STARTED" | "UNCLEAR";
  label: string;
  color: "green" | "amber" | "red" | "purple";
  pct: number;
  assessment: AssessmentItem[];
}

export interface AnalysisMeta {
  repo: string;
  branch: string;
  commit: string;
  plan_source: string;
  generated_at: string;
  title: string;
  // Подзаголовок под названием проекта: о чём проект и зачем он нужен —
  // пишет агент (`submit_plan.project_summary`). Пустая строка, если он его
  // не прислал: тогда фронт показывает описание самого дашборда.
  description?: string;
  client?: string;
  client_goal?: string;
}

// Структурированный сводный вывод по всему проекту. Опционально: пока backend
// отдаёт общий вывод агента (`submit_summary`) как единый текст, `_dashboard_json`
// оборачивает его в `conclusion`, а `risks`/`priorities` остаются пустыми
// массивами — колонки рендерятся пустыми, но не ломаются (`BulletList` ничего
// не рисует на пустом массиве). Если `summary` в ответе нет вовсе —
// `ProjectSummaryPanel` не появляется, остальной дашборд работает как обычно.
export interface ProjectSummary {
  conclusion: string;
  risks: string[];
  priorities: string[];
}

export interface AnalysisResult {
  status: "READY";
  meta: AnalysisMeta;
  readiness: number;
  counts: Record<StageItem["status"], number>;
  items: StageItem[];
  summary?: ProjectSummary;
}

export interface AnalysisPending {
  status: "PROCESSING";
}

export interface AnalysisFailed {
  status: "ERROR";
  message: string;
  hint: string;
}

export type Analysis = AnalysisResult | AnalysisPending | AnalysisFailed;

export interface CreateAnalysisResponse {
  analysis_id: string;
  status: "PROCESSING";
}

export interface ApiErrorBody {
  message: string;
  hint: string;
}

// События SSE (`GET /api/analyses/{id}/events`) — ровно то, что кладёт в
// очередь backend/pko/web/analyses.py::_execute (`emit("phase", {...})` —
// только materials_loading/materials_ready) и адаптер `on_event`,
// передаваемый в `run_progress` (`presentation_parsed`/`plan_ready`/
// `claim_verified`/`summarizing` — прилетают как отдельные `type`, не
// завёрнутые в "phase").
export type PhaseName = "materials_loading" | "materials_ready";

export type AnalysisEvent =
  | { type: "phase"; phase: PhaseName; label: string }
  | { type: "presentation_parsed"; slide_count: number }
  | {
      type: "plan_ready";
      item_count: number;
      // `origin` — откуда взят этап: "slide" (назван в презентации), "user"
      // (задан в форме загрузки) или "restored" (агент собрал по опорной
      // карте, потому что этапов не было ни там, ни там).
      items: {
        title: string;
        source_slide: number;
        origin: "slide" | "user" | "restored";
      }[];
    }
  | {
      type: "claim_verified";
      title: string;
      status: StageItem["status"];
    }
  | { type: "summary_ready"; text: string }
  | { type: "analysis_ready" }
  | { type: "error"; message: string; hint: string };

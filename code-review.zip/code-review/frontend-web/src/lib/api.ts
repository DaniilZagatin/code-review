import type { Analysis, ApiErrorBody, CreateAnalysisResponse } from "./types";

// `/api/*` — в dev проксируется на FastAPI через rewrites() в next.config.ts,
// в проде оба процесса стоят за одним обратным прокси (см. README) — здесь
// достаточно относительного пути, свой базовый URL не нужен.

export class ApiError extends Error {
  hint: string;
  constructor(body: ApiErrorBody) {
    super(body.message);
    this.hint = body.hint;
  }
}

async function parseOrThrow<T>(resp: Response): Promise<T> {
  const body = await resp.json();
  if (!resp.ok) {
    throw new ApiError(body as ApiErrorBody);
  }
  return body as T;
}

export async function createAnalysis(
  presentation: File,
  repository: string,
  branch: string,
  files: File[],
  thinking: boolean = false,
  stages: string = "",
): Promise<CreateAnalysisResponse> {
  // Репозиторий и файлы — два независимых необязательных источника evidence,
  // не выбор одного из вариантов (см. backend/pko/web/analyses.py::create_analysis)
  // — можно и репозиторий, и файлы поверх; оба можно оставить пустыми.
  // `thinking` — переключатель режима рассуждения (кнопка в форме), пробрасывается
  // в `get_spec("matcher", thinking=...)` на бэкенде и имеет приоритет над env.
  const form = new FormData();
  form.set("presentation", presentation);
  form.set("repository", repository);
  form.set("branch", branch);
  form.set("thinking", thinking ? "true" : "false");
  // `stages` — этапы клиентского пути, по одному в строке. Пусто — агент
  // берёт их из презентации или собирает по опорной карте; непусто — эти
  // этапы для него обязательны (backend/pko/web/app.py::create_analysis).
  form.set("stages", stages);
  for (const file of files) {
    form.append("files", file);
  }
  const resp = await fetch("/api/analyses", { method: "POST", body: form });
  return parseOrThrow<CreateAnalysisResponse>(resp);
}

export async function getAnalysis(analysisId: string): Promise<Analysis> {
  const resp = await fetch(`/api/analyses/${analysisId}`);
  // ERROR-статус тоже приходит с HTTP 400 (см. web/app.py::get_analysis) —
  // это по-прежнему валидный Analysis, а не ApiError: сама задача найдена и
  // выполнилась, просто с ошибкой пайплайна, а не проблема с запросом.
  const body = await resp.json();
  if (!resp.ok && body.status !== "ERROR") {
    throw new ApiError(body as ApiErrorBody);
  }
  return body as Analysis;
}

"""Скачиваемый HTML-дашборд готовности проекта — отдельная генерация, отдельно
от CLI-отчёта (`progress_report.py` + React-бандл `frontend-app/`, не трогается).

Идея: один самодостаточный HTML-файл (`dashboard_template.html`), который
поведением и видом повторяет «экран 3» веб-приложения
(`frontend-web/src/components/dashboard/`) — те же шевроны с кликом и анимацией
заливки, панель описания выбранного этапа, карточки оценки и общий вывод
агента. Шаблон — статический HTML+CSS+JS без внешних ресурсов; данные агента
подставляются одним JSON-блоком (маркер `/*__DATA__*/`).

Источник данных — тот же контракт, что отдаёт веб-экран 3
(`web/analyses.py::_dashboard_json` → `job.result`): meta, readiness, items[],
summary{}. Передавая в `render_dashboard_html` именно `job.result`, а не
`ProgressModel`, веб-экран и скачиваемый HTML расходятся не могут — один
источник данных, одна подготовка полей (title/description/status/label/color/
pct/points) уже выполнена в `_dashboard_json`.

Безопасность: тексты агента (title/points/description/conclusion/risks/
priorities) вставляются в страницу через `textContent` в шаблоне, а в JSON
предварительно заменяются все `<` на `\u003c` — поэтому даже `</script>` или
разметка в ответе агента не могут выйти за пределы `<script>` с данными и не
инъецируют HTML.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_DASHBOARD_TEMPLATE_PATH = Path(__file__).parent / "dashboard_template.html"

# Маркер в шаблоне, который заменяется на JSON-литерал с данными агента.
# Валидный JS-комментарий → файл остаётся открываемым как заглушка (нет данных
# → window.__DATA__ = ; был бы синтаксической ошибкой, поэтому заменяем весь
# маркер вместе с `/* */`).
_DATA_MARKER = "/*__DATA__*/"


def render_dashboard_html(result: dict[str, Any]) -> str:
    """Собрать самодостаточный HTML-дашборд из контракта `_dashboard_json`.

    `result` — словарь с ключами `meta`, `readiness`, `items`, опционально
    `summary` (тот же вид, что отдаёт `GET /api/analyses/{id}` в статусе READY).
    Никаких путей к файлам/тестов/технических деталей здесь нет — те же поля,
    что рисует веб-экран 3.
    """
    template = _DASHBOARD_TEMPLATE_PATH.read_text(encoding="utf-8")
    data_json = _to_safe_json(result)
    return template.replace(_DATA_MARKER, data_json, 1)


def _to_safe_json(result: dict[str, Any]) -> str:
    """JSON-литерал, безопасный для встраивания в `<script>` HTML-страницы.

    `json.dumps` сам по себе не экранирует `<`/`>` — строка вроде `"</script>"`
    в данных агента досрочно закрыла бы тег `<script>` с данными. Замена `<` на
    `\\u003c` делает литерал безопасным: JS раскрывает последовательность
    обратно в `<`, а в HTML-потоке её нет. `>` экранировать не нужно — без `<>`
    тег не сформировать.
    """
    return json.dumps(result, ensure_ascii=False).replace("<", "\\u003c")

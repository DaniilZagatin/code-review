"""Веб API `pko progress`: асинхронный анализ + живой прогресс по SSE.

Локальный инструмент: сервер поднимается на своей машине, git-доступ — через
уже настроенный SSH-agent (см. README). Логика пайплайна не дублируется с
CLI — обе стороны зовут один и тот же `pko.progress.pipeline.run_progress`,
поэтому веб и `pko progress` не могут разойтись в поведении.

UI — отдельный Next.js-проект `frontend-web/` (свой dev/прод-процесс, ходит
сюда через `/api/*`), этот модуль отдаёт только JSON и SSE, HTML не рендерит и
не раздаёт статику. Реальный прогон может занимать от секунд до ~15 минут
только на клонирование репозитория (`progress/target_repo.py`,
`network_timeout=900`) плюс агентная сессия до 60 шагов, и ждать это за одним
запросом без обратной связи не годится.
"""

from __future__ import annotations

import json
import queue

import anyio
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.requests import Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse

from pko.errors import PkoError
from pko.render.dashboard_html import render_dashboard_html
from pko.llm.registry import get_spec
from pko.llm.tracing import init_phoenix_tracing
from pko.util.env import load_env
from pko.web import analyses

load_env()
init_phoenix_tracing()

app = FastAPI(title="PKO progress")


@app.exception_handler(PkoError)
def _handle_pko_error(request: Request, exc: PkoError) -> JSONResponse:
    # Тот же контракт ошибки, что печатает CLI (`exc.render()`), но в JSON:
    # страница показывает message и hint отдельно, а не голый стек.
    return JSONResponse(status_code=400, content={"message": exc.message, "hint": exc.hint})


# Пауза между шагами реального агента (не скриптованного тестового LLM)
# может доходить до `ChatClient.timeout` (120с, backend/pko/llm/client.py) —
# без периодического события простаивающее HTTP-соединение рискует быть
# закрытым промежуточным прокси/балансировщиком, у которых idle-таймаут
# часто короче. `: ...\n\n` — SSE-комментарий: `EventSource` браузера его
# не отдаёт как `message`, только держит соединение видимо активным.
_HEARTBEAT_SECONDS = 15


def _get_job_or_404(analysis_id: str) -> analyses.AnalysisJob:
    job = analyses.get_job(analysis_id)
    if job is None:
        raise PkoError("Анализ не найден.", hint=f"неизвестный analysis_id: {analysis_id!r}")
    return job


@app.post("/api/analyses")
async def create_analysis(
    presentation: list[UploadFile] = File([]),
    repository: str = Form(""),
    branch: str = Form(""),
    thinking: bool = Form(False),
    stages: str = Form(""),
    files: list[UploadFile] = File([]),
) -> JSONResponse:
    """`repository` и `files` — два независимых необязательных источника
    evidence (см. докстринг `analyses.create_analysis`), не выбор одного из
    вариантов — можно и репозиторий, и файлы поверх (например
    `metrics.json`, которого нет в самом репозитории). Оба пустые — тоже
    валидный запрос: агент получает пустой снимок материалов и сам решает,
    что писать в вердикт.

    `thinking` — переключатель режима рассуждения модели с формы (кнопка в
    `frontend-web/`). Имеет приоритет над env `PKO_THINKING`: явный выбор
    оператора важнее серверного дефолта. Как `get_spec` переводит его в
    `chat_template_kwargs.enable_thinking` — см. `llm/registry.py::get_spec`.

    `stages` — этапы клиентского пути, по одному в строке. Необязательное
    поле: пусто — агент берёт этапы из презентации или собирает по опорной
    карте. Заполнено — эти этапы обязательны для агента и попадают в отчёт в
    авторской редакции, без пересказа моделью.

    `presentation` — образ результата, один файл или несколько: он бывает
    разложен по документам (схема пути отдельно от карточек инициатив).
    Слайды склеиваются в один список со сквозной нумерацией.
    """
    spec = get_spec("matcher", thinking=thinking)
    if spec is None:
        raise PkoError(
            "Не настроен LLM-доступ для пайплайна прогресса.",
            hint="задайте PKO_ASSEMBLER_BASE_URL/PKO_ASSEMBLER_MODEL/PKO_ASSEMBLER_API_KEY "
                 "перед запуском `pko serve` — роль matcher использует его по умолчанию; "
                 "либо настройте PKO_MATCHER_* отдельно.",
        )
    # Общий вывод пишет сам агент (submit_summary) — отдельной роли reporter
    # больше нет. vision нужен только PDF/изображению; для .pptx не используется.
    vision_spec = get_spec("vision")

    # `files=[UploadFile()]` пустышка — Starlette так отдаёт поле, которое
    # клиент вообще не передал в multipart-форме, а не пустой список; отличать
    # её от настоящего файла с пустым именем не нужно — с пустым именем
    # `local_source._safe_relative_path` его всё равно отклонит как файл.
    uploads = [
        (f.filename, await f.read())
        for f in files
        if f.filename
    ]

    # Та же пустышка `UploadFile()` без имени, что и у `files` — Starlette
    # так отдаёт незаполненное поле формы; отфильтровываем по имени, пустой
    # список отклонит `create_analysis` понятной ошибкой.
    presentation_files = [
        (f.filename, await f.read())
        for f in presentation
        if f.filename
    ]

    job = analyses.create_analysis(
        presentation_files=presentation_files,
        repository=repository,
        branch=branch,
        uploads=uploads,
        spec=spec,
        vision_spec=vision_spec,
        stages=stages,
    )
    return JSONResponse({"analysis_id": job.id, "status": job.status})


@app.get("/api/analyses/{analysis_id}/events")
async def stream_analysis_events(analysis_id: str) -> StreamingResponse:
    job = _get_job_or_404(analysis_id)

    async def generate():
        # Задача могла завершиться раньше, чем клиент открыл это соединение
        # (например, `EventSource` браузера переподключается после разрыва
        # сети) — тогда очередь уже пуста и блокирующий `get()` повис бы
        # навсегда. В этом случае сразу отдаём терминальное событие вместо
        # чтения из очереди.
        if job.status != "PROCESSING":
            terminal = {"type": "analysis_ready"} if job.status == "READY" else {"type": "error", **(job.error or {})}
            yield f"data: {json.dumps(terminal, ensure_ascii=False)}\n\n"
            return

        while True:
            # `queue.Queue.get` блокирует поток — уводим в threadpool, чтобы не
            # держать event loop; сама очередь на задачу одна (один подписчик).
            # Таймаут — не для отмены, а чтобы регулярно возвращаться сюда и
            # отдать heartbeat, если реальный агент надолго задумался.
            try:
                event = await anyio.to_thread.run_sync(lambda: job.events.get(timeout=_HEARTBEAT_SECONDS))
            except queue.Empty:
                yield ": keepalive\n\n"
                continue
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
            if event.get("type") in ("analysis_ready", "error"):
                break

    return StreamingResponse(generate(), media_type="text/event-stream")


@app.get("/api/analyses/{analysis_id}")
async def get_analysis(analysis_id: str) -> JSONResponse:
    job = _get_job_or_404(analysis_id)
    if job.status == "PROCESSING":
        return JSONResponse({"status": "PROCESSING"})
    if job.status == "ERROR":
        return JSONResponse(status_code=400, content={"status": "ERROR", **(job.error or {})})
    return JSONResponse({"status": "READY", **(job.result or {})})


@app.get("/api/analyses/{analysis_id}/dashboard.html")
async def get_analysis_dashboard(analysis_id: str) -> HTMLResponse:
    """Самодостаточный HTML-дашборд готовности проекта для скачивания.

    Тот же контракт данных, что у `GET /api/analyses/{id}` в статусе READY
    (`job.result` = `_dashboard_json`), но собранный в один HTML-файл
    (`render/dashboard_html.py` + `dashboard_template.html`). Веб-экран 3 и
    скачиваемый HTML расходятся не могут — один источник.

    Отдаётся inline (`text/html`): открыть URL напрямую — посмотреть,
    фронт-кнопка «Скачать» качает тот же ответ через `<a download>`.
    PROCESSING/ERROR — тот же чистый JSON-ошибке, что у `get_analysis`,
    а не молчаливый пустой HTML.
    """
    job = _get_job_or_404(analysis_id)
    if job.status == "PROCESSING":
        raise PkoError("Анализ ещё не завершён.", hint="дождитесь READY по SSE/GET, затем запросите дашборд")
    if job.status == "ERROR":
        raise PkoError(job.error["message"] if job.error else "Анализ завершился с ошибкой.",
                       hint=(job.error or {}).get("hint", ""))
    return HTMLResponse(render_dashboard_html(job.result or {}))

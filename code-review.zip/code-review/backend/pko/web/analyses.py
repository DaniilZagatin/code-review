"""Асинхронные задачи анализа для живого веб-фронтенда (`frontend-web/`).

Локальный инструмент, один процесс — как и весь `pko serve` (см. докстринг
`web/app.py`). Поэтому реестр задач — обычный `dict` в памяти, выполнение —
`threading.Thread`, обмен событиями прогресса — `queue.Queue`: без
БД/очереди/Redis, ровно тот же принцип простоты, что и у остального PKO.
Задачи не переживают перезапуск сервера — сознательное ограничение, не
случайный пробел.

Один прогон = один `AnalysisJob`. `run_progress` (`progress.pipeline`) уже
умеет сообщать о прогрессе через `on_event` — здесь это событие просто
складывается в очередь задачи, откуда его читает SSE-эндпоинт
(`web/app.py::stream_analysis_events`).
"""

from __future__ import annotations

import queue
import shutil
import tempfile
import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from pko.errors import PkoError
from pko.llm.registry import ModelSpec
from pko.progress.local_source import (
    build_empty_workspace,
    build_target_repo_from_uploads,
    merge_with_uploads,
)
from pko.progress.matcher import parse_stage_titles
from pko.progress.pipeline import run_progress
from pko.progress.schema import ProgressModel
from pko.progress.target_repo import TargetRepo, load_target, open_repo_source

Status = Literal["PROCESSING", "READY", "ERROR"]

# Допустимые форматы плана в веб-форме: PPTX (текстовые фигуры), PDF/изображение
# (рендер + vision-распознавание). См. `pipeline._load_slides`.
_PLAN_SUFFIXES = (".pptx", ".pdf", ".bmp", ".jpeg", ".jpg", ".png", ".tif", ".tiff")

# Сколько файлов принимаем в образе результата. Образ бывает собран из
# нескольких документов (схема пути отдельно от карточек инициатив), но
# десяток — уже не образ результата, а свалка: слайды всех файлов уезжают в
# один промпт целиком, и вместе с ними растёт шанс, что агент выделит этапы
# не из того документа.
MAX_PLAN_FILES = 10


@dataclass
class AnalysisJob:
    id: str
    status: Status = "PROCESSING"
    events: "queue.Queue[dict[str, Any]]" = field(default_factory=queue.Queue)
    result: dict[str, Any] | None = None
    error: dict[str, str] | None = None


_JOBS: dict[str, AnalysisJob] = {}


def get_job(job_id: str) -> AnalysisJob | None:
    return _JOBS.get(job_id)


def _dashboard_json(model: ProgressModel) -> dict[str, Any]:
    """Контракт дашборда — не полный `ProgressModel.to_dict()`.

    Читатель дашборда — первое лицо, не разработчик: пути к материалам,
    `unclaimed` и `gaps` сюда осознанно не попадают.

    Форму задаёт шаблон (`render/dashboard_template.html`) и его описание.
    Процент и цвет этапа мы не передаём: их считает сам шаблон по применимым
    буллитам — так цифра на карточке не может разойтись с тем, что под ней
    нарисовано. От нас идут только тексты (дословно из образа результата) и
    отметки применимости со статусами.
    """
    items = []
    for verdict in model.verdicts:
        item = model.items.get(verdict.item_id)
        if item is None:
            continue
        assessment = []
        for text, criterion in zip(item.criteria, verdict.criteria):
            row: dict[str, Any] = {"text": text}
            # `applicable` и `status` передаются только у относящихся к
            # инициативе пунктов: шаблон трактует отсутствие поля как «серый,
            # в расчёт не входит», и искусственный статус чужому пункту
            # выставлять нельзя.
            if criterion.applicable:
                row["applicable"] = True
                row["status"] = criterion.status
            assessment.append(row)
        stage: dict[str, Any] = {
            "title": item.title,
            "description": item.description,
            "assessment": assessment,
        }
        if verdict.applicable:
            stage["applicable"] = True
        items.append(stage)

    meta = dict(model.meta)
    if model.summary is not None:
        meta["decision"] = model.summary.decision

    result: dict[str, Any] = {
        "meta": meta,
        # Готовность — самостоятельная оценка модели, а не среднее по этапам:
        # критичность отдельного разрыва арифметика не выражает. Шаблон её не
        # пересчитывает, только рисует.
        "readiness": model.readiness,
        "items": items,
    }
    if model.summary is not None:
        summary = model.summary.to_dict()
        # `decision` уехал в meta — шаблон читает его оттуда.
        summary.pop("decision", None)
        result["summary"] = summary
    return result


def create_analysis(
    presentation_files: list[tuple[str, bytes]],
    repository: str,
    branch: str,
    uploads: list[tuple[str, bytes]],
    spec: ModelSpec,
    vision_spec: ModelSpec | None = None,
    stages: list[str] | None = None,
) -> AnalysisJob:
    """Провалидировать вход, создать задачу и сразу запустить её в фоне.

    `repository` и `uploads` — два независимых необязательных источника
    evidence, не выбор одного из вариантов: репозиторий даёт код, файлы —
    то, что в него не попало (результат эксперимента, отчёт, метрики).
    Заполнены оба сразу — `_execute` объединяет их в один workspace
    (`progress/local_source.py::merge_with_uploads`). Не заполнен ни
    один — это НЕ ошибка запроса: агент всё равно запускается, просто видит
    пустой снимок материалов (`local_source.build_empty_workspace`) и сам
    решает, что писать в вердикт — тем же путём, что и «в репозитории
    ничего не нашлось» (см. `agent_system.md` рядом с `matcher.py`).

    `stages` — этапы клиентского пути, заданные человеком в форме. Третий
    источник этапов рядом с двумя прежними (названы в презентации / собраны
    агентом по опорной карте): человек знает путь своего продукта лучше, чем
    его знает слайд, на котором ряда этапов может просто не быть. Заданные
    этапы обязательны для агента — он не может их переименовать, переставить
    или дополнить.

    `presentation_files` — образ результата: один файл или несколько. Несколько
    нужны, когда образ разложен по документам (схема клиентского пути отдельно
    от карточек инициатив): слайды склеиваются в один список со сквозной
    нумерацией, имя файла видно агенту в тексте каждого слайда.

    Валидация файлов образа результата и этапов падает сразу в ответе на
    `POST`, до создания задачи и потока, а не всплывает позже как молчаливо
    зависшая задача.
    """
    if not presentation_files:
        raise PkoError(
            "Не приложен образ результата.",
            hint="нужен хотя бы один файл .pptx, .pdf или изображение (PNG/JPEG/TIFF/BMP)",
        )
    if len(presentation_files) > MAX_PLAN_FILES:
        raise PkoError(
            f"Слишком много файлов образа результата: {len(presentation_files)}.",
            hint=f"принимаем не больше {MAX_PLAN_FILES} — оставьте те, где описан "
                 "клиентский путь и инициативы",
        )
    for filename, _ in presentation_files:
        if not filename or not filename.lower().endswith(_PLAN_SUFFIXES):
            raise PkoError(
                "Образ результата должен быть .pptx, .pdf или изображением (PNG/JPEG/TIFF/BMP).",
                hint=f"получено имя файла: {filename!r}",
            )

    stage_titles = parse_stage_titles(stages)

    job = AnalysisJob(id="an_" + uuid.uuid4().hex[:12])
    _JOBS[job.id] = job

    tmp_dir = Path(tempfile.mkdtemp(prefix=f"pko-analysis-{job.id}-"))
    plan_dir = tmp_dir / "plan"
    plan_dir.mkdir()
    plan_paths: list[Path] = []
    for index, (filename, data) in enumerate(presentation_files, start=1):
        # Имена от клиента могут совпасть между собой — раскладываем по
        # порядковому префиксу, иначе второй файл затёр бы первый. Порядок
        # префикса заодно фиксирует порядок слайдов в промпте.
        path = plan_dir / f"{index:02d}-{Path(filename).name}"
        path.write_bytes(data)
        plan_paths.append(path)

    thread = threading.Thread(
        target=_execute,
        args=(job, plan_paths, repository.strip(), branch.strip() or None, uploads, tmp_dir,
              spec, vision_spec, stage_titles),
        daemon=True,
    )
    thread.start()
    return job


def _build_target(
    repository: str, branch: str | None, uploads: list[tuple[str, bytes]], workspace_dir: Path,
    emit,
) -> tuple[TargetRepo, str]:
    """Git, файлы, или оба сразу — см. докстринг `create_analysis`."""
    target: TargetRepo | None = None
    name = ""
    if repository:
        emit("phase", {"phase": "materials_loading", "label": "Подключаем репозиторий"})
        git_repo, name = open_repo_source(repository, branch=branch)
        target = load_target(git_repo, branch)
    else:
        emit("phase", {"phase": "materials_loading", "label": "Обрабатываем загруженные файлы"})

    if uploads:
        target = (
            merge_with_uploads(target, uploads, workspace_dir) if target is not None
            else build_target_repo_from_uploads(uploads, workspace_dir)
        )
    elif target is None:
        # Ни репозитория, ни файлов — см. докстринг create_analysis: не
        # ошибка, агент получает пустой снимок и сам решает, что с этим делать.
        target = build_empty_workspace(workspace_dir)
    emit("phase", {"phase": "materials_ready", "label": "Материалы проекта готовы"})
    return target, name


def _execute(
    job: AnalysisJob,
    plan_paths: list[Path],
    repository: str,
    branch: str | None,
    uploads: list[tuple[str, bytes]],
    tmp_dir: Path,
    spec: ModelSpec,
    vision_spec: ModelSpec | None = None,
    stages: list[str] | None = None,
) -> None:
    def emit(kind: str, data: dict[str, Any]) -> None:
        job.events.put({"type": kind, **data})

    try:
        target, name = _build_target(repository, branch, uploads, tmp_dir / "workspace", emit)
        model = run_progress(plan_paths, name, target, spec,
                             on_event=emit, vision_spec=vision_spec, stages=stages)

        job.result = _dashboard_json(model)
        job.status = "READY"
        job.events.put({"type": "analysis_ready"})
    except PkoError as exc:
        job.error = {"message": exc.message, "hint": exc.hint}
        job.status = "ERROR"
        job.events.put({"type": "error", **job.error})
    except Exception as exc:  # noqa: BLE001 — граница фонового потока: без этого
        # необработанное исключение молча оседает в потоке (traceback только в
        # stderr процесса), а SSE-клиент завис бы навсегда без единого
        # терминального события. Дальше по стеку это не поймать — здесь конец пути.
        job.error = {"message": "Внутренняя ошибка анализа.", "hint": str(exc)}
        job.status = "ERROR"
        job.events.put({"type": "error", **job.error})
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

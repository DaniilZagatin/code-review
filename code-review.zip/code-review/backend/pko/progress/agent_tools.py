"""Инструменты единого агента: read-only доступ к коду и контексту программы.

Пять инструментов — `list_files`, `read_file`, `search`, `show_facts` и
`lookup_ai_efficiency` — и ничего больше: нет ни bash, ни write-операций, поэтому набор инструментов
физически не может изменить репозиторий, только прочитать его на
зафиксированном коммите. Секреты (`*_key`/`*_token`/`*_secret`/`*_password`)
маскируются в выдаче, `.env*`/`*.pem`/`*.key` не читаются вовсе. Текст слайдов
презентации агент получает upfront первым user-сообщением и здесь не
дублируется.

`show_facts` отдаёт уже разобранные экстракторами факты (ROUTE, TOOL,
SQL_WRITE, TEST и т.п.) — агент не парсит AST заново, а берёт готовые
сигнатуры с line/kind/name для evidence. `search` поддерживает контекст строк
вокруг совпадения (before/after), чтобы видеть декоратор/сигнатуру рядом с
именем без второго вызова `read_file`.
"""

from __future__ import annotations

import fnmatch
import re
import time
from dataclasses import dataclass
from typing import Any

from pko.extractors.base import Tree, is_vendor
from pko.extractors.runner import Extraction
from pko.progress.program_reference import lookup_program_context

MAX_LIST_FILES = 400
MAX_READ_LINES = 400
SEARCH_MAX_MATCHES = 200
SEARCH_TIMEOUT_SECONDS = 5.0
MAX_SEARCH_LINE_CHARS = 2000
MAX_SEARCH_CONTEXT = 20
FACTS_MAX_ROWS = 200

_BLOCKED_NAME_PREFIXES = (".env",)
_BLOCKED_NAME_SUFFIXES = (".pem", ".key")

_SECRET_ASSIGNMENT = re.compile(
    r"(?i)(\b\w*(?:key|token|secret|password)\w*\s*[:=]\s*)([\"']?)([^\s\"']{4,})\2"
)

# Грубая, но дешёвая проверка на классический ReDoS-паттерн: повторяющаяся
# группа, внутри которой уже есть свой повтор — "(a+)+", "(\w*)+" и т.п.
_CATASTROPHIC_SHAPE = re.compile(r"\([^()]*[+*?][^()]*\)[+*]")

# Нативные OpenAI-совместимые схемы тулов (`tools=[...]` в запросе) — один в
# один повторяют сигнатуры и дефолты методов `ToolBox` ниже.
TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "Список файлов репозитория на этом коммите (vendor-каталоги скрыты).",
            "parameters": {
                "type": "object",
                "properties": {
                    "glob": {"type": "string", "description": "Шаблон имени файла или пути, например *.py", "default": "*"},
                    "offset": {"type": "integer", "description": "С какого файла продолжить (постранично)", "default": 1},
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Содержимое файла построчно, с номерами строк. Секреты маскируются, .env/.pem/.key не читаются.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Путь к файлу, как он вернулся из list_files/search"},
                    "offset": {"type": "integer", "description": "Строка, с которой начать", "default": 1},
                    "limit": {"type": "integer", "description": f"Сколько строк вернуть (не больше {MAX_READ_LINES})", "default": MAX_READ_LINES},
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search",
            "description": (
                "Regex-поиск по файлам репозитория на этом коммите. "
                f"before/after показывают строки вокруг совпадения (до {MAX_SEARCH_CONTEXT}), "
                "чтобы видеть декоратор/сигнатуру рядом с именем без отдельного read_file."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {"type": "string", "description": "Регулярное выражение для поиска"},
                    "glob": {"type": "string", "description": "Ограничить поиск файлами по шаблону", "default": "*"},
                    "before": {"type": "integer", "description": "Сколько строк показать до совпадения", "default": 0},
                    "after": {"type": "integer", "description": "Сколько строк показать после совпадения", "default": 0},
                    "offset": {"type": "integer", "description": "С какого совпадения продолжить (постранично)", "default": 1},
                },
                "required": ["pattern"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "show_facts",
            "description": (
                "Уже разобранные факты кода (ROUTE/TOOL/SQL_WRITE/TEST/GRAPH_NODE и др.) — "
                "готовые сигнатуры с kind, path, line, key/value. Не парсит AST заново: "
                "берёт результаты детерминированных экстракторов. Фильтр по path (glob) "
                "и/или kind. Полезно для evidence: факт уже содержит line+kind+name."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Шаблон пути (glob), например backend/src/*.py", "default": "*"},
                    "kind": {"type": "string", "description": "Только факты этого вида (ROUTE, TOOL, SQL_WRITE, TEST, GRAPH_NODE, SETTING, LIMIT, EXTERNAL, LLM_CALL, MODULE, OWNER, TEST_REPORT и др.)"},
                    "offset": {"type": "integer", "description": "С какого факта продолжить (постранично)", "default": 1},
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "lookup_ai_efficiency",
            "description": (
                "Найти инициативу и клиентский путь в срезе программы AI-эффективность. "
                "Возвращает заявленные командой сроки, эффекты, ресурс, статус демо и "
                "целевую карточку пути. Это плановый контекст для факт-чекинга, а не "
                "доказательство реализации. Ищи по названию, коду АГ/П/CROSSGOAL или пути."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Название инициативы, агента, клиентского пути или программный код"},
                    "limit": {"type": "integer", "description": "Число наиболее близких совпадений, 1-5", "default": 3},
                },
                "required": ["query"],
            },
        },
    },
]


@dataclass
class ToolResult:
    ok: bool
    content: str
    meta: dict[str, Any]


class ToolBox:
    """Инструменты над `Tree` и `Extraction` — снимком репозитория на коммите."""

    def __init__(self, tree: Tree, extraction: Extraction | None = None):
        self.tree = tree
        self._files = [p for p in tree.files if not is_vendor(p)]
        self._extraction = extraction

    def call(self, name: str, args: dict[str, Any] | None) -> ToolResult:
        args = args if isinstance(args, dict) else {}
        if name == "list_files":
            return self.list_files(glob=str(args.get("glob") or "*"), offset=_as_int(args.get("offset"), 1))
        if name == "read_file":
            return self.read_file(
                path=str(args.get("path") or ""),
                offset=_as_int(args.get("offset"), 1),
                limit=_as_int(args.get("limit"), MAX_READ_LINES),
            )
        if name == "search":
            return self.search(
                pattern=str(args.get("pattern") or ""),
                glob=str(args.get("glob") or "*"),
                before=_as_int(args.get("before"), 0),
                after=_as_int(args.get("after"), 0),
                offset=_as_int(args.get("offset"), 1),
            )
        if name == "show_facts":
            return self.show_facts(
                path=str(args.get("path") or "*"),
                kind=str(args.get("kind") or ""),
                offset=_as_int(args.get("offset"), 1),
            )
        if name == "lookup_ai_efficiency":
            return self.lookup_ai_efficiency(
                query=str(args.get("query") or ""),
                limit=_as_int(args.get("limit"), 3),
            )
        return ToolResult(False, f"неизвестный инструмент: {name!r}. Доступны: list_files, read_file, search, show_facts, lookup_ai_efficiency", {})

    def list_files(self, glob: str = "*", offset: int = 1) -> ToolResult:
        matched = _glob_filter(self._files, glob)
        page, has_more = _paginate(matched, offset, MAX_LIST_FILES)
        content = "\n".join(page) if page else "(ничего не найдено)"
        if has_more:
            content += f"\n... есть ещё файлы, offset={offset + MAX_LIST_FILES} для продолжения"
        return ToolResult(True, content, {"count": len(page), "total": len(matched)})

    def read_file(self, path: str, offset: int = 1, limit: int = MAX_READ_LINES) -> ToolResult:
        path = path.strip()
        if path not in self._files:
            return ToolResult(False, f"файл не найден на этом коммите: {path}", {})
        if _is_blocked(path):
            return ToolResult(False, f"чтение файла запрещено (похоже на секрет): {path}", {})
        text = self.tree.read(path)
        if text is None:
            return ToolResult(False, f"файл не читается: {path}", {})

        lines = text.splitlines()
        limit = max(1, min(limit, MAX_READ_LINES))
        offset = max(1, offset)
        window = lines[offset - 1: offset - 1 + limit]
        if not window:
            return ToolResult(True, "(пусто или offset за пределами файла)", {"total_lines": len(lines)})
        numbered = "\n".join(
            f"{i}: {_mask_secrets(line)}" for i, line in enumerate(window, start=offset)
        )
        if offset - 1 + limit < len(lines):
            numbered += f"\n... есть ещё строки (всего {len(lines)}), offset={offset + limit} для продолжения"
        return ToolResult(True, numbered, {"total_lines": len(lines)})

    def search(
        self, pattern: str, glob: str = "*",
        before: int = 0, after: int = 0, offset: int = 1,
    ) -> ToolResult:
        """Regex-поиск с опциональным контекстом строк вокруг совпадения.

        `before`/`after` — сколько строк показать до/после совпадения. Без
        контекста (0/0) выдача — построчная `path:i: text`, как раньше. С
        контекстом — блочная: каждое совпадение группой с номерами строк,
        чтобы видеть декоратор/сигнатуру рядом без отдельного `read_file`.
        """
        pattern = pattern.strip()
        if not pattern:
            return ToolResult(False, "пустой паттерн поиска", {})
        try:
            compiled = re.compile(pattern)
        except re.error as exc:
            return ToolResult(False, f"некорректный regex: {exc}", {})
        if _CATASTROPHIC_SHAPE.search(pattern):
            return ToolResult(
                False,
                "паттерн похож на катастрофический backtracking (вложенный повтор внутри "
                "повторяющейся группы) — упростите regex",
                {},
            )

        before = max(0, min(before, MAX_SEARCH_CONTEXT))
        after = max(0, min(after, MAX_SEARCH_CONTEXT))

        matched_files = _glob_filter(self._files, glob)
        blocks: list[str] = []
        deadline = time.monotonic() + SEARCH_TIMEOUT_SECONDS
        truncated = False
        for path in matched_files:
            if time.monotonic() > deadline:
                truncated = True
                break
            text = self.tree.read(path)
            if text is None:
                continue
            lines = text.splitlines()
            for i, line in enumerate(lines, start=1):
                if len(line) > MAX_SEARCH_LINE_CHARS:
                    continue
                if compiled.search(line):
                    blocks.append(_format_match(path, i, lines, before, after))
                    if len(blocks) >= SEARCH_MAX_MATCHES * 4:
                        truncated = True
                        break
            if truncated:
                break

        page, has_more = _paginate(blocks, offset, SEARCH_MAX_MATCHES)
        content = "\n\n".join(page) if page else "(совпадений нет)"
        if has_more:
            content += f"\n\n... есть ещё совпадения, offset={offset + SEARCH_MAX_MATCHES} для продолжения"
        if truncated:
            content += "\n(поиск остановлен раньше срока — сузьте паттерн или glob)"
        return ToolResult(True, content, {"count": len(page)})

    def show_facts(self, path: str = "*", kind: str = "", offset: int = 1) -> ToolResult:
        """Готовые факты из экстракторов — без повторного парсинга кода агентом.

        Фильтр по `path` (glob) и `kind`. Выдача: `kind | path:line | key=value`
        построчно. Пагинация по `offset`. Без экстракции (ToolBox без extraction)
        возвращает понятное «нет данных», не ошибку.
        """
        if self._extraction is None or not self._extraction.facts:
            return ToolResult(True, "(факты недоступны — экстракция не выполнялась)", {"count": 0, "total": 0})

        facts = self._extraction.facts
        if kind:
            kind_norm = kind.strip().upper()
            facts = [f for f in facts if f.kind == kind_norm]
        if path and path != "*":
            facts = [f for f in facts if _glob_match(f.path, path)]

        rows: list[str] = []
        for f in facts:
            loc = f"{f.path}:{f.line}" if f.line else f.path
            value_str = _format_fact_value(f.value)
            row = f"{f.kind} | {loc} | {f.key}"
            if value_str:
                row += f" = {value_str}"
            rows.append(row)

        page, has_more = _paginate(rows, offset, FACTS_MAX_ROWS)
        content = "\n".join(page) if page else "(фактов по фильтру нет)"
        if has_more:
            content += f"\n... есть ещё факты, offset={offset + FACTS_MAX_ROWS} для продолжения"
        return ToolResult(True, content, {"count": len(page), "total": len(rows)})

    def lookup_ai_efficiency(self, query: str, limit: int = 3) -> ToolResult:
        """Relevant programme records without loading the full portfolio into context."""
        query = " ".join(query.split())
        if not query:
            return ToolResult(False, "нужно название инициативы, пути или программный код", {})
        content, count = lookup_program_context(query, limit=limit)
        return ToolResult(True, content, {"count": count, "query": query})


def _format_match(path: str, line_no: int, lines: list[str], before: int, after: int) -> str:
    """Блок совпадения: при контексте — группа с номерами строк, иначе одна строка."""
    if before == 0 and after == 0:
        return f"{path}:{line_no}: {_mask_secrets(lines[line_no - 1].strip())[:200]}"

    start = max(1, line_no - before)
    end = min(len(lines), line_no + after)
    header = f"─── {path}:{start}-{end} (совпадение на {line_no}) ───"
    body = "\n".join(
        f"{i}: {_mask_secrets(lines[i - 1])}"
        for i in range(start, end + 1)
    )
    return header + "\n" + body


def _format_fact_value(value: Any) -> str:
    """Компактное строковое представление значения факта для выдачи."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value[:120]
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)[:120]
    return str(value)[:120]


def _as_int(value: Any, default: int) -> int:
    try:
        return int(value) if value is not None else default
    except (TypeError, ValueError):
        return default


def _glob_filter(paths: list[str], pattern: str) -> list[str]:
    if pattern in ("", "*"):
        return paths
    return [p for p in paths if _glob_match(p, pattern)]


def _glob_match(path: str, pattern: str) -> bool:
    if pattern in ("", "*"):
        return True
    return (
        fnmatch.fnmatch(path, pattern)
        or fnmatch.fnmatch(path.rsplit("/", 1)[-1], pattern)
    )


def _paginate(items: list[Any], offset: int, limit: int) -> tuple[list[Any], bool]:
    offset = max(1, offset)
    start = offset - 1
    page = items[start: start + limit]
    return page, start + limit < len(items)


def _is_blocked(path: str) -> bool:
    base = path.rsplit("/", 1)[-1].lower()
    return base.startswith(_BLOCKED_NAME_PREFIXES) or base.endswith(_BLOCKED_NAME_SUFFIXES)


def _mask_secrets(text: str) -> str:
    return _SECRET_ASSIGNMENT.sub(lambda m: f"{m.group(1)}{m.group(2)}***{m.group(2)}", text)

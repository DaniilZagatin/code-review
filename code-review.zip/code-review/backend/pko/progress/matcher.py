"""Единый агент: составляет карту клиентского пути, проходит её по этапам и
пишет общий вывод — одна сессия, одна личность.

Работа идёт в три фазы:
  1. ПЛАН — агент читает слайды и вызывает `submit_plan`: кто клиент, какую
     задачу он решает, и список всех этапов пути. Этапы приходят из одного из
     трёх источников (`PlanItem.origin`): названы в презентации (`slide`),
     заданы человеком при загрузке материалов (`user`) или восстановлены
     агентом по опорной карте, если ни того, ни другого не было (`restored`).
     Код проверяет каждый этап и принимает план целиком; только после этого
     разблокируется `submit_stage`.
  2. ОБХОД — по каждому этапу агент инструментами `list_files`/`read_file`/
     `search` собирает факты и вызывает `submit_stage` — один вызов на этап.
  3. ОБЩИЙ ВЫВОД — `submit_summary` (conclusion/risks/priorities), затем `finish`.

Почему один вызов на этап, а не два. Раньше было `submit_findings` (техническая
анкета: режим, объекты стандарта, evidence) → `submit_business_verdict`
(бизнес-текст «на основе анкеты»). Гарантии это давало те же, но текст для
руководителя рождался как пересказ только что выписанной технической находки:
в ближайшем контексте модели лежали пути к файлам и имена функций, и любая
формулировка сползала в «реализован эндпоинт» / «модуль не подключён». Теперь
вызов один, а поля объявлены в схеме бизнесом вперёд (`stage_summary`,
`capabilities`, и только потом `evidence` и классификация стандарта): факты
по-прежнему собираются инструментами до вызова, но формулируется сначала
возможность, а подтверждение выкладывается под неё.

Единица вердикта тоже другая. Вместо буллетов «сделано/частично/не сделано»
(`VerdictPoint`) — `StageCapability`: что клиент или бизнес может делать на
этапе, кто это фактически выполняет и в каких границах. Шкала
`AVAILABLE/LIMITED/NOT_AVAILABLE` вместо `DONE/PARTIAL/NOT_STARTED` — не
переименование, а смена вопроса: «что доступно» вместо «что сделано». Контракт
дашборда при этом не менялся — перевод в `assessment` делает
`render/progress_report.py::capability_rows`.

Список возможностей этапа собирается из двух источников сразу: презентация
даёт обещанное клиенту (в том числе то, чего в материалах нет и следа),
материалы — то, что продукт уже даёт (в том числе то, чего на слайде не было).
Отметку `availability` расставляют материалы: обещанное и найденное —
`AVAILABLE`/`LIMITED`, обещанное и не найденное — `NOT_AVAILABLE`, а не
пропуск. Правило живёт в промпте (`agent_system.md`, шаг 2) и кодом не
проверяется: сверить «все ли обещания этапа закрыты» можно было бы только
против явного списка обещаний, а его агент не отправляет.

Ни одна evidence-ссылка не публикуется без проверки: `progress.verify.verify_evidence`
подтверждает её структурно (путь и строка существуют на этом коммите, рядом —
слово из основания). Неподтверждённая ссылка не отбрасывается — остаётся в
отчёте с `verified=False` и причиной, а вердикт `DONE`/`PARTIAL` без единой
подтверждённой ссылки явно помечается негrounded (`ItemVerdict.is_grounded`),
а не тихо принимается на слово агента.

Свободный текст проходит два сторожа, а не один. `report.guard.check_explanation`
ловит выдуманные пути (как и раньше), `report.guard.check_business_language` —
техническую лексику, которой сторож путей не видел вовсе: «Не реализована
интеграция скоринга» не содержит ни одного пути и раньше проходило насквозь.
Нарушение отклоняет вызов с объяснением, и агент переформулирует; после
`_MAX_LANGUAGE_STRIKES` неудачных попыток вердикт всё же принимается, но
нарушившее поле заменяется пометкой — вердикт не теряется из-за языка.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Callable

from pko.errors import LlmError, PkoError
from pko.extractors.base import Tree
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import trace_span
from pko.progress.agent_tools import TOOL_SCHEMAS as REPO_TOOL_SCHEMAS, ToolBox
from pko.progress.pptx_reader import Slide, render_slide
from pko.progress.schema import (
    AVAILABILITY,
    COMPLETION_STATUSES,
    EXECUTION_MODES,
    EXECUTION_TYPES,
    STANDARD_OBJECT_KINDS,
    STATUSES,
    WHO_ACTS,
    EvidenceRef,
    ItemVerdict,
    PlanItem,
    ProjectSummary,
    StageCapability,
    StandardObject,
    UnclaimedGroup,
)
from pko.progress.verify import verify_evidence
from pko.report.guard import (
    check_business_language,
    check_explanation,
    check_summary_text,
    has_business_subject,
    is_restatement,
)

# Системный промпт собирается из трёх редактируемых Markdown-файлов рядом с
# этим модулем: протокол сессии, язык отчёта, стандарт автономных процессов.
# Раньше правила языка лежали в корне репозитория и грузились по `parents[3]`
# — файла там не оказалось, `OSError` глушился, и весь языковой блок молча не
# попадал в промпт. Отсюда два решения: все части лежат рядом с кодом, который
# их читает, и пропажа любой из них видна в `notes` прогона, а не растворяется
# в тишине.
_PROMPT_PARTS = ("agent_system.md", "business_language.md", "standard_reference.md")
_PROMPT_DIR = Path(__file__).parent


def load_system_prompt() -> tuple[str, list[str]]:
    """Системный промпт и список ненайденных частей.

    Отсутствие части не роняет прогон (агент работает на том, что есть), но
    попадает в `notes` — читатель отчёта должен видеть, что правила языка или
    справочник стандарта до модели не дошли."""
    parts: list[str] = []
    missing: list[str] = []
    for name in _PROMPT_PARTS:
        try:
            parts.append((_PROMPT_DIR / name).read_text(encoding="utf-8"))
        except OSError:
            missing.append(name)
    if not parts:
        parts.append("Ты — агент, который разбирает план команды из презентации "
                     "и сопоставляет его с материалами проекта.")
    return "\n\n---\n\n".join(parts), missing


# Этапы, заданные человеком при загрузке материалов. Верхняя граница — не
# вкус: ряд пазлов на дашборде при большем числе становится нечитаемым, а
# сам агент по опорной карте держится в 4-7. Длина названия ограничена по
# той же причине — оно должно помещаться в пазл.
MAX_USER_STAGES = 12
MAX_USER_STAGE_CHARS = 60


def parse_stage_titles(raw: "str | list[str] | None") -> list[str]:
    """Список названий этапов из пользовательского ввода.

    Принимает и текст (одно название в строке — так его вводят в форме), и
    готовый список (так его передаёт CLI). Пустые строки отбрасываются,
    пробелы схлопываются. Пустой ввод — это не ошибка, а «этапы не заданы»:
    тогда агент берёт их со слайдов или из опорной карты, как и раньше.

    Ошибки ввода поднимаются здесь, а не после запуска анализа: человек
    должен увидеть их в ответе на отправку формы, а не через минуту в
    зависшей задаче.
    """
    if raw is None:
        return []
    lines = raw.splitlines() if isinstance(raw, str) else list(raw)
    titles = [" ".join(str(line).split()) for line in lines]
    titles = [t for t in titles if t]
    if len(titles) > MAX_USER_STAGES:
        raise PkoError(
            f"Слишком много этапов клиентского пути: {len(titles)}.",
            hint=f"оставьте не больше {MAX_USER_STAGES} — иначе ряд этапов на "
                 "дашборде не читается; объедините мелкие вехи в одну",
        )
    too_long = [t for t in titles if len(t) > MAX_USER_STAGE_CHARS]
    if too_long:
        raise PkoError(
            f"Название этапа длиннее {MAX_USER_STAGE_CHARS} символов: «{too_long[0]}».",
            hint="этап подписывается внутри пазла на дашборде — нужно 2-4 слова",
        )
    return titles


def _same_title(left: str, right: str) -> bool:
    """Сравнение названий этапов без учёта регистра и лишних пробелов."""
    return " ".join(left.split()).casefold() == " ".join(right.split()).casefold()


# Бюджет шагов агента на всю сессию (составление плана + обход всех этапов),
# не на один этап: этапов в плане обычно немного (4-7), но заранее их число
# неизвестно — агент сам решает, когда закончить. Крутится снаружи
# (`run_progress(..., max_steps=...)` / `--max-steps`).
DEFAULT_MAX_STEPS = 60

# Бюджет ответа для агентского цикла. Thinking-режим съедает значительную
# часть max_tokens в reasoning_content — ему нужен больший budget, иначе
# content приходит пустым («пустой ответ»). Без thinking 2000 достаточно:
# агент отвечает tool_calls, а не длинным текстом.
MAX_TOKENS_DEFAULT = 2000
MAX_TOKENS_THINKING = 8192

_SUBMIT_PLAN_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_plan",
        "description": "Карта клиентского пути целиком — обязательный первый вызов сессии: "
                       "пока план не принят, submit_stage отклоняется. Сначала назови, КТО "
                       "клиент и какую свою задачу он решает, и только потом перечисляй этапы "
                       "— путь принадлежит клиенту, а не системе. Пункт плана = один "
                       "бизнес-этап пути целиком («Первичный контакт», «Оформление»), НЕ "
                       "техническая подзадача. Заглушки «tbd»/«…»/пустые шевроны пропускай. "
                       "Если этапы заданы заказчиком во входных данных — верни ровно их, в том "
                       "же порядке и с теми же названиями. Иначе бери их со слайда; а если "
                       "явных этапов на слайде нет — собери путь по опорной карте клиентского "
                       "пути из справочника и поставь таким этапам source_slide: 0. Этапов "
                       "4-7. Повторный вызов заменяет весь план.",
        "parameters": {
            "type": "object",
            "properties": {
                "project_title": {"type": "string", "description": "краткое название проекта, 2-4 слова: только суть, без префиксов «Образ результата:»/«Roadmap:». Например «Клиентский путь», «Редизайн платёжного сервиса»."},
                "client": {"type": "string", "description": "кто клиент этого продукта — одной фразой, бизнес-языком («заёмщик по ипотеке», «менеджер отделения»)"},
                "client_goal": {"type": "string", "description": "какую свою задачу клиент решает — одним предложением, его словами, не терминами системы"},
                "project_summary": {"type": "string", "description": "о чём проект и зачем он нужен — 1-2 предложения до 30 слов. Это подзаголовок отчёта под названием проекта, его читают первым: не пересказ названия и не перечень этапов, а суть — какую задачу бизнеса проект закрывает и что меняется, когда он заработает. Например: «Ипотека оформляется целиком онлайн: клиент доходит от заявки до сделки, не приходя в отделение, а банк снимает нагрузку с офисов»."},
                "items": {
                    "type": "array",
                    "description": "этапы клиентского пути по порядку прохождения (на слайде — слева направо)",
                    "items": {
                        "type": "object",
                        "properties": {
                            "item_id": {"type": "string", "description": "короткий устойчивый идентификатор латиницей/цифрами/дефисами"},
                            "title": {"type": "string", "description": "бизнес-название этапа пути, не техническое. КОРОТКОЕ: 2-4 слова, ≤ 24 символов — помещается в пазл дашборда"},
                            "stage": {"type": "string", "description": "этап/спринт, если указан на слайде"},
                            "description": {"type": "string", "description": "что происходит на этапе с точки зрения клиента — одно предложение бизнес-языком"},
                            "source_slide": {"type": "integer", "description": "номер слайда, где назван этап — только реально существующий во входе; 0 — этап восстановлен по опорной карте, а не назван в презентации"},
                        },
                        "required": ["item_id", "title", "source_slide"],
                    },
                },
            },
            "required": ["project_title", "client", "project_summary", "items"],
        },
    },
}

_SUBMIT_STAGE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_stage",
        "description": "Вердикт по одному этапу клиентского пути — ОДИН вызов на этап, после "
                       "того как ты собрал факты инструментами. Заполняй поля в порядке схемы: "
                       "сначала что этап даёт клиенту (stage_summary, capabilities), потом чем "
                       "это подтверждается (evidence) и служебная классификация стандарта. "
                       "Порядок не формальность: формулируй возможность, а потом выкладывай под "
                       "неё подтверждение, а не пересказывай находку бизнес-словами. "
                       "capabilities — 1-5 бизнес-возможностей: что клиент или бизнес МОЖЕТ "
                       "делать на этапе, кто это фактически выполняет и в каких границах. "
                       "Список собирается из двух источников сразу: что этап обещает клиенту по "
                       "презентации (даже если в материалах этого нет) и что продукт уже даёт "
                       "(даже если на слайде этого не было). Обещанную, но не найденную "
                       "возможность отправляй с NOT_AVAILABLE — молча пропускать её нельзя. Без "
                       "путей к файлам, имён функций, слов «код», «тест», «модуль», "
                       "«реализовано». progress не заполняй — его считает код по режиму "
                       "исполнения. Повторный вызов с тем же item_id заменяет предыдущий вердикт.",
        "parameters": {
            "type": "object",
            "properties": {
                "item_id": {"type": "string", "description": "идентификатор этапа из принятого плана"},
                "stage_summary": {
                    "type": "string",
                    "description": "что этап значит для клиента в целевой картине — ОДНО предложение, настоящее время, без оценки готовности. Например: «Клиент подаёт заявку на ипотеку полностью онлайн, без визита в отделение».",
                },
                "capabilities": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 5,
                    "description": "бизнес-возможности этапа, 1-5 штук. Одна возможность — одна "
                                   "мысль. Формулировку даёт задуманное (презентация + то, что "
                                   "продукт уже умеет), отметку доступности — материалы проекта.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "capability": {
                                "type": "string",
                                "description": "что клиент или бизнес получает на этом этапе, 4-16 слов. Речь о людях и результате, а не об устройстве системы: подлежащим не может быть компонент системы. Формулируй так, чтобы фраза осталась верной, даже если всю реализацию перепишут на другой технологии. НЕ начинай все возможности одного этапа одинаково — можно от действующего лица («Агент собирает и проверяет комплект документов»), можно от результата («Решение по заявке приходит в тот же день»), можно от ситуации («В сложных случаях клиент попадает к специалисту, не пересказывая всё заново»).",
                            },
                            "availability": {
                                "type": "string", "enum": list(AVAILABILITY),
                                "description": "ставится по материалам проекта, а не по замыслу: AVAILABLE — возможность работает и подтверждение найдено; LIMITED — работает, но в границах; NOT_AVAILABLE — обещана, но подтверждения нет",
                            },
                            "who_acts": {
                                "type": "string", "enum": list(WHO_ACTS),
                                "description": "кто фактически выполняет работу сегодня: AGENT (сам), AGENT_WITH_CONFIRMATION (сам, человек подтверждает), HUMAN_WITH_AGENT (человек, агент готовит), HUMAN (человек без агента)",
                            },
                            "detail": {
                                "type": "string",
                                "description": "что стоит за этой возможностью сегодня, 8-30 слов: где проходит её граница, что происходит вместо неё, чего это стоит бизнесу. Раскрывается по клику под тезисом, поэтому обязан ДОБАВЛЯТЬ то, чего в тезисе нет: пересказ тезиса другими словами отклоняется. Не пиши «выполняет агент» / «выполняет человек» — это уже сказано в who_acts и в самом тезисе; пиши конкретику. Пример: тезис «Решение по заявке приходит в тот же день» → «Пока так работает по зарплатным клиентам; остальным ответ готовит андеррайтер, обычно за два-три дня».",
                            },
                        },
                        "required": ["capability", "availability", "detail"],
                    },
                },
                "stage_status": {
                    "type": "string", "enum": list(STATUSES),
                    "description": "статус этапа целиком: DONE/PARTIAL/NOT_STARTED/UNCLEAR",
                },
                "evidence": {
                    "type": "array",
                    "description": "ссылки на материалы, подтверждающие возможности; пусто, если ничего не найдено",
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string"},
                            "line": {"type": "integer"},
                            "basis": {"type": "string", "description": "конкретное имя (функции/класса/эндпоинта/файла) рядом со строкой"},
                        },
                    },
                },
                "execution_mode": {"type": "string", "enum": list(EXECUTION_MODES),
                                   "description": "режим исполнения этапа: HUMAN_ONLY/ASSIST/CONFIRM/AUTO — см. справочник; согласован с who_acts возможностей"},
                "execution_type": {"type": "string", "enum": list(EXECUTION_TYPES),
                                   "description": "тип автономного исполнения: PROACTIVE_ACTION/REACTIVE_ACTION/PROACTIVE_STATE/REACTIVE_STATE"},
                "completion_status": {"type": "string", "enum": list(COMPLETION_STATUSES),
                                      "description": "статус завершения: ACHIEVED/CORRECTLY_HANDLED/UNCONFIRMED"},
                "objects_found": {
                    "type": "array",
                    "description": "найденные объекты стандарта с evidence-ссылкой; пусто, если ни одного не найдено",
                    "items": {
                        "type": "object",
                        "properties": {
                            "kind": {"type": "string", "enum": list(STANDARD_OBJECT_KINDS)},
                            "path": {"type": "string"},
                            "line": {"type": "integer"},
                            "basis": {"type": "string"},
                        },
                        "required": ["kind", "path"],
                    },
                },
                "technical_notes": {"type": "string", "description": "краткие технические наблюдения для себя (что найдено, чего не хватает) — служебное поле, в отчёт не идёт"},
            },
            "required": ["item_id", "stage_summary", "capabilities", "stage_status"],
        },
    },
}

_FINISH_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "finish",
        "description": "Вызови, когда отправил вердикты по всем этапам плана и общий вывод "
                       "(submit_summary) — сессия завершена.",
        "parameters": {"type": "object", "properties": {}},
    },
}

_SUBMIT_SUMMARY_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_summary",
        "description": "Общий вывод по проекту в целом — вызывай ОДИН раз после всех "
                       "submit_stage и ДО finish. Три независимых поля, не повторяющих "
                       "друг друга: conclusion — 2-3 предложения; risks — ключевые риски "
                       "(до 3 пунктов); priorities — что сделать в первую очередь (до 3 "
                       "пунктов). Всё бизнес-языком, на основе уже отправленных вердиктов. "
                       "Повторный вызов заменяет предыдущий вывод.",
        "parameters": {
            "type": "object",
            "properties": {
                "conclusion": {
                    "type": "string",
                    "description": "2-3 предложения до 60 слов: где проект в целом и ОДИН "
                                   "главный барьер на пути к запуску. Без путей к файлам и "
                                   "технических слов. Опирайся только на уже отправленные "
                                   "вердикты.",
                },
                "risks": {
                    "type": "array",
                    "maxItems": 3,
                    "items": {"type": "string"},
                    "description": "ключевые бизнес-риски, максимум 3 пункта по убыванию "
                                   "важности. Каждый — до 140 символов и обязательно С "
                                   "ПОСЛЕДСТВИЕМ: «Решение принимается вручную — это "
                                   "ограничивает объём выдач и ставит под угрозу срок "
                                   "запуска». Не словосочетание, а мысль целиком.",
                },
                "priorities": {
                    "type": "array",
                    "maxItems": 3,
                    "items": {"type": "string"},
                    "description": "что сделать в первую очередь, максимум 3 пункта в "
                                   "повелительном наклонении, каждый до 140 символов и с "
                                   "эффектом: «Запустить автоматическое решение по заявке — "
                                   "снять главный барьер клиентского пути». Приоритет №1 "
                                   "закрывает риск №1.",
                },
            },
            "required": ["conclusion"],
        },
    },
}

_SESSION_TOOL_SCHEMAS: list[dict[str, Any]] = (
    REPO_TOOL_SCHEMAS
    + [_SUBMIT_PLAN_SCHEMA, _SUBMIT_STAGE_SCHEMA, _SUBMIT_SUMMARY_SCHEMA, _FINISH_SCHEMA]
)

_MAX_MALFORMED = 3
_REPEAT_STOP = 3

# Сколько раз подряд можно отклонить текст из-за языка, прежде чем принять его
# с заменой нарушившего поля. Без потолка сессия рискует уйти в круг
# «отклонено — переформулировал так же — отклонено» и умереть по
# `_REPEAT_STOP`, потеряв этап целиком; лучше принять вердикт с честной
# пометкой, чем не получить его вовсе.
_MAX_LANGUAGE_STRIKES = 2


@dataclass
class AgentResult:
    items: list[PlanItem] = field(default_factory=list)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    plan: list[PlanItem] = field(default_factory=list)
    summary: ProjectSummary | None = None
    summary_source: str = "none"
    project_title: str = ""
    project_summary: str = ""
    client: str = ""
    client_goal: str = ""
    source: str = "none"
    notes: list[str] = field(default_factory=list)

    @property
    def usable(self) -> bool:
        return bool(self.items)


def run_agent(
    slides: list[Slide],
    tree: Tree,
    spec: ModelSpec | None,
    client: ChatClient | None = None,
    max_steps: int = DEFAULT_MAX_STEPS,
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None,
    on_plan: Callable[[list[PlanItem]], None] | None = None,
    on_summary: Callable[[ProjectSummary], None] | None = None,
    extraction: Extraction | None = None,
    stages: list[str] | None = None,
) -> AgentResult:
    """Составить карту клиентского пути, пройти её по этапам и написать общий
    вывод — одна сессия, одна личность.

    `stages` — этапы, заданные человеком при загрузке материалов. Пустой
    список (по умолчанию) — этапы берутся со слайдов или из опорной карты, как
    и раньше. Непустой — агент обязан вернуть в `submit_plan` ровно эти этапы,
    в этом же порядке; несовпадение отклоняет план. Названия в отчёт идут в
    авторской редакции человека, а не в пересказе модели.

    `client` — тестовая инъекция по образцу остальных LLM-ролей: без неё
    `ChatClient` по умолчанию читает/пишет реальный `~/.pko/llm-cache`.

    `on_verdict`/`on_plan`/`on_summary` — необязательные колбэки для
    live-прогресса (веб-эндпоинт): вызываются сразу после принятия
    соответствующего `submit_stage`/`submit_plan`/`submit_summary`.
    Без колбэков (`None`) поведение не меняется.
    """
    if spec is None:
        return AgentResult(notes=["Matcher не настроен: план и вердикты не получены"])

    content_slides = [s for s in slides if not s.is_empty]
    if not content_slides:
        return AgentResult(notes=["В презентации нет текстовых фигур"])

    known_slides = {s.number for s in content_slides}
    user_stages = list(stages or [])
    user = "Слайды презентации:\n\n" + "\n\n".join(render_slide(s) for s in content_slides)
    if user_stages:
        # Заданные этапы идут ПЕРЕД слайдами: это не подсказка, а задание, и
        # оно должно быть первым, что модель читает в пользовательском
        # сообщении. Совпадение всё равно проверит код, но чем меньше поводов
        # для пересдачи плана, тем меньше шагов уходит впустую.
        listing = "\n".join(f"{i}. {title}" for i, title in enumerate(user_stages, 1))
        user = (
            "Этапы клиентского пути заданы заказчиком. В submit_plan верни ровно эти "
            "этапы, в этом порядке и с этими названиями — не добавляй новых, не убирай "
            "и не переименовывай. Опорная карта и разбор слайдов на этапы в этом случае "
            f"не применяются:\n{listing}\n\n" + user
        )

    chat_client = client if client is not None else ChatClient(spec=spec)
    # При включённом thinking (enable_thinking=True в extra_body) reasoning
    # съедает значительную часть max_tokens — 2000 не оставляют места content,
    # и агент падает с «пустой ответ». Thinking-режиму нужен больший budget.
    thinking_on = bool(
        spec.extra_body
        and spec.extra_body.get("chat_template_kwargs", {}).get("enable_thinking") is True
    )
    max_tokens = MAX_TOKENS_THINKING if thinking_on else MAX_TOKENS_DEFAULT
    outcome = _run_session(
        user, known_slides, tree, chat_client, max_steps, max_tokens,
        on_verdict=on_verdict, on_plan=on_plan, on_summary=on_summary,
        extraction=extraction, user_stages=user_stages,
    )

    notes = outcome.notes
    ungrounded = sum(
        1 for v in outcome.verdicts if v.status in ("DONE", "PARTIAL") and not v.is_grounded
    )
    if ungrounded:
        notes.append(
            f"Вердиктов DONE/PARTIAL без единой подтверждённой ссылки на код: {ungrounded} — "
            "агент утверждает прогресс, но код это не показывает; нужна ручная проверка"
        )
    restored = sum(1 for item in outcome.plan if item.restored)
    if restored:
        notes.append(
            f"Этапов пути, восстановленных агентом по опорной карте (в презентации их нет): "
            f"{restored} — это реконструкция, а не замысел команды"
        )
    return AgentResult(
        items=outcome.items, verdicts=outcome.verdicts, plan=outcome.plan,
        summary=outcome.summary, summary_source=outcome.summary_source,
        project_title=outcome.project_title, project_summary=outcome.project_summary,
        client=outcome.client, client_goal=outcome.client_goal,
        source="llm" if outcome.items else "none", notes=notes,
    )


def find_unclaimed_paths(
    extraction: Extraction, verdicts: list[ItemVerdict], limit: int = 20
) -> list[UnclaimedGroup]:
    """Файлы-кандидаты, не процитированные ни одной подтверждённой evidence."""
    claimed = {
        e.path for v in verdicts for e in v.verified_evidence if e.path
    }
    candidate_paths = sorted({f.path for f in extraction.facts if f.path})
    unclaimed = [p for p in candidate_paths if p not in claimed]

    groups: dict[str, list[str]] = {}
    for path in unclaimed:
        segments = path.split("/")
        key = "/".join(segments[:2]) if len(segments) > 1 else segments[0]
        groups.setdefault(key, []).append(path)

    ranked = sorted(groups.items(), key=lambda kv: -len(kv[1]))[:limit]
    return [
        UnclaimedGroup(group=key, example_paths=paths[:3], file_count=len(paths))
        for key, paths in ranked
    ]


@dataclass
class _SessionOutcome:
    """Итог одной сессии агента — то, что `run_agent` превращает в `AgentResult`."""

    items: list[PlanItem] = field(default_factory=list)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    plan: list[PlanItem] = field(default_factory=list)
    summary: ProjectSummary | None = None
    summary_source: str = "none"
    project_title: str = ""
    project_summary: str = ""
    client: str = ""
    client_goal: str = ""
    notes: list[str] = field(default_factory=list)


def _run_session(
    user_brief: str,
    known_slides: set[int],
    tree: Tree,
    chat_client: ChatClient,
    max_steps: int,
    max_tokens: int,
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None,
    on_plan: Callable[[list[PlanItem]], None] | None = None,
    on_summary: Callable[[ProjectSummary], None] | None = None,
    extraction: Extraction | None = None,
    user_stages: list[str] | None = None,
) -> _SessionOutcome:
    """Фаза 1: `submit_plan` → Фаза 2: `submit_stage` по каждому этапу →
    Фаза 3: `submit_summary` (общий вывод) → `finish`."""
    user_stages = list(user_stages or [])
    tools = ToolBox(tree, extraction=extraction)
    system_prompt, missing_parts = load_system_prompt()
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_brief},
    ]
    notes: list[str] = []
    if missing_parts:
        notes.append(
            "Части системного промпта не найдены и в анализ не попали: "
            + ", ".join(missing_parts)
        )
    recent_calls: list[tuple[tuple[str, str], ...]] = []
    malformed = 0
    items_by_id: dict[str, PlanItem] = {}
    verdicts_by_id: dict[str, ItemVerdict] = {}
    plan_items: list[PlanItem] = []
    plan_by_id: dict[str, PlanItem] = {}
    # Счётчик отклонений по языку — свой на каждый этап, плюс служебные ключи
    # для плана и общего вывода. См. `_MAX_LANGUAGE_STRIKES`.
    language_strikes: dict[str, int] = {}
    project_title = ""
    project_summary = ""
    client_name = ""
    client_goal = ""
    plan_accepted = False
    summary: ProjectSummary | None = None
    summary_source = "none"
    finished = False
    steps_done = 0

    with trace_span("agent_session") as session_handle:
        for step in range(1, max(1, max_steps) + 1):
            steps_done = step
            # Спан шага оборачивает LLM-вызов ( Phoenix строит по нему
            # дочерний авто-спан chat.completions.create) и несёт атрибуты:
            # номер шага, вызванные инструменты, длину reasoning/text — то,
            # по чему в трейсе виден ход агента, а не только голые LLM-вызовы.
            with trace_span("agent.step", step=step) as step_span:
                try:
                    result = chat_client.chat(messages, tools=_SESSION_TOOL_SCHEMAS, max_tokens=max_tokens)
                except LlmError as exc:
                    step_span.set_attribute("error", exc.message)
                    notes.append(f"агент недоступен на шаге {step}: {exc.message}")
                    break

                step_span.set_attribute("from_cache", result.from_cache)
                step_span.set_attribute("text_chars", len(result.text or ""))
                step_span.set_attribute("reasoning_chars", len(result.reasoning_content or ""))
                if result.tool_calls:
                    names = ",".join(
                        str((c.get("function") or {}).get("name") or "")
                        for c in result.tool_calls
                    )
                    step_span.set_attribute("tool_calls", names)
                    step_span.set_attribute("tool_call_count", len(result.tool_calls))
                else:
                    step_span.set_attribute("tool_calls", "")
                    step_span.set_attribute("tool_call_count", 0)
                if result.usage:
                    step_span.set_attribute("total_tokens", result.usage.get("total_tokens", 0))

            if not result.tool_calls:
                malformed += 1
                if malformed >= _MAX_MALFORMED:
                    notes.append(f"агент не вызвал инструмент {malformed} раз подряд — остановлено")
                    break
                messages.append({"role": "assistant", "content": result.text})
                messages.append({
                    "role": "user",
                    "content": "Нужно вызвать инструмент — сначала submit_plan (кто клиент и "
                               "список этапов пути), затем по каждому этапу submit_stage, "
                               "потом submit_summary с тремя полями "
                               "(conclusion/risks/priorities) и finish, когда закончил.",
                })
                continue
            malformed = 0

            signature = tuple(sorted(
                (str((c.get("function") or {}).get("name") or ""),
                 str((c.get("function") or {}).get("arguments") or ""))
                for c in result.tool_calls
            ))
            recent_calls.append(signature)
            if len(recent_calls) >= _REPEAT_STOP and len(set(recent_calls[-_REPEAT_STOP:])) == 1:
                notes.append(f"остановлено — {_REPEAT_STOP} одинаковых вызова подряд")
                break

            messages.append({
                "role": "assistant",
                "content": result.text or None,
                "tool_calls": result.tool_calls,
                # reasoning_content — цепочка рассуждений модели (thinking).
                # Сохраняется в историю для анализа прогона, но не показывается
                # модели в последующих шагах: многие эндпоинты не принимают
                # это поле в запросе и падают с 400. Поле нужно человеку/трейсам,
                # не самому агенту.
                "reasoning_content": result.reasoning_content or None,
            })

            for call in result.tool_calls:
                function = call.get("function") or {}
                name = str(function.get("name") or "")
                raw_args = function.get("arguments") or "{}"
                call_id = str(call.get("id") or "")
                try:
                    args = json.loads(raw_args)
                except json.JSONDecodeError:
                    messages.append({
                        "role": "tool", "tool_call_id": call_id,
                        "content": f"аргументы инструмента не являются валидным JSON: {raw_args!r}",
                    })
                    continue
                args = args if isinstance(args, dict) else {}

                if name == "submit_plan":
                    strikes = language_strikes.get("__plan__", 0)
                    plan, context, error = _accept_plan(
                        args, known_slides, user_stages=user_stages,
                        enforce_language=strikes < _MAX_LANGUAGE_STRIKES,
                    )
                    if error:
                        language_strikes["__plan__"] = strikes + 1
                        tool_content = f"план отклонён: {error}"
                    else:
                        plan_items = plan
                        project_title = context.get("project_title", "")
                        project_summary = context.get("project_summary", "")
                        client_name = context.get("client", "")
                        client_goal = context.get("client_goal", "")
                        plan_accepted = True
                        plan_by_id = {p.id: p for p in plan}
                        if on_plan is not None:
                            on_plan(plan)
                        tool_content = (
                            f"план принят: {len(plan)} этапов. Теперь по каждому этапу: сначала "
                            "перечитай, что он обещает клиенту по презентации, и выпиши все "
                            "обещанные возможности; затем собери факты инструментами и добавь "
                            "к ним то, что продукт уже даёт, но на слайде названо не было. "
                            "Обещанное и не найденное отправляй с NOT_AVAILABLE, а не "
                            "пропускай. Называй возможность, а не пересказывай находку."
                        )
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": tool_content})
                    continue

                if name == "submit_stage":
                    if not plan_accepted:
                        messages.append({
                            "role": "tool", "tool_call_id": call_id,
                            "content": "сначала вызови submit_plan (клиент + список этапов пути), "
                                       "затем submit_stage по каждому этапу",
                        })
                        continue
                    item_id = str(args.get("item_id") or "").strip()
                    if not item_id or item_id not in plan_by_id:
                        messages.append({
                            "role": "tool", "tool_call_id": call_id,
                            "content": f"вердикт отклонён: item_id {item_id!r} не найден в плане",
                        })
                        continue
                    strikes = language_strikes.get(item_id, 0)
                    verdict, error, hints = _accept_stage(
                        item_id, args, tree,
                        enforce_language=strikes < _MAX_LANGUAGE_STRIKES,
                    )
                    if error:
                        language_strikes[item_id] = strikes + 1
                        tool_content = f"вердикт отклонён: {error}"
                    else:
                        item = plan_by_id[item_id]
                        items_by_id[item_id] = item
                        verdicts_by_id[item_id] = verdict
                        if strikes >= _MAX_LANGUAGE_STRIKES:
                            notes.append(
                                f"Этап «{item.title}»: формулировки приняты после "
                                f"{strikes} отклонений по языку — часть текста заменена пометкой"
                            )
                        tool_content = "вердикт принят. Переходи к следующему этапу плана."
                        if hints:
                            tool_content += " Подсказка на будущее: " + " ".join(hints)
                        if on_verdict is not None:
                            on_verdict(item, verdict)
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": tool_content})
                    continue

                if name == "submit_summary":
                    strikes = language_strikes.get("__summary__", 0)
                    parsed, error = _accept_summary(
                        args, set(items_by_id), verdicts_by_id, tree,
                        enforce_language=strikes < _MAX_LANGUAGE_STRIKES,
                    )
                    if error:
                        language_strikes["__summary__"] = strikes + 1
                        tool_content = f"общий вывод отклонён: {error}"
                    else:
                        summary = parsed
                        summary_source = "llm"
                        if on_summary is not None:
                            on_summary(parsed)
                        tool_content = "общий вывод принят. Теперь вызови finish."
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": tool_content})
                    continue

                if name == "finish":
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": "сессия завершена"})
                    finished = True
                    continue

                outcome = tools.call(name, args)
                messages.append({"role": "tool", "tool_call_id": call_id, "content": outcome.content})

            if finished:
                break
        else:
            notes.append(f"бюджет шагов исчерпан ({max_steps})")

        # Сводка по сессии — видна в Phoenix как атрибуты корня agent_session:
        # на каком шаге остановились, сколько этапов/вердиктов собрано.
        session_handle.set_attribute("steps_done", steps_done)
        session_handle.set_attribute("plan_items", len(plan_items))
        session_handle.set_attribute("verdicts", len(verdicts_by_id))
        session_handle.set_attribute("summary_source", summary_source)
        session_handle.set_attribute("finished", finished)

    if not verdicts_by_id:
        notes.append("Вердикты по этапам не отправлены (submit_stage не вызывался)")
    if not plan_accepted:
        notes.append("План не был передан (submit_plan не вызывался) — вердикты не принимались")
    if not summary:
        notes.append("Общий вывод не сформирован (submit_summary не вызывался или отклонён)")
    return _SessionOutcome(
        items=list(items_by_id.values()), verdicts=list(verdicts_by_id.values()),
        plan=plan_items, summary=summary, summary_source=summary_source,
        project_title=project_title, project_summary=project_summary,
        client=client_name, client_goal=client_goal,
        notes=notes,
    )


# Лимиты бизнес-текстов. Прежние 6 слов на буллет и молчаливое обрезание были
# отдельной причиной технических формулировок: в шесть слов помещается «Скоринг
# не подключён», но не помещается «Клиент получает решение без визита в
# отделение», а обрезание превращало нормальную фразу в обрубок, который
# читается как заголовок задачи. Теперь у возможности есть и нижняя граница
# (короче четырёх слов — это ярлык, а не возможность), а нарушение верхней
# отклоняется с объяснением, а не режется молча.
_MAX_CAPABILITIES = 5
_MIN_CAPABILITY_WORDS = 4
_MAX_CAPABILITY_WORDS = 16
_MAX_DETAIL_WORDS = 30
_MAX_STAGE_SUMMARY_WORDS = 30

# Готовность этапа по режиму исполнения (таблица из `standard_reference.md`) с
# корректировкой по статусу завершения. Считается кодом, а не моделью: раньше
# `progress` приходил числом от агента и регулярно расходился с режимом
# (`HUMAN_ONLY` с готовностью 90). Модель отвечает за наблюдение, арифметику
# делает код — тот же принцип, что и с проверкой evidence.
_MODE_PROGRESS = {"AUTO": 100, "CONFIRM": 75, "ASSIST": 50, "HUMAN_ONLY": 25}
_COMPLETION_DELTA = {"ACHIEVED": 0, "CORRECTLY_HANDLED": -20, "UNCONFIRMED": -30}
_AVAILABILITY_PROGRESS = {"AVAILABLE": 100, "LIMITED": 50, "NOT_AVAILABLE": 0}


def derive_progress(
    execution_mode: str, completion_status: str, capabilities: list[StageCapability]
) -> int:
    """Готовность этапа 0-100 по режиму исполнения и статусу завершения.

    Режим не определён — считаем по доступности возможностей этапа: это
    единственный сигнал, который у нас всё равно есть, и он честнее нуля.
    """
    if execution_mode in _MODE_PROGRESS:
        base = _MODE_PROGRESS[execution_mode] + _COMPLETION_DELTA.get(completion_status, 0)
        return max(0, min(100, base))
    if capabilities:
        total = sum(_AVAILABILITY_PROGRESS[c.availability] for c in capabilities)
        return max(0, min(100, round(total / len(capabilities))))
    return 0


def _language_violations(text: str, tree: Tree) -> list[str]:
    """Причины, по которым текст нельзя показывать руководителю.

    Два сторожа в одном месте: выдуманные пути (`check_explanation`) и
    техническая лексика (`check_business_language`). Первый ловит ложный факт,
    второй — язык; ни один не заменяет другого.
    """
    violations = check_explanation(text, tree_files=tree.files_set)
    violations += check_business_language(text)
    return [v.render() for v in violations]


def _trim_words(text: str, limit: int) -> str:
    words = text.split()
    return " ".join(words[:limit])


def _accept_stage(
    item_id: str, args: dict, tree: Tree, enforce_language: bool
) -> tuple[ItemVerdict | None, str | None, list[str]]:
    """Разобрать `submit_stage` в `ItemVerdict`.

    Возвращает `(вердикт, ошибка, подсказки)`. Ошибка не фатальна: агент
    получает её текстом и может прислать вердикт заново — так же, как с
    отклонённым планом или общим выводом.

    `enforce_language=False` — режим «страйки кончились»: нарушения языка
    больше не отклоняют вызов, а заменяют текст нарушившего поля пометкой.
    Вердикт при этом сохраняется: потерять оценку этапа из-за формулировки
    хуже, чем показать честную пометку рядом с ней.
    """
    status = str(args.get("stage_status") or "").strip().upper()
    if status not in STATUSES:
        return None, f"неизвестный stage_status: {status!r} (допустимы: {', '.join(STATUSES)})", []

    execution_mode = str(args.get("execution_mode") or "").strip()
    if execution_mode and execution_mode not in EXECUTION_MODES:
        return None, f"неизвестный execution_mode: {execution_mode!r}", []
    execution_type = str(args.get("execution_type") or "").strip()
    if execution_type and execution_type not in EXECUTION_TYPES:
        return None, f"неизвестный execution_type: {execution_type!r}", []
    completion_status = str(args.get("completion_status") or "").strip()
    if completion_status and completion_status not in COMPLETION_STATUSES:
        return None, f"неизвестный completion_status: {completion_status!r}", []

    stage_summary = " ".join(str(args.get("stage_summary") or "").split())
    if not stage_summary:
        return None, ("пустой stage_summary: одним предложением скажите, что этап значит "
                      "для клиента в целевой картине"), []

    capabilities, cap_error = _parse_capabilities(args.get("capabilities"), enforce_language)
    if cap_error:
        return None, cap_error, []
    if not capabilities:
        return None, ("пустой список capabilities: передайте хотя бы одну бизнес-возможность "
                      "этапа — что клиент или бизнес может здесь делать"), []

    # Сторожи по всем текстам, которые увидит руководитель. Собираем нарушения
    # разом, чтобы агент переформулировал за один заход, а не по одному полю.
    problems: list[str] = []
    summary_bad = _language_violations(stage_summary, tree)
    if summary_bad:
        problems.append("stage_summary — " + "; ".join(summary_bad))
    restatements: list[int] = []
    for i, cap in enumerate(capabilities, start=1):
        for attr in ("capability", "detail"):
            value = getattr(cap, attr)
            if not value:
                continue
            bad = _language_violations(value, tree)
            if bad:
                problems.append(f"возможность {i}, {attr} — " + "; ".join(bad))
        # Пересказ — не нарушение языка, а пустой комментарий: буллет
        # раскрывается по клику и ничего нового не сообщает. Считаем отдельно,
        # потому что и лечится он иначе (см. ниже: текст не заменяется
        # пометкой, а убирается совсем).
        if cap.detail and is_restatement(cap.detail, cap.capability):
            restatements.append(i)

    if restatements and enforce_language:
        listing = ", ".join(str(i) for i in restatements)
        return None, (
            f"комментарий пересказывает сам тезис (возможности: {listing}). Под буллетом "
            "раскрывается то, чего в нём нет: где проходит граница, что происходит вместо "
            "обещанного, чего это стоит бизнесу. Не повторяйте тезис другими словами и не "
            "пишите «выполняет агент»/«выполняет человек» — это уже сказано."
        ), []

    if problems and enforce_language:
        return None, (
            "формулировки не годятся для отчёта руководству: " + " | ".join(problems[:4])
            + ". Переформулируйте: подлежащее — человек или организация (клиент, менеджер, "
              "банк, агент), и фраза должна остаться верной, даже если всю реализацию "
              "перепишут на другой технологии."
        ), []

    if problems:
        # Страйки кончились — принимаем вердикт, но нарушившие поля заменяем.
        if summary_bad:
            stage_summary = "(описание этапа отклонено сторожем: " + "; ".join(summary_bad) + ")"
        for cap in capabilities:
            for attr in ("capability", "detail"):
                value = getattr(cap, attr)
                if value and _language_violations(value, tree):
                    setattr(cap, attr, f"({attr} отклонён сторожем)")

    if restatements:
        # Попытки кончились, а комментарий всё ещё пересказывает тезис. Пустой
        # комментарий честнее пометки: строка на дашборде просто перестанет
        # раскрываться, вместо того чтобы обещать пояснение и не давать его.
        for i in restatements:
            capabilities[i - 1].detail = ""

    verdict = ItemVerdict(
        item_id=item_id,
        status=status,
        stage_summary=_trim_words(stage_summary, _MAX_STAGE_SUMMARY_WORDS),
        capabilities=capabilities,
        evidence=_parse_evidence(args.get("evidence"), tree),
        progress=derive_progress(execution_mode, completion_status, capabilities),
        execution_mode=execution_mode,
        execution_type=execution_type,
        completion_status=completion_status,
        objects_found=_parse_standard_objects(args.get("objects_found")),
    )
    hints = _subject_hints(capabilities)
    return verdict, None, hints


def _subject_hints(capabilities: list[StageCapability]) -> list[str]:
    """Мягкая подсказка: в формулировке не видно ни человека, ни результата.

    Не основание отклонить вызов — бывают корректные исключения, — но почти
    всегда признак того, что описано устройство системы, а не возможность.
    Подсказка уходит в ответ инструмента и влияет на следующий этап.

    Формулировка подсказки важна не меньше самой проверки: прежняя редакция
    предлагала «начните с клиента, менеджера, банка или агента» — и получала
    ровно то, что просила, страницу однообразных «Клиент…» / «Агент…».
    Требование к возможности не в том, чтобы фраза начиналась с действующего
    лица, а в том, чтобы она была про людей и результат.
    """
    faceless = [c.capability for c in capabilities if not has_business_subject(c.capability)]
    if not faceless:
        return []
    return [
        f"в формулировке «{faceless[0]}» не видно ни человека, ни результата для него — "
        "проверьте, что это возможность бизнеса, а не описание устройства системы."
    ]


def _parse_capabilities(
    raw: object, enforce_language: bool
) -> tuple[list[StageCapability], str | None]:
    """Разобрать `submit_stage.capabilities`.

    Возвращает `(возможности, ошибка)`. Проверка длины строгая, пока есть
    страйки: слишком короткая формулировка — это ярлык («скоринг готов»), а
    слишком длинная не помещается в карточку этапа. Когда страйки кончились,
    длина приводится к границам обрезанием, чтобы вердикт всё-таки состоялся.
    """
    if not isinstance(raw, list):
        return [], None
    capabilities: list[StageCapability] = []
    for i, raw_cap in enumerate(raw[:_MAX_CAPABILITIES], start=1):
        if not isinstance(raw_cap, dict):
            continue
        availability = str(raw_cap.get("availability") or "").strip().upper()
        if availability not in AVAILABILITY:
            return [], (f"возможность {i}: неизвестная availability {availability!r} "
                        f"(допустимы: {', '.join(AVAILABILITY)})")
        who_acts = str(raw_cap.get("who_acts") or "").strip().upper()
        if who_acts and who_acts not in WHO_ACTS:
            return [], (f"возможность {i}: неизвестный who_acts {who_acts!r} "
                        f"(допустимы: {', '.join(WHO_ACTS)})")
        capability = " ".join(str(raw_cap.get("capability") or "").split())
        if not capability:
            continue
        words = len(capability.split())
        if enforce_language and words < _MIN_CAPABILITY_WORDS:
            return [], (f"возможность {i} («{capability}»): слишком коротко — это ярлык, а не "
                        f"возможность. Нужно {_MIN_CAPABILITY_WORDS}-{_MAX_CAPABILITY_WORDS} "
                        "слов: кто → что делает или получает → в каких границах.")
        if enforce_language and words > _MAX_CAPABILITY_WORDS:
            return [], (f"возможность {i}: {words} слов при пределе {_MAX_CAPABILITY_WORDS} — "
                        "оставьте одну мысль, подробности перенесите в limit.")
        capabilities.append(StageCapability(
            availability=availability,
            capability=_trim_words(capability, _MAX_CAPABILITY_WORDS),
            who_acts=who_acts,
            detail=_trim_words(" ".join(str(raw_cap.get("detail") or "").split()),
                               _MAX_DETAIL_WORDS),
        ))
    return capabilities, None


def _parse_evidence(raw: object, tree: Tree) -> list[EvidenceRef]:
    """Разобрать список evidence-ссылок и проверить каждую `verify_evidence`."""
    evidence: list[EvidenceRef] = []
    if not isinstance(raw, list):
        return evidence
    for raw_ev in raw:
        if not isinstance(raw_ev, dict):
            continue
        path = str(raw_ev.get("path") or "").strip()
        basis = str(raw_ev.get("basis") or "").strip()
        try:
            line = int(raw_ev["line"]) if raw_ev.get("line") is not None else None
        except (TypeError, ValueError):
            line = None
        if not path:
            continue
        result = verify_evidence(path, line, basis, tree)
        evidence.append(EvidenceRef(
            path=result.path, line=result.line, basis=basis,
            verified=result.ok, reason=result.reason,
        ))
    return evidence


def _parse_standard_objects(raw: object) -> list[StandardObject]:
    """Разобрать найденные объекты стандарта (BBB/guardrail/handoff/метрика).

    Битые/неполные элементы пропускаются (как evidence): классификация
    объектов — информационная, не основание для вердикта."""
    objects: list[StandardObject] = []
    if not isinstance(raw, list):
        return objects
    for raw_obj in raw:
        if not isinstance(raw_obj, dict):
            continue
        kind = str(raw_obj.get("kind") or "").strip()
        if kind not in STANDARD_OBJECT_KINDS:
            continue
        path = str(raw_obj.get("path") or "").strip()
        if not path:
            continue
        try:
            line = int(raw_obj["line"]) if raw_obj.get("line") is not None else None
        except (TypeError, ValueError):
            line = None
        objects.append(StandardObject(
            kind=kind, path=path, line=line,
            basis=str(raw_obj.get("basis") or "").strip(),
        ))
    return objects


def _accept_summary(
    args: dict,
    plan_ids: set[str],
    verdicts_by_id: dict[str, ItemVerdict],
    tree: Tree,
    enforce_language: bool = True,
) -> tuple[ProjectSummary | None, str | None]:
    """Разобрать `submit_summary` (conclusion/risks/priorities) и проверить сторожами.

    Три независимых поля, не повторяющих друг друга. Каждый текст проходит
    `check_summary_text` (агент может ссылаться только на подтверждённую
    evidence и id пунктов плана) и `check_business_language` (техническая
    лексика). Нарушение отклоняет вывод целиком — агент может пересдать
    `submit_summary`; после `_MAX_LANGUAGE_STRIKES` попыток языковая часть
    перестаёт отклонять (`enforce_language=False`), проверка фактов остаётся.

    После сторожей вывод нормализуется детерминированно, без обратного обмена с
    LLM (формат — не фактическая ошибка, как у `display_percent`): conclusion —
    до 3 предложений и 60 слов, списки — до 3 пунктов по 140 символов. Сторожи
    гоняются по исходному тексту, поэтому нарушение в отброшенном хвосте
    по-прежнему валит вывод — нормализация не даёт его «спрятать».
    """
    conclusion = str(args.get("conclusion") or "").strip()
    if not conclusion:
        return None, "пустой общий вывод (conclusion)"

    risks = _parse_string_list(args.get("risks"))
    priorities = _parse_string_list(args.get("priorities"))

    verified_paths = {e.path for v in verdicts_by_id.values() for e in v.verified_evidence}
    # Проверяем каждое текстовое поле отдельно — найдём нарушение в любом из них.
    for label, text in _summary_texts(conclusion, risks, priorities):
        violations = check_summary_text(text, plan_ids=plan_ids, verified_paths=verified_paths)
        if enforce_language:
            violations = violations + check_business_language(text)
        if violations:
            reasons = "; ".join(v.render() for v in violations)
            return None, f"сторож отклонил поле {label}: {reasons}"

    return ProjectSummary(
        conclusion=_lead_sentences(conclusion),
        risks=[_short_phrase(r) for r in risks[:_MAX_SUMMARY_LIST_ITEMS]],
        priorities=[_short_phrase(p) for p in priorities[:_MAX_SUMMARY_LIST_ITEMS]],
    ), None


# Лимиты вывода: conclusion — до 3 предложений и 60 слов, risks/priorities —
# до 3 пунктов по 140 символов. Прежний лимит в 4 слова на пункт давал
# «Нет автоматического скоринга» — словосочетание без последствия, которое
# читается как строка бэклога. Риск для правления обязан называть последствие,
# а оно в четыре слова не помещается.
# Подзаголовок отчёта: две фразы и 30 слов — столько помещается под
# названием проекта, не превращая шапку в абзац.
_MAX_PROJECT_SUMMARY_SENTENCES = 2
_MAX_PROJECT_SUMMARY_WORDS = 30

_MAX_SUMMARY_LIST_ITEMS = 3
_MAX_SUMMARY_ITEM_CHARS = 140
_MAX_CONCLUSION_SENTENCES = 3
_MAX_CONCLUSION_WORDS = 60

# Разбивка на предложения — по terminator'у (.!?) с последующим пробелом.
# Без терминатора текст считается одним предложением.
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


def _lead_sentences(
    text: str,
    max_sentences: int = _MAX_CONCLUSION_SENTENCES,
    max_words: int = _MAX_CONCLUSION_WORDS,
) -> str:
    """Первые предложения текста в пределах лимитов по числу фраз и слов.

    Один нормализатор на общий вывод (`conclusion`) и на подзаголовок отчёта
    (`project_summary`) — правило одно, различаются только границы."""
    parts = [p for p in _SENTENCE_SPLIT.split(text.strip()) if p]
    kept: list[str] = []
    words = 0
    for sentence in parts[:max_sentences]:
        count = len(sentence.split())
        if kept and words + count > max_words:
            break
        kept.append(sentence)
        words += count
    if not kept:
        return ""
    return _trim_words(" ".join(kept), max_words)


def _short_phrase(text: str) -> str:
    """Пункт списка в пределах `_MAX_SUMMARY_ITEM_CHARS`, обрезанный по слову.

    Обрезаем по границе слова и ставим многоточие: обрубок посреди слова в
    отчёте правления выглядит как ошибка выгрузки, а не как сокращение.
    """
    text = " ".join(text.split())
    if len(text) <= _MAX_SUMMARY_ITEM_CHARS:
        return text
    cut = text[:_MAX_SUMMARY_ITEM_CHARS].rsplit(" ", 1)[0].rstrip(" ,;:—-")
    return f"{cut}…"


def _parse_string_list(raw: object) -> list[str]:
    """Список строк из аргумента risks/priorities — отбрасывает пустые элементы."""
    if not isinstance(raw, list):
        return []
    return [str(item).strip() for item in raw if str(item).strip()]


def _summary_texts(conclusion: str, risks: list[str], priorities: list[str]):
    yield "conclusion", conclusion
    for i, r in enumerate(risks):
        yield f"risks[{i}]", r
    for i, p in enumerate(priorities):
        yield f"priorities[{i}]", p


def _validate_plan_item(
    raw: object, known_slides: set[int], index: int, user_stage: str | None = None
) -> PlanItem | None:
    """Один этап пути из `submit_plan`.

    `user_stage` — название, заданное человеком для этой позиции. Если оно
    есть, агент обязан вернуть его же (сравнение без учёта регистра и лишних
    пробелов), а в план идёт авторская редакция человека, не пересказ модели.
    Номер слайда у такого этапа не спрашивается: за ним слайда нет.

    Без `user_stage` `source_slide` обязан быть реальным номером слайда — либо
    `0`, что значит «этап восстановлен по опорной карте, в презентации его
    нет». Ноль здесь не поблажка, а именованный случай: без него агент,
    которому не дали ряда этапов, был вынужден привязывать выдуманный этап к
    произвольному слайду или собирать путь из карточек задач — и то, и другое
    давало технические формулировки. Происхождение (`origin`) доходит до
    отчёта, так что реконструкция не выдаётся за замысел команды.
    """
    if not isinstance(raw, dict):
        return None
    title = str(raw.get("title") or "").strip()
    if not title:
        return None
    item_id = str(raw.get("item_id") or "").strip()

    if user_stage is not None:
        if not _same_title(title, user_stage):
            return None
        return PlanItem(
            id=item_id or f"stage-{index}",
            title=user_stage,
            stage=str(raw.get("stage") or "").strip(),
            description=str(raw.get("description") or "").strip(),
            source_slide=0,
            origin="user",
        )

    try:
        source_slide = int(raw.get("source_slide"))
    except (TypeError, ValueError):
        return None
    if source_slide != 0 and source_slide not in known_slides:
        return None
    if not item_id:
        item_id = f"slide-{source_slide}-{index}"
    return PlanItem(
        id=item_id, title=title,
        stage=str(raw.get("stage") or "").strip(),
        description=str(raw.get("description") or "").strip(),
        source_slide=source_slide,
        origin="restored" if source_slide == 0 else "slide",
    )


def _stage_listing(titles: list[str]) -> str:
    """Нумерованный перечень заданных этапов для текста отказа."""
    return "; ".join(f"{i}) {t}" for i, t in enumerate(titles, 1))


def _accept_plan(
    args: dict, known_slides: set[int], user_stages: list[str] | None = None,
    enforce_language: bool = True,
) -> tuple[list[PlanItem], dict[str, str], str | None]:
    """Разобрать `submit_plan` в список `PlanItem` и контекст проекта.

    Один битый пункт валит весь план — агенту проще переделать весь список
    сразу, чем чинить его по одной ошибке за раз. Дизамбигуация коллизий id
    через индекс (`-N`), в остальном id — как пришёл от агента.

    `user_stages` — этапы, заданные человеком при загрузке. Тогда план обязан
    состоять ровно из них, в том же порядке: и число, и названия сверяются
    кодом. Проверка нужна не ради педантизма — если агент переставит или
    выбросит этап, описания и вердикты уедут не на те позиции, и отчёт молча
    покажет чужую готовность у чужого этапа.

    Языковой сторож применяется к `description` любого этапа и к `title`
    только восстановленных: название, названное человеком (на слайде или при
    загрузке), принадлежит ему, и отклонять его за чужой выбор слов
    неправильно — а вот текст, который агент написал сам, обязан быть на
    языке отчёта.

    `client`/`client_goal` — кто клиент и какую задачу он решает. Отдельные
    поля, а не преамбула к плану: клиентский путь принадлежит клиенту, и, пока
    он не назван, этапы почти неизбежно собираются из карточек задач.
    """
    user_stages = list(user_stages or [])
    raw_items = args.get("items")
    if not isinstance(raw_items, list) or not raw_items:
        return [], {}, "план пуст: передайте непустой список items"
    if user_stages and len(raw_items) != len(user_stages):
        return [], {}, (
            f"этапы заданы заказчиком: их {len(user_stages)}, а в плане {len(raw_items)}. "
            "Верните ровно эти этапы, в этом порядке: " + _stage_listing(user_stages)
        )
    plan: list[PlanItem] = []
    seen: set[str] = set()
    for i, raw in enumerate(raw_items, start=1):
        expected = user_stages[i - 1] if user_stages else None
        item = _validate_plan_item(raw, known_slides, i, user_stage=expected)
        if item is None:
            if expected is not None:
                return [], {}, (f"пункт {i}: ожидался этап «{expected}» — заказчик задал этапы, "
                                "их нельзя переименовывать и переставлять. Порядок: "
                                + _stage_listing(user_stages))
            return [], {}, (f"пункт {i}: проверьте title и source_slide (должен быть реальным "
                            "номером слайда из входных данных либо 0, если этап восстановлен "
                            "по опорной карте)")
        if enforce_language:
            texts = [("description", item.description)]
            if item.origin == "restored":
                texts.append(("title", item.title))
            for label, text in texts:
                if not text:
                    continue
                bad = check_business_language(text)
                if bad:
                    return [], {}, (f"пункт {i}, {label} — " + "; ".join(v.render() for v in bad)
                                    + ". Опишите этап словами клиента, а не устройством системы.")
        if item.id in seen:
            item = replace(item, id=f"{item.id}-{i}")
        seen.add(item.id)
        plan.append(item)
    project_summary = " ".join(str(args.get("project_summary") or "").split())
    if project_summary and enforce_language:
        bad = check_business_language(project_summary)
        if bad:
            return [], {}, ("project_summary — " + "; ".join(v.render() for v in bad)
                            + ". Скажите, зачем проект нужен бизнесу, а не как он устроен.")
    context = {
        "project_title": str(args.get("project_title") or "").strip(),
        "client": str(args.get("client") or "").strip(),
        "client_goal": str(args.get("client_goal") or "").strip(),
        "project_summary": _lead_sentences(
            project_summary,
            max_sentences=_MAX_PROJECT_SUMMARY_SENTENCES,
            max_words=_MAX_PROJECT_SUMMARY_WORDS,
        ),
    }
    return plan, context, None

"""Общий пайплайн прогресса: PPTX-план + целевой репозиторий → ProgressModel.

Вызывается и CLI (`cli.cmd_progress`), и веб-эндпоинтом (`web.app`) — одна
реализация, чтобы поведение двух интерфейсов не могло разойтись. Функция
ничего не печатает и не пишет на диск — это дело вызывающей стороны (CLI
пишет отчёт через `output.publisher`, веб отдаёт HTML прямо в ответе).
"""

from __future__ import annotations

import time
from dataclasses import replace
from pathlib import Path
from typing import Any, Callable

from pko.errors import PkoError
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import trace_span
from pko.progress.matcher import DEFAULT_MAX_STEPS, find_unclaimed_paths, run_agent
from pko.progress.schema import ItemVerdict, PlanItem, ProgressModel, ProjectSummary
from pko.progress.target_repo import TargetRepo

# Событие — (kind, data), например ("presentation_parsed", {"slide_count": 12})
# или ("claim_verified", {"title": "...", "applicable": true, "percent": 60}).
# Один и тот же колбэк используется и для грубых фаз пайплайна, и
# (через адаптер ниже) для каждого принятого вердикта агента — веб-эндпоинту
# не нужно различать источник, только складывать всё в один SSE-поток по порядку.
ProgressEvent = Callable[[str, dict[str, Any]], None]

# Допустимые форматы входа плана. PPTX разбирается текстовыми фигурами
# (`pptx_reader`), PDF/изображение — рендерятся в PNG и распознаются vision-
# моделью (`slide_renderer` + `vision_client`). Каждая страница PDF становится
# отдельным слайдом и распознаётся самостоятельно.
_PPTX_SUFFIX = ".pptx"
_PDF_SUFFIX = ".pdf"
_IMAGE_SUFFIXES = (".bmp", ".jpeg", ".jpg", ".png", ".tif", ".tiff")


def run_progress(
    plan_paths: "Path | list[Path]",
    repo_name: str,
    target: TargetRepo,
    spec: ModelSpec,
    client: ChatClient | None = None,
    max_steps: int = DEFAULT_MAX_STEPS,
    on_event: ProgressEvent | None = None,
    vision_spec: ModelSpec | None = None,
    vision_client: "ChatClient | None" = None,
    stages: list[str] | None = None,
) -> ProgressModel:
    """Собрать ProgressModel: образ результата + репозиторий → агент → сводный вывод.

    `plan_paths` — один файл или несколько: образ результата может быть собран
    из нескольких документов (например, схема пути отдельно от карточек
    инициатив). Слайды всех файлов склеиваются в один список со сквозной
    нумерацией, а имя файла попадает в `Slide.source` и в текст промпта, чтобы
    агент видел границу между документами. Формат у каждого файла свой:
    PPTX разбирается текстом, PDF/изображение — vision-моделью.

    `stages` — этапы клиентского пути, заданные человеком при запуске (форма
    загрузки в вебе, `--stage` в CLI). Пусто — агент берёт этапы со слайдов
    или собирает по опорной карте, как и раньше.

    Формат входа определяется по суффиксу каждого файла:
      * `.pptx` — текстовые фигуры через `python-pptx` (`pptx_reader`);
      * `.pdf`/изображение — рендер в PNG + vision-распознавание в Markdown
        (`slide_renderer` + `vision_client`), нужен `vision_spec`.

    `python-pptx` нужен только PPTX-пути; импорт `pptx_reader` отложен, чтобы
    веб-эндпоинт с PDF-входом не требовал пакет ради импорта модуля.

    `client`/`vision_client` — инъекция для тестов: без неё `ChatClient`/
    `VisionClient` по умолчанию ходят в реальный эндпоинт (и кеш).

    Единый агент (`spec`) сам составляет план, обходит пункты и пишет общий
    вывод (`submit_summary`) — отдельной роли reporter больше нет.
    `vision_spec`, как и `client`, необязателен: без `vision_spec` PDF/
    изображение невозможны (но PPTX работает как раньше).

    `on_event`, необязателен (`None` — поведение не меняется) — точка
    расширения для живого прогресса веб-эндпоинта, синхронный CLI её не
    использует.
    """
    # Один прогон = один trace в Phoenix. Имя спана строится из repo+commit+
    # времени запуска, чтобы в списке трейсов прогоны различались с первого
    # взгляда и не сливались при повторных запусках того же коммита. Фазы ниже
    # (`load_plan`, `agent_session`, `find_unclaimed`, `build_model`) открывают
    # дочерние спаны внутри него.
    paths = [plan_paths] if isinstance(plan_paths, Path) else list(plan_paths)
    started_at = time.strftime("%Y%m%d_%H:%M")
    span_name = f"pko.progress · {started_at}"
    with trace_span(
        span_name,
        repo=repo_name,
        branch=target.branch,
        commit=target.sha,
        plan=", ".join(p.name for p in paths),
        model=spec.model,
        role=spec.role,
        max_steps=max_steps,
    ):
        return _run_progress(
            paths, repo_name, target, spec, client=client, max_steps=max_steps,
            on_event=on_event, vision_spec=vision_spec, vision_client=vision_client,
            stages=stages,
        )


def _run_progress(
    plan_paths: list[Path],
    repo_name: str,
    target: TargetRepo,
    spec: ModelSpec,
    client: ChatClient | None = None,
    max_steps: int = DEFAULT_MAX_STEPS,
    on_event: ProgressEvent | None = None,
    vision_spec: ModelSpec | None = None,
    vision_client: "ChatClient | None" = None,
    stages: list[str] | None = None,
) -> ProgressModel:
    """Тело пайплайна; вызывается внутри корневого `trace_span` из `run_progress`."""
    with trace_span(
        "load_plan",
        format=", ".join(sorted({p.suffix.lower() for p in plan_paths})),
        file_count=len(plan_paths),
    ) as span:
        slides = _load_slides_from_all(plan_paths, vision_spec, vision_client)
        span.set_attribute("slide_count", len(slides))
    if on_event is not None:
        on_event("presentation_parsed", {"slide_count": len(slides)})

    on_verdict = None
    on_plan = None
    on_summary = None
    if on_event is not None:
        def on_verdict(item: PlanItem, verdict: ItemVerdict) -> None:
            on_event("claim_verified", {
                "title": item.title,
                "applicable": verdict.applicable,
                "percent": verdict.percent(),
                "criteria": len(verdict.criteria),
            })

        def on_plan(plan_items: list[PlanItem]) -> None:
            on_event("plan_ready", {
                "item_count": len(plan_items),
                # `origin` — откуда взят этап: назван в презентации, задан
                # человеком при загрузке или восстановлен агентом по опорной
                # карте. Экран прогресса его не рисует, но по потоку событий
                # видно, чей это был выбор.
                "items": [{"title": p.title, "source_slide": p.source_slide,
                           "origin": p.origin, "criteria": len(p.criteria)}
                          for p in plan_items],
            })

        def on_summary(summary: ProjectSummary) -> None:
            # Экран прогресса (`AnalysisProgress`) по этому событию только
            # переключает стадию на «Формирование выводов» — текст не рендерит.
            # Полный структурированный вывод (conclusion/risks/priorities) фронт
            # берёт позже из `GET /api/analyses/{id}`; сюда отдаём conclusion как
            # text, чтобы не менять SSE-контракт ради подписи прогресса.
            on_event("summary_ready", {"text": summary.conclusion,
                                       "decision": summary.decision})

    # `agent_session` открывает свой спан внутри matcher (`_run_session`),
    # поэтому здесь обёртка не нужна — иначе получился бы двойной спан фазы.
    result = run_agent(
        slides, target.tree, spec, client=client, max_steps=max_steps,
        on_verdict=on_verdict, on_plan=on_plan, on_summary=on_summary,
        extraction=target.extraction, stages=stages,
    )
    if not result.usable:
        raise PkoError(
            "Не удалось получить пункты плана и вердикты.",
            hint="проверьте текст слайдов и доступность LLM; причина: "
                 + ("; ".join(result.notes) or "неизвестна"),
        )

    with trace_span("find_unclaimed") as span:
        unclaimed = find_unclaimed_paths(target.extraction, result.verdicts)
        span.set_attribute("unclaimed_groups", len(unclaimed))

    generated_at = time.strftime("%Y-%m-%d %H:%M")
    with trace_span("build_model") as span:
        model = ProgressModel(
            meta={
                "repo": repo_name, "branch": target.branch, "commit": target.sha,
                "plan_source": ", ".join(p.name for p in plan_paths),
                "generated_at": generated_at,
                # Поля шапки дашборда пишет агент в `submit_plan`: название
                # клиентского пути, название инициативы, кто клиент и что
                # меняется в его опыте («было → стало»).
                **result.context,
            },
            items={item.id: item for item in result.items},
            verdicts=result.verdicts,
            unclaimed=unclaimed,
            gaps=result.notes,
            readiness=result.readiness,
            summary=result.summary,
            summary_source=result.summary_source,
        )
        span.set_attribute("items", len(model.items))
        span.set_attribute("verdicts", len(model.verdicts))
        span.set_attribute("summary_source", result.summary_source)
    return model


def _load_slides_from_all(
    plan_paths: list[Path],
    vision_spec: ModelSpec | None,
    vision_client: "ChatClient | None",
):
    """Слайды всех файлов образа результата — один список со сквозной нумерацией.

    Номер слайда для агента — единственный способ сослаться на источник этапа
    (`source_slide` проверяется кодом), поэтому нумерация обязана быть сквозной
    и стабильной: два файла со «слайдом 1» сделали бы ссылку неоднозначной.
    Имя файла проставляется в `Slide.source` только когда файлов больше одного
    — при единственном оно ничего не различает и только засоряет промпт.
    """
    named = len(plan_paths) > 1
    slides = []
    for path in plan_paths:
        for slide in _load_slides(path, vision_spec, vision_client):
            slides.append(replace(
                slide,
                number=len(slides) + 1,
                source=path.name if named else "",
            ))
    return slides


def _load_slides(
    plan_path: Path,
    vision_spec: ModelSpec | None,
    vision_client: "ChatClient | None",
):
    """Разобрать план в список `Slide` по формату входа.

    PPTX — текстовые фигуры (`pptx_reader`, требует `python-pptx`).
    PDF — все страницы в PNG + отдельное vision-распознавание каждой страницы.
    Изображение — один `Slide(raw_text=...)`. Координат фигур нет, есть только
    связный распознанный текст.
    """
    suffix = plan_path.suffix.lower()

    if suffix == _PPTX_SUFFIX:
        try:
            from pko.progress.pptx_reader import read_deck
        except ImportError as exc:
            raise PkoError(
                "Не установлен python-pptx.",
                hint="поставьте пакет: pip install python-pptx>=1.0",
            ) from exc
        return read_deck(plan_path)

    if suffix in (_PDF_SUFFIX, *_IMAGE_SUFFIXES):
        return _load_slides_via_vision(plan_path, suffix, vision_spec, vision_client)

    raise PkoError(
        f"Неподдерживаемый формат плана: {plan_path.name}",
        hint=f"допустимы: {_PPTX_SUFFIX}, {_PDF_SUFFIX}, {', '.join(_IMAGE_SUFFIXES)}",
    )


def _load_slides_via_vision(
    plan_path: Path, suffix: str, vision_spec: ModelSpec | None, vision_client
):
    """PDF/изображение → PNG → vision-Markdown → один `Slide` на страницу."""
    if vision_spec is None:
        raise PkoError(
            "Вход — PDF/изображение, но vision-модель не настроена.",
            hint="задайте PKO_VISION_BASE_URL/PKO_VISION_MODEL/PKO_VISION_API_KEY "
                 "перед запуском (или используйте .pptx, который разбирается текстом)",
        )

    from pko.llm.vision_client import VisionClient
    from pko.progress.pptx_reader import Slide

    vc = vision_client if vision_client is not None else VisionClient(spec=vision_spec)

    if suffix == _PDF_SUFFIX:
        from pko.progress.slide_renderer import render_pdf_pages

        images = render_pdf_pages(plan_path)
        mime = "image/png"
    else:
        images = [plan_path.read_bytes()]
        import mimetypes
        mime = mimetypes.guess_type(plan_path.name)[0] or "image/png"

    return [
        Slide(
            number=index,
            heading=None,
            shapes=[],
            raw_text=vc.recognize(image_bytes, mime=mime),
        )
        for index, image_bytes in enumerate(images, start=1)
    ]

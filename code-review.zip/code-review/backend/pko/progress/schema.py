"""Модель пункта плана, извлечённого из презентации.

Намеренно не расширяет `pko.model.schema.PkoModel`/`PkoObject` — у них закрытый
перечень `KINDS` (§4), которым пользуется остальной PKO (`checks.validator`,
таксономия), и он не про сравнение план/факт. Вместо этого пункт плана
переиспользует уже готовую форму `Evidence`/`Field` — «значение + происхождение
+ ссылка на факт» — только источником факта здесь может быть либо слайд
презентации, либо строка кода целевого репозитория.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# Вердикт по пункту плана. Отдельный от `pko.model.schema.ORIGINS`: там —
# надёжность значения поля, здесь — состояние работы. `UNCLEAR` — честный
# результат, когда доказательств недостаточно ни на «сделано», ни на «не начато».
STATUSES = ("DONE", "PARTIAL", "NOT_STARTED", "UNCLEAR")


# Откуда взялся этап клиентского пути. Три источника, три разных уровня
# доверия к названию — и читатель отчёта обязан их различать, тем же
# принципом, что и `verified` у evidence: происхождение факта видно, а не
# растворяется в общем списке.
#
#   `slide`    — этап назван в презентации (`source_slide` > 0). Замысел команды.
#   `user`     — этап задан человеком при загрузке материалов. Тоже замысел, но
#                названный вне презентации: слайда за ним нет.
#   `restored` — этапов в презентации не было, агент собрал путь по опорной
#                карте (`standard_reference.md`). Реконструкция, а не замысел.
PLAN_ORIGINS = ("slide", "user", "restored")


@dataclass(frozen=True)
class PlanItem:
    """Один этап клиентского пути.

    `origin` — откуда взято название этапа (см. `PLAN_ORIGINS`). У `user` и
    `restored` слайда за этапом нет, поэтому `source_slide` у них всегда 0;
    единственный источник, у которого номер слайда осмыслен, — `slide`.
    """

    id: str
    title: str
    stage: str = ""
    description: str = ""
    source_slide: int = 0
    origin: str = "slide"

    def __post_init__(self) -> None:
        if self.origin not in PLAN_ORIGINS:
            raise ValueError(f"неизвестное происхождение этапа: {self.origin}")

    @property
    def restored(self) -> bool:
        """Этап восстановлен агентом, а не назван человеком.

        Отдельное имя для самого частого вопроса к `origin`: в отчёте и в
        заметках прогона важно ровно одно различие — назвал этап человек
        (слайд или ввод при загрузке) или домыслил агент."""
        return self.origin == "restored"

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "stage": self.stage,
            "description": self.description,
            "source_slide": self.source_slide,
            "origin": self.origin,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "PlanItem":
        return PlanItem(
            id=d["id"],
            title=d["title"],
            stage=d.get("stage", ""),
            description=d.get("description", ""),
            source_slide=int(d.get("source_slide") or 0),
            origin=d.get("origin", "slide"),
        )


@dataclass(frozen=True)
class EvidenceRef:
    """Одна ссылка на код, подтверждающая (или нет) пункт плана.

    `verified=False` не отбрасывается — понижается и остаётся в отчёте с
    причиной, тем же принципом, что и `pko.model.schema.Field`: утверждение без
    доказательства не публикуется как «код показывает».
    """

    path: str
    line: int | None
    basis: str
    verified: bool
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path, "line": self.line, "basis": self.basis,
            "verified": self.verified, "reason": self.reason,
        }


# Режим исполнения, тип автономного исполнения и статус завершения —
# классификации стандарта автономных процессов (см. standard_reference.md).
# Не подменяют DONE/PARTIAL/...: режим/тип/статус — служебная классификация
# этапа, а DONE/PARTIAL — его бизнес-статус. Приходят одним вызовом
# `submit_stage`, но объявлены в схеме после бизнес-полей: сначала агент
# формулирует возможность, потом классифицирует то, чем её подтвердил.
# Готовность (`ItemVerdict.progress`) выводится из режима кодом
# (`matcher.derive_progress`), а не приходит числом от модели.
EXECUTION_MODES = ("HUMAN_ONLY", "ASSIST", "CONFIRM", "AUTO")
EXECUTION_TYPES = ("PROACTIVE_ACTION", "REACTIVE_ACTION", "PROACTIVE_STATE", "REACTIVE_STATE")
COMPLETION_STATUSES = ("ACHIEVED", "CORRECTLY_HANDLED", "UNCONFIRMED")
STANDARD_OBJECT_KINDS = ("BBB", "GUARDRAIL", "HANDOFF", "METRIC")


@dataclass
class StandardObject:
    """Найденный агентом объект стандарта (BBB/guardrail/handoff/метрика) —
    привязан к коду/материалам evidence-ссылкой. Агент отмечает, какие объекты
    реализованы по этапу; отсутствие значимых объектов — риск для points."""

    kind: str
    path: str
    line: int | None
    basis: str

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind, "path": self.path, "line": self.line, "basis": self.basis}


# Доступность бизнес-возможности на этапе — три состояния, три иконки на
# дашборде (✓/◐/○). Намеренно НЕ `DONE/PARTIAL/NOT_STARTED`: «сделано/не
# сделано» — рамка проектного трекера, она заставляет и модель, и читателя
# думать о задачах разработки. Здесь единица другая — что бизнес и клиент
# могут делать на этапе сегодня, поэтому и шкала другая: доступно / доступно
# с ограничениями / пока недоступно. Без «неясно»: неопределённость живёт на
# уровне этапа целиком (`ItemVerdict.status == "UNCLEAR"`), а каждая
# отдельная возможность обязана быть конкретной.
AVAILABILITY = ("AVAILABLE", "LIMITED", "NOT_AVAILABLE")

# Кто фактически выполняет работу на этапе сегодня — шкала автономности
# стандарта (`EXECUTION_MODES`), выраженная через действующее лицо, а не через
# режим системы. Это и есть ответ на вопрос «какую бизнес-возможность даёт
# агент на этом этапе»: не «реализован автоматический вызов», а «выполняет
# агент, решение подтверждает человек».
WHO_ACTS = ("AGENT", "AGENT_WITH_CONFIRMATION", "HUMAN_WITH_AGENT", "HUMAN")


@dataclass
class StageCapability:
    """Одна бизнес-возможность этапа: что клиент или бизнес может делать здесь
    и в каких границах.

    Пришла на смену `VerdictPoint` (буллет «сделано/частично/не сделано»).
    Замена не косметическая: старая форма спрашивала у модели «что сделано»,
    и любой текст в ней читался как пункт технического бэклога, каким бы
    языком его ни написали. Новая спрашивает «что доступно и кто это делает» —
    формулировка бизнес-возможности становится единственным способом заполнить
    поле, а не пожеланием в промпте.

    `capability` — сама возможность, 4-16 слов, настоящее время: речь о людях
    и результате, а не об устройстве системы. Правило проверки уровня
    абстракции: предложение должно остаться верным, даже если завтра всю
    реализацию перепишут заново на другой технологии.

    `detail` — что стоит за возможностью сегодня: где проходит её граница, что
    происходит вместо неё, чего это стоит бизнесу. Раскрывается на дашборде по
    клику и обязан добавлять то, чего в самом тезисе нет. Раньше это поле
    называлось `limit` и означало только границу; комментарий под буллетом
    собирался кодом из шаблонной подписи `who_acts` («Выполняет агент без
    участия человека») плюс эта граница. Отсюда шли и повторы (актор был
    закодирован дважды — в тексте возможности и в `who_acts`), и прямые
    противоречия: `capability` пишется в целевой картине, а `who_acts`
    описывает сегодняшний день, и у недоступной возможности они по определению
    расходятся. Теперь комментарий пишет модель, а код проверяет, что он не
    пересказывает тезис.

    `who_acts` остаётся в модели как ось автономности (она нужна в
    `progress_model.json` и дисциплинирует разбор), но в текст комментария
    больше не подставляется.

    Сторожи (`check_explanation` + `check_business_language` + проверка на
    пересказ) проходят по `capability` и `detail` каждой возможности отдельно."""

    availability: str
    capability: str
    who_acts: str = ""
    detail: str = ""

    def __post_init__(self) -> None:
        if self.availability not in AVAILABILITY:
            raise ValueError(f"неизвестная доступность возможности: {self.availability}")
        if self.who_acts and self.who_acts not in WHO_ACTS:
            raise ValueError(f"неизвестный исполнитель возможности: {self.who_acts}")

    def to_dict(self) -> dict[str, Any]:
        return {"availability": self.availability, "capability": self.capability,
                "who_acts": self.who_acts, "detail": self.detail}


@dataclass
class ItemVerdict:
    """Вердикт агента по одному этапу клиентского пути.

    Все поля приходят одним вызовом `submit_stage`, но порядок их объявления
    в схеме инструмента — не случайность: сначала бизнес (`stage_summary`,
    `capabilities`), потом техника (`evidence`, поля стандарта). Раньше это
    были два вызова, `submit_findings` → `submit_business_verdict`, и
    бизнес-текст рождался как пересказ только что выписанной технической
    анкеты — с путями к файлам и именами функций в ближайшем контексте.
    Порядок перевёрнут: сбор фактов инструментами идёт как и раньше первым,
    а формулируется сначала возможность, и уже под неё выкладывается
    подтверждение.

    `stage_summary` — что этап значит для клиента в целевой картине (одно
    предложение, не про готовность). `capabilities` — что из этого доступно
    сегодня и в каких границах. `progress` не приходит от модели: он
    выводится кодом из `execution_mode`/`completion_status` по таблице
    справочника (`derive_progress` в matcher), чтобы цифра не расходилась с
    режимом исполнения."""

    item_id: str
    status: str
    stage_summary: str = ""
    capabilities: list[StageCapability] = field(default_factory=list)
    evidence: list[EvidenceRef] = field(default_factory=list)
    progress: int = 0
    # Техническая анкета стандарта (могут быть пустыми, если агент не смог
    # определить — тогда это должно быть видно как ограничение возможности).
    execution_mode: str = ""
    execution_type: str = ""
    completion_status: str = ""
    objects_found: list[StandardObject] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.status not in STATUSES:
            raise ValueError(f"неизвестный статус пункта плана: {self.status}")
        self.progress = max(0, min(100, int(self.progress)))

    @property
    def verified_evidence(self) -> list[EvidenceRef]:
        return [e for e in self.evidence if e.verified]

    @property
    def is_grounded(self) -> bool:
        """Есть ли у вердикта хоть одна подтверждённая ссылка.

        `DONE`/`PARTIAL` без единой проверенной evidence — это ровно то, от
        чего Gate предостерегает («PASS без доказательства не является
        результатом», §5.2.3.2): здесь вердикт не отбрасывается, но отчёт
        обязан явно показать, что он не подтверждён кодом.
        """
        return bool(self.verified_evidence)

    def to_dict(self) -> dict[str, Any]:
        return {
            "item_id": self.item_id,
            "status": self.status,
            "stage_summary": self.stage_summary,
            "capabilities": [c.to_dict() for c in self.capabilities],
            "grounded": self.is_grounded,
            "progress": self.progress,
            "evidence": [e.to_dict() for e in self.evidence],
            "execution_mode": self.execution_mode,
            "execution_type": self.execution_type,
            "completion_status": self.completion_status,
            "objects_found": [o.to_dict() for o in self.objects_found],
        }


@dataclass(frozen=True)
class UnclaimedGroup:
    """Группа файлов кода, не подтвердивших ни одного пункта плана.

    Не вердикт «сделано сверх плана» — только сырой кандидат для него.
    Детерминированная разница множеств, без суждения модели: решить, действительно
    ли это дополнительная работа, а не инфраструктура или чужой периметр, может
    только человек, читающий отчёт.
    """

    group: str
    example_paths: list[str]
    file_count: int

    def to_dict(self) -> dict[str, Any]:
        return {"group": self.group, "example_paths": self.example_paths,
                "file_count": self.file_count}


@dataclass(frozen=True)
class ProjectSummary:
    """Структурированный общий вывод по проекту — три независимых поля, не
    один сплошной текст. Так их и рендерит дашборд (`ProjectSummaryPanel`):
    общий вывод / ключевые риски / что реализовать в первую очередь.

    Поля не должны повторять друг друга: `conclusion` — 2-3 предложения до 60
    слов (где проект в целом и главный барьер), `risks` — до 3 рисков,
    `priorities` — до 3 действий, каждый пункт до 140 символов и с
    последствием («ручное решение — ограничивает объём выдач»). Прежний лимит
    в 4 слова на пункт давал обрубок вида «Нет автоматического скоринга»:
    словосочетание без последствия читается как строка бэклога, а не как риск
    для бизнеса, — поэтому лимит измеряется символами, а не словами. Границы
    выдерживает `_accept_summary` в `matcher.py` нормализацией после сторожа.
    Пустые `risks`/`priorities` допустимы, если агент не нашёл рисков/
    приоритетов. `None` у `ProgressModel.summary` в целом — вывод не
    сформирован."""

    conclusion: str = ""
    risks: list[str] = field(default_factory=list)
    priorities: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {"conclusion": self.conclusion,
                "risks": list(self.risks), "priorities": list(self.priorities)}


@dataclass
class ProgressModel:
    """Итоговая модель одного прогона: план, вердикты, кандидаты сверх плана."""

    meta: dict[str, Any] = field(default_factory=dict)
    items: dict[str, PlanItem] = field(default_factory=dict)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    unclaimed: list[UnclaimedGroup] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    # Структурированный общий вывод агента (`submit_summary`) по итогам всех
    # пунктов — три поля, см. `ProjectSummary`. `None` — вывод не сформирован
    # (роль не вызывала submit_summary или сторож отклонил). `summary_source`
    # ("llm"/"none") — то же различие авторства, что и у остальных текстов PKO:
    # читатель должен видеть, что перед ним — написанное моделью или ничего.
    summary: ProjectSummary | None = None
    summary_source: str = "none"

    def counts(self) -> dict[str, int]:
        out = {status: 0 for status in STATUSES}
        for v in self.verdicts:
            out[v.status] = out.get(v.status, 0) + 1
        return out

    def progress_ratio(self) -> float:
        """Доля DONE среди всех пунктов плана; PARTIAL не засчитывается наполовину.

        Округление в пользу пункта — искажение в другую сторону: отчёт о
        прогрессе не должен выглядеть более готовым, чем показывает код.
        """
        total = len(self.verdicts)
        if not total:
            return 0.0
        return self.counts().get("DONE", 0) / total

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "pko-progress-model/0.1",
            "meta": self.meta,
            "counts": self.counts(),
            "progress_ratio": round(self.progress_ratio(), 4),
            "items": {item_id: item.to_dict() for item_id, item in self.items.items()},
            "verdicts": [v.to_dict() for v in self.verdicts],
            "unclaimed": [u.to_dict() for u in self.unclaimed],
            "gaps": self.gaps,
            "summary": self.summary.to_dict() if self.summary else None,
            "summary_source": self.summary_source,
        }

    def to_json(self) -> str:
        import json

        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2, sort_keys=False)

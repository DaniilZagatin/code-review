"""Рендер всех страниц PDF в PNG для vision-распознавания.

Единственный внешний инструмент — `pdftoppm` (poppler-utils). headless office
(LibreOffice/Collabora) на целевой машине падает в headless-режиме, а `pdftoppm`
работает без GUI и прав на ptrace. Это и весь нужный путь: страницы PDF → PNG →
vision-модель. Каждая страница становится отдельным слайдом; порядок страниц
сохраняется.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from pko.errors import PkoError

DEFAULT_DPI = 150
DEFAULT_TIMEOUT = 60

# `pdftoppm` — единственная разрешённая команда; жёстко, без списка аргументов:
# флаги фиксированы внутри функции, внешний ввод в argv не попадает.
_RENDERER = "pdftoppm"


def render_pdf_pages(
    pdf_path: str | Path,
    dpi: int = DEFAULT_DPI,
    timeout: int = DEFAULT_TIMEOUT,
) -> list[bytes]:
    """Отрендерить все страницы PDF и вернуть PNG-байты в исходном порядке.

    Каждый элемент результата готов для отдельного вызова
    `VisionClient.recognize`. Поднимает
    `PkoError` с человекочитаемой причиной, если `pdftoppm` нет, он не уложился
    в таймаут или вернул ошибку — рендер не должен выходить трассой стека.
    """
    pdf = Path(pdf_path)
    if not pdf.exists():
        raise PkoError(
            f"PDF не найден: {pdf}",
            hint="проверьте путь к файлу плана",
        )

    import tempfile
    with tempfile.TemporaryDirectory(prefix="pko-render-") as tmp:
        prefix = Path(tmp) / "slide"
        try:
            proc = subprocess.run(
                [_RENDERER, "-png", "-r", str(dpi), str(pdf), str(prefix)],
                capture_output=True, text=True, errors="replace",
                timeout=timeout, check=False,
            )
        except FileNotFoundError as exc:
            raise PkoError(
                "pdftoppm не установлен — рендер PDF в PNG невозможен.",
                hint="установите poppler-utils (apt-get install poppler-utils)",
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise PkoError(
                f"рендер PDF не уложился в {timeout} с.",
                "файл слишком большой или pdftoppm завис — увеличьте timeout или проверьте PDF.",
            ) from exc

        if proc.returncode != 0:
            raise PkoError(
                "Рендер PDF не удался.",
                hint=(proc.stderr or proc.stdout).strip()[:400]
                or f"pdftoppm завершился с кодом {proc.returncode}",
            )

        pages = sorted(
            Path(tmp).glob("slide-*.png"),
            key=_page_number,
        )
        if not pages:
            raise PkoError(
                "Рендер PDF не создал ни одной PNG-страницы.",
                hint="возможно, PDF пустой или повреждён",
            )
        return [page.read_bytes() for page in pages]


def _page_number(path: Path) -> int:
    """Число в имени `slide-001.png`, чтобы 10-я страница не встала перед 2-й."""
    try:
        return int(path.stem.rsplit("-", 1)[1])
    except (IndexError, ValueError):
        return 0


def render_pdf_first_page(
    pdf_path: str | Path,
    dpi: int = DEFAULT_DPI,
    timeout: int = DEFAULT_TIMEOUT,
) -> bytes:
    """Совместимый помощник для прежних вызовов: вернуть первую страницу."""
    return render_pdf_pages(pdf_path, dpi=dpi, timeout=timeout)[0]

"""Реестр моделей: роли пайплайна прогресса.

Ключи берутся только из переменных окружения и никогда не сохраняются в
отчётах, кеше и логах.

Роли:
  * `matcher`  — единый агент: текст слайдов PPTX + инструменты поиска по коду
                 → план пунктов, вердикты по ним и общий вывод, за одну сессию;
  * `vision`   — распознавание слайда (PNG→Markdown) отдельной vision-моделью,
                 когда вход — PDF/изображение, а не PPTX с текстовыми фигурами.

`matcher` по умолчанию использует общие `PKO_ASSEMBLER_*` (унаследованное
имя — исторически это была роль сборщика в другом инструменте; здесь это просто
общий дефолт для «вернуть текст/JSON по структурированному входу», чтобы роль
работала сразу на одной уже настроенной паре endpoint/ключ).
`PKO_MATCHER_*` переопределяет его, если нужна другая модель. Роль `reporter`
больше не существует — общий вывод пишет сам агент (`submit_summary`) в той же
сессии. `vision` не наследует `PKO_ASSEMBLER_*` — vision-эндпоинт физически
другой (свой inference-сервер с vision-бэкендом), и настраивается отдельными
`PKO_VISION_*`; без неё PDF-вход невозможен, PPTX-вход работает как раньше.

Endpoint роли можно переопределить с командной строки, но ключ берётся только
из переменной окружения: значение, переданное флагом, осело бы в истории
оболочки и в списке процессов.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from pko.errors import PkoError

# Для каждой роли: (переменная base_url, переменная модели, переменная ключа).
_ENV = {
    "matcher": {
        "base_url": ("PKO_MATCHER_BASE_URL", "PKO_ASSEMBLER_BASE_URL", "GLM_52_API", "GLM_51_API"),
        "model": ("PKO_MATCHER_MODEL", "PKO_ASSEMBLER_MODEL", "GLM_MODEL_NAME"),
        "api_key": ("PKO_MATCHER_API_KEY", "PKO_ASSEMBLER_API_KEY", "GLM_API_KEY"),
        "default_model": "GLM-5.2",
    },
    # Vision: распознавание слайда (PDF/изображение → PNG → Markdown) отдельной
    # vision-моделью (Qwen3-Omni и т.п.). Не наследует PKO_ASSEMBLER_*:
    # vision-эндпоинт физически другой (свой inference-сервер с vision-бэкендом),
    # общий дефолт текстовой модели тут бесполезен и даже вреден — отправил бы
    # картинку в текстовую инстанцию, которая её не примет.
    "vision": {
        "base_url": ("PKO_VISION_BASE_URL",),
        "model": ("PKO_VISION_MODEL",),
        "api_key": ("PKO_VISION_API_KEY",),
        "default_model": "qwen-omni",
    },
}


@dataclass(frozen=True)
class ModelSpec:
    role: str
    base_url: str
    model: str
    api_key: str
    extra_body: dict[str, Any] | None = None

    @property
    def upstream_model(self) -> str:
        """DeepSeek-endpoint игнорирует имя модели — если роль сконфигурирована под него."""
        return "" if "deep" in self.model.lower() else self.model

    def masked(self) -> dict[str, str]:
        return {"role": self.role, "base_url": self.base_url, "model": self.model,
                "api_key": "<задан>" if self.api_key else "<пусто>"}


def get_spec(
    role: str,
    thinking: bool | None = None,
    base_url: str = "",
    model: str = "",
    api_key_env: str = "",
) -> ModelSpec | None:
    """Вернуть настройки роли или None, если endpoint нигде не задан.

    `base_url` и `model` приходят с командной строки и имеют приоритет над
    окружением. `api_key_env` — имя переменной, а не сам ключ: значение во флаге
    попало бы в историю оболочки и в вывод `ps`.

    `thinking` — включить рассуждение (reasoning_content). `None` — взять из
    env `PKO_THINKING` (по умолчанию выключено). Рассуждающие модели (GLM-5.2,
    DeepSeek-R1, Qwen-QwQ и т.п.) без явного флага работают в своём режиме по
    умолчанию — для GLM это thinking-on, для остальных обычно thinking-off.
    Явное `thinking=True` ставит `enable_thinking=True` в `chat_template_kwargs`,
    `thinking=False` — `enable_thinking=False`. Не все эндпоинты поддерживают
    `chat_template_kwargs` — если эндпоинт его не принимает, оставьте
    `PKO_THINKING` пустым, тогда `extra_body` не формируется вовсе.
    """
    conf = _ENV.get(role)
    if not conf:
        raise ValueError(f"неизвестная роль модели: {role}")

    base_url = (base_url or "").strip() or _first_env(conf["base_url"])
    if not base_url:
        return None

    model = (model or "").strip() or _first_env(conf["model"]) or conf["default_model"]
    if api_key_env:
        # Оператор назвал переменную явно. Если она пуста, молчаливый откат
        # отправил бы ключ внутреннего контура на чужой endpoint — это утечка,
        # а не удобство. Лучше остановиться и сказать, чего не хватает.
        api_key = (os.environ.get(api_key_env) or "").strip()
        if not api_key:
            raise PkoError(
                f"переменная окружения {api_key_env} пуста или не задана",
                hint=f"экспортируйте ключ перед запуском: export {api_key_env}=...",
            )
    else:
        api_key = _first_env(conf["api_key"]) or "not-needed"

    # thinking: явный аргумент > env PKO_THINKING > False (по умолчанию).
    if thinking is None:
        thinking = os.environ.get("PKO_THINKING", "").lower() in ("1", "true", "yes", "on")

    extra: dict[str, Any] | None = None
    if thinking:
        # Рассуждение включено. Большинство OpenAI-совместимых инференс-серверов
        # (sglang, vLLM) принимают `chat_template_kwargs.enable_thinking`.
        extra = {"chat_template_kwargs": {"enable_thinking": True}}
    elif "glm" in model.lower():
        # GLM-5.2 — рассуждающая модель: thinking включён по умолчанию и
        # съедает весь max_tokens в reasoning_content, оставляя content
        # пустым (агент падает с «пустой ответ»). Для агентского цикла
        # без явного PKO_THINKING=true рассуждение не нужно — агент «думает»
        # инструментами по шагам, а отключённый thinking даёт надёжный
        # content/tool_calls и ответ за <1с вместо ~40с на шаг.
        extra = {"chat_template_kwargs": {"enable_thinking": False}}
    # Для остальных моделей без явного thinking: extra_body не формируется —
    # эндпоинт работает в своём режиме по умолчанию (обычно thinking-off).

    return ModelSpec(role=role, base_url=base_url.rstrip("/"), model=model,
                     api_key=api_key, extra_body=extra)


def _first_env(names: tuple[str, ...]) -> str:
    for name in names:
        value = os.environ.get(name)
        if value:
            return value.strip()
    return ""

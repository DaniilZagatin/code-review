"""Vision-клиент: PNG-байты → Markdown через OpenAI-совместимый vision-эндпоинт.

Qwen3-Omni и подобные принимают изображение инлайном как `data:`-URL внутри
`image_url` (отдельной загрузки файла нет). Распознавание слайда —
детерминированная задача, поэтому `temperature=0` и `enable_thinking=False`:
рассуждение здесь не нужно, а без него `content` надёжнее и ответ приходит
за секунды, а не десятки секунд.

Транспорт и повтор транзитных 404/503 унаследованы от `ChatClient` —
vision-эндпоинт на том же sglang-стеке флапает так же, пока модель грузится.
Кеш намеренно отключён: payload с инлайн-картинкой весит мегабайты, а
распознавание одного слайда вызывается один раз за прогон — кеш не окупает
ни места на диске, ни риска вернуть устаревший текст при смене модели.
"""

from __future__ import annotations

import base64
from typing import Any

from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec

# Форматы, которые имеет смысл слать vision-модели инлайном. PDF/PPTX сюда не
# годятся — их сначала рендерят в PNG (см. `progress/slide_renderer.py`).
IMAGE_EXTENSIONS = (".bmp", ".jpeg", ".jpg", ".png", ".tif", ".tiff")

# Распознавание таблицы на плотном слайде может быть длинным; обрыв по длине
# виден в `finish_reason` и диагностируется `_text_of` как пустой ответ.
DEFAULT_VISION_MAX_TOKENS = 4096

_SYSTEM_PROMPT = (
    "Ты распознаёшь слайд презентации и возвращаешь его содержимое в Markdown. "
    "Числа переноси дословно, таблицы оформляй Markdown-таблицами, ничего не додумывай."
)
_USER_PROMPT = "Распознай слайд: заголовок, все поля карточек/таблиц, подписи."


class VisionClient(ChatClient):
    """Распознавание изображения слайда в Markdown. `spec` — роль `vision`."""

    def __init__(self, spec: ModelSpec) -> None:
        # Кеш отключён: картинка в payload делает ключ огромным, а один прогон
        # = один вызов vision — экономить нечего, зато нет риска отдать текст
        # от прошлой модели после смены эндпоинта.
        super().__init__(spec=spec, use_cache=False)

    def recognize(
        self,
        image_bytes: bytes,
        mime: str = "image/png",
        system: str = _SYSTEM_PROMPT,
        user: str = _USER_PROMPT,
        max_tokens: int = DEFAULT_VISION_MAX_TOKENS,
    ) -> str:
        """Распознать слайд (PNG/JPEG-байты) → Markdown-строка.

        Поднимает `LlmError` при пустом ответе (модель не увидела картинку —
        типичный сигнал, что эндпоинт текстовый, не vision) или сетевом сбое.
        """
        encoded = base64.b64encode(image_bytes).decode("ascii")
        payload: dict[str, Any] = {
            "model": self.spec.upstream_model,
            "temperature": 0.0,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": [
                    {"type": "text", "text": user},
                    {"type": "image_url", "image_url": {
                        "url": f"data:{mime};base64,{encoded}",
                        "detail": "high",
                    }},
                ]},
            ],
        }
        # thinking выключен для всех vision-моделей: рассуждение не нужно,
        # а у thinking-моделей (Qwen3-Omni-...-Thinking) без этого флага
        # `content` пустой — бюджет уходит в reasoning_content.
        extra_body = {"chat_template_kwargs": {"enable_thinking": False}}

        data = self._create(payload, extra_body=extra_body)
        # `_text_of` уже поднимает LlmError при пустом content (finish_reason
        # и причина в hint) — дублировать проверку здесь не нужно.
        return self._text_of(data)


def is_supported_image(path: str) -> bool:
    """Допустимое расширение для прямой подачи в vision (без рендера)."""
    return path.lower().endswith(IMAGE_EXTENSIONS)

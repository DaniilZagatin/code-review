"""Phoenix tracing: один trace на весь прогон агента со структурой спанов.

Иерархия (см. `pipeline.run_progress` и `matcher._run_session`):

  pko.progress            ← корневой спан прогона (repo, branch, commit, plan, model)
  ├── load_plan           ← парсинг PPTX/PDF/изображения
  ├── agent_session       ← агентский цикл
  │   ├── agent.step.1    ← шаг: LLM-вызов + reasoning + tool_calls
  │   │   └── [auto] LLM  ← Phoenix auto_instrument по chat.completions.create
  │   ├── agent.step.2
  │   ...
  ├── find_unclaimed
  └── build_model

`init_phoenix_tracing` должна отработать ДО создания любого OpenAI-клиента:
`register(auto_instrument=True)` перехватывает вызовы `chat.completions.create`
и строит по ним LLM-спаны, дочерние к текущему контексту. `trace_span` —
no-op, если трассировка выключена, поэтому код пайплайна не зависит от того,
идёт ли сбор трейсов.
"""

import logging
import os
from contextlib import contextmanager
from typing import Any, Iterator, Optional

logger = logging.getLogger(__name__)


class _NoopSpan:
    """Заглушка для режима без трассировки: методы ничего не делают.

    Даёт коду пайплайна единый интерфейс `set_attribute`/`record_error`
    независимо от того, включён ли Phoenix — не нужно ветвить логику.
    """

    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def record_error(self, exc: BaseException) -> None:
        pass


class _SpanHandle:
    """Тонкая обёртка над OTel-спаном: глотает ошибки наблюдаемости.

    Атрибуты и статусы — метаданные; ронять прогон ради них нельзя.
    """

    def __init__(self, span: Any) -> None:
        self._span = span

    def set_attribute(self, key: str, value: Any) -> None:
        if value is None:
            return
        try:
            self._span.set_attribute(key, value)
        except Exception:
            pass

    def record_error(self, exc: BaseException) -> None:
        try:
            from opentelemetry.trace import Status, StatusCode
            self._span.record_exception(exc)
            self._span.set_status(Status(StatusCode.ERROR, str(exc)))
        except Exception:
            pass

# Tracer из Phoenix/OTel. None, если трассировка выключена или не
# инициализирована — в этом режиме `trace_span` работает как no-op,
# и код пайплайна не замечает отсутствия наблюдаемости.
_tracer: Optional[object] = None
# True после любой попытки инициализации (успех/отказ/выключено).
# Защищает от повторного `register`, который подменит global tracer provider.
_initialized: bool = False


def init_phoenix_tracing() -> Optional[object]:
    """Initialize Phoenix OpenTelemetry tracing for LLM calls.

    Returns tracer_provider if initialized, None if disabled or failed.
    Must be called before any OpenAI client creation.
    """
    global _tracer, _initialized

    if _initialized:
        return None

    enabled = os.environ.get("PKO_PHOENIX_ENABLED", "").lower() in ("1", "true", "yes", "on")
    if not enabled:
        logger.info("Phoenix tracing disabled via PKO_PHOENIX_ENABLED")
        _initialized = True
        return None

    try:
        from phoenix.otel import register

        host = os.environ.get("PKO_PHOENIX_HOST", "localhost")
        port = int(os.environ.get("PKO_PHOENIX_PORT", "6006"))
        endpoint = os.environ.get("PKO_PHOENIX_ENDPOINT") or f"http://{host}:{port}/v1/traces"
        project = os.environ.get("PKO_PHOENIX_PROJECT", "pko-progress")

        tracer_provider = register(
            project_name=project,
            endpoint=endpoint,
            auto_instrument=True,
            set_global_tracer_provider=True,
        )
        _tracer = tracer_provider.get_tracer("pko")
        _initialized = True

        logger.info(
            "Phoenix tracing initialized | project=%s | endpoint=%s",
            project, endpoint,
        )
        return tracer_provider

    except ImportError:
        logger.warning(
            "arize-phoenix not installed — tracing disabled. "
            "Install with: pip install arize-phoenix"
        )
        _initialized = True
        return None
    except Exception as e:
        logger.error("Failed to initialize Phoenix tracing: %s", e)
        _initialized = True
        return None


@contextmanager
def trace_span(name: str, **attributes: Any) -> Iterator[Any]:
    """Открыть именованный спан с атрибутами. No-op, если трассировка выключена.

    Все LLM-вызовы (автоинструментированные Phoenix) и дочерние `trace_span`
    внутри блока становятся дочерними к этому спану — так выстраивается
    иерархия одного trace. Атрибуты из `**attributes` ставятся при открытии;
    донастроить спан после выполнения фазы можно через возвращаемый хэндл:

        with trace_span("load_plan", format=".pptx") as span:
            slides = parse(...)
            span.set_attribute("slide_count", len(slides))

    Исключение внутри блока помечается на спане (`record_error`) и
    пробрасывается дальше — трассировка не глотает ошибки.
    """
    if _tracer is None:
        yield _NoopSpan()
        return

    with _tracer.start_as_current_span(name) as span:
        handle = _SpanHandle(span)
        for key, value in attributes.items():
            handle.set_attribute(key, value)
        try:
            yield handle
        except Exception as exc:
            handle.record_error(exc)
            raise

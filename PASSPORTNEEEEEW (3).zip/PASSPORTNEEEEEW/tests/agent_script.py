"""Заготовки вызовов агента для сквозных тестов (CLI, веб, пайплайн).

Сценарий: оценка этапа → вердикт → finish. submit_plan больше нет — план
разбирается кодом из текстового поля, агент только проверяет пункты.
"""

import json

CLIENT_PATH_NAME = "Постановка задачи в работу"
PROJECT_NAME = "Редизайн платёжного сервиса"
BEFORE = "задача пересылается вручную и теряется между сменами"
NOW = "задача видна в системе, но без автоматической маршрутизации"
AFTER = "задача попадает исполнителю сразу и видна обеим сторонам"

DESCRIPTION = (
    "Раньше задачи пересылались вручную и терялись между сменами. Теперь "
    "задача попадает исполнителю сразу и видна обеим сторонам."
)

STAGE_ID = "postanovka-zadach"
STAGE_TITLE = "Постановка задач"
STAGE_DESCRIPTION = "Клиент передаёт задачу в работу и видит её статус без звонка"
BULLETS = ["Определены источники обращений", "Подтверждена скорость обработки"]

CONCLUSION = [
    "Ценность подтверждена материалами",
    "Измеримость результата не закрыта",
    "Можно идти дальше",
]

ROUTER_EVIDENCE = [{"path": "backend/src/api/v1/router.py", "line": 7,
                    "basis": "функция start_task ставит задачу в обработку"}]

CONTEXT = {
    "client_path_name": CLIENT_PATH_NAME,
    "project_name": PROJECT_NAME,
    "before": BEFORE,
    "now": NOW,
    "after": AFTER,
}

JOURNEY_TEXT = "\n".join([
    f"Клиентский путь: {CLIENT_PATH_NAME}",
    f"Проект: {PROJECT_NAME}",
    f"Было: {BEFORE}",
    f"Сейчас: {NOW}",
    f"Стало: {AFTER}",
    "",
    f"## {STAGE_TITLE}",
    f"- {BULLETS[0]}",
    f"- {BULLETS[1]}",
])


def tool_call(call_id: str, name: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": call_id, "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


# Раскрытие пункта — два буллита человеческим языком. Ссылок на репозиторий
# в тексте нет намеренно: их отклоняет гейт, потому что в отчёт они не идут.
# Для не-зелёных статусов «Проверка» обязана быть развёрнутой: что похожее
# нашлось и чего именно из буллита не нашлось. Короче 120 символов гейт такую
# оценку не принимает — заглушки написаны так же, как их писал бы агент.
PROOF = {
    "done": "Код есть и работает: путь от заявки до обработки проходит целиком.",
    "limited": (
        "Приём заявок и передача исполнителю работают. Ограничение в том, что "
        "обрабатываются не все типы обращений: часть уходит в общую очередь и "
        "дальше её ведут вручную."
    ),
    "unused": (
        "Код передачи заявки исполнителю написан и рабочий, обходится без "
        "ручных шагов. В текущем сценарии до него не доходит очередь: вызова "
        "из рабочего пути нет."
    ),
    "partial": (
        "Регистрация заявки в системе есть и работает. Дальнейшей передачи "
        "исполнителю не нашлось: после регистрации заявка остаётся в списке, "
        "и сквозной путь не отрабатывает."
    ),
    "planned": (
        "Похожего в коде нашлась только регистрация обращения без дальнейшей "
        "обработки. Ни маршрутизации по исполнителям, ни уведомления сторон "
        "не нашлось: этого в коде нет."
    ),
    "blocked": (
        "Код приёма заявки есть и работает, но результат дальше не уходит: "
        "следующий шаг пути ждёт его и без него не начинается."
    ),
}
HOW = {
    "done": "Заявка попадает исполнителю сразу, обе стороны видят её статус.",
    "limited": "Заявка доходит до исполнителя, кроме отдельных случаев.",
    "unused": "Функция готова, но её никто не вызывает.",
    "partial": "Заявка регистрируется, дальше её ведут руками.",
    "planned": "Пока делается вручную.",
    "blocked": "Дальше по пути ничего не происходит.",
}


def stage_args(item_id: str = STAGE_ID, applicable: bool = True,
               statuses: list[str] | None = None,
               evidence: list[dict] | None = None) -> dict:
    statuses = statuses or ["done", "planned"]
    criteria = []
    for status in statuses:
        row: dict = {
            "applicable": True, "status": status,
            "proof": PROOF.get(status, ""), "how": HOW.get(status, ""),
        }
        if status != "planned":
            row["evidence"] = ROUTER_EVIDENCE if evidence is None else evidence
        criteria.append(row)
    return {"item_id": item_id, "applicable": applicable, "criteria": criteria}


# Верхнеуровневая оценка целого: её модель присылает сама, в отличие от
# готовности и решения — те считает код.
MATCH = "mostly"
MATCH_NOTE = (
    "Система принимает файл модели и считает по нему сценарии, "
    "а готовых форм под материалы сделки в ней пока нет."
)


def summary_args(
    decision: str = "PIVOT",
    match: str = MATCH,
    match_note: str = MATCH_NOTE,
) -> dict:
    # `decision` модель больше не присылает — решение считает код. Параметр
    # оставлен, чтобы сценарии тестов не переписывать под каждый вызов.
    return {
        "conclusion": list(CONCLUSION),
        "match": match,
        "match_note": match_note,
    }


def brief_args(before: str = BEFORE, now: str = NOW, after: str = AFTER) -> dict:
    return {"before": before, "now": now, "after": after}


def critic_session(*challenges: dict) -> list[dict]:
    """Сессия рецензента (`progress.critic`): понижения и `finish`.

    Идёт после `finish` первого агента из той же очереди ответов. Без
    понижений — один `finish`: рецензент прошёл список и претензий не нашёл.
    """
    calls = [
        tool_call(f"call_challenge_{i}", "submit_challenge", **challenge)
        for i, challenge in enumerate(challenges, start=1)
    ]
    calls.append(tool_call("call_critic_finish", "finish"))
    return calls


# Ревизия связности (`progress.coherence`): сквозной путь, изъяны, уровень.
# Заглушки написаны так же, как их писал бы ревизор: тексты без кода, изъян с
# проверенной ссылкой, уровень согласован со списком изъянов.
FLOW = {
    "entry": "Запрос на постановку задачи приходит от клиента",
    "steps": [
        "Система регистрирует заявку",
        "Заявка уходит исполнителю",
    ],
    "outcome": "Исполнитель видит задачу, клиент видит статус",
    "complete": True,
    "evidence": ROUTER_EVIDENCE,
}
INTEGRITY_NOTE = (
    "Система принимает заявку и доводит её до исполнителя: сквозной путь "
    "проходит целиком, части соединены между собой."
)


def flow_args(**over) -> dict:
    args = {**FLOW, "evidence": list(ROUTER_EVIDENCE)}
    args.update(over)
    return args


SYSTEM_DOES = (
    "Система принимает заявку от клиента, регистрирует её и передаёт "
    "исполнителю: на вход приходит обращение, на выходе исполнитель видит "
    "задачу, а клиент — её статус. По сути это сервис маршрутизации обращений "
    "между клиентом и исполнителем, работающий без участия диспетчера."
)
SYSTEM_NOT_DOES = (
    "Расхождений с замыслом не нашлось: обещанная передача заявки исполнителю "
    "и видимость статуса обеими сторонами в коде есть и работают."
)


def system_args(**over) -> dict:
    args = {"does": SYSTEM_DOES, "not_does": SYSTEM_NOT_DOES,
            "verdict": "same_purpose", "evidence": list(ROUTER_EVIDENCE)}
    args.update(over)
    return args


# Сквозная связность: целевые сценарии из ОР и стыки. Один сценарий на два
# шага с одним стыком, подтверждённым тремя обязательными проверками —
# статус «собран». `SCENARIO_BROKEN` — тот же сценарий с разрывом на стыке.
SCENARIO = {
    "title": "Постановка задачи исполнителю",
    "entry": "Клиент передаёт задачу в систему",
    "outcome": "Исполнитель видит задачу, клиент — её статус",
    "steps": ["Система регистрирует заявку", "Заявка уходит исполнителю"],
    "critical": True,
    "bullets": [BULLETS[0]],
}


def _checks(result: str = "ok", note: str = "") -> list[dict]:
    return [
        {"check": check, "result": result, "note": note, "evidence": list(ROUTER_EVIDENCE)}
        for check in ("reachability", "contract", "data_continuity")
    ]


def scenarios_args(*scenarios: dict) -> dict:
    return {"scenarios": [dict(s) for s in (scenarios or (SCENARIO,))]}


def trace_args(scenario_id: str = "scenario-1", result: str = "ok",
               note: str = "", kind: str = "call") -> dict:
    return {"scenario_id": scenario_id,
            "handoffs": [{"step": 0, "kind": kind, "checks": _checks(result, note)}]}


def coherence_session(*flaws: dict, flow: dict | None = None,
                      system: dict | None = None,
                      scenarios: dict | None = None,
                      traces: list[dict] | None = None,
                      level: str = "coherent", note: str = INTEGRITY_NOTE) -> list[dict]:
    """Сессия ревизора связности: что делает система → целевые сценарии →
    стыки → путь → изъяны → уровень → finish.

    Идёт после сессии рецензента. `scenarios=False` — сценарии не
    объявляются (finish тогда отклоняется).
    """
    calls = [tool_call("call_system", "submit_system", **(system or system_args()))]
    if scenarios is not False:
        calls.append(tool_call("call_scenarios", "submit_scenarios", **(scenarios or scenarios_args())))
        for i, trace in enumerate(traces if traces is not None else [trace_args()], start=1):
            calls.append(tool_call(f"call_trace_{i}", "submit_trace", **trace))
    calls.append(tool_call("call_flow", "submit_flow", **(flow or flow_args())))
    calls.extend(
        tool_call(f"call_flaw_{i}", "submit_flaw", **flaw)
        for i, flaw in enumerate(flaws, start=1)
    )
    calls.append(tool_call("call_integrity", "submit_integrity", level=level, note=note))
    calls.append(tool_call("call_coherence_finish", "finish"))
    return calls


# Паспортная сессия (`progress.passport_agent`): дерево сверху вниз — путь →
# процесс → BBB → операции, затем потребность и ограничение. Идёт последней,
# после ревизии связности. Уровни обоснования в `source` — те, которые
# требует гейт: «Установлено» только с привязкой к коду.
PASSPORT_OWNER = "Требует подтверждения владельца: владелец продукта, назначение вне кода"
PASSPORT_EST = "Установлено: backend/src/api/v1/router.py, start_task — ставит задачу в обработку"


def passport_node(node_id: str, name: str, basis: str, fields: dict, **extra) -> dict:
    # Не через `tool_call`: у него свой позиционный `name` (имя инструмента).
    args = {"id": node_id, "name": name, "basis": basis, "fields": fields, **extra}
    return {"content": None, "tool_calls": [{
        "id": f"call_{node_id}", "type": "function",
        "function": {"name": "submit_node", "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


def passport_children(parent: str, *children: tuple[str, str]) -> dict:
    return tool_call(f"call_children_{parent}", "declare_children", parent=parent,
                     children=[{"name": n, "basis": b} for n, b in children])


def passport_session() -> list[dict]:
    """Обход сверху вниз: путь → процесс → 2 BBB → операции → потребность →
    ограничение → finish."""
    proc = {
        "4.3.3": {"value": "Предложение: владелец продукта", "source": PASSPORT_OWNER},
        "4.3.6": {"value": "Приём — AUTO; передача исполнителю — CONFIRM.",
                  "source": "Выведено: маршрутизация ждёт подтверждения"},
        "4.3.8": {"value": "Не установлено: передачи человеку нет.", "source": "Не установлено"},
    }
    bbb = {"4.4.1": {"value": "Одно бизнес-действие.", "source": PASSPORT_EST}}
    op = {"4.5.1": {"value": "Шаг с наблюдаемым результатом.", "source": PASSPORT_EST}}
    # Привязка узлов к пунктам ОР и шагам сценария scenario-1 из
    # `coherence_session`: по ней код красит схему и рисует путь.
    return [
        # Модель пытается переименовать корень: код оставляет название из
        # образа результата (`CLIENT_PATH_NAME`) и принимает узел.
        passport_node("journey-1", "Путь, как его назвала модель", "путь из образа результата",
                      {"4.2.3": {"value": "Предложение: владелец процесса", "source": PASSPORT_OWNER}},
                      decision_boundary="END_TO_END_PROCESS"),
        passport_children("journey-1", ("Приём и маршрутизация задачи", "сценарий со своим входом")),
        passport_node("process-1", "Приём и маршрутизация задачи", "сценарий со своим входом", proc),
        passport_children("process-1", ("Регистрация обращения", "фиксирует задачу"),
                          ("Передача исполнителю", "выбирает исполнителя")),
        passport_node("bbb-1", "Регистрация обращения", "фиксирует задачу", bbb,
                      bullets=[BULLETS[0]], scenario_steps=[{"scenario": "scenario-1", "step": 0}]),
        passport_children("bbb-1", ("Запись задачи", "запись в хранилище")),
        passport_node("operation-1", "Запись задачи", "запись в хранилище", op),
        passport_node("bbb-2", "Передача исполнителю", "выбирает исполнителя", bbb,
                      bullets=[BULLETS[1]], scenario_steps=[{"scenario": "scenario-1", "step": 1}]),
        passport_children("bbb-2", ("Назначение исполнителя", "внешний эффект — уведомление")),
        passport_node("operation-2", "Назначение исполнителя", "внешний эффект — уведомление", op),
        passport_node("need-1", "Передать задачу и знать её судьбу", "существует до продукта",
                      {"4.1.1": {"value": "Клиент хочет, чтобы задача дошла до исполнителя без звонков.",
                                 "source": "Требует подтверждения владельца: аналитика обращений"}},
                      journeys=["journey-1"]),
        passport_node("guardrail-1", "Задача не назначается без исполнителя", "исполняемая проверка",
                      {"4.6.8": {"value": "DENY — назначение отклоняется.", "source": PASSPORT_EST}},
                      scope=["bbb-2"]),
        tool_call("call_finish_passport", "finish"),
    ]


def full_session(**kwargs) -> list[dict]:
    """Полный сценарий: brief (из описания) → оценка этапа → контр-проверка →
    вердикт → finish → сессия рецензента (`critic`) → ревизия связности
    (`coherence`) → паспортная сессия (`passport`). Рецензент и ревизор по
    умолчанию без претензий; `passport=False` — паспортных ходов нет, и
    сессия останавливается на пустых ответах с заметкой."""
    calls = []
    if kwargs.get("with_brief"):
        calls.append(tool_call("call_brief", "submit_brief", **brief_args(
            **kwargs.get("brief", {}),
        )))
    calls.append(tool_call("call_stage", "submit_stage", **stage_args(**kwargs.get("stage", {}))))
    calls.append(tool_call("call_review", "submit_review", confirmed=True, notes="проверено"))
    calls.append(tool_call("call_summary", "submit_summary", **summary_args(**kwargs.get("summary", {}))))
    calls.append(tool_call("call_finish", "finish"))
    calls.extend(critic_session(*kwargs.get("critic", ())))
    calls.extend(coherence_session(**kwargs.get("coherence", {})))
    if kwargs.get("passport", True):
        calls.extend(passport_session())
    return calls

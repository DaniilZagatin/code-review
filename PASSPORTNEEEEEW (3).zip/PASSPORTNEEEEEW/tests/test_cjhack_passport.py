"""Карта паспорта готовится отдельно и пока не встраивается в CJ Hack."""

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "cjhack"))

import build  # noqa: E402
from pko.render.passport_map import passport_map_nodes  # noqa: E402


class PassportOverlayTest(unittest.TestCase):
    def test_nodes_from_registry_keep_roots_and_scope(self):
        nodes = passport_map_nodes({
            "registry": [
                {"id": "journey-1", "type": "КП", "name": "Путь", "parent": "—", "basis": "b"},
                {"id": "process-1", "type": "Процесс", "name": "Процесс", "parent": "journey-1", "basis": "b"},
                {"id": "guardrail-1", "type": "Ограничение", "name": "Огр", "parent": "process-1", "basis": "b"},
            ],
            "nodes": {},
        })
        by_id = {n["id"]: n for n in nodes}
        self.assertIsNone(by_id["journey-1"]["parent"])
        self.assertEqual(by_id["journey-1"]["type"], "journey")
        self.assertEqual(by_id["process-1"]["parent"], "journey-1")
        self.assertEqual(by_id["guardrail-1"]["scope"], ["process-1"])
        self.assertEqual(passport_map_nodes(None), [])

    def test_report_without_tree_gets_no_button(self):
        data = {"documents": []}
        html = build.render_html(data)
        self.assertNotIn("cj-passport-btn", html)
        self.assertNotIn("pko-overlay", html)

    def test_cj_hack_does_not_embed_passport_map(self):
        html = build.render_html({"documents": []})
        self.assertNotIn("cj-passport-btn", html)
        self.assertNotIn('id="pko-overlay"', html)
        self.assertNotIn("window.pkoPassportMap", html)


if __name__ == "__main__":
    unittest.main()

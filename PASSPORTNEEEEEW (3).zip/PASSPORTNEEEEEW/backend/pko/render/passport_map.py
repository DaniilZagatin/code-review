"""Карта дерева паспорта — общий компонент для паспорта и CJ Hack.

Один и тот же CSS и JS рисуют схему путь → процесс → BBB → операция с
потребностями сверху и ограничениями снизу, зумом (колесо, кнопки, FIT) и
панорамой перетаскиванием. Источник узлов у потребителей разный:

* паспорт (`client_journey_passport`) собирает узлы из карточек шаблона в
  DOM и по клику клонирует карточку в боковую панель;
* CJ Hack (`cjhack/build.py`) получает узлы из контракта дашборда
  (`passport.tree`) и показывает по клику название, основание и ссылку на
  полный паспорт.

Функция `pkoPassportMap(viewport, nodes, options)` строит карту в
контейнере и возвращает `{select, fit, boxes}`; `options.onSelect(node)`
вызывается по клику на узел (не по перетаскиванию).

Узел: `{id, type, name, basis, parent, scope: [id, …]}`; `type` —
journey | process | bbb | operation | need | guardrail.
"""

from __future__ import annotations

import json
from typing import Any

from pko.progress.schema import (
    CHECK_RESULT_LABEL,
    SCENARIO_STATUS_LABEL,
    STATUS_LABEL,
    ProgressModel,
    calculate_progress,
)

PASSPORT_MAP_CSS = """
.pko-viewport{position:relative;flex:1;min-height:0;overflow:hidden;cursor:grab;background:#F8FAFC;background-image:radial-gradient(#DCE3E9 .8px,transparent .8px);background-size:20px 20px;user-select:none;touch-action:none;color:#18232E}
.pko-viewport.dragging{cursor:grabbing}
.pko-canvas{position:absolute;left:0;top:0;transform-origin:0 0;padding:88px 56px 40px;will-change:transform}
.pko-tree,.pko-tree ul{display:flex;justify-content:center;list-style:none;margin:0;padding:18px 0 0;position:relative}
.pko-tree{padding-top:0}
.pko-tree li{display:flex;flex-direction:column;align-items:center;padding:18px 7px 0;position:relative}
.pko-tree>li{padding-top:0}
.pko-tree li::before,.pko-tree li::after{content:'';position:absolute;top:0;right:50%;width:50%;height:18px;border-top:1px solid #AEBAC4}
.pko-tree li::after{right:auto;left:50%;border-left:1px solid #AEBAC4}
.pko-tree>li::before,.pko-tree>li::after{display:none}
.pko-tree li:only-child::before,.pko-tree li:only-child::after{border-top:0}
.pko-tree li:only-child::after{border-left:1px solid #AEBAC4}
.pko-tree li:first-child::before,.pko-tree li:last-child::after{border:0}
.pko-tree li:last-child::before{border-right:1px solid #AEBAC4;border-radius:0 8px 0 0}
.pko-tree li:first-child::after{border-radius:8px 0 0 0}
.pko-tree ul::before{content:'';position:absolute;top:0;left:50%;width:0;height:18px;border-left:1px solid #AEBAC4}
.pko-box{display:flex;flex-direction:column;gap:6px;min-width:164px;max-width:228px;padding:11px 12px;border:1px solid #C8D1D9;border-radius:10px;background:#fff;cursor:pointer;text-align:left;font-family:inherit;color:#18232E;box-shadow:0 3px 10px rgba(30,48,65,.06);transition:box-shadow .16s ease,border-color .16s ease,background-color .16s ease,opacity .16s ease}
.pko-box:hover{border-color:#7C5CE6;box-shadow:0 8px 22px rgba(51,65,85,.14)}
.pko-box:focus-visible{outline:3px solid rgba(124,92,230,.38);outline-offset:2px;border-color:#7C5CE6}
.pko-box.active{border-color:#6D4BE0;background:#F8F5FF;box-shadow:0 0 0 3px rgba(124,92,230,.18),0 10px 24px rgba(51,65,85,.12)}
.pko-box.scoped{border-style:dashed;border-color:#6D4BE0}
.pko-box .t{font-size:10px;font-weight:800;letter-spacing:.07em;text-transform:uppercase;color:#6D4BE0;background:#F0ECFF;border-radius:5px;padding:2px 6px;align-self:flex-start}
.pko-box[data-type=process] .t{color:#5C45B8;background:#F0ECFF}
.pko-box[data-type=bbb] .t{color:#1769AA;background:#EAF4FF}
.pko-box[data-type=operation] .t{color:#08736E;background:#E2F6F4}
.pko-box[data-type=need] .t{color:#7A5700;background:#FFF4D6}
.pko-box[data-type=guardrail] .t{color:#9C1833;background:#FCE8ED}
.pko-box .n{font-size:13px;font-weight:700;color:#18232E;line-height:1.28;overflow-wrap:anywhere}
.pko-box .i{display:none}
.pko-box .r{display:flex;align-items:center;gap:7px;font-size:11px;font-weight:800;color:#526373;font-variant-numeric:tabular-nums}
.pko-box .r .bar{flex:1;height:4px;border-radius:99px;background:#E7ECF0;overflow:hidden}
.pko-box .r .bar i{display:block;height:100%;background:#92A2B0}
.pko-box[data-band=good]{border-color:#2CB6B0}.pko-box[data-band=good] .r .bar i{background:#2CB6B0}
.pko-box[data-band=mid]{border-color:#E0A100}.pko-box[data-band=mid] .r .bar i{background:#E0A100}
.pko-box[data-band=bad]{border-color:#E2556F}.pko-box[data-band=bad] .r .bar i{background:#E2556F}
.pko-box[data-band=none] .r{color:#B7C2CB;font-weight:500}
.pko-box .s{font-size:10px;font-weight:800;line-height:1.25;border-radius:5px;padding:3px 6px;align-self:flex-start;background:#F0F2F2;color:#405160}
.pko-box[data-implementation=implemented]{border-color:#16857F}.pko-box[data-implementation=implemented] .s{background:#DDF5F2;color:#09615D}
.pko-box[data-implementation=limited]{border-color:#B98000}.pko-box[data-implementation=limited] .s{background:#FFF3CC;color:#765400}
.pko-box[data-implementation=partial]{border-color:#C66A1B}.pko-box[data-implementation=partial] .s{background:#FFF0E2;color:#8B430C}
.pko-box[data-implementation=not_implemented]{border-color:#C73955}.pko-box[data-implementation=not_implemented] .s{background:#FCE5EB;color:#9C1833}
.pko-box[data-implementation=unknown]{border-style:dashed;border-color:#7A8995}.pko-box[data-implementation=unknown] .s{background:#F0F2F2;color:#405160}
.pko-box .m{font-size:10px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;border-radius:5px;padding:2px 6px;align-self:flex-start}
.pko-box .m.broken{background:#FCE5EB;color:#E2556F}
.pko-box .m.unknown{background:#F0F2F2;color:#5A6D7C}
.pko-box.dim{opacity:.28;filter:saturate(.35)}
.pko-paths{position:absolute;left:0;top:0;width:0;height:0;overflow:visible;pointer-events:none;z-index:2}
.pko-paths line,.pko-paths path{fill:none;stroke-width:3;stroke-linecap:round}
.pko-paths .ok{stroke:#2CB6B0}.pko-paths .broken{stroke:#E2556F;stroke-dasharray:7 5}.pko-paths .unknown{stroke:#92A2B0;stroke-dasharray:2 5}
.pko-paths text{font-size:11px;font-weight:700;fill:#E2556F;font-family:inherit}
.pko-legend{position:absolute;left:14px;right:72px;top:12px;z-index:5;display:flex;flex-direction:column;gap:8px;width:max-content;max-width:calc(100% - 94px);padding:8px 10px;border:1px solid rgba(203,213,225,.9);border-radius:10px;background:rgba(255,255,255,.94);box-shadow:0 8px 24px rgba(30,48,65,.09);backdrop-filter:blur(8px)}
.pko-legend .row{display:flex;flex-wrap:wrap;gap:6px}
.pko-chip{min-height:34px;display:inline-flex;align-items:center;gap:7px;font-size:12px;font-weight:650;padding:6px 10px;border:1px solid #CBD5DE;border-radius:8px;background:#fff;cursor:pointer;font-family:inherit;color:#263746;transition:border-color .16s ease,background-color .16s ease,box-shadow .16s ease}
.pko-chip:hover{border-color:#8B78D8}
.pko-chip:focus-visible{outline:3px solid rgba(124,92,230,.3);outline-offset:1px}
.pko-chip.on{border-color:#7C5CE6;background:#F5F1FF;box-shadow:inset 0 0 0 1px rgba(124,92,230,.08)}
.pko-chip .dot{width:8px;height:8px;border-radius:50%;background:#92A2B0}
.pko-chip .dot.assembled{background:#2CB6B0}.pko-chip .dot.broken{background:#E2556F}.pko-chip .dot.unknown{background:#92A2B0}
.pko-key{font-size:11px;color:#526373;display:flex;flex-wrap:wrap;gap:5px 12px;line-height:1.35}
.pko-key span{white-space:nowrap}
.pko-key b{display:inline-block;width:9px;height:9px;border-radius:3px;vertical-align:-1px;margin-right:4px}
.pko-lane{display:flex;gap:12px;flex-wrap:wrap;justify-content:center;align-items:flex-start;padding:8px 0}
.pko-lane-title{font-size:10px;font-weight:800;color:#7A8995;letter-spacing:.08em;text-transform:uppercase;margin:12px 0 4px;text-align:center}
.pko-zoom{position:absolute;right:14px;bottom:14px;display:flex;gap:6px;z-index:5;padding:5px;border:1px solid #D7DEE4;border-radius:11px;background:rgba(255,255,255,.94);box-shadow:0 8px 24px rgba(30,48,65,.10)}
.pko-zoom button{width:38px;height:38px;border:0;border-radius:7px;background:#fff;cursor:pointer;font-size:18px;line-height:1;color:#18232E;font-family:inherit}
.pko-zoom button:hover{background:#F0ECFF;color:#5C45B8}
.pko-zoom button:focus-visible{outline:3px solid rgba(124,92,230,.3);outline-offset:0}
.pko-zoom .pko-zoom-fit{font-size:12px;font-weight:700;letter-spacing:.04em}
.pko-hint{position:absolute;left:14px;bottom:14px;font-size:11px;color:#6D7D8A;background:rgba(255,255,255,.92);border:1px solid #E1E7EB;border-radius:8px;padding:6px 9px;pointer-events:none}
@media(max-width:768px){.pko-canvas{padding:116px 28px 36px}.pko-box{min-width:148px;max-width:194px}.pko-legend{right:14px;max-width:calc(100% - 28px)}.pko-hint{display:none}}
@media(prefers-reduced-motion:reduce){.pko-box,.pko-chip{transition:none!important}}
"""

PASSPORT_MAP_JS = """
window.pkoPassportMap=function(viewport,nodes,options){
  options=options||{};
  var TYPE_LABEL={journey:'КП',process:'Процесс',bbb:'BBB',operation:'Операция',need:'Потребность',guardrail:'Ограничение'};
  var byId={}, order=[];
  (nodes||[]).forEach(function(n){ if(!n||!n.id||byId[n.id]) return; byId[n.id]={id:n.id,type:n.type||n.id.split('-')[0],name:n.name||'',basis:n.basis||'',parent:n.parent||null,scope:(n.scope||[]).slice(),children:[],data:n}; order.push(n.id); });
  // Родитель, которого нет среди узлов («—» у корня в реестре), — не родитель.
  order.forEach(function(id){var n=byId[id]; if(n.parent&&!byId[n.parent]) n.parent=null; if(n.parent) byId[n.parent].children.push(id);});
  var needs=order.filter(function(id){return byId[id].type==='need'});
  var guards=order.filter(function(id){return byId[id].type==='guardrail'});
  var roots=order.filter(function(id){return byId[id].type==='journey'&&!byId[id].parent});

  viewport.classList.add('pko-viewport');
  var canvas=document.createElement('div'); canvas.className='pko-canvas';
  var moved=false, current=null;
  function box(n){
    var b=document.createElement('button'); b.type='button'; b.className='pko-box'; b.dataset.id=n.id; b.dataset.type=n.type;
    b.innerHTML='<span class="t"></span><span class="n"></span><span class="i"></span>';
    b.querySelector('.t').textContent=TYPE_LABEL[n.type]||n.type;
    b.querySelector('.n').textContent=n.name||'[без названия]';
    var info=n.id;
    if(n.type==='guardrail'&&n.scope.length) info+=' · область: '+n.scope.join(', ');
    if(n.type==='need'&&n.scope.length) info+=' · путь: '+n.scope.join(', ');
    b.querySelector('.i').textContent=info;
    var d=n.data||{};
    if(d.implementation_status){
      b.dataset.implementation=d.implementation_status;
      var s=document.createElement('span'); s.className='s'; s.textContent=d.implementation_label||d.implementation_status; b.appendChild(s);
      b.setAttribute('aria-label',(TYPE_LABEL[n.type]||n.type)+' «'+(n.name||'[без названия]')+'»: '+s.textContent);
    }
    if(d.band){
      b.dataset.band=d.band;
      var r=document.createElement('span'); r.className='r';
      if(d.readiness==null){ r.textContent='не сопоставлено с ОР'; }
      else { r.innerHTML='<span class="bar"><i></i></span><span></span>'; r.querySelector('i').style.width=d.readiness+'%'; r.lastChild.textContent=d.readiness+'%'; }
      b.appendChild(r);
    }
    if(d.mark){ var m=document.createElement('span'); m.className='m '+d.mark; m.textContent=d.mark==='broken'?'разрыв':'стык не подтверждён'; b.appendChild(m); }
    b.addEventListener('click',function(e){if(e.detail===0) select(n.id);});
    return b;
  }
  function li(n){
    var item=document.createElement('li'); item.appendChild(box(n));
    if(n.children.length){var ul=document.createElement('ul'); n.children.forEach(function(c){ul.appendChild(li(byId[c]))}); item.appendChild(ul);}
    return item;
  }
  function lane(title,ids){
    if(!ids.length) return;
    var t=document.createElement('div'); t.className='pko-lane-title'; t.textContent=title; canvas.appendChild(t);
    var l=document.createElement('div'); l.className='pko-lane'; ids.forEach(function(id){l.appendChild(box(byId[id]))}); canvas.appendChild(l);
  }
  lane('Потребности клиента',needs);
  var tree=document.createElement('ul'); tree.className='pko-tree';
  roots.forEach(function(id){tree.appendChild(li(byId[id]))});
  canvas.appendChild(tree);
  lane('Ограничения исполнения',guards);
  // Пути сценариев — SVG поверх дерева в координатах холста: масштаб и
  // сдвиг применяются к холсту целиком, пересчитывать линии при зуме не надо.
  var svg=document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('class','pko-paths'); canvas.appendChild(svg);
  var paths=(options.paths||[]).slice();
  var activePaths={}; paths.forEach(function(p){activePaths[p.id]=true;});
  function anchor(id){
    var b=viewport.querySelector('.pko-box[data-id="'+id+'"]'); if(!b) return null;
    var r=b.getBoundingClientRect(), c=canvas.getBoundingClientRect();
    return {x:(r.left-c.left)/scale, y:(r.top-c.top)/scale, w:r.width/scale, h:r.height/scale};
  }
  function drawPaths(){
    while(svg.firstChild) svg.removeChild(svg.firstChild);
    var onPath={};
    paths.forEach(function(p){
      if(!activePaths[p.id]) return;
      (p.nodes||[]).forEach(function(pn){onPath[pn.id]=true;});
      (p.edges||[]).forEach(function(e){
        var a=anchor(e.from), b=anchor(e.to); if(!a||!b) return;
        var x1=a.x+a.w/2, y1=a.y+a.h, x2=b.x+b.w/2, y2=b.y;
        if(y2<y1){ y1=a.y+a.h/2; y2=b.y+b.h/2; x1=a.x+(x2>x1?a.w:0); x2=b.x+(x2>x1?0:b.w); }
        var path=document.createElementNS('http://www.w3.org/2000/svg','path');
        var mx=(x1+x2)/2, my=(y1+y2)/2;
        path.setAttribute('d','M'+x1+','+y1+' C'+x1+','+my+' '+x2+','+my+' '+x2+','+y2);
        path.setAttribute('class',e.result||'unknown');
        svg.appendChild(path);
        if(e.result==='broken'){
          var t=document.createElementNS('http://www.w3.org/2000/svg','text');
          t.setAttribute('x',mx+8); t.setAttribute('y',my-4); t.textContent='✕ разрыв'; svg.appendChild(t);
        }
      });
    });
    var any=paths.some(function(p){return activePaths[p.id]});
    Array.prototype.forEach.call(viewport.querySelectorAll('.pko-box'),function(b){
      b.classList.toggle('dim',any&&paths.length>0&&!onPath[b.dataset.id]&&(b.dataset.type==='bbb'||b.dataset.type==='operation'));
    });
  }
  viewport.appendChild(canvas);
  if(paths.length||options.legend!==false){
    var legend=document.createElement('div'); legend.className='pko-legend';
    var key=document.createElement('div'); key.className='pko-key';
    key.innerHTML='<span><b style="background:#16857F"></b>реализован</span><span><b style="background:#B98000"></b>с ограничениями</span><span><b style="background:#C66A1B"></b>частично</span><span><b style="background:#C73955"></b>не реализован</span><span><b style="background:#E9ECEF;border:1px dashed #7A8995"></b>недостаточно данных</span>'
      +(paths.length?'<span><b style="background:#2CB6B0;border-radius:0;height:3px;width:14px"></b>стык подтверждён</span><span><b style="background:#E2556F;border-radius:0;height:3px;width:14px"></b>разрыв</span><span><b style="background:#92A2B0;border-radius:0;height:3px;width:14px"></b>недостаточно данных</span><span><b style="background:#E9ECEF;opacity:.35"></b>приглушено — узел не входит в выбранные сценарии</span>':'');
    legend.appendChild(key);
    if(paths.length){
      var row=document.createElement('div'); row.className='row';
      paths.forEach(function(p){
        var chip=document.createElement('button'); chip.type='button'; chip.className='pko-chip on'; chip.dataset.path=p.id;
        chip.setAttribute('aria-pressed','true');
        chip.innerHTML='<span class="dot '+(p.status||'unknown')+'"></span><span></span>';
        chip.lastChild.textContent=p.title+(p.critical?' · критический':'');
        chip.title=(p.status_label||'')+(p.break_point?' — '+p.break_point:'');
        chip.addEventListener('click',function(e){e.stopPropagation(); activePaths[p.id]=!activePaths[p.id]; chip.classList.toggle('on',activePaths[p.id]); chip.setAttribute('aria-pressed',String(activePaths[p.id])); drawPaths();});
        row.appendChild(chip);
      });
      legend.appendChild(row);
    }
    viewport.appendChild(legend);
  }
  var zoom=document.createElement('div'); zoom.className='pko-zoom';
  zoom.innerHTML='<button type="button" data-z="in" title="Приблизить" aria-label="Приблизить">+</button><button type="button" data-z="out" title="Отдалить" aria-label="Отдалить">−</button><button type="button" data-z="fit" class="pko-zoom-fit" title="Вписать в окно" aria-label="Вписать схему в окно">FIT</button>';
  viewport.appendChild(zoom);
  var hint=document.createElement('div'); hint.className='pko-hint'; hint.textContent='Колесо — масштаб · перетаскивание — сдвиг · клик по узлу — паспорт узла'; viewport.appendChild(hint);

  var scale=1, tx=0, ty=0;
  function apply(){canvas.style.transform='translate('+tx+'px,'+ty+'px) scale('+scale+')';}
  function setScale(next,cx,cy){
    next=Math.min(3,Math.max(.2,next));
    if(cx===undefined){cx=viewport.clientWidth/2; cy=viewport.clientHeight/2;}
    tx=cx-(cx-tx)*next/scale; ty=cy-(cy-ty)*next/scale; scale=next; apply();
  }
  function place(minScale){
    var w=canvas.scrollWidth, h=canvas.scrollHeight, vw=viewport.clientWidth, vh=viewport.clientHeight;
    if(!w||!h||!vw||!vh) return;
    scale=Math.min(1.1,Math.max(minScale,Math.min(vw/w,vh/h)));
    var topInset=legend?legend.offsetHeight+20:20;
    var padTop=vw<=768?116:88;
    var minTy=Math.max(0,topInset-padTop*scale);
    tx=(vw-w*scale)/2; ty=Math.max(minTy,(vh-h*scale)/2); apply(); drawPaths();
  }
  function fit(){place(.2);}
  function readable(){
    var shortViewport=viewport.clientHeight<560;
    place(viewport.clientWidth<=768?(shortViewport?.48:.64):(shortViewport?.56:.72));
  }
  zoom.addEventListener('click',function(e){
    var b=e.target.closest('button'); if(!b) return;
    if(b.dataset.z==='in') setScale(scale*1.2); else if(b.dataset.z==='out') setScale(scale/1.2); else fit();
  });
  viewport.addEventListener('wheel',function(e){
    e.preventDefault();
    var r=viewport.getBoundingClientRect();
    setScale(scale*(e.deltaY<0?1.1:1/1.1),e.clientX-r.left,e.clientY-r.top);
  },{passive:false});
  // Панорама и выбор узла — одной парой pointerdown/pointerup без захвата
  // указателя: с setPointerCapture click уходил на область, а не на узел.
  var drag=null;
  viewport.addEventListener('pointerdown',function(e){
    if(e.button!==0||e.target.closest('.pko-zoom')||e.target.closest('.pko-legend')) return;
    drag={x:e.clientX,y:e.clientY,tx:tx,ty:ty,target:e.target.closest('.pko-box')}; moved=false;
  });
  window.addEventListener('pointermove',function(e){
    if(!drag) return;
    var dx=e.clientX-drag.x, dy=e.clientY-drag.y;
    if(!moved&&Math.abs(dx)+Math.abs(dy)>4){moved=true; viewport.classList.add('dragging');}
    if(moved){tx=drag.tx+dx; ty=drag.ty+dy; apply();}
  });
  window.addEventListener('pointerup',function(){
    if(!drag) return;
    var target=drag.target, wasMoved=moved;
    drag=null; viewport.classList.remove('dragging'); moved=false;
    if(!wasMoved&&target&&target.dataset.id) select(target.dataset.id);
  });
  window.addEventListener('pointercancel',function(){drag=null; moved=false; viewport.classList.remove('dragging');});
  window.addEventListener('resize',readable);

  function highlight(id){
    var n=id?byId[id]:null;
    Array.prototype.forEach.call(viewport.querySelectorAll('.pko-box'),function(b){
      b.classList.toggle('active',!!n&&b.dataset.id===id);
      b.classList.toggle('scoped',!!n&&n.type==='guardrail'&&n.scope.indexOf(b.dataset.id)>=0);
    });
  }
  function select(id){
    var n=byId[id]; if(!n) return; current=id; highlight(id);
    if(options.onSelect) options.onSelect(n, byId, guards);
  }
  function clear(){current=null; highlight(null);}
  readable();
  return {select:select, clear:clear, fit:fit, redraw:drawPaths, nodes:byId, order:order, guards:guards, paths:paths};
};
"""


def passport_map_nodes(passport_data: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Узлы карты из `passport_data` — то, что идёт в контракт дашборда.

    Только структура: id, тип, название, основание, родитель и область
    (у ограничений и потребностей). Поля карточек остаются в файле паспорта.
    """
    if not passport_data or not isinstance(passport_data, dict):
        return []
    rows = passport_data.get("registry") or []
    nodes_data = passport_data.get("nodes") or {}
    out: list[dict[str, Any]] = []
    known = {str(r.get("id")) for r in rows if isinstance(r, dict) and r.get("id")}
    for row in rows:
        if not isinstance(row, dict) or not row.get("id"):
            continue
        node_id = str(row["id"])
        # В реестре `type` — подпись для читателя («КП», «Процесс»); вид
        # узла — по префиксу id, как везде в паспорте.
        ntype = node_id.split("-")[0]
        raw_parent = str(row.get("parent") or "").strip()
        parent: str | None = None
        scope: list[str] = []
        if ntype in ("need", "guardrail"):
            scope = [p.strip() for p in raw_parent.replace(";", ",").replace("·", ",").split(",") if p.strip()]
        elif raw_parent in known:
            parent = raw_parent
        node = nodes_data.get(node_id) if isinstance(nodes_data, dict) else None
        basis = str(row.get("basis") or (node or {}).get("basis") or "")
        out.append({
            "id": node_id, "type": ntype,
            "name": str(row.get("name") or (node or {}).get("name") or node_id),
            "basis": basis, "parent": parent, "scope": scope,
        })
    return out


# Пороги раскраски узла по готовности — те же полосы, что у бейджа
# решения: зелёный от порога GO, красный ниже четверти.
_GOOD_FROM = 75
_WEAK_BELOW = 25

NODE_IMPLEMENTATION_LABEL = {
    "implemented": "Реализован",
    "limited": "Реализован с ограничениями",
    "partial": "Частично реализован",
    "not_implemented": "Не реализован",
    "unknown": "Недостаточно данных",
}


def _band(readiness: int | None) -> str:
    if readiness is None:
        return "none"
    if readiness >= _GOOD_FROM:
        return "good"
    if readiness < _WEAK_BELOW:
        return "bad"
    return "mid"


def _implementation_state(criteria: list[Any]) -> str:
    """Читаемое состояние узла по связанным пунктам ОР.

    Это не новая шкала оценки: состояния сворачивают уже рассчитанные
    статусы пунктов. Цвет всегда дублируется текстом на узле.
    """
    statuses = [str(c.status) for c in criteria if getattr(c, "applicable", False)]
    if not statuses:
        return "unknown"
    if all(s == "done" for s in statuses):
        return "implemented"
    if all(s in ("done", "limited") for s in statuses):
        return "limited"
    if all(s in ("planned", "blocked") for s in statuses):
        return "not_implemented"
    return "partial"


def build_passport_map(model: ProgressModel) -> dict[str, Any]:
    """Схема паспорта с оценкой: узлы с готовностью и проблемами, пути
    сценариев со стыками. Всё считает код по привязкам, которые дал
    паспортный агент (`bullets`, `scenario_steps`) и которые гейт сопоставил
    с планом и сценариями.

    Готовность узла — `calculate_progress` по его пунктам ОР, теми же
    весами, что и общая готовность. Проблемы узла — незакрытые пункты и
    стыки сценариев, где после этого узла разрыв или недостаточно данных.
    """
    nodes = passport_map_nodes(model.passport_data)
    if not nodes:
        return {
            "nodes": [], "paths": [],
            "summary": {
                "functional_nodes": 0,
                "counts": {state: 0 for state in NODE_IMPLEMENTATION_LABEL},
                "requirements_mapped": 0,
                "requirements_total": len(model.rated_criteria()),
                "mapping_coverage": 0 if model.rated_criteria() else None,
                "assessment": model.solution_assessment().to_dict(),
            },
        }
    raw_nodes = (model.passport_data or {}).get("nodes") or {}

    # Пункт ОР → его оценка (дословный текст плана — ключ, как везде).
    criterion_by_text: dict[str, Any] = {}
    for verdict in model.verdicts:
        item = model.items.get(verdict.item_id)
        if item is None or not verdict.applicable:
            continue
        for text, criterion in zip(item.criteria, verdict.criteria):
            if criterion.applicable:
                criterion_by_text[str(text)] = criterion

    scenarios = {s.id: s for s in (model.connectivity.scenarios if model.connectivity else [])}
    # (сценарий, шаг) → узлы, которые его выполняют.
    step_nodes: dict[tuple[str, int], list[str]] = {}

    by_id = {n["id"]: n for n in nodes}
    children: dict[str, list[str]] = {nid: [] for nid in by_id}
    for node in nodes:
        if node.get("parent") in children:
            children[node["parent"]].append(node["id"])

    direct_texts: dict[str, list[str]] = {}
    for node in nodes:
        raw = raw_nodes.get(node["id"]) if isinstance(raw_nodes, dict) else None
        raw = raw if isinstance(raw, dict) else {}
        direct_texts[node["id"]] = [
            str(text) for text in (raw.get("bullets") or [])
            if str(text) in criterion_by_text
        ]

    def linked_texts(node_id: str, trail: set[str] | None = None) -> list[str]:
        """Прямая привязка; для контейнера — сумма детей, для листа —
        привязка ближайшего родителя. Так каждый функциональный узел получает
        объяснимое состояние, но источник связи остаётся виден в карточке.
        """
        trail = set(trail or ())
        if node_id in trail:
            return []
        trail.add(node_id)
        direct = direct_texts.get(node_id) or []
        if direct:
            return list(dict.fromkeys(direct))
        descendant: list[str] = []
        for child in children.get(node_id, []):
            descendant.extend(linked_texts(child, trail))
        if descendant:
            return list(dict.fromkeys(descendant))
        parent = by_id.get(node_id, {}).get("parent")
        while parent in by_id:
            inherited = direct_texts.get(parent) or []
            if inherited:
                return list(dict.fromkeys(inherited))
            parent = by_id[parent].get("parent")
        return []

    for node in nodes:
        raw = raw_nodes.get(node["id"]) if isinstance(raw_nodes, dict) else None
        raw = raw if isinstance(raw, dict) else {}
        bullets: list[dict[str, Any]] = []
        criteria = []
        texts = linked_texts(node["id"]) if node["type"] not in ("need", "guardrail") else direct_texts[node["id"]]
        for text in texts:
            criterion = criterion_by_text.get(str(text))
            if criterion is None:
                continue
            criteria.append(criterion)
            bullets.append({"text": str(text), "status": criterion.status,
                            "status_label": STATUS_LABEL.get(criterion.status, criterion.status)})
        readiness = calculate_progress(criteria) if criteria else None
        node["bullets"] = bullets
        node["readiness"] = readiness
        node["band"] = _band(readiness)
        state = _implementation_state(criteria)
        node["implementation_status"] = state
        node["implementation_label"] = NODE_IMPLEMENTATION_LABEL[state]
        node["assessment_source"] = (
            "direct" if direct_texts[node["id"]] else
            "derived" if texts else "unknown"
        )
        node["steps"] = []
        for entry in raw.get("scenario_steps") or []:
            if not isinstance(entry, dict):
                continue
            sid, step = str(entry.get("scenario") or ""), entry.get("step")
            if sid in scenarios and isinstance(step, int):
                node["steps"].append({"scenario": sid, "step": step})
                step_nodes.setdefault((sid, step), []).append(node["id"])
        node["problems"] = [
            f"{b['status_label']}: {b['text']}" for b in bullets if b["status"] != "done"
        ]
        if state == "unknown":
            node["problems"].append("Узел не сопоставлен с оценёнными пунктами образа результата")

    # Пути сценариев поверх дерева: узлы по шагам, рёбра между соседними
    # шагами с результатом стыка. Шаг без узла — пропуск в пути.
    paths: list[dict[str, Any]] = []
    for scenario in scenarios.values():
        path_nodes: list[dict[str, Any]] = []
        edges: list[dict[str, Any]] = []
        prev: list[str] = []
        prev_step = -1
        for index, step_text in enumerate(scenario.steps):
            ids = step_nodes.get((scenario.id, index), [])
            for nid in ids:
                path_nodes.append({"id": nid, "step": index, "text": step_text})
            if ids and prev:
                # Результат стыка — по переходам между prev_step и index:
                # разрыв сильнее неизвестного.
                results = []
                for t in range(prev_step, index):
                    handoff = scenario.handoff_at(t)
                    results.append(handoff.result if handoff else "unknown")
                result = ("broken" if "broken" in results
                          else "unknown" if "unknown" in results else "ok")
                handoff = next((scenario.handoff_at(t) for t in range(prev_step, index)
                                if scenario.handoff_at(t) and scenario.handoff_at(t).result == result), None)
                note = ""
                if handoff is not None:
                    check = handoff.break_check or next(
                        (c for c in handoff.checks if c.result == result), None)
                    note = check.note if check else ""
                for a in prev:
                    for b in ids:
                        edges.append({"from": a, "to": b, "result": result,
                                      "result_label": CHECK_RESULT_LABEL.get(result, result),
                                      "note": note})
                        if result != "ok" and a in by_id:
                            by_id[a]["problems"].append(
                                f"{scenario.title}: {CHECK_RESULT_LABEL.get(result, result).lower()} "
                                f"на переходе к «{step_text}»" + (f" — {note}" if note else "")
                            )
            if ids:
                prev, prev_step = ids, index
        paths.append({
            "id": scenario.id, "title": scenario.title, "critical": scenario.critical,
            "status": scenario.status,
            "status_label": SCENARIO_STATUS_LABEL.get(scenario.status, scenario.status),
            "entry": scenario.entry, "outcome": scenario.outcome,
            "steps": list(scenario.steps), "nodes": path_nodes, "edges": edges,
            "break_point": scenario.break_point,
        })
    for node in nodes:
        # Разрыв виден и на самом узле: отметка «разрыв» — если после него
        # рвётся хотя бы один сценарий.
        outgoing = [e for p in paths for e in p["edges"] if e["from"] == node["id"]]
        node["mark"] = ("broken" if any(e["result"] == "broken" for e in outgoing)
                        else "unknown" if any(e["result"] == "unknown" for e in outgoing)
                        else "")
    functional = [n for n in nodes if n["type"] in ("journey", "process", "bbb", "operation")]
    counts = {state: 0 for state in NODE_IMPLEMENTATION_LABEL}
    for node in functional:
        counts[node["implementation_status"]] += 1
    mapped = {text for texts in direct_texts.values() for text in texts}
    total_bullets = len(criterion_by_text)
    mapping_coverage = round(100 * len(mapped) / total_bullets) if total_bullets else None
    return {
        "nodes": nodes,
        "paths": paths,
        "summary": {
            "functional_nodes": len(functional),
            "counts": counts,
            "requirements_mapped": len(mapped),
            "requirements_total": total_bullets,
            "mapping_coverage": mapping_coverage,
            "assessment": model.solution_assessment().to_dict(),
        },
    }


def nodes_json(nodes: Any) -> str:
    """JSON для вставки в `<script>` — без `</` и U+2028/2029."""
    text = json.dumps(nodes, ensure_ascii=False, separators=(",", ":"))
    return text.replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")

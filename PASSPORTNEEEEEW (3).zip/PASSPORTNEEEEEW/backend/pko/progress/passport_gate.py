"""Гейт паспорта клиентского пути: модель предлагает узлы, код проверяет.

Паспорт заполняет агент (`passport_agent`), и без проверки он получается
реверс-инжинирингом кода: потребности клиента переписаны с категорий
классификатора, ограничения висят «сквозными» без области, BBB остаются
без операций, реестр расходится с деревом, а «Установлено» стоит там, где
источник — строка промпта. Здесь то, что можно проверить кодом.

Две функции:

* `check_passport` — проверка готового JSON целиком; поузловые части
  (`check_node_fields`, `check_need_node`, `check_guardrail_node`) зовёт
  паспортный агент на каждом шаге: `errors` — узел отклоняется, `remarks` —
  принимается, замечания идут агенту и в служебные заметки прогона.
* `normalize_passport` — то, чего у модели не спрашивают: сквозная
  нумерация узлов, идентификаторы объектов по единой схеме, реестр,
  выведенный из дерева и связей. Модель присылает дерево и поля, реестр
  строит код — расходиться им негде.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from pko.progress.schema import contains_code
from pko.progress.text_input import slug

# Сколько потребностей клиента может закрывать один путь. Три и больше —
# почти всегда перечень функций продукта (по одной на процесс), а не
# потребности: потребность существует до продукта и переживёт его закрытие.
MAX_NEEDS = 2

NODE_TYPES = ("journey", "process", "bbb", "operation", "need", "guardrail")
TREE_TYPES = ("journey", "process", "bbb", "operation")
CHILD_TYPE = {"journey": "process", "process": "bbb", "bbb": "operation"}

TYPE_LABEL = {
    "journey": "Клиентский путь",
    "process": "Автономный процесс",
    "bbb": "BBB",
    "operation": "Атомарная операция",
    "need": "Потребность клиента",
    "guardrail": "Ограничение исполнения",
}

DECISION_BOUNDARIES = ("END_TO_END_PROCESS", "COMPONENT_BBB")

# Уровни обоснования. Каждое «Основание» начинается с одного из них.
SOURCE_LEVELS = (
    "Установлено",
    "Выведено",
    "Гипотеза",
    "Требует подтверждения владельца",
    "Не установлено",
)
# После уровня обязана идти привязка: голое «Выведено» — пустое поле,
# оформленное как заполненное. «Не установлено» без пояснения допускается.
MIN_SOURCE_DETAIL_CHARS = 12

# Поля бизнес-намерения: код их не устанавливает. Потребность, её смысл и
# любой владелец подтверждаются вне кода — «Установлено» здесь означает,
# что категория промпта или CODEOWNERS выданы за решение бизнеса.
INTENT_FIELDS = {
    "4.1.1", "4.1.2", "4.1.3",  # потребность, её смысл, владелец
    "4.2.3", "4.3.3", "4.4.3", "4.5.3", "4.6.3",  # владельцы
}

# Поля потребности, где текст должен быть на языке клиента: код, флаги,
# права и имена сценариев туда не идут.
NEED_TEXT_FIELDS = ("4.1.1", "4.1.2", "4.1.5", "4.1.7")

# Режимы исполнения BBB (§ 4.3.6) — поле без режима не заполнено.
EXECUTION_MODES = ("HUMAN_ONLY", "ASSIST", "CONFIRM", "AUTO")

# Ограничивающие эффекты (§ 4.6.8).
GUARDRAIL_EFFECTS = (
    "DENY", "SAFE_STOP", "REQUIRE_HANDOFF", "LIMIT_MODE",
    "REQUIRE_CONFIRMATION", "NOTIFY", "LOG",
)

# Константы, флаги, права и категории сценариев: ALLOW_PORTFOLIO, PICKER.
_CAPS_TOKEN = re.compile(r"\b[A-Z][A-Z0-9_]{3,}\b")
# Имя исключения вместо ограничения: PortfolioNotAvailableError.
_EXCEPTION_NAME = re.compile(r"\b\w+(?:Error|Exception)\b")

# Handoff — передача человеку. Переход между сценариями агента им не является.
_HUMAN_WORDS = re.compile(
    r"человек|оператор|сотрудник|специалист|менеджер|консультант|"
    r"не установлено|неприменимо|нет передачи|передач\w* нет",
    re.IGNORECASE,
)
# Маршрутизатор упоминается в основаниях — значит, он определяет, какой
# процесс запустится, и обязан быть узлом.
_ROUTER_WORDS = re.compile(
    r"классификатор|классификац|маршрутизатор|маршрутизац|роутер|"
    r"\brouter\b|classif|scenario\.py|intent",
    re.IGNORECASE,
)
_ROUTER_NODE_WORDS = re.compile(
    r"классификац|маршрутизац|определение сценария|распознавание (?:запроса|намерения|сценария)",
    re.IGNORECASE,
)
# Компенсация — обратное действие на внешний эффект. Откат статуса в своей
# базе им не является.
_STATUS_WORDS = re.compile(r"статус", re.IGNORECASE)
_COMPENSATION_WORDS = re.compile(
    r"компенсац|возврат|возвращ|отмен|обратн|компенсации нет|не компенсир",
    re.IGNORECASE,
)
_MONEY_WORDS = re.compile(
    r"перевод|платёж|платеж|списан|зачислен|средств|деньг|открыти[ея] (?:продукта|вклада|счёта|счета)",
    re.IGNORECASE,
)


@dataclass
class PassportCheck:
    errors: list[str] = field(default_factory=list)
    remarks: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors


# --- разбор структуры ---------------------------------------------------------

def node_type(node_id: str) -> str:
    for prefix in NODE_TYPES:
        if str(node_id).startswith(prefix + "-"):
            return prefix
    return ""


def _walk(tree: Any) -> list[tuple[str, str | None, int]]:
    """Список (id, parent_id, глубина) в порядке обхода дерева."""
    out: list[tuple[str, str | None, int]] = []

    def visit(node: Any, parent: str | None, depth: int) -> None:
        if not isinstance(node, dict):
            return
        nid = str(node.get("id") or "")
        if nid:
            out.append((nid, parent, depth))
        for child in node.get("children") or []:
            visit(child, nid or parent, depth + 1)

    if isinstance(tree, list):
        for root in tree:
            visit(root, None, 0)
    return out


def _fields(node: dict) -> dict[str, dict]:
    fields = node.get("fields")
    if not isinstance(fields, dict):
        return {}
    return {str(k): v for k, v in fields.items() if isinstance(v, dict)}


def _text(field_obj: dict | None, key: str) -> str:
    if not isinstance(field_obj, dict):
        return ""
    value = field_obj.get(key)
    return value.strip() if isinstance(value, str) else ""


def _links(node: dict, key: str) -> list[str]:
    """Список ссылок на узлы: `journeys` у потребности, `scope` у ограничения."""
    raw = node.get(key)
    if isinstance(raw, str):
        raw = [part.strip() for part in re.split(r"[,;·]", raw)]
    if not isinstance(raw, list):
        return []
    return [str(x).strip() for x in raw if str(x).strip() and str(x).strip() != "—"]


def _registry_parent(data: dict, node_id: str) -> list[str]:
    """Родитель из реестра агента — на случай, если связи в узле не заданы."""
    for row in data.get("registry") or []:
        if isinstance(row, dict) and str(row.get("id")) == node_id:
            return _links(row, "parent")
    return []


def _norm_name(name: Any) -> str:
    return re.sub(r"[^\wа-яё]+", " ", str(name or "").lower()).strip()


# --- проверка ------------------------------------------------------------------

def check_passport(data: Any) -> PassportCheck:
    """Проверить паспорт от агента. Пустой `errors` — можно принимать."""
    check = PassportCheck()
    if not isinstance(data, dict) or not data:
        check.errors.append("паспорт должен быть непустым JSON-объектом")
        return check

    nodes = data.get("nodes")
    if not isinstance(nodes, dict) or not nodes:
        check.errors.append("nodes пуст: узлы паспорта не переданы")
        return check
    nodes = {str(k): v for k, v in nodes.items() if isinstance(v, dict)}

    boundary = str(data.get("decision-boundary") or "").strip()
    if boundary and boundary not in DECISION_BOUNDARIES:
        check.errors.append(
            "decision-boundary должен быть одним из: " + ", ".join(DECISION_BOUNDARIES)
        )

    walk = _walk(data.get("tree"))
    tree_ids = [nid for nid, _, _ in walk]
    _check_tree(check, walk, nodes)
    _check_names(check, nodes, walk)
    _check_needs(check, data, nodes, tree_ids)
    _check_guardrails(check, data, nodes, tree_ids)
    _check_fields(check, nodes)
    _check_router(check, nodes)
    return check


def _check_tree(check: PassportCheck, walk: list, nodes: dict) -> None:
    if not walk:
        check.errors.append("tree пуст: нужен хотя бы один узел journey с процессами")
        return
    known = {nid for nid, _, _ in walk}
    children: dict[str, list[str]] = {}
    for nid, parent, _ in walk:
        if parent is not None:
            children.setdefault(parent, []).append(nid)

    for nid, parent, _ in walk:
        ntype = node_type(nid)
        if ntype not in TREE_TYPES:
            check.errors.append(
                f"{nid}: в tree допустимы только journey/process/bbb/operation; "
                "потребности и ограничения идут отдельно в nodes"
            )
            continue
        if nid not in nodes:
            check.errors.append(f"{nid}: есть в tree, но нет в nodes")
        expected_parent = {"journey": None, "process": "journey", "bbb": "process", "operation": "bbb"}[ntype]
        parent_type = node_type(parent) if parent else None
        if parent_type != expected_parent:
            check.errors.append(
                f"{nid}: родитель должен быть типа {expected_parent or 'нет (корень)'}, "
                f"а стоит {parent or 'корень'}"
            )
        if ntype == "bbb" and not children.get(nid):
            check.errors.append(
                f"{nid}: BBB без атомарных операций. Уровень BBB промежуточный: "
                "заведи хотя бы одну операцию — шаг, который отдаёт результат "
                "блока наружу (расчёт, сообщение клиенту, перевод, открытие продукта, "
                "запись). Кандидаты обычно уже перечислены в «Способах исполнения» "
                "этого же блока"
            )
        if ntype == "process" and not children.get(nid):
            check.errors.append(f"{nid}: процесс без BBB")
        if ntype == "journey" and not children.get(nid):
            check.errors.append(f"{nid}: клиентский путь без процессов")

    for nid, node in nodes.items():
        if node_type(nid) in TREE_TYPES and nid not in known:
            check.errors.append(f"{nid}: есть в nodes, но не входит в tree")


def _check_names(check: PassportCheck, nodes: dict, walk: list) -> None:
    """Узел не дублирует родителя и не совпадает по названию с другим узлом."""
    names: dict[str, str] = {}
    for nid, node in nodes.items():
        name = _norm_name(node.get("name"))
        if not name:
            check.errors.append(f"{nid}: нет названия (name)")
            continue
        if name in names:
            check.errors.append(duplicate_name_message(nid, names[name], str(node.get("name"))))
        names.setdefault(name, nid)

    by_id = {nid: parent for nid, parent, _ in walk}
    children: dict[str, list[str]] = {}
    for nid, parent in by_id.items():
        if parent:
            children.setdefault(parent, []).append(nid)
    for parent, kids in children.items():
        if len(kids) != 1 or node_type(parent) != "process":
            continue
        kid = kids[0]
        p_basis = _norm_name(nodes.get(parent, {}).get("basis"))
        k_basis = _norm_name(nodes.get(kid, {}).get("basis"))
        if p_basis and p_basis == k_basis:
            check.errors.append(collapsed_level_message(parent, kid))


def duplicate_name_message(nid: str, other: str, name: str) -> str:
    return (
        f"{nid} и {other} названы одинаково («{name}»): "
        "это один объект, записанный на двух уровнях. Оставь один узел "
        "или назови ребёнка по его собственному действию"
    )


def collapsed_level_message(parent: str, kid: str) -> str:
    return (
        f"{parent} и {kid}: у процесса один BBB с тем же основанием "
        "существования — средний уровень пустой. Разбей процесс на "
        "блоки с разными действиями или объясни в basis, чем блок отличается"
    )


def norm_name(name: Any) -> str:
    return _norm_name(name)


def _check_needs(check: PassportCheck, data: dict, nodes: dict, tree_ids: list[str]) -> None:
    needs = [nid for nid in nodes if node_type(nid) == "need"]
    if not needs:
        check.errors.append("нет ни одной потребности клиента (need-1)")
        return
    if len(needs) > MAX_NEEDS:
        check.errors.append(too_many_needs_message(len(needs)))
    journeys = {nid for nid in tree_ids if node_type(nid) == "journey"}
    process_names = [str(nodes[nid].get("name") or "") for nid in nodes if node_type(nid) == "process"]
    for nid in needs:
        node = dict(nodes[nid])
        if not _links(node, "journeys"):
            node["journeys"] = _registry_parent(data, nid)
        check_need_node(check, nid, node, journeys, process_names)


def too_many_needs_message(count: int) -> str:
    return (
        f"потребностей {count}, допустимо не больше {MAX_NEEDS}. "
        "Потребность — не функция продукта и не сценарий классификатора: "
        "она существует до продукта и переживёт его закрытие. Сведи к "
        "одной-двум в терминах результата для клиента"
    )


def _check_guardrails(check: PassportCheck, data: dict, nodes: dict, tree_ids: list[str]) -> None:
    known = set(tree_ids)
    for nid, node in nodes.items():
        if node_type(nid) != "guardrail":
            continue
        node = dict(node)
        if not _links(node, "scope"):
            node["scope"] = _registry_parent(data, nid)
        check_guardrail_node(check, nid, node, known)


def _check_fields(check: PassportCheck, nodes: dict) -> None:
    for nid, node in nodes.items():
        check_node_fields(check, nid, node)


def check_node_fields(check: PassportCheck, nid: str, node: dict) -> None:
    """Поля одного узла: уровни оснований, ⚑-поля, режим, handoff, компенсация."""
    ntype = node_type(nid)
    fields = _fields(node)
    for fid, fobj in fields.items():
        value = _text(fobj, "value")
        source = _text(fobj, "source")
        if not value and not source:
            continue
        level = _source_level(source)
        if level is None:
            check.errors.append(
                f"{nid} {fid}: основание должно начинаться с уровня "
                "(Установлено: / Выведено: / Гипотеза: / Требует подтверждения "
                f"владельца: / Не установлено:), а не «{source[:40]}»"
            )
            continue
        detail = source[len(level):].lstrip(" :·—-")
        if level != "Не установлено" and len(detail) < MIN_SOURCE_DETAIL_CHARS:
            check.errors.append(
                f"{nid} {fid}: «{level}» без привязки. После уровня — что "
                "именно и где найдено (файл, функция, факт) или чем можно проверить"
            )
        if fid in INTENT_FIELDS and level == "Установлено":
            check.errors.append(
                f"{nid} {fid}: бизнес-намерение (потребность, владелец) кодом не "
                "устанавливается. Уровень — «Требует подтверждения владельца:» "
                "или «Гипотеза:», предложение — в значении"
            )
    if ntype == "process":
        modes = _text(fields.get("4.3.6"), "value")
        if modes and not any(m in modes.upper() for m in EXECUTION_MODES):
            check.errors.append(
                f"{nid} 4.3.6: не назван режим исполнения. Для каждого BBB "
                "укажи максимум из HUMAN_ONLY / ASSIST / CONFIRM / AUTO по факту "
                "кода: ждёт ли он подтверждения человека перед действием"
            )
        handoff = _text(fields.get("4.3.8"), "value")
        if handoff and not _HUMAN_WORDS.search(handoff):
            check.remarks.append(
                f"{nid} 4.3.8: handoff — передача управления человеку (оператору, "
                "специалисту), а не переход между сценариями агента. Если "
                "передачи человеку в коде нет — так и напиши: «Не установлено: "
                "передачи человеку нет, клиент остаётся с ботом»"
            )
    if ntype == "operation":
        comp = _text(fields.get("4.5.6"), "value")
        effect = _text(fields.get("4.5.4"), "value") + " " + _text(fields.get("4.5.1"), "value")
        if (comp and _STATUS_WORDS.search(comp) and not _COMPENSATION_WORDS.search(comp)
                and _MONEY_WORDS.search(effect)):
            check.remarks.append(
                f"{nid} 4.5.6: откат статуса — не компенсация. Операция двигает "
                "деньги или открывает продукт: скажи прямо, есть ли обратное "
                "действие на внешний эффект, и что происходит с уже выполненной "
                "частью при ошибке следующего шага"
            )


def check_need_node(check: PassportCheck, nid: str, node: dict,
                    journeys: set[str], process_names: list[str]) -> None:
    """Одна потребность: связь с путём, язык клиента, основание не из кода."""
    links = _links(node, "journeys")
    if not links:
        check.errors.append(
            f"{nid}: не указано, какой клиентский путь закрывает потребность "
            '(поле journeys: ["journey-1"])'
        )
    for link in links:
        if link not in journeys:
            check.errors.append(f"{nid}: journeys ссылается на несуществующий путь {link}")
    fields = _fields(node)
    for fid in NEED_TEXT_FIELDS:
        value = _text(fields.get(fid), "value")
        code = contains_code(value)
        caps = _CAPS_TOKEN.search(value)
        token = code or (caps.group(0) if caps else "")
        if token:
            check.errors.append(
                f"{nid}: поле {fid} описано языком системы («{token}»). "
                "Потребность клиента не зависит от флагов, прав и сценариев "
                "в коде банка — перепиши в терминах клиента: доход, сохранность, "
                "доступ к деньгам, время, усилия"
            )
    source_11 = _text(fields.get("4.1.1"), "source")
    level_11 = _source_level(source_11)
    if (level_11 in ("Установлено", "Выведено")
            and (_ROUTER_WORDS.search(source_11)
                 or re.search(r"сценари|scenario", source_11, re.IGNORECASE))):
        check.errors.append(
            f"{nid}: основание потребности — сценарий или классификатор. "
            "Категория в промпте размечает реплику, а не подтверждает "
            "потребность. Ставь «Требует подтверждения владельца:» и назови, "
            "чем потребность подтверждается вне кода (исследование, аналитика "
            "обращений, продуктовая политика)"
        )
    name = _norm_name(node.get("name"))
    for pname in process_names:
        if name and name == _norm_name(pname):
            check.errors.append(
                f"{nid} названа так же, как процесс «{pname}»: потребность "
                "переписана с процесса. Потребность — что нужно клиенту, "
                "процесс — как банк это делает"
            )


def check_guardrail_node(check: PassportCheck, nid: str, node: dict, known: set[str]) -> None:
    """Одно ограничение: область по узлам, название по инварианту, эффект."""
    scope = _links(node, "scope")
    if not scope:
        check.errors.append(
            f"{nid}: не указана область действия (scope: [\"bbb-3\", ...]). "
            "«Сквозное на всё дерево» не принимается: назови узлы, где "
            "проверка фактически выполняется"
        )
    for link in scope:
        if link not in known:
            check.errors.append(f"{nid}: scope ссылается на несуществующий узел {link}")
    name = str(node.get("name") or "")
    if _EXCEPTION_NAME.search(name) or contains_code(name):
        check.errors.append(
            f"{nid}: название «{name}» — имя из кода. Исключение или флаг — "
            "способ сигнализации, а не ограничение. Назови по защищаемому "
            "инварианту: «Портфель не собирается из одного продукта»"
        )
    if re.search(r"\bи\b", name) and re.search(r"минимум|диапазон|порог", name, re.IGNORECASE):
        check.remarks.append(
            f"{nid}: в названии два правила через «и» — похоже на два "
            "ограничения с разными инвариантами; разбей на две карточки"
        )
    fields = _fields(node)
    effect = _text(fields.get("4.6.8"), "value")
    if effect and not any(effect.upper().startswith(e) or f" {e}" in effect.upper() for e in GUARDRAIL_EFFECTS):
        check.errors.append(
            f"{nid}: поле 4.6.8 должно начинаться с эффекта из перечня: "
            + "/".join(GUARDRAIL_EFFECTS)
        )


def check_router_present(check: PassportCheck, nodes: dict) -> None:
    """Классификатор упоминается в основаниях — он обязан быть узлом."""
    _check_router(check, nodes)


def _check_router(check: PassportCheck, nodes: dict) -> None:
    """Классификатор упоминается в основаниях — он обязан быть узлом."""
    mentioned = False
    for node in nodes.values():
        for fobj in _fields(node).values():
            if _ROUTER_WORDS.search(_text(fobj, "source")):
                mentioned = True
                break
        if mentioned:
            break
    if not mentioned:
        return
    for nid, node in nodes.items():
        if node_type(nid) not in ("process", "bbb", "guardrail"):
            continue
        haystack = " ".join([str(node.get("name") or ""), str(node.get("basis") or "")])
        if _ROUTER_NODE_WORDS.search(haystack):
            return
    check.remarks.append(
        "классификатор или маршрутизатор сценария упоминается в основаниях, но "
        "узла для него нет. Он решает, какой процесс запустится, — самый "
        "рискованный компонент решения. Заведи BBB «Определение сценария "
        "обращения» и ограничение на поведение при неуверенности"
    )


def _source_level(source: str) -> str | None:
    for level in SOURCE_LEVELS:
        if source.startswith(level):
            return level
    return None


# --- нормализация --------------------------------------------------------------

def normalize_passport(data: dict) -> dict:
    """Сквозная нумерация, единая схема ID объектов, реестр из дерева.

    Модель присылает `tree`, `nodes` и связи (`journeys` у потребности,
    `scope` у ограничения). Всё остальное строит код:

    * узлы нумеруются по порядку обхода дерева: journey-1, process-1…,
      bbb-1…, operation-1… — заготовки шаблона всегда заняты, «дыр» нет;
    * `object-id` = `<тип>.<слаг названия>`: единая схема, по которой
      паспорта разных инициатив можно сшить;
    * `registry` выводится из дерева и связей: родитель узла дерева — его
      родитель в дереве, родитель потребности — её пути, родитель
      ограничения — узлы области действия.
    """
    nodes_in = {str(k): v for k, v in (data.get("nodes") or {}).items() if isinstance(v, dict)}
    walk = _walk(data.get("tree"))

    counters: dict[str, int] = {}
    rename: dict[str, str] = {}

    def assign(old: str) -> str:
        if old in rename:
            return rename[old]
        ntype = node_type(old)
        counters[ntype] = counters.get(ntype, 0) + 1
        rename[old] = f"{ntype}-{counters[ntype]}"
        return rename[old]

    for nid, _, _ in walk:
        assign(nid)
    for ntype in ("need", "guardrail"):
        for nid in nodes_in:
            if node_type(nid) == ntype and nid not in rename:
                assign(nid)

    def rebuild(node: Any) -> dict | None:
        if not isinstance(node, dict) or not node.get("id"):
            return None
        new = {"id": rename[str(node["id"])], "type": node_type(str(node["id"]))}
        kids = [rebuild(c) for c in node.get("children") or []]
        kids = [k for k in kids if k]
        if kids or new["type"] != "operation":
            new["children"] = kids
        return new

    tree = [t for t in (rebuild(r) for r in data.get("tree") or []) if t]

    agent_basis = {
        str(row.get("id")): str(row.get("basis") or "")
        for row in data.get("registry") or [] if isinstance(row, dict)
    }
    nodes_out: dict[str, dict] = {}
    for old, node in nodes_in.items():
        if old not in rename:
            continue  # узел дерева, которого нет в tree — проверка его уже отклонила
        new_id = rename[old]
        ntype = node_type(new_id)
        out = dict(node)
        out["object-id"] = f"{ntype}.{slug(str(node.get('name') or new_id))}"
        out["basis"] = str(node.get("basis") or agent_basis.get(old) or "")
        if ntype == "need":
            links = _links(node, "journeys") or _registry_parent(data, old)
            out["journeys"] = [rename[x] for x in links if x in rename]
        if ntype == "guardrail":
            links = _links(node, "scope") or _registry_parent(data, old)
            out["scope"] = [rename[x] for x in links if x in rename]
        nodes_out[new_id] = out

    parent_of = {rename[nid]: (rename[p] if p else None) for nid, p, _ in walk}
    order = [rename[nid] for nid, _, _ in walk]
    order += [nid for nid in nodes_out if node_type(nid) == "need"]
    order += [nid for nid in nodes_out if node_type(nid) == "guardrail"]

    registry = []
    for nid in order:
        node = nodes_out.get(nid, {})
        ntype = node_type(nid)
        if ntype == "need":
            parent = ", ".join(node.get("journeys") or []) or "—"
        elif ntype == "guardrail":
            parent = ", ".join(node.get("scope") or []) or "—"
        else:
            parent = parent_of.get(nid) or "—"
        registry.append({
            "id": nid,
            "type": TYPE_LABEL[ntype],
            "name": str(node.get("name") or ""),
            "parent": parent,
            "basis": str(node.get("basis") or ""),
        })

    out = {k: v for k, v in data.items() if k not in ("tree", "nodes", "registry")}
    out["tree"] = tree
    out["nodes"] = nodes_out
    out["registry"] = registry
    return out


def journey_name_of(ctx: dict[str, str], repo_name: str = "") -> str:
    """Название клиентского пути — из образа результата (`client_path_name`).

    Один источник для заголовка паспорта, корня дерева и брифа паспортного
    агента: иначе путь назывался то именем проекта, то именем репозитория.
    """
    return ctx.get("client_path_name") or ctx.get("project_name") or repo_name or "—"

"""Единый паспорт клиентского пути — рендер HTML-шаблона v3.

Шаблон: ``passport-dpss-v3.html``. Использует ``data-fill``
атрибуты (не Mustache): каждый заполняемый элемент имеет
``data-fill="value|source|name|object-id|object-version|..."`` и
``data-placeholder``. Рендерер находит эти элементы и подставляет текст,
сохраняя CSS, структуру, классы и ``<template>``-доноры.

Иерархия объектов в шаблоне:
  journey (КП) → process (процесс) → bbb (бизнес-блок) → operation (операция)

Карточки потребности клиента (§ 4.1) и ограничения исполнения (§ 4.6),
которые есть в шаблоне, паспорт не выпускает: их контейнеры и заготовки
рендерер вырезает (`_strip_removed_sections`), сам шаблон не меняется.
Раздел «Основание паспорта» (область анализа, граница решения, дата,
образ результата) вырезается так же: заказчику он не нужен, репозиторий
и коммит остаются строкой в шапке.
Поверх дерева паспорт несёт связи: у узла может быть несколько родителей
(общий BBB в нескольких процессах), а между узлами — связи из
`passport_gate.RELATION_KINDS`; в реестре столбец «Родитель» перечисляет
всех родителей через запятую, связи идут в схему и карточку узла.

Два источника значений полей:
  1. **Паспортный агент** (``progress.passport_agent``, отдельная сессия
     после оценки, рецензента и ревизора) — модель заполняет смысловые поля
     по знаниям сессии оценки. Значения приходят как ``passport_data``
     (``ProgressModel.passport_data``) и преобразуются в ``llm_values``
     (плоский dict, ключи совпадают со схемой ``_fill_template``).
  2. **Детерминированное заполнение** (``_build_fill_values``) — fallback
     из ProgressModel + Extraction, если паспортная сессия не приняла ни
     одного узла.

Принцип тот же: код заполняет, не выдумывает. Агент предлагает содержания
полей, код подставляет их в HTML — модель не видит разметку и не может
её сломать.
"""

from __future__ import annotations

import html as _html
import re
import time
from pathlib import Path
from typing import Any

from pko.errors import PkoError
from pko.extractors.runner import Extraction
from pko.progress.passport_gate import PLANNED_FIELDS, audience_of, journey_name_of
from pko.render.passport_map import (
    PASSPORT_MAP_CSS,
    PASSPORT_MAP_JS,
    build_passport_map,
    nodes_json,
)
from pko.progress.plan_input import PlanInput
from pko.progress.schema import ProgressModel

_TEMPLATE_PATH = Path(__file__).resolve().parents[3] / "passport-dpss-v3.html"

_EMPTY = "Не установлено по доступным артефактам"
_NEEDS_OWNER = "Требуется подтверждение владельца"


def render_client_journey_passport(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str = "",
    llm_values: dict[str, str] | None = None,
    registry_rows: list[dict[str, str]] | None = None,
    tree_spec: list[dict[str, Any]] | None = None,
) -> str:
    """Собрать заполненный HTML-паспорт из модели и экстракции.

    ``llm_values`` — плоский dict значений полей от агента (ключи вида
    ``{node}:{field}:value``, ``{node}:name``, ``analysis-scope`` и т.д.).
    Если передан, значения LLM перекрывают детерминированные (только непустые).

    ``registry_rows`` — строки реестра узлов от агента. Если не передан,
    реестр строится детерминированно из известных узлов.

    ``tree_spec`` — спецификация дерева узлов от агента (произвольное число
    узлов каждого типа). Если передана, рендерер клонирует
    ``<template>``-заготовки и перестраивает дерево.
    """
    template = _strip_removed_sections(_TEMPLATE_PATH.read_text(encoding="utf-8"))
    values = _build_fill_values(model, plan_input, repo_name, extraction, commit, branch, model_name)
    filled_by_agent = bool(llm_values)
    if llm_values:
        for key, val in llm_values.items():
            if val:
                values[key] = val
    if tree_spec:
        template = _insert_extra_nodes(template, tree_spec, registry_rows)
    if registry_rows is None:
        registry_rows = _build_registry(values)
    schema = build_passport_map(model)
    # Статус узла в реестре — тот же, что на схеме: считает код по пунктам ОР.
    status_by_id = {n["id"]: n.get("implementation_label", "") for n in schema.get("nodes", [])}
    template = _fill_registry(template, registry_rows, status_by_id)
    template = _fill_template(template, values)
    # Библиотека заготовок нужна только клонированию узлов; в выпуске её нет:
    # заготовка с унаследованным id и названием читается как пустой узел.
    template = _strip_templates(template)
    _assert_no_placeholders(template)
    template = _set_status_badge(template, filled_by_agent)
    template = _set_title(template, journey_name_of(plan_input.context, repo_name))
    summary = schema.get("summary") or {}
    schema["meta"] = {
        "scope": values.get("analysis-scope", ""),
        "audience": audience_of(plan_input.context),
        "boundary": values.get("decision-boundary", ""),
        "date": values.get("analysis-date", ""),
        "analysis": _analysis_scope_lines(extraction, commit, summary),
        "planned_fields": {k: sorted(v) for k, v in PLANNED_FIELDS.items()},
    }
    template = _finalize_html(template, schema)
    return template


_TEMPLATE_BLOCK_RE = re.compile(r'<template id="tpl-\w+">.*?</template>\s*', re.DOTALL)
_PLACEHOLDER_ID_RE = re.compile(r'id="(?:journey|process|bbb|operation)-N"')


def _strip_templates(template: str) -> str:
    """Убрать библиотеку заготовок. Сначала — комментарии: в них шаблон
    упоминает «<template id="tpl-journey">» текстом, и регулярка по тегам
    иначе съедает дерево до первого настоящего `</template>`."""
    return _TEMPLATE_BLOCK_RE.sub("", _COMMENT_RE.sub("", template))


def _assert_no_placeholders(template: str) -> None:
    """Ни один видимый узел не несёт `-N` в id — иначе в паспорт уехала заготовка."""
    stripped = _COMMENT_RE.sub("", template)
    if _PLACEHOLDER_ID_RE.search(stripped):
        raise PkoError(
            "в паспорт попала заготовка узла с id «-N»",
            "проверьте вставку узлов: заготовки клонируются только с реальным номером",
        )


def _analysis_scope_lines(extraction: Extraction, commit: str, summary: dict[str, Any]) -> list[str]:
    """Область анализа для шапки: что загружено и чего среди материалов нет.
    Явное «не проверялось» лучше молчания."""
    paths = {str(f.path) for f in getattr(extraction, "facts", []) or [] if getattr(f, "path", "")}
    lines = [f"файлов с фактами: {len(paths)}" if paths else "фактов из кода не извлечено"]
    if not commit:
        lines.append("git-история отсутствует: источник — архив или отдельные файлы, версия кода не привязана")
    total, unchecked = summary.get("handoffs_total") or 0, summary.get("wiring_unchecked") or 0
    if total and unchecked:
        lines.append(f"подключение в конфигурации сборки не проверено на {unchecked} из {total} передач")
    elif not total:
        lines.append("передачи между шагами не прослежены: целевых сценариев нет")
    return lines


_TITLE_RE = re.compile(r"(<h1\b[^>]*>)(.*?)(</h1>)", re.DOTALL)


def _set_title(html: str, name: str) -> str:
    """Заголовок страницы — «Паспорт инициативы «Название»».

    Название — из образа результата; в `<title>` оно же, чтобы вкладка и
    файл в письме опознавались без открытия.
    """
    title = f"Паспорт инициативы «{_html.escape(name)}»"
    html = _TITLE_RE.sub(lambda m: m.group(1) + title + m.group(3), html, count=1)
    return html.replace(
        "<title>Единый паспорт клиентского пути · ДПСС</title>",
        f"<title>{title}</title>", 1,
    )


def render_passport_from_model(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str = "",
) -> str:
    """Паспорт по итоговой модели прогона — общая точка для CLI и веба.

    Если паспортная сессия приняла хотя бы один узел (`model.passport_data`),
    дерево, реестр и поля берутся из него; иначе рендерер заполняет паспорт
    детерминированно из модели и экстракции и ставит бейдж «агент паспорт
    не заполнил».
    """
    data = model.passport_data
    return render_client_journey_passport(
        model, plan_input, repo_name, extraction,
        commit=commit, branch=branch, model_name=model_name,
        llm_values=flatten_passport_data(data) if data else None,
        registry_rows=passport_registry_rows(data) if data else None,
        tree_spec=passport_tree_spec(data) if data else None,
    )


# Бейдж в шапке. Шаблон приходит с «ЗАГОТОВКА · ПОЛЯ НЕ ЗАПОЛНЕНЫ», и
# заполненный паспорт уходил читателю с этой подписью. Статус переключает
# код: он один знает, кто заполнял поля.
STATUS_BADGE_TEMPLATE = "ЗАГОТОВКА · ПОЛЯ НЕ ЗАПОЛНЕНЫ"
STATUS_BADGE_AGENT = "ЗАПОЛНЕНО ПО КОДУ · БИЗНЕС-НАМЕРЕНИЕ ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ ВЛАДЕЛЬЦА"
STATUS_BADGE_FALLBACK = "ЗАПОЛНЕНО ДЕТЕРМИНИРОВАННО · АГЕНТ ПАСПОРТ НЕ ЗАПОЛНИЛ"


def _set_status_badge(html: str, filled_by_agent: bool) -> str:
    badge = STATUS_BADGE_AGENT if filled_by_agent else STATUS_BADGE_FALLBACK
    return html.replace(STATUS_BADGE_TEMPLATE, badge, 1)


# --- разделы шаблона, которых в паспорте нет -----------------------------------

# Контейнеры и заготовки потребности клиента и ограничения исполнения. Шаблон
# остаётся прежним (это стандарт заказчика), а из выпускаемого файла эти
# разделы вырезаются вместе с образцами need-1 и guardrail-1 внутри.
_REMOVED_CONTAINERS = ("related-needs", "related-guardrails")
_REMOVED_TEMPLATES = ("tpl-need", "tpl-guardrail")
# Разделы шаблона, которые вырезаются целиком по заголовку.
_REMOVED_SECTION_TITLES = ("Основание паспорта",)


def _strip_removed_sections(template: str) -> str:
    for container_id in _REMOVED_CONTAINERS:
        template = _remove_div_by_id(template, container_id)
    for tpl_id in _REMOVED_TEMPLATES:
        template = re.sub(
            rf'<template id="{tpl_id}">.*?</template>\s*', '', template, count=1, flags=re.DOTALL,
        )
    for title in _REMOVED_SECTION_TITLES:
        template = re.sub(
            rf'<section\b[^>]*>\s*<h2\b[^>]*>{re.escape(title)}</h2>.*?</section>\s*',
            '', template, count=1, flags=re.DOTALL,
        )
    return template


def _remove_div_by_id(template: str, element_id: str) -> str:
    """Убрать `<div id="…">…</div>` целиком, с учётом вложенных div."""
    m = re.search(rf'<div\b[^>]*id="{re.escape(element_id)}"[^>]*>', template)
    if not m:
        return template
    end = _closing_div_end(template, m.end())
    if end is None:
        return template
    return template[:m.start()] + template[end:]


def _closing_div_end(template: str, pos: int) -> int | None:
    """Позиция сразу после закрывающего `</div>` контейнера, открытого до `pos`."""
    depth = 1
    while depth > 0 and pos < len(template):
        open_m = re.search(r"<div\b", template[pos:])
        close_m = re.search(r"</div>", template[pos:])
        if close_m is None:
            return None
        if open_m and open_m.start() < close_m.start():
            depth += 1
            pos += open_m.end()
        else:
            depth -= 1
            pos += close_m.end()
            if depth == 0:
                return pos
    return None


# --- динамические узлы из ответа агента ---------------------------------------
#
# Агент может вернуть дерево с произвольным числом узлов каждого типа.
# Шаблон v3 содержит образцы (journey-1, process-1, bbb-1, ...) и
# <template>-заготовки для клонирования. Рендерер:
#   1. Находит узлы, которых ещё нет в HTML (по id).
#   2. Клонирует <template> нужного типа, заменяет -N на реальный номер.
#   3. Вставляет клон в data-children контейнер родителя.

_TEMPLATE_RE = re.compile(
    r'<template id="tpl-(\w+)">(.*?)</template>', re.DOTALL,
)

# HTML-комментарии: в шаблоне v3 внутри комментариев встречаются тексты
# вида «<template id="tpl-journey">» — они не теги, а подсказки агенту.
# Без удаления комментариев regex выше ловит их и ест половину файла.
_COMMENT_RE = re.compile(r'<!--.*?-->', re.DOTALL)


def _strip_comments(html: str) -> str:
    """Убрать HTML-комментарии, чтобы regex по тегам не матчил текст в них."""
    return _COMMENT_RE.sub("", html)


def _extract_templates(template: str) -> dict[str, str]:
    """Извлечь HTML-заготовки узлов из <template> элементов."""
    clean = _strip_comments(template)
    out: dict[str, str] = {}
    for m in _TEMPLATE_RE.finditer(clean):
        out[m.group(1)] = m.group(2)
    return out


def _clone_node(template_html: str, node_id: str) -> str:
    """Клонировать заготовку узла, заменив ``N`` в id на реальный номер."""
    number = node_id.rsplit("-", 1)[-1]
    return template_html.replace("-N", f"-{number}")


def _existing_node_ids(template: str) -> set[str]:
    """Найти id всех узлов, уже присутствующих в HTML (вне <template>)."""
    clean = _strip_comments(template)
    stripped = _TEMPLATE_RE.sub("", clean)
    return set(re.findall(
        r'id="((?:journey|process|bbb|operation)-\d+)"',
        stripped,
    ))


def _insert_extra_nodes(
    template: str,
    tree_spec: list[dict[str, Any]],
    registry_rows: list[dict[str, str]] | None,
) -> str:
    """Добавить недостающие узлы в HTML, клонируя <template>-заготовки.

    Работает с шаблоном v3, где нет ``id="tree"`` контейнера: узлы лежат
    напрямую в ``<section>``, а дочерние — в ``data-children`` контейнерах
    внутри родительского узла.
    """
    templates = _extract_templates(template)
    if not templates:
        return template

    existing = _existing_node_ids(template)

    # Собираем все id узлов из tree_spec и registry.
    all_nodes = _collect_all_node_ids(tree_spec, registry_rows)

    # Узлы, которые нужно добавить.
    missing = [nid for nid in all_nodes if nid not in existing]
    if not missing:
        return template

    # Для каждого недостающего узла: клонируем template и вставляем
    # в data-children контейнер родителя.
    for node_id in missing:
        node_type = _node_type(node_id)
        tpl = templates.get(node_type)
        if not tpl:
            continue
        clone = _clone_node(tpl, node_id)

        # Ищем родителя по registry. В столбце «Родитель» могут стоять
        # несколько узлов через запятую: карточка общего узла лежит под
        # первым, остальные родители — связи на схеме.
        parent_id = None
        for row in (registry_rows or []):
            if row.get("id") == node_id:
                parent_id = _first_parent(row.get("parent", ""))
                break

        if parent_id and parent_id != "—":
            # Вставляем в data-children="[type]" контейнер внутри родителя.
            template = _insert_into_parent(template, parent_id, node_type, clone)
        else:
            # Journey без родителя — вставляем после последнего journey.
            template = _insert_after_last_node(template, node_type, clone)

    return template


def _insert_into_parent(
    template: str, parent_id: str, child_type: str, clone_html: str,
) -> str:
    """Вставить клон узла в data-children контейнер внутри родительского узла.

    Ищем ``<div ... data-children="child_type" ...>...</div>`` внутри HTML
    родительского узла (по id) и вставляем клон перед закрывающим ``</div>``.
    """
    # Находим позицию родительского узла по id.
    parent_re = re.compile(rf'id="{re.escape(parent_id)}"')
    parent_m = parent_re.search(template)
    if not parent_m:
        return template

    # После родительского id ищем data-children="child_type" контейнер.
    search_start = parent_m.end()
    container_re = re.compile(
        rf'(<div\b[^>]*data-children="{child_type}"[^>]*>)',
    )
    if child_type == "bbb" and _node_type(parent_id) == "journey":
        # Узел до развилки живёт под клиентским путём, а у пути в шаблоне
        # только контейнер процессов: свой контейнер BBB добавляется перед
        # ним. Искать первый попавшийся data-children="bbb" нельзя — он
        # окажется внутри первого процесса.
        process_m = re.compile(r'<div\b[^>]*data-children="process"[^>]*>').search(template, search_start)
        if not process_m:
            return template
        holder_re = re.compile(r'(<div\b[^>]*data-children="bbb" data-before-fork="true"[^>]*>)')
        container_m = holder_re.search(template, search_start, process_m.start())
        if not container_m:
            holder = ('<div class="children" data-children="bbb" data-before-fork="true" '
                      'style="margin:24px 0 0 12px;padding-left:24px;border-left:1px dashed var(--g3)"></div>\n')
            template = template[:process_m.start()] + holder + template[process_m.start():]
            container_m = holder_re.search(template, search_start)
    else:
        container_m = container_re.search(template, search_start)
    if not container_m:
        return template

    # От начала контейнера ищем его закрывающий </div> (с учётом вложенности).
    pos = container_m.end()
    depth = 1
    while depth > 0 and pos < len(template):
        open_m = re.search(r"<div\b", template[pos:])
        close_m = re.search(r"</div>", template[pos:])
        if close_m is None:
            break
        if open_m and open_m.start() < close_m.start():
            depth += 1
            pos += open_m.end()
        else:
            depth -= 1
            if depth == 0:
                # Это закрывающий тег контейнера — вставляем перед ним.
                insert_pos = pos + close_m.start()
                return (
                    template[:insert_pos]
                    + "\n" + clone_html + "\n"
                    + template[insert_pos:]
                )
            pos += close_m.end()

    return template


def _first_parent(raw: str) -> str:
    """Первый родитель из столбца «Родитель» реестра («process-1, process-2»)."""
    parts = [p.strip() for p in str(raw or "").replace(";", ",").replace("·", ",").split(",")]
    return next((p for p in parts if p), "")


def _insert_after_last_node(
    template: str, node_type: str, clone_html: str,
) -> str:
    """Вставить клон после последнего узла того же типа (fallback)."""
    # Ищем все id="type-N" вне <template>.
    stripped = _TEMPLATE_RE.sub("", template)
    matches = list(re.finditer(
        rf'id="({node_type}-\d+)"', stripped,
    ))
    if not matches:
        return template
    # Вставляем после конца последнего узла — после следующего </div>
    # на том же уровне. Простой подход: вставляем перед началом следующего
    # блока (следующий узел или конец section).
    last_pos = matches[-1].end()
    # Ищем следующий </div> на нужной глубине — грубо, ищем
    # "<!--#NODE:" или "<div id=\"related-" после последнего узла.
    after = re.search(
        r'(<!--#NODE:|</section)',
        template[last_pos:],
    )
    if after:
        insert_pos = last_pos + after.start()
        return (
            template[:insert_pos]
            + "\n" + clone_html + "\n"
            + template[insert_pos:]
        )
    return template


def _collect_all_node_ids(
    tree_spec: list[dict[str, Any]] | None,
    registry_rows: list[dict[str, str]] | None,
) -> list[str]:
    """Собрать все id узлов из tree_spec и/или registry, в порядке появления."""
    seen: list[str] = []
    seen_set: set[str] = set()

    def visit(node: dict[str, Any]) -> None:
        nid = node.get("id", "")
        if nid and nid not in seen_set:
            seen.append(nid)
            seen_set.add(nid)
        for child in (node.get("children") or []):
            if isinstance(child, dict):
                visit(child)

    if tree_spec:
        for node in tree_spec:
            if isinstance(node, dict):
                visit(node)

    if registry_rows:
        for row in registry_rows:
            nid = row.get("id", "")
            if nid and nid not in seen_set:
                seen.append(nid)
                seen_set.add(nid)

    return seen

    return html


# --- данные ------------------------------------------------------------------

def _build_fill_values(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str,
) -> dict[str, str]:
    """Сопоставить поля шаблона с данными модели.

    Ключи — составные: `{node_id}:{fill_type}` или `{node_id}:{field_id}:{fill_type}`.
    `fill_type` — value | source | name | object-id | object-version.
    """
    ctx = plan_input.context
    # Название клиентского пути — строго из образа результата инициативы.
    # Имя проекта и репозитория — только запасные варианты, когда в тексте
    # пути названия нет вовсе.
    journey_name = journey_name_of(ctx, repo_name)
    project_name = ctx.get("project_name") or journey_name
    generated = time.strftime("%Y-%m-%d %H:%M")
    v: dict[str, str] = {}

    # --- мета (в шапку: раздела «Основание паспорта» в выпуске нет) ---
    v["analysis-scope"] = f"{repo_name} · коммит {commit[:8] if commit else '—'} · {project_name}"
    v["decision-boundary"] = "END_TO_END_PROCESS"
    v["analysis-date"] = generated

    # --- journey-1 (Клиентский путь) ---
    v["journey-1:name"] = journey_name
    v["journey-1:object-id"] = _EMPTY
    v["journey-1:object-version"] = _EMPTY
    v["journey-1:4.2.1:value"] = ctx.get("before") or _EMPTY
    v["journey-1:4.2.1:source"] = "образ результата инициативы"
    v["journey-1:4.2.2:value"] = ctx.get("client_path_name") or _EMPTY
    v["journey-1:4.2.2:source"] = "образ результата инициативы"
    v["journey-1:4.2.3:value"] = _NEEDS_OWNER
    v["journey-1:4.2.3:source"] = _EMPTY
    v["journey-1:4.2.4:value"] = (
        f"До: {ctx.get('before', _EMPTY)}. После: {ctx.get('after', _EMPTY)}."
    )
    v["journey-1:4.2.4:source"] = "образ результата инициативы"
    v["journey-1:4.2.5:value"] = _summary_outcomes(model)
    v["journey-1:4.2.5:source"] = "оценка агента по коду репозитория"
    v["journey-1:4.2.6:value"] = _stages_text(plan_input)
    v["journey-1:4.2.6:source"] = "образ результата инициативы"
    v["journey-1:4.2.7:value"] = _interaction_moments(model)
    v["journey-1:4.2.7:source"] = "оценка агента по коду репозитория"
    v["journey-1:4.2.8:value"] = _EMPTY
    v["journey-1:4.2.8:source"] = _EMPTY

    # --- process-1 (Автономный процесс) ---
    v["process-1:name"] = project_name
    v["process-1:object-id"] = _EMPTY
    v["process-1:object-version"] = _EMPTY
    v["process-1:4.3.1:value"] = f"Собирает и исполняет решение для клиентского пути «{journey_name}»."
    v["process-1:4.3.1:source"] = "образ результата инициативы"
    v["process-1:4.3.2:value"] = f"Клиентский путь: {journey_name}"
    v["process-1:4.3.2:source"] = "образ результата инициативы"
    v["process-1:4.3.3:value"] = _NEEDS_OWNER
    v["process-1:4.3.3:source"] = _EMPTY
    v["process-1:4.3.4:value"] = _entry_conditions(extraction)
    v["process-1:4.3.4:source"] = _extraction_source(extraction, "ROUTE")
    v["process-1:4.3.5:value"] = _routing_logic(model, plan_input)
    v["process-1:4.3.5:source"] = _extraction_source(extraction, "GRAPH_NODE")
    v["process-1:4.3.6:value"] = _bbbs_and_modes(extraction)
    v["process-1:4.3.6:source"] = _extraction_source(extraction, "TOOL")
    v["process-1:4.3.7:value"] = _fallback(model, extraction)
    v["process-1:4.3.7:source"] = "оценка агента по коду репозитория"
    v["process-1:4.3.8:value"] = _EMPTY
    v["process-1:4.3.8:source"] = _EMPTY
    v["process-1:4.3.9:value"] = f"Коммит: {commit or '—'}"
    v["process-1:4.3.9:source"] = "git-коммит"

    # --- bbb-1 (первый бизнес-блок) ---
    _fill_bbb(v, "bbb-1", extraction, model, 0)
    # --- bbb-2 ---
    _fill_bbb(v, "bbb-2", extraction, model, 1)
    # --- bbb-3 ---
    _fill_bbb(v, "bbb-3", extraction, model, 2)

    # --- operation-1, operation-2 ---
    _fill_operation(v, "operation-1", extraction, 0)
    _fill_operation(v, "operation-2", extraction, 1)

    return v


def _fill_bbb(v: dict, node_id: str, extraction: Extraction, model: ProgressModel, index: int) -> None:
    tools = extraction.by_kind("TOOL") + extraction.by_kind("GRAPH_NODE")
    fact = tools[index] if index < len(tools) else None
    if fact:
        v[f"{node_id}:name"] = fact.key
        v[f"{node_id}:object-id"] = _EMPTY
        v[f"{node_id}:object-version"] = _EMPTY
        v[f"{node_id}:4.4.1:value"] = str(fact.value or _EMPTY)[:200] if isinstance(fact.value, (str, dict)) else _EMPTY
        v[f"{node_id}:4.4.1:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.2:value"] = _EMPTY
        v[f"{node_id}:4.4.2:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.3:value"] = _NEEDS_OWNER
        v[f"{node_id}:4.4.3:source"] = _EMPTY
        v[f"{node_id}:4.4.4:value"] = _EMPTY
        v[f"{node_id}:4.4.4:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.5:value"] = _EMPTY
        v[f"{node_id}:4.4.5:source"] = _EMPTY
        v[f"{node_id}:4.4.6:value"] = _EMPTY
        v[f"{node_id}:4.4.6:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.7:value"] = _EMPTY
        v[f"{node_id}:4.4.7:source"] = _EMPTY
    else:
        for fill in ("name", "object-id", "object-version"):
            v[f"{node_id}:{fill}"] = _EMPTY
        for field in ("4.4.1", "4.4.2", "4.4.3", "4.4.4", "4.4.5", "4.4.6", "4.4.7"):
            v[f"{node_id}:{field}:value"] = _EMPTY
            v[f"{node_id}:{field}:source"] = _EMPTY


def _fill_operation(v: dict, node_id: str, extraction: Extraction, index: int) -> None:
    funcs = [f for f in extraction.by_kind("FUNCTION") if f.value and isinstance(f.value, dict) and f.value.get("doc")]
    fact = funcs[index] if index < len(funcs) else None
    if fact:
        doc = str(fact.value.get("doc") or _EMPTY)[:200]
        v[f"{node_id}:name"] = fact.key
        v[f"{node_id}:object-id"] = _EMPTY
        v[f"{node_id}:object-version"] = _EMPTY
        v[f"{node_id}:4.5.1:value"] = doc
        v[f"{node_id}:4.5.1:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.2:value"] = _EMPTY
        v[f"{node_id}:4.5.2:source"] = _EMPTY
        v[f"{node_id}:4.5.3:value"] = _NEEDS_OWNER
        v[f"{node_id}:4.5.3:source"] = _EMPTY
        v[f"{node_id}:4.5.4:value"] = _EMPTY
        v[f"{node_id}:4.5.4:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.5:value"] = _EMPTY
        v[f"{node_id}:4.5.5:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.6:value"] = _EMPTY
        v[f"{node_id}:4.5.6:source"] = _EMPTY
    else:
        for fill in ("name", "object-id", "object-version"):
            v[f"{node_id}:{fill}"] = _EMPTY
        for field in ("4.5.1", "4.5.2", "4.5.3", "4.5.4", "4.5.5", "4.5.6"):
            v[f"{node_id}:{field}:value"] = _EMPTY
            v[f"{node_id}:{field}:source"] = _EMPTY


# --- вспомогательные ---------------------------------------------------------

def _summary_outcomes(model: ProgressModel) -> str:
    if not model.verdicts:
        return _EMPTY
    done = sum(1 for v in model.verdicts for c in v.criteria if c.applicable and c.status == "done")
    total = sum(1 for v in model.verdicts for c in v.criteria if c.applicable)
    if done == total:
        return f"Все {total} пунктов реализованы — путь завершается успешно."
    if done > 0:
        return f"Из {total} пунктов полностью работают {done} — результат достигается частично."
    return f"Из {total} пунктов ни один не работает полностью — результат не подтверждён."


def _stages_text(plan_input: PlanInput) -> str:
    if not plan_input.stages:
        return _EMPTY
    return "; ".join(f"{i}. {s}" for i, s in enumerate(plan_input.stages, 1))


def _interaction_moments(model: ProgressModel) -> str:
    moments: list[str] = []
    for v in model.verdicts:
        for c in v.criteria:
            if c.applicable and c.how_text:
                moments.append(c.how_text[:120])
    if not moments:
        return _EMPTY
    return "; ".join(moments[:5])


def _entry_conditions(extraction: Extraction) -> str:
    routes = extraction.by_kind("ROUTE")
    if not routes:
        return _EMPTY
    return "Точка входа: " + ", ".join(f.key for f in routes[:3])


def _routing_logic(model: ProgressModel, plan_input: PlanInput) -> str:
    parts: list[str] = []
    if plan_input.stages:
        parts.append("Этапы: " + " → ".join(plan_input.stages))
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        done = sum(1 for c in v.criteria if c.applicable and c.status == "done")
        total = sum(1 for c in v.criteria if c.applicable)
        parts.append(f"{item.title}: {done}/{total}")
    return "; ".join(parts[:5]) or _EMPTY


def _bbbs_and_modes(extraction: Extraction) -> str:
    tools = extraction.by_kind("TOOL")
    if not tools:
        return _EMPTY
    return ", ".join(f.key for f in tools[:5])


def _fallback(model: ProgressModel, extraction: Extraction) -> str:
    for v in model.verdicts:
        for c in v.criteria:
            if c.applicable and c.status in ("partial", "blocked"):
                return "Обнаружены нереализованные пункты — требуется ручная проверка"
    return _EMPTY


def _extraction_source(extraction: Extraction, kind: str) -> str:
    facts = extraction.by_kind(kind)
    if not facts:
        return _EMPTY
    f = facts[0]
    return f"{f.path}:{f.line}" if f.line else f.path


# --- реестр узлов ------------------------------------------------------------

_NODE_META = [
    ("journey-1", "Клиентский путь", "—"),
    ("process-1", "Автономный процесс", "journey-1"),
    ("bbb-1", "BBB", "process-1"),
    ("operation-1", "Атомарная операция", "bbb-1"),
]


def _build_registry(values: dict[str, str]) -> list[dict[str, str]]:
    """Построить реестр узлов из заполненных значений (fallback без LLM)."""
    rows: list[dict[str, str]] = []
    for node_id, type_label, parent in _NODE_META:
        name = values.get(f"{node_id}:name", "")
        rows.append({
            "id": node_id,
            "type": type_label,
            "name": name,
            "parent": parent,
            "basis": "обнаружен в коде репозитория",
        })
    return rows


_REGISTRY_TBODY_RE = re.compile(
    r"(<table[^>]*class=\"registry\"[^>]*>.*?<tbody>)(.*?)(</tbody>)",
    re.DOTALL,
)


_REGISTRY_STATUS_TH = (
    '<th style="width:14%;text-align:left;padding:0 16px 10px;font-size:17px;font-weight:700;'
    'color:#000;vertical-align:bottom;border-bottom:1px solid #000">Статус</th>'
)


def _fill_registry(template: str, rows: list[dict[str, str]],
                   status_by_id: dict[str, str] | None = None) -> str:
    """Заполнить таблицу реестра узлов строками.

    Заменяет содержимое ``<tbody>`` шаблона на строки из ``rows``.
    Сохраняет структуру ``<td data-col="...">`` для CSS. Столбец «Статус»
    (реализован / с ограничениями / частично / не реализован / недостаточно
    данных) добавляется кодом: в шаблоне его нет, а без него планируемый
    процесс стоит в одном ряду с работающими и отличим только по прозе.
    """
    if not rows:
        return template
    status_by_id = status_by_id or {}

    def replace_tbody(m: re.Match) -> str:
        open_tag = m.group(1)
        close_tag = m.group(3)

        col_names = ["HTML-id", "Тип", "Название", "Родитель", "Статус", "Основание"]
        col_keys = ["id", "type", "name", "parent", "status", "basis"]

        new_rows: list[str] = []
        for row in rows:
            row = {**row, "status": status_by_id.get(str(row.get("id", "")), "") or "—"}
            cells = []
            for col_name, col_key in zip(col_names, col_keys):
                val = _html.escape(str(row.get(col_key, "")), quote=False)
                cells.append(f'<td data-col="{col_name}">{val}</td>')
            new_rows.append("<tr>" + "".join(cells) + "</tr>")

        return open_tag + "\n" + "\n".join(new_rows) + "\n" + close_tag

    template = _REGISTRY_TBODY_RE.sub(replace_tbody, template, count=1)
    # Заголовок столбца — перед «Основание существования узла».
    return re.sub(
        r'(<th\b[^>]*>Основание существования узла</th>)',
        _REGISTRY_STATUS_TH + r'\1', template, count=1,
    )


# --- HTML-рендерер -----------------------------------------------------------
#
# Шаблон v3 использует <div class="node [type]" id="[type]-N"> вместо <details>.
# Линейный проход: отслеживаем текущий узел (по id на div.node) и поле
# (data-field), пропускаем HTML-комментарии.
#
# fill types:
#   name, object-id, object-version → ключ {node}:{fill} (без поля)
#   value, source                   → ключ {node}:{field}:{fill}
#   analysis-scope, decision-boundary, analysis-date → ключ {fill} (вне узлов)

# Узел: id="(journey|process|bbb|operation)-N" на любом теге.
# Поле: data-field="X.Y.Z". Заполнение: data-fill="value|source|name|...".

_TOKEN_RE = re.compile(
    r'(<!--.*?-->)'                                                  # 1: comment (skip)
    r'|(id="((?:journey|process|bbb|operation)-\d+)")'                # 2,3: node id
    r'|(data-field="([^"]+)")'                                       # 4,5: data-field
    r'|(data-fill="([^"]+)"[^>]*>)([^<]*)(</(?:div|span)>)',        # 6,7,8,9: data-fill element
    re.DOTALL,
)

_NODE_FILLS = {"name", "object-id", "object-version"}
_FIELD_FILLS = {"value", "source"}
_NODE_ID_RE = re.compile(
    r"^(?:journey|process|bbb|operation)-\d+$"
)


def _fill_template(template: str, values: dict[str, str]) -> str:
    """Заполнить data-fill элементы значениями из dict.

    Линейный проход: отслеживаем текущий узел (по id) и поле (data-field),
    пропускаем комментарии. Каждый data-fill заполняется по ключу
    {node}:{field}:{fill} или {node}:{fill} или {fill}.

    Работает с шаблоном v3, где узлы — ``<div class="node" id="X">``, а не
    ``<details>``: нет стека open/close, текущий узел обновляется при
    обнаружении нового id узла.
    """
    parts: list[str] = []
    last_end = 0
    current_node: str | None = None
    current_field: str | None = None

    for m in _TOKEN_RE.finditer(template):
        parts.append(template[last_end:m.start()])
        last_end = m.end()

        if m.group(1) is not None:
            # HTML-комментарий — пропускаем как есть
            parts.append(m.group(0))
        elif m.group(3) is not None:
            # id="journey-1" / id="process-2" и т.д. — вход в узел.
            # В v3 узлы не вкладываются через details, а идут последовательно:
            # новый id узла означает, что предыдущий закончился.
            current_node = m.group(3)
            current_field = None
            parts.append(m.group(0))
        elif m.group(5) is not None:
            # data-field="X.Y.Z"
            current_field = m.group(5)
            parts.append(m.group(0))
        elif m.group(7) is not None:
            # data-fill="..." element
            fill_type = m.group(7)
            open_tag = m.group(6)
            content = m.group(8)
            close_tag = m.group(9)
            key = _make_key(current_node, current_field, fill_type)
            val = values.get(key, "") if key else ""
            if val:
                safe = _html.escape(val, quote=False)
                parts.append(open_tag + safe + close_tag)
            else:
                parts.append(m.group(0))

    parts.append(template[last_end:])
    return "".join(parts)


def _make_key(node: str | None, field: str | None, fill: str) -> str | None:
    """Собрать ключ для values dict по контексту узла и поля."""
    if fill in _NODE_FILLS:
        return f"{node}:{fill}" if node else None
    if fill in _FIELD_FILLS:
        return f"{node}:{field}:{fill}" if node and field else None
    return fill


# --- разбор passport_data от агента ------------------------------------------
#
# Агент-матчер вызывает инструмент `submit_passport` с JSON-объектом,
# содержащим значения полей паспорта. Эти функции преобразуют его в плоский
# dict для `_fill_template` и в строки реестра.

_FIELD_MAP = {
    "journey": ["4.2.1", "4.2.2", "4.2.3", "4.2.4", "4.2.5", "4.2.6", "4.2.7", "4.2.8"],
    "process": ["4.3.1", "4.3.2", "4.3.3", "4.3.4", "4.3.5", "4.3.6", "4.3.7", "4.3.8", "4.3.9"],
    "bbb": ["4.4.1", "4.4.2", "4.4.3", "4.4.4", "4.4.5", "4.4.6", "4.4.7"],
    "operation": ["4.5.1", "4.5.2", "4.5.3", "4.5.4", "4.5.5", "4.5.6"],
}

_SAMPLE_NODES = {
    "journey-1": "journey",
    "process-1": "process",
    "bbb-1": "bbb",
    "operation-1": "operation",
}

_NODE_TYPE_PREFIXES = ("journey", "process", "bbb", "operation")


def _node_type(node_id: str) -> str:
    """Тип узла по id: journey-1 → journey, bbb-3 → bbb."""
    for prefix in _NODE_TYPE_PREFIXES:
        if node_id.startswith(prefix + "-"):
            return prefix
    return ""


def flatten_passport_data(data: dict[str, Any] | None) -> dict[str, str]:
    """Преобразовать JSON-ответ агента (``submit_passport``) в плоский dict.

    Ключи совпадают со схемой ``_fill_template``:
    - ``analysis-scope``, ``decision-boundary``, ``analysis-date``
    - ``{node}:name``, ``{node}:object-id``, ``{node}:object-version``
    - ``{node}:{field}:value``, ``{node}:{field}:source``

    Обрабатывает произвольное число узлов — агент может вернуть
    journey-1, journey-2, bbb-1, bbb-2, bbb-3 и т.д.
    """
    if not data or not isinstance(data, dict):
        return {}

    v: dict[str, str] = {}
    v["analysis-scope"] = str(data.get("analysis-scope", ""))
    v["decision-boundary"] = str(data.get("decision-boundary", ""))
    v["analysis-date"] = str(data.get("analysis-date", ""))

    nodes = data.get("nodes", {})
    if not isinstance(nodes, dict):
        return v

    for node_id, node in nodes.items():
        if not isinstance(node, dict):
            continue
        node_type = _node_type(str(node_id))
        if not node_type:
            continue
        v[f"{node_id}:name"] = str(node.get("name", ""))
        v[f"{node_id}:object-id"] = str(node.get("object-id", ""))
        v[f"{node_id}:object-version"] = str(node.get("object-version", ""))
        fields = node.get("fields", {})
        if not isinstance(fields, dict):
            continue
        for field_id in _FIELD_MAP.get(node_type, []):
            field = fields.get(field_id, {})
            if not isinstance(field, dict):
                continue
            v[f"{node_id}:{field_id}:value"] = str(field.get("value", ""))
            v[f"{node_id}:{field_id}:source"] = str(field.get("source", ""))

    return v


def passport_tree_spec(data: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Извлечь спецификацию дерева узлов из ответа агента.

    Возвращает список корневых узлов (journey), каждый может содержать
    ``children`` (process → bbb → operation). Используется ``rebuild_tree``
    для клонирования ``<template>``-заготовок.
    """
    if not data or not isinstance(data, dict):
        return []
    tree = data.get("tree")
    if isinstance(tree, list):
        return tree
    # Если tree нет, строим из nodes по известным образцам.
    nodes = data.get("nodes", {})
    if not isinstance(nodes, dict):
        return []
    tree_spec = []
    for node_id, node in nodes.items():
        if not isinstance(node, dict):
            continue
        node_type = _node_type(str(node_id))
        if node_type == "journey":
            tree_spec.append({"id": str(node_id), "type": "journey", "children": []})
    # Упрощённая сборка: процессы под первый journey, BBB под первый процесс.
    journeys = [n for n in tree_spec if n["type"] == "journey"]
    if not journeys:
        return []
    journey = journeys[0]
    processes = []
    for node_id, node in nodes.items():
        if _node_type(str(node_id)) == "process":
            processes.append({"id": str(node_id), "type": "process", "children": []})
    journey["children"] = processes
    for proc in processes:
        bbbs = []
        for node_id, node in nodes.items():
            if _node_type(str(node_id)) == "bbb":
                bbbs.append({"id": str(node_id), "type": "bbb", "children": []})
        proc["children"] = bbbs
        for bbb in bbbs:
            ops = []
            for node_id, node in nodes.items():
                if _node_type(str(node_id)) == "operation":
                    ops.append({"id": str(node_id), "type": "operation"})
            bbb["children"] = ops
        break  # только под первый BBB
    return tree_spec


def passport_registry_rows(data: dict[str, Any] | None) -> list[dict[str, str]]:
    """Строки реестра узлов из ответа агента."""
    if not data or not isinstance(data, dict):
        return []
    rows = data.get("registry", [])
    if not isinstance(rows, list):
        return []
    out: list[dict[str, str]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        out.append({
            "id": str(row.get("id", "")),
            "type": str(row.get("type", "")),
            "name": str(row.get("name", "")),
            "parent": str(row.get("parent", "")),
            "basis": str(row.get("basis", "")),
        })
    return out


# --- финализация HTML: убираем зависимость от DCLogic/support.js -------------
#
# Шаблон v3 — это DCLogic-компонент: Mustache-плейсхолдеры `{{ ... }}`,
# `style-hover` (нестандартный атрибут), внешний `support.js` и класс
# `Component extends DCLogic`. Без движка всё ломается: кнопки не работают,
# узлы не раскрываются, анимация не применяется.
#
# `_finalize_html` делает шаблон самодостаточным:
#   1. Убирает `<script src="./support.js">` и DCLogic-скрипт.
#   2. Заменяет Mustache-плейсхолдеры на статические значения.
#   3. Убирает `data-anim` / `data-uneditable` / `style-hover`.
#   4. Конвертирует `style-hover` в CSS `:hover`.
#   5. Добавляет свой `<script>` для сворачивания/разворачивания узлов.

_MUSTACHE_RE = re.compile(r"\{\{[^}]+\}\}")

# Статические значения для Mustache-плейсхолдеров. Узлы раскрыты по умолчанию
# (кроме operation и guardrail — их много, и они длинные).
_MUSTACHE_VALUES: dict[str, str] = {
    "allLabel": "Свернуть все",
    "panelRows": "0fr",
    "iconOpacity": ".65",
    "grayVal": "1",
    "grayPct": "100%",
    "oJourney": "1fr", "rJourney": "180deg",
    "oProcess": "1fr", "rProcess": "180deg",
    "oBbb": "1fr", "rBbb": "180deg",
    "oOperation": "0fr", "rOperation": "0deg",
    "oGuardrail": "0fr", "rGuardrail": "0deg",
}
# Callback-плейсхолдеры (onClick/onInput) — заменяем на пустые вызовы.
_MUSTACE_CALLBACKS = {
    "tJourney", "tProcess", "tBbb", "tOperation", "tGuardrail",
    "toggleAll", "onGray", "hidePanel", "showPanel",
}

# Раскладка отчёта: заголовок «Паспорт инициативы» → карта дерева на всю
# область (зум колесом и кнопками, панорама перетаскиванием) → карточка
# выбранного узла в боковой панели. Карточки узлов из шаблона остаются в DOM
# скрытым хранилищем — JS строит карту по их вложенности, а карточку
# выбранного узла клонирует из них. Все родители узла берутся из столбца
# «Родитель» реестра, который построил код; связи — из схемы. Шапка,
# реестр и футер шаблона на экран не идут: всё, что нужно читателю,
# доступно с карты. Планируемый узел в карточке показывает только поля
# бизнес-смысла, у процесса отдельным блоком — известные дефекты.
_INLINE_CSS = """<style data-passport-fix>
[data-uneditable]{display:none!important}
/* Исходные разделы шаблона — источник данных, на экран не идут. */
#pko-store,.pko-hidden{display:none!important}
html,body{height:100%;overflow:hidden}
.pko-page{max-width:none!important;padding:0!important;margin:0!important;height:100vh;display:flex;flex-direction:column;background:#F8FAFC}
/* === Шапка === */
.pko-head{display:grid;grid-template-columns:minmax(280px,1fr) minmax(520px,auto);grid-template-areas:"title meta" "legend legend";align-items:start;gap:2px 24px;padding:10px 20px 8px;border-bottom:1px solid #D8E0E6;background:#fff;box-shadow:0 4px 18px rgba(30,48,65,.05);flex:none;z-index:10}
.pko-head h1{grid-area:title;display:flex;flex-wrap:wrap;align-items:center;gap:10px 14px;font-size:20px;font-weight:750;line-height:1.2;letter-spacing:-.02em;margin:0;color:#18232E;overflow-wrap:anywhere}
.pko-head .pko-badge{font-size:11px;font-weight:750;color:#526373;letter-spacing:.04em;text-align:right;white-space:nowrap}
.pko-head .pko-scope{font-size:11px;color:#6D7D8A;white-space:nowrap}
.pko-head-meta{display:flex;flex-direction:column;align-items:flex-end;gap:4px;min-width:0}
.pko-head .pko-nav{display:inline-flex;margin:0}.pko-head-meta{grid-area:meta}.pko-head .pko-legend-host{grid-area:legend;min-width:0}
.pko-head .pko-analysis{font-size:11px;color:#6D7D8A;line-height:1.35;margin-top:4px;max-width:70ch}
.pko-head .pko-analysis span{display:inline-block;margin-right:10px}
.pko-nav{display:flex;gap:6px;flex-wrap:wrap}
.pko-nav button{height:26px;padding:0 9px;border:1px solid #CBD5DE;border-radius:8px;background:#fff;cursor:pointer;font-size:12px;font-weight:700;color:#263746;font-family:inherit}
.pko-nav button:hover{border-color:#8B78D8}.pko-nav button.on{border-color:#7C5CE6;background:#F5F1FF}
.pko-nav button b{font-weight:800;color:#5C45B8;margin-left:4px}
.pko-page-panel{position:absolute;left:0;right:0;top:0;bottom:0;z-index:20;background:#F8FAFC;display:none;flex-direction:column}
.pko-page-panel.open{display:flex}
.pko-page-head{display:flex;align-items:center;gap:14px;padding:12px 20px;border-bottom:1px solid #D8E0E6;background:#fff;flex:none}
.pko-page-head h2{font-size:16px;font-weight:750;margin:0;color:#18232E}
.pko-page-head .sub{font-size:12px;color:#6D7D8A}
.pko-page-head .spacer{flex:1}
.pko-page-head .pko-filter{font-size:12px;color:#5C45B8;background:#F5F1FF;border:1px solid #C4B5FD;border-radius:8px;padding:4px 9px;cursor:pointer}
.pko-page-body{flex:1;min-height:0;overflow:auto;padding:16px 20px 40px}
.pko-table{width:100%;border-collapse:collapse;font-size:12.5px;background:#fff;border:1px solid #D8E0E6;border-radius:10px;overflow:hidden}
.pko-table th{position:sticky;top:0;background:#F1F4F7;text-align:left;padding:9px 10px;font-size:11px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;color:#526373;border-bottom:1px solid #D8E0E6;z-index:1}
.pko-table td{padding:9px 10px;border-bottom:1px solid #E7ECF0;vertical-align:top;line-height:1.4}
.pko-table tr.link{cursor:pointer}.pko-table tr.link:hover td{background:#F8F5FF}.pko-table tr.hit td{background:#F0ECFF}
.pko-table td a{color:#5C45B8;text-decoration:none;border-bottom:1px dotted #8B78D8;cursor:pointer;white-space:nowrap}
.pko-table .tag{display:inline-block;font-size:10px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;border-radius:4px;padding:1px 6px;border:1px solid #CBD5DE;color:#334155;background:#fff;white-space:nowrap}
.pko-table .tag.ok{color:#09615D;border-color:#2CB6B0;background:#DDF5F2}.pko-table .tag.broken{color:#9C1833;border-color:#E2556F;background:#FCE5EB}.pko-table .tag.unknown{color:#405160;border-color:#B7C2CB;background:#F0F2F2}
.pko-table .tag.blocking{color:#fff;background:#C73955;border-color:#C73955}
.pko-table .tag.completeness{color:#8B430C;border-color:#F0C674;background:#FFF7E6}.pko-table .tag.integration{color:#3E4C9A;border-color:#93C5FD;background:#EAF4FF}.pko-table .tag.data{color:#1D4ED8;border-color:#93C5FD;background:#EAF4FF}.pko-table .tag.wiring{color:#6D28D9;border-color:#C4B5FD;background:#F5F1FF}
.pko-table .tag.implemented{color:#09615D;border-color:#2CB6B0}.pko-table .tag.limited{color:#765400;border-color:#E0A100}.pko-table .tag.partial{color:#8B430C;border-color:#C66A1B}.pko-table .tag.not_implemented{color:#9C1833;border-color:#C73955}
.pko-table .checks{display:flex;flex-wrap:wrap;gap:4px}
.pko-table .checks .tag{cursor:help}
.pko-table .note{font-size:11.5px;color:#6D7D8A;margin-top:3px}
.pko-table .mono{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11.5px}
.pko-page-foot{margin-top:12px;font-size:12px;color:#526373}
.pko-node-defects{margin:0 24px 20px;padding:12px 14px;border:1px solid #F5C2CC;border-radius:10px;background:#FFF7F8;font-size:13px;line-height:1.5}
.pko-node-defects a{color:#9C1833;cursor:pointer;border-bottom:1px dotted #9C1833}
.pko-metrics{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:0;margin-top:2px;border:1px solid #D8E0E6;border-radius:9px;background:#F8FAFC;overflow:hidden}
.pko-metric{display:inline-flex;flex-direction:column;gap:0;padding:5px 10px;border-left:1px solid #D8E0E6;font-size:10px;line-height:1.2;color:#607180;white-space:nowrap}
.pko-metric:first-child{border-left:0}
.pko-metric b{font-size:15px;line-height:1.25;color:#18232E;font-variant-numeric:tabular-nums}
/* === Карта (общий компонент passport_map) === */
""" + PASSPORT_MAP_CSS + """
/* === Боковая карточка узла === */
.pko-drawer{position:fixed;top:0;right:0;height:100vh;width:min(520px,100vw);background:#fff;border-left:1px solid #D8E0E6;box-shadow:-24px 0 56px -28px rgba(30,48,65,.36);transform:translateX(100%);transition:transform .22s cubic-bezier(.2,.7,.2,1);z-index:100;display:flex;flex-direction:column}
.pko-drawer.open{transform:none}
.pko-drawer-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 20px;border-bottom:1px solid #D8E0E6;background:#F8FAFC;flex:none}
.pko-drawer-head .pko-drawer-title{font-size:11px;font-weight:800;color:#526373;letter-spacing:.06em;text-transform:uppercase}
.pko-drawer-close{width:40px;height:40px;border:1px solid #CBD5DE;border-radius:9px;background:#fff;cursor:pointer;font-size:20px;line-height:1;font-family:inherit;color:#263746}
.pko-drawer-close:hover{border-color:#7C5CE6;background:#F5F1FF}
.pko-drawer-close:focus-visible{outline:3px solid rgba(124,92,230,.3);outline-offset:1px}
.pko-drawer-body{flex:1;min-height:0;overflow:auto;padding:18px 20px 32px}
.pko-drawer-body .node{border:1px solid #D8E0E6;border-radius:12px;background:#fff;box-shadow:0 8px 24px rgba(30,48,65,.06)}
.pko-drawer-body .node .pko-collapsible{grid-template-rows:1fr!important}
.pko-drawer-body .node .children{display:none!important}
.pko-drawer-body .node>div:first-child{cursor:default}
/* Панель узкая: поле в один столбец — подпись над значением, без обрезки. */
.pko-drawer-body .field{grid-template-columns:minmax(0,1fr)!important;gap:6px 0!important}
.pko-drawer-body .identity{grid-template-columns:minmax(0,1fr)!important}
.pko-drawer-body .node-body,.pko-drawer-body .field,.pko-drawer-body .field *{overflow-wrap:anywhere;min-width:0}
.pko-links{display:flex;gap:8px;flex-wrap:wrap;padding:0 24px 20px;font-size:13px;color:var(--g1)}
.pko-links a{color:#7C5CE6;text-decoration:none;border-bottom:1px dotted #7C5CE6;cursor:pointer}
.pko-links a:hover{border-bottom-style:solid}
.pko-node-assessment{margin:0 0 14px;padding:12px 14px;border:1px solid #D8E0E6;border-radius:10px;background:#F8FAFC;font-size:13px;line-height:1.5}
.pko-node-assessment .state{display:inline-block;font-weight:700;margin-bottom:5px}.pko-node-assessment ul{margin:6px 0 0;padding-left:18px}
.pko-node-relations{margin:0 24px 20px;padding:12px 14px;border:1px solid #D8E0E6;border-radius:10px;background:#F8FAFC;font-size:13px;line-height:1.5}
.pko-node-relations .lbl{font-size:11px;font-weight:800;color:#526373;letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px}
.pko-node-relations ul{margin:0;padding-left:18px}.pko-node-relations .basis{font-size:12px;color:#6D7D8A}
.pko-node-relations li{margin-bottom:6px}
.pko-node-relations .kind{display:inline-block;font-size:10px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;border-radius:4px;padding:1px 6px;margin-right:4px;border:1px solid #CBD5DE;color:#334155;background:#fff}
.pko-node-relations .kind.precedes{color:#475569;border-color:#94A3B8}.pko-node-relations .kind.feeds{color:#1D4ED8;border-color:#93C5FD}.pko-node-relations .kind.triggers{color:#C2410C;border-color:#FDBA74}.pko-node-relations .kind.depends_on{color:#6D28D9;border-color:#C4B5FD}.pko-node-relations .kind.fallback{color:#B45309;border-color:#FCD34D}.pko-node-relations .kind.confirms{color:#15803D;border-color:#86EFAC}
.pko-node-defects{margin:0 24px 20px;padding:12px 14px;border:1px solid #F5C2CC;border-radius:10px;background:#FFF7F8;font-size:13px;line-height:1.5}
.pko-node-defects .lbl{font-size:11px;font-weight:800;color:#9C1833;letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px}
.pko-node-defects ul{margin:0;padding-left:18px}
.pko-node-flags{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 10px}
.pko-node-flags span{font-size:10px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;border-radius:5px;padding:3px 7px;background:#F0ECFF;color:#5C45B8}
.pko-node-flags span.planned{background:#FCE5EB;color:#9C1833}
.pko-node-planned-note{margin:0 0 12px;font-size:12px;color:#6D7D8A}
@media(max-width:980px){.pko-head{grid-template-columns:1fr;gap:8px}.pko-head-meta{align-items:flex-start}.pko-metrics{justify-content:flex-start}.pko-head .pko-badge,.pko-head .pko-scope{white-space:normal;text-align:left}}
@media(prefers-reduced-motion:reduce){.pko-drawer{transition:none}}
</style>
"""

_INLINE_JS = """<script data-passport-fix>""" + PASSPORT_MAP_JS + """
(function(){
  var SCHEMA=__PKO_SCHEMA__;
  // --- 1. Данные: узлы из DOM (карточки шаблона) + родители из реестра ---
  var store=document.createElement('div'); store.id='pko-store';
  var nodeEls=Array.prototype.slice.call(document.querySelectorAll('.node[id]'));
  var els={}, nodes=[];
  nodeEls.forEach(function(el){
    var type=el.getAttribute('data-type')||(el.id.split('-')[0]);
    var nameEl=el.querySelector('[data-fill="name"]');
    var parentEl=el.parentElement?el.parentElement.closest('.node[id]'):null;
    els[el.id]=el;
    nodes.push({id:el.id,type:type,name:(nameEl?nameEl.textContent:el.id).trim(),parent:parentEl?parentEl.id:null,parents:parentEl?[parentEl.id]:[]});
  });
  var byNode={}; nodes.forEach(function(n){byNode[n.id]=n});
  // Оценка узлов, пути и связи рассчитаны бэкендом. DOM остаётся источником
  // полных карточек паспорта, а схема — источником статуса, проблем и связей.
  (SCHEMA.nodes||[]).forEach(function(e){
    var n=byNode[e.id]; if(!n) return;
    Object.keys(e).forEach(function(k){n[k]=e[k]});
  });
  // Все родители — из столбца «Родитель» реестра: карточка общего узла лежит
  // в DOM под первым, остальные родители — рёбра на схеме.
  var registry=document.querySelector('table.registry');
  if(registry){
    Array.prototype.forEach.call(registry.querySelectorAll('tbody tr'),function(tr){
      var idCell=tr.querySelector('[data-col="HTML-id"]'); if(!idCell) return;
      var id=idCell.textContent.trim(); var n=byNode[id];
      var parentCell=tr.querySelector('[data-col="Родитель"]');
      if(n&&parentCell){
        var listed=parentCell.textContent.split(/[,;·]/).map(function(s){return s.trim()}).filter(function(s){return byNode[s]});
        if(listed.length){ n.parents=listed; n.parent=listed[0]; }
      }
    });
  }

  // --- 2. Страница: шапка → карта → боковая панель; разделы шаблона в хранилище ---
  var header=document.querySelector('header');
  var page=header?header.parentElement:document.body;
  page.classList.add('pko-page');
  var h1=header?header.querySelector('h1'):null;
  var badgeEl=header?header.querySelector('div>div:last-child'):null;
  var meta=SCHEMA.meta||{};
  var head=document.createElement('div'); head.className='pko-head';
  var hTitle=document.createElement('h1'); hTitle.textContent=h1?h1.textContent.trim():'Паспорт инициативы'; head.appendChild(hTitle);
  var hMeta=document.createElement('div'); hMeta.className='pko-head-meta';
  var badge=document.createElement('div'); badge.className='pko-badge'; badge.textContent=badgeEl?badgeEl.textContent.trim():''; hMeta.appendChild(badge);
  var scope=document.createElement('div'); scope.className='pko-scope'; scope.textContent=meta.scope||''; hMeta.appendChild(scope);
  var nav=document.createElement('div'); nav.className='pko-nav'; hTitle.appendChild(nav);
  var legendHost=document.createElement('div'); legendHost.className='pko-legend-host';
  var summary=SCHEMA.summary||{}, score=summary.assessment||{};
  var metrics=document.createElement('div'); metrics.className='pko-metrics';
  function metric(label,value){var el=document.createElement('span'); el.className='pko-metric'; var l=document.createElement('span'); l.textContent=label; var v=document.createElement('b'); v.textContent=value; el.appendChild(l); el.appendChild(v); metrics.appendChild(el);}
  metric('Сценариев собрано',(summary.scenarios_total?(summary.scenarios_assembled||0)+' из '+summary.scenarios_total:'нет'));
  metric('Блокирующих разрывов',String(summary.blocking_breaks||0));
  metric('Недостаточно данных',String(summary.unknown_nodes||0)+' узл.');
  metric('Полнота',score.completeness==null?'не измерена':score.completeness+'%');
  metric('Связность',score.connectivity_measured?(score.connectivity==null?0:score.connectivity)+'%':'не измерена');
  if(summary.mapping_coverage!=null) metric('Покрытие схемой',summary.mapping_coverage+'%');
  if(summary.planned_nodes) metric('Планируется',String(summary.planned_nodes)+' узл.');
  hMeta.appendChild(metrics);
  head.appendChild(hMeta); head.appendChild(legendHost);
  var viewport=document.createElement('div');
  var drawer=document.createElement('aside'); drawer.className='pko-drawer';
  drawer.innerHTML='<div class="pko-drawer-head"><div class="pko-drawer-title">Паспорт узла</div><button type="button" class="pko-drawer-close" title="Закрыть">×</button></div><div class="pko-drawer-body"></div>';
  var drawerBody=drawer.querySelector('.pko-drawer-body');
  // Коллекция живая: копируем список до переноса, иначе пропускается каждый второй элемент.
  Array.prototype.slice.call(page.children).forEach(function(el){store.appendChild(el)});
  page.appendChild(head); page.appendChild(viewport); page.appendChild(store); document.body.appendChild(drawer);

  // --- 3. Карта и карточка выбранного узла ---
  var map=null;
  function link(id,label){var a=document.createElement('a'); a.textContent=label||(id+' «'+(map.nodes[id]?map.nodes[id].name:id)+'»'); a.addEventListener('click',function(){map.select(id)}); return a;}
  function closeDrawer(){
    drawer.classList.remove('open'); map.clear(); pageFilter=null; if(openPage) renderPages();
    if(location.hash) history.replaceState(null,'',location.pathname+location.search);
  }
  function show(n,byId,relations){
    var clone=els[n.id].cloneNode(true);
    clone.removeAttribute('id'); clone.classList.remove('collapsed'); clone.removeAttribute('data-anim');
    var head=clone.firstElementChild; if(head){head.removeAttribute('onClick'); head.removeAttribute('onclick'); var arrow=head.querySelector('svg'); if(arrow&&arrow.parentElement) arrow.parentElement.style.display='none';}
    var grid=head?head.nextElementSibling:null; if(grid){grid.classList.add('pko-collapsible'); grid.style.gridTemplateRows='1fr';}
    Array.prototype.forEach.call(clone.querySelectorAll('.children'),function(c){c.parentNode.removeChild(c)});
    var d=n.data||{};
    // Планируемый узел: поля о поведении кода, которого нет, в карточке не
    // показываются — остаются бизнес-смысл, владелец и «чего не хватает».
    if(d.planned){
      var allowed=(meta.planned_fields||{})[n.type]||[];
      Array.prototype.forEach.call(clone.querySelectorAll('[data-field]'),function(f){ if(allowed.indexOf(f.getAttribute('data-field'))<0) f.parentNode.removeChild(f); });
    }
    var assessment=document.createElement('div'); assessment.className='pko-node-assessment';
    var flags=document.createElement('div'); flags.className='pko-node-flags';
    if(d.before_fork){var f1=document.createElement('span'); f1.textContent='до развилки · выполняется до выбора процесса'; flags.appendChild(f1);}
    if(n.parents.length>1){var f2=document.createElement('span'); f2.textContent='общий узел · родителей: '+n.parents.length; flags.appendChild(f2);}
    if(d.planned){var f3=document.createElement('span'); f3.className='planned'; f3.textContent='в коде нет · планируется'; flags.appendChild(f3);}
    if(flags.childNodes.length) assessment.appendChild(flags);
    var state=document.createElement('div'); state.className='state'; state.textContent=d.implementation_label||'Недостаточно данных'; assessment.appendChild(state);
    if(d.readiness!=null){var metric=document.createElement('div'); metric.textContent='Полнота узла: '+d.readiness+'%'; assessment.appendChild(metric);}
    if(Array.isArray(d.problems)&&d.problems.length){var ul=document.createElement('ul'); d.problems.forEach(function(p){var li=document.createElement('li'); li.textContent=p; ul.appendChild(li)}); assessment.appendChild(ul);}
    if(d.planned){var note=document.createElement('div'); note.className='pko-node-planned-note'; note.textContent='Поля режимов исполнения, fallback, handoff, контрактов и компенсации у планируемого узла не заполняются: они описывали бы поведение кода, которого нет.'; assessment.appendChild(note);}
    clone.insertBefore(assessment,clone.firstChild);
    if(Array.isArray(d.defects)&&d.defects.length){
      var defects=document.createElement('div'); defects.className='pko-node-defects';
      var dh=document.createElement('div'); dh.className='lbl'; dh.textContent='Известные дефекты и ограничения реализации'; defects.appendChild(dh);
      var dul=document.createElement('ul'); d.defects.forEach(function(t){var li=document.createElement('li'); li.textContent=t; dul.appendChild(li)}); defects.appendChild(dul);
      clone.appendChild(defects);
    }
    var links=document.createElement('div'); links.className='pko-links';
    function list(label,ids){ if(!ids.length) return; links.appendChild(document.createTextNode(label)); ids.forEach(function(c,i){if(i) links.appendChild(document.createTextNode(', ')); links.appendChild(link(c));}); }
    list(n.parents.length>1?'Родители ('+n.parents.length+', общий узел): ':'Родитель: ',n.parents);
    list(' · Дети: ',n.children);
    clone.appendChild(links);
    // Связи — отдельным блоком: вид словами, направление, основание.
    var rels=(relations||[]).filter(function(r){return r.from===n.id||r.to===n.id});
    if(rels.length){
      var box=document.createElement('div'); box.className='pko-node-relations';
      var h=document.createElement('div'); h.className='lbl'; h.textContent='Связи'; box.appendChild(h);
      var ul=document.createElement('ul');
      rels.forEach(function(r){
        var li=document.createElement('li');
        var kind=document.createElement('span'); kind.className='kind '+r.kind; kind.textContent=r.kind_label||r.kind; li.appendChild(kind);
        if(r.from===n.id){ li.appendChild(document.createTextNode('→ ')); li.appendChild(link(r.to)); }
        else { li.appendChild(link(r.from)); li.appendChild(document.createTextNode(' → этот узел')); }
        if(r.basis){ var b=document.createElement('div'); b.className='basis'; b.textContent=r.basis; li.appendChild(b); }
        ul.appendChild(li);
      });
      box.appendChild(ul); clone.appendChild(box);
    }
    if(Array.isArray(d.defects)&&d.defects.length){
      var dbox=document.createElement('div'); dbox.className='pko-node-defects';
      var dh=document.createElement('div'); dh.className='lbl'; dh.textContent='Дефекты'; dbox.appendChild(dh);
      var dul=document.createElement('ul');
      d.defects.forEach(function(id){var df=defectsById[id]; var li=document.createElement('li'); var a=document.createElement('a'); a.textContent=(df?df.title:id); a.addEventListener('click',function(){window.pkoOpenPage('defects',n.id)}); li.appendChild(a); if(df&&df.blocking){li.appendChild(document.createTextNode(' — блокирует'));} dul.appendChild(li);});
      dbox.appendChild(dul); clone.appendChild(dbox);
    }
    pageFilter=n.id; if(openPage) renderPages();
    drawerBody.innerHTML=''; drawerBody.appendChild(clone); drawerBody.scrollTop=0;
    drawer.classList.add('open');
    if(location.hash!=='#'+n.id) history.replaceState(null,'','#'+n.id);
  }
  map=window.pkoPassportMap(viewport,nodes,{paths:SCHEMA.paths||[],relations:SCHEMA.relations||[],onSelect:show,legendHost:legendHost});

  // --- 4. Три страницы: реестр узлов, таблица передач, реестр дефектов ---
  // Все три — из данных схемы (реестр — из таблицы шаблона, которую собрал
  // код). Клик по строке подсвечивает объект на карте; выбранный узел
  // фильтрует строки.
  var pages={}, openPage=null, pageFilter=null;
  var defectsById={}; (SCHEMA.defects||[]).forEach(function(d){defectsById[d.id]=d});
  function el(tag,cls,text){var e=document.createElement(tag); if(cls) e.className=cls; if(text!=null) e.textContent=text; return e;}
  function nodeLink(id){var a=el('a',null,(map.nodes[id]?map.nodes[id].name:id)); a.title=id; a.addEventListener('click',function(e){e.stopPropagation(); map.select(id);}); return a;}
  function nodeLinks(td,ids){(ids||[]).forEach(function(id,i){if(i) td.appendChild(document.createTextNode(', ')); td.appendChild(nodeLink(id));}); if(!(ids||[]).length) td.textContent='—';}
  function tag(cls,text){return el('span','tag '+cls,text);}
  function makePage(key,title,sub){
    var panel=el('div','pko-page-panel'); panel.dataset.page=key;
    var ph=el('div','pko-page-head'); ph.appendChild(el('h2',null,title)); ph.appendChild(el('div','sub',sub)); ph.appendChild(el('div','spacer'));
    var filt=el('button','pko-filter',''); filt.type='button'; filt.style.display='none'; filt.addEventListener('click',function(){pageFilter=null; renderPages();}); ph.appendChild(filt);
    var close=el('button','pko-drawer-close','×'); close.type='button'; close.title='К карте'; close.addEventListener('click',function(){showPage(null)}); ph.appendChild(close);
    var body=el('div','pko-page-body'); panel.appendChild(ph); panel.appendChild(body);
    viewport.appendChild(panel); pages[key]={panel:panel,body:body,filter:filt};
    var btn=el('button',null,title); btn.type='button'; btn.dataset.page=key; btn.addEventListener('click',function(){showPage(openPage===key?null:key)}); nav.appendChild(btn);
    pages[key].button=btn; return pages[key];
  }
  function showPage(key){
    openPage=key;
    Object.keys(pages).forEach(function(k){pages[k].panel.classList.toggle('open',k===key); pages[k].button.classList.toggle('on',k===key);});
    if(key) renderPages();
  }
  function rowHit(tr,ids,sids){
    var hit=pageFilter&&((ids||[]).indexOf(pageFilter)>=0||(sids||[]).indexOf(pageFilter)>=0);
    tr.classList.toggle('hit',!!hit);
    if(pageFilter&&!hit) tr.style.display='none';
  }
  function filterLabel(){var n=map.nodes[pageFilter]; return pageFilter?('фильтр: '+(n?n.name:pageFilter)+' — снять ×'):'';}
  var registry=document.querySelector('table.registry');
  var pRegistry=makePage('registry','Реестр узлов','строка — узел дерева; реестр построен обходом дерева, вручную не правится');
  var pHandoffs=makePage('handoffs','Таблица передач','строка — переход между соседними шагами сценария с проверками ревизии связности');
  var pDefects=makePage('defects','Реестр дефектов','строка — один дефект, даже если он объясняет несколько узлов и сценариев');
  pHandoffs.button.innerHTML='Таблица передач<b>'+(SCHEMA.handoffs||[]).length+'</b>';
  pDefects.button.innerHTML='Реестр дефектов<b>'+(SCHEMA.defects||[]).length+'</b>';
  function renderRegistry(){
    var body=pRegistry.body; body.innerHTML=''; pRegistry.filter.style.display=pageFilter?'':'none'; pRegistry.filter.textContent=filterLabel();
    var t=el('table','pko-table'); var thead=el('thead'); var hr=el('tr');
    ['id','тип','название','родитель','статус','ветвление','основание существования'].forEach(function(h){hr.appendChild(el('th',null,h))}); thead.appendChild(hr); t.appendChild(thead);
    var tb=el('tbody');
    Array.prototype.forEach.call(registry?registry.querySelectorAll('tbody tr'):[],function(src){
      var cell=function(c){var e=src.querySelector('[data-col="'+c+'"]'); return e?e.textContent.trim():'';};
      var id=cell('HTML-id'); if(!id) return; var n=map.nodes[id]||{}; var d=n.data||{};
      var tr=el('tr','link'); tr.addEventListener('click',function(){map.select(id)});
      tr.appendChild(el('td','mono',id)); tr.appendChild(el('td',null,cell('Тип')+(n.beforeFork?' · до развилки':'')+(n.planned?' · планируется':'')));
      tr.appendChild(el('td',null,cell('Название')));
      var tp=el('td'); nodeLinks(tp,(n.parents||[]).length?n.parents:[]); tr.appendChild(tp);
      var ts=el('td'); ts.appendChild(tag(d.implementation_status||'unknown',d.implementation_label||cell('Статус')||'—')); tr.appendChild(ts);
      tr.appendChild(el('td',null,d.branching_label||'—'));
      tr.appendChild(el('td',null,cell('Основание')));
      rowHit(tr,[id].concat(n.parents||[]),[]); tb.appendChild(tr);
    });
    t.appendChild(tb); body.appendChild(t);
  }
  function renderHandoffs(){
    var body=pHandoffs.body; body.innerHTML=''; pHandoffs.filter.style.display=pageFilter?'':'none'; pHandoffs.filter.textContent=filterLabel();
    var rows=SCHEMA.handoffs||[];
    var t=el('table','pko-table'); var thead=el('thead'); var hr=el('tr');
    ['сценарий','откуда','куда','узлы','поле состояния','вид','проверки','итог'].forEach(function(h){hr.appendChild(el('th',null,h))}); thead.appendChild(hr); t.appendChild(thead);
    var tb=el('tbody'); var checked=0;
    rows.forEach(function(r){
      if(r.checked) checked++;
      var tr=el('tr','link'); tr.addEventListener('click',function(){map.showPaths([r.scenario]); if(r.from_nodes[0]) map.select(r.from_nodes[0]);});
      var tsc=el('td'); tsc.appendChild(document.createTextNode(r.scenario_title)); if(r.critical) tsc.appendChild(el('div','note','критический')); tr.appendChild(tsc);
      tr.appendChild(el('td',null,(r.step)+'. '+r.from_step)); tr.appendChild(el('td',null,(r.step+1)+'. '+r.to_step));
      var tn=el('td'); nodeLinks(tn,r.from_nodes); tn.appendChild(document.createTextNode(' → ')); nodeLinks(tn,r.to_nodes); tr.appendChild(tn);
      tr.appendChild(el('td','mono',r.field||'не названо'));
      tr.appendChild(el('td',null,r.kind_label||'—'));
      var tc=el('td'); var box=el('div','checks');
      (r.checks||[]).forEach(function(c){var tg=tag(c.result,c.check_label+': '+c.result_label); tg.title=(c.note||'')+((c.links||[]).length?' · '+c.links.map(function(l){return l.path+(l.line?':'+l.line:'')}).join(', '):''); box.appendChild(tg);});
      tc.appendChild(box); tr.appendChild(tc);
      var ti=el('td'); ti.appendChild(tag(r.result,r.result_label)); tr.appendChild(ti);
      rowHit(tr,r.from_nodes.concat(r.to_nodes),[r.scenario]); tb.appendChild(tr);
    });
    t.appendChild(tb); body.appendChild(t);
    body.appendChild(el('div','pko-page-foot','Покрытие: проверено '+checked+' из '+rows.length+' передач — показатель прогресса ревизии, не оценка. Подключение в конфигурации не проверено на '+(summary.wiring_unchecked||0)+' передачах.'));
  }
  function renderDefects(){
    var body=pDefects.body; body.innerHTML=''; pDefects.filter.style.display=pageFilter?'':'none'; pDefects.filter.textContent=filterLabel();
    var rows=SCHEMA.defects||[];
    var t=el('table','pko-table'); var thead=el('thead'); var hr=el('tr');
    ['id','формулировка','тип','место в коде','затронутые узлы','сценарии','блокирует','источник'].forEach(function(h){hr.appendChild(el('th',null,h))}); thead.appendChild(hr); t.appendChild(thead);
    var tb=el('tbody');
    var titles={}; (SCHEMA.paths||[]).forEach(function(p){titles[p.id]=p.title});
    rows.forEach(function(d){
      var tr=el('tr','link'); tr.dataset.defect=d.id; tr.addEventListener('click',function(){ if(d.scenarios.length) map.showPaths(d.scenarios); if(d.nodes[0]) map.select(d.nodes[0]); });
      tr.appendChild(el('td','mono',d.id)); tr.appendChild(el('td',null,d.title));
      var tk=el('td'); tk.appendChild(tag(d.kind,d.kind_label)); tr.appendChild(tk);
      tr.appendChild(el('td','mono',d.where||'—'));
      var tn=el('td'); nodeLinks(tn,d.nodes); tr.appendChild(tn);
      tr.appendChild(el('td',null,(d.scenarios||[]).map(function(s){return titles[s]||s}).join('; ')||'—'));
      var tbk=el('td'); if(d.blocking) tbk.appendChild(tag('blocking','блокирует')); else tbk.textContent='нет'; tr.appendChild(tbk);
      tr.appendChild(el('td',null,d.source==='code'?'ревизия / код':'паспортный агент'));
      rowHit(tr,d.nodes,d.scenarios); tb.appendChild(tr);
    });
    if(!rows.length) tb.appendChild(el('tr')).appendChild(el('td',null,'дефектов не заведено'));
    t.appendChild(tb); body.appendChild(t);
  }
  function renderPages(){ if(openPage==='registry') renderRegistry(); if(openPage==='handoffs') renderHandoffs(); if(openPage==='defects') renderDefects(); }
  window.pkoOpenPage=function(key,filter){pageFilter=filter||null; showPage(key);};
  drawer.querySelector('.pko-drawer-close').addEventListener('click',closeDrawer);
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&drawer.classList.contains('open')) closeDrawer();});
  window.addEventListener('hashchange',function(){var id=location.hash.slice(1); if(map.nodes[id]) map.select(id);});
  var initial=location.hash&&map.nodes[location.hash.slice(1)]?location.hash.slice(1):null;
  if(initial) map.select(initial);
})();
</script>
"""


def _finalize_html(html: str, schema: dict[str, Any] | None = None) -> str:
    """Сделать HTML самодостаточным: убрать DCLogic, заменить Mustache, добавить JS.

    Шаблон v3 рассчитан на внешний движок DCLogic (`support.js`). В
    статичном файле паспорта этого движка нет — функция убирает зависимость
    и добавляет собственный минималистичный JS.
    """
    # 1. Убираем внешний скрипт support.js и DCLogic-блок.
    html = re.sub(r'<script\s+src="./support\.js">\s*</script>', '', html)
    html = re.sub(
        r'<script type="text/x-dc"[^>]*>.*?</script>',
        '', html, flags=re.DOTALL,
    )

    # 2. Заменяем Mustache-плейсхолдеры.
    def replace_mustache(m: re.Match) -> str:
        key = m.group(0).strip("{} ").strip()
        if key in _MUSTACE_CALLBACKS:
            return ""  # onClick="{{ tJourney }}" → onClick=""
        return _MUSTACHE_VALUES.get(key, "")

    html = _MUSTACHE_RE.sub(replace_mustache, html)

    # 3. Убираем data-anim (анимация не нужна в статике).
    html = re.sub(r'\s+data-anim\b', '', html)

    # 4. Убираем style-hover (нестандартный атрибут) — hover в CSS.
    html = re.sub(r'\s+style-hover="[^"]*"', '', html)

    # 6. Убираем упоминания параграфов стандарта из видимых элементов.
    #    «§ 4.2.1», «§ 4.2 · 8 полей», «(§ 3.2.1)», «§§ 3.2, 4.0–4.6» и т.д.
    #    В заголовках полей: «<span ...>§ 4.2.1</span>» → убираем span целиком.
    html = re.sub(
        r'<span[^>]*>§+\s*[\d.,–-]*</span>',
        '', html,
    )
    # Footer с упоминанием стандарта целиком.
    html = re.sub(
        r'Источник:\s*Стандарт автономного процесса[^<]*',
        '', html,
    )
    # В тексте заголовков узлов: «§ 4.2 · 8 полей» → «8 полей»
    html = re.sub(r'§+\s*[\d.]+\s*·\s*', '', html)
    # Одиночные «§ 4.5», «§§ 3.2», «§ 4.0» в видимом тексте.
    html = re.sub(r'§+\s*[\d.,–-]+', '', html)

    # 7. Добавляем CSS и JS перед </body>.
    script = _INLINE_JS.replace("__PKO_SCHEMA__", nodes_json(schema or {"nodes": [], "paths": [], "relations": []}), 1)
    inject = _INLINE_CSS + "\n" + script
    html = html.replace("</body>", inject + "\n</body>", 1)

    return html

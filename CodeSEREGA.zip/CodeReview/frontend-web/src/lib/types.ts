// Зеркало JSON-контракта backend/pko/web/analyses.py::_dashboard_json и
// событий SSE из backend/pko/web/app.py::stream_analysis_events.

// Один буллит этапа — дословный текст из ввода плюс оценка.
// `applicable` приходит только у пунктов, относящихся к анализируемой
// инициативе: у остальных полей нет вовсе, они серые и в расчёт не входят.
export interface AssessmentItem {
  text: string;
  applicable?: boolean;
  status?: "done" | "partial" | "planned" | "blocked";
  comment?: string;
}

export interface StageItem {
  title: string;
  description: string;
  applicable?: boolean;
  assessment: AssessmentItem[];
}

export interface AnalysisMeta {
  repo: string;
  branch: string;
  commit: string;
  generated_at: string;
  client_path_name?: string;
  project_name?: string;
  before?: string;
  now?: string;
  after?: string;
  decision?: "GO" | "PIVOT" | "NO GO";
}

export interface ProjectSummary {
  conclusion: string[];
}

export interface AnalysisResult {
  status: "READY";
  meta: AnalysisMeta;
  readiness: number;
  items: StageItem[];
  summary?: ProjectSummary;
}

export interface AnalysisPending {
  status: "PROCESSING";
}

export interface AnalysisFailed {
  status: "ERROR";
  message: string;
  hint: string;
}

export type Analysis = AnalysisResult | AnalysisPending | AnalysisFailed;

export interface CreateAnalysisResponse {
  analysis_id: string;
  status: "PROCESSING";
}

export interface ApiErrorBody {
  message: string;
  hint: string;
}

// События SSE (`GET /api/analyses/{id}/events`).
export type PhaseName = "materials_loading" | "materials_ready";

export type AnalysisEvent =
  | { type: "phase"; phase: PhaseName; label: string }
  | {
      type: "plan_ready";
      item_count: number;
      items: {
        title: string;
        origin: "user";
        criteria: number;
      }[];
    }
  | {
      type: "claim_verified";
      title: string;
      applicable: boolean;
      percent: number | null;
      criteria: number;
    }
  | { type: "summary_ready"; text: string; decision: string }
  | { type: "analysis_ready" }
  | { type: "error"; message: string; hint: string };

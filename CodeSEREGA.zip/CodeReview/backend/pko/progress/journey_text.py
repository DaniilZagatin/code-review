"""Разбор клиентского пути из текстового поля.

Образ результата вводится вручную текстом: название пути, этапы и буллиты
каждого этапа. Код разбирает их в `PlanItem` — модель ничего не придумывает,
только проверяет готовность пунктов по материалам.

Формат ввода — простой Markdown-подобный текст::

    Клиентский путь: Подготовка руководителя к встрече
    Проект: Пульс 2.0
    Было: данные собираются вручную
    Сейчас: дашборд собирает метрики, но без анализа
    Стало: автоматический дашборд за минуту с анализом

    ## Сбор данных
    - Автоматический сбор метрик из системы
    - Формирование дашборда

    ## Анализ
    - Сопоставление с планом

    ## Решения

Первая строка `Клиентский путь:` задаёт название пути (обязательно).
Контекстные поля `Проект:`/`Было:`/`Сейчас:`/`Стало:` — необязательны,
каждое в отдельной строке до первого этапа.

`##` — заголовок этапа. `-` — буллит этапа. Этап без буллитов (сразу
за ним следующий `##` или конец текста) — допустим: у этапа может не
быть пунктов.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from pko.errors import PkoError
from pko.progress.schema import PlanItem

_MAX_STAGES = 12
_MAX_STAGE_CHARS = 120

_CONTEXT_KEYS = {
    "клиентский путь": "client_path_name",
    "проект": "project_name",
    "инициатива": "project_name",
    "было": "before",
    "сейчас": "now",
    "стало": "after",
}

# Заголовок этапа без решётки: «Этап 3. Саммаризация», «Шаг 2) Проверка».
# Реальные вводы приходят и так, и через `##` — оба варианта равноправны.
_PLAIN_STAGE = re.compile(r"^(?:этап|шаг|stage|step)\s+\d+\s*[.):-]?\s*(.+)$", re.IGNORECASE)

# Невидимые символы, которые приносит копирование из презентаций и Word:
# BOM/zero-width. Без вычистки они попадают в текст буллита, ломают якорный
# поиск evidence и видны в отчёте как пустые квадраты.
_INVISIBLE = dict.fromkeys(map(ord, "﻿​‌‍⁠­"), None)


def _clean_line(raw_line: str) -> str:
    return raw_line.translate(_INVISIBLE).replace(" ", " ").strip()


@dataclass
class JourneyParse:
    """Результат разбора текстового поля: этапы + контекстные поля."""

    items: list[PlanItem] = field(default_factory=list)
    context: dict[str, str] = field(default_factory=dict)


def parse_journey_text(raw: str) -> JourneyParse:
    """Разобрать текстовое поле в этапы пути и контекст.

    Поднимает `PkoError` с понятной причиной, если путь пуст, этапов нет
    или название слишком длинное — до запуска агента, в ответе на отправку
    формы, а не в зависшей задаче.
    """
    if not raw or not raw.strip():
        raise PkoError(
            "Клиентский путь не задан.",
            hint="введите название пути, этапы и их пункты в текстовое поле",
        )

    lines = raw.splitlines()
    context: dict[str, str] = {}
    items: list[PlanItem] = []
    current_stage: PlanItem | None = None
    seen_ids: set[str] = set()
    stage_no = 0

    for raw_line in lines:
        line = _clean_line(raw_line)
        if not line:
            continue

        # Заголовок этапа без решётки приводим к общей форме, чтобы дальше
        # была одна ветка разбора, а не две расходящиеся.
        if not line.startswith("##"):
            plain_stage = _PLAIN_STAGE.match(line)
            if plain_stage and len(plain_stage.group(1).strip()) >= 3:
                line = "## " + line

        # Контекстное поле: «Ключ: значение» — только до первого этапа.
        if not items and line.startswith("##"):
            pass  # переход к этапам — контекст уже закончился
        m = re.match(r"^([^:]{2,40}):\s*(.+)$", line) if not line.startswith("##") else None
        if m and not items and not line.startswith("-"):
            key = m.group(1).strip().lower()
            value = m.group(2).strip()
            if key in _CONTEXT_KEYS:
                context[_CONTEXT_KEYS[key]] = value
                continue
            # «Клиентский путь: ...» мог быть первой строкой
            if not context and not items:
                context["client_path_name"] = line
                continue

        if line.startswith("##"):
            title = line.lstrip("#").strip()
            if not title:
                raise PkoError(
                    "Этап без названия.",
                    hint="после ## укажите название этапа",
                )
            if len(title) > _MAX_STAGE_CHARS:
                # Обрезаем, а не падаем: длинное название этапа — повод
                # ужать заголовок в отчёте, а не потерять весь анализ.
                title = title[:_MAX_STAGE_CHARS].rstrip() + "…"
            stage_no += 1
            if stage_no > _MAX_STAGES:
                raise PkoError(
                    f"Слишком много этапов: {stage_no}.",
                    hint=f"оставьте не больше {_MAX_STAGES}",
                )
            item_id = _slug(title) or f"stage-{stage_no}"
            if item_id in seen_ids:
                item_id = f"{item_id}-{stage_no}"
            seen_ids.add(item_id)
            current_stage = PlanItem(
                id=item_id, title=title, description="",
                criteria=[], origin="user",
            )
            items.append(current_stage)
            continue

        if line.startswith("-") or line.startswith("•"):
            bullet = line.lstrip("-•").strip()
            if not bullet:
                continue
            if current_stage is None:
                raise PkoError(
                    "Буллит без этапа.",
                    hint="сначала укажите этап через ##, затем его пункты через -",
                )
            # PlanItem frozen — пересоздаём с добавленным буллитом
            current_stage_criteria = list(current_stage.criteria) + [bullet]
            items[-1] = PlanItem(
                id=current_stage.id, title=current_stage.title,
                description=current_stage.description,
                criteria=current_stage_criteria, origin="user",
            )
            current_stage = items[-1]
            continue

        # Обычная строка без префикса: если этапов ещё нет — это может быть
        # название пути без «Клиентский путь:». Если уже есть этап — это
        # буллит без дефиса (допускаем для удобства ввода).
        if current_stage is not None:
            bullet = line
            current_stage_criteria = list(current_stage.criteria) + [bullet]
            items[-1] = PlanItem(
                id=current_stage.id, title=current_stage.title,
                description=current_stage.description,
                criteria=current_stage_criteria, origin="user",
            )
            current_stage = items[-1]
        elif not context:
            context["client_path_name"] = line

    if not items:
        raise PkoError(
            "В клиентском пути нет этапов.",
            hint="укажите хотя бы один этап через ## с его названием",
        )
    if "client_path_name" not in context:
        context["client_path_name"] = "Клиентский путь"

    return JourneyParse(items=items, context=context)


def render_plan_brief(items: list[PlanItem], context: dict[str, str]) -> str:
    """План в читаемый текст для промпта агента.

    Агент получает уже разобранный путь: ему не нужно копировать тексты,
    только проверить готовность каждого пункта по материалам.
    """
    lines: list[str] = []

    path_name = context.get("client_path_name", "Клиентский путь")
    lines.append(f"Клиентский путь: {path_name}")
    if context.get("project_name"):
        lines.append(f"Проект: {context['project_name']}")
    if context.get("before"):
        lines.append(f"Было: {context['before']}")
    if context.get("now"):
        lines.append(f"Сейчас: {context['now']}")
    if context.get("after"):
        lines.append(f"Стало: {context['after']}")
    lines.append("")

    for index, item in enumerate(items, start=1):
        lines.append(f"## Этап {index}: {item.title}")
        if item.description:
            lines.append(item.description)
        if item.criteria:
            for bullet in item.criteria:
                lines.append(f"- {bullet}")
        else:
            lines.append("(пунктов нет)")
        lines.append("")

    return "\n".join(lines)


_CYRILLIC_LATIN = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch",
    "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
}


def _slug(text: str) -> str:
    """Название этапа → короткий идентификатор латиницей/цифрами/дефисами."""
    lowered = text.lower()
    translit = "".join(_CYRILLIC_LATIN.get(c, c) for c in lowered)
    slug = re.sub(r"[^A-Za-z0-9]+", "-", translit).strip("-").lower()
    return slug[:40] if slug else ""

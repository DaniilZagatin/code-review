"""Общий пайплайн прогресса: текстовый клиентский путь + целевой репозиторий
→ ProgressModel.

Вызывается веб-эндпоинтом (`web.app`). Функция ничего не печатает и не пишет
на диск — это дело вызывающей стороны (веб отдаёт HTML прямо в ответе).
"""

from __future__ import annotations

import time
from typing import Any, Callable

from pko.errors import PkoError
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import trace_span
from pko.progress.matcher import DEFAULT_MAX_STEPS, find_unclaimed_paths, run_agent
from pko.progress.journey_text import JourneyParse, parse_journey_text, render_plan_brief
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import ItemVerdict, PlanItem, ProgressModel, ProjectSummary
from pko.progress.target_repo import TargetRepo

# Событие — (kind, data). Один и тот же колбэк используется и для грубых фаз
# пайплайна, и для каждого принятого вердикта агента.
ProgressEvent = Callable[[str, dict[str, Any]], None]


def run_progress(
    journey_text: str,
    repo_name: str,
    target: TargetRepo,
    spec: ModelSpec,
    client: ChatClient | None = None,
    max_steps: int = DEFAULT_MAX_STEPS,
    on_event: ProgressEvent | None = None,
    description: str | None = None,
) -> ProgressModel:
    """Собрать ProgressModel: клиентский путь (текст) + репозиторий → агент → вывод.

    `journey_text` — текстовое поле с клиентским путём: название, этапы и
    буллиты каждого этапа. Код разбирает его в `PlanItem` (`journey_text`),
    модель ничего не придумывает — только проверяет готовность пунктов.

    `description` — описание инициативы: из него агент формулирует «Было» и
    «Стало» первым шагом сессии (`submit_brief`), если они не заданы в тексте
    пути. Применяется в веб-форме; CLI передаёт `None`.

    `on_event` — точка расширения для живого прогресса веб-эндпоинта.
    """
    started_at = time.strftime("%Y%m%d_%H:%M")
    span_name = f"pko.progress · {started_at}"
    with trace_span(
        span_name,
        repo=repo_name,
        branch=target.branch,
        commit=target.sha,
        model=spec.model,
        role=spec.role,
        max_steps=max_steps,
    ):
        return _run_progress(
            journey_text, repo_name, target, spec, client=client,
            max_steps=max_steps, on_event=on_event, description=description,
        )


def _run_progress(
    journey_text: str,
    repo_name: str,
    target: TargetRepo,
    spec: ModelSpec,
    client: ChatClient | None = None,
    max_steps: int = DEFAULT_MAX_STEPS,
    on_event: ProgressEvent | None = None,
    description: str | None = None,
) -> ProgressModel:
    """Тело пайплайна; вызывается внутри корневого `trace_span`."""
    with trace_span("parse_journey", text_chars=len(journey_text)) as span:
        plan_input = parse_plan_text(journey_text)
        parsed = plan_input.parse
        span.set_attribute("source_format", plan_input.source_format)
        span.set_attribute("stage_count", len(parsed.items))
        span.set_attribute("bullet_count", sum(len(p.criteria) for p in parsed.items))

    if on_event is not None:
        on_event("plan_ready", {
            "item_count": len(parsed.items),
            "items": [{"title": p.title, "origin": p.origin,
                       "criteria": len(p.criteria)}
                      for p in parsed.items],
        })

    on_verdict = None
    on_summary = None
    if on_event is not None:
        def on_verdict(item: PlanItem, verdict: ItemVerdict) -> None:
            on_event("claim_verified", {
                "title": item.title,
                "applicable": verdict.applicable,
                "percent": verdict.percent(),
                "criteria": len(verdict.criteria),
            })

        def on_summary(summary: ProjectSummary) -> None:
            on_event("summary_ready", {"text": " · ".join(summary.conclusion),
                                       "decision": summary.decision})

    result = run_agent(
        parsed.items, parsed.context, target.tree, spec, client=client,
        max_steps=max_steps, on_verdict=on_verdict, on_summary=on_summary,
        extraction=target.extraction, description=description,
    )
    if not result.usable:
        raise PkoError(
            "Не удалось получить вердикты по этапам.",
            hint="проверьте доступность LLM; причина: "
                 + ("; ".join(result.notes) or "неизвестна"),
        )

    with trace_span("find_unclaimed") as span:
        unclaimed = find_unclaimed_paths(target.extraction, result.verdicts)
        span.set_attribute("unclaimed_groups", len(unclaimed))

    # Готовность — детерминированный расчёт по статусам буллитов.
    generated_at = time.strftime("%Y-%m-%d %H:%M")
    with trace_span("build_model") as span:
        model = ProgressModel(
            meta={
                "repo": repo_name, "branch": target.branch, "commit": target.sha,
                "generated_at": generated_at,
                "source_format": plan_input.source_format,
                "source_digest": plan_input.source_digest,
                "stages": list(plan_input.stages),
                "effect_quotes": list(plan_input.effect_quotes),
                **result.context,
            },
            items={item.id: item for item in result.items},
            verdicts=result.verdicts,
            unclaimed=unclaimed,
            gaps=list(plan_input.notes) + list(result.notes),
            readiness=0,
            summary=result.summary,
            summary_source=result.summary_source,
        )
        model.readiness = model.overall_progress()
        span.set_attribute("items", len(model.items))
        span.set_attribute("verdicts", len(model.verdicts))
        span.set_attribute("readiness", model.readiness)
        span.set_attribute("summary_source", result.summary_source)
    return model

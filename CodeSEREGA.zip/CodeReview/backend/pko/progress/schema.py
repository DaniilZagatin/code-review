"""Модель одного прогона: клиентский путь из образа результата и оценка его
этапов по материалам проекта.

Ключевой принцип новой версии — **тексты пути не пишет модель**. Названия
этапов, их описания и буллиты копируются из образа результата дословно и
живут в `PlanItem`; вердикт (`ItemVerdict`) добавляет к ним только две вещи:
относится ли пункт к рассматриваемой инициативе и в каком он состоянии. Текст
и оценка разведены по разным объектам, поэтому переформулировать буллет
физически нечем: в вердикте для текста просто нет поля.

Это заменило прежнюю конструкцию, где модель сама сочиняла и этапы, и
формулировки возможностей. Она давала либо технический язык, либо — после
починки языка — гладкий, но не тот текст: отчёт переставал совпадать с
образом результата, который команда согласовала и по которому себя мерит.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# Шкала согласия: согласны ли мы, что буллит образа результата уже сделан.
# Оцениваемые системы — агенты, и агент решает задачу, обращаясь к своему
# инструменту. Поэтому граница шкалы проходит между «функционал написан» и
# «агент им пользуется»: `done` требует тула, `partial` — нет.
# `blocked` — не «хуже, чем planned», а другое: отсутствие результата
# блокирует следующий шаг.
CRITERION_STATUSES = ("done", "partial", "scaffold", "planned", "blocked")
CRITERION_WEIGHT = {
    "done": 1.0,       # Да — есть тул, агент через него решает задачу
    "partial": 0.7,    # Почти — код есть и работает, но к агенту не подключён
    "scaffold": 0.3,   # Почти нет — только заготовка, сквозной путь не работает
    "planned": 0.0,    # Нет — в коде не найдено
    "blocked": 0.0,
}
STATUS_LABEL = {
    "done": "Да",
    "partial": "Почти",
    "scaffold": "Почти нет",
    "planned": "Нет",
    "blocked": "Блокирует",
}

# Роли доказательств: ссылка говорит, что именно она подтверждает.
EVIDENCE_KINDS = ("definition", "wiring", "tool", "test")
EVIDENCE_KIND_LABEL = {
    "definition": "Объявление",
    "wiring": "Подключение",
    "tool": "Инструмент агента",
    "test": "Тест",
}

# Минимум доказательств на статус (METHODOLOGY.md §4).
REQUIRED_EVIDENCE = {
    "done": ("definition", "tool"),
    "partial": ("definition", "wiring"),
    "scaffold": ("definition",),
    "blocked": ("definition",),
    "planned": (),
}

DECISIONS = ("GO", "PIVOT", "NO GO")

# Порог решения. Одно правило и ничего больше: так его может пересказать любой
# читатель отчёта, не заглядывая в документацию.
READY_THRESHOLD = 50


def scale_rows() -> list[dict[str, Any]]:
    """Шкала согласия для отчёта: ответ, вес и что он означает.

    Единственный источник и для расчёта, и для легенды: разойтись они не могут.
    """
    meaning = {
        "done": "функционал есть и выведен агенту инструментом",
        "partial": "код есть и работает, но к агенту не подключён",
        "scaffold": "только заготовка, сквозной путь не работает",
        "planned": "в коде не найдено",
        "blocked": "отсутствие блокирует следующий шаг",
    }
    rows = [
        {
            "status": status,
            "label": STATUS_LABEL[status],
            "weight": int(CRITERION_WEIGHT[status] * 100),
            "meaning": meaning[status],
        }
        for status in ("done", "partial", "scaffold", "planned")
    ]
    rows.append({
        "status": "na",
        "label": "Не применимо",
        "weight": None,
        "meaning": "буллит не про код — исключён из расчёта",
    })
    return rows


def compute_decision(readiness: int) -> str:
    """Решение по одному порогу: ≥50% — GO, иначе PIVOT.

    Считает код, а не модель и не шаблон.
    """
    return "GO" if readiness >= READY_THRESHOLD else "PIVOT"


def decision_reason(readiness: int) -> str:
    """Строка расчёта под решением — чтобы бейдж не выглядел волшебным."""
    sign = "≥" if readiness >= READY_THRESHOLD else "<"
    return f"{readiness}% {sign} {READY_THRESHOLD}%"

# Потолок статуса по ролям доказательств: «Да» невозможно подтвердить, если
# не показано, что функционал выведен агенту инструментом.
_CAP_ORDER = ("done", "partial", "scaffold")


def cap_status(status: str, verified_kinds: set[str]) -> tuple[str, str]:
    """Понизить статус до подтверждённого потолка.

    Возвращает (статус, причина понижения). Причина пустая, если понижения
    не было. Применяется только когда агент вообще размечает роли ссылок:
    без разметки различить объявление и подключение нечем, и молча понижать
    было бы враньём в другую сторону.
    """
    if status not in _CAP_ORDER or not verified_kinds:
        return status, ""
    for candidate in _CAP_ORDER[_CAP_ORDER.index(status):]:
        needed = REQUIRED_EVIDENCE.get(candidate, ())
        if all(kind in verified_kinds for kind in needed):
            if candidate == status:
                return status, ""
            missing = [
                EVIDENCE_KIND_LABEL.get(k, k)
                for k in REQUIRED_EVIDENCE.get(status, ())
                if k not in verified_kinds
            ]
            return candidate, (
                f"понижено с «{STATUS_LABEL.get(status, status)}» до "
                f"«{STATUS_LABEL.get(candidate, candidate)}»: не показано — "
                + ", ".join(missing).lower()
            )
    return "scaffold", (
        f"понижено с «{STATUS_LABEL.get(status, status)}» до «Почти нет»: "
        "подтверждено только объявление"
    )


def calculate_progress(criteria: list["CriterionVerdict"]) -> int | None:
    """Детерминированный расчёт прогресса по списку буллитов.

    Формула: (Да×100 + Почти×70 + Почти нет×30) / применимые буллиты.

    Неприменимые буллиты (`applicable=False`) исключаются из знаменателя:
    декларация эффекта или список потребителей — не про код, и тянуть из-за
    них готовность вниз значит наказывать инициативу за формат слайда.
    Возвращает None, если применимых буллитов нет.
    """
    if not criteria:
        return None
    usable = [c for c in criteria if c.applicable]
    if not usable:
        return None
    return round(sum(c.weight for c in usable) / len(usable) * 100)


def calculate_closed_share(criteria: list["CriterionVerdict"]) -> int | None:
    """Доля буллитов со статусом «Да» — второе, более простое число.

    Расхождение с готовностью показывает, много ли написанного, но не
    подключённого к агенту.
    """
    usable = [c for c in criteria if c.applicable]
    if not usable:
        return None
    return round(sum(1 for c in usable if c.status == "done") / len(usable) * 100)


@dataclass(frozen=True)
class PlanItem:
    """Один этап клиентского пути — дословно из текстового ввода.

    `criteria` — буллиты этапа в исходном порядке и исходной редакции. Они
    попадают сюда на фазе разбора текста и дальше не меняются: вердикт
    ссылается на них по позиции, а не пересылает текст заново.
    """

    id: str
    title: str
    description: str = ""
    criteria: list[str] = field(default_factory=list)
    origin: str = "user"

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "criteria": list(self.criteria),
            "origin": self.origin,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "PlanItem":
        return PlanItem(
            id=d["id"],
            title=d["title"],
            description=d.get("description", ""),
            criteria=list(d.get("criteria") or []),
            origin=d.get("origin", "user"),
        )


@dataclass(frozen=True)
class EvidenceRef:
    """Одна ссылка на материалы, подтверждающая состояние буллита.

    `verified=False` не отбрасывается — понижается и остаётся в модели с
    причиной: утверждение без доказательства не публикуется как «материалы
    показывают».
    """

    path: str
    line: int | None
    basis: str
    verified: bool
    reason: str
    # Что именно доказывает ссылка: объявление, подключение, тул агента, тест.
    # Пустая строка — роль не указана; это не то же самое, что «объявление».
    kind: str = ""
    # Что происходит в этой строке — одна фраза человеческим языком.
    # Без неё ссылка остаётся координатой: читатель видит «router.py:42»
    # и всё равно не знает, что там.
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path, "line": self.line, "basis": self.basis,
            "verified": self.verified, "reason": self.reason,
            "kind": self.kind,
            "kind_label": EVIDENCE_KIND_LABEL.get(self.kind, "Ссылка"),
            "note": self.note,
        }


@dataclass
class CriterionVerdict:
    """Оценка одного буллита этапа: относится ли он к инициативе и что с ним.

    Текста здесь нет намеренно — он берётся из `PlanItem.criteria` по той же
    позиции. Модель не может ни переписать буллет, ни выбросить его, ни
    добавить новый: длина списка сверяется с планом.

    `applicable=False` — буллит не про эту инициативу. Тогда `status`
    игнорируется, пункт показывается серым и не участвует в расчёте
    готовности этапа. Это не «плохо» и не «не сделано»: чужой пункт не должен
    ни портить, ни улучшать картину.
    """

    applicable: bool = False
    status: str = ""
    comment: str = ""
    evidence: list[EvidenceRef] = field(default_factory=list)
    # Тематическая группа для вёрстки отчёта («Обработка запросов»).
    # Только оформление: на расчёт готовности не влияет никак.
    group: str = ""

    def __post_init__(self) -> None:
        if self.status and self.status not in CRITERION_STATUSES:
            raise ValueError(f"неизвестный статус буллита: {self.status}")

    @property
    def weight(self) -> float:
        return CRITERION_WEIGHT.get(self.status, 0.0)

    @property
    def verified_evidence(self) -> list[EvidenceRef]:
        return [e for e in self.evidence if e.verified]

    @property
    def verified_kinds(self) -> set[str]:
        return {e.kind for e in self.evidence if e.verified and e.kind}

    @property
    def missing_evidence(self) -> tuple[str, ...]:
        """Каких ролей доказательств не хватает под заявленный статус."""
        if not self.applicable or not self.status:
            return ()
        needed = REQUIRED_EVIDENCE.get(self.status, ())
        have = self.verified_kinds
        return tuple(kind for kind in needed if kind not in have)

    @property
    def is_grounded(self) -> bool:
        """Есть ли подтверждение у заявленного прогресса.

        «Нет» подтверждать нечем — отсутствие ссылкой не доказывается.
        Недостающая роль доказательства оценку не отклоняет: она понижает
        статус до подтверждённого потолка (`cap_status`). Отклонять было бы
        хуже — агент уходил бы в цикл переписывания вместо честного «почти».
        """
        if not self.applicable or self.status == "planned":
            return True
        return bool(self.verified_evidence)

    def to_dict(self) -> dict[str, Any]:
        return {
            "applicable": self.applicable,
            "status": self.status,
            "status_label": STATUS_LABEL.get(self.status, self.status),
            "comment": self.comment,
            "group": self.group,
            "evidence": [e.to_dict() for e in self.evidence],
            "missing_evidence": list(self.missing_evidence),
        }


@dataclass
class ItemVerdict:
    """Оценка одного этапа: применимость этапа и состояние его буллитов."""

    item_id: str
    applicable: bool = False
    criteria: list[CriterionVerdict] = field(default_factory=list)

    @property
    def applicable_criteria(self) -> list[CriterionVerdict]:
        return [c for c in self.criteria if c.applicable]

    def percent(self) -> int | None:
        """Готовность этапа: `calculate_progress` по всем буллитам этапа.

        `None` — этап не относится к инициативе или в нём нет буллитов:
        серый, в расчёт не входит.
        """
        if not self.applicable:
            return None
        return calculate_progress(self.criteria)

    @property
    def evidence(self) -> list[EvidenceRef]:
        return [e for c in self.criteria for e in c.evidence]

    @property
    def ungrounded_count(self) -> int:
        return sum(1 for c in self.criteria if not c.is_grounded)

    def to_dict(self) -> dict[str, Any]:
        return {
            "item_id": self.item_id,
            "applicable": self.applicable,
            "percent": self.percent(),
            "criteria": [c.to_dict() for c in self.criteria],
        }


@dataclass(frozen=True)
class UnclaimedGroup:
    """Группа файлов, не подтвердивших ни одного буллита плана.

    Не вердикт «сделано сверх плана» — только сырой кандидат для него.
    Детерминированная разница множеств, без суждения модели.
    """

    group: str
    example_paths: list[str]
    file_count: int

    def to_dict(self) -> dict[str, Any]:
        return {"group": self.group, "example_paths": self.example_paths,
                "file_count": self.file_count}


@dataclass(frozen=True)
class ProjectSummary:
    """Итог анализа: вердикт и его обоснование.

    `conclusion` — 3 коротких буллита (до 4 слов каждый): что подтверждено,
    что мешает, можно ли идти дальше.
    """

    decision: str = ""
    conclusion: list[str] = field(default_factory=list)
    # Строка расчёта под решением: «68% ≥ 50%».
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision,
            "conclusion": list(self.conclusion),
            "reason": self.reason,
        }


@dataclass
class ProgressModel:
    """Итоговая модель одного прогона.

    `readiness` — детерминированный расчёт: сумма весов всех применимых
    буллитов, делённая на их число. Done = 1, partial = 0.5,
    planned/blocked = 0. Не оценка модели, а арифметика по статусам.
    """

    meta: dict[str, Any] = field(default_factory=dict)
    items: dict[str, PlanItem] = field(default_factory=dict)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    unclaimed: list[UnclaimedGroup] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    readiness: int = 0
    summary: ProjectSummary | None = None
    summary_source: str = "none"

    def criterion_counts(self) -> dict[str, int]:
        """Сколько применимых буллитов в каждом состоянии — по всему пути."""
        out = {status: 0 for status in CRITERION_STATUSES}
        for verdict in self.verdicts:
            for criterion in verdict.applicable_criteria:
                if criterion.status in out:
                    out[criterion.status] += 1
        return out

    def all_criteria(self) -> list[CriterionVerdict]:
        return [c for v in self.verdicts for c in v.criteria]

    def overall_progress(self) -> int:
        """Готовность: (Да×100 + Почти×70 + Почти нет×30) / применимые буллиты."""
        return calculate_progress(self.all_criteria()) or 0

    def closed_share(self) -> int:
        """Доля буллитов «Да» — сколько пунктов закрыто полностью."""
        return calculate_closed_share(self.all_criteria()) or 0

    def not_applicable_count(self) -> int:
        return sum(1 for c in self.all_criteria() if not c.applicable)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "pko-progress-model/0.3",
            "meta": self.meta,
            "readiness": self.readiness,
            "closed_share": self.closed_share(),
            "criterion_counts": self.criterion_counts(),
            "not_applicable": self.not_applicable_count(),
            "items": {item_id: item.to_dict() for item_id, item in self.items.items()},
            "verdicts": [v.to_dict() for v in self.verdicts],
            "unclaimed": [u.to_dict() for u in self.unclaimed],
            "gaps": self.gaps,
            "summary": self.summary.to_dict() if self.summary else None,
            "summary_source": self.summary_source,
        }

    def to_json(self) -> str:
        import json

        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2, sort_keys=False)

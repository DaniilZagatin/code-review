"""Единый агент: получает готовый клиентский путь из текстового ввода,
оценивает его этапы по материалам проекта и выносит вердикт — одна сессия.

Работа идёт в три фазы:
  1. ОЦЕНКА — по каждому этапу агент собирает факты инструментами и вызывает
     `submit_stage`: относится ли этап к инициативе и что с каждым его
     буллитом (`done`/`partial`/`planned`/`blocked` либо «не относится»).
  2. КОНТР-ПРОВЕРКА НА ЗАНИЖЕНИЕ — после всех `submit_stage` агент получает
     сводку со своими оценками, списком непроцитированных фактов (точки
     входа, инструменты, SQL, LLM-вызовы — готовые подсказки, где могла
     быть пропущена реализация) и непроцитированных файлов (слепые зоны).
     Проверяет каждый `planned` (не пропущен ли существующий код) и каждый
     `partial` (не является ли он на самом деле `done` — путь end-to-end
     работает без ограничений). Если нашёл — исправляет через повторный
     `submit_stage`, подтверждает через `submit_review`. `submit_summary`
     не принимается без `submit_review`, если есть хотя бы один
     `done`/`partial`.
  3. ВЕРДИКТ — `submit_summary`: решение GO/PIVOT/NO GO и его обоснование.
     Затем `finish`.

Тексты пути (названия этапов, буллиты) приходят из текстового поля, разбираются
кодом в `PlanItem` и передаются агенту уже готовыми. Модель ничего не
придумывает по ним — только проверяет готовность пунктов. `submit_plan`
больше нет: план не нужно «принимать» от модели, он уже есть.

Готовность проекта считается кодом (сумма весов / число буллитов), а не
оценивается моделью. `submit_summary` не включает readiness — только решение
и его обоснование.

Ни одна evidence-ссылка не публикуется без проверки: `progress.verify.verify_evidence`
подтверждает её структурно. Неподтверждённая ссылка остаётся в модели с
`verified=False` и причиной.

Смысловые гейты кода (`_accept_stage`/`_accept_summary`): статус, утверждающий
результат, не принимается без проверенной ссылки; `GO` не публикуется при
«blocked» или отсутствии подтверждённого движения (нет ни одного done/partial);
свободные тексты (комментарии, вывод) проверяются сторожем `report.guard` на
упоминание данных, которых нет в материалах.
Нарушение отклоняет вызов с объяснением; после `_MAX_GATE_REJECTIONS`
отклонений оценка принимается, но нарушившее поле заменяется пометкой.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from pko.errors import LlmError, PkoError
from pko.extractors.base import Tree
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import trace_span
from pko.progress.agent_tools import TOOL_SCHEMAS as REPO_TOOL_SCHEMAS, ToolBox
from pko.progress.journey_text import render_plan_brief
from pko.progress.schema import (
    CRITERION_STATUSES,
    DECISIONS,
    EVIDENCE_KINDS,
    STATUS_LABEL,
    calculate_progress,
    cap_status,
    compute_decision,
    decision_reason,
    CriterionVerdict,
    EvidenceRef,
    ItemVerdict,
    PlanItem,
    ProjectSummary,
    UnclaimedGroup,
)
from pko.progress.verify import verify_evidence
from pko.report.guard import check_explanation, check_summary_text

# Системный промпт — один редактируемый Markdown-файл рядом с этим модулем.
_PROMPT_PARTS = ("agent_system.md",)
_PROMPT_DIR = Path(__file__).parent


def load_system_prompt() -> tuple[str, list[str]]:
    """Системный промпт и список ненайденных частей."""
    parts: list[str] = []
    missing: list[str] = []
    for name in _PROMPT_PARTS:
        try:
            parts.append((_PROMPT_DIR / name).read_text(encoding="utf-8"))
        except OSError:
            missing.append(name)
    if not parts:
        parts.append("Ты — агент, который проверяет готовность пунктов "
                     "клиентского пути по материалам проекта.")
    return "\n\n---\n\n".join(parts), missing


# Бюджет шагов агента на всю сессию (обход всех этапов + контр-проверка + вердикт).
DEFAULT_MAX_STEPS = 80

MAX_TOKENS_DEFAULT = 8192
MAX_TOKENS_THINKING = 16384

_SUBMIT_STAGE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_stage",
        "description": "Оценка одного этапа — ОДИН вызов на этап, после того как ты собрал "
                       "факты инструментами. Тексты пунктов уже известны из плана, здесь "
                       "только применимость и статусы по позициям. Список criteria обязан "
                       "совпадать по длине и порядку с буллитами этого этапа в плане. "
                       "applicable=true ставь только тем этапам и буллитам, которые "
                       "относятся к анализируемой инициативе; остальные оставь "
                       "неприменимыми — они станут серыми и в расчёт не войдут. Повторный "
                       "вызов с тем же item_id заменяет предыдущую оценку.",
        "parameters": {
            "type": "object",
            "properties": {
                "item_id": {"type": "string", "description": "идентификатор этапа из плана"},
                "applicable": {"type": "boolean", "description": "относится ли этап к анализируемой инициативе"},
                "criteria": {
                    "type": "array",
                    "description": "оценки буллитов этапа строго по позициям плана: столько же элементов и в том же порядке",
                    "items": {
                        "type": "object",
                        "properties": {
                            "applicable": {"type": "boolean", "description": "относится ли буллит к анализируемой инициативе; если нет — статус не нужен, пункт станет серым"},
                            "status": {
                                "type": "string", "enum": list(CRITERION_STATUSES),
                                "description": (
                                    "Согласен ли ты, что это уже сделано. "
                                    "done — Да: функционал есть И выведен агенту инструментом, агент через него решает задачу. "
                                    "partial — Почти: код есть и работает, но к агенту не подключён (тула нет). "
                                    "scaffold — Почти нет: есть только заготовка, сквозной путь не работает. "
                                    "planned — Нет: в коде не найдено. "
                                    "blocked — отсутствие результата блокирует следующий этап. "
                                    "Целевые метрики (сроки, доли, проценты) на статус НЕ влияют — они идут в комментарий."
                                ),
                            },
                            "evidence": {
                                "type": "array",
                                "description": "чем подтверждён статус: реальные путь и строка из прочитанного кода. Каждая ссылка обязана сказать, ЧТО она доказывает (поле kind). done требует kind=definition и kind=tool; partial — definition и wiring; scaffold — definition. Если нужной роли нет, код понизит статус до подтверждённого. Для planned оставь пустым.",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "path": {"type": "string"},
                                        "line": {"type": "integer"},
                                        "basis": {"type": "string", "description": "конкретное имя (функции/класса/таблицы/процедуры) рядом со строкой — по нему ссылка проверяется"},
                                        "note": {"type": "string", "description": "что происходит в этой строке, одной фразой: «принимает модель и запрос от пользователя», «регистрирует расчёт как инструмент агента». Без неё ссылка остаётся координатой."},
                                        "kind": {
                                            "type": "string",
                                            "enum": list(EVIDENCE_KINDS),
                                            "description": "definition — где объявлено; wiring — где вызывается, сквозной путь работает; tool — где зарегистрировано как инструмент агента; test — где покрыто проходящим тестом",
                                        },
                                    },
                                },
                            },
                            "comment": {"type": "string", "description": "вывод в одну-две фразы: чего не хватает до следующей ступени. Если в буллите есть целевая метрика — отдельной фразой, подтверждается ли она по коду. До 400 символов."},
                            "group": {"type": "string", "description": "тематическая группа для вёрстки отчёта, 1–3 слова («Обработка запросов», «Сценарный анализ», «Документы»). Буллиты одной темы — одна группа. На расчёт не влияет."},
                        },
                        "required": ["applicable"],
                    },
                },
                "notes": {"type": "string", "description": "краткие наблюдения для себя — служебное поле, в отчёт не идёт"},
            },
            "required": ["item_id", "applicable", "criteria"],
        },
    },
}

_SUBMIT_SUMMARY_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_summary",
        "description": "Вердикт по проекту — вызывай ОДИН раз после всех submit_stage и ДО "
                       "finish. Решение и его обоснование. "
                       "Готовность проекта считается кодом автоматически — здесь её указывать не нужно.",
        "parameters": {
            "type": "object",
            "properties": {
                "decision": {
                    "type": "string", "enum": list(DECISIONS),
                    "description": "GO — стоящая инициатива, которую стоит развивать (ценность реальна или правдоподобна, есть хоть какое-то подтверждённое движение — хотя бы один done/partial, нет blocked); PIVOT — требует доработки или вмешательства: нет подтверждённого движения (всё planned/blocked), есть blocked или инициатива ненужная; NO GO — бесполезная инициатива или очень плохая по выполнению. При blocked или отсутствии подтверждённого движения решение GO кодом не публикуется",
                },
                "conclusion": {
                    "type": "array",
                    "minItems": 3,
                    "maxItems": 3,
                    "items": {"type": "string"},
                    "description": "Ровно 3 буллита, каждый максимум 4 слова: что подтверждено, что мешает, можно ли идти дальше. Не предложения, а короткие тезисы.",
                },
            },
            "required": ["decision", "conclusion"],
        },
    },
}

_FINISH_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "finish",
        "description": "Вызови, когда оценил все этапы пути и отправил вердикт "
                       "(submit_summary) — сессия завершена.",
        "parameters": {"type": "object", "properties": {}},
    },
}

_SUBMIT_BRIEF_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_brief",
        "description": "Сформулируй из описания инициативы три коротких тезиса — «AS IS» "
                       "(исходное состояние), «Now» (текущее состояние после частичной "
                       "реализации) и «To Be» (целевое состояние). По одному понятному "
                       "предложению каждое. Вызови ОДИН раз в самом начале сессии, до "
                       "submit_stage. Если описания нет — не вызывай. Формулировки "
                       "попадают в шапку дашборда: конкретно, без воды, одно предложение.",
        "parameters": {
            "type": "object",
            "properties": {
                "before": {
                    "type": "string",
                    "description": "AS IS — исходное состояние до инициативы, одно предложение до 200 символов.",
                },
                "now": {
                    "type": "string",
                    "description": "Now — текущее состояние после частичной реализации, одно предложение до 200 символов.",
                },
                "after": {
                    "type": "string",
                    "description": "To Be — целевое состояние после инициативы, одно предложение до 200 символов.",
                },
            },
            "required": ["before", "now", "after"],
        },
    },
}

_SUBMIT_REVIEW_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_review",
        "description": "Контр-проверка на занижение статусов — вызови ОДИН раз после всех "
                       "submit_stage и ДО submit_summary. Проверь каждый planned (не "
                       "пропущена ли реализация) и каждый partial (не является ли он на "
                       "самом деле done). Тебе передана сводка с непроцитированными фактами "
                       "и файлами — отсмотри их. Если нашёл код, который пропустил, или "
                       "убедился, что partial — это done — исправь статус через повторный "
                       "submit_stage, потом вызови submit_review с confirmed=true. Если всё "
                       "подтверждается — сразу confirmed=true. Без submit_review вердикт "
                       "(submit_summary) не принимается, если есть хотя бы один done/partial.",
        "parameters": {
            "type": "object",
            "properties": {
                "confirmed": {
                    "type": "boolean",
                    "description": "true — все planned/partial перепроверены на занижение (или исправлены через повторный submit_stage); false — найдена пропущенная реализация или заниженный статус, нужно исправить перед подтверждением",
                },
                "notes": {
                    "type": "string",
                    "description": "что проверял и что нашёл, до 500 символов. Служебное поле, в отчёт не идёт.",
                },
            },
            "required": ["confirmed"],
        },
    },
}

_SESSION_TOOL_SCHEMAS: list[dict[str, Any]] = (
    REPO_TOOL_SCHEMAS
    + [_SUBMIT_BRIEF_SCHEMA, _SUBMIT_STAGE_SCHEMA, _SUBMIT_REVIEW_SCHEMA,
       _SUBMIT_SUMMARY_SCHEMA, _FINISH_SCHEMA]
)

_MAX_MALFORMED = 3
_REPEAT_STOP = 3

# Жёсткие смысловые гейты («LLM предлагает, код проверяет» — не только про
# структуру полей, но и про содержание). Первое нарушение — отклонение вызова
# с объяснением; повторная отправка с тем же нарушением (после `_MAX_GATE_
# REJECTIONS` отклонений) принимается, но нарушившее поле заменяется пометкой —
# оценка этапа или вердикт не теряются из-за формулировки.
_MAX_GATE_REJECTIONS = 1

# Статусы, утверждающие наличие результата, — их обязан подтверждать
# проверенный фрагмент кода (CriterionVerdict.is_grounded).
_GROUNDED_STATUSES = ("done", "partial", "blocked")

_COMMENT_STRUCK = "Комментарий снят сторожем: ссылка на данные, которых нет в материалах"
_ITEM_STRUCK = "Пункт снят сторожем: ссылка на данные, которых нет в материалах"


@dataclass
class AgentResult:
    items: list[PlanItem] = field(default_factory=list)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    plan: list[PlanItem] = field(default_factory=list)
    summary: ProjectSummary | None = None
    summary_source: str = "none"
    readiness: int = 0
    context: dict[str, str] = field(default_factory=dict)
    source: str = "none"
    notes: list[str] = field(default_factory=list)

    @property
    def usable(self) -> bool:
        return bool(self.items)


def run_agent(
    plan_items: list[PlanItem],
    context: dict[str, str],
    tree: Tree,
    spec: ModelSpec | None,
    client: ChatClient | None = None,
    max_steps: int = DEFAULT_MAX_STEPS,
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None,
    on_summary: Callable[[ProjectSummary], None] | None = None,
    extraction: Extraction | None = None,
    description: str | None = None,
) -> AgentResult:
    """Проверить готовность пунктов готового клиентского пути по материалам
    проекта и вынести вердикт — одна сессия.

    `plan_items` — этапы пути, разобранные кодом из текстового поля. Модель
    не придумывает их, только проверяет. `context` — название пути, проект,
    «было → стало» (для шапки дашборда и вердикта). `description` — описание
    инициативы: из него агент формулирует «было → стало» первым шагом
    (`submit_brief`), если поля ещё не заданы в `context`.
    """
    if spec is None:
        return AgentResult(
            notes=["Matcher не настроен: оценки не получены"],
        )
    if not plan_items:
        return AgentResult(notes=["План пуст: этапы не заданы"])

    user_brief = render_plan_brief(plan_items, context)
    preface = (
        "Клиентский путь уже разобран и передан ниже. Тебе не нужно "
        "копировать его — только проверь готовность каждого пункта по "
        "материалам проекта инструментами и вызови submit_stage по каждому "
        "этапу, затем submit_summary и finish.\n\n"
    )
    if description and description.strip():
        preface += (
            "Описание инициативы (из него первым шагом сформулируй «Было» и "
            "«Стало» через submit_brief — по одному понятному предложению):\n"
            + description.strip() + "\n\n"
        )
    user_brief = preface + user_brief

    chat_client = client if client is not None else ChatClient(spec=spec)
    thinking_on = bool(
        spec.extra_body
        and spec.extra_body.get("chat_template_kwargs", {}).get("enable_thinking") is True
    )
    max_tokens = MAX_TOKENS_THINKING if thinking_on else MAX_TOKENS_DEFAULT
    outcome = _run_session(
        user_brief, plan_items, tree, chat_client, max_steps, max_tokens,
        on_verdict=on_verdict, on_summary=on_summary, extraction=extraction,
        context=dict(context),
    )

    notes = outcome.notes
    ungrounded = sum(v.ungrounded_count for v in outcome.verdicts)
    if ungrounded:
        notes.append(
            f"Буллитов со статусом «сделано»/«в работе»/«блокер» без единой подтверждённой "
            f"ссылки на материалы: {ungrounded} — агент утверждает состояние, но материалы "
            "его не показывают; нужна ручная проверка"
        )
    return AgentResult(
        items=outcome.items, verdicts=outcome.verdicts, plan=plan_items,
        summary=outcome.summary, summary_source=outcome.summary_source,
        readiness=0, context=outcome.context,
        source="llm" if outcome.items else "none", notes=notes,
    )


def find_unclaimed_paths(
    extraction: Extraction, verdicts: list[ItemVerdict], limit: int = 20
) -> list[UnclaimedGroup]:
    """Файлы-кандидаты, не процитированные ни одной подтверждённой evidence."""
    claimed = {
        e.path for v in verdicts for e in v.evidence if e.verified and e.path
    }
    candidate_paths = sorted({f.path for f in extraction.facts if f.path})
    unclaimed = [p for p in candidate_paths if p not in claimed]

    groups: dict[str, list[str]] = {}
    for path in unclaimed:
        segments = path.split("/")
        key = "/".join(segments[:2]) if len(segments) > 1 else segments[0]
        groups.setdefault(key, []).append(path)

    ranked = sorted(groups.items(), key=lambda kv: -len(kv[1]))[:limit]
    return [
        UnclaimedGroup(group=key, example_paths=paths[:3], file_count=len(paths))
        for key, paths in ranked
    ]


@dataclass
class _SessionOutcome:
    """Итог одной сессии агента."""

    items: list[PlanItem] = field(default_factory=list)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    summary: ProjectSummary | None = None
    summary_source: str = "none"
    context: dict[str, str] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)


def _run_session(
    user_brief: str,
    plan_items: list[PlanItem],
    tree: Tree,
    chat_client: ChatClient,
    max_steps: int,
    max_tokens: int,
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None,
    on_summary: Callable[[ProjectSummary], None] | None = None,
    extraction: Extraction | None = None,
    context: dict[str, str] | None = None,
) -> _SessionOutcome:
    """Фаза 0: `submit_brief` (опц.) → Фаза 1: `submit_stage` по каждому
    этапу → Фаза 1.5: `submit_review` контр-проверка → Фаза 2:
    `submit_summary` (вердикт) → `finish`.

    `context` — входный контекст пути; если агент вызвал `submit_brief`,
    поля `before`/`after` в нём обновляются и возвращаются наружу.
    """
    tools = ToolBox(tree, extraction=extraction)
    system_prompt, missing_parts = load_system_prompt()
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_brief},
    ]
    notes: list[str] = []
    if missing_parts:
        notes.append(
            "Части системного промпта не найдены и в анализ не попали: "
            + ", ".join(missing_parts)
        )
    recent_calls: list[tuple[tuple[str, str], ...]] = []
    malformed = 0
    # Сколько раз вызов по этап/вердикту отклонялся именно из-за смыслового
    # гейта (не из-за структуры) — после `_MAX_GATE_REJECTIONS` включается
    # tolerant-режим: оценка принимается, нарушившее поле заменяется пометкой.
    gate_attempts: dict[str, int] = {}
    summary_gate_attempts = 0
    items_by_id: dict[str, PlanItem] = {}
    verdicts_by_id: dict[str, ItemVerdict] = {}
    plan_by_id: dict[str, PlanItem] = {p.id: p for p in plan_items}
    summary: ProjectSummary | None = None
    summary_source = "none"
    finished = False
    steps_done = 0
    session_context: dict[str, str] = dict(context or {})
    review_injected = False
    review_done = False

    with trace_span("agent_session") as session_handle:
        for step in range(1, max(1, max_steps) + 1):
            steps_done = step
            with trace_span("agent.step", step=step) as step_span:
                try:
                    result = chat_client.chat(messages, tools=_SESSION_TOOL_SCHEMAS, max_tokens=max_tokens)
                except LlmError as exc:
                    step_span.set_attribute("error", exc.message)
                    notes.append(f"агент недоступен на шаге {step}: {exc.message}")
                    break

                step_span.set_attribute("from_cache", result.from_cache)
                step_span.set_attribute("text_chars", len(result.text or ""))
                step_span.set_attribute("reasoning_chars", len(result.reasoning_content or ""))
                if result.tool_calls:
                    names = ",".join(
                        str((c.get("function") or {}).get("name") or "")
                        for c in result.tool_calls
                    )
                    step_span.set_attribute("tool_calls", names)
                    step_span.set_attribute("tool_call_count", len(result.tool_calls))
                else:
                    step_span.set_attribute("tool_calls", "")
                    step_span.set_attribute("tool_call_count", 0)
                if result.usage:
                    step_span.set_attribute("total_tokens", result.usage.get("total_tokens", 0))

            if not result.tool_calls:
                malformed += 1
                if malformed >= _MAX_MALFORMED:
                    notes.append(f"агент не вызвал инструмент {malformed} раз подряд — остановлено")
                    break
                messages.append({"role": "assistant", "content": result.text})
                messages.append({
                    "role": "user",
                    "content": "Нужно вызвать инструмент — по каждому этапу "
                               "submit_stage (применимость и статусы по позициям), "
                               "потом submit_summary (решение, обоснование) и finish.",
                })
                continue
            malformed = 0

            signature = tuple(sorted(
                (str((c.get("function") or {}).get("name") or ""),
                 str((c.get("function") or {}).get("arguments") or ""))
                for c in result.tool_calls
            ))
            recent_calls.append(signature)
            if len(recent_calls) >= _REPEAT_STOP and len(set(recent_calls[-_REPEAT_STOP:])) == 1:
                notes.append(f"остановлено — {_REPEAT_STOP} одинаковых вызова подряд")
                break

            messages.append({
                "role": "assistant",
                "content": result.text or None,
                "tool_calls": result.tool_calls,
                "reasoning_content": result.reasoning_content or None,
            })

            for call in result.tool_calls:
                function = call.get("function") or {}
                name = str(function.get("name") or "")
                raw_args = function.get("arguments") or "{}"
                call_id = str(call.get("id") or "")
                try:
                    args = json.loads(raw_args)
                except json.JSONDecodeError:
                    messages.append({
                        "role": "tool", "tool_call_id": call_id,
                        "content": f"аргументы инструмента не являются валидным JSON: {raw_args!r}",
                    })
                    continue
                args = args if isinstance(args, dict) else {}

                if name == "submit_brief":
                    before = " ".join(str(args.get("before") or "").split())[:_MAX_BRIEF_CHARS]
                    now = " ".join(str(args.get("now") or "").split())[:_MAX_BRIEF_CHARS]
                    after = " ".join(str(args.get("after") or "").split())[:_MAX_BRIEF_CHARS]
                    if not before or not now or not after:
                        tool_content = (
                            "brief отклонён: все три поля (before, now, after) должны быть "
                            "непустыми, по одному предложению каждое"
                        )
                    else:
                        session_context["before"] = before
                        session_context["now"] = now
                        session_context["after"] = after
                        tool_content = (
                            "brief принят: «AS IS», «Now» и «To Be» зафиксированы. "
                            "Переходи к оценке этапов (submit_stage)."
                        )
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": tool_content})
                    continue

                if name == "submit_stage":
                    item_id = str(args.get("item_id") or "").strip()
                    if not item_id or item_id not in plan_by_id:
                        messages.append({
                            "role": "tool", "tool_call_id": call_id,
                            "content": f"оценка отклонена: item_id {item_id!r} не найден в плане. "
                                       f"Доступные этапы: {', '.join(plan_by_id.keys())}",
                        })
                        continue
                    item = plan_by_id[item_id]
                    tolerant = gate_attempts.get(item_id, 0) >= _MAX_GATE_REJECTIONS
                    verdict, error, gate_hit = _accept_stage(item, args, tree, tolerant=tolerant)
                    if error:
                        if gate_hit:
                            gate_attempts[item_id] = gate_attempts.get(item_id, 0) + 1
                        tool_content = f"оценка отклонена: {error}"
                    else:
                        items_by_id[item_id] = item
                        verdicts_by_id[item_id] = verdict
                        tool_content = "оценка принята. Переходи к следующему этапу."
                        if on_verdict is not None:
                            on_verdict(item, verdict)
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": tool_content})
                    continue

                if name == "submit_summary":
                    if len(verdicts_by_id) == len(plan_items) and not review_done:
                        messages.append({
                            "role": "tool", "tool_call_id": call_id,
                            "content": "сначала вызови submit_review для контр-проверки "
                                       "оценок, потом submit_summary",
                        })
                        continue
                    tolerant = summary_gate_attempts >= _MAX_GATE_REJECTIONS
                    parsed, error, gate_hit, warnings = _accept_summary(
                        args, set(items_by_id), verdicts_by_id, tolerant=tolerant,
                    )
                    if error:
                        if gate_hit:
                            summary_gate_attempts += 1
                        tool_content = f"вердикт отклонён: {error}"
                    else:
                        summary = parsed
                        summary_source = "llm"
                        notes.extend(warnings)
                        if on_summary is not None:
                            on_summary(parsed)
                        tool_content = "вердикт принят. Теперь вызови finish."
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": tool_content})
                    continue

                if name == "submit_review":
                    confirmed = bool(args.get("confirmed"))
                    if not confirmed:
                        tool_content = (
                            "нашёл пропущенную реализацию или заниженный статус — "
                            "исправь через повторный submit_stage, потом вызови "
                            "submit_review с confirmed=true"
                        )
                    else:
                        review_done = True
                        tool_content = "контр-проверка завершена. Переходи к submit_summary."
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": tool_content})
                    continue

                if name == "finish":
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": "сессия завершена"})
                    finished = True
                    continue

                outcome = tools.call(name, args)
                messages.append({"role": "tool", "tool_call_id": call_id, "content": outcome.content})

            if not review_injected and not finished and len(verdicts_by_id) == len(plan_items):
                review_injected = True
                messages.append({
                    "role": "user",
                    "content": _build_review_brief(plan_items, verdicts_by_id, extraction),
                })

            if finished:
                break
        else:
            notes.append(f"бюджет шагов исчерпан ({max_steps})")

        session_handle.set_attribute("steps_done", steps_done)
        session_handle.set_attribute("verdicts", len(verdicts_by_id))
        session_handle.set_attribute("summary_source", summary_source)
        session_handle.set_attribute("finished", finished)

    if not verdicts_by_id:
        notes.append("Этапы не оценены (submit_stage не вызывался)")
    if not summary:
        notes.append("Вердикт не сформирован (submit_summary не вызывался или отклонён)")
    if review_injected and not review_done:
        notes.append("Контр-проверка не завершена: submit_review не вызван")
    unrated = [p.title for p in plan_items if p.id not in verdicts_by_id]
    if unrated:
        notes.append("Этапы пути остались без оценки: " + ", ".join(unrated[:5]))
    return _SessionOutcome(
        items=list(items_by_id.values()), verdicts=list(verdicts_by_id.values()),
        summary=summary, summary_source=summary_source, notes=notes,
        context=session_context,
    )


def _build_review_brief(
    plan_items: list[PlanItem],
    verdicts_by_id: dict[str, ItemVerdict],
    extraction: Extraction | None,
) -> str:
    """Сводка для контр-проверки на занижение: текущие оценки + непроцитированные
    факты и файлы как подсказки, где могла быть пропущена реализация.

    Вставляется как user-сообщение после того, как все этапы оценены.
    Агент видит свои статусы (особенно `planned` и `partial`), непроцитированные
    точки входа/интеграции (ROUTE, TOOL, SQL, LLM_CALL — готовые path:line) и
    непроцитированные файлы (слепые зоны), после чего обязан проверить:
      - каждый `planned` — не пропущен ли существующий код;
      - каждый `partial` — не является ли он на самом деле `done` (путь
        end-to-end работает, ограничений нет).
    Вызывает `submit_review`.
    """
    lines = [
        "Все этапы оценены. Перед вердиктом — контр-проверка на занижение статусов.",
        "",
        "Твои текущие оценки:",
    ]
    check_count = 0
    for item in plan_items:
        v = verdicts_by_id.get(item.id)
        if not v:
            continue
        parts: list[str] = []
        for idx, c in enumerate(v.criteria, start=1):
            if not (c.applicable and c.status):
                continue
            tag = f"буллит {idx}={c.status}"
            if c.status == "planned":
                check_count += 1
                tag += " ← проверь, не пропущена ли реализация"
            elif c.status == "partial":
                check_count += 1
                tag += " ← проверь, не является ли он done (ограничений нет?)"
            parts.append(tag)
        lines.append(f"- {item.title}: {', '.join(parts) or 'нет оценок'}")

    if check_count == 0:
        lines.append("")
        lines.append("planned и partial пунктов нет — контр-проверка не требуется.")
        lines.append("Вызови submit_review с confirmed=true.")
        return "\n".join(lines)

    lines.append("")
    lines.append(
        f"У тебя {check_count} пунктов с возможным занижением. "
        "Проверь каждый по подсказкам ниже."
    )

    if extraction is not None:
        claimed = {
            e.path for v in verdicts_by_id.values()
            for e in v.evidence if e.verified and e.path
        }
        hint_kinds = ("ROUTE", "TOOL", "SQL_WRITE", "SQL_READ", "LLM_CALL",
                       "GRAPH_NODE", "EXTERNAL", "MODULE")
        unclaimed_facts = [
            f for f in extraction.facts
            if f.path and f.path not in claimed and f.kind in hint_kinds
        ]
        if unclaimed_facts:
            lines.append("")
            lines.append("Непроцитированные факты — точки входа и интеграции, которые ты не смотрел:")
            for f in unclaimed_facts[:20]:
                loc = f"{f.path}:{f.line}" if f.line else f.path
                value_str = _format_review_fact_value(f.value)
                row = f"- {f.kind} | {loc} | {f.key}"
                if value_str:
                    row += f" = {value_str}"
                lines.append(row)

        unclaimed = find_unclaimed_paths(extraction, list(verdicts_by_id.values()))
        if unclaimed:
            lines.append("")
            lines.append("Непроцитированные файлы (слепые зоны — открой те, что рядом с planned/partial):")
            for g in unclaimed[:8]:
                lines.append(f"- {g.group} — {g.file_count} файл(ов)")

    lines.extend([
        "",
        "Действуй:",
        "1. show_facts с kind из подсказок выше — готовые точки входа с path:line",
        "2. read_file по пути из подсказки — посмотри реализацию",
        "3. search по синонимам буллита, если подсказок нет",
        "4. Для partial: проверь, есть ли реальное ограничение. Если путь end-to-end",
        "   работает и ограничений нет — это done, исправь через submit_stage",
        "5. Для planned: если нашёл код — исправь статус через submit_stage",
        "6. Затем вызови submit_review с confirmed=true",
    ])
    return "\n".join(lines)


def _format_review_fact_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value[:120]
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)[:120]
    return str(value)[:120]


_MAX_CONCLUSION_BULLETS = 3
_MAX_CONCLUSION_WORDS = 4
_MAX_BRIEF_CHARS = 200

# Минимальное подтверждение движения для GO: хотя бы один применимый буллит
# `done`/`partial`. Полного выполнения не требуется — только свидетельство,
# что инициатива не стоит на месте. Ниже этого (всё `planned`/`blocked`) —
# PIVOT, GO кодом не публикуется.
_GROUNDED_PROOF_STATUSES = ("done", "partial")

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


def _accept_stage(
    item: PlanItem, args: dict, tree: Tree, tolerant: bool = False,
) -> tuple[ItemVerdict | None, str | None, bool]:
    """Разобрать `submit_stage` в `ItemVerdict`.

    Структурные проверки: совпадение числа оценок с числом буллитов этапа
    (этап без буллитов принимает пустой список criteria) и известные статусы.

    Смысловые гейты (`gate_violation=True` при нарушении):
    * статус, утверждающий результат (`done`/`partial`/`blocked`), обязан иметь
      хотя бы одну проверенную `verify_evidence` ссылку;
    * комментарий не должен упоминать пути, которых нет в материалах
      (`report.guard`).

    В `tolerant` режиме (после `_MAX_GATE_REJECTIONS` отклонений того же этапа)
    гейты не отклоняют вызов: нарушившие комментарии заменяются пометкой,
    неподтверждённые статусы остаются с флагом ungrounded — их видно в `gaps`.
    """
    raw_criteria = args.get("criteria")
    if not isinstance(raw_criteria, list):
        return None, "criteria должен быть списком оценок по позициям буллитов этапа", False
    expected = len(item.criteria)
    if len(raw_criteria) != expected:
        return None, (
            f"у этапа «{item.title}» {expected} буллитов, а прислано оценок: "
            f"{len(raw_criteria)}. Нужен ровно один элемент на буллет, в том же порядке."
        ), False

    criteria: list[CriterionVerdict] = []
    for index, raw in enumerate(raw_criteria, start=1):
        raw = raw if isinstance(raw, dict) else {}
        applicable = bool(raw.get("applicable"))
        status = str(raw.get("status") or "").strip().lower()
        if applicable and status not in CRITERION_STATUSES:
            return None, (
                f"буллит {index} отмечен как относящийся к инициативе, но его статус "
                f"{status!r} неизвестен (допустимы: {', '.join(CRITERION_STATUSES)})"
            ), False
        evidence = _parse_evidence(raw.get("evidence"), tree) if applicable else []
        comment = " ".join(str(raw.get("comment") or "").split())[:400] if applicable else ""
        if applicable:
            # Потолок по ролям доказательств: «Да» без ссылки на тул агента —
            # это «Почти». Решает код, а не формулировка модели.
            capped, reason = cap_status(
                status, {e.kind for e in evidence if e.verified and e.kind}
            )
            if reason:
                status = capped
                comment = f"{comment} {reason}.".strip() if comment else f"{reason.capitalize()}."
        criteria.append(CriterionVerdict(
            applicable=applicable,
            status=status if applicable else "",
            comment=comment[:400],
            evidence=evidence,
            group=" ".join(str(raw.get("group") or "").split())[:60],
        ))

    problems: list[str] = []
    struck_comments: list[int] = []
    for index, criterion in enumerate(criteria, start=1):
        if not criterion.applicable:
            continue
        if criterion.status in _GROUNDED_STATUSES and not criterion.is_grounded:
            problems.append(
                f"буллит {index} со статусом «{criterion.status}» без единой проверенной "
                "ссылки: evidence обязана содержать реальные путь, строку и основание "
                "из прочитанного кода; если подтверждения нет — ставь статус «planned»"
            )
        if criterion.comment:
            violations = check_explanation(criterion.comment, tree.files_set)
            if violations:
                struck_comments.append(index)
                problems.append(
                    f"комментарий буллита {index}: "
                    + "; ".join(v.render() for v in violations)
                )
    if problems and not tolerant:
        return None, " | ".join(problems[:3]), True

    for index in struck_comments:
        criteria[index - 1].comment = _COMMENT_STRUCK

    return ItemVerdict(
        item_id=item.id,
        applicable=bool(args.get("applicable")),
        criteria=criteria,
    ), None, False


def _parse_evidence(raw: object, tree: Tree) -> list[EvidenceRef]:
    """Разобрать список evidence-ссылок и проверить каждую `verify_evidence`."""
    evidence: list[EvidenceRef] = []
    if not isinstance(raw, list):
        return evidence
    for raw_ev in raw:
        if not isinstance(raw_ev, dict):
            continue
        path = str(raw_ev.get("path") or "").strip()
        basis = str(raw_ev.get("basis") or "").strip()
        try:
            line = int(raw_ev["line"]) if raw_ev.get("line") is not None else None
        except (TypeError, ValueError):
            line = None
        if not path:
            continue
        # Пустая роль означает «модель её не указала» и отличается от
        # definition: без разметки понижать статус нечем и не за что.
        kind = str(raw_ev.get("kind") or "").strip().lower()
        if kind not in EVIDENCE_KINDS:
            kind = ""
        note = " ".join(str(raw_ev.get("note") or "").split())[:160]
        result = verify_evidence(path, line, basis, tree)
        evidence.append(EvidenceRef(
            path=result.path, line=result.line, basis=basis,
            verified=result.ok, reason=result.reason, kind=kind, note=note,
        ))
    return evidence


def _accept_summary(
    args: dict,
    plan_ids: set[str],
    verdicts_by_id: dict[str, ItemVerdict],
    tolerant: bool = False,
) -> tuple[ProjectSummary | None, str | None, bool, list[str]]:
    """Разобрать `submit_summary` — вердикт и тексты.

    `conclusion` — ровно 3 буллита, каждый обрезается до 4 слов.

    Смысловые гейты (третий элемент кортежа — `gate_violation`):
    * `blocked` перевешивает процент — решение `GO` при блокирующем буллите
      кодом не публикуется; в `tolerant` режиме оно заменяется на `PIVOT`
      с записью в `warnings`;
    * нет подтверждённого движения (ни одного `done`/`partial`) — решение
      `GO` кодом не публикуется (нужен `PIVOT`); в `tolerant` режиме
      заменяется на `PIVOT` с записью в `warnings`;
    * текст `conclusion` проверяется сторожем путей и идентификаторов
      (`report.guard.check_summary_text`) против файлов, подтверждённых
      evidence; в `tolerant` режиме нарушивший пункт заменяется пометкой.
    """
    # Решение вычисляет код по единственному порогу: ≥50% — GO, иначе PIVOT.
    # Что прислала модель в `decision`, значения не имеет: поле принимается
    # для совместимости схемы вызова и молча заменяется расчётом.
    all_criteria = [c for v in verdicts_by_id.values() for c in v.criteria]
    readiness = calculate_progress(all_criteria) or 0
    decision = compute_decision(readiness)

    raw_conclusion = args.get("conclusion")
    if not isinstance(raw_conclusion, list) or len(raw_conclusion) != _MAX_CONCLUSION_BULLETS:
        return None, (f"conclusion: нужно ровно {_MAX_CONCLUSION_BULLETS} буллита, "
                      f"прислано {len(raw_conclusion) if isinstance(raw_conclusion, list) else 'не список'}"), False, []
    conclusion = [_trim_words(str(b), _MAX_CONCLUSION_WORDS) for b in raw_conclusion if str(b).strip()]
    if len(conclusion) != _MAX_CONCLUSION_BULLETS:
        return None, "conclusion: все 3 буллита должны быть непустыми", False, []

    # Прежние гейты (blocked перевешивает, «нет движения — не GO») сняты:
    # на текущем шаге решение определяется одним порогом готовности и ничем
    # больше. Блокирующие буллиты остаются видны в отчёте, но решение уже
    # не меняют.
    warnings: list[str] = []

    verified_paths = {
        e.path for verdict in verdicts_by_id.values()
        for e in verdict.evidence if e.verified
    }
    checked: list[str] = []
    for index, text in enumerate(conclusion, start=1):
        violations = check_summary_text(text, plan_ids, verified_paths)
        if not violations:
            checked.append(text)
            continue
        if not tolerant:
            return None, (f"conclusion, пункт {index}: "
                          + "; ".join(v.render() for v in violations)), True, []
        checked.append(_ITEM_STRUCK)
    conclusion[:] = checked

    return ProjectSummary(
        decision=decision,
        conclusion=conclusion,
        reason=decision_reason(readiness),
    ), None, False, warnings


def _trim_words(text: str, limit: int) -> str:
    return " ".join(text.split()[:limit])


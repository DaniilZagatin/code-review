"""Разбор файла инициативы из колоды и выбор формата ввода.

Главный риск здесь — принять один формат за другой. Оба начинаются одинаково
(«Клиентский путь:», «Проект:»), но в формате колоды все `##` идут до буллитов,
а за буллитами следует дословный хвост, который сам содержит строки с дефисом.
Ошибка распознавания раздувает знаменатель готовности.
"""

from __future__ import annotations

import os
import unittest
from pathlib import Path

from pko.errors import PkoError
from pko.progress.agent_md import looks_like_agent_md, parse_agent_md
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import CRITERION_WEIGHT, cap_status, scale_rows

DECK = """Клиентский путь: Key Clients
Проект: Copilot сотрудника ДККК по расчету CF моделей
## Подготовка к встрече с клиентом
## Детальный анализ сделки
- Принимает от пользователя модель и запрос в произвольной текстовой форме.
- Производит необходимые расчёты по модели.
- Интегрирован с моделью консистентных inputs при её готовности.
Длительный и ручной процесс CF-моделирования по key clients (до 36 часов).
- Принимает от пользователя модель и запрос, производит расчеты
Ключевые источники эффекта: As IS 36 часов, To Be 4 часа.
"""

MANUAL = """Клиентский путь: Постановка задачи в работу
Проект: Редизайн платёжного сервиса
Было: задача пересылается вручную

## Постановка задач
- Определены источники обращений
- Подтверждена скорость обработки

## Маршрутизация
- Задача уходит исполнителю автоматически
"""


class Detection(unittest.TestCase):
    def test_deck_is_recognised(self) -> None:
        self.assertTrue(looks_like_agent_md(DECK))

    def test_manual_journey_is_not_mistaken_for_deck(self) -> None:
        """Буллит раньше последнего `##` — это ручной формат."""
        self.assertFalse(looks_like_agent_md(MANUAL))

    def test_dispatcher_picks_the_right_parser(self) -> None:
        self.assertEqual(parse_plan_text(DECK).source_format, "agent_md")
        self.assertEqual(parse_plan_text(MANUAL).source_format, "journey_text")

    def test_manual_journey_keeps_its_stages(self) -> None:
        parsed = parse_plan_text(MANUAL)
        self.assertEqual(len(parsed.items), 2)

    def test_plain_stage_headings_are_recognised(self) -> None:
        """«Этап 3. Название» — такой же заголовок, как `##`."""
        text = (
            "Клиентский путь: Автотрекинг целей\n"
            "Инициатива: П4911\n"
            "Этап 1. Разметка задач\n"
            "Автоматическая разметка задач на метрические и бинарные\n"
            "Этап 2. Снятие цифрового следа\n"
            "Подбор системы-источника цифрового следа\n"
        )
        parsed = parse_plan_text(text)
        self.assertEqual(parsed.source_format, "journey_text")
        self.assertEqual([item.title for item in parsed.items],
                         ["Этап 1. Разметка задач", "Этап 2. Снятие цифрового следа"])
        self.assertEqual([len(item.criteria) for item in parsed.items], [1, 1])

    def test_deck_shape_without_dashes_goes_to_agent_md(self) -> None:
        """Все `##` подряд, затем строки без дефиса — это колода."""
        text = (
            "Клиентский путь: Key Clients\n"
            "Проект: Copilot ДККК\n"
            "## Подготовка к встрече\n"
            "## Детальный анализ сделки\n"
            "Принимает от пользователя модель и запрос.\n"
            "Производит необходимые расчёты по модели.\n"
        )
        parsed = parse_plan_text(text)
        self.assertEqual(parsed.source_format, "agent_md")
        self.assertEqual(len(parsed.items), 1)
        self.assertEqual(len(parsed.items[0].criteria), 2)


class DeckParsing(unittest.TestCase):
    def test_header_stages_and_bullets(self) -> None:
        plan = parse_agent_md(DECK)
        self.assertEqual(plan.journey, "Key Clients")
        self.assertEqual(plan.project, "Copilot сотрудника ДККК по расчету CF моделей")
        self.assertEqual(plan.stages,
                         ["Подготовка к встрече с клиентом", "Детальный анализ сделки"])
        self.assertEqual(len(plan.bullets), 3)

    def test_verbatim_tail_is_not_parsed_as_bullets(self) -> None:
        """В хвосте есть строка с дефисом — она не должна стать буллитом."""
        plan = parse_agent_md(DECK)
        self.assertEqual(len(plan.bullets), 3)
        self.assertIn("Длительный и ручной процесс", plan.source_text)
        self.assertIn("- Принимает от пользователя модель и запрос, производит расчеты",
                      plan.source_text)

    def test_bullets_are_kept_verbatim(self) -> None:
        plan = parse_agent_md(DECK)
        self.assertEqual(plan.bullets[0],
                         "Принимает от пользователя модель и запрос в произвольной текстовой форме.")

    def test_stages_are_context_not_bullet_owners(self) -> None:
        """Связи «буллит → этап» в файле нет, изобретать её нельзя."""
        parsed = parse_agent_md(DECK).to_journey_parse()
        self.assertEqual(len(parsed.items), 1)
        self.assertEqual(len(parsed.items[0].criteria), 3)
        self.assertIn("Детальный анализ сделки", parsed.context["stages"])

    def test_effect_is_quoted_from_the_tail(self) -> None:
        quotes = parse_agent_md(DECK).effect_quotes
        self.assertTrue(any("As IS 36 часов" in q for q in quotes))

    def test_digest_changes_with_content(self) -> None:
        first = parse_agent_md(DECK).source_digest
        second = parse_agent_md(DECK.replace("Key Clients", "ММБ")).source_digest
        self.assertTrue(first)
        self.assertNotEqual(first, second)

    def test_deck_without_stages(self) -> None:
        text = "Клиентский путь: X\nПроект: Y\n- Первый буллит\n- Второй буллит\nХвост.\n"
        plan = parse_agent_md(text)
        self.assertEqual(plan.stages, [])
        self.assertEqual(len(plan.bullets), 2)

    def test_duplicate_bullet_is_noted(self) -> None:
        text = "Клиентский путь: X\nПроект: Y\n- Один и тот же\n- Один и тот же\nХвост\n"
        self.assertTrue(any("дублирует" in n for n in parse_agent_md(text).notes))

    def test_missing_header_is_a_clear_error(self) -> None:
        with self.assertRaises(PkoError) as ctx:
            parse_agent_md("Проект: Y\n- Буллит один\nХвост\n")
        self.assertIn("Клиентский путь", ctx.exception.message)
        self.assertTrue(ctx.exception.hint)

    def test_no_bullets_is_a_clear_error(self) -> None:
        with self.assertRaises(PkoError) as ctx:
            parse_agent_md("Клиентский путь: X\nПроект: Y\n## Этап один\n## Этап два\n")
        self.assertIn("буллита", ctx.exception.message)

    def test_bullets_without_dashes_are_accepted(self) -> None:
        """Реальный ввод приходит и без маркеров списка."""
        text = (
            "Клиентский путь: Key Clients\n"
            "Проект: Copilot ДККК\n"
            "## Подготовка к встрече\n"
            "## Детальный анализ сделки\n"
            "Принимает от пользователя модель и запрос.\n"
            "Производит необходимые расчёты по модели.\n"
        )
        plan = parse_agent_md(text)
        self.assertEqual(len(plan.stages), 2)
        self.assertEqual(len(plan.bullets), 2)
        self.assertEqual(plan.bullets[0], "Принимает от пользователя модель и запрос.")

    def test_invisible_characters_are_stripped(self) -> None:
        """Копирование из презентаций приносит BOM и zero-width."""
        text = (
            "Клиентский путь: X\nПроект: Y\n## Этап\n"
            "﻿﻿Принимает модель от пользователя\n"
            "​Производит расчёты\n"
        )
        plan = parse_agent_md(text)
        self.assertEqual(plan.bullets[0], "Принимает модель от пользователя")
        self.assertEqual(plan.bullets[1], "Производит расчёты")


class StatusCap(unittest.TestCase):
    """«Да» невозможно подтвердить без ссылки на инструмент агента."""

    def test_done_without_tool_is_capped_to_partial(self) -> None:
        status, reason = cap_status("done", {"definition", "wiring"})
        self.assertEqual(status, "partial")
        self.assertIn("инструмент агента", reason.lower())

    def test_done_with_tool_stays(self) -> None:
        self.assertEqual(cap_status("done", {"definition", "tool"}), ("done", ""))

    def test_partial_without_wiring_is_capped_to_scaffold(self) -> None:
        status, reason = cap_status("partial", {"definition"})
        self.assertEqual(status, "scaffold")
        self.assertTrue(reason)

    def test_no_kinds_means_no_cap(self) -> None:
        """Без разметки ролей понижать нечем и не за что."""
        self.assertEqual(cap_status("done", set()), ("done", ""))

    def test_planned_is_never_capped(self) -> None:
        self.assertEqual(cap_status("planned", {"definition"}), ("planned", ""))


class Scale(unittest.TestCase):
    def test_scale_matches_the_weights_used_in_the_formula(self) -> None:
        """Легенда и расчёт берут веса из одного места и разойтись не могут."""
        for row in scale_rows():
            if row["weight"] is None:
                continue
            self.assertEqual(row["weight"], int(CRITERION_WEIGHT[row["status"]] * 100))

    def test_scale_covers_four_answers_plus_not_applicable(self) -> None:
        labels = [row["label"] for row in scale_rows()]
        self.assertEqual(labels, ["Да", "Почти", "Почти нет", "Нет", "Не применимо"])


_CORPUS = Path(os.environ.get(
    "PKO_CORPUS",
    str(Path.home() / "Downloads" / "Telegram Desktop" / "agents" / "agents"),
))


def _corpus_files() -> list[Path]:
    if not _CORPUS.is_dir():
        return []
    return [p for p in sorted(_CORPUS.rglob("*.md")) if p.name != "INDEX.md"]


@unittest.skipUnless(_corpus_files(), f"корпус инициатив не найден: {_CORPUS}")
class Corpus(unittest.TestCase):
    """Прогон по реальным файлам, если они есть локально."""

    def test_every_file_is_recognised_and_parsed(self) -> None:
        failures: list[str] = []
        for path in _corpus_files():
            text = path.read_text(encoding="utf-8")
            if not looks_like_agent_md(text):
                failures.append(f"{path.name}: формат не опознан")
                continue
            try:
                plan = parse_agent_md(text, path.name)
            except PkoError as exc:
                failures.append(f"{path.name}: {exc.message}")
                continue
            if not plan.bullets:
                failures.append(f"{path.name}: ноль буллитов")
        self.assertEqual(failures, [], f"не разобрано файлов: {len(failures)}")

    def test_tail_never_inflates_the_bullet_list(self) -> None:
        for path in _corpus_files():
            text = path.read_text(encoding="utf-8")
            dashes = sum(1 for line in text.split("\n")
                         if line.strip().startswith(("-", "•")))
            self.assertLessEqual(len(parse_agent_md(text).bullets), dashes, path.name)


if __name__ == "__main__":
    unittest.main()

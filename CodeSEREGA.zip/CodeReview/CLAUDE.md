# CLAUDE.md — PKO progress

Контекст проекта для Claude Code. Кладётся в корень репозитория.

## Что это

Инструмент из двух команд:

- `pko progress` — сверяет текстовое описание клиентского пути (этапы + буллиты)
  с кодом целевого репозитория, выпускает отчёт о готовности с решением
  **GO / PIVOT / NO GO**.
- `pko review` — ревьюит git-diff между коммитами по рубрикатору, выдаёт
  **APPROVE / COMMENT / REQUEST_CHANGES**.

## Главный принцип: LLM предлагает, код проверяет

Это не лозунг, а архитектурное ограничение. Нарушать его нельзя ни в бэкенде,
ни в шаблонах, ни во фронтенде.

1. **Клон только на чтение.** Мутирующие git-подкоманды падают до запуска git
   (`ALLOWED_SUBCOMMANDS` в `git/repo.py`). Мутации разрешены только в
   `git/remote.py` (`clone --mirror`, `fetch`). Инструменты агента не имеют
   пишущих операций; секреты маскируются; `.env*`, `*.pem`, `*.key` не читаются.
2. **Ссылка на код без проверки не публикуется.** Каждая evidence проходит
   `verify.py`: путь и строка обязаны существовать, рядом со строкой обязан
   найтись якорный токен из основания.
3. **Свободный текст тоже проверяется.** Статус без проверенной ссылки не
   принимается. Комментарии и вердикты проходят `report/guard.py`.
4. **Финальный вердикт вычисляет код.** `compute_decision` и `compute_verdict` —
   детерминированные функции. Ни модель, ни шаблон, ни JS не имеют права
   вычислять решение самостоятельно.

Если правка добавляет вычисление статуса/процента/решения вне
`progress/schema.py` или `review/aggregator.py` — это регресс, а не фича.

## Карта репозитория

```
backend/pko/
  cli.py           pko progress / review / serve
  defaults.py      дефолтные репозиторий, ветка, LLM-эндпоинт
  errors.py        PkoError + GitError/SshAccessError/UrlError/
                   ExtractionError/ValidationError/LlmError
  git/             read-only обёртка: repo.py, remote.py, url.py
  extractors/      детерминированные факты из кода
                   base.py, runner.py, python_code.py, deps.py,
                   contracts.py, policy_specs.py, ownership.py,
                   prompts.py, test_reports.py
  llm/             registry.py (ModelSpec), client.py (кеш), tracing.py
  progress/        journey_text.py, schema.py, verify.py, agent_tools.py,
                   matcher.py, pipeline.py, target_repo.py, local_source.py,
                   agent_system.md
  review/          rubric.py, diff_model.py, verify_diff.py, aggregator.py,
                   review_tools.py, reviewer.py, pipeline.py, agent_system.md
  report/guard.py  сторож текста
  render/          base.py, progress_report.py, dashboard_html.py,
                   dashboard_template.html
  output/          publisher.py (атомарная запись отчётов)
  web/             app.py (FastAPI), analyses.py, reviews.py
  util/            env.py, paths.py, sources.py, yamlmini.py
frontend-web/      Next.js 16: загрузка → SSE прогресс → дашборд
frontend-app/      Vite + React: компонент пути для оффлайн-отчёта CLI
tests/             unittest, герметичный (без сети и без реального LLM)
```

## Команды

```bash
pip install -e .                  # editable-установка, даёт бинарь pko
make test                         # Python-тесты (241+), должны быть зелёными
pko serve --port 8000             # бэкенд
cd frontend-web && npm run dev    # фронт на :3000, проксирует /api на :8000
cd frontend-app && npm run build  # → dist/index.html, нужен для CLI-отчёта
cd frontend-app && npm test       # 5 тестов геометрии шеврона
cd frontend-web && npm run lint

pko progress --journey-text "..." --repo-path /path/to/repo
pko review --repo-path /path/to/repo --base <sha> --head <sha>
```

## Ключевые контракты

**`_dashboard_json(model)`** в `web/analyses.py` — контракт между бэкендом и
`render/dashboard_template.html`. Сейчас отдаёт `meta`, `readiness`, `items`
(с `assessment`-строками), `summary`. Любое поле, которое шаблон читает из
`window.__DATA__`, обязано появляться здесь; шаблон не имеет права
достраивать недостающее вычислением.

**`calculate_progress(criteria)`** — веса `done=1.0`, `partial=0.5`,
`planned/n\a/blocked=0.0`; `n/a` **исключается из знаменателя**.
`READY_THRESHOLD = 50`, `DEADLINE_WINDOW = 120`.

**Статусы критериев:** `done`, `partial`, `planned`, `n/a`, `blocked`.
`done`/`partial`/`blocked` требуют проверенной evidence, иначе оценка
отклоняется гейтом.

## Подводные камни

- **`PKO_THINKING=False` обязателен для GLM-5.2.** С включённым thinking модель
  съедает бюджет на рассуждения и возвращает пустой ответ.
- **Кеш LLM** в `~/.pko/llm-cache`, ключ — sha256 payload (system prompt входит
  в payload, поэтому правка `agent_system.md` кеш инвалидирует). Повторный
  прогон того же коммита = 0 вызовов. Права 0o600 — там корпоративные данные.
- **Тесты герметичны:** `ChatClient._create` подменяется скриптованными
  ответами из `tests/agent_script.py`, кеш уводится во временный каталог,
  фикстура `tests/fixtures/mini_repo` создаётся автоматически. Не добавлять
  тесты, которые ходят в сеть или клонируют реальный репозиторий.
- **`python_code.py` разбирает только Python.** Целевые репозитории часто на
  SQL/Java — тогда `show_facts` почти пуст и агент работает вслепую. См. задачу
  T4 в TASKS.md.
- **`yamlmini.py`** — свой минимальный парсер вместо PyYAML. Не поддерживает
  anchors, merge keys, flow style. Не расширять его молча: на неподдерживаемом
  синтаксисе нужна явная ошибка, а не тихая деградация.
- **Задачи веба живут в памяти** (`MAX_JOBS = 100`, `queue.Queue`,
  daemon-поток). Рестарт сервера теряет всё, включая готовые анализы.
- **`frontend-app/dist/index.html`** должен быть собран, иначе
  `render_progress_report` падает с `PkoError("Дашборд-путь не собран")`.

## Пороги (справочник)

| Константа | Значение | Где |
|---|---|---|
| `DEFAULT_MAX_STEPS` | 60 | matcher, reviewer |
| `MAX_TOKENS_DEFAULT` / `MAX_TOKENS_THINKING` | 2000 / 8192 | client |
| `_MAX_MALFORMED` / `_REPEAT_STOP` | 3 / 3 | matcher, reviewer |
| `_MAX_GATE_REJECTIONS` | 1 | matcher (см. T10 — расходится со спекой) |
| `READY_THRESHOLD` / `DEADLINE_WINDOW` | 50% / 120 дн. | schema |
| `MAX_LIST_FILES` / `MAX_READ_LINES` | 400 / 400 | agent_tools |
| `SEARCH_MAX_MATCHES` / `SEARCH_TIMEOUT_SECONDS` | 200 / 5.0 | agent_tools |
| `MAX_DIFF_FILES` / `MAX_DIFF_LINES` | 200 / 5000 | review |
| `ANCHOR_WINDOW` / `MIN_ANCHOR` | 5 строк / 4 символа | verify |
| `MAX_FILE_BYTES` | 2 МБ | чтение файла |
| `MAX_WORKSPACE_FILES` / `MAX_WORKSPACE_BYTES` | 5000 / 200 МБ | ZIP-гвард |

## Стиль работы

- Язык интерфейса, ошибок и отчётов — русский. Имена в коде — английские.
- Ошибки бросать как `PkoError(message, hint)`: `message` — что случилось,
  `hint` — что делать человеку.
- Новый детерминированный расчёт — в `schema.py` или `aggregator.py`, с тестом.
- Правка шаблона `dashboard_template.html` не должна вводить вычислений,
  дублирующих бэкенд.
- После правок: `make test`, затем прогон `pko progress` на `mini_repo`.

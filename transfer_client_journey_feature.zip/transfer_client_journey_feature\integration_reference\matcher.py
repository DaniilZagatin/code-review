"""Единый агент: формулирует клиентский путь по доступной информации, оценивает
его этапы по материалам проекта и выносит вердикт — одна сессия, одна личность.

Работа идёт в три фазы:
  1. ПУТЬ — агент читает образ результата и компактный справочник программы,
     затем формулирует этапы и бизнес-возможности через `submit_plan`.
  2. ОЦЕНКА — по каждому этапу агент собирает факты инструментами и вызывает
     `submit_stage`: относится ли этап к инициативе и что с каждым его
     буллитом (`done`/`partial`/`planned`/`blocked` либо «не относится»).
  3. ВЕРДИКТ — `submit_summary`: решение GO/PIVOT/NO GO, готовность проекта,
     обоснование решения, риски и ближайшие действия. Затем `finish`.

Текст пути отделён от оценки: `PlanItem` хранит принятую бизнес-формулировку,
а `submit_stage` присылает только статусы по позициям. Так оценка не может
случайно переписать буллит после анализа фактов.

Сторож бизнес-языка применяется ко всем видимым текстам, включая этапы и
буллиты: техническое описание не должно попадать на управленческий дашборд.

Ни одна evidence-ссылка не публикуется без проверки: `progress.verify.verify_evidence`
подтверждает её структурно (путь и строка существуют на этом коммите, рядом —
слово из основания). Неподтверждённая ссылка не отбрасывается — остаётся в
модели с `verified=False` и причиной, а буллет, которому заявили `done` без
единой подтверждённой ссылки, попадает в `gaps` отчёта. Ссылка теперь
привязана к конкретному буллету, а не к этапу целиком: раньше одна валидная
ссылка «прикрывала» весь этап, включая пункты, к которым не относилась.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Callable

from pko.errors import LlmError, PkoError
from pko.extractors.base import Tree
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import trace_span
from pko.progress.agent_tools import TOOL_SCHEMAS as REPO_TOOL_SCHEMAS, ToolBox
from pko.progress.pptx_reader import Slide, render_slide
from pko.progress.schema import (
    CRITERION_STATUSES,
    DECISIONS,
    CriterionVerdict,
    EvidenceRef,
    ItemVerdict,
    PlanItem,
    ProjectSummary,
    UnclaimedGroup,
)
from pko.progress.verify import verify_evidence
from pko.report.guard import (
    check_business_language,
    check_summary_text,
    is_restatement,
)

# Системный промпт собирается из трёх редактируемых Markdown-файлов рядом с
# этим модулем: протокол сессии, язык отчёта и короткие правила вердикта
# программы AI-эффективность. Данные конкретного клиентского пути подбираются
# отдельно и добавляются только при совпадении.
_PROMPT_PARTS = ("agent_system.md", "business_language.md", "ai_efficiency_program.md")
_PROMPT_DIR = Path(__file__).parent


def load_system_prompt() -> tuple[str, list[str]]:
    """Системный промпт и список ненайденных частей.

    Отсутствие части не роняет прогон (агент работает на том, что есть), но
    попадает в `gaps` — читатель отчёта должен видеть, какие правила до
    модели не дошли."""
    parts: list[str] = []
    missing: list[str] = []
    for name in _PROMPT_PARTS:
        try:
            parts.append((_PROMPT_DIR / name).read_text(encoding="utf-8"))
        except OSError:
            missing.append(name)
    if not parts:
        parts.append("Ты — агент, который переносит клиентский путь из образа "
                     "результата и сверяет его с материалами проекта.")
    return "\n\n---\n\n".join(parts), missing


# Этапы, заданные человеком при загрузке материалов. Верхняя граница — не
# вкус: ряд этапов на дашборде при большем числе становится нечитаемым.
MAX_USER_STAGES = 12
MAX_USER_STAGE_CHARS = 60
MAX_STAGE_TITLE_CHARS = 70
MAX_STAGE_DESCRIPTION_CHARS = 140
MAX_CAPABILITY_CHARS = 140
MIN_CAPABILITIES_PER_STAGE = 2
MAX_CAPABILITIES_PER_STAGE = 5
MAX_CLIENT_PATH_NAME_CHARS = 90


def parse_stage_titles(raw: "str | list[str] | None") -> list[str]:
    """Список названий этапов из пользовательского ввода.

    Принимает и текст (одно название в строке — так его вводят в форме), и
    готовый список (так его передаёт CLI). Пустой ввод — не ошибка, а «этапы
    не заданы»: тогда агент формулирует их по доступной информации.

    Ошибки ввода поднимаются здесь, а не после запуска анализа: человек должен
    увидеть их в ответе на отправку формы, а не через минуту в зависшей задаче.
    """
    if raw is None:
        return []
    lines = raw.splitlines() if isinstance(raw, str) else list(raw)
    titles = [" ".join(str(line).split()) for line in lines]
    titles = [t for t in titles if t]
    if len(titles) > MAX_USER_STAGES:
        raise PkoError(
            f"Слишком много этапов клиентского пути: {len(titles)}.",
            hint=f"оставьте не больше {MAX_USER_STAGES} — иначе ряд этапов на "
                 "дашборде не читается; объедините мелкие вехи в одну",
        )
    too_long = [t for t in titles if len(t) > MAX_USER_STAGE_CHARS]
    if too_long:
        raise PkoError(
            f"Название этапа длиннее {MAX_USER_STAGE_CHARS} символов: «{too_long[0]}».",
            hint="этап подписывается внутри карточки на дашборде — нужно 2-5 слов",
        )
    return titles


def _same_title(left: str, right: str) -> bool:
    """Сравнение названий этапов без учёта регистра и лишних пробелов."""
    return " ".join(left.split()).casefold() == " ".join(right.split()).casefold()


# Бюджет шагов агента на всю сессию (формирование пути + обход всех этапов).
DEFAULT_MAX_STEPS = 60

# Бюджет ответа для агентского цикла. Thinking-режим съедает значительную
# часть max_tokens в reasoning_content — ему нужен больший budget, иначе
# content приходит пустым («пустой ответ»).
MAX_TOKENS_DEFAULT = 4096
MAX_TOKENS_THINKING = 12288

_SUBMIT_PLAN_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_plan",
        "description": "Клиентский путь целиком — обязательный первый вызов сессии. "
                       "Сформулируй этапы и 2-5 ключевых бизнес-возможностей каждого этапа "
                       "по образу результата, релевантному пути программы и материалам "
                       "проекта. Пиши о наблюдаемом изменении для клиента или процесса, а "
                       "не о функциях и выполненных технических работах. Повторный вызов "
                       "заменяет весь путь.",
        "parameters": {
            "type": "object",
            "properties": {
                "client_path_name": {"type": "string", "description": "название клиентского пути — это путь или задача КЛИЕНТА, а не название продукта. Например «Подготовка руководителя к управленческой встрече»."},
                "project_name": {"type": "string", "description": "название проекта, продукта или инициативы, которую анализируем"},
                "client": {"type": "string", "description": "кто получает основную пользу и кому должно стать лучше: конкретная роль или группа и её задача, до 20 слов"},
                "before": {"type": "string", "description": "как клиент решает эту задачу сейчас и в чём сложность — до 20 слов, наблюдаемое поведение, не перечень недостающих функций"},
                "after": {"type": "string", "description": "как изменится опыт клиента и какой результат он получит — до 20 слов, наблюдаемое изменение, не список функций продукта"},
                "items": {
                    "type": "array",
                    "description": "последовательные этапы клиентского пути",
                    "items": {
                        "type": "object",
                        "properties": {
                            "item_id": {"type": "string", "description": "короткий устойчивый идентификатор латиницей/цифрами/дефисами"},
                            "title": {"type": "string", "maxLength": MAX_STAGE_TITLE_CHARS, "description": "краткий этап клиентского пути или бизнес-процесса, 2-7 слов"},
                            "description": {"type": "string", "maxLength": MAX_STAGE_DESCRIPTION_CHARS, "description": "одно короткое предложение о том, что меняется для клиента или процесса"},
                            "criteria": {
                                "type": "array",
                                "minItems": MIN_CAPABILITIES_PER_STAGE,
                                "maxItems": MAX_CAPABILITIES_PER_STAGE,
                                "items": {"type": "string", "maxLength": MAX_CAPABILITY_CHARS},
                                "description": "2-5 наиболее важных бизнес-возможностей этапа: наблюдаемый результат для клиента или процесса, без статуса и технических деталей",
                            },
                            "source_slide": {"type": "integer", "description": "номер основного слайда-источника; 0, если этап задан пользователем или собран из нескольких источников"},
                        },
                        "required": ["item_id", "title", "description", "criteria", "source_slide"],
                    },
                },
            },
            "required": ["client_path_name", "project_name", "client", "before", "after", "items"],
        },
    },
}

_SUBMIT_STAGE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_stage",
        "description": "Оценка одного этапа — ОДИН вызов на этап, после того как ты собрал "
                       "факты инструментами. Тексты сюда не передаются: они уже приняты в "
                       "submit_plan, здесь только применимость и статусы по позициям. Список "
                       "criteria обязан совпадать по длине и порядку с буллитами этого этапа "
                       "в принятом пути. applicable=true ставь только тем этапам и буллитам, "
                       "которые относятся к анализируемой инициативе; остальные оставь "
                       "неприменимыми — они станут серыми и в расчёт не войдут. Повторный "
                       "вызов с тем же item_id заменяет предыдущую оценку.",
        "parameters": {
            "type": "object",
            "properties": {
                "item_id": {"type": "string", "description": "идентификатор этапа из принятого пути"},
                "applicable": {"type": "boolean", "description": "относится ли этап к анализируемой инициативе"},
                "criteria": {
                    "type": "array",
                    "description": "оценки буллитов этапа строго по позициям принятого пути: столько же элементов и в том же порядке",
                    "items": {
                        "type": "object",
                        "properties": {
                            "applicable": {"type": "boolean", "description": "относится ли буллит к анализируемой инициативе; если нет — статус не нужен, пункт станет серым"},
                            "status": {
                                "type": "string", "enum": list(CRITERION_STATUSES),
                                "description": "done — результат подтверждён материалами и существенной доработки не требует; partial — уже создаётся, но значимый разрыв остался; planned — предусмотрен планом, но не реализован; blocked — отсутствие этого результата блокирует следующий этап, пилот или клиентский эффект (только для конкретного критического препятствия)",
                            },
                            "evidence": {
                                "type": "array",
                                "description": "чем подтверждён статус: только реальные путь и строка из того, что ты действительно прочитал инструментами. Для planned оставь пустым — подтверждать отсутствие нечем.",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "path": {"type": "string"},
                                        "line": {"type": "integer"},
                                        "basis": {"type": "string", "description": "конкретное имя (функции/класса/эндпоинта/файла) рядом со строкой — по нему ссылка проверяется"},
                                    },
                                },
                            },
                        },
                        "required": ["applicable"],
                    },
                },
                "notes": {"type": "string", "description": "краткие наблюдения для себя — служебное поле, в отчёт не идёт"},
            },
            "required": ["item_id", "applicable", "criteria"],
        },
    },
}

_SUBMIT_SUMMARY_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_summary",
        "description": "Вердикт по проекту — вызывай ОДИН раз после всех submit_stage и ДО "
                       "finish. Решение, готовность, обоснование, риски и ближайшие действия. "
                       "Всё бизнес-языком, на основе уже отправленных оценок и последовательных "
                       "критериев программы AI-эффективность.",
        "parameters": {
            "type": "object",
            "properties": {
                "decision": {
                    "type": "string", "enum": list(DECISIONS),
                    "description": "GO — E2E-решение, prod/prod-like данные, обратная связь и гипотеза подтверждены; PIVOT — проблема клиента реальна, но подход, скоуп или гипотеза требуют нового PoC; NO GO — после полного цикла работающего результата нет либо ценность не подтверждена и новой гипотезы нет",
                },
                "readiness": {
                    "type": "integer",
                    "description": "готовность проекта целиком, 0-100. Это ТВОЯ целостная оценка, а не среднее по этапам: учитывай подтверждённость клиентской ценности, зрелость применимых этапов, критичность незакрытых пунктов, риски и блокеры, возможность безопасно перейти к следующему шагу. Не занижай из осторожности: 0 означает, что клиент не получил ничего.",
                },
                "conclusion": {
                    "type": "string",
                    "description": "почему выбрано именно это решение: что уже меняется для клиента, какой разрыв мешает и можно ли идти дальше. Ровно 2 коротких предложения, суммарно до 45 слов.",
                },
                "risks": {
                    "type": "array",
                    "minItems": 2,
                    "maxItems": 3,
                    "items": {"type": "string", "maxLength": 110},
                    "description": "2-3 ключевых риска по убыванию важности, каждый до 110 символов: обстоятельство и его последствие для клиента или процесса.",
                },
                "priorities": {
                    "type": "array",
                    "minItems": 2,
                    "maxItems": 3,
                    "items": {"type": "string", "maxLength": 110},
                    "description": "2-3 ближайших действия по приоритету, каждое до 110 символов: шаг и изменение клиентского пути или процесса.",
                },
            },
            "required": ["decision", "readiness", "conclusion", "risks", "priorities"],
        },
    },
}

_FINISH_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "finish",
        "description": "Вызови, когда оценил все этапы пути и отправил вердикт "
                       "(submit_summary) — сессия завершена.",
        "parameters": {"type": "object", "properties": {}},
    },
}

_SESSION_TOOL_SCHEMAS: list[dict[str, Any]] = (
    REPO_TOOL_SCHEMAS
    + [_SUBMIT_PLAN_SCHEMA, _SUBMIT_STAGE_SCHEMA, _SUBMIT_SUMMARY_SCHEMA, _FINISH_SCHEMA]
)

_MAX_MALFORMED = 3
_REPEAT_STOP = 3

@dataclass
class AgentResult:
    items: list[PlanItem] = field(default_factory=list)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    plan: list[PlanItem] = field(default_factory=list)
    summary: ProjectSummary | None = None
    summary_source: str = "none"
    readiness: int = 0
    context: dict[str, str] = field(default_factory=dict)
    source: str = "none"
    notes: list[str] = field(default_factory=list)

    @property
    def usable(self) -> bool:
        return bool(self.items)


def run_agent(
    slides: list[Slide],
    tree: Tree,
    spec: ModelSpec | None,
    client: ChatClient | None = None,
    max_steps: int = DEFAULT_MAX_STEPS,
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None,
    on_plan: Callable[[list[PlanItem]], None] | None = None,
    on_summary: Callable[[ProjectSummary], None] | None = None,
    extraction: Extraction | None = None,
    stages: list[str] | None = None,
) -> AgentResult:
    """Сформулировать клиентский путь, оценить его этапы по материалам проекта
    и вынести вердикт — одна сессия, одна личность.

    `stages` — этапы, заданные человеком при загрузке. Пустой список (по
    умолчанию) — путь формулируется по образу результата, справочнику и
    материалам проекта. Непустой — агент
    обязан вернуть ровно эти этапы, в этом же порядке; названия идут в отчёт в
    авторской редакции человека.
    """
    if spec is None:
        return AgentResult(notes=["Matcher не настроен: путь и оценки не получены"])

    content_slides = [s for s in slides if not s.is_empty]
    if not content_slides:
        return AgentResult(notes=["В образе результата нет текстовых фигур"])

    known_slides = {s.number for s in content_slides}
    user_stages = list(stages or [])
    user = "Образ результата:\n\n" + "\n\n".join(render_slide(s) for s in content_slides)
    if user_stages:
        listing = "\n".join(f"{i}. {title}" for i, title in enumerate(user_stages, 1))
        user = (
            "Этапы клиентского пути заданы заказчиком. В submit_plan верни ровно эти "
            "этапы, в этом порядке и с этими названиями — не добавляй новых, не убирай "
            "и не переименовывай. Бизнес-возможности внутри этапов сформулируй "
            f"по всем доступным материалам:\n{listing}\n\n" + user
        )

    chat_client = client if client is not None else ChatClient(spec=spec)
    thinking_on = spec.thinking_enabled
    max_tokens = MAX_TOKENS_THINKING if thinking_on else MAX_TOKENS_DEFAULT
    outcome = _run_session(
        user, known_slides, tree, chat_client, max_steps, max_tokens,
        on_verdict=on_verdict, on_plan=on_plan, on_summary=on_summary,
        extraction=extraction, user_stages=user_stages,
    )

    notes = outcome.notes
    ungrounded = sum(v.ungrounded_count for v in outcome.verdicts)
    if ungrounded:
        notes.append(
            f"Буллитов со статусом «сделано»/«в работе»/«блокер» без единой подтверждённой "
            f"ссылки на материалы: {ungrounded} — агент утверждает состояние, но материалы "
            "его не показывают; нужна ручная проверка"
        )
    if outcome.summary is not None:
        notes.extend(_readiness_notes(outcome.readiness, outcome.verdicts))
    return AgentResult(
        items=outcome.items, verdicts=outcome.verdicts, plan=outcome.plan,
        summary=outcome.summary, summary_source=outcome.summary_source,
        readiness=outcome.readiness, context=outcome.context,
        source="llm" if outcome.items else "none", notes=notes,
    )


def _readiness_notes(readiness: int, verdicts: list[ItemVerdict]) -> list[str]:
    """Расхождения между цифрой готовности и картиной по буллитам.

    Готовность ставит модель — среднее по этапам её не заменяет, и это
    осознанно: критичность отдельного разрыва арифметикой не выражается. Но
    если цифра прямо спорит с собственными оценками агента, читатель отчёта
    должен это увидеть. Поэтому расхождение не исправляется молча, а
    называется в `gaps`.
    """
    notes: list[str] = []
    statuses = [c.status for v in verdicts for c in v.applicable_criteria]
    if readiness == 0 and any(s in ("done", "partial") for s in statuses):
        notes.append(
            "Готовность проекта заявлена как 0%, хотя часть результатов отмечена как "
            "сделанные или в работе — цифра расходится с оценкой этапов"
        )
    if readiness >= 80 and "blocked" in statuses:
        notes.append(
            f"Готовность заявлена как {readiness}% при наличии блокирующих факторов — "
            "проверьте, что блокер действительно не мешает запуску"
        )
    return notes


def find_unclaimed_paths(
    extraction: Extraction, verdicts: list[ItemVerdict], limit: int = 20
) -> list[UnclaimedGroup]:
    """Файлы-кандидаты, не процитированные ни одной подтверждённой evidence."""
    claimed = {
        e.path for v in verdicts for e in v.evidence if e.verified and e.path
    }
    candidate_paths = sorted({f.path for f in extraction.facts if f.path})
    unclaimed = [p for p in candidate_paths if p not in claimed]

    groups: dict[str, list[str]] = {}
    for path in unclaimed:
        segments = path.split("/")
        key = "/".join(segments[:2]) if len(segments) > 1 else segments[0]
        groups.setdefault(key, []).append(path)

    ranked = sorted(groups.items(), key=lambda kv: -len(kv[1]))[:limit]
    return [
        UnclaimedGroup(group=key, example_paths=paths[:3], file_count=len(paths))
        for key, paths in ranked
    ]


@dataclass
class _SessionOutcome:
    """Итог одной сессии агента — то, что `run_agent` превращает в `AgentResult`."""

    items: list[PlanItem] = field(default_factory=list)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    plan: list[PlanItem] = field(default_factory=list)
    summary: ProjectSummary | None = None
    summary_source: str = "none"
    readiness: int = 0
    context: dict[str, str] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)


def _run_session(
    user_brief: str,
    known_slides: set[int],
    tree: Tree,
    chat_client: ChatClient,
    max_steps: int,
    max_tokens: int,
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None,
    on_plan: Callable[[list[PlanItem]], None] | None = None,
    on_summary: Callable[[ProjectSummary], None] | None = None,
    extraction: Extraction | None = None,
    user_stages: list[str] | None = None,
) -> _SessionOutcome:
    """Фаза 1: `submit_plan` → Фаза 2: `submit_stage` по каждому этапу →
    Фаза 3: `submit_summary` (вердикт) → `finish`."""
    user_stages = list(user_stages or [])
    tools = ToolBox(tree, extraction=extraction)
    system_prompt, missing_parts = load_system_prompt()
    programme = tools.lookup_ai_efficiency(user_brief, limit=2)
    if programme.meta.get("count"):
        user_brief += (
            "\n\nРелевантный контекст программы для формулирования клиентского пути:\n"
            + programme.content
        )
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_brief},
    ]
    notes: list[str] = []
    if missing_parts:
        notes.append(
            "Части системного промпта не найдены и в анализ не попали: "
            + ", ".join(missing_parts)
        )
    recent_calls: list[tuple[tuple[str, str], ...]] = []
    malformed = 0
    items_by_id: dict[str, PlanItem] = {}
    verdicts_by_id: dict[str, ItemVerdict] = {}
    plan_items: list[PlanItem] = []
    plan_by_id: dict[str, PlanItem] = {}
    context: dict[str, str] = {}
    readiness = 0
    plan_accepted = False
    summary: ProjectSummary | None = None
    summary_source = "none"
    finished = False
    steps_done = 0

    with trace_span("agent_session") as session_handle:
        for step in range(1, max(1, max_steps) + 1):
            steps_done = step
            with trace_span("agent.step", step=step) as step_span:
                try:
                    result = chat_client.chat(messages, tools=_SESSION_TOOL_SCHEMAS, max_tokens=max_tokens)
                except LlmError as exc:
                    step_span.set_attribute("error", exc.message)
                    notes.append(f"агент недоступен на шаге {step}: {exc.message}")
                    break

                step_span.set_attribute("from_cache", result.from_cache)
                step_span.set_attribute("text_chars", len(result.text or ""))
                step_span.set_attribute("reasoning_chars", len(result.reasoning_content or ""))
                if result.tool_calls:
                    names = ",".join(
                        str((c.get("function") or {}).get("name") or "")
                        for c in result.tool_calls
                    )
                    step_span.set_attribute("tool_calls", names)
                    step_span.set_attribute("tool_call_count", len(result.tool_calls))
                else:
                    step_span.set_attribute("tool_calls", "")
                    step_span.set_attribute("tool_call_count", 0)
                if result.usage:
                    step_span.set_attribute("total_tokens", result.usage.get("total_tokens", 0))

            if not result.tool_calls:
                malformed += 1
                if malformed >= _MAX_MALFORMED:
                    notes.append(f"агент не вызвал инструмент {malformed} раз подряд — остановлено")
                    break
                messages.append({"role": "assistant", "content": result.text})
                messages.append({
                    "role": "user",
                    "content": "Нужно вызвать инструмент — сначала submit_plan (клиент, "
                               "«было → стало», этапы пути и краткие бизнес-возможности), затем "
                               "по каждому этапу submit_stage, потом submit_summary "
                               "(решение, готовность, обоснование, риски, действия) и finish.",
                })
                continue
            malformed = 0

            signature = tuple(sorted(
                (str((c.get("function") or {}).get("name") or ""),
                 str((c.get("function") or {}).get("arguments") or ""))
                for c in result.tool_calls
            ))
            recent_calls.append(signature)
            if len(recent_calls) >= _REPEAT_STOP and len(set(recent_calls[-_REPEAT_STOP:])) == 1:
                notes.append(f"остановлено — {_REPEAT_STOP} одинаковых вызова подряд")
                break

            messages.append({
                "role": "assistant",
                "content": result.text or None,
                "tool_calls": result.tool_calls,
                # reasoning_content нужен человеку и трейсам, не самому агенту:
                # многие эндпоинты не принимают это поле в запросе.
                "reasoning_content": result.reasoning_content or None,
            })

            for call in result.tool_calls:
                function = call.get("function") or {}
                name = str(function.get("name") or "")
                raw_args = function.get("arguments") or "{}"
                call_id = str(call.get("id") or "")
                try:
                    args = json.loads(raw_args)
                except json.JSONDecodeError:
                    messages.append({
                        "role": "tool", "tool_call_id": call_id,
                        "content": f"аргументы инструмента не являются валидным JSON: {raw_args!r}",
                    })
                    continue
                args = args if isinstance(args, dict) else {}

                if name == "submit_plan":
                    plan, plan_context, error = _accept_plan(
                        args, known_slides, user_stages=user_stages,
                        enforce_language=True,
                    )
                    if error:
                        tool_content = f"путь отклонён: {error}"
                    else:
                        plan_items = plan
                        context = plan_context
                        plan_accepted = True
                        plan_by_id = {p.id: p for p in plan}
                        if on_plan is not None:
                            on_plan(plan)
                        bullets = sum(len(p.criteria) for p in plan)
                        tool_content = (
                            f"путь принят: {len(plan)} этапов, {bullets} буллитов. Теперь по "
                            "каждому этапу собери факты инструментами и вызови submit_stage. "
                            "Тексты уже сохранены — присылай только применимость и статусы "
                            "по позициям."
                        )
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": tool_content})
                    continue

                if name == "submit_stage":
                    if not plan_accepted:
                        messages.append({
                            "role": "tool", "tool_call_id": call_id,
                            "content": "сначала вызови submit_plan (клиент, «было → стало» и все "
                                       "этапы пути с буллитами), затем submit_stage по каждому этапу",
                        })
                        continue
                    item_id = str(args.get("item_id") or "").strip()
                    if not item_id or item_id not in plan_by_id:
                        messages.append({
                            "role": "tool", "tool_call_id": call_id,
                            "content": f"оценка отклонена: item_id {item_id!r} не найден в пути",
                        })
                        continue
                    item = plan_by_id[item_id]
                    verdict, error = _accept_stage(item, args, tree)
                    if error:
                        tool_content = f"оценка отклонена: {error}"
                    else:
                        items_by_id[item_id] = item
                        verdicts_by_id[item_id] = verdict
                        tool_content = "оценка принята. Переходи к следующему этапу пути."
                        if on_verdict is not None:
                            on_verdict(item, verdict)
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": tool_content})
                    continue

                if name == "submit_summary":
                    parsed, parsed_readiness, error = _accept_summary(
                        args, set(items_by_id), verdicts_by_id,
                        enforce_language=True,
                    )
                    if error:
                        tool_content = f"вердикт отклонён: {error}"
                    else:
                        summary = parsed
                        readiness = parsed_readiness
                        summary_source = "llm"
                        if on_summary is not None:
                            on_summary(parsed)
                        tool_content = "вердикт принят. Теперь вызови finish."
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": tool_content})
                    continue

                if name == "finish":
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": "сессия завершена"})
                    finished = True
                    continue

                outcome = tools.call(name, args)
                messages.append({"role": "tool", "tool_call_id": call_id, "content": outcome.content})

            if finished:
                break
        else:
            notes.append(f"бюджет шагов исчерпан ({max_steps})")

        session_handle.set_attribute("steps_done", steps_done)
        session_handle.set_attribute("plan_items", len(plan_items))
        session_handle.set_attribute("verdicts", len(verdicts_by_id))
        session_handle.set_attribute("summary_source", summary_source)
        session_handle.set_attribute("finished", finished)

    if not verdicts_by_id:
        notes.append("Этапы не оценены (submit_stage не вызывался)")
    if not plan_accepted:
        notes.append("Клиентский путь не передан (submit_plan не вызывался) — оценки не принимались")
    if not summary:
        notes.append("Вердикт не сформирован (submit_summary не вызывался или отклонён)")
    unrated = [p.title for p in plan_items if p.id not in verdicts_by_id]
    if plan_accepted and unrated:
        notes.append("Этапы пути остались без оценки: " + ", ".join(unrated[:5]))
    return _SessionOutcome(
        items=list(items_by_id.values()), verdicts=list(verdicts_by_id.values()),
        plan=plan_items, summary=summary, summary_source=summary_source,
        readiness=readiness, context=context, notes=notes,
    )


# Лимиты управленческих текстов защищают дашборд от полотен. Превышение
# отклоняется до принятия плана, поэтому в интерфейс не попадает обрезанная
# посередине мысль.
_MAX_CONTEXT_WORDS = 20
_MAX_SUMMARY_LIST_ITEMS = 3
_MIN_SUMMARY_LIST_ITEMS = 2
_MAX_SUMMARY_ITEM_CHARS = 110
_MAX_CONCLUSION_SENTENCES = 2
_MAX_CONCLUSION_WORDS = 45

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


def _accept_stage(
    item: PlanItem, args: dict, tree: Tree
) -> tuple[ItemVerdict | None, str | None]:
    """Разобрать `submit_stage` в `ItemVerdict`.

    Единственная содержательная проверка — совпадение числа оценок с числом
    буллитов этапа. Она и держит инвариант «путь в отчёте равен пути в образе
    результата»: текста в вердикте нет, а раз длина сверяется, то ни выбросить
    буллит, ни добавить свой агент не может.
    """
    raw_criteria = args.get("criteria")
    if not isinstance(raw_criteria, list):
        return None, "criteria должен быть списком оценок по позициям буллитов этапа"
    expected = len(item.criteria)
    if len(raw_criteria) != expected:
        return None, (
            f"у этапа «{item.title}» {expected} буллитов, а прислано оценок: "
            f"{len(raw_criteria)}. Нужен ровно один элемент на буллет, в том же порядке — "
            "тексты переданы в submit_plan и здесь не повторяются."
        )

    criteria: list[CriterionVerdict] = []
    for index, raw in enumerate(raw_criteria, start=1):
        raw = raw if isinstance(raw, dict) else {}
        applicable = bool(raw.get("applicable"))
        status = str(raw.get("status") or "").strip().lower()
        if applicable and status not in CRITERION_STATUSES:
            return None, (
                f"буллит {index} отмечен как относящийся к инициативе, но его статус "
                f"{status!r} неизвестен (допустимы: {', '.join(CRITERION_STATUSES)})"
            )
        criteria.append(CriterionVerdict(
            applicable=applicable,
            status=status if applicable else "",
            evidence=_parse_evidence(raw.get("evidence"), tree) if applicable else [],
        ))

    return ItemVerdict(
        item_id=item.id,
        applicable=bool(args.get("applicable")),
        criteria=criteria,
    ), None


def _parse_evidence(raw: object, tree: Tree) -> list[EvidenceRef]:
    """Разобрать список evidence-ссылок и проверить каждую `verify_evidence`."""
    evidence: list[EvidenceRef] = []
    if not isinstance(raw, list):
        return evidence
    for raw_ev in raw:
        if not isinstance(raw_ev, dict):
            continue
        path = str(raw_ev.get("path") or "").strip()
        basis = str(raw_ev.get("basis") or "").strip()
        try:
            line = int(raw_ev["line"]) if raw_ev.get("line") is not None else None
        except (TypeError, ValueError):
            line = None
        if not path:
            continue
        result = verify_evidence(path, line, basis, tree)
        evidence.append(EvidenceRef(
            path=result.path, line=result.line, basis=basis,
            verified=result.ok, reason=result.reason,
        ))
    return evidence


def _accept_summary(
    args: dict,
    plan_ids: set[str],
    verdicts_by_id: dict[str, ItemVerdict],
    enforce_language: bool = True,
) -> tuple[ProjectSummary | None, int, str | None]:
    """Разобрать `submit_summary` — вердикт, готовность и тексты для правления.

    Готовность приходит от модели и кодом не пересчитывается: критичность
    отдельного разрыва среднее арифметическое не выражает. Код только зажимает
    её в 0..100 и, если она спорит с оценками этапов, называет расхождение в
    `gaps` (`_readiness_notes`) — не исправляет молча.
    """
    decision = str(args.get("decision") or "").strip().upper().replace("NO-GO", "NO GO")
    if decision not in DECISIONS:
        return None, 0, f"неизвестное решение: {decision!r} (допустимы: {', '.join(DECISIONS)})"

    try:
        readiness = int(args.get("readiness"))
    except (TypeError, ValueError):
        return None, 0, "готовность (readiness) должна быть целым числом 0-100"
    readiness = max(0, min(100, readiness))

    conclusion = " ".join(str(args.get("conclusion") or "").split())
    if not conclusion:
        return None, 0, "пустое обоснование решения (conclusion)"

    risks = _parse_string_list(args.get("risks"))
    priorities = _parse_string_list(args.get("priorities"))
    for label, values in (("risks", risks), ("priorities", priorities)):
        if len(values) < _MIN_SUMMARY_LIST_ITEMS:
            return None, 0, (f"{label}: нужно минимум {_MIN_SUMMARY_LIST_ITEMS} пункта, "
                             f"прислано {len(values)}")

    verified_paths = {
        e.path for v in verdicts_by_id.values() for e in v.evidence if e.verified
    }
    for label, text in _summary_texts(conclusion, risks, priorities):
        violations = check_summary_text(text, plan_ids=plan_ids, verified_paths=verified_paths)
        if enforce_language:
            violations = violations + check_business_language(text)
        if violations:
            reasons = "; ".join(v.render() for v in violations)
            return None, 0, f"сторож отклонил поле {label}: {reasons}"

    if enforce_language:
        echoed = [
            text for _, text in _summary_texts("", risks, priorities)
            if is_restatement(text, conclusion)
        ]
        if echoed:
            return None, 0, (
                f"пункт «{echoed[0]}» пересказывает обоснование решения. Обоснование — "
                "связная мысль о том, почему выбрано это решение; риски и действия — "
                "отдельные конкретные пункты, а не его нарезка."
            )

    return ProjectSummary(
        decision=decision,
        conclusion=_lead_sentences(conclusion),
        risks=[_short_phrase(r) for r in risks[:_MAX_SUMMARY_LIST_ITEMS]],
        priorities=[_short_phrase(p) for p in priorities[:_MAX_SUMMARY_LIST_ITEMS]],
    ), readiness, None


def _lead_sentences(text: str) -> str:
    """Первые предложения обоснования в пределах лимитов по фразам и словам."""
    parts = [p for p in _SENTENCE_SPLIT.split(text.strip()) if p]
    kept: list[str] = []
    words = 0
    for sentence in parts[:_MAX_CONCLUSION_SENTENCES]:
        count = len(sentence.split())
        if kept and words + count > _MAX_CONCLUSION_WORDS:
            break
        kept.append(sentence)
        words += count
    if not kept:
        return ""
    return " ".join(" ".join(kept).split()[:_MAX_CONCLUSION_WORDS])


def _short_phrase(text: str) -> str:
    """Пункт списка в пределах `_MAX_SUMMARY_ITEM_CHARS`, обрезанный по слову."""
    text = " ".join(text.split())
    if len(text) <= _MAX_SUMMARY_ITEM_CHARS:
        return text
    cut = text[:_MAX_SUMMARY_ITEM_CHARS].rsplit(" ", 1)[0].rstrip(" ,;:—-")
    return f"{cut}…"


def _parse_string_list(raw: object) -> list[str]:
    if not isinstance(raw, list):
        return []
    return [" ".join(str(item).split()) for item in raw if str(item).strip()]


def _summary_texts(conclusion: str, risks: list[str], priorities: list[str]):
    if conclusion:
        yield "conclusion", conclusion
    for i, r in enumerate(risks):
        yield f"risks[{i}]", r
    for i, p in enumerate(priorities):
        yield f"priorities[{i}]", p


def _validate_plan_item(
    raw: object, known_slides: set[int], index: int, user_stage: str | None = None
) -> PlanItem | None:
    """Один этап пути из `submit_plan`: структура и жёсткие лимиты дашборда."""
    if not isinstance(raw, dict):
        return None
    title = " ".join(str(raw.get("title") or "").split())
    if not title or len(title) > MAX_STAGE_TITLE_CHARS:
        return None
    raw_criteria = raw.get("criteria")
    criteria = [
        " ".join(str(c).split())
        for c in (raw_criteria if isinstance(raw_criteria, list) else [])
        if str(c).strip()
    ]
    item_id = str(raw.get("item_id") or "").strip()
    description = " ".join(str(raw.get("description") or "").split())
    if not description or len(description) > MAX_STAGE_DESCRIPTION_CHARS:
        return None
    if not MIN_CAPABILITIES_PER_STAGE <= len(criteria) <= MAX_CAPABILITIES_PER_STAGE:
        return None
    if any(len(text) > MAX_CAPABILITY_CHARS for text in criteria):
        return None

    if user_stage is not None:
        if not _same_title(title, user_stage):
            return None
        return PlanItem(id=item_id or f"stage-{index}", title=user_stage,
                        description=description, criteria=criteria,
                        source_slide=0, origin="user")

    try:
        source_slide = int(raw.get("source_slide"))
    except (TypeError, ValueError):
        return None
    if source_slide != 0 and source_slide not in known_slides:
        return None
    return PlanItem(id=item_id or f"stage-{index}", title=title,
                    description=description, criteria=criteria,
                    source_slide=source_slide, origin="materials")


def _stage_listing(titles: list[str]) -> str:
    return "; ".join(f"{i}) {t}" for i, t in enumerate(titles, 1))


def _accept_plan(
    args: dict, known_slides: set[int], user_stages: list[str] | None = None,
    enforce_language: bool = True,
) -> tuple[list[PlanItem], dict[str, str], str | None]:
    """Разобрать `submit_plan` в список `PlanItem` и контекст проекта.

    Один битый пункт валит весь путь — агенту проще переслать список целиком,
    чем чинить его по одной ошибке за раз.

    Языковой сторож проверяет все видимые тексты, включая этапы и буллиты.
    """
    user_stages = list(user_stages or [])
    raw_items = args.get("items")
    if not isinstance(raw_items, list) or not raw_items:
        return [], {}, "путь пуст: передайте непустой список items"
    if user_stages and len(raw_items) != len(user_stages):
        return [], {}, (
            f"этапы заданы заказчиком: их {len(user_stages)}, а в пути {len(raw_items)}. "
            "Верните ровно эти этапы, в этом порядке: " + _stage_listing(user_stages)
        )

    plan: list[PlanItem] = []
    seen: set[str] = set()
    for i, raw in enumerate(raw_items, start=1):
        expected = user_stages[i - 1] if user_stages else None
        item = _validate_plan_item(raw, known_slides, i, user_stage=expected)
        if item is None:
            if expected is not None:
                return [], {}, (f"этап {i}: ожидался «{expected}» — заказчик задал этапы, их "
                                "нельзя переименовывать и переставлять. Порядок: "
                                + _stage_listing(user_stages))
            return [], {}, (
                f"этап {i}: нужны краткие title/description, от "
                f"{MIN_CAPABILITIES_PER_STAGE} до "
                f"{MAX_CAPABILITIES_PER_STAGE} буллитов не длиннее "
                f"{MAX_CAPABILITY_CHARS} символов и реальный source_slide либо 0"
            )
        if item.id in seen:
            item = replace(item, id=f"{item.id}-{i}")
        seen.add(item.id)
        plan.append(item)

    context = {
        "client_path_name": " ".join(str(args.get("client_path_name") or "").split()),
        "project_name": " ".join(str(args.get("project_name") or "").split()),
        "client": _trim_words(str(args.get("client") or "")),
        "before": _trim_words(str(args.get("before") or "")),
        "after": _trim_words(str(args.get("after") or "")),
    }
    if not context["client_path_name"] or len(context["client_path_name"]) > MAX_CLIENT_PATH_NAME_CHARS:
        return [], {}, (
            f"client_path_name должен называть задачу клиента и быть не длиннее "
            f"{MAX_CLIENT_PATH_NAME_CHARS} символов"
        )
    if enforce_language:
        for label in ("client_path_name", "client", "before", "after"):
            text = context[label]
            if not text:
                continue
            bad = check_business_language(text)
            if bad:
                return [], {}, (f"{label} — " + "; ".join(v.render() for v in bad)
                                + ". Опишите это словами клиента, а не устройством системы.")
        for item_index, item in enumerate(plan, start=1):
            visible = [
                ("title", item.title),
                ("description", item.description),
                *((f"criteria[{i}]", text) for i, text in enumerate(item.criteria)),
            ]
            for field_name, text in visible:
                if not text:
                    continue
                bad = check_business_language(text)
                if bad:
                    return [], {}, (
                        f"этап {item_index}, {field_name} — "
                        + "; ".join(v.render() for v in bad)
                        + ". Сформулируйте бизнес-возможность через изменение для клиента "
                          "или процесса."
                    )
    return plan, context, None


def _trim_words(text: str, limit: int = _MAX_CONTEXT_WORDS) -> str:
    return " ".join(text.split()[:limit])

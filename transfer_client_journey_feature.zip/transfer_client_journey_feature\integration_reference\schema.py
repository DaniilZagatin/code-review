"""Модель одного прогона: бизнес-представление клиентского пути и оценка его
этапов по материалам проекта.

Названия этапов, их описания и буллиты модель формулирует по образу результата,
компактному справочнику программы и материалам проекта. Они живут в
`PlanItem`; вердикт (`ItemVerdict`) добавляет к ним только две вещи:
относится ли пункт к рассматриваемой инициативе и в каком он состоянии. Текст
и оценка разведены по разным объектам, поэтому переформулировать буллет
физически нечем: в вердикте для текста просто нет поля.

Видимый текст описывает изменение для клиента и процесса, а технические
доказательства остаются в служебных полях оценки.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# Состояние буллита. Совпадает со словарём шаблона дашборда: он же задаёт вес
# в расчёте готовности этапа (done — 1, partial — 0.5, planned/blocked — 0).
# `blocked` — не «хуже, чем planned», а другое: не просто «ещё не сделано», а
# «отсутствие этого результата блокирует следующий шаг».
CRITERION_STATUSES = ("done", "partial", "planned", "blocked")
CRITERION_WEIGHT = {"done": 1.0, "partial": 0.5, "planned": 0.0, "blocked": 0.0}

# Вердикт по проекту целиком. Формулировки — из описания дашборда: GO —
# продолжать, PIVOT — существенно скорректировать, NO GO — в текущем виде не
# обосновано.
DECISIONS = ("GO", "PIVOT", "NO GO")

# Откуда взято название этапа: сформулировано по материалам либо задано
# пользователем вручную. Содержание этапа в обоих случаях пишет агент.
PLAN_ORIGINS = ("materials", "user")


@dataclass(frozen=True)
class PlanItem:
    """Один этап клиентского пути в управленческой бизнес-формулировке.

    `criteria` — ключевые бизнес-возможности этапа. Они принимаются на фазе
    формирования пути и дальше не меняются: вердикт
    ссылается на них по позиции, а не пересылает текст заново.
    """

    id: str
    title: str
    description: str = ""
    criteria: list[str] = field(default_factory=list)
    source_slide: int = 0
    origin: str = "materials"

    def __post_init__(self) -> None:
        if self.origin not in PLAN_ORIGINS:
            raise ValueError(f"неизвестное происхождение этапа: {self.origin}")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "criteria": list(self.criteria),
            "source_slide": self.source_slide,
            "origin": self.origin,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "PlanItem":
        return PlanItem(
            id=d["id"],
            title=d["title"],
            description=d.get("description", ""),
            criteria=list(d.get("criteria") or []),
            source_slide=int(d.get("source_slide") or 0),
            origin=d.get("origin", "materials"),
        )


@dataclass(frozen=True)
class EvidenceRef:
    """Одна ссылка на материалы, подтверждающая состояние буллита.

    `verified=False` не отбрасывается — понижается и остаётся в модели с
    причиной: утверждение без доказательства не публикуется как «материалы
    показывают».
    """

    path: str
    line: int | None
    basis: str
    verified: bool
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path, "line": self.line, "basis": self.basis,
            "verified": self.verified, "reason": self.reason,
        }


@dataclass
class CriterionVerdict:
    """Оценка одного буллита этапа: относится ли он к инициативе и что с ним.

    Текста здесь нет намеренно — он берётся из `PlanItem.criteria` по той же
    позиции. Оценка не может переписать уже принятую бизнес-формулировку:
    длина списка сверяется с планом.

    `applicable=False` — буллит не про эту инициативу. Тогда `status`
    игнорируется, пункт показывается серым и не участвует в расчёте
    готовности этапа. Это не «плохо» и не «не сделано»: чужой пункт не должен
    ни портить, ни улучшать картину.
    """

    applicable: bool = False
    status: str = ""
    evidence: list[EvidenceRef] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.status and self.status not in CRITERION_STATUSES:
            raise ValueError(f"неизвестный статус буллита: {self.status}")

    @property
    def weight(self) -> float:
        return CRITERION_WEIGHT.get(self.status, 0.0)

    @property
    def verified_evidence(self) -> list[EvidenceRef]:
        return [e for e in self.evidence if e.verified]

    @property
    def is_grounded(self) -> bool:
        """Есть ли подтверждение у заявленного прогресса.

        Спрашивается только с `done`/`partial`/`blocked`: «запланировано» —
        это утверждение об отсутствии, подтверждать в материалах нечего.
        """
        if not self.applicable or self.status == "planned":
            return True
        return bool(self.verified_evidence)

    def to_dict(self) -> dict[str, Any]:
        return {
            "applicable": self.applicable,
            "status": self.status,
            "evidence": [e.to_dict() for e in self.evidence],
        }


@dataclass
class ItemVerdict:
    """Оценка одного этапа: применимость этапа и состояние его буллитов."""

    item_id: str
    applicable: bool = False
    criteria: list[CriterionVerdict] = field(default_factory=list)

    @property
    def applicable_criteria(self) -> list[CriterionVerdict]:
        return [c for c in self.criteria if c.applicable]

    def percent(self) -> int | None:
        """Готовность этапа: сумма весов применимых буллитов, 0..100.

        `None` — этап не относится к инициативе или в нём нет ни одного
        применимого буллита: тогда на дашборде он серый и в общую картину не
        входит. Формула повторяет расчёт шаблона дашборда — цифра в
        офлайн-отчёте и на веб-экране не может разойтись.
        """
        if not self.applicable:
            return None
        applicable = self.applicable_criteria
        if not applicable:
            return None
        return round(sum(c.weight for c in applicable) / len(applicable) * 100)

    @property
    def evidence(self) -> list[EvidenceRef]:
        return [e for c in self.criteria for e in c.evidence]

    @property
    def ungrounded_count(self) -> int:
        return sum(1 for c in self.criteria if not c.is_grounded)

    def to_dict(self) -> dict[str, Any]:
        return {
            "item_id": self.item_id,
            "applicable": self.applicable,
            "percent": self.percent(),
            "criteria": [c.to_dict() for c in self.criteria],
        }


@dataclass(frozen=True)
class UnclaimedGroup:
    """Группа файлов, не подтвердивших ни одного буллита плана.

    Не вердикт «сделано сверх плана» — только сырой кандидат для него.
    Детерминированная разница множеств, без суждения модели.
    """

    group: str
    example_paths: list[str]
    file_count: int

    def to_dict(self) -> dict[str, Any]:
        return {"group": self.group, "example_paths": self.example_paths,
                "file_count": self.file_count}


@dataclass(frozen=True)
class ProjectSummary:
    """Итог анализа: вердикт, его обоснование, риски и ближайшие действия.

    `conclusion` — не пересказ списков ниже, а ответ на вопрос «почему такое
    решение»: что подтверждено, что мешает и можно ли идти дальше.
    """

    decision: str = ""
    conclusion: str = ""
    risks: list[str] = field(default_factory=list)
    priorities: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {"decision": self.decision, "conclusion": self.conclusion,
                "risks": list(self.risks), "priorities": list(self.priorities)}


@dataclass
class ProgressModel:
    """Итоговая модель одного прогона.

    `readiness` (0..100) — самостоятельная оценка модели, а не среднее по
    этапам. Так задумано: критичность отдельного разрыва и доказательность
    материалов среднее арифметическое не выражает — проект с одним
    заблокированным этапом может быть ближе к нулю, чем к своим 60% по
    буллитам.
    """

    meta: dict[str, Any] = field(default_factory=dict)
    items: dict[str, PlanItem] = field(default_factory=dict)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    unclaimed: list[UnclaimedGroup] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    readiness: int = 0
    summary: ProjectSummary | None = None
    summary_source: str = "none"

    def criterion_counts(self) -> dict[str, int]:
        """Сколько применимых буллитов в каждом состоянии — по всему пути."""
        out = {status: 0 for status in CRITERION_STATUSES}
        for verdict in self.verdicts:
            for criterion in verdict.applicable_criteria:
                if criterion.status in out:
                    out[criterion.status] += 1
        return out

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "pko-progress-model/0.2",
            "meta": self.meta,
            "readiness": self.readiness,
            "criterion_counts": self.criterion_counts(),
            "items": {item_id: item.to_dict() for item_id, item in self.items.items()},
            "verdicts": [v.to_dict() for v in self.verdicts],
            "unclaimed": [u.to_dict() for u in self.unclaimed],
            "gaps": self.gaps,
            "summary": self.summary.to_dict() if self.summary else None,
            "summary_source": self.summary_source,
        }

    def to_json(self) -> str:
        import json

        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2, sort_keys=False)

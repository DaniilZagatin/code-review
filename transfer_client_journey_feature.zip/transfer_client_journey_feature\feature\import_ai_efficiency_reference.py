"""Build the compact AI-efficiency client-journey reference.

The source HTML is treated only as data: its embedded bundle is parsed, never
executed. Portfolio, staffing, dates, effects and programme statuses are not
copied into the runtime reference. The agent needs only the target client path,
its stages and business-capability bullets.
"""

from __future__ import annotations

import argparse
import html
import json
import re
from datetime import datetime
from pathlib import Path


def _bundled_template(path: Path) -> str:
    source = path.read_text(encoding="utf-8")
    match = re.search(
        r'<script\s+type="__bundler/template">\s*(.*?)\s*</script>',
        source,
        re.DOTALL,
    )
    if not match:
        raise RuntimeError("Bundled HTML template was not found")
    return json.loads(match.group(1))


def _plain(value: object) -> str:
    text = re.sub(r"<[^>]+>", "", str(value or ""))
    return " ".join(html.unescape(text).split())


def _aliases(inner: str) -> dict[str, list[str]]:
    marker = "const PATH2PAGES = "
    offset = inner.index(marker) + len(marker)
    end = inner.index(";", offset)
    source = re.sub(r",\s*([}\]])", r"\1", inner[offset:end])
    path_map = json.loads(source)
    aliases_by_page: dict[str, list[str]] = {}
    for alias, page_ids in path_map.items():
        for page_id in page_ids:
            key = str(page_id).split("#", 1)[0]
            aliases_by_page.setdefault(key, []).append(_plain(alias))
    return aliases_by_page


def _stage(stage: dict[str, object]) -> dict[str, object]:
    bullets = []
    for task in stage.get("tasks", []):
        if isinstance(task, dict):
            text = _plain(task.get("t"))
        else:
            text = _plain(task)
        if text:
            bullets.append(text)
    return {
        "name": _plain(stage.get("name")),
        "outcome": _plain(stage.get("target") or stage.get("merge")),
        "bullets": bullets,
    }


def _lookup_terms(data: dict[str, object]) -> list[str]:
    """Names and codes used only to find the journey; never shown to the LLM."""
    terms: list[str] = []
    for initiative in data.get("inits", []):
        if not isinstance(initiative, dict):
            continue
        for key in ("name", "short", "process"):
            value = _plain(initiative.get(key))
            if value:
                terms.append(value)
    for status in data.get("status", []):
        if isinstance(status, dict):
            value = _plain(status.get("n"))
            if value:
                terms.append(value)
    return list(dict.fromkeys(terms))


def _journeys(path: Path) -> list[dict[str, object]]:
    inner = _bundled_template(path)
    marker = "const PAGEDATA = "
    offset = inner.index(marker) + len(marker)
    payload, _ = json.JSONDecoder().raw_decode(inner[offset:])
    aliases_by_page = _aliases(inner)

    journeys: list[dict[str, object]] = []
    for page_id, page in payload.get("pages", {}).items():
        data = page.get("d", {})
        stages = [
            _stage(stage) for stage in data.get("stages", [])
            if isinstance(stage, dict) and _plain(stage.get("name"))
        ]
        journeys.append({
            "id": str(page_id),
            "label": _plain(page.get("label")),
            "aliases": aliases_by_page.get(str(page_id), []),
            "title": _plain(data.get("title")),
            "client": _plain(data.get("client")),
            "change": _plain(data.get("whychange") or data.get("target")),
            "stages": stages,
            # Indexing metadata keeps lookup by initiative name/process working,
            # but is deliberately omitted from the formatted model context.
            "lookup_terms": _lookup_terms(data),
        })
    return journeys


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("timeline_html", type=Path)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("backend/pko/progress/ai_efficiency_reference.json"),
    )
    parser.add_argument("--snapshot-date", default="")
    args = parser.parse_args()

    snapshot_date = args.snapshot_date or datetime.fromtimestamp(
        args.timeline_html.stat().st_mtime
    ).date().isoformat()
    result = {
        "schema": "pko-ai-efficiency-reference/1.1",
        "snapshot_date": snapshot_date,
        "source": {"timeline": args.timeline_html.name},
        "notice": (
            "The reference contains target client journeys and capabilities only. "
            "It helps formulate the analysis but does not prove implementation."
        ),
        "journeys": _journeys(args.timeline_html),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"Wrote {len(result['journeys'])} client paths to {args.output}")


if __name__ == "__main__":
    main()

"""Сторож текста отчёта.

Писатель (DeepSeek) получает только готовую модель и не видит кода, но проверять
его всё равно нужно: текст не должен вводить идентификаторы, счётчики и пути,
которых в модели нет. Нарушение не правится — текст целиком отбрасывается, и
отчёт собирается детерминированным шаблоном. Так «красивая» формулировка не может
подменить факт.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from pko.extractors.base import CODE_SUFFIXES, DATA_SUFFIXES

# Идентификаторы объектов управления: NEED-…, CP-…, AP-…, BBB-001, AO-010, GRD-003.
# Взгляд назад нужен, чтобы не выхватывать «NEED-001» из середины «CHK-NEED-001».
ID_PATTERN = re.compile(r"(?<![A-Za-z0-9\-])(?:NEED|CP|AP-CP|AP|BBB|AO|GRD)-[A-Za-z0-9\-]{2,}\b")
# Расширения берём из общего перечня, а не перечисляем заново: со списком
# `py|ts|tsx|yaml|yml|toml|json` сторож не видел путей чужих стеков, и
# выдуманный `ui/src/OrderForm.jsx` в тексте писателя проходил незамеченным —
# ровно на тех проектах, ради которых модель и делали универсальной.
_SUFFIXES = "|".join(s.lstrip(".") for s in CODE_SUFFIXES + DATA_SUFFIXES)
PATH_PATTERN = re.compile(rf"\b[\w./-]+\.(?:{_SUFFIXES})\b")
CHECK_ID_PATTERN = re.compile(r"\bCHK-[A-Z]+-\d+\b")


@dataclass(frozen=True)
class GuardViolation:
    code: str
    detail: str

    def render(self) -> str:
        return f"{self.code}: {self.detail}"


def check_text(text: str, allowed_ids: set[str], allowed_paths: set[str] | None = None
               ) -> list[GuardViolation]:
    """Вернуть нарушения. Пустой список — текст можно публиковать."""
    violations: list[GuardViolation] = []
    allowed_paths = allowed_paths or set()

    unknown_ids = sorted(
        {m for m in ID_PATTERN.findall(text) if m not in allowed_ids and not _is_check_id(m)}
    )
    if unknown_ids:
        violations.append(
            GuardViolation(
                "UNKNOWN_ID",
                "в тексте есть идентификаторы, которых нет в модели: " + ", ".join(unknown_ids[:5]),
            )
        )

    unknown_paths = sorted({p for p in PATH_PATTERN.findall(text) if p not in allowed_paths})
    if unknown_paths:
        violations.append(
            GuardViolation(
                "UNKNOWN_PATH",
                "в тексте есть пути к файлам, не подтверждённые доказательствами: "
                + ", ".join(unknown_paths[:5]),
            )
        )
    return violations


def _is_check_id(value: str) -> bool:
    return bool(CHECK_ID_PATTERN.fullmatch(value))


def check_explanation(text: str, tree_files: set[str]) -> list[GuardViolation]:
    """Проверить свободный текст объяснения вердикта.

    Инвариант: агент может упоминать только пути, которые реально существуют в
    репозитории. ID-схема (`NEED-`/`BBB-`/…) здесь не применима — `ID_PATTERN`
    заточен под объекты Gate, а не под `item_id` пунктов плана, поэтому
    `allowed_ids` пуст: любой ID в explanation — нарушение.
    """
    return check_text(text, allowed_ids=set(), allowed_paths=tree_files)


def check_summary_text(
    text: str, plan_ids: set[str], verified_paths: set[str]
) -> list[GuardViolation]:
    """Проверить текст сводного вывода по проекту.

    Инвариант строже, чем у explanation: агент может ссылаться только на id
    пунктов плана и пути из подтверждённой evidence, а не на любые файлы
    репозитория. Нарушение в любом поле отклоняет вывод целиком.
    """
    return check_text(text, allowed_ids=plan_ids, allowed_paths=verified_paths)


# Лексический сторож бизнес-языка. Сторож путей (`check_explanation`) ловит
# только имена файлов — «Не реализована интеграция скоринга» проходил его
# насквозь, потому что путей в тексте нет. А это ровно тот язык, который
# отчёту противопоказан: он описывает устройство системы, а не то, что бизнес
# и клиент могут делать.
#
# Список намеренно узкий и состоит только из однозначно технических слов.
# Двусмысленные («сервис», «функция», «класс», «таблица», «интерфейс»,
# «покрытие») сюда не входят: в банковском тексте у них есть законное
# бизнес-значение («класс обслуживания», «страховое покрытие»), и отклонять
# из-за них — значит гонять модель по кругу. Полный, более широкий стоп-лист
# живёт в `progress/business_language.md` и работает как правило в промпте;
# здесь — только то, за что можно отклонить вызов, не рискуя ложной
# сработкой. Список правится одной строкой — это точка настройки.
_TECH_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"эндпо[иy]нт|endpoint", "эндпоинт"),
    (r"\bapi\b|\bsdk\b|\bhttp\b|\bhttps\b|\bjson\b|\bxml\b|\bsql\b|\bcrud\b", "технический протокол/формат"),
    (r"б[эе]кенд|backend|фронт[еэ]нд|frontend|микросервис", "слой системы"),
    (r"репозитор|коммит|\bgit\b|рефактор|деплой|легаси|legacy|хардкод", "разработка"),
    (r"пайплайн|pipeline|\bci/?cd\b|вебхук|webhook|конфиг|скрипт|парсер|парсинг|к[эе]ш\w*", "инфраструктура"),
    (r"библиотек|фреймворк|модул[ьяеию]", "компонент реализации"),
    (r"баз[аеуы]\s+данных|\bбд\b|логирован", "хранение и журналы"),
    (r"\bтест\w*|покрыти[ея]\s+(?:кода|тестами)|юнит-?тест", "тестирование"),
    (r"(?:в|по|из)\s+код[еу]\b|исходн\w+\s+код|код\s+проекта", "упоминание кода"),
    (r"реализован\w*|разработан\w*|добавлен\w*|настроен\w*|имплемент\w*|запрограммирован\w*", "язык выполненных работ, а не доступного результата"),
    (r"интеграци\w*", "интеграция — скажите, что происходит для бизнеса"),
)

_TECH_RE = tuple((re.compile(p, re.IGNORECASE), label) for p, label in _TECH_PATTERNS)

def check_business_language(text: str) -> list[GuardViolation]:
    """Вернуть нарушения бизнес-языка: техническая лексика в смысловом тексте.

    Пустой список — текст можно публиковать. Дополняет `check_explanation`
    (пути к файлам), не заменяет его: там — выдуманные факты, здесь — язык.
    """
    hits: list[str] = []
    for pattern, label in _TECH_RE:
        found = pattern.search(text)
        if found:
            hits.append(f"{found.group(0)} ({label})")
    if not hits:
        return []
    return [
        GuardViolation(
            "TECH_LANGUAGE",
            "технические слова вместо бизнес-формулировки: " + ", ".join(hits[:5]),
        )
    ]
# Служебные слова, которые совпадают в любых двух русских фразах и потому
# ничего не говорят о пересказе.
_STOPWORDS = frozenset({
    "быть", "если", "или", "него", "неё", "этом", "этот", "эта", "того", "тому",
    "такой", "такое", "также", "чтобы", "когда", "пока", "ещё", "уже", "весь",
    "всех", "всей", "всё", "может", "можно", "нужно", "надо", "есть", "нет",
    "только", "очень", "более", "менее",
})

# Длина префикса для сравнения слов. Русская морфология даёт «клиента» /
# «клиенту» / «клиентом» — точное совпадение их не поймает, а полноценная
# лемматизация ради одной проверки не нужна. Пять символов различают разные
# корни и склеивают формы одного слова.
_STEM = 5
_RESTATEMENT_MIN_WORDS = 3
_RESTATEMENT_THRESHOLD = 0.7

_WORD_RE = re.compile(r"[а-яёa-z]+", re.IGNORECASE)


def _stems(text: str) -> set[str]:
    """Основы значимых слов текста — то, по чему сравниваются две фразы."""
    return {
        word.lower()[:_STEM]
        for word in _WORD_RE.findall(text)
        if len(word) >= 4 and word.lower() not in _STOPWORDS
    }


def is_restatement(text: str, of: str) -> bool:
    """Пересказывает ли `text` фразу `of` вместо того, чтобы что-то добавить.

    Комментарий под буллетом существует ради того, чего в самом буллете нет:
    где проходит граница, что происходит вместо обещанного, чего это стоит.
    Комментарий, целиком собранный из слов тезиса, не сообщает читателю
    ничего — он только занимает место и заставляет кликать впустую.

    Порог высокий (70% основ комментария должны найтись в тезисе) и работает
    только на фразах от трёх значимых слов: пара общих существительных —
    нормально и даже неизбежно, речь идёт об одной и той же возможности.
    """
    words = _stems(text)
    if len(words) < _RESTATEMENT_MIN_WORDS:
        return False
    base = _stems(of)
    if not base:
        return False
    return len(words & base) / len(words) >= _RESTATEMENT_THRESHOLD

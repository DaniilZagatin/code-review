"""Embedded compact AI-efficiency client-path lookup."""

import unittest

from pko.progress.program_reference import (
    format_matches,
    load_reference,
    search_reference,
)


class ProgrammeReferenceTest(unittest.TestCase):
    def test_snapshot_contains_only_compact_client_paths(self):
        reference = load_reference()
        self.assertEqual(reference["schema"], "pko-ai-efficiency-reference/1.1")
        self.assertEqual(reference["snapshot_date"], "2026-09-03")
        self.assertEqual(len(reference["journeys"]), 25)
        self.assertNotIn("portfolio", reference)
        self.assertEqual(
            set(reference["journeys"][0]),
            {"id", "label", "aliases", "title", "client", "change", "stages", "lookup_terms"},
        )
        self.assertEqual(
            set(reference["journeys"][0]["stages"][0]),
            {"name", "outcome", "bullets"},
        )

    def test_finds_initiative_by_name(self):
        matches = search_reference("GigaSo", limit=3)
        self.assertTrue(matches)
        self.assertEqual(matches[0].kind, "journey")
        self.assertTrue(any("GigaSo" in term for term in matches[0].data["lookup_terms"]))

    def test_finds_journey_by_process_code(self):
        matches = search_reference("П3385", limit=1)
        self.assertEqual(len(matches), 1)
        self.assertTrue(any("П3385" in term for term in matches[0].data["lookup_terms"]))

    def test_finds_client_path(self):
        matches = search_reference("Работа с проблемной задолженностью ЮЛ", limit=5)
        journey_ids = [match.data.get("id") for match in matches if match.kind == "journey"]
        self.assertIn("drpa_ul", journey_ids)

    def test_unknown_query_does_not_invent_match(self):
        self.assertEqual(search_reference("совершенно неизвестный проект xyz987"), [])

    def test_formatted_result_contains_only_journey_and_capabilities(self):
        text = format_matches(search_reference("GigaSo", limit=1))
        self.assertIn("КЛИЕНТСКИЙ ПУТЬ", text)
        self.assertIn("Этап:", text)
        self.assertIn("• ", text)
        self.assertIn("не как доказательство реализации", text)
        self.assertNotIn("Плановые вехи", text)
        self.assertNotIn("Ресурс и идентификаторы", text)
        self.assertNotIn("Заявленный эффект", text)


if __name__ == "__main__":
    unittest.main()

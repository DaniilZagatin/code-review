"""Search the compact AI-efficiency client-journey reference.

Only the closest paths are added to a session. The full reference is never
placed in the prompt, and lookup-only initiative names/codes are not shown to
the model after a match is found.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from functools import lru_cache
from pathlib import Path
from typing import Any


REFERENCE_PATH = Path(__file__).with_name("ai_efficiency_reference.json")
MAX_RESULTS = 5
MAX_OUTPUT_CHARS = 7_000
_TOKEN_RE = re.compile(r"[a-zа-яё0-9]+", re.IGNORECASE)
_CODE_RE = re.compile(r"(?:аг|п|crossgoal)[-\s]?\d+", re.IGNORECASE)
_STOPWORDS = {
    "ai", "ии", "агент", "агента", "агенты", "инициатива", "инициативы",
    "автономный", "автономная", "система", "сервис", "для", "the", "and",
}


@dataclass(frozen=True)
class ReferenceMatch:
    kind: str
    score: float
    data: dict[str, Any]


def _normalize(value: object) -> str:
    text = str(value or "").casefold().replace("ё", "е")
    return " ".join(_TOKEN_RE.findall(text))


def _tokens(value: object) -> set[str]:
    return {
        token for token in _normalize(value).split()
        if len(token) >= 2 and token not in _STOPWORDS
    }


def _flatten_strings(value: object) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        return [part for item in value.values() for part in _flatten_strings(item)]
    if isinstance(value, list):
        return [part for item in value for part in _flatten_strings(item)]
    return []


@lru_cache(maxsize=1)
def load_reference(path: Path = REFERENCE_PATH) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _search_text(row: dict[str, Any]) -> str:
    fields = [
        row.get("label"), row.get("aliases"), row.get("title"),
        row.get("client"), row.get("change"), row.get("stages"),
        row.get("lookup_terms"),
    ]
    return " ".join(_flatten_strings(fields))


def _primary_names(row: dict[str, Any]) -> list[str]:
    return [
        str(row.get("label") or ""), str(row.get("title") or ""),
        *[str(alias) for alias in row.get("aliases", [])],
        *[str(term) for term in row.get("lookup_terms", [])],
    ]


def _score(query: str, text: str) -> float:
    query_norm = _normalize(query)
    text_norm = _normalize(text)
    if not query_norm or not text_norm:
        return 0.0
    overlap = _tokens(query) & _tokens(text)
    if not overlap:
        return 0.0
    coverage = len(overlap) / max(1, min(len(_tokens(query)), 12))
    precision = len(overlap) / max(1, min(len(_tokens(text)), 20))
    ratio = SequenceMatcher(None, query_norm[:500], text_norm[:1500]).ratio()
    substring = 0.25 if query_norm in text_norm else 0.0
    query_codes = {_normalize(code) for code in _CODE_RE.findall(query)}
    text_codes = {_normalize(code) for code in _CODE_RE.findall(text)}
    code_bonus = 0.8 if query_codes & text_codes else 0.0
    return coverage * 0.55 + precision * 0.10 + ratio * 0.20 + substring + code_bonus


def _row_score(query: str, row: dict[str, Any]) -> float:
    score = _score(query, _search_text(row))
    query_norm = _normalize(query)
    query_tokens = _tokens(query)
    for name in _primary_names(row):
        name_norm = _normalize(name)
        if not name_norm:
            continue
        if query_norm == name_norm:
            return score + 1.2
        if name_norm in query_norm or query_norm in name_norm:
            score += 0.35
            continue
        # В автоматическом поиске запросом служит весь текст образа результата.
        # Название инициативы там окружено десятками других слов и не является
        # подстрокой целиком, поэтому учитываем заметное пересечение с одним из
        # индексных названий отдельно.
        name_tokens = _tokens(name)
        overlap = query_tokens & name_tokens
        if overlap and len(overlap) / max(1, len(name_tokens)) >= 0.35:
            score += 0.45
        elif any(len(token) >= 6 for token in overlap):
            score += 0.30
    return score


def search_reference(query: str, limit: int = 3) -> list[ReferenceMatch]:
    matches = []
    for row in load_reference().get("journeys", []):
        score = _row_score(query, row)
        if score >= 0.24:
            matches.append(ReferenceMatch("journey", score, row))
    matches.sort(key=lambda match: match.score, reverse=True)
    return matches[:max(1, min(int(limit), MAX_RESULTS))]


def _clip(value: object, limit: int = 300) -> str:
    text = " ".join(str(value or "").split())
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def _format_journey(row: dict[str, Any]) -> str:
    lines = [
        f"КЛИЕНТСКИЙ ПУТЬ: {_clip(row.get('title') or row.get('label'))}",
        f"Клиент: {_clip(row.get('client'), 220)}",
        f"Изменение пути: {_clip(row.get('change'), 300)}",
    ]
    for stage in row.get("stages", []):
        name = _clip(stage.get("name"), 120)
        outcome = _clip(stage.get("outcome"), 220)
        lines.append(f"Этап: {name}" + (f" — {outcome}" if outcome else ""))
        for bullet in stage.get("bullets", []):
            lines.append(f"• {_clip(bullet, 240)}")
    return "\n".join(lines)


def format_matches(matches: list[ReferenceMatch]) -> str:
    if not matches:
        return (
            "Подходящего клиентского пути в справочнике AI-эффективности не найдено. "
            "Сформулируй путь по образу результата и материалам проекта."
        )
    reference = load_reference()
    blocks = [
        "ОПОРНЫЕ КЛИЕНТСКИЕ ПУТИ ПРОГРАММЫ AI-ЭФФЕКТИВНОСТЬ.",
        f"Срез на {reference.get('snapshot_date', 'неизвестную дату')}. Используй эти "
        "этапы и возможности как информацию для осмысленной бизнес-формулировки, "
        "а не как доказательство реализации и не как текст для механического копирования.",
    ]
    blocks.extend(_format_journey(match.data) for match in matches)
    return "\n\n".join(blocks)[:MAX_OUTPUT_CHARS]


def lookup_program_context(query: str, limit: int = 3) -> tuple[str, int]:
    matches = search_reference(query, limit=limit)
    return format_matches(matches), len(matches)

$ErrorActionPreference = 'Stop'
$composeFile = Join-Path $PSScriptRoot 'compose.yaml'
$configuredDir = if ($env:PKO_MONITOR_DIR) { $env:PKO_MONITOR_DIR } else {
    Join-Path ([Environment]::GetFolderPath('UserProfile')) '.pko\monitoring'
}
$env:PKO_MONITOR_DIR = [System.IO.Path]::GetFullPath($configuredDir).Replace('\', '/')
$podman = Get-Command podman -ErrorAction SilentlyContinue
if (-not $podman) {
    foreach ($candidate in @(
        'C:\Program Files\RedHat\Podman\podman.exe',
        'C:\Program Files\Podman\podman.exe'
    )) {
        if (Test-Path -LiteralPath $candidate) {
            $podman = @{ Source = $candidate }
            break
        }
    }
}
if (-not $podman) { throw 'Podman не найден.' }
& $podman.Source compose -f $composeFile down
if ($LASTEXITCODE -ne 0) { throw 'Не удалось остановить стек мониторинга.' }

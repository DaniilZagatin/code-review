$ErrorActionPreference = 'Stop'

$composeFile = Join-Path $PSScriptRoot 'compose.yaml'
$configuredDir = if ($env:PKO_MONITOR_DIR) { $env:PKO_MONITOR_DIR } else {
    Join-Path ([Environment]::GetFolderPath('UserProfile')) '.pko\monitoring'
}
$resolvedDir = [System.IO.Path]::GetFullPath($configuredDir)
[System.IO.Directory]::CreateDirectory($resolvedDir) | Out-Null
$env:PKO_MONITOR_DIR = $resolvedDir.Replace('\', '/')

$podman = Get-Command podman -ErrorAction SilentlyContinue
if (-not $podman) {
    foreach ($candidate in @(
        'C:\Program Files\RedHat\Podman\podman.exe',
        'C:\Program Files\Podman\podman.exe'
    )) {
        if (Test-Path -LiteralPath $candidate) {
            $podman = @{ Source = $candidate }
            break
        }
    }
}
if (-not $podman) {
    throw 'Podman не найден. Добавьте podman.exe в PATH или установите Podman Desktop.'
}
$exe = $podman.Source

& $exe info *> $null
if ($LASTEXITCODE -ne 0) {
    & $exe machine start
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось запустить podman machine.' }
}

& $exe compose version *> $null
if ($LASTEXITCODE -ne 0) {
    throw 'Для podman compose нужен compose provider (podman-compose или docker-compose).'
}

& $exe compose -f $composeFile up -d --build
if ($LASTEXITCODE -ne 0) { throw 'Стек мониторинга не запустился. Проверьте вывод podman compose.' }

Write-Host 'Grafana: http://localhost:3000/d/pko-cli-monitoring'
Write-Host "Журнал CLI: $resolvedDir"

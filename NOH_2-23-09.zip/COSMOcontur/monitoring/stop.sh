#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export PKO_MONITOR_DIR="${PKO_MONITOR_DIR:-$HOME/.pko/monitoring}"
podman compose -f "$script_dir/compose.yaml" down

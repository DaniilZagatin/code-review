"""Собрать каталог инициатив из папки с образами результата.

    python scripts/build_initiatives.py <папка с .md> [--out backend/pko/initiatives/catalog.json]

Колоды SteerCo обновляются, и каталог должен пересобираться командой, а не
правиться руками. В каталог кладётся только то, что нужно анализу: путь,
название инициативы, этапы, буллиты образа результата и дословный хвост из
колоды — он даёт агенту смысл, которого в телеграфных буллитах нет.

Разбор идёт тем же `parse_plan_text`, что и в бою: если файл каталога собрался,
значит инициатива точно разберётся и на прогоне.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from pko.progress.plan_input import parse_plan_text  # noqa: E402
from pko.progress.text_input import slug  # noqa: E402

SCHEMA = "pko-initiatives/1"


def build(source_dir: Path) -> dict:
    files = sorted(
        path for path in source_dir.rglob("*.md")
        # `._name` — служебные файлы macOS из архива, INDEX — оглавление.
        if not path.name.startswith("._") and path.name != "INDEX.md"
    )
    items: list[dict] = []
    failures: list[str] = []
    seen: set[str] = set()

    for path in files:
        text = path.read_text(encoding="utf-8")
        try:
            plan = parse_plan_text(text)
        except Exception as exc:  # noqa: BLE001 — причина уходит в отчёт сборки
            failures.append(f"{path.name}: {exc}")
            continue

        project = plan.context.get("project_name", "").strip()
        client_path = plan.context.get("client_path_name", "").strip()
        bullets = [b for item in plan.items for b in item.criteria]
        if not bullets:
            failures.append(f"{path.name}: нет буллитов")
            continue

        base = slug(project) or slug(path.stem) or "initiative"
        item_id = base
        suffix = 2
        while item_id in seen:
            item_id = f"{base}-{suffix}"
            suffix += 1
        seen.add(item_id)

        items.append({
            "id": item_id,
            "source": path.parent.name,
            "client_path": client_path,
            "project": project,
            "stages": list(plan.stages),
            "bullets": bullets,
            "context_text": plan.source_text,
        })

    return {
        "schema": SCHEMA,
        "generated_at": time.strftime("%Y-%m-%d"),
        "count": len(items),
        "failures": failures,
        "items": sorted(items, key=lambda i: (i["source"], i["project"])),
    }


def _dump(catalog: dict) -> str:
    """Шапка человеческим отступом, инициативы — по одной на строку.

    Полные отступы стоили бы вдвое больше места (467 КБ против 260), а
    сплошная строка убила бы diff: правка одной инициативы должна выглядеть
    как одна изменённая строка, иначе обновление каталога нечем проверять.
    """
    head = {key: value for key, value in catalog.items() if key != "items"}
    lines = [json.dumps(head, ensure_ascii=False, indent=1)[:-2].rstrip()]
    lines[0] += ',\n "items": ['
    rows = [
        "  " + json.dumps(item, ensure_ascii=False, separators=(",", ":"))
        for item in catalog["items"]
    ]
    lines.append(",\n".join(rows))
    lines.append(" ]\n}")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Собрать каталог инициатив")
    parser.add_argument("source", help="папка с .md образами результата")
    parser.add_argument(
        "--out",
        default=str(Path("backend") / "pko" / "initiatives" / "catalog.json"),
        help="куда положить каталог",
    )
    args = parser.parse_args(argv)

    source = Path(args.source)
    if not source.is_dir():
        print(f"Не папка: {source}", file=sys.stderr)
        return 1

    catalog = build(source)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(_dump(catalog), encoding="utf-8", newline="\n")

    bullets = sum(len(i["bullets"]) for i in catalog["items"])
    print(f"инициатив: {catalog['count']}, буллитов: {bullets}")
    print(f"размер: {out.stat().st_size / 1024:.0f} КБ → {out}")
    for line in catalog["failures"]:
        print("  ! не разобрано:", line, file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

// Local, headless regression check. Run with bundled Playwright via NODE_PATH.
const { chromium } = require('playwright');
const { pathToFileURL } = require('url');
const path = require('path');
const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');

(async () => {
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 960 }, reducedMotion: 'reduce' });
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    const source = path.resolve(process.argv[2] || 'reports/example/passport_executive_preview.html');
    await page.goto(pathToFileURL(source).href);
    await page.locator('.pko-object').first().waitFor();
    const theme = await page.evaluate(() => ({
      font: getComputedStyle(document.body).fontFamily,
      loadedWeights: [...document.fonts].filter(f => f.family === 'SB Sans Display' && f.status === 'loaded').map(f => f.weight).sort(),
      accent: getComputedStyle(document.documentElement).getPropertyValue('--dpss-accent').trim(),
      background: getComputedStyle(document.body).backgroundColor,
    }));
    assert(theme.font.includes('SB Sans Display'));
    assert.deepEqual(theme.loadedWeights, ['400', '600', '700']);
    assert.equal(theme.accent, '#C17DF7');
    assert.equal(theme.background, 'rgb(255, 255, 255)');
    assert.equal(await page.locator('.pko-viewport').evaluate(node => getComputedStyle(node).backgroundColor), 'rgb(246, 250, 248)');
    assert.equal(await page.locator('.pko-legend').getByText('операционный риск (количество)', { exact: true }).count(), 1);
    assert.equal(await page.locator('.pko-context,.pko-hint,.pko-head .pko-preview-note').count(), 0);
    const resetButton = page.locator('.pko-head').getByRole('button', { name: 'Сбросить выбор' });
    assert(await resetButton.isDisabled());
    assert((await page.locator('.pko-head').boundingBox()).height < 125);
    const viewportBox = await page.locator('.pko-viewport').boundingBox();
    const mapCursor = await page.locator('.pko-viewport').evaluate(node => getComputedStyle(node).cursor);
    assert.equal(mapCursor, 'default');
    assert.equal(await page.locator('.pko-object').first().evaluate(node => getComputedStyle(node).cursor), mapCursor);
    await page.mouse.move(viewportBox.x + 80, viewportBox.y + 80);
    await page.mouse.down();
    await page.mouse.move(viewportBox.x + 110, viewportBox.y + 100);
    assert.equal(await page.locator('.pko-viewport').evaluate(node => getComputedStyle(node).cursor), mapCursor);
    await page.mouse.up();
    assert.equal(await page.locator('.pko-viewport').evaluate(node => getComputedStyle(node).cursor), mapCursor);
    const zoomBox = await page.locator('.pko-zoom').boundingBox();
    assert(Math.abs(zoomBox.x - viewportBox.x - 16) < 1);
    assert(Math.abs(viewportBox.y + viewportBox.height - zoomBox.y - zoomBox.height - 16) < 1);
    assert.deepEqual(await page.locator('.pko-zoom button').evaluateAll(buttons => buttons.map(b => b.getAttribute('aria-label'))),
      ['Отдалить', 'Приблизить', 'Показать весь граф']);
    assert.equal(await page.locator('.pko-zoom .fit svg').count(), 1);
    const beforeZoom = await page.locator('.pko-zoom .lvl').textContent();
    await page.getByRole('button', { name: 'Приблизить' }).click();
    assert.notEqual(await page.locator('.pko-zoom .lvl').textContent(), beforeZoom);
    await page.getByRole('button', { name: 'Показать весь граф' }).click();
    const statusMismatches = await page.evaluate(() => {
      const script = [...document.scripts].find(s => s.textContent.includes('var SCHEMA='));
      const schema = JSON.parse(script.textContent.match(/var SCHEMA=(.*?); var meta/s)[1]);
      return schema.nodes.filter(n => n.implementation_status).filter(n => {
        const node = [...document.querySelectorAll('.pko-object')].find(b => b.dataset.id === n.id);
        const badge = node && node.querySelector('.st');
        return !badge || badge.textContent !== (n.implementation_label || n.implementation_status) ||
          !badge.classList.contains(n.implementation_status) || !node.getAttribute('aria-label').includes(badge.textContent);
      }).map(n => n.id);
    });
    assert.deepEqual(statusMismatches, [], 'graph status must match the supplied node status');
    assert.equal(await page.locator('.pko-object .risk svg').count(), await page.locator('.pko-object .risk').count());
    assert.equal(await page.locator('.pko-object .risk').filter({ hasText: 'рисков:' }).count(), 0);
    const badgeAlignment = await page.locator('.pko-object').filter({ has: page.locator('.st') }).filter({ has: page.locator('.risk') }).first().evaluate(node => {
      const a = node.querySelector('.st').getBoundingClientRect();
      const b = node.querySelector('.risk').getBoundingClientRect();
      return Math.abs(a.y - b.y);
    });
    assert(badgeAlignment < 2, 'risk count should be alongside node status');
    const graph = await page.evaluate(() => {
      const lines = [...document.querySelectorAll('.pko-links path.link')];
      return { pairs: lines.map(n => n.dataset.pair),
        styles: [...new Set(lines.map(n => { const s = getComputedStyle(n); return [s.stroke, s.strokeDasharray, s.markerEnd].join('|'); }))],
        nodes: document.querySelectorAll('.pko-object').length,
        pins: document.querySelectorAll('.pko-pin').length };
    });
    assert.equal(new Set(graph.pairs).size, graph.pairs.length, 'duplicate pair');
    assert.equal(graph.styles.length, 1, 'different line styles');
    assert.equal(await page.locator('.pko-links [marker-end]').count(), 0);
    await page.screenshot({ path: 'reports/example/passport_executive_preview.png' });
    // Choose a node that actually has a risk.
    const node = page.locator('.pko-object').filter({ has: page.locator('.risk') }).first();
    await node.focus();
    await node.press('Enter');
    assert(await resetButton.isEnabled());
    await page.locator('.pko-action').click();
    const selectedStyle = await page.locator('.pko-object.selected').evaluate(node => {
      const style = getComputedStyle(node);
      return { background: style.backgroundColor, borderWidth: style.borderTopWidth,
        outlineStyle: style.outlineStyle, focusVisible: node.matches(':focus-visible') };
    });
    assert.equal(selectedStyle.background, 'rgba(193, 125, 247, 0.2)');
    assert.equal(selectedStyle.borderWidth, '1px');
    assert(selectedStyle.outlineStyle === 'none' || selectedStyle.focusVisible,
      'only keyboard focus may add an outline');
    const card = page.locator('.pko-drawer-body');
    await card.locator('.pko-risk-card').first().waitFor({ state: 'attached' });
    const descriptionTab = card.getByRole('tab', { name: 'Описание', exact: true });
    const risksTab = card.getByRole('tab', { name: 'Риски', exact: true });
    const linksTab = card.getByRole('tab', { name: 'Связи', exact: true });
    assert.equal(await card.getByRole('tab').count(), 3);
    assert.equal(await descriptionTab.getAttribute('aria-selected'), 'true');
    assert.equal(await card.locator('.pko-risk-card').first().isVisible(), false);
    assert.deepEqual(await card.locator('.pko-field').evaluateAll(nodes => nodes.map(n => n.dataset.field)), ['4.3.1']);
    const blockOrder = await card.locator('[role="tabpanel"]').first().evaluate(panel => [...panel.children].map(n => n.className));
    assert(blockOrder.indexOf('pko-field') < blockOrder.indexOf('pko-node-assessment'));
    assert(!blockOrder.includes('pko-links-list'));
    assert.equal(await card.locator('.pko-links-list').isVisible(), false);
    if (blockOrder.includes('pko-node-defects')) {
      assert(blockOrder.indexOf('pko-node-assessment') < blockOrder.indexOf('pko-node-defects'));
    }
    assert.equal(await card.locator('.identity,[data-fill="object-id"],[data-fill="object-version"]').count(), 0);
    assert.equal(await card.locator('details[open]').count(), 0);
    const headings = await card.locator('h3').allTextContents();
    assert(!headings.some(x => /Владелец|Вход и выход|Версия и изменения|Способы исполнения/.test(x)));
    assert.equal(await card.locator('.pko-card-heading').locator('svg').count(), 0);
    await card.locator('details summary').first().click();
    assert.equal(await card.locator('details[open]').count(), 1);
    await card.locator('details summary').first().click();
    await page.screenshot({ path: 'reports/example/passport_executive_card.png' });
    await risksTab.click();
    assert.equal(await card.locator('.pko-risk-card').first().isVisible(), true);
    assert.equal(await card.locator('.pko-node-risks .lbl,.pko-risk-card .meta').count(), 0);
    assert.equal(await card.locator('.pko-node-risks').getByText('Связанные узлы:', { exact: false }).count(), 0);
    assert.equal(await card.locator('.pko-node-risks').getByText('Связанные ограничения:', { exact: false }).count(), 0);
    assert.equal(await card.locator('.chain').count(), 0);
    const risk = card.locator('.pko-risk-card').first();
    assert(await risk.getByText('Что может случиться', { exact: true }).isVisible());
    assert(await risk.getByText('В чём пробел', { exact: true }).isVisible());
    assert(await risk.getByText('Чем это грозит', { exact: true }).isVisible());
    assert.equal(await card.locator('.pko-node-assessment').isVisible(), false);
    await risksTab.press('ArrowLeft');
    assert.equal(await descriptionTab.getAttribute('aria-selected'), 'true');
    await descriptionTab.press('End');
    assert.equal(await linksTab.getAttribute('aria-selected'), 'true');
    assert(await card.locator('.pko-links-list').isVisible());
    assert(await card.locator('.pko-node-risk-links').isVisible());
    await linksTab.press('ArrowLeft');
    assert.equal(await risksTab.getAttribute('aria-selected'), 'true');
    await page.setViewportSize({ width: 375, height: 812 });
    assert(await page.locator('.pko-drawer').isVisible());
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    const box = await page.locator('.pko-drawer').boundingBox();
    assert(box.x >= 0 && box.width <= 375);
    await page.screenshot({ path: 'reports/example/passport_executive_mobile.png' });
    await page.keyboard.press('Escape');
    assert.equal(await page.locator('.pko-drawer.open').count(), 0);
    await page.setViewportSize({ width: 1440, height: 960 });
    await page.locator('.pko-object').first().focus();
    await page.locator('.pko-object').first().press('Enter');
    await page.locator('.pko-action').focus();
    await page.locator('.pko-action').press('Enter');
    assert.equal(await card.getByRole('tab', { name: 'Описание', exact: true }).getAttribute('aria-selected'), 'true');
    await card.getByRole('tab', { name: 'Риски', exact: true }).click();
    assert(await card.getByText('Для этого узла риски в отчёте не указаны.', { exact: true }).isVisible());
    assert.deepEqual(errors, []);
    await resetButton.click();
    assert(await resetButton.isDisabled());
    assert.equal(await page.locator('.pko-object.selected,.pko-drawer.open').count(), 0);
    // Capture the same node used in the user's design feedback.
    if (await page.locator('.pko-object[data-id="bbb-7"]').count()) {
      await page.keyboard.press('Escape');
      await page.setViewportSize({ width: 1263, height: 706 });
      await page.locator('.pko-object[data-id="bbb-7"]').focus();
      await page.locator('.pko-object[data-id="bbb-7"]').press('Enter');
      await page.locator('.pko-action').focus();
      await page.locator('.pko-action').press('Enter');
      await page.screenshot({ path: 'reports/example/passport_dpss_description.png' });
      await card.getByRole('tab', { name: 'Связи', exact: true }).click();
      await page.screenshot({ path: 'reports/example/passport_dpss_links.png' });
      await card.getByRole('tab', { name: 'Риски', exact: true }).click();
      await page.screenshot({ path: 'reports/example/passport_dpss_risks.png' });
    }
    if (await page.locator('.pko-object[data-id="operation-24"]').count()) {
      await page.locator('.pko-head button.tool').click();
      await page.locator('.pko-object[data-id="operation-24"]').focus();
      await page.locator('.pko-object[data-id="operation-24"]').press('Enter');
      await page.locator('.pko-action').focus();
      await page.locator('.pko-action').press('Enter');
      await card.getByRole('tab', { name: 'Риски', exact: true }).click();
      const disclosures = card.locator('.pko-risk-disclosure');
      assert((await disclosures.count()) > 1);
      assert.equal(await card.locator('.pko-risk-disclosure[open]').count(), 0);
      assert.equal(await card.locator('.pko-risk-card .risk-event:visible').count(), 0);
      await page.screenshot({ path: 'reports/example/passport_dpss_risk_list.png' });
      await disclosures.first().locator('summary').first().click();
      assert.equal(await card.locator('.pko-risk-disclosure[open]').count(), 1);
      assert(await card.locator('.pko-risk-card .risk-event').first().isVisible());
      await disclosures.first().locator('summary').first().press('Enter');
      assert.equal(await card.locator('.pko-risk-disclosure[open]').count(), 0);
      await card.getByRole('tab', { name: 'Связи', exact: true }).click();
      assert(await card.locator('.pko-node-risk-links').isVisible());
    }
    if (await page.locator('.pko-object[data-id="process-5"]').count()) {
      await page.locator('.pko-head button.tool').click();
      await page.locator('.pko-object[data-id="process-5"]').focus();
      await page.locator('.pko-object[data-id="process-5"]').press('Enter');
      await page.locator('.pko-action').focus();
      await page.locator('.pko-action').press('Enter');
      await card.getByRole('tab', { name: 'Риски', exact: true }).click();
      assert.equal(await card.locator('.pko-node-risks .lbl,.pko-risk-card .meta').count(), 0);
      assert.equal(await card.locator('.pko-node-risks').getByText('Связанные узлы:', { exact: false }).count(), 0);
      assert.equal(await card.locator('.pko-node-risks').getByText('Связанные ограничения:', { exact: false }).count(), 0);
      await page.screenshot({ path: 'reports/example/passport_dpss_process_risk.png' });
      await card.getByRole('tab', { name: 'Связи', exact: true }).click();
      assert(await card.locator('.pko-node-risk-links').getByText('Связанные узлы:', { exact: false }).first().isVisible());
      assert(await card.locator('.pko-node-risk-links').getByText('Связанные ограничения:', { exact: false }).first().isVisible());
      await page.screenshot({ path: 'reports/example/passport_dpss_process_links.png' });
    }
    const cardFit = await page.evaluate(() => {
      const nodes = [...document.querySelectorAll('.pko-object')];
      let fits = 0;
      for (const node of nodes) {
        document.querySelector('.pko-head button.tool').click();
        node.click();
        document.querySelector('.pko-action').click();
        const body = document.querySelector('.pko-drawer-body');
        if (body.scrollHeight <= body.clientHeight + 2) fits++;
      }
      return { fits, total: nodes.length };
    });
    assert(cardFit.fits > cardFit.total / 2, 'description should fit one screen for most nodes at 1263×706');
    if (await page.locator('.pko-object[data-id="process-6"]').count()) {
      await page.evaluate(() => {
        document.querySelector('.pko-head button.tool').click();
        document.querySelector('.pko-object[data-id="process-6"]').click();
        document.querySelector('.pko-action').click();
      });
      const selected = await page.locator('.pko-object[data-id="process-6"]').evaluate(node => {
        const style = getComputedStyle(node);
        return { border: style.borderTopWidth, outline: style.outlineStyle,
          fill: style.backgroundColor, focusVisible: node.matches(':focus-visible') };
      });
      assert.equal(selected.border, '1px');
      assert.equal(selected.outline, 'none');
      assert.equal(selected.fill, 'rgba(193, 125, 247, 0.2)');
      assert.equal(selected.focusVisible, false);
      const controlOverlap = await page.evaluate(() => {
        const a = document.querySelector('.pko-zoom').getBoundingClientRect();
        const b = document.querySelector('.pko-action').getBoundingClientRect();
        return Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left)) *
          Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
      });
      assert.equal(controlOverlap, 0, 'zoom controls must not cover the selected node action');
      await page.screenshot({ path: 'reports/example/passport_dpss_mint_selection.png' });
    }
    if (process.env.PKO_PYTHON) {
      const shared = JSON.parse(execFileSync(process.env.PKO_PYTHON, ['-c',
        'import json; from pko.render.passport_map import PASSPORT_MAP_JS, PASSPORT_MAP_CSS; print(json.dumps(dict(js=PASSPORT_MAP_JS, css=PASSPORT_MAP_CSS)))'], { encoding: 'utf8' }));
      await page.setViewportSize({ width: 1000, height: 800 });
      await page.setContent('<style>' + shared.css + '</style><div id="map" style="height:700px"></div>');
      await page.addScriptTag({ content: shared.js });
      await page.evaluate(() => window.pkoPassportMap(document.querySelector('#map'), [
        { id: 'journey-1', type: 'journey', name: 'Путь' },
        { id: 'process-1', type: 'process', parents: ['journey-1'], name: 'Сценарий' },
        { id: 'bbb-1', type: 'bbb', parents: ['process-1'], name: 'Действие' },
        { id: 'operation-1', type: 'operation', parents: ['bbb-1'], name: 'Операция' },
      ], { relations: [
        { from: 'operation-1', to: 'bbb-1', kind: 'feeds' },
        { from: 'operation-1', to: 'process-1', kind: 'feeds' },
        { from: 'process-1', to: 'operation-1', kind: 'triggers' },
      ], paths: [{ id: 'scenario-1', title: 'Сценарий', nodes: [{id:'operation-1'}],
        edges: [{from:'process-1',to:'operation-1',result:'broken'}] }] }));
      await page.waitForFunction(() => document.querySelectorAll('.pko-paths .connection').length === 4);
      assert.equal(await page.locator('.pko-viewport').evaluate(node => getComputedStyle(node).cursor), mapCursor);
      const pairs = await page.locator('.pko-paths .connection').evaluateAll(nodes => nodes.map(n => n.dataset.pair));
      assert.equal(pairs.length, new Set(pairs).size);
      assert.equal(await page.locator('.pko-paths [marker-end]').count(), 0);
    }
    assert.deepEqual(errors, []);
    console.log(JSON.stringify({ ok: true, nodes: graph.nodes, lines: graph.pairs.length,
      lineStyles: graph.styles, pins: graph.pins, cards: cardFit, mobile: '375px', shared: !!process.env.PKO_PYTHON, errors }));
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });

"""Прогнать папку с проектами локально: отчёт ложится в папку самого проекта.

    python scripts/review_projects.py Review_project

Раскладка входа — по папке на проект, внутри архивы репозиториев:

    Review_project/
      Copilot сотрудника ДККК по расчету CF моделей/
        backend.zip
        agent.zip
      Агент – ассистент ГКМ Key Clients/
        repo.zip

Образ результата берётся из вшитого каталога по имени папки: тех же самых
инициатив, что показывает `pko initiatives`. Если имя не совпадает или проекта
в каталоге нет — положите рядом с архивами `описание.txt` (или `.md`) в том же
формате, что и файлы колоды.

Результат — `dashboard.html` и `progress_model.json` в папке проекта, рядом с
архивами. Это ровно тот отчёт, что выдаёт стенд: и веб, и это скрипт зовут один
`build_dashboard_data` и один `render_dashboard_html`.

Это локальный инструмент, а не часть сервиса: в образ каталог `scripts/` не
едет, на стенде команд не прибавляется.

Прогон длинный — до четверти часа на проект. Что важно:

* проекты идут по очереди: каждый держит распакованный код и историю диалога;
* упавший проект не отменяет остальные, причина печатается в конце;
* повторный запуск досчитывает — проект с готовым `dashboard.html`
  пропускается, `--force` пересчитывает.
"""

from __future__ import annotations

import argparse
import sys
import tempfile
import time
import traceback
from dataclasses import dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from pko.errors import PkoError  # noqa: E402
from pko.initiatives import find as find_initiative  # noqa: E402
from pko.llm.registry import get_spec  # noqa: E402
from pko.progress.local_source import build_target_repo_from_uploads  # noqa: E402
from pko.progress.pipeline import run_progress  # noqa: E402
from pko.render.dashboard_data import build_dashboard_data  # noqa: E402
from pko.render.dashboard_html import render_dashboard_html  # noqa: E402
from pko.util.env import load_env  # noqa: E402

REPORT = "dashboard.html"
MODEL = "progress_model.json"
TEXT_SUFFIXES = (".txt", ".md")


@dataclass
class Outcome:
    name: str
    status: str          # ok | skipped | error
    readiness: int = 0
    decision: str = ""
    detail: str = ""


def journey_text_of(folder: Path) -> str:
    """Образ результата проекта: файл рядом с архивами или каталог по имени."""
    texts = sorted(p for p in folder.iterdir()
                   if p.is_file() and p.suffix.lower() in TEXT_SUFFIXES)
    if len(texts) == 1:
        return texts[0].read_text(encoding="utf-8", errors="replace")
    if len(texts) > 1:
        raise PkoError(
            "Несколько файлов с описанием: " + ", ".join(t.name for t in texts),
            hint="оставьте один — какой из них главный, догадываться нельзя",
        )
    # Файла нет: имя папки должно совпасть с инициативой каталога.
    return find_initiative(folder.name).to_text()


def run_one(folder: Path, spec, workspace: Path, max_steps: int) -> tuple[int, str]:
    archives = sorted(p for p in folder.iterdir()
                      if p.is_file() and p.suffix.lower() == ".zip")
    if not archives:
        raise PkoError("В папке проекта нет ни одного .zip",
                       hint="положите архивы репозиториев рядом")

    target = build_target_repo_from_uploads(archives, workspace)
    model = run_progress(journey_text_of(folder), folder.name, target, spec,
                         max_steps=max_steps)
    (folder / REPORT).write_text(
        render_dashboard_html(build_dashboard_data(model)), encoding="utf-8")
    (folder / MODEL).write_text(model.to_json(), encoding="utf-8")
    return model.readiness, (model.summary.decision if model.summary else "")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Прогнать все проекты из папки; отчёт ложится в папку проекта.")
    parser.add_argument("root", help="Папка, внутри которой лежат папки проектов")
    parser.add_argument("--force", action="store_true",
                        help="Пересчитать проекты с готовым отчётом")
    parser.add_argument("--only", default="",
                        help="Только проекты, чьё имя содержит эту строку")
    parser.add_argument("--max-steps", type=int, default=80)
    parser.add_argument("--thinking", action="store_true")
    args = parser.parse_args(argv)

    load_env()
    root = Path(args.root)
    if not root.is_dir():
        print(f"Ошибка: папка не найдена — {root}", file=sys.stderr)
        return 1

    spec = get_spec("matcher", thinking=True if args.thinking else None)
    if spec is None:
        print("Ошибка: не настроен LLM-эндпоинт (PKO_ASSEMBLER_BASE_URL в .env)",
              file=sys.stderr)
        return 1

    folders = [p for p in sorted(root.iterdir()) if p.is_dir()]
    if args.only:
        folders = [p for p in folders if args.only.lower() in p.name.lower()]
    if not folders:
        print(f"В {root} нет ни одной папки проекта.", file=sys.stderr)
        return 1

    outcomes: list[Outcome] = []
    with tempfile.TemporaryDirectory(prefix="pko-review-") as tmp:
        for index, folder in enumerate(folders, start=1):
            head = f"[{index}/{len(folders)}] {folder.name}"
            if (folder / REPORT).is_file() and not args.force:
                print(f"{head}: отчёт уже есть, пропускаю")
                outcomes.append(Outcome(folder.name, "skipped"))
                continue

            print(f"{head}: считаю…", flush=True)
            started = time.monotonic()
            try:
                readiness, decision = run_one(
                    folder, spec, Path(tmp) / f"ws{index}", args.max_steps)
            except PkoError as exc:
                print(f"{head}: ошибка — {exc.message}")
                outcomes.append(Outcome(folder.name, "error", detail=exc.render()))
                continue
            except Exception as exc:  # noqa: BLE001
                # Прогон идёт часами без присмотра: один сбой не повод потерять
                # остальные. Трассировка ложится рядом с архивами.
                (folder / "error.txt").write_text(
                    traceback.format_exc(), encoding="utf-8")
                print(f"{head}: сбой — {exc}")
                outcomes.append(Outcome(folder.name, "error",
                                        detail=f"{type(exc).__name__}: {exc}"))
                continue

            minutes = int((time.monotonic() - started) // 60)
            print(f"{head}: {readiness}% · {decision or 'решение не сформировано'}"
                  f" · {minutes} мин")
            outcomes.append(Outcome(folder.name, "ok", readiness, decision))

    done = [o for o in outcomes if o.status == "ok"]
    failed = [o for o in outcomes if o.status == "error"]
    print()
    print(f"Посчитано: {len(done)} · пропущено: "
          f"{sum(1 for o in outcomes if o.status == 'skipped')} · "
          f"с ошибкой: {len(failed)}")
    for outcome in failed:
        print(f"  ! {outcome.name}: {outcome.detail}")
    for outcome in done:
        print(f"  {outcome.readiness:3d}%  {outcome.decision:5s}  {outcome.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

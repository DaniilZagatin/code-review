"""Re-render an existing HTML passport without rerunning or inventing analysis."""
import argparse
import json
from html import escape
from pathlib import Path
import re
from types import SimpleNamespace

from pko.render.client_journey_passport import _finalize_html
from pko.render.passport_map import _build_breaks
from pko.render.passport_content import compact_template


def refresh(source: Path, target: Path, editorial: Path | None = None):
    text = source.read_text(encoding="utf-8")
    match = re.search(r"var SCHEMA=(.*?); var meta", text, re.S)
    if not match:
        raise ValueError("HTML не содержит встроенной схемы паспорта")
    schema = json.loads(match[1])
    # Derive break markers from the existing facts, not from new assumptions.
    if "breaks" not in schema:
        scenarios = {p["id"]: SimpleNamespace(**p) for p in schema.get("paths", [])}
        schema["breaks"] = _build_breaks(schema["nodes"], schema.get("handoffs", []), scenarios)
    schema.setdefault("meta", {})["preview_note"] = (
        "Пример нового оформления на данных исходного паспорта. Повторная оценка кода и рисков не выполнялась."
    )
    text = re.sub(r"<(script|style)\b[^>]*data-passport-fix[^>]*>.*?</\1>", "", text, flags=re.S)
    text = re.sub(r"<style\b[^>]*data-passport-fonts[^>]*>.*?</style>", "", text, flags=re.S)
    if editorial:
        # Explicit example copy edits, not new model findings or code evidence.
        edits = json.loads(editorial.read_text(encoding="utf-8"))
        text = compact_template(text)
        for nid, meaning in edits.get("business_meaning", {}).items():
            pattern = r'(<section class="node" id="' + re.escape(nid) + r'">.*?<p data-fill="value">).*?(</p>)'
            text, count = re.subn(pattern, lambda m: m[1] + escape(meaning) + m[2], text, count=1, flags=re.S)
            if count != 1:
                raise ValueError(f"Узел редакционной правки не найден: {nid}")
        by_id = {r["id"]: r for r in schema.get("risks", [])}
        allowed = {"title", "cause", "negative_event", "consequences", "control_gap", "confirmation_needed"}
        for rid, fields in edits.get("risks", {}).items():
            if rid not in by_id or set(fields) - allowed:
                raise ValueError(f"Недопустимая редакционная правка риска: {rid}")
            by_id[rid].update(fields)
        schema["meta"]["preview_note"] += " Формулировки выбранного узла и риска отредактированы для читаемости."
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(_finalize_html(text, schema), encoding="utf-8")
    print(f"{target}: {target.stat().st_size} bytes (source {source.stat().st_size})")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("--editorial", type=Path, help="Явные редакционные правки примера, без переоценки")
    args = parser.parse_args()
    refresh(args.source, args.target, args.editorial)

"""Собрать автономный визуальный пример оценённой карты паспорта.

Файл использует тот же CSS/JS-компонент, что итоговый HTML-паспорт, поэтому
служит не макетом, а быстро открываемой демонстрацией отдельной фичи.
"""

from __future__ import annotations

import json
from pathlib import Path

from pko.render.passport_map import PASSPORT_MAP_CSS, PASSPORT_MAP_JS


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "reports" / "example" / "passport_schema_feature_example.html"


NODES = [
    {
        "id": "need-1", "type": "need",
        "name": "Быстро решить обращение без повторного объяснения",
        "basis": "Потребность сформулирована из образа результата",
        "scope": ["journey-1"], "implementation_status": "partial",
        "implementation_label": "Частично реализован", "readiness": 67,
        "band": "mid", "bullets": [
            {"text": "Сохранять контекст обращения между этапами", "status_label": "Частично"},
        ],
        "problems": ["Контекст теряется при передаче в экспертный контур"],
    },
    {
        "id": "journey-1", "type": "journey", "name": "Решение обращения клиента",
        "basis": "Корневой путь инициативы", "parent": None,
        "implementation_status": "partial", "implementation_label": "Частично реализован",
        "readiness": 67, "band": "mid", "bullets": [],
        "problems": ["Критический сценарий не доходит до запуска работ"],
    },
    {
        "id": "process-1", "type": "process", "name": "Обработка обращения",
        "basis": "Сквозной процесс от входа до ответа", "parent": "journey-1",
        "implementation_status": "partial", "implementation_label": "Частично реализован",
        "readiness": 67, "band": "mid", "bullets": [],
        "problems": ["Один из двух целевых сценариев разорван"],
    },
    {
        "id": "bbb-1", "type": "bbb", "name": "Приём и классификация",
        "basis": "Выделяет сценарий и фиксирует обращение", "parent": "process-1",
        "implementation_status": "implemented", "implementation_label": "Реализован",
        "readiness": 100, "band": "good", "bullets": [
            {"text": "Классифицировать обращение", "status_label": "Готово"},
            {"text": "Создать заявку", "status_label": "Готово"},
        ], "problems": [],
    },
    {
        "id": "operation-1", "type": "operation", "name": "Определить тему",
        "basis": "Классификатор вызывается из реального входа", "parent": "bbb-1",
        "implementation_status": "implemented", "implementation_label": "Реализован",
        "readiness": 100, "band": "good", "bullets": [
            {"text": "Классифицировать обращение", "status_label": "Готово"},
        ], "problems": [],
    },
    {
        "id": "operation-2", "type": "operation", "name": "Зарегистрировать заявку",
        "basis": "Заявка сохраняется с идентификатором", "parent": "bbb-1",
        "implementation_status": "implemented", "implementation_label": "Реализован",
        "readiness": 100, "band": "good", "bullets": [
            {"text": "Создать заявку", "status_label": "Готово"},
        ], "problems": [],
    },
    {
        "id": "bbb-2", "type": "bbb", "name": "Экспертиза и решение",
        "basis": "Готовит ответ либо решение о запуске работ", "parent": "process-1",
        "implementation_status": "limited", "implementation_label": "Реализован с ограничениями",
        "readiness": 50, "band": "mid", "bullets": [
            {"text": "Подготовить справочный ответ", "status_label": "Готово"},
            {"text": "Передать заявку эксперту", "status_label": "С ограничениями"},
        ], "problems": ["Идентификатор заявки не передаётся в команду запуска работ"],
        "mark": "broken",
    },
    {
        "id": "operation-3", "type": "operation", "name": "Подготовить справку",
        "basis": "Ответ формируется и возвращается клиенту", "parent": "bbb-2",
        "implementation_status": "implemented", "implementation_label": "Реализован",
        "readiness": 100, "band": "good", "bullets": [
            {"text": "Подготовить справочный ответ", "status_label": "Готово"},
        ], "problems": [],
    },
    {
        "id": "operation-4", "type": "operation", "name": "Передать эксперту",
        "basis": "Вызов найден, контракт передачи неполный", "parent": "bbb-2",
        "implementation_status": "limited", "implementation_label": "Реализован с ограничениями",
        "readiness": 50, "band": "mid", "bullets": [
            {"text": "Передать заявку эксперту", "status_label": "С ограничениями"},
        ], "problems": ["В контракте отсутствует идентификатор заявки"],
        "mark": "broken",
    },
    {
        "id": "bbb-3", "type": "bbb", "name": "Исполнение и уведомление",
        "basis": "Должен запустить работы и уведомить клиента", "parent": "process-1",
        "implementation_status": "not_implemented", "implementation_label": "Не реализован",
        "readiness": 0, "band": "bad", "bullets": [
            {"text": "Запустить работы", "status_label": "Запланировано"},
            {"text": "Уведомить клиента", "status_label": "Запланировано"},
        ], "problems": ["Нет принимающего обработчика команды запуска"],
        "mark": "broken",
    },
    {
        "id": "operation-5", "type": "operation", "name": "Запустить работы",
        "basis": "Обязательство есть в образе результата, реализации нет", "parent": "bbb-3",
        "implementation_status": "not_implemented", "implementation_label": "Не реализован",
        "readiness": 0, "band": "bad", "bullets": [
            {"text": "Запустить работы", "status_label": "Запланировано"},
        ], "problems": ["Команда не принимается ни одним компонентом"],
        "mark": "broken",
    },
    {
        "id": "operation-6", "type": "operation", "name": "Сообщить результат",
        "basis": "Точка уведомления заявлена, трасса отсутствует", "parent": "bbb-3",
        "implementation_status": "unknown", "implementation_label": "Недостаточно данных",
        "readiness": None, "band": "none", "bullets": [],
        "problems": ["Не найдена подтверждённая связь с каналом уведомлений"],
        "mark": "unknown",
    },
    {
        "id": "guardrail-1", "type": "guardrail",
        "name": "Работы нельзя запускать без подтверждённого решения",
        "basis": "Исполняемое ограничение для блока экспертизы",
        "scope": ["bbb-2", "bbb-3"], "implementation_status": "limited",
        "implementation_label": "Реализован с ограничениями", "readiness": 50,
        "band": "mid", "bullets": [
            {"text": "Проверять подтверждение решения", "status_label": "С ограничениями"},
        ], "problems": ["Проверка есть до передачи, но отсутствует у получателя"],
    },
]


PATHS = [
    {
        "id": "scenario-reference", "title": "Получить справочный ответ",
        "status": "assembled", "status_label": "Собран по коду", "critical": False,
        "nodes": [{"id": x} for x in ("operation-1", "operation-2", "operation-3")],
        "edges": [
            {"from": "operation-1", "to": "operation-2", "result": "ok"},
            {"from": "operation-2", "to": "operation-3", "result": "ok"},
        ],
    },
    {
        "id": "scenario-work", "title": "Запустить работы по обращению",
        "status": "broken", "status_label": "Выявлен разрыв", "critical": True,
        "break_point": "«Передать эксперту» → «Запустить работы»: потерян идентификатор заявки",
        "nodes": [{"id": x} for x in ("operation-1", "operation-2", "operation-4", "operation-5", "operation-6")],
        "edges": [
            {"from": "operation-1", "to": "operation-2", "result": "ok"},
            {"from": "operation-2", "to": "operation-4", "result": "ok"},
            {"from": "operation-4", "to": "operation-5", "result": "broken"},
            {"from": "operation-5", "to": "operation-6", "result": "unknown"},
        ],
    },
]


def json_for_script(value: object) -> str:
    return json.dumps(value, ensure_ascii=False).replace("</", "<\\/")


def build_html() -> str:
    nodes = json_for_script(NODES)
    paths = json_for_script(PATHS)
    return f"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Пример · Оценённая схема паспорта</title>
<style>
:root{{--ink:#17212b;--muted:#637282;--line:#d9e0e5;--surface:#fff;--bg:#f3f6f8;--accent:#7c5ce6;--danger:#c73955;--success:#16857f;--warning:#b98000}}
*{{box-sizing:border-box}}
html,body{{height:100%}}
body{{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,"Segoe UI",Arial,sans-serif;line-height:1.5}}
button{{font:inherit}}
.page{{height:100%;min-height:680px;padding:16px;display:flex;flex-direction:column;gap:12px;overflow:hidden}}
.overview{{display:grid;grid-template-columns:minmax(340px,.9fr) minmax(650px,1.6fr);background:var(--surface);border:1px solid var(--line);border-radius:14px;overflow:hidden;box-shadow:0 8px 28px -24px rgba(23,33,43,.6);flex:none}}
.hero{{padding:18px 20px;display:flex;align-items:center}}
h1{{margin:0;font-size:clamp(24px,2.4vw,32px);line-height:1.12;letter-spacing:-.025em}}
.lead{{margin:7px 0 0;color:var(--muted);max-width:62ch;font-size:14px;line-height:1.45}}
.metrics{{display:grid;grid-template-columns:repeat(5,minmax(104px,1fr));align-items:stretch;background:#f8fafc;border-left:1px solid var(--line)}}
.metric{{display:flex;min-width:0;flex-direction:column;justify-content:center;padding:12px;border-left:1px solid #e5eaee}}
.metric:first-child{{border-left:0}}
.metric .label{{color:var(--muted);font-size:11px;font-weight:700;line-height:1.25}}
.metric .value{{display:flex;align-items:baseline;gap:6px;margin-top:5px;font-size:24px;font-weight:800;line-height:1;font-variant-numeric:tabular-nums}}
.metric.score .value{{color:#5c45b8}}.metric.critical .value{{color:var(--danger)}}
.workspace{{display:grid;grid-template-columns:minmax(0,1fr) 340px;min-height:0;flex:1;background:var(--surface);border:1px solid var(--line);border-radius:14px;overflow:hidden;box-shadow:0 12px 34px -28px rgba(23,33,43,.55)}}
.map-wrap{{position:relative;min-width:0;min-height:0}}
#map{{height:100%;min-height:0}}
.details{{padding:24px;border-left:1px solid var(--line);background:#fff;overflow:auto}}
.details h2{{margin:0 0 5px;font-size:20px;line-height:1.25;letter-spacing:-.01em}}
.details .id{{color:#7a8995;font:11px ui-monospace,SFMono-Regular,Consolas,monospace}}
.status{{display:inline-flex;margin:14px 0 4px;padding:5px 8px;border-radius:6px;background:#f0f2f2;color:#405160;font-size:12px;font-weight:800}}
.status-implemented{{background:#ddf5f2;color:#09615d}}.status-limited{{background:#fff3cc;color:#765400}}.status-partial{{background:#fff0e2;color:#8b430c}}.status-not_implemented{{background:#fce5eb;color:#9c1833}}.status-unknown{{background:#f0f2f2;color:#405160}}
.detail-label{{margin:20px 0 6px;color:#607180;font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}}
.details p{{margin:0;font-size:13px;line-height:1.55}}
.details ul{{margin:5px 0 0;padding-left:18px;font-size:13px;line-height:1.5}}
.details li+li{{margin-top:5px}}
.empty{{color:var(--muted)}}
.a11y-note{{display:flex;align-items:center;gap:8px;color:var(--muted);font-size:11px;flex:none;padding:0 2px}}
.a11y-note svg{{flex:0 0 auto}}
{PASSPORT_MAP_CSS}
@media(max-width:1100px){{.page{{height:auto;min-height:100%;overflow:visible}}.overview{{grid-template-columns:1fr}}.metrics{{border-left:0;border-top:1px solid var(--line)}}.workspace{{min-height:680px}}}}
@media(max-width:760px){{.page{{padding:10px}}.metrics{{grid-template-columns:repeat(2,1fr)}}.metric{{border-top:1px solid #e5eaee}}.workspace{{grid-template-columns:1fr;min-height:0}}.map-wrap,#map{{min-height:560px}}.details{{min-height:300px;border-left:0;border-top:1px solid var(--line)}}}}
</style>
</head>
<body>
<main class="page">
  <section class="overview">
    <header class="hero">
      <div>
        <h1>Обработка обращения клиента</h1>
        <p class="lead">По карте сразу видно, что реализовано, где есть ограничения и на каком переходе перестаёт собираться целевой сценарий.</p>
      </div>
    </header>
    <section class="metrics" aria-label="Оценка схемы">
      <article class="metric score"><div class="label">Оценка схемы</div><div class="value">50%</div></article>
      <article class="metric"><div class="label">Полнота</div><div class="value">67%</div></article>
      <article class="metric"><div class="label">Связность</div><div class="value">50%</div></article>
      <article class="metric critical"><div class="label">Критические разрывы</div><div class="value">1</div></article>
      <article class="metric"><div class="label">Покрытие требованиями</div><div class="value">100%</div></article>
    </section>
  </section>

  <section class="workspace" aria-label="Интерактивная карта паспорта">
    <div class="map-wrap"><div id="map"></div></div>
    <aside class="details" id="details" aria-live="polite">
      <h2>Выберите узел</h2>
      <p class="empty">Нажмите на карточку на схеме, чтобы увидеть основание оценки, связанные требования и конкретные проблемы.</p>
    </aside>
  </section>
  <div class="a11y-note">
    <svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/></svg>
    Статус передаётся не только цветом: он написан на каждом узле и доступен с клавиатуры.
  </div>
</main>
<script>{PASSPORT_MAP_JS}</script>
<script>
var NODES={nodes};
var PATHS={paths};
var details=document.getElementById('details');
function esc(value){{return String(value==null?'':value).replace(/[&<>\"']/g,function(ch){{return {{'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}}[ch]}})}}
function list(items, render){{return items&&items.length?'<ul>'+items.map(render).join('')+'</ul>':'<p class="empty">Нет</p>'}}
var map=window.pkoPassportMap(document.getElementById('map'),NODES,{{paths:PATHS,onSelect:function(node){{
  var d=node.data||{{}};
  details.innerHTML='<h2>'+esc(node.name)+'</h2><div class="id">'+esc(node.id)+'</div>'+
    '<div class="status status-'+esc(d.implementation_status||'unknown')+'">'+esc(d.implementation_label||'Недостаточно данных')+(d.readiness==null?'':' · '+d.readiness+'%')+'</div>'+
    '<div class="detail-label">Почему этот узел есть</div><p>'+esc(node.basis||'Основание не указано')+'</p>'+
    '<div class="detail-label">Связанные требования</div>'+list(d.bullets,function(x){{return '<li><strong>'+esc(x.status_label)+'</strong> — '+esc(x.text)+'</li>'}})+
    '<div class="detail-label">Проблемы</div>'+list(d.problems,function(x){{return '<li>'+esc(x)+'</li>'}});
}}}});
setTimeout(function(){{map.select('operation-4')}},60);
</script>
</body>
</html>"""


def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(build_html(), encoding="utf-8")
    print(OUTPUT)


if __name__ == "__main__":
    main()

"""Offline passport-only reproductions; no LLM or repository-analysis calls."""
import json
from pko.progress.passport_agent import _PassportSession, _handle_submit_node
from pko.progress.risk_review import grounded_reference

session = _PassportSession(current="journey-1")
payload = {"id": "journey-1", "name": "Размещение сбережений во вклады",
           "basis": "", "fields": {}}
responses = [_handle_submit_node(session, payload).splitlines()[0] for _ in range(3)]
print(json.dumps({"probe": "invalid_node_after_retries", "responses": responses,
                  "filled": session.nodes["journey-1"].filled,
                  "notes": session.notes}, ensure_ascii=False))
print(json.dumps({"probe": "risk_reference_range", "where": "payment.py:999999",
                  "known_paths": ["payment.py"],
                  "accepted_by_reference_predicate": grounded_reference(
                      "payment.py:999999", {"payment.py"})}, ensure_ascii=False))

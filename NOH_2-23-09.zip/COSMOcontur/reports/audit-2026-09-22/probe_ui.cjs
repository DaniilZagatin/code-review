const {chromium}=require('playwright');
const {pathToFileURL}=require('url');
const path=require('path');
const fs=require('fs');
const out=__dirname;
(async()=>{
  const browser=await chromium.launch({channel:'msedge',headless:true});
  const page=await browser.newPage({viewport:{width:1440,height:960},reducedMotion:'reduce'});
  const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(pathToFileURL(path.join(out,'passport-current.html')).href);
  await page.locator('.pko-object').first().waitFor();
  await page.evaluate(()=>document.fonts.ready);
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  await page.getByRole('button',{name:'Показать весь граф',exact:true}).click();
  await page.screenshot({path:path.join(out,'passport-fit.png')});
  const metrics=await page.evaluate(()=>({
    zoom:document.querySelector('.pko-zoom .lvl').textContent,
    nodes:document.querySelectorAll('.pko-object').length,
    effectiveTextSize:(()=>{const n=document.querySelector('.pko-object .name')||document.querySelector('.pko-object');const s=parseFloat(document.querySelector('.pko-zoom .lvl').textContent)/100;return parseFloat(getComputedStyle(n).fontSize)*s;})(),
    buttons:[...document.querySelectorAll('.pko-head button,.pko-zoom button')].map(b=>b.getAttribute('aria-label')||b.textContent),
    hasSearch:!!document.querySelector('input[type="search"]'),
  }));
  const node=page.locator('.pko-object').filter({has:page.locator('.risk')}).first();
  await node.focus();
  await node.press('Enter');
  await page.locator('.pko-action').click();
  await page.getByRole('tab',{name:'Риски',exact:true}).click();
  await page.screenshot({path:path.join(out,'passport-risk.png')});
  metrics.drawerWidth=(await page.locator('.pko-drawer').boundingBox()).width;
  metrics.riskText=(await page.locator('.pko-drawer-body').innerText()).slice(0,4500);
  metrics.errors=errors;
  await page.setViewportSize({width:390,height:844});
  await page.screenshot({path:path.join(out,'passport-mobile.png')});
  fs.writeFileSync(path.join(out,'ui-observations.json'),JSON.stringify(metrics,null,2));
  console.log(JSON.stringify(metrics,null,2));
  await browser.close();
})();

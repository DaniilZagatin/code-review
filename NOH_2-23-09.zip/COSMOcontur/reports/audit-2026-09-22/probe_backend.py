"""Read-only, offline audit probes. No model or network requests."""
import asyncio
import json
from pko.progress.verify import verify_evidence
from pko.web import analyses
from pko.web.app import stream_analysis_events


class TinyTree:
    files_set = {"payment.py"}
    def read(self, path):
        return "def charge_card(amount):\n    return None\n"


async def main():
    verdict = verify_evidence("payment.py", 2,
        "charge_card списывает деньги и сохраняет подтверждённую транзакцию", TinyTree())
    print(json.dumps({"probe": "anchor_is_not_semantic_proof", "accepted": verdict.ok,
                      "reason": verdict.reason}, ensure_ascii=False))
    job = analyses.AnalysisJob(id="audit_offline_probe")
    analyses._JOBS[job.id] = job
    try:
        first = (await stream_analysis_events(job.id)).body_iterator
        second = (await stream_analysis_events(job.id)).body_iterator
        job.events.put({"type": "phase", "phase": "agent"})
        await anext(first)
        job.events.put({"type": "phase", "phase": "critic"})
        await anext(second)
        job.status = "READY"
        job.events.put({"type": "analysis_ready"})
        terminal = await anext(first)
        try:
            other = await asyncio.wait_for(anext(second), timeout=0.35)
        except asyncio.TimeoutError:
            other = "timeout: second subscriber received no terminal event"
        print(json.dumps({"probe": "two_active_sse_subscribers", "first": terminal,
                          "second": other}, ensure_ascii=False))
        await first.aclose()
        await second.aclose()
    finally:
        analyses._JOBS.pop(job.id, None)


asyncio.run(main())

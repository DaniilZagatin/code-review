import unittest

from agent_script import risk_review
from pko.progress.risk_review import validate_review
from pko.render.passport_map import _node_code_state
from pko.progress.risk_review import grounded_reference
from pko.progress.matcher import _summarize_tool_result
from pko.render.passport_content import compact_template


class RiskReviewTests(unittest.TestCase):
    def test_known_path_must_match_not_be_substring(self):
        self.assertTrue(grounded_reference("app.py:4 — запись", {"app.py"}))
        self.assertFalse(grounded_reference("other_app.py:4", {"app.py"}))
        self.assertFalse(grounded_reference("other/app.py:4", {"app.py"}))

    def test_review_rejects_invented_source(self):
        review = risk_review()
        check = review[0]["checks"][0]
        check.update(result="no_finding", evidence=[{"where": "invented.py:3", "basis": "Обработчик проверяет ключ действия до списания средств"}])
        self.assertTrue(validate_review(review, {"process-1"}, [], {"app.py"}))

    def test_code_context_survives_for_risk_analysis(self):
        result = _summarize_tool_result("read_file", {"path": "app.py", "offset": 1, "limit": 6},
            "1: def run():\n2:     try:\n3:         charge()\n4:     except TimeoutError:\n5:         charge()")
        self.assertIn("except TimeoutError", result)
        self.assertIn("charge()", result)
        self.assertIn("не доказывает", result)
        self.assertLess(len(result), 2300)

    def test_compact_cards_drop_chrome_and_escape_field_text(self):
        html = '<header><h1>Инициатива</h1></header><div class="node" id="operation-1">' \
               '<div class="identity">object-version secret</div>' \
               '<div data-field="4.5.3"><h4>Владелец и аудит</h4><p data-fill="value">owner</p></div>' \
               '<div data-field="4.5.4"><h4>Проверяемый эффект</h4><small>Какой минимальный эффект контролируется</small>' \
               '<p data-fill="value">&lt;script&gt;bad&lt;/script&gt;</p><span data-fill="source">app.py:4</span></div></div>'
        output = compact_template(html)
        self.assertNotIn("object-version", output)
        self.assertNotIn("Владелец", output)
        self.assertNotIn("Какой минимальный", output)
        self.assertNotIn("<script>", output)
        self.assertIn("&lt;script&gt;bad&lt;/script&gt;", output)
        self.assertIn("app.py:4", output)

    def test_empty_findings_require_coverage(self):
        self.assertTrue(validate_review(None, {"process-1"}, []))
        self.assertTrue(validate_review([], {"process-1"}, []))
        self.assertEqual(validate_review(risk_review(), {"process-1"}, []), [])

    def test_missing_duplicate_and_unknown_checks_rejected(self):
        review = risk_review()
        review[0]["checks"].pop()
        self.assertTrue(validate_review(review, {"process-1"}, []))
        review = risk_review()
        review[0]["checks"].append(review[0]["checks"][0])
        self.assertTrue(validate_review(review, {"process-1"}, []))

    def test_no_finding_is_not_an_unsupported_safety_claim(self):
        review = risk_review()
        review[0]["checks"][0]["result"] = "no_finding"
        self.assertTrue(validate_review(review, {"process-1"}, []))
        review[0]["checks"][0]["evidence"] = [{"where": "app.py:4", "basis": "Проверка до записи отклоняет повторный ключ клиентского действия"}]
        self.assertEqual(validate_review(review, {"process-1"}, []), [])

    def test_findings_must_reference_accepted_risks(self):
        review = risk_review(risks=[{"title": "Повторное списание"}])
        self.assertTrue(validate_review(review, {"process-1"}, []))
        self.assertEqual(validate_review(review, {"process-1"}, [{"title": "Повторное списание"}]), [])

    def test_wrong_process_and_malformed_review(self):
        for review in ([None], [{"node": "process-1", "checks": None}], risk_review(("process-2",))):
            self.assertTrue(validate_review(review, {"process-1"}, []))

    def test_fallback_words_do_not_imply_partial_implementation(self):
        raw = {"name": "Подбор предложения", "basis": "Доступный подбор по условиям клиента",
               "fields": {"4.3.7": {"value": "Если сервис отключён, используется запасной маршрут",
                                      "source": "Установлено: вызывается резервный обработчик"}}}
        state, note = _node_code_state(raw, "process", False)
        self.assertNotEqual(state, "partial")
        self.assertNotIn("отключена", note)


if __name__ == "__main__":
    unittest.main()

"""`pko progress` целиком: четыре сессии агента (оценка, рецензент, ревизор,
паспорт) со скриптованной моделью → четыре файла на диске.

Проверяет стык, который поузловые тесты не видят: след прочитанного из
сессии оценки доходит до паспортного агента, его дерево — до
`progress_model.json` и HTML-паспорта, а карта дерева, карточка узла и
реестр собираются рендерером. Герметично: сеть не нужна, репозиторий —
автоматическая фикстура.
"""

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

import pko.llm.client as client_module
from agent_script import JOURNEY_TEXT, full_session
from fixture_support import ensure_fixture, scripted_responses
from pko import cli
from pko.llm.client import ChatClient
from pko.render.client_journey_passport import STATUS_BADGE_AGENT, STATUS_BADGE_FALLBACK


class CliEndToEndTest(unittest.TestCase):
    def setUp(self):
        self.repo_path = ensure_fixture()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self._cache = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = Path(self.tmp.name) / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._cache)
        self._create = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._create)
        # Роль matcher резолвится из окружения — заглушка без сети.
        self._env = {k: os.environ.get(k) for k in (
            "PKO_MATCHER_BASE_URL", "PKO_MATCHER_MODEL", "PKO_MATCHER_API_KEY",
            "PKO_MONITOR_DIR",
        )}
        os.environ.update({"PKO_MATCHER_BASE_URL": "https://stub.local/v1",
                           "PKO_MATCHER_MODEL": "stub-model", "PKO_MATCHER_API_KEY": "x",
                           "PKO_MONITOR_DIR": str(Path(self.tmp.name) / "monitor")})
        self.addCleanup(self._restore_env)

    def _restore_env(self):
        for k, v in self._env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    def _run(self, *responses: dict) -> Path:
        journey = Path(self.tmp.name) / "initiative.md"
        journey.write_text(JOURNEY_TEXT, encoding="utf-8")
        out = Path(self.tmp.name) / "out"
        ChatClient._create = scripted_responses(*responses)
        code = cli.main(["progress", "--journey-file", str(journey),
                         "--repo-path", str(self.repo_path), "--out", str(out), "--quiet"])
        self.assertEqual(code, 0)
        return out

    def test_progress_writes_all_artifacts_with_agent_passport(self):
        out = self._run(*full_session())

        journals = list((Path(self.tmp.name) / "monitor").glob("run_*.jsonl"))
        self.assertEqual(len(journals), 1)
        events = [json.loads(line) for line in journals[0].read_text(encoding="utf-8").splitlines()]
        self.assertEqual(events[0]["event"], "run_started")
        self.assertEqual(events[-1]["event"], "run_finished")
        self.assertEqual(events[-1]["result"], "success")
        self.assertEqual(
            [event["pass"] for event in events if event["event"] == "pass_started"],
            ["matcher", "critic", "coherence", "passport"],
        )
        self.assertGreaterEqual(sum(event["event"] == "step_finished" for event in events), 4)
        self.assertTrue(any(event["event"] == "model_ready" for event in events))

        files = {p.name for p in out.iterdir()}
        self.assertEqual(files, {"progress_model.json", "progress_report.html",
                                 "dashboard.html", "client_journey_passport.html"})

        model = json.loads((out / "progress_model.json").read_text(encoding="utf-8"))
        passport = model["passport_data"]
        self.assertEqual(passport["decision-boundary"], "END_TO_END_PROCESS")
        rows = {r["id"]: r for r in passport["registry"]}
        self.assertEqual(set(rows), {"journey-1", "process-1", "bbb-1", "bbb-2",
                                     "operation-1", "operation-2"})
        self.assertEqual(rows["operation-2"]["parent"], "bbb-2")
        self.assertEqual(passport["relations"], [{
            "from": "bbb-1", "to": "bbb-2", "kind": "precedes", "kind_label": "предшествует",
            "basis": "передача идёт после записи задачи в start_task", "field": "",
        }])
        self.assertFalse(any("паспорт не завершён" in g for g in model["gaps"]), model["gaps"])

        html = (out / "client_journey_passport.html").read_text(encoding="utf-8")
        self.assertIn(STATUS_BADGE_AGENT, html)
        self.assertIn("Передача исполнителю", html)
        self.assertNotIn("bbb.peredacha-ispolnitelyu", html)  # object-id не входит в карточку
        self.assertIn('"id":"bbb-2"', html)
        self.assertIn('<td data-col="Родитель">bbb-2</td>', html)
        # Потребности и ограничения паспорт больше не выпускает.
        self.assertNotIn('id="related-needs"', html)
        self.assertNotIn('id="related-guardrails"', html)
        self.assertNotIn('id="tpl-need"', html)
        self.assertIn('"kind_label":"предшествует"', html)
        # Раскладка: заголовок «Паспорт инициативы», карта на всю область с
        # зумом, карточка узла в боковой панели — строятся скриптом.
        # Путь называет агент, а не образ результата.
        self.assertIn("Паспорт инициативы «Редизайн платёжного сервиса»", html)
        self.assertIn("Передача задачи исполнителю с отслеживанием статуса", html)
        self.assertIn("pko-viewport", html)
        self.assertIn("pko-drawer", html)
        self.assertIn("pko-zoom", html)
        self.assertNotIn("{{", html.split("<script data-passport-fix>")[0].split("<template", 1)[0])

    def test_progress_without_passport_session_falls_back(self):
        out = self._run(*full_session(passport=False))
        model = json.loads((out / "progress_model.json").read_text(encoding="utf-8"))
        self.assertIsNone(model["passport_data"])
        self.assertTrue(any("паспорт" in g for g in model["gaps"]), model["gaps"])
        html = (out / "client_journey_passport.html").read_text(encoding="utf-8")
        self.assertIn(STATUS_BADGE_FALLBACK, html)

    def test_passport_can_be_switched_off(self):
        os.environ["PKO_PASSPORT"] = "false"
        self.addCleanup(os.environ.pop, "PKO_PASSPORT", None)
        out = self._run(*full_session(passport=False))
        model = json.loads((out / "progress_model.json").read_text(encoding="utf-8"))
        self.assertIsNone(model["passport_data"])
        self.assertTrue(any("PKO_PASSPORT=false" in g for g in model["gaps"]), model["gaps"])
        # Файл паспорта пишется и без агента — заполнен детерминированно.
        self.assertIn(STATUS_BADGE_FALLBACK,
                      (out / "client_journey_passport.html").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()

"""Hypothesis retrieval is bounded, explicit and never project evidence."""

import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from pko.errors import ValidationError
from pko.progress import risk_catalog


class RiskCatalogTests(unittest.TestCase):
    def test_bundled_catalog_preserves_general_coverage_and_adds_domains(self):
        patterns = risk_catalog.load_catalog()["patterns"]
        self.assertEqual({p["id"] for p in patterns if p["domain"] == "general"},
                         {f"R{i:02d}" for i in range(1, 26)})
        self.assertEqual({p["domain"] for p in patterns}, set(risk_catalog.DOMAINS))
        self.assertTrue(all(len(p["facts_to_check"]) >= 2 for p in patterns))

    def test_index_exposes_all_choices_without_loading_detailed_questions(self):
        index = risk_catalog.render_index()
        for pattern in risk_catalog.load_catalog()["patterns"]:
            self.assertIn(pattern["id"] + " · ", index)
            self.assertNotIn(pattern["mechanism"], index)
        self.assertIn("не доказательства", index)

    def test_explicit_cross_domain_selection_returns_only_requested_details(self):
        result = json.loads(risk_catalog.read_patterns(["DEP01", "R03", "AI01", "DEP01"]))
        self.assertEqual([p["id"] for p in result["patterns"]], ["DEP01", "R03", "AI01"])
        self.assertIn("R03", result["patterns"][0]["related"])
        self.assertIn("нельзя использовать как evidence", result["notice"])
        self.assertEqual(result["catalog_version"], risk_catalog.load_catalog()["version"])

    def test_invalid_requests_cannot_load_arbitrary_files_or_expand_unboundedly(self):
        for request in (None, "R01", [], [1], [{}], ["R01"] * 9,
                        ["../../secrets"], ["R01", "UNKNOWN"]):
            with self.subTest(request=request), self.assertRaises(ValidationError):
                risk_catalog.read_patterns(request)

    def test_missing_malformed_or_incomplete_catalog_fails_explicitly(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "patterns.json"
            with patch.object(risk_catalog, "CATALOG_PATH", path):
                with self.assertRaises(ValidationError):
                    risk_catalog.load_catalog()
                for text in ("{", '{"schema_version": 2}', '{"schema_version": 1, "patterns": []}'):
                    path.write_text(text, encoding="utf-8")
                    with self.assertRaises(ValidationError):
                        risk_catalog.load_catalog()

    def test_invalid_template_and_dangling_links_rejected(self):
        original = risk_catalog.load_catalog()
        for key, value in (("reject_when", []), ("possible_controls", [""]),
                           ("domain", []), ("related", ["ABSENT"]),
                           ("related", ["R01"]), ("id", "../file")):
            data = copy.deepcopy(original)
            data["patterns"][0][key] = value
            with self.subTest(key=key, value=value), self.assertRaises(ValidationError):
                risk_catalog.validate_catalog(data)
        data = copy.deepcopy(original)
        data["patterns"].append(data["patterns"][0])
        with self.assertRaises(ValidationError):
            risk_catalog.validate_catalog(data)


if __name__ == "__main__":
    unittest.main()

"""Каталог образов результата, вшитый в пакет.

Инициатив шестьдесят с лишним; искать нужный `.md` руками и копировать его в
форму — лишняя работа и лишний способ ошибиться.
"""

import unittest

from pko.errors import PkoError
from pko.initiatives import Initiative, all_initiatives, find
from pko.progress.plan_input import parse_plan_text


class CatalogContentTest(unittest.TestCase):
    def setUp(self):
        self.items = all_initiatives()
        if not self.items:
            self.skipTest("каталог не собран (scripts/build_initiatives.py)")

    def test_catalog_is_not_empty(self):
        self.assertGreaterEqual(len(self.items), 50)

    def test_every_initiative_has_identity_and_bullets(self):
        for item in self.items:
            with self.subTest(item=item.id):
                self.assertTrue(item.id)
                self.assertTrue(item.project)
                self.assertTrue(item.bullets)

    def test_identifiers_are_unique(self):
        ids = [item.id for item in self.items]
        self.assertEqual(len(ids), len(set(ids)))

    def test_round_trip_keeps_every_bullet(self):
        """Каталог хранит разобранные части, а дальше идёт тот же парсер.

        Если сборка обратно в текст теряет буллиты, инициатива из каталога
        оценится иначе, чем тот же текст, вставленный руками, — а расходиться
        этим двум путям нельзя.
        """
        for item in self.items:
            with self.subTest(item=item.id):
                plan = parse_plan_text(item.to_text())
                restored = [b for stage in plan.items for b in stage.criteria]
                self.assertEqual(restored, item.bullets)

    def test_round_trip_keeps_names(self):
        item = self.items[0]
        plan = parse_plan_text(item.to_text())
        self.assertEqual(plan.context.get("project_name"), item.project)
        if item.client_path:
            self.assertEqual(plan.context.get("client_path_name"), item.client_path)


class CatalogLookupTest(unittest.TestCase):
    ITEMS = [
        Initiative(id="alpha-agent", project="Альфа агент", client_path="ММБ",
                   bullets=["Первый пункт"]),
        Initiative(id="beta-agent", project="Бета агент", bullets=["Второй пункт"]),
        Initiative(id="beta-agent-2", project="Бета агент для сервиса",
                   bullets=["Третий пункт"]),
    ]

    def setUp(self):
        from pko.initiatives import catalog
        self._original = catalog._load
        catalog._load = lambda: tuple(self.ITEMS)
        self.addCleanup(setattr, catalog, "_load", self._original)

    def test_exact_id_wins_over_name_search(self):
        """Скрипты и ссылки ходят по идентификатору: подмена «похожим»
        превратила бы воспроизводимый прогон в лотерею."""
        self.assertEqual(find("beta-agent").id, "beta-agent")

    def test_unique_name_fragment_resolves(self):
        self.assertEqual(find("Альфа").id, "alpha-agent")

    def test_ambiguous_query_asks_to_narrow(self):
        with self.assertRaises(PkoError) as ctx:
            find("Бета")
        self.assertIn("подходит", ctx.exception.message)

    def test_unknown_query_is_a_clean_error(self):
        with self.assertRaises(PkoError) as ctx:
            find("такого нет")
        self.assertIn("не найдена", ctx.exception.message)

    def test_empty_query_is_refused(self):
        with self.assertRaises(PkoError):
            find("   ")

    def test_title_reads_path_and_project_together(self):
        self.assertEqual(self.ITEMS[0].title, "ММБ: Альфа агент")
        self.assertEqual(self.ITEMS[1].title, "Бета агент")


if __name__ == "__main__":
    unittest.main()

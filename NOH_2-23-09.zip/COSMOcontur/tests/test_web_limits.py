"""Пределы сервиса: очередь прогонов, потолок времени сессии, ZIP-бомба.

Проверки выросли из подготовки к стенду. На своей машине всё это не видно:
прогон один, времени не жалко, архивы свои. На стенде каждый из трёх пределов
отсутствовал бы ровно до первого плохого дня — и стоил бы пода целиком.
"""

from __future__ import annotations

import io
import os
import threading
import unittest
import zipfile
from pathlib import Path

from pko.errors import PkoError
from pko.progress import local_source, matcher
from pko.web import analyses


class ParallelSlots(unittest.TestCase):
    """Одновременных прогонов ограниченное число, остальные ждут очереди."""

    def setUp(self) -> None:
        self._slots = analyses._SLOTS
        self._max = analyses.MAX_PARALLEL
        self.addCleanup(setattr, analyses, "_SLOTS", self._slots)
        self.addCleanup(setattr, analyses, "MAX_PARALLEL", self._max)

    def test_env_sets_the_limit(self) -> None:
        saved = os.environ.get("PKO_MAX_PARALLEL")
        self.addCleanup(
            lambda: os.environ.__setitem__("PKO_MAX_PARALLEL", saved)
            if saved is not None else os.environ.pop("PKO_MAX_PARALLEL", None))
        os.environ["PKO_MAX_PARALLEL"] = "5"
        self.assertEqual(analyses._max_parallel(), 5)

    def test_garbage_falls_back_to_the_default(self) -> None:
        """Опечатка в переменной окружения не должна ронять сервер на старте."""
        saved = os.environ.get("PKO_MAX_PARALLEL")
        self.addCleanup(
            lambda: os.environ.__setitem__("PKO_MAX_PARALLEL", saved)
            if saved is not None else os.environ.pop("PKO_MAX_PARALLEL", None))
        os.environ["PKO_MAX_PARALLEL"] = "две штуки"
        self.assertEqual(analyses._max_parallel(), analyses.DEFAULT_MAX_PARALLEL)
        os.environ["PKO_MAX_PARALLEL"] = "0"
        self.assertEqual(analyses._max_parallel(), 1)

    def test_second_run_waits_and_says_so(self) -> None:
        """Лишний прогон не отклоняется и не стартует — он в очереди."""
        analyses._SLOTS = threading.BoundedSemaphore(1)
        held = analyses._SLOTS.acquire()
        self.assertTrue(held)

        job = analyses.AnalysisJob(id="an_test")
        started = threading.Event()

        def body() -> None:
            analyses._execute(
                job, journey_text="x", repository="", branch=None, uploads=[],
                tmp_dir=Path(os.devnull).parent / "pko-not-used",
                spec=None, description=None,
            )
            started.set()

        worker = threading.Thread(target=body, daemon=True)
        worker.start()
        # Слот занят: прогон обязан сообщить об ожидании и не начаться.
        event = job.events.get(timeout=5)
        self.assertEqual(event["phase"], "queued")
        self.assertFalse(started.is_set())

        analyses._SLOTS.release()
        worker.join(timeout=10)
        self.assertTrue(started.is_set())


class SessionDeadline(unittest.TestCase):
    """Потолок времени на сессию агента."""

    def setUp(self) -> None:
        self.saved = os.environ.get("PKO_MAX_SESSION_SECONDS")
        self.addCleanup(
            lambda: os.environ.__setitem__("PKO_MAX_SESSION_SECONDS", self.saved)
            if self.saved is not None
            else os.environ.pop("PKO_MAX_SESSION_SECONDS", None))

    def test_default_budget(self) -> None:
        os.environ.pop("PKO_MAX_SESSION_SECONDS", None)
        self.assertEqual(matcher._session_budget(), matcher.DEFAULT_SESSION_SECONDS)

    def test_zero_means_no_limit(self) -> None:
        """Долгий прогон под присмотром человека — законный случай."""
        os.environ["PKO_MAX_SESSION_SECONDS"] = "0"
        self.assertEqual(matcher._session_budget(), 0.0)

    def test_garbage_falls_back_to_the_default(self) -> None:
        os.environ["PKO_MAX_SESSION_SECONDS"] = "полчаса"
        self.assertEqual(matcher._session_budget(), matcher.DEFAULT_SESSION_SECONDS)

    # Что сессия действительно останавливается по времени и закрывается тем,
    # что успела оценить, проверяет test_progress_matcher: там есть
    # скриптованный агент и полный прогон.


class ZipBomb(unittest.TestCase):
    """Бюджет распаковки считается до чтения элемента в память."""

    def _archive(self, name: str, data: bytes) -> tuple[str, bytes]:
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(name, data)
        return ("repo.zip", buffer.getvalue())

    def test_declared_size_is_checked_before_reading(self) -> None:
        """Ноль-байты жмутся в тысячи раз: маленький архив, огромная память."""
        payload = b"\0" * (local_source.MAX_WORKSPACE_BYTES + 1)
        upload = self._archive("big.bin", payload)
        self.assertLess(len(upload[1]), 1_000_000)

        reads: list[str] = []
        original = zipfile.ZipFile.read

        def counting_read(self_, member, pwd=None):  # type: ignore[no-untyped-def]
            reads.append(getattr(member, "filename", str(member)))
            return original(self_, member, pwd)

        zipfile.ZipFile.read = counting_read
        self.addCleanup(setattr, zipfile.ZipFile, "read", original)

        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(PkoError) as ctx:
                local_source.build_target_repo_from_uploads([upload], Path(tmp))
        self.assertIn("слишком большие", ctx.exception.message.lower())
        # Главное: до чтения в память дело не дошло.
        self.assertEqual(reads, [])

    def test_normal_archive_still_extracts(self) -> None:
        import tempfile

        upload = self._archive("src/main.py", b"def main():\n    return 1\n")
        with tempfile.TemporaryDirectory() as tmp:
            target = local_source.build_target_repo_from_uploads([upload], Path(tmp))
        self.assertIn("src/main.py", target.tree.files)


if __name__ == "__main__":
    unittest.main()

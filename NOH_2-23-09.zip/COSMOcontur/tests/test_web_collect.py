"""Сбор ответов из вернувшихся HTML-отчётов.

Отчёт уходит письмом и возвращается письмом же — с ответами внутри файла.
Шестьдесят инициатив это шестьдесят писем: разбирать их поштучно никто не
станет, поэтому ответы сводятся в ту же базу, что и у веб-формы.
"""

import json
import tempfile
import unittest
from pathlib import Path

from pko.render.dashboard_html import render_dashboard_html
from pko.web.collect import answers_of, collect, collect_file, report_of
from pko.web.feedback import FeedbackStore

DATA = {
    "meta": {"project_name": "Демо-инициатива", "client_path_name": "Key Clients"},
    "readiness": 50,
    "items": [{
        "title": "Этап",
        "description": "",
        "percent": 50,
        "assessment": [
            {"text": "Первый пункт", "applicable": True, "status": "planned",
             "proof": "Похожее есть, но целиком не нашлось.", "how": "Пока вручную."},
            {"text": "Второй пункт", "applicable": True, "status": "done",
             "proof": "Код есть и работает.", "how": "Работает так."},
        ],
    }],
}


def report_with(answers: dict) -> str:
    """Отчёт, вернувшийся с ответами — ровно как его сохраняет страница."""
    html = render_dashboard_html(DATA)
    assert "window.__ANSWERS__ = {};" in html
    return html.replace(
        "window.__ANSWERS__ = {};",
        "window.__ANSWERS__ = " + json.dumps(answers, ensure_ascii=False) + ";",
        1,
    )


class ParseReturnedReportTest(unittest.TestCase):
    def test_fresh_report_has_no_answers(self):
        self.assertEqual(answers_of(render_dashboard_html(DATA)), {})

    def test_answers_are_read_back(self):
        html = report_with({"0": {"verdict": "reject", "comment": "Сделано."}})
        self.assertEqual(answers_of(html)["0"]["comment"], "Сделано.")

    def test_report_data_is_read_back(self):
        data = report_of(report_with({}))
        self.assertEqual(data["meta"]["project_name"], "Демо-инициатива")

    def test_broken_answers_do_not_crash(self):
        self.assertEqual(answers_of("window.__ANSWERS__ = {сломано};"), {})

    def test_entries_without_verdict_are_ignored(self):
        html = report_with({"0": {"comment": "без вердикта"}})
        self.assertEqual(answers_of(html), {})

    def test_foreign_html_yields_nothing(self):
        self.assertEqual(answers_of("<html><body>письмо</body></html>"), {})


class CollectIntoStoreTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.store = FeedbackStore(path=self.dir / "f.db")
        self.addCleanup(self.store.close)

    def _write(self, name: str, answers: dict) -> Path:
        path = self.dir / name
        path.write_text(report_with(answers), encoding="utf-8")
        return path

    def test_answer_keeps_the_bullet_it_belongs_to(self):
        path = self._write("a.html", {"0": {"verdict": "reject", "comment": "Сделано."}})
        self.assertEqual(collect_file(path, self.store), 1)
        [saved] = self.store.list()
        self.assertEqual(saved.bullet_index, 0)
        self.assertEqual(saved.bullet_text, "Первый пункт")
        self.assertEqual(saved.agent_status, "planned")
        self.assertEqual(saved.project_name, "Демо-инициатива")

    def test_accept_without_comment_is_saved(self):
        path = self._write("a.html", {"1": {"verdict": "accept", "comment": ""}})
        self.assertEqual(collect_file(path, self.store), 1)

    def test_several_letters_are_collected_at_once(self):
        self._write("one.html", {"0": {"verdict": "reject", "comment": "Раз."}})
        self._write("two.html", {"0": {"verdict": "accept_with_note", "comment": "Два."}})
        result = collect([self.dir], self.store)
        self.assertEqual(result.saved, 2)
        self.assertEqual(result.files_with_answers, 2)
        self.assertEqual(len(self.store.list()), 2)

    def test_report_without_answers_is_reported_not_skipped_silently(self):
        (self.dir / "empty.html").write_text(render_dashboard_html(DATA), encoding="utf-8")
        result = collect([self.dir], self.store)
        self.assertEqual(result.saved, 0)
        self.assertEqual(result.files_without_answers, ["empty.html"])

    def test_answers_land_in_the_same_store_as_the_web_form(self):
        """Ответы из письма и с экрана должны читаться одним запросом."""
        self._write("a.html", {"0": {"verdict": "reject", "comment": "Из письма."}})
        collect([self.dir], self.store)
        from pko.web.feedback import Dispute
        self.store.save(Dispute(analysis_id="an_web", bullet_index=0,
                                verdict="accept"))
        self.assertEqual(len(self.store.list()), 2)

    def test_collecting_the_same_folder_twice_does_not_duplicate(self):
        """Письма приходят по одному, а сбор запускают по всей папке."""
        self._write("a.html", {"0": {"verdict": "reject", "comment": "Сделано."},
                               "1": {"verdict": "accept", "comment": ""}})
        first = collect([self.dir], self.store)
        second = collect([self.dir], self.store)
        self.assertEqual(first.saved, 2)
        self.assertEqual(second.saved, 0)
        self.assertEqual(len(self.store.list()), 2)

    def test_changed_answer_is_added_as_a_newer_one(self):
        self._write("a.html", {"0": {"verdict": "reject", "comment": "Сделано."}})
        collect([self.dir], self.store)
        self._write("a.html", {"0": {"verdict": "accept_with_note", "comment": "Частично."}})
        collect([self.dir], self.store)
        rows = self.store.list()
        self.assertEqual(len(rows), 2)
        # Свежий сверху — его экран и считает текущим.
        self.assertEqual(rows[0].verdict, "accept_with_note")

    def test_unacceptable_answer_is_skipped_not_fatal(self):
        """Один негодный ответ не обрывает разбор файла на середине."""
        self._write("a.html", {"0": {"verdict": "reject", "comment": ""},
                               "1": {"verdict": "accept", "comment": ""}})
        result = collect([self.dir], self.store)
        self.assertEqual(result.saved, 1)
        self.assertEqual(len(result.skipped), 1)
        self.assertIn("пункт 0", result.skipped[0])
        self.assertEqual(len(self.store.list()), 1)


if __name__ == "__main__":
    unittest.main()

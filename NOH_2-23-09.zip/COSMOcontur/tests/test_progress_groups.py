"""Темы отчёта объявляет модель, а держит их код.

Просьбы в промпте оказалось мало: на живом прогоне модель выдала 11 тем на
12 буллитов, и отчёт превратился в список блоков по одному пункту.
"""

from __future__ import annotations

import unittest

from fixture_support import ensure_fixture
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.progress.matcher import _accept_groups, _accept_stage, _match_group
from pko.progress.schema import MAX_GROUPS, PlanItem

GROUPS = ["Обработка запросов", "Сценарный анализ", "Документы"]


class AcceptGroups(unittest.TestCase):
    def test_normal_list_is_accepted(self) -> None:
        names, error = _accept_groups({"groups": GROUPS})
        self.assertIsNone(error)
        self.assertEqual(names, GROUPS)

    def test_more_than_four_is_rejected(self) -> None:
        names, error = _accept_groups({"groups": [f"Тема {i}" for i in range(1, 8)]})
        self.assertEqual(names, [])
        self.assertIn("от 2 до 4", error)

    def test_single_theme_is_rejected(self) -> None:
        """Одна тема — это не группировка, а отсутствие группировки."""
        _, error = _accept_groups({"groups": ["Функционал"]})
        self.assertTrue(error)

    def test_duplicates_collapse(self) -> None:
        names, error = _accept_groups({"groups": ["Расчёты", "расчёты", "Документы"]})
        self.assertIsNone(error)
        self.assertEqual(names, ["Расчёты", "Документы"])

    def test_empty_names_are_dropped(self) -> None:
        _, error = _accept_groups({"groups": ["Расчёты", "  ", ""]})
        self.assertTrue(error, "остаётся одна тема — этого мало")

    def test_not_a_list(self) -> None:
        self.assertTrue(_accept_groups({"groups": "Расчёты"})[1])

    def test_limit_matches_the_report(self) -> None:
        self.assertEqual(MAX_GROUPS, 4)


class MatchGroup(unittest.TestCase):
    def test_exact_match(self) -> None:
        self.assertEqual(_match_group("Документы", GROUPS), "Документы")

    def test_case_insensitive(self) -> None:
        self.assertEqual(_match_group("документы", GROUPS), "Документы")

    def test_unknown_returns_none(self) -> None:
        self.assertIsNone(_match_group("Интеграции", GROUPS))

    def test_empty_returns_none(self) -> None:
        self.assertIsNone(_match_group("  ", GROUPS))


# Не зелёный статус требует развёрнутой «Проверки»: гейт хочет увидеть,
# что похожее нашлось и чего именно не нашлось.
_PROOF = (
    "Похожее в коде есть: приём обращения работает. Дальнейшей обработки "
    "не нашлось — маршрутизации по исполнителям в коде нет."
)


# «Как работает» гейт требует непустым у любого оценённого буллита.
_HOW = "Система принимает обращение и регистрирует его в списке задач."


class StageRespectsGroups(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        repo = GitRepo(ensure_fixture())
        cls.tree = Tree.at(repo, repo.resolve("master"))
        cls.item = PlanItem(id="a", title="Этап", criteria=["Первый пункт", "Второй пункт"])

    def _args(self, first_group: str, second_group: str) -> dict:
        return {
            "item_id": "a",
            "applicable": True,
            "criteria": [
                {"applicable": True, "status": "planned", "group": first_group,
                 "proof": _PROOF, "how": _HOW},
                {"applicable": True, "status": "planned", "group": second_group,
                 "proof": _PROOF, "how": _HOW},
            ],
        }

    def test_declared_groups_pass(self) -> None:
        verdict, error, _ = _accept_stage(
            self.item, self._args("Документы", "Сценарный анализ"), self.tree, groups=GROUPS,
        )
        self.assertIsNone(error)
        self.assertEqual([c.group for c in verdict.criteria], ["Документы", "Сценарный анализ"])

    def test_unknown_group_is_rejected_with_the_allowed_list(self) -> None:
        verdict, error, gate = _accept_stage(
            self.item, self._args("Интеграции", "Документы"), self.tree, groups=GROUPS,
        )
        self.assertIsNone(verdict)
        self.assertTrue(gate)
        self.assertIn("Интеграции", error)
        self.assertIn("Обработка запросов", error)

    def test_tolerant_mode_snaps_to_the_first_theme(self) -> None:
        """Новый блок заводить нельзя: их ровно столько, сколько объявлено."""
        verdict, error, _ = _accept_stage(
            self.item, self._args("Интеграции", "Документы"), self.tree,
            tolerant=True, groups=GROUPS,
        )
        self.assertIsNone(error)
        self.assertEqual(verdict.criteria[0].group, GROUPS[0])
        self.assertEqual(verdict.criteria[1].group, "Документы")

    def test_without_declared_groups_anything_passes(self) -> None:
        """Модель тем не объявила — сводит код, а не гейт."""
        verdict, error, _ = _accept_stage(
            self.item, self._args("Своя тема", "Другая тема"), self.tree, groups=[],
        )
        self.assertIsNone(error)
        self.assertEqual(verdict.criteria[0].group, "Своя тема")


if __name__ == "__main__":
    unittest.main()

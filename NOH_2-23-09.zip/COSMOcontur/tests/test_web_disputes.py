"""Возражения команд: три ответа, обязательный комментарий, общий реестр.

Отчёт — утверждение о чужой работе, и у команды должно быть право с ним не
согласиться. Возражения складываются в базу, чтобы разбирать их в одном
месте, а не открывая шестьдесят файлов.
"""

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from fastapi.testclient import TestClient

import pko.llm.client as client_module
from agent_script import JOURNEY_TEXT, full_session
from fixture_support import ensure_fixture, scripted_responses
from pko.errors import PkoError
from pko.llm.client import ChatClient
from pko.web import feedback
from pko.web.app import app

ENV_KEYS = ("PKO_ASSEMBLER_BASE_URL", "PKO_ASSEMBLER_MODEL", "PKO_ASSEMBLER_API_KEY")


class FeedbackStoreTest(unittest.TestCase):
    """Хранилище отдельно от веба: правила ответа не зависят от транспорта."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store = feedback.FeedbackStore(path=Path(self.tmp.name) / "f.db")
        self.addCleanup(self.store.close)

    def _dispute(self, **kwargs) -> feedback.Dispute:
        base = dict(analysis_id="an_1", bullet_index=0, verdict="accept")
        base.update(kwargs)
        return feedback.Dispute(**base)

    def test_accept_needs_no_comment(self):
        saved = self.store.save(self._dispute())
        self.assertGreater(saved.id, 0)
        self.assertTrue(saved.created_at)

    def test_reject_without_comment_is_refused(self):
        """Возражение без объяснения нечем обработать."""
        with self.assertRaises(PkoError) as ctx:
            self.store.save(self._dispute(verdict="reject"))
        self.assertIn("комментари", ctx.exception.message.lower())

    def test_accept_with_note_without_comment_is_refused(self):
        with self.assertRaises(PkoError):
            self.store.save(self._dispute(verdict="accept_with_note"))

    def test_unknown_verdict_is_refused(self):
        with self.assertRaises(PkoError):
            self.store.save(self._dispute(verdict="maybe"))

    def test_comment_is_stored_and_trimmed(self):
        saved = self.store.save(self._dispute(
            verdict="reject", comment="  Пункт   сделан,\n вот  где  ",
        ))
        self.assertEqual(saved.comment, "Пункт сделан, вот где")

    def test_long_comment_is_capped(self):
        saved = self.store.save(self._dispute(verdict="reject", comment="я" * 5000))
        self.assertEqual(len(saved.comment), feedback.MAX_COMMENT_CHARS)

    def test_survives_reopening_the_file(self):
        """Реестр анализов живёт в памяти; возражения так терять нельзя."""
        self.store.save(self._dispute(verdict="reject", comment="не согласны"))
        self.store.close()
        again = feedback.FeedbackStore(path=self.store.path)
        self.addCleanup(again.close)
        self.assertEqual(len(again.list()), 1)
        self.assertEqual(again.list()[0].comment, "не согласны")

    def test_only_the_tools_own_directory_is_hardened(self):
        """Права ужимаются на `~/.pko`, а не на каталог, выбранный оператором.

        Прежний вызов закрывал ещё и родителя: при пути по умолчанию —
        домашний каталог целиком, при `/tmp/feedback.db` — `/tmp` и `/`.
        """
        with mock.patch.object(feedback, "harden_dir") as harden:
            self.store.connect()
        harden.assert_not_called()

        default_dir = Path(self.tmp.name) / ".pko"
        with mock.patch.object(feedback, "DEFAULT_DB_PATH", default_dir / "feedback.db"), \
                mock.patch.object(feedback, "harden_dir") as harden:
            store = feedback.FeedbackStore(path=default_dir / "feedback.db")
            self.addCleanup(store.close)
            store.connect()
        harden.assert_called_once_with(default_dir)

    def test_list_filters_by_analysis_and_orders_newest_first(self):
        self.store.save(self._dispute(analysis_id="an_1", bullet_index=0))
        self.store.save(self._dispute(analysis_id="an_2", bullet_index=1))
        self.store.save(self._dispute(analysis_id="an_1", bullet_index=2))
        only_first = self.store.list(analysis_id="an_1")
        self.assertEqual([d.bullet_index for d in only_first], [2, 0])
        self.assertEqual(len(self.store.list()), 3)


class DisputeApiTest(unittest.TestCase):
    """Работать должно по ссылке, без пересылки файлов."""

    def setUp(self):
        self.client = TestClient(app)

        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        client_module.DEFAULT_CACHE_DIR = Path(self.tmp.name) / "llm-cache"
        feedback.reset_store(feedback.FeedbackStore(path=Path(self.tmp.name) / "f.db"))
        self.addCleanup(feedback.reset_store, None)

        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)
        ChatClient._create = scripted_responses(*full_session())

        self._env = {k: os.environ.get(k) for k in ENV_KEYS}
        os.environ.update({
            "PKO_ASSEMBLER_BASE_URL": "https://stub.local/v1",
            "PKO_ASSEMBLER_MODEL": "stub-model",
            "PKO_ASSEMBLER_API_KEY": "x",
        })

        def _restore():
            for key, value in self._env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

        self.addCleanup(_restore)

        created = self.client.post("/api/analyses", data={
            "journey_text": JOURNEY_TEXT, "repository": str(ensure_fixture()),
        })
        self.analysis_id = created.json()["analysis_id"]
        self.client.get(f"/api/analyses/{self.analysis_id}/events")

    def _post(self, **data):
        return self.client.post(
            f"/api/analyses/{self.analysis_id}/disputes", data=data,
        )

    def test_dispute_is_saved_with_context_from_the_report(self):
        """Контекст берётся из анализа, а не из формы: приписать возражение
        к чужому пункту клиент не должен."""
        resp = self._post(bullet_index=1, verdict="reject", comment="Пункт сделан.")
        self.assertEqual(resp.status_code, 200, resp.text)
        body = resp.json()
        self.assertEqual(body["verdict"], "reject")
        self.assertEqual(body["verdict_label"], "Отклонить")
        self.assertTrue(body["bullet_text"])
        self.assertEqual(body["agent_status"], "planned")
        self.assertTrue(body["project_name"])

    def test_accept_needs_no_comment_over_http(self):
        self.assertEqual(self._post(bullet_index=0, verdict="accept").status_code, 200)

    def test_reject_without_comment_is_a_clean_400(self):
        resp = self._post(bullet_index=0, verdict="reject")
        self.assertEqual(resp.status_code, 400)
        self.assertIn("комментари", resp.json()["message"].lower())

    def test_bullet_out_of_range_is_a_clean_400(self):
        resp = self._post(bullet_index=99, verdict="accept")
        self.assertEqual(resp.status_code, 400)
        self.assertIn("не найден", resp.json()["message"])

    def test_unknown_analysis_is_a_clean_400(self):
        resp = self.client.post("/api/analyses/an_nope/disputes",
                                data={"bullet_index": 0, "verdict": "accept"})
        self.assertEqual(resp.status_code, 400)

    def test_disputes_are_listed_per_analysis_and_globally(self):
        self._post(bullet_index=0, verdict="accept")
        self._post(bullet_index=1, verdict="accept_with_note", comment="Частично.")

        one = self.client.get(f"/api/analyses/{self.analysis_id}/disputes").json()
        self.assertEqual(one["total"], 2)

        # Всё в одном месте — ради этого механика и заводилась.
        every = self.client.get("/api/disputes").json()
        self.assertEqual(every["total"], 2)
        self.assertEqual(every["items"][0]["analysis_id"], self.analysis_id)


if __name__ == "__main__":
    unittest.main()

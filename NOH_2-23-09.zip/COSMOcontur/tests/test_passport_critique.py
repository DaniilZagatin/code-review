"""Регрессии по критике паспорта от 23.09: факты, сценарии и представление.

Фикстуры искусственные; исходный банковский отчёт не включается в репозиторий.
"""
from __future__ import annotations

import unittest
from types import SimpleNamespace

import test_passport_gate as fixtures
from pko.progress.connectivity import ConnectivityState, handle_scenarios
from pko.progress.passport_agent import (
    _Node, _PassportSession, _handle_submit_node, render_scenarios_digest,
)
from pko.progress.passport_gate import PassportCheck, check_node_fields, check_relation, normalize_passport
from pko.progress.schema import (
    ConnectivityReview, CriterionVerdict, EvidenceRef, Handoff, HandoffCheck, Scenario,
    passport_requirement_counts, passport_node_state,
)
from pko.render.passport_map import build_passport_map


def scenario():
    return Scenario(id="scenario-1", title="Продление размещения", entry="Срок договора подходит к окончанию",
                    outcome="Клиенту предложен вариант продления", steps=["Наступает срок", "Подобран вариант", "Получено предложение"],
                    bullets=["Показан оффер."], critical=True)


class PassportCritiqueTest(unittest.TestCase):
    def build(self, data, s=None):
        return build_passport_map(fixtures.PassportMapTest()._model(normalize_passport(data), s))

    def test_disabled_effect_is_not_implemented_even_with_done_bullet(self):
        data = fixtures._valid()
        data["nodes"]["operation-1"].update(bullets=["Подобран продукт."], fields={
            "4.5.4": fixtures._f("Должны загружаться траты. Фактически вызов закомментирован и заменён нулём.", fixtures.EST),
            "4.5.5": fixtures._f("Вход — клиент; выход — траты.", fixtures.EST),
        })
        nodes = {n["id"]: n for n in self.build(data)["nodes"]}
        self.assertEqual(nodes["operation-1"]["implementation_status"], "not_implemented")
        self.assertEqual(nodes["process-1"]["implementation_status"], "partial")
        self.assertTrue(any("эффект" in p for p in nodes["operation-1"]["problems"]))

    def test_unconfirmed_negative_and_missing_retry_do_not_erase_effect(self):
        data = fixtures._valid()
        fields = {
            "4.5.4": fixtures._f("Результат получен от исполнителя.", fixtures.EST),
            "4.5.5": fixtures._f("На выходе подтверждённый договор.", fixtures.EST),
            "4.5.6": fixtures._f("Вызов повторной отправки закомментирован.", fixtures.EST),
        }
        data["nodes"]["operation-1"]["fields"] = fields
        nodes = {n["id"]: n for n in self.build(data)["nodes"]}
        self.assertEqual(nodes["operation-1"]["implementation_status"], "implemented")
        fields["4.5.4"] = fixtures._f("Гипотеза: вызов закомментирован.", "Гипотеза: нужно прочитать обработчик")
        nodes = {n["id"]: n for n in self.build(data)["nodes"]}
        self.assertEqual(nodes["operation-1"]["implementation_status"], "unknown")

    def test_planned_overrides_legacy_conflicting_done_bullet(self):
        self.assertEqual(passport_node_state("not_implemented", "implemented", planned=True), "not_implemented")

    def test_negative_detection_does_not_confuse_conditions_and_history(self):
        data = fixtures._valid()
        for value in ("Вызов не закомментирован, данные загружаются.",
                      "Если вызов закомментирован, данные не загрузятся.",
                      "Ранее вызов был закомментирован. Сейчас данные получены."):
            data["nodes"]["operation-1"]["fields"] = {
                "4.5.4": fixtures._f(value, fixtures.EST),
                "4.5.5": fixtures._f("Вход — запрос; выход — результат.", fixtures.EST),
            }
            nodes = {n["id"]: n for n in self.build(data)["nodes"]}
            self.assertEqual(nodes["operation-1"]["implementation_status"], "implemented", value)

    def test_risks_roll_up_through_all_parents_without_badges(self):
        data = fixtures._valid()
        data["risks"] = [{"title": "Неверный результат", "primary_node": "operation-1",
                          "linked_nodes": ["operation-1"], "confidence": "inferred", "scope": "local"}]
        nodes = {n["id"]: n for n in self.build(data)["nodes"]}
        for nid in ("journey-1", "process-1", "process-2", "bbb-1"):
            self.assertEqual(nodes[nid]["risks"], [])
            self.assertEqual(nodes[nid]["descendant_risks"], ["risk-1"])
        self.assertEqual(nodes["operation-1"]["risks"], ["risk-1"])
        self.assertEqual(nodes["operation-1"]["descendant_risks"], [])

    def test_missing_process_is_one_break_with_all_transition_details(self):
        data = fixtures._valid()
        data["nodes"]["process-2"].update(planned=True, scenario="scenario-1", bullets=["Показан оффер."])
        s = scenario()
        s.handoffs.extend([Handoff(step=i, checks=[HandoffCheck(check="reachability", result="broken",
                        note="Обработчик отсутствует", evidence=[EvidenceRef(path="app.py", line=1,
                        basis="routes", verified=True, reason="ok")])]) for i in (0, 1)])
        result = self.build(data, s)
        self.assertEqual(len(result["breaks"]), 1)
        br = result["breaks"][0]
        self.assertEqual(br["nodes"], ["process-2"])
        self.assertTrue(br["critical"])
        self.assertEqual(len(br["transitions"]), 2)
        self.assertEqual(result["summary"]["handoffs_total"], 2)

    def test_scenario_context_retains_entry_result_and_verified_trace(self):
        s = scenario()
        s.handoffs.extend([Handoff(step=0, checks=[HandoffCheck(check="reachability", result="broken",
            note="Переход не подключён", evidence=[EvidenceRef(path="app.py", line=12, basis="renew",
            verified=True, reason="ok", note="регистрация отключена")])])])
        text = render_scenarios_digest(ConnectivityReview(scenarios=[s]))
        for expected in (s.entry, s.outcome, s.bullets[0], "Переход не подключён", "app.py:12", "регистрация отключена"):
            self.assertIn(expected, text)
        self.assertNotIn("— broken", text)

    def test_planned_process_gets_target_fields_without_invented_runtime(self):
        s = scenario()
        state = _PassportSession(current="process-1", scenarios={s.id: s.steps}, scenario_titles={s.id: s.title},
                                 scenario_context={s.id: {"entry": s.entry, "outcome": s.outcome}})
        state.nodes = {"journey-1": _Node(id="journey-1", name="Размещение", basis="путь", filled=True),
                       "process-1": _Node(id="process-1", name="Продление", basis="обещание", parents=["journey-1"])}
        answer = _handle_submit_node(state, {"id": "process-1", "name": "Продление", "basis": "Обещанный процесс отсутствует",
            "planned": True, "scenario": s.id,
            "fields": {"4.3.1": fixtures._f("Предлагает продолжить размещение после окончания срока.", "Выведено: обещание образа результата")}})
        self.assertIn("принят", answer)
        fields = state.nodes["process-1"].data["fields"]
        self.assertEqual(fields["4.3.4"]["value"], "План: " + s.entry)
        self.assertIn(s.outcome, fields["4.3.5"]["value"])
        self.assertNotIn("4.3.6", fields)

    def test_fully_done_share_is_not_weighted_readiness(self):
        criteria = [CriterionVerdict(applicable=True, status=s, proof="", how="")
                    for s in ("done", "done", "done", "limited", "partial", "planned")]
        counts = passport_requirement_counts(criteria)
        self.assertEqual(counts, {"total": 6, "done": 3, "done_percent": 50})
        criteria.append(CriterionVerdict(applicable=False, status="done", proof="", how=""))
        self.assertEqual(passport_requirement_counts(criteria), counts)

    def test_order_cycle_rejected_but_data_return_is_allowed(self):
        seen = {("bbb-1", "bbb-2", "precedes"), ("bbb-2", "bbb-3", "precedes")}
        for kind, expected in (("precedes", True), ("feeds", False)):
            check = PassportCheck()
            check_relation(check, {"from": "bbb-3", "to": "bbb-1", "kind": kind, "field": "result",
                "basis": "Подтверждённый порядок по прочитанному коду"}, {"bbb-1", "bbb-2", "bbb-3"}, set(seen))
            self.assertEqual(any("цикл" in e for e in check.errors), expected)

    def test_technical_business_meaning_is_rejected_but_source_is_allowed(self):
        for value, rejected in (("Маппит uid в состояние графа через post_invoke.", True),
                                ("Связывает обращение с нужным клиентом.", False)):
            check = PassportCheck()
            check_node_fields(check, "operation-1", {"name": "Определение клиента",
                "fields": {"4.5.1": fixtures._f(value, "Установлено: runtime.py, post_invoke маппит uid")}})
            self.assertEqual(bool(check.errors), rejected, check.errors)

    def test_duplicate_scenarios_rejected_transactionally(self):
        # Text guard needs only the known paths, no real repository or network.
        state = ConnectivityState(plan_bullets=["Предложен продукт"], tree=SimpleNamespace(files_set=set()))
        base = {"title": "Подбор", "entry": "Клиент просит предложение", "outcome": "Клиент получает продукт",
                "steps": ["Получены данные", "Выбран продукт"], "bullets": ["Предложен продукт"]}
        answer = handle_scenarios(state, {"scenarios": [base, {**base, "title": "Подбор с учётом трат"}]})
        self.assertIn("повторяет вход и результат", answer)
        self.assertFalse(state.declared)

"""Скачиваемый HTML-дашборд (`render/dashboard_html.py` + `dashboard_template.html`):
контракт данных и безопасность. Без сети, без LLM, без fastapi — шаблон и
подстановка JSON проверяются как чистый строковый рендер.

Сама вёрстка/интерактив (шевроны, клик, анимация) — vanilla JS в шаблоне,
в статическом HTML их нет; здесь проверяется, что данные агента доходят до
страницы в правильном виде и что тексты агента не могут сломать/инъецировать
разметку.
"""

import json
import unittest

from pko.render.dashboard_html import _DASHBOARD_TEMPLATE_PATH, render_dashboard_html


def _result(items, summary=None, readiness=1.0, title="Тестовый проект"):
    return {
        "meta": {"title": title, "repo": "demo/repo", "commit": "abc1234", "generated_at": "2026-01-01"},
        "readiness": readiness,
        "counts": {"DONE": len(items), "PARTIAL": 0, "NOT_STARTED": 0, "UNCLEAR": 0},
        "items": items,
        **({"summary": summary} if summary is not None else {}),
    }


def _item(title="API постановки задач", status="DONE", pct=100,
          assessment=None, description="Описание этапа", color="green", label="Сделано"):
    if assessment is None:
        assessment = [{"status": "done", "text": "Реализован", "comment": ""}]
    return {"title": title, "status": status, "pct": pct, "assessment": assessment,
            "description": description, "color": color, "label": label}


class DashboardHtmlTest(unittest.TestCase):
    def test_gaps_do_not_reach_the_downloadable_file(self):
        """Замечания отчёта в скачиваемый файл не идут — ни блоком, ни в данных.

        Файл уходит команде и руководству письмом; «статус без подтверждённой
        ссылки, нужна ручная проверка» — рабочий след для того, кто прогон
        запускал, и живёт в progress_model.json и в JSON API.
        """
        html = render_dashboard_html({**_result([_item()]), "gaps": ["Замечание раз"]})
        self.assertNotIn("Замечание раз", html)
        self.assertNotIn('"gaps"', html)
        self.assertNotIn('id="gaps"', html)

    def test_integrity_block_reaches_the_downloadable_file(self):
        """Связность — не замечание прогона, а часть отчёта.

        В отличие от `gaps` это предметное суждение о системе с
        подтверждёнными ссылками: письмо руководству без него теряет ответ на
        вопрос, собрано ли решение вообще.
        """
        integrity = {
            "level": "fragmented", "level_label": "Связность частичная",
            "note": "Части работают, соединены не все.",
            "flow": {"entry": "Запрос клиента", "steps": ["Регистрация"],
                     "outcome": "Задача у исполнителя", "complete": False,
                     "break_point": "Передача не происходит", "links": []},
            "flaws": [{"kind": "broken_chain", "kind_label": "Разрыв сквозного пути",
                       "severity": "blocker", "severity_label": "Блокирует замысел",
                       "title": "Заявка не уходит дальше", "detail": "Текст изъяна.",
                       "bullets": ["Буллит"], "links": []}],
        }
        html = render_dashboard_html({**_result([_item()]), "integrity": integrity})
        self.assertIn('"integrity"', html)
        self.assertIn("Заявка не уходит дальше", html)
        self.assertIn("Передача не происходит", html)
        # Блок и его отрисовка есть в самом шаблоне, а не дорисовываются извне.
        self.assertIn('id="integrity"', html)
        self.assertIn("renderIntegrity", html)
        # Блок свёрнут: отчёт обязан помещаться на один экран. Разворачивается
        # кнопкой, а на печати раскрывается сам.
        self.assertIn("integrity-toggle", html)
        self.assertIn(".integrity-body[hidden] { display: none; }", html)
        self.assertIn(".integrity-body, .integrity-body[hidden] { display: block !important; }", html)

    def test_marker_is_replaced_and_data_embedded(self):
        html = render_dashboard_html(_result([_item()]))
        self.assertNotIn("/*__DATA__*/", html)
        self.assertIn("window.__DATA__", html)

    def test_agent_texts_reach_the_page_json(self):
        html = render_dashboard_html(_result([_item(assessment=[{"status": "done", "text": "Эндпоинт реализован и подтверждён", "comment": ""}])]))
        self.assertIn("Эндпоинт реализован и подтверждён", html)
        self.assertIn("Тестовый проект", html)

    def test_readiness_rounds_to_percent_in_template(self):
        # Шаблон считает процент в JS из readiness; в JSON лежит сырое 0.4 —
        # проверяем, что оно дошло без искажения (округление делает JS).
        html = render_dashboard_html(_result([_item(status="PARTIAL", pct=40, color="amber",
                                                     label="Частично")], readiness=0.4))
        data = _extract_data(html)
        self.assertAlmostEqual(data["readiness"], 0.4)
        self.assertEqual(data["items"][0]["pct"], 40)

    def test_summary_is_present_when_provided(self):
        summary = {"conclusion": "Проект готов."}
        html = render_dashboard_html(_result([_item()], summary=summary))
        data = _extract_data(html)
        self.assertEqual(data["summary"]["conclusion"], "Проект готов.")
        self.assertIn("Проект готов.", html)

    def test_summary_is_absent_when_none(self):
        html = render_dashboard_html(_result([_item()]))
        data = _extract_data(html)
        self.assertNotIn("summary", data)

    def test_script_injection_in_agent_text_is_neutralised(self):
        # Текст агента со `</script>` не должен закрывать тег <script> с данными
        # и не должен инъецировать разметку. `<` заменяется на \u003c в JSON.
        poison = "</script><img src=x onerror=alert(1)>"
        clean = render_dashboard_html(_result([_item(assessment=[{"status": "done", "text": "чистый текст", "comment": ""}])]))
        poisoned = render_dashboard_html(_result([_item(assessment=[{"status": "done", "text": poison, "comment": ""}])]))
        # В шаблоне два <script> (данные + код) — инъекция не должна добавить
        # ни одного закрывающего тега сверх базового числа.
        self.assertEqual(poisoned.count("</script>"), clean.count("</script>"))
        # literal `<img` не выжил — `<` заменён на \u003c, тег не формируется.
        # `onerror` как подстрока в данных остаётся, но через textContent она
        # не исполнится — поэтому эту подстроку отдельно не проверяем.
        self.assertNotIn("<img", poisoned)
        # Текст восстанавливается JS-парсером: \u003c/script> → </script>
        self.assertIn("\\u003c/script>", poisoned)

    def test_empty_items_renders_without_error(self):
        html = render_dashboard_html(_result([], readiness=0.0))
        self.assertIn("window.__DATA__", html)
        self.assertEqual(_extract_data(html)["items"], [])


class HiddenIsHidden(unittest.TestCase):
    """Спрятанное кодом должно быть спрятано и на экране."""

    def test_explicit_display_is_paired_with_a_hidden_rule(self):
        """Явный `display` забивает браузерный `[hidden] { display: none }`.

        Страница прячет два места — шторку со ссылками и поле комментария, —
        и обоим CSS задаёт свой `display`. Без пары `[hidden]` элемент висит
        открытым, хотя `element.hidden = true` уже выставлен: ровно так поле
        для комментария показывалось до нажатия кнопки.
        """
        css = _DASHBOARD_TEMPLATE_PATH.read_text(encoding="utf-8")
        for selector in (".links-body", ".dispute-form"):
            with self.subTest(selector=selector):
                self.assertIn(selector + "[hidden] { display: none; }", css)


class ReadinessNumbers(unittest.TestCase):
    """В шапке одно число готовности — прототип."""

    def test_prod_readiness_is_not_shown(self):
        """Второе число рядом с первым читали как «до прома осталось 29%».

        Расчёт остался (он лежит в `progress_model.json` и в контракте), но
        на экран не идёт: страница ничего не считает, она только не рисует.
        """
        html = render_dashboard_html(_result([_item()]))
        self.assertIn("Прототип", html)
        self.assertNotIn("Промышленное решение", html)


def _extract_data(html: str) -> dict:
    start = html.index("window.__DATA__ = ") + len("window.__DATA__ = ")
    end = html.index(";</script>", start)
    return json.loads(html[start:end])


if __name__ == "__main__":
    unittest.main()

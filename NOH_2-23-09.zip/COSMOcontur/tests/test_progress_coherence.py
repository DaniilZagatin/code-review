"""Ревизия связности (`progress.coherence`): складываются ли закрытые пункты
в работающую систему.

Главные инварианты, которые держат тесты:

* ревизор **не меняет ни одного числа** — статусы, готовность и решение после
  него те же;
* изъян без проверенной ссылки не принимается: отсутствие связи доказывается
  местом, а не утверждением;
* уровень связности не спорит с собственным списком изъянов;
* тексты пунктов в карточку идут из плана, а не из пересказа модели.
"""

import os
import unittest

from fixture_support import ensure_fixture, scripted_responses
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress.coherence import (
    build_coherence_brief,
    coherence_enabled,
    evidence_map,
    load_coherence_prompt,
    run_coherence,
)
from pko.progress.matcher import AgentResult
from pko.progress.schema import (
    FLAW_KINDS,
    CriterionVerdict,
    EvidenceRef,
    ItemVerdict,
    PlanItem,
    ProjectSummary,
    SystemFlaw,
    calculate_progress,
    compute_decision,
    integrity_level_problem,
    rated_criteria,
)
from test_progress_matcher import finish, tool_call

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")

BULLETS = ["Заявка попадает исполнителю", "Стороны видят статус"]
ROUTER = EvidenceRef(
    path="backend/src/api/v1/router.py", line=7,
    basis="функция start_task ставит задачу в обработку",
    verified=True, reason="", note="принимает заявку",
)
LINK = {"path": "backend/src/api/v1/router.py", "line": 7,
        "basis": "start_task", "note": "заявка принимается и дальше не уходит"}

DETAIL = (
    "Приём заявки работает: обращение регистрируется и попадает в общий список. "
    "Но дальше по цепочке оно не уходит — передачи исполнителю нет, и обещанного "
    "сквозного пути от обращения до работы не получается."
)
NOTE = (
    "Система принимает заявки и регистрирует их, но до исполнителя они не "
    "доходят: сквозной путь рвётся на передаче."
)
FLOW = {
    "entry": "Клиент отправляет заявку",
    "steps": ["Заявка регистрируется в системе", "Заявка попадает в общий список"],
    "outcome": "Исполнитель видит задачу",
    "complete": True,
    "evidence": [LINK],
}


SYSTEM_DOES = (
    "Система принимает обращение клиента, регистрирует его и передаёт "
    "исполнителю: на вход приходит заявка, на выходе исполнитель видит задачу. "
    "По сути это сервис маршрутизации обращений, работающий без диспетчера."
)
SYSTEM_NOT_DOES = (
    "Расхождений с замыслом не нашлось: передача заявки исполнителю и "
    "видимость статуса обеими сторонами в коде есть и работают целиком, "
    "ничего из обещанного мимо реализации не прошло."
)


def flow(**over) -> dict:
    args = dict(FLOW)
    args.update(over)
    return args


def system(**over) -> dict:
    args = {"does": SYSTEM_DOES, "not_does": SYSTEM_NOT_DOES,
            "verdict": "same_purpose", "evidence": [LINK]}
    args.update(over)
    return args


def flaw(**over) -> dict:
    args = {
        "kind": "broken_chain", "severity": "major",
        "title": "Заявка регистрируется, но исполнителю не уходит",
        "detail": DETAIL, "evidence": [LINK],
    }
    args.update(over)
    return args


def verdicts(statuses=("done", "done")) -> list[ItemVerdict]:
    # «Не реализовано» подтверждать нечем — ссылки у такого пункта нет, как и
    # в живом прогоне: отсутствие ссылкой не доказывается.
    return [ItemVerdict(item_id="intake", applicable=True, criteria=[
        CriterionVerdict(applicable=True, status=status, proof="Работает.",
                         how="Заявка идёт дальше.",
                         evidence=[] if status == "planned" else [ROUTER])
        for status in statuses
    ])]


def result_of(statuses=("done", "done")) -> AgentResult:
    plan = [PlanItem(id="intake", title="Постановка задачи", criteria=BULLETS, origin="user")]
    items = verdicts(statuses)
    readiness = calculate_progress(rated_criteria(items)) or 0
    return AgentResult(
        items=list(plan), verdicts=items, plan=list(plan),
        summary=ProjectSummary(decision=compute_decision(readiness), conclusion=["а", "б", "в"],
                               match="mostly", match_note="Главное делает."),
        summary_source="llm", source="llm", context={"project_name": "Приём обращений"},
    )


class IntegrityLevelTest(unittest.TestCase):
    """Согласие уровня со списком изъянов — детерминированная проверка."""

    def _flaw(self, severity: str) -> SystemFlaw:
        return SystemFlaw(kind="broken_chain", severity=severity, title="т", detail="д")

    def test_unknown_level(self):
        self.assertIn("неизвестен", integrity_level_problem("perfect", []))

    def test_coherent_with_blocker_rejected(self):
        self.assertIn("блокирующ", integrity_level_problem("coherent", [self._flaw("blocker")]))

    def test_coherent_with_major_rejected(self):
        self.assertIn("fragmented", integrity_level_problem("coherent", [self._flaw("major")]))

    def test_coherent_with_minor_is_fine(self):
        self.assertEqual(integrity_level_problem("coherent", [self._flaw("minor")]), "")

    def test_coherent_without_flaws_is_fine(self):
        self.assertEqual(integrity_level_problem("coherent", []), "")

    def test_fragmented_without_flaws_rejected(self):
        self.assertIn("ни одного изъяна", integrity_level_problem("fragmented", []))

    def test_disconnected_needs_blocker(self):
        self.assertIn("blocker", integrity_level_problem("disconnected", [self._flaw("major")]))
        self.assertEqual(integrity_level_problem("disconnected", [self._flaw("blocker")]), "")


class BriefTest(unittest.TestCase):
    def test_brief_shows_bullets_statuses_and_evidence_map(self):
        res = result_of(("done", "planned"))
        text = build_coherence_brief(res.plan, res.verdicts, context=res.context,
                                     match_note="Главное делает.")
        self.assertIn("Приём обращений", text)
        self.assertIn(BULLETS[0], text)
        self.assertIn("[Работает]", text)
        self.assertIn("[Не реализовано]", text)
        self.assertIn("backend/src/api/v1/router.py — пунктов: 1", text)
        self.assertIn("Главное делает.", text)

    def test_evidence_map_counts_bullets_per_file(self):
        self.assertEqual(evidence_map(verdicts(("done", "done"))),
                         [("backend/src/api/v1/router.py", 2)])

    def test_evidence_map_skips_inapplicable(self):
        item = ItemVerdict(item_id="x", applicable=False, criteria=[
            CriterionVerdict(applicable=True, status="done", evidence=[ROUTER]),
        ])
        self.assertEqual(evidence_map([item]), [])

    def test_prompt_file_is_shipped_with_full_checklist(self):
        text, found = load_coherence_prompt()
        self.assertTrue(found)
        self.assertIn("ревизор связности", text)
        for kind in FLAW_KINDS:
            self.assertIn(kind, text)


class RunCoherenceTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        repo = GitRepo(ensure_fixture())
        cls.tree = Tree.at(repo, repo.resolve("master"))

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)
        self._env = os.environ.get("PKO_COHERENCE")
        os.environ.pop("PKO_COHERENCE", None)
        self.addCleanup(self._restore)

    def _restore(self):
        if self._env is None:
            os.environ.pop("PKO_COHERENCE", None)
        else:
            os.environ["PKO_COHERENCE"] = self._env

    def _run(self, *answers, result=None, with_system=True, **kwargs):
        # `submit_system` — обязательный первый шаг ревизии, и почти каждому
        # тесту он нужен только как предисловие. Подставляем его сам, а тесты
        # про сам этот шаг отключают подстановку через `with_system=False`.
        if with_system:
            answers = (tool_call("submit_system", **system()),) + answers
        ChatClient._create = scripted_responses(*answers)
        return run_coherence(result or result_of(), self.tree, SPEC,
                             client=self.client, **kwargs)

    def integrity(self, level="fragmented", note=NOTE) -> dict:
        return tool_call("submit_integrity", level=level, note=note)

    def test_full_pass_builds_review_for_the_card(self):
        out = self._run(
            tool_call("submit_flow", **flow(complete=False,
                                            break_point="Заявка не уходит исполнителю")),
            tool_call("submit_flaw", **flaw()),
            self.integrity(),
            finish(),
        )
        review = out.review
        self.assertIsNotNone(review)
        self.assertEqual(review.level, "fragmented")
        self.assertEqual(review.checked, 2)
        self.assertEqual(len(review.flaws), 1)
        card = review.to_dict()
        self.assertEqual(card["level_label"], "Связность частичная")
        self.assertEqual(card["flaws"][0]["severity_label"], "Существенный изъян")
        self.assertEqual(card["flaws"][0]["kind_label"], "Разрыв сквозного пути")
        self.assertEqual(card["flow"]["complete"], False)
        self.assertEqual(card["flow"]["break_point"], "Заявка не уходит исполнителю")
        self.assertEqual(card["counts"]["major"], 1)
        # Ссылки в карточку идут только подтверждённые.
        self.assertEqual(card["flaws"][0]["links"][0]["path"], "backend/src/api/v1/router.py")
        self.assertIn("существенных — 1", " ".join(out.notes))

    def test_nothing_is_recalculated(self):
        res = result_of()
        self._run(
            tool_call("submit_flow", **flow()),
            tool_call("submit_flaw", **flaw(severity="blocker")),
            self.integrity(level="disconnected"),
            finish(),
            result=res,
        )
        self.assertEqual([c.status for c in res.verdicts[0].criteria], ["done", "done"])
        self.assertEqual(res.summary.decision, "GO")

    def test_flaws_sorted_by_severity(self):
        out = self._run(
            tool_call("submit_flow", **flow()),
            tool_call("submit_flaw", **flaw(severity="minor", title="Мелочь")),
            tool_call("submit_flaw", **flaw(kind="stub_on_seam", severity="blocker",
                                            title="Заглушка на стыке")),
            tool_call("submit_flaw", **flaw(kind="state_lost", severity="major",
                                            title="Состояние теряется")),
            self.integrity(level="disconnected"),
            finish(),
        )
        self.assertEqual([f["severity"] for f in out.review.to_dict()["flaws"]],
                         ["blocker", "major", "minor"])

    def test_flaw_without_verified_link_rejected(self):
        out = self._run(
            tool_call("submit_flow", **flow()),
            tool_call("submit_flaw", **flaw(evidence=[])),
            tool_call("submit_flaw", **flaw(evidence=[{"path": "backend/nope.py", "line": 1,
                                                       "basis": "x"}])),
            self.integrity(level="coherent", note=NOTE),
            finish(),
        )
        self.assertEqual(out.review.flaws, [])
        self.assertEqual(out.review.level, "coherent")

    def test_flaw_with_code_in_text_rejected(self):
        bad = DETAIL + " Смотри функцию start_task() в router.py."
        out = self._run(
            tool_call("submit_flow", **flow()),
            tool_call("submit_flaw", **flaw(detail=bad)),
            self.integrity(level="coherent"),
            finish(),
        )
        self.assertEqual(out.review.flaws, [])

    def test_short_detail_rejected(self):
        out = self._run(
            tool_call("submit_flow", **flow()),
            tool_call("submit_flaw", **flaw(detail="не соединено")),
            self.integrity(level="coherent"),
            finish(),
        )
        self.assertEqual(out.review.flaws, [])

    def test_unknown_kind_rejected(self):
        out = self._run(
            tool_call("submit_flow", **flow()),
            tool_call("submit_flaw", **flaw(kind="no_tests")),
            self.integrity(level="coherent"),
            finish(),
        )
        self.assertEqual(out.review.flaws, [])

    def test_duplicate_flaw_rejected(self):
        out = self._run(
            tool_call("submit_flow", **flow()),
            tool_call("submit_flaw", **flaw()),
            tool_call("submit_flaw", **flaw()),
            self.integrity(),
            finish(),
        )
        self.assertEqual(len(out.review.flaws), 1)

    def test_bullets_come_from_the_plan_not_the_model(self):
        out = self._run(
            tool_call("submit_flow", **flow()),
            tool_call("submit_flaw", **flaw(bullets=[
                "заявка попадает исполнителю!!!",   # пересказ — берём текст плана
                "чего-то совсем другого",           # не сопоставилось — отбрасываем
            ])),
            self.integrity(),
            finish(),
        )
        self.assertEqual(out.review.flaws[0].bullets, [BULLETS[0]])

    def test_level_conflicting_with_flaws_rejected(self):
        out = self._run(
            tool_call("submit_flow", **flow()),
            tool_call("submit_flaw", **flaw(severity="blocker")),
            self.integrity(level="coherent"),   # спорит со своим же блокером
            self.integrity(level="disconnected"),
            finish(),
        )
        self.assertEqual(out.review.level, "disconnected")

    def test_integrity_before_flow_rejected(self):
        out = self._run(
            self.integrity(level="coherent"),
            tool_call("submit_flow", **flow()),
            self.integrity(level="coherent"),
            finish(),
        )
        self.assertEqual(out.review.level, "coherent")

    def test_flow_without_break_point_rejected(self):
        out = self._run(
            tool_call("submit_flow", **flow(complete=False)),
            tool_call("submit_flow", **flow(complete=False, break_point="рвётся на передаче")),
            self.integrity(level="coherent"),
            finish(),
        )
        self.assertFalse(out.review.flow.complete)
        self.assertEqual(out.review.flow.break_point, "рвётся на передаче")

    def test_flow_without_verified_link_rejected(self):
        out = self._run(
            tool_call("submit_flow", **flow(evidence=[])),
            finish(),
            tool_call("submit_flow", **flow()),
            self.integrity(level="coherent"),
            finish(),
        )
        self.assertIsNotNone(out.review)
        self.assertEqual(out.review.flow.entry, FLOW["entry"])

    def test_finish_without_level_rejected(self):
        out = self._run(
            tool_call("submit_flow", **flow()),
            finish(),
            self.integrity(level="coherent"),
            finish(),
        )
        self.assertEqual(out.review.level, "coherent")

    def test_incomplete_session_gives_no_card_block(self):
        out = self._run(tool_call("submit_flow", **flow()), finish(), finish(), finish())
        self.assertIsNone(out.review)
        self.assertIn("уровень связности не вынесен", " ".join(out.notes))

    def test_foreign_tools_are_refused_repo_tools_work(self):
        out = self._run(
            tool_call("read_file", path="backend/src/api/v1/router.py"),
            tool_call("submit_stage", item_id="intake"),
            tool_call("submit_challenge", item_id="intake"),
            tool_call("submit_flow", **flow()),
            self.integrity(level="coherent"),
            finish(),
        )
        self.assertEqual(out.review.level, "coherent")

    def test_disabled_by_env(self):
        os.environ["PKO_COHERENCE"] = "false"
        out = self._run(tool_call("submit_flow", **flow()), self.integrity(), finish())
        self.assertIsNone(out.review)
        self.assertIn("выключена", " ".join(out.notes))

    def test_zero_steps_disables(self):
        out = self._run(tool_call("submit_flow", **flow()), self.integrity(), finish(),
                        max_steps=0)
        self.assertIsNone(out.review)

    def test_enabled_by_default(self):
        self.assertTrue(coherence_enabled())

    def test_silence_stops_session(self):
        out = self._run({"content": "думаю"}, {"content": "ещё"}, {"content": "и ещё"})
        self.assertIsNone(out.review)
        self.assertIn("не вызвал инструмент", " ".join(out.notes))

    # --- Что система делает на самом деле (`submit_system`) ---------------

    def test_purpose_reaches_the_card(self):
        out = self._run(
            tool_call("submit_flow", **flow()),
            self.integrity(level="coherent"),
            finish(),
        )
        card = out.review.to_dict()["purpose"]
        self.assertEqual(card["verdict"], "same_purpose")
        self.assertEqual(card["verdict_label"], "Назначение совпадает с замыслом")
        self.assertEqual(card["does"], SYSTEM_DOES)
        self.assertEqual(card["links"][0]["path"], "backend/src/api/v1/router.py")

    def test_review_needs_the_system_description(self):
        """Без ответа «что система делает» ревизия не засчитывается: это
        главный её вывод, а не предисловие."""
        out = self._run(
            tool_call("submit_flow", **flow()),
            self.integrity(level="coherent"),
            finish(),
            with_system=False,
        )
        self.assertIsNone(out.review)
        self.assertIn("не сказано, что система делает", " ".join(out.notes))

    def test_short_or_coded_description_rejected(self):
        out = self._run(
            tool_call("submit_system", **system(does="Делает всё хорошо.")),
            tool_call("submit_system", **system(
                does=SYSTEM_DOES + " Смотри функцию start_task() в router.py.")),
            tool_call("submit_system", **system()),
            tool_call("submit_flow", **flow()),
            self.integrity(level="coherent"),
            finish(),
            with_system=False,
        )
        self.assertEqual(out.review.purpose.does, SYSTEM_DOES)

    def test_different_purpose_requires_scope_mismatch_flaw(self):
        """«Решает другую задачу» — ярлык, пока не показано, что она решает
        вместо. Требуем изъян вида scope_mismatch."""
        out = self._run(
            tool_call("submit_system", **system(verdict="different")),
            tool_call("submit_flow", **flow()),
            self.integrity(level="fragmented"),          # отклонят: нет scope_mismatch
            tool_call("submit_flaw", **flaw(kind="scope_mismatch", severity="major",
                                            title="Код решает соседнюю задачу")),
            self.integrity(level="fragmented"),
            finish(),
            with_system=False,
        )
        self.assertEqual(out.review.purpose.verdict, "different")
        self.assertEqual(out.review.level, "fragmented")
        self.assertEqual([f.kind for f in out.review.flaws], ["scope_mismatch"])

    def test_unknown_verdict_rejected(self):
        out = self._run(
            tool_call("submit_system", **system(verdict="perfect")),
            tool_call("submit_system", **system(verdict="narrower")),
            tool_call("submit_flow", **flow()),
            self.integrity(level="coherent"),
            finish(),
            with_system=False,
        )
        self.assertEqual(out.review.purpose.verdict, "narrower")

    def test_no_applicable_bullets_reports_note(self):
        res = result_of()
        res.verdicts[0].applicable = False
        out = self._run(finish(), result=res)
        self.assertIsNone(out.review)
        self.assertIn("проверять связность нечего", " ".join(out.notes))


if __name__ == "__main__":
    unittest.main()

"""Веб API `pko progress`: `POST /api/analyses` -> SSE-прогресс -> `GET /api/analyses/{id}`.

LLM подменяется скриптованным `ChatClient._create` + `DEFAULT_CACHE_DIR` во
временном каталоге.
"""

import json
import os
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from fastapi.testclient import TestClient

import pko.llm.client as client_module
import pko.web.app as app_module
from agent_script import (
    BULLETS,
    CONCLUSION,
    MATCH,
    MATCH_NOTE,
    HOW,
    JOURNEY_TEXT,
    PROJECT_NAME,
    PROOF,
    STAGE_TITLE,
    full_session,
)
from fixture_support import ensure_fixture, scripted_responses
from pko import defaults
from pko.llm.client import ChatClient
from pko.render.client_journey_passport import STATUS_BADGE_AGENT, STATUS_BADGE_FALLBACK
from pko.web import analyses
from pko.web.app import app

ENV_KEYS = ("PKO_ASSEMBLER_BASE_URL", "PKO_ASSEMBLER_MODEL", "PKO_ASSEMBLER_API_KEY")


def _parse_sse(text: str) -> list[dict]:
    events = []
    for line in text.splitlines():
        if line.startswith("data: "):
            events.append(json.loads(line[len("data: "):]))
    return events


class WebAnalysesTest(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

        self._original_cache_dir = client_module.DEFAULT_CACHE_DIR
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        client_module.DEFAULT_CACHE_DIR = Path(self.tmp.name) / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._original_cache_dir)

        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)

        self._original_env = {k: os.environ.get(k) for k in ENV_KEYS}
        os.environ.update({
            "PKO_ASSEMBLER_BASE_URL": "https://stub.local/v1",
            "PKO_ASSEMBLER_MODEL": "stub-model",
            "PKO_ASSEMBLER_API_KEY": "x",
        })

        def _restore_env():
            for k, v in self._original_env.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

        self.addCleanup(_restore_env)

    def _create(self, repository: str = "", branch: str = "",
                journey_text: str = JOURNEY_TEXT,
                extra_files: dict[str, bytes] | None = None):
        data = {"journey_text": journey_text, "repository": repository, "branch": branch}
        files = []
        for name, blob in (extra_files or {}).items():
            files.append(("files", (name, blob, "application/octet-stream")))
        return self.client.post("/api/analyses", data=data, files=files)

    def test_full_run_streams_events_then_ready_analysis(self):
        ChatClient._create = scripted_responses(*full_session())

        create_resp = self._create(repository=str(ensure_fixture()))
        self.assertEqual(create_resp.status_code, 200, create_resp.text)
        body = create_resp.json()
        self.assertEqual(body["status"], "PROCESSING")
        analysis_id = body["analysis_id"]

        events_resp = self.client.get(f"/api/analyses/{analysis_id}/events")
        self.assertEqual(events_resp.status_code, 200)
        events = _parse_sse(events_resp.text)
        self.assertEqual([e["type"] for e in events], [
            "phase", "phase", "plan_ready",
            "claim_verified", "summary_ready", "phase", "phase",
            "passport_started", *(["passport_node"] * 6), "passport_ready",
            "analysis_ready",
        ])
        self.assertEqual(events[0]["phase"], "materials_loading")
        self.assertEqual(events[1]["phase"], "materials_ready")
        # После вердикта идут два прохода: строгая проверка и ревизия связности.
        self.assertEqual(events[5]["phase"], "critic")
        self.assertEqual(events[6]["phase"], "coherence")
        self.assertEqual(events[2], {
            "type": "plan_ready", "item_count": 1,
            "items": [{"title": STAGE_TITLE, "origin": "user", "criteria": 2}],
        })
        self.assertEqual(events[3], {
            "type": "claim_verified", "title": STAGE_TITLE,
            "applicable": True, "percent": 50, "criteria": 2,
        })
        self.assertEqual(events[4]["decision"], "GO")

        get_resp = self.client.get(f"/api/analyses/{analysis_id}")
        self.assertEqual(get_resp.status_code, 200)
        result = get_resp.json()
        self.assertEqual(result["status"], "READY")
        # readiness считается кодом: («Да» 100 + «Нет» 0) / 2 = 50%.
        self.assertEqual(result["readiness"], 50)
        self.assertEqual(result["meta"]["decision"], "GO")
        self.assertEqual(result["meta"]["project_name"], PROJECT_NAME)
        # Сводка паспорта — для кнопки скачивания; само дерево в файл
        # карточки не идёт.
        self.assertEqual(result["passport"]["filled_by_agent"], True)
        self.assertEqual(result["passport"]["nodes"], 6)
        self.assertEqual(result["passport"]["risks"], [])
        self.assertEqual(result["passport"]["summary"]["risks_total"], 0)
        # Дерево в контракте отчёта: только структура, без полей карточек.
        tree = {n["id"]: n for n in result["passport"]["tree"]}
        self.assertEqual(tree["bbb-2"]["parent"], "process-1")
        self.assertEqual(tree["bbb-2"]["parents"], ["process-1"])
        self.assertNotIn("guardrail-1", tree)
        self.assertNotIn("need-1", tree)
        self.assertEqual([r["kind"] for r in result["passport"]["relations"]], ["precedes"])
        self.assertEqual(tree["bbb-1"]["relations"][0]["direction"], "out")
        self.assertEqual(tree["journey-1"]["type"], "journey")
        # Подтверждённый пункт ОР даёт оценку без повторного ручного
        # подтверждения; смесь работающего и планируемого — частичная
        # реализация процесса.
        self.assertEqual(tree["bbb-1"]["implementation_status"], "implemented")
        self.assertEqual(tree["bbb-2"]["implementation_status"], "not_implemented")
        self.assertEqual(tree["process-1"]["implementation_status"], "partial")
        self.assertEqual(result["passport"]["summary"]["mapping_coverage"], 100)
        self.assertEqual(result["passport"]["summary"]["assessment"]["completeness"], 50)
        self.assertEqual(result["passport"]["summary"]["assessment"]["connectivity"], 100)
        self.assertEqual(len(result["passport"]["paths"]), 1)
        self.assertEqual(result["passport"]["paths"][0]["steps_mapped"], 2)
        self.assertEqual(result["passport"]["paths"][0]["unmapped_steps"], [])
        self.assertEqual(result["passport"]["summary"]["scenario_steps_mapped"], 2)

        [item] = result["items"]
        self.assertEqual(item["title"], STAGE_TITLE)
        self.assertTrue(item["applicable"])
        self.assertEqual([a["text"] for a in item["assessment"]], BULLETS)
        first = item["assessment"][0]
        self.assertEqual(first["text"], BULLETS[0])
        self.assertTrue(first["applicable"])
        self.assertEqual(first["status"], "done")
        self.assertEqual(first["status_label"], "Работает")
        # Раскрытие пункта — ровно два буллита человеческим языком.
        self.assertEqual(first["proof"], PROOF["done"])
        self.assertEqual(first["how"], HOW["done"])

        second = item["assessment"][1]
        self.assertEqual(second["status"], "planned")
        self.assertEqual(second["status_label"], "Не реализовано")
        self.assertEqual(second["proof"], PROOF["planned"])

        # Процент этапа считает бэкенд, а не шаблон.
        self.assertEqual(item["percent"], 50)
        self.assertNotIn("color", item)
        # Ссылки на код — в шторке пункта, и только подтверждённые: поля
        # `verified`/`reason` в контракт не едут, показывать по ним нечего.
        self.assertNotIn("evidence", first)
        self.assertEqual(first["links"][0]["path"], "backend/src/api/v1/router.py")
        self.assertEqual(first["links"][0]["line"], 7)
        self.assertNotIn("verified", first["links"][0])
        # У «не реализовано» подтверждать нечего — шторки нет.
        self.assertNotIn("links", second)

        self.assertEqual(result["summary"], {
            "conclusion": CONCLUSION,
            # Строка расчёта под решением: читатель видит, откуда взялся бейдж.
            "reason": "50% ≥ 40%",
            # Верхнеуровневая оценка целого: её даёт модель, подпись к ней —
            # код, чтобы формулировка в отчёте была одна на все прогоны.
            "match": MATCH,
            "match_label": "Код в основном соответствует образу результата",
            "match_note": MATCH_NOTE,
        })
        # Две готовности из одних и тех же статусов: прототип и пром.
        # («Работает» 100 + «Не реализовано» 0) / 2 = 50% по обеим шкалам.
        self.assertEqual(result["readiness_prod"], 50)

    def test_events_stream_sends_heartbeat_while_agent_is_slow(self):
        job = analyses.AnalysisJob(id="an_slow_test")
        analyses._JOBS[job.id] = job
        self.addCleanup(analyses._JOBS.pop, job.id, None)

        original_heartbeat = app_module._HEARTBEAT_SECONDS
        app_module._HEARTBEAT_SECONDS = 0.05
        self.addCleanup(setattr, app_module, "_HEARTBEAT_SECONDS", original_heartbeat)

        def deliver_after_delay():
            time.sleep(0.2)
            job.events.put({"type": "analysis_ready"})

        threading.Thread(target=deliver_after_delay, daemon=True).start()

        resp = self.client.get(f"/api/analyses/{job.id}/events")
        self.assertEqual(resp.status_code, 200)
        self.assertIn(": keepalive\n\n", resp.text)
        events = _parse_sse(resp.text)
        self.assertEqual(events, [{"type": "analysis_ready"}])

    def test_prune_jobs_evicts_oldest_finished_only(self):
        ids = [f"an_prune_{i}" for i in range(4)]
        # Реестр общий на процесс: изолируем его на время теста и возвращаем
        # как было — иначе чужие завершённые задачи вытеснятся вместо наших.
        snapshot = dict(analyses._JOBS)

        def _restore():
            analyses._JOBS.clear()
            analyses._JOBS.update(snapshot)

        self.addCleanup(_restore)
        analyses._JOBS.clear()

        for job_id, status in zip(ids, ["PROCESSING", "READY", "READY", "READY"]):
            job = analyses.AnalysisJob(id=job_id)
            job.status = status
            analyses._JOBS[job.id] = job

        original = analyses.MAX_JOBS
        analyses.MAX_JOBS = 4
        self.addCleanup(setattr, analyses, "MAX_JOBS", original)

        analyses._prune_jobs()
        # Вытесняется самая старая завершённая; PROCESSING не вытесняется никогда.
        self.assertNotIn("an_prune_1", analyses._JOBS)
        self.assertIn("an_prune_0", analyses._JOBS)

    def test_files_only_analysis_runs(self):
        # Дефолтный репозиторий отключён (пустой дефолт), загружены только
        # файлы — агент работает по файлам.
        ChatClient._create = scripted_responses(
            *full_session(stage={"statuses": ["planned", "planned"]})
        )
        with mock.patch.object(defaults, "DEFAULT_REPOSITORY", ""):
            create_resp = self._create(extra_files={"metrics.json": b'{"roc_auc": 0.88}'})
            self.assertEqual(create_resp.status_code, 200, create_resp.text)
            analysis_id = create_resp.json()["analysis_id"]

            events = _parse_sse(self.client.get(f"/api/analyses/{analysis_id}/events").text)
            self.assertEqual(events[-1]["type"], "analysis_ready")
            self.assertEqual(events[0]["phase"], "materials_loading")

            result = self.client.get(f"/api/analyses/{analysis_id}").json()
            self.assertEqual(result["status"], "READY")

    def test_repository_and_files_together_are_merged_into_one_analysis(self):
        ChatClient._create = scripted_responses(*full_session(
            stage={"evidence": [{"path": "metrics.json", "line": 1,
                                 "basis": "roc_auc в metrics.json"}]},
        ))

        create_resp = self._create(
            repository=str(ensure_fixture()),
            extra_files={"metrics.json": b'{"roc_auc": 0.9}'},
        )
        self.assertEqual(create_resp.status_code, 200, create_resp.text)
        analysis_id = create_resp.json()["analysis_id"]
        self.client.get(f"/api/analyses/{analysis_id}/events")

        result = self.client.get(f"/api/analyses/{analysis_id}").json()
        self.assertEqual(result["status"], "READY")
        self.assertNotEqual(result["meta"]["repo"], "")

    def test_no_files_still_runs_against_repository_from_form(self):
        # Репозиторий из формы, файлов нет — агент работает по коду репозитория.
        ChatClient._create = scripted_responses(*full_session(
            stage={"statuses": ["planned", "planned"]},
            summary={"decision": "NO GO"},
        ))

        create_resp = self._create(repository=str(ensure_fixture()))
        self.assertEqual(create_resp.status_code, 200, create_resp.text)
        analysis_id = create_resp.json()["analysis_id"]

        events = _parse_sse(self.client.get(f"/api/analyses/{analysis_id}/events").text)
        self.assertEqual(events[-1]["type"], "analysis_ready")

        result = self.client.get(f"/api/analyses/{analysis_id}").json()
        self.assertEqual(result["status"], "READY")
        # Все planned -> 0%.
        self.assertEqual(result["readiness"], 0)
        self.assertEqual(result["meta"]["decision"], "PIVOT")

    def test_empty_materials_still_runs(self):
        # Дефолтный репозиторий отключён, ни репозитория, ни файлов — не
        # ошибка запроса: агент получает пустой снимок материалов.
        ChatClient._create = scripted_responses(*full_session(
            stage={"statuses": ["planned", "planned"]},
            summary={"decision": "NO GO"},
        ))

        with mock.patch.object(defaults, "DEFAULT_REPOSITORY", ""):
            create_resp = self._create()
            self.assertEqual(create_resp.status_code, 200, create_resp.text)
            analysis_id = create_resp.json()["analysis_id"]

            events = _parse_sse(self.client.get(f"/api/analyses/{analysis_id}/events").text)
            self.assertEqual(events[-1]["type"], "analysis_ready")

            result = self.client.get(f"/api/analyses/{analysis_id}").json()
            self.assertEqual(result["status"], "READY")
            self.assertEqual(result["readiness"], 0)

    def test_empty_repository_runs_on_files_only(self):
        # Пустой репозиторий — дефолт больше не подставляется, анализ идёт
        # по загруженным файлам (или пустому снимку, если файлов тоже нет).
        ChatClient._create = scripted_responses(*full_session(
            stage={"statuses": ["planned", "planned"]},
        ))
        analysis_id = self._create().json()["analysis_id"]
        events = _parse_sse(self.client.get(f"/api/analyses/{analysis_id}/events").text)
        self.assertEqual(events[-1]["type"], "analysis_ready")

        result = self.client.get(f"/api/analyses/{analysis_id}").json()
        self.assertEqual(result["status"], "READY")
        self.assertEqual(result["readiness"], 0)

    def test_repository_from_form_is_not_fixed_anymore(self):
        # Поле «репозиторий» обязано уважаться: несуществующий путь доходит
        # до git-слоя и падает понятной ошибкой задачи, а не подменяется
        # зашитым репозиторием.
        ChatClient._create = scripted_responses(*full_session(
            stage={"statuses": ["planned", "planned"]},
        ))
        bogus = str(Path(self.tmp.name) / "form-repo-не-существует")
        analysis_id = self._create(repository=bogus).json()["analysis_id"]
        events = _parse_sse(self.client.get(f"/api/analyses/{analysis_id}/events").text)
        self.assertEqual(events[-1]["type"], "error")

    def test_one_file_over_the_limit_is_refused_while_it_is_read(self):
        """Предел проверяется по ходу чтения, а не после `read()` целиком:
        один файл на гигабайт оказывался в памяти раньше проверки."""
        with mock.patch.object(app_module, "MAX_UPLOAD_BYTES", 1024):
            resp = self._create(extra_files={"big.bin": b"x" * 4096})
        self.assertEqual(resp.status_code, 400, resp.text)
        self.assertIn("слишком большие", resp.json()["message"].lower())

    def test_empty_journey_text_is_a_clean_400(self):
        resp = self._create(journey_text="")
        self.assertEqual(resp.status_code, 400)
        self.assertIn("клиентский путь", resp.json()["message"].lower())

    def test_thinking_flag_is_forwarded_to_get_spec(self):
        captured: list[bool | None] = []

        def fake_get_spec(role, thinking=None, **_):
            if role == "matcher":
                captured.append(thinking)
            return object()

        def fake_create_analysis(**_):
            return analyses.AnalysisJob(id="an_thinking_test")

        self.addCleanup(setattr, app_module, "get_spec", app_module.get_spec)
        self.addCleanup(setattr, analyses, "create_analysis", analyses.create_analysis)
        app_module.get_spec = fake_get_spec
        analyses.create_analysis = fake_create_analysis

        self.client.post("/api/analyses", data={
            "journey_text": JOURNEY_TEXT, "thinking": "true",
        })
        self.client.post("/api/analyses", data={
            "journey_text": JOURNEY_TEXT,
        })

        self.assertEqual(captured, [True, False])

    def test_unknown_analysis_id_is_a_clean_400_not_a_500(self):
        resp = self.client.get("/api/analyses/an_doesnotexist")
        self.assertEqual(resp.status_code, 400)
        self.assertTrue(resp.json()["message"])

        events_resp = self.client.get("/api/analyses/an_doesnotexist/events")
        self.assertEqual(events_resp.status_code, 400)

    def test_dashboard_html_endpoint_returns_selfcontained_html(self):
        ChatClient._create = scripted_responses(*full_session())

        analysis_id = self._create(repository=str(ensure_fixture())).json()["analysis_id"]
        self.client.get(f"/api/analyses/{analysis_id}/events")

        resp = self.client.get(f"/api/analyses/{analysis_id}/dashboard.html")
        self.assertEqual(resp.status_code, 200, resp.text)
        self.assertIn("text/html", resp.headers["content-type"])
        self.assertIn("window.__DATA__", resp.text)
        self.assertIn(PROJECT_NAME, resp.text)
        self.assertIn(BULLETS[0], resp.text)
        self.assertIn(CONCLUSION[0], resp.text)
        # Ссылки доезжают до отчёта — в шторке под пунктом.
        self.assertIn("backend/src/api/v1/router.py", resp.text)
        self.assertIn("Ссылки на код", resp.text)
        self.assertIn(PROOF["done"], resp.text)

    def test_passport_html_endpoint_returns_agent_filled_passport(self):
        ChatClient._create = scripted_responses(*full_session())

        analysis_id = self._create(repository=str(ensure_fixture())).json()["analysis_id"]
        self.client.get(f"/api/analyses/{analysis_id}/events")

        resp = self.client.get(f"/api/analyses/{analysis_id}/passport.html")
        self.assertEqual(resp.status_code, 200, resp.text)
        self.assertIn("text/html", resp.headers["content-type"])
        self.assertIn(STATUS_BADGE_AGENT, resp.text)
        # Узлы, объявленные паспортной сессией, доезжают до HTML вместе с
        # object-id и строкой реестра, которые строит код.
        self.assertIn("Передача исполнителю", resp.text)
        self.assertNotIn("bbb.peredacha-ispolnitelyu", resp.text)  # object-id не входит в карточку
        self.assertIn('"id":"bbb-2"', resp.text)
        self.assertIn('<td data-col="Родитель">bbb-2</td>', resp.text)
        # Отдельная фича паспорта: граф объектов по уровням с двумя
        # показателями в шапке и состояниями узлов.
        self.assertIn("Процессов", resp.text)
        self.assertIn("Разрывов", resp.text)
        self.assertIn("Открыть описание", resp.text)
        self.assertIn("Недостаточно данных", resp.text)
        self.assertIn('"paths"', resp.text)

    def test_passport_without_agent_nodes_is_filled_deterministically(self):
        # Паспортных ходов в очереди нет: сессия останавливается на пустых
        # ответах, паспорт собирает код и говорит об этом бейджем.
        ChatClient._create = scripted_responses(*full_session(passport=False))

        analysis_id = self._create(repository=str(ensure_fixture())).json()["analysis_id"]
        self.client.get(f"/api/analyses/{analysis_id}/events")

        result = self.client.get(f"/api/analyses/{analysis_id}").json()
        self.assertEqual(result["passport"]["filled_by_agent"], False)
        self.assertEqual(result["passport"]["nodes"], 0)
        self.assertEqual(result["passport"]["tree"], [])
        self.assertEqual(result["passport"]["paths"], [])
        self.assertEqual(result["passport"]["summary"]["functional_nodes"], 0)
        self.assertTrue(any("паспорт" in g for g in result["gaps"]), result["gaps"])
        resp = self.client.get(f"/api/analyses/{analysis_id}/passport.html")
        self.assertEqual(resp.status_code, 200, resp.text)
        self.assertIn(STATUS_BADGE_FALLBACK, resp.text)

    def test_passport_html_for_unknown_analysis_is_a_clean_400(self):
        self.assertEqual(
            self.client.get("/api/analyses/an_doesnotexist/passport.html").status_code, 400,
        )

    def test_dashboard_html_for_processing_or_unknown_is_a_clean_400(self):
        self.assertEqual(
            self.client.get("/api/analyses/an_doesnotexist/dashboard.html").status_code, 400,
        )

    def test_missing_llm_config_is_a_clean_400_before_any_job_is_created(self):
        # Роль не заведётся, только если переменные не заданы И дефолтный
        # GLM-эндпоинт отключён: иначе агент поднимается на дефолте.
        for k in ENV_KEYS:
            os.environ.pop(k, None)
        with mock.patch.object(defaults, "GLM_BASE_URL", ""):
            resp = self._create(repository=str(ensure_fixture()))
        self.assertEqual(resp.status_code, 400)
        self.assertIn("LLM", resp.json()["message"])

    def test_nonexistent_repo_surfaces_as_error_event_and_error_status(self):
        ChatClient._create = scripted_responses(json.dumps({}))
        missing = str(Path(self.tmp.name) / "no-such-repo")
        analysis_id = self._create(repository=missing).json()["analysis_id"]

        events = _parse_sse(self.client.get(f"/api/analyses/{analysis_id}/events").text)
        self.assertEqual(events[-1]["type"], "error")
        self.assertTrue(events[-1]["message"])

        result = self.client.get(f"/api/analyses/{analysis_id}")
        self.assertEqual(result.status_code, 400)
        self.assertEqual(result.json()["status"], "ERROR")


if __name__ == "__main__":
    unittest.main()

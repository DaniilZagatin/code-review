"""Сквозная связность (`progress.connectivity` + расчёт в `schema`).

Что держат тесты:

* статусы сценариев и процент считает код, и считает детерминированно:
  разрыв на любом стыке — `broken`, непрослеженный стык — `unknown`,
  неизвестное остаётся в знаменателе;
* «собран» и «разрыв» без проверенной ссылки не принимаются — понижаются
  до «недостаточно данных», а не отклоняются молча;
* сценарий без привязки к пунктам ОР не принимается: состав выводится из
  обещанного, а не из найденного кода;
* критический разорванный сценарий держит явный статус блокировки при любой
  общей доле;
* отдельная оценка схемы берёт минимум полноты и связности, а критический
  разрыв блокирует GO; основной GO/PIVOT отчёта не меняется.
"""

import unittest

from fixture_support import ensure_fixture, scripted_responses
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress.coherence import run_coherence
from pko.render.dashboard_data import build_dashboard_data
from pko.render.dashboard_html import render_dashboard_html
from pko.progress.schema import (
    REQUIRED_CHECKS_FOR_OK,
    ConnectivityReview,
    EvidenceRef,
    Handoff,
    HandoffCheck,
    ProgressModel,
    ProjectSummary,
    Scenario,
    calculate_connectivity,
    calculate_solution_assessment,
    handoff_result,
    scenario_status,
)
from test_progress_coherence import BULLETS, LINK, flow, result_of, system
from test_progress_matcher import finish, tool_call

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")

OK = EvidenceRef(path="a.py", line=1, basis="f", verified=True, reason="")


def check(name: str, result: str = "ok", evidence=(OK,), note: str = "") -> HandoffCheck:
    return HandoffCheck(check=name, result=result, note=note, evidence=list(evidence))


def handoff(step: int, result: str = "ok", checks=REQUIRED_CHECKS_FOR_OK) -> Handoff:
    return Handoff(step=step, checks=[check(c, result) for c in checks])


def scenario(handoffs, steps=("вход", "середина", "результат"), critical=False) -> Scenario:
    return Scenario(id="s", title="t", entry="e", outcome="o", steps=list(steps),
                    critical=critical, handoffs=list(handoffs))


class CalculationTest(unittest.TestCase):
    """Арифметика связности — код, а не модель."""

    def test_handoff_needs_required_checks(self):
        self.assertEqual(handoff_result([check("reachability")]), "unknown")
        self.assertEqual(handoff_result([check(c) for c in REQUIRED_CHECKS_FOR_OK]), "ok")
        self.assertEqual(handoff_result([check(c) for c in REQUIRED_CHECKS_FOR_OK]
                                        + [check("wiring", "unknown")]), "unknown")
        self.assertEqual(handoff_result([check("reachability", "broken")]), "broken")
        self.assertEqual(handoff_result([]), "unknown")

    def test_scenario_status_by_transitions(self):
        steps = ["a", "b", "c"]
        self.assertEqual(scenario_status(steps, [handoff(0), handoff(1)]), "assembled")
        self.assertEqual(scenario_status(steps, [handoff(0)]), "unknown")
        self.assertEqual(scenario_status(steps, [handoff(0), handoff(1, "broken")]), "broken")
        # Разрыв сильнее неизвестного: один непрослеженный стык и один разрыв — разрыв.
        self.assertEqual(scenario_status(steps, [handoff(1, "broken")]), "broken")
        self.assertEqual(scenario_status(["один"], []), "unknown")

    def test_percent_keeps_unknown_in_denominator(self):
        review = ConnectivityReview(scenarios=[
            scenario([handoff(0), handoff(1)]),
            scenario([handoff(0), handoff(1)]),
            scenario([handoff(0), handoff(1, "broken")], critical=True),
            scenario([handoff(0, "broken")]),
            scenario([handoff(0)]),
        ])
        self.assertEqual(review.percent(), 40)
        self.assertEqual(review.counts(), {"assembled": 2, "broken": 2, "unknown": 1})
        self.assertEqual([s.critical for s in review.blocked()], [True])
        self.assertEqual(review.handoff_coverage(), (8, 10))
        self.assertIsNone(calculate_connectivity([]))

    def test_break_point_names_the_transition(self):
        s = scenario([handoff(0), Handoff(step=1, checks=[
            check("reachability", "broken", note="обработчик не зарегистрирован"),
        ])])
        self.assertIn("«середина» → «результат»", s.break_point)
        self.assertIn("обработчик не зарегистрирован", s.break_point)
        self.assertEqual(s.to_dict()["status_label"], "Выявлен разрыв")

    def test_solution_assessment_integrates_without_averaging(self):
        connected = ConnectivityReview(scenarios=[scenario([handoff(0), handoff(1)])])
        assessment = calculate_solution_assessment(75, connected)
        self.assertEqual(assessment.score, 75)
        self.assertIn("min(полнота 75%, связность 100%)", assessment.reason)
        self.assertNotIn("decision", assessment.to_dict())

        half = ConnectivityReview(scenarios=[
            scenario([handoff(0), handoff(1)]),
            scenario([handoff(0, "broken"), handoff(1)]),
        ])
        assessment = calculate_solution_assessment(90, half)
        self.assertEqual((assessment.score, assessment.connectivity), (50, 50))

    def test_critical_break_is_reported_without_verdict(self):
        review = ConnectivityReview(scenarios=[
            scenario([handoff(0), handoff(1)], critical=True),
            scenario([handoff(0), handoff(1, "broken")], critical=True),
            scenario([handoff(0), handoff(1)]),
        ])
        assessment = calculate_solution_assessment(100, review)
        self.assertEqual(assessment.score, 67)
        self.assertEqual(assessment.critical_breaks, 1)
        self.assertIn("критических разрывов 1", assessment.reason)
        self.assertNotIn("PIVOT", assessment.reason)

    def test_missing_connectivity_is_explicit_fallback(self):
        assessment = calculate_solution_assessment(60, None)
        self.assertIsNone(assessment.score)
        self.assertFalse(assessment.connectivity_measured)
        self.assertIn("связность не измерена", assessment.reason)


def checks(result="ok", evidence=None, note="проверено по коду"):
    ev = [LINK] if evidence is None else evidence
    return [{"check": c, "result": result, "note": note, "evidence": ev}
            for c in REQUIRED_CHECKS_FOR_OK]


def scenarios(**over) -> dict:
    entry = {
        "title": "Постановка задачи исполнителю",
        "entry": "Клиент передаёт задачу",
        "outcome": "Исполнитель видит задачу",
        "steps": ["Заявка регистрируется", "Заявка уходит исполнителю"],
        "critical": True,
        "bullets": [BULLETS[0]],
    }
    entry.update(over)
    return {"scenarios": [entry]}


class GateTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        repo = GitRepo(ensure_fixture())
        cls.tree = Tree.at(repo, repo.resolve("master"))

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)

    def _run(self, *answers):
        answers = (tool_call("submit_system", **system()),) + answers + (
            tool_call("submit_flow", **flow()),
            tool_call("submit_integrity", level="coherent",
                      note="Система принимает заявки и доводит их до исполнителя, "
                           "сквозной путь проходит целиком."),
            finish(),
        )
        ChatClient._create = scripted_responses(*answers)
        return run_coherence(result_of(), self.tree, SPEC, client=self.client,
                             source_digest="digest-1")

    def test_assembled_scenario_counts_and_numbers_stay(self):
        res = result_of()
        out = self._run(
            tool_call("submit_scenarios", **scenarios()),
            tool_call("submit_trace", scenario_id="scenario-1",
                      handoffs=[{"step": 0, "kind": "call", "checks": checks()}]),
        )
        self.assertIsNotNone(out.connectivity)
        self.assertEqual(out.connectivity.percent(), 100)
        self.assertEqual(out.connectivity.source_digest, "digest-1")
        s = out.connectivity.scenarios[0]
        self.assertEqual((s.id, s.status, s.bullets), ("scenario-1", "assembled", [BULLETS[0]]))
        self.assertTrue(any("Сквозная связность: собрано 1 из 1" in n for n in out.notes), out.notes)
        # Готовность и статусы — те же.
        self.assertEqual(res.verdicts[0].criteria[0].status, "done")

    def test_broken_without_link_is_downgraded_to_unknown(self):
        out = self._run(
            tool_call("submit_scenarios", **scenarios()),
            tool_call("submit_trace", scenario_id="scenario-1", handoffs=[{
                "step": 0, "kind": "queue",
                "checks": checks("broken", evidence=[], note="вызова не нашлось"),
            }]),
        )
        s = out.connectivity.scenarios[0]
        self.assertEqual(s.status, "unknown")
        self.assertIn("понижено кодом до unknown", s.handoffs[0].checks[0].note)
        self.assertTrue(any("понижено до unknown" in n for n in out.notes), out.notes)

    def test_ok_without_link_is_not_a_confirmation(self):
        out = self._run(
            tool_call("submit_scenarios", **scenarios()),
            tool_call("submit_trace", scenario_id="scenario-1", handoffs=[{
                "step": 0, "kind": "call", "checks": checks("ok", evidence=[]),
            }]),
        )
        self.assertEqual(out.connectivity.scenarios[0].status, "unknown")
        self.assertEqual(out.connectivity.percent(), 0)

    def test_high_confidence_code_basis_accepts_ok_without_exact_line(self):
        grounded = checks("ok", evidence=[])
        for check in grounded:
            check.update({
                "note": "Переход однозначно задан ребром графа и передаёт то же поле состояния.",
                "support": "code",
                "confidence": "high",
            })
        out = self._run(
            tool_call("submit_scenarios", **scenarios()),
            tool_call("submit_trace", scenario_id="scenario-1", handoffs=[{
                "step": 0, "kind": "call", "checks": grounded,
            }]),
        )
        scenario = out.connectivity.scenarios[0]
        self.assertEqual(scenario.status, "assembled")
        self.assertEqual(scenario.handoffs[0].checks[0].support, "code")
        self.assertEqual(scenario.handoffs[0].checks[0].confidence, "high")

    def test_broken_with_link_blocks_critical_scenario(self):
        out = self._run(
            tool_call("submit_scenarios", **scenarios()),
            tool_call("submit_trace", scenario_id="scenario-1", handoffs=[{
                "step": 0, "kind": "call",
                "checks": [{"check": "reachability", "result": "broken",
                            "note": "заявка регистрируется, но дальше никуда не уходит",
                            "evidence": [LINK]}],
            }]),
        )
        s = out.connectivity.scenarios[0]
        self.assertEqual(s.status, "broken")
        self.assertEqual([b.id for b in out.connectivity.blocked()], ["scenario-1"])
        self.assertTrue(any("Критический сценарий" in n and "заблокирован" in n
                            for n in out.notes), out.notes)

    def test_scenario_without_bullets_rejected(self):
        out = self._run(
            tool_call("submit_scenarios", **scenarios(bullets=["чего нет в плане"])),
            tool_call("submit_scenarios", **scenarios()),
            tool_call("submit_trace", scenario_id="scenario-1",
                      handoffs=[{"step": 0, "kind": "call", "checks": checks()}]),
        )
        self.assertEqual(len(out.connectivity.scenarios), 1)
        self.assertEqual(out.connectivity.scenarios[0].status, "assembled")

    def test_composition_is_fixed_after_first_call(self):
        out = self._run(
            tool_call("submit_scenarios", **scenarios()),
            tool_call("submit_scenarios", **scenarios(title="Ещё один")),
            tool_call("submit_trace", scenario_id="scenario-1",
                      handoffs=[{"step": 0, "kind": "call", "checks": checks()}]),
        )
        self.assertEqual([s.title for s in out.connectivity.scenarios],
                         ["Постановка задачи исполнителю"])

    def test_code_in_step_text_rejected(self):
        out = self._run(
            tool_call("submit_scenarios", **scenarios(steps=["Вызов start_task()", "Заявка уходит"])),
            tool_call("submit_scenarios", **scenarios()),
            tool_call("submit_trace", scenario_id="scenario-1",
                      handoffs=[{"step": 0, "kind": "call", "checks": checks()}]),
        )
        self.assertEqual(out.connectivity.scenarios[0].steps,
                         ["Заявка регистрируется", "Заявка уходит исполнителю"])

    def test_untraced_scenario_stays_unknown_and_finish_is_refused(self):
        out = self._run(tool_call("submit_scenarios", **scenarios()))
        self.assertEqual(out.connectivity.scenarios[0].status, "unknown")
        self.assertTrue(any("не прослежены: scenario-1" in n for n in out.notes), out.notes)
        # finish отклонён — ревизор остался без ходов, и в заметках это виден
        # отклонённый вызов.
        self.assertTrue(any("отклонённых вызовов — 1" in n for n in out.notes), out.notes)

    def test_without_scenarios_metric_is_absent_not_zero(self):
        out = self._run()
        self.assertIsNone(out.connectivity)
        self.assertTrue(any("не измерена" in n for n in out.notes), out.notes)


class ReportTest(unittest.TestCase):
    """Контракт отчёта: блок связности и спор с решением в замечаниях."""

    def _model(self, scenarios, decision="GO", readiness=50) -> ProgressModel:
        model = ProgressModel(
            meta={"repo": "r", "branch": "b", "commit": "c", "generated_at": "2026-09-16 10:00"},
            readiness=readiness,
            summary=ProjectSummary(decision=decision, reason="", conclusion=["ok"]),
            connectivity=ConnectivityReview(scenarios=scenarios, source_digest="d"),
        )
        return model

    def test_contract_carries_percent_and_blocked(self):
        data = build_dashboard_data(self._model([
            Scenario(id="s1", title="Справка", entry="e", outcome="ответ показан",
                     steps=["a", "b"], handoffs=[handoff(0)]),
            Scenario(id="s2", title="Запуск работ", entry="e", outcome="работы начаты",
                     steps=["a", "b"], critical=True, handoffs=[handoff(0, "broken")]),
        ]))
        conn = data["connectivity"]
        self.assertEqual(conn["percent"], 50)
        self.assertEqual(conn["total"], 2)
        self.assertEqual([b["title"] for b in conn["blocked"]], ["Запуск работ"])
        self.assertEqual(conn["scenarios"][1]["status"], "broken")
        # Основной вердикт пока не меняется; отдельная схема покажет разрыв.
        self.assertEqual(data["meta"]["decision"], "GO")
        self.assertTrue(any("решение GO при разорванных критических" in g for g in data["gaps"]), data["gaps"])
        html = render_dashboard_html(data)
        self.assertIn("renderConnectivity", html)
        self.assertIn("Запуск работ", html)

    def test_no_scenarios_no_block_no_conflict(self):
        model = self._model([])
        model.connectivity = None
        data = build_dashboard_data(model)
        self.assertNotIn("connectivity", data)
        self.assertFalse(any("Сквозная связность" in g for g in data["gaps"]))


if __name__ == "__main__":
    unittest.main()

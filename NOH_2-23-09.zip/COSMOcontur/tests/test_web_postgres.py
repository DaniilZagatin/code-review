"""Ответы команд в Postgres: тот же код, другой драйвер.

Настоящей базы в тестах нет и быть не должно — прогон обязан работать на
машине без Postgres и без сети. Поэтому драйвер подменяется фиктивным: он
запоминает SQL и параметры и хранит строки в списке. Проверяем не Postgres
(он работает), а то, что наш код разговаривает с ним правильно: `%s` вместо
`?`, `RETURNING id` вместо `lastrowid`, полное имя таблицы со схемой в каждом
запросе (через pgbouncer `search_path` не живёт дольше одной транзакции),
переподключение при обрыве связи и одинаковые с SQLite правила ответа.
"""

from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from pko.errors import PkoError
from pko.web import feedback

DSN = "postgresql://pko:secret@db.example:5432/analytics"


class _FakeError(Exception):
    """База ответила ошибкой на сам запрос — повторять его бессмысленно."""


class _FakeOperationalError(Exception):
    """Связь оборвалась: тот случай, когда повтор как раз и нужен."""


class _FakeDb:
    """Состояние «сервера»: живёт дольше соединения, как настоящая база."""

    def __init__(self) -> None:
        self.rows: list[tuple] = []
        self.log: list[tuple[str, tuple]] = []
        self.connects: list[str] = []
        # Сколько ближайших запросов упадёт обрывом связи.
        self.break_next = 0
        self.fail_ddl = False


class _FakeCursor:
    def __init__(self, db: _FakeDb) -> None:
        self._db = db
        self._result: list[tuple] = []

    def execute(self, sql: str, params: tuple = ()) -> None:
        self._db.log.append((sql, tuple(params)))
        if self._db.break_next:
            self._db.break_next -= 1
            raise _FakeOperationalError("сервер закрыл соединение")
        head = sql.strip().split()[0].upper()
        if head in {"CREATE", "SET"}:
            if self._db.fail_ddl and head == "CREATE":
                raise _FakeError("нет прав на DDL")
            self._result = []
        elif head == "INSERT":
            new_id = len(self._db.rows) + 1
            self._db.rows.append((new_id, *params))
            self._result = [(new_id,)]
        elif head == "SELECT":
            rows = list(self._db.rows)
            if " WHERE analysis_id = " in sql:
                rows = [r for r in rows if r[2] == params[0]]
            rows.reverse()
            self._result = rows[: params[-1]] if params else rows
        else:  # pragma: no cover — в коде других команд нет
            raise AssertionError("неизвестный запрос: " + sql)

    def fetchall(self) -> list[tuple]:
        return self._result


class _FakeConn:
    def __init__(self, db: _FakeDb) -> None:
        self._db = db
        self.autocommit = False
        self.closed = False

    def cursor(self) -> _FakeCursor:
        return _FakeCursor(self._db)

    def close(self) -> None:
        self.closed = True


class _FakeDriver:
    OperationalError = _FakeOperationalError
    InterfaceError = _FakeOperationalError
    Error = _FakeError


class PostgresStoreTest(unittest.TestCase):
    def setUp(self) -> None:
        self.db = _FakeDb()
        self._real_connect = feedback._pg_connect
        self._real_driver = feedback._load_driver

        def fake_connect(driver: object, dsn: str) -> _FakeConn:
            self.db.connects.append(dsn)
            return _FakeConn(self.db)

        feedback._pg_connect = fake_connect
        feedback._load_driver = lambda: _FakeDriver
        self.addCleanup(setattr, feedback, "_pg_connect", self._real_connect)
        self.addCleanup(setattr, feedback, "_load_driver", self._real_driver)
        self.store = feedback.FeedbackStore(dsn=DSN, schema="pko_progress")
        self.addCleanup(self.store.close)

    def _dispute(self, **kwargs) -> feedback.Dispute:
        base = dict(analysis_id="an_1", bullet_index=0, verdict="accept")
        base.update(kwargs)
        return feedback.Dispute(**base)

    def _sql(self) -> list[str]:
        return [sql for sql, _ in self.db.log]

    def test_every_query_names_the_table_with_its_schema(self) -> None:
        """Таблицы приложения лежат в своей схеме, а не в общем `public`.

        И названы полностью в каждом запросе: через pgbouncer в режиме
        transaction pooling `SET search_path` живёт одну транзакцию — DDL на
        старте проходил, а следующий `INSERT` уезжал в другое соединение и
        падал с «relation "disputes" does not exist».
        """
        self.store.save(self._dispute())
        self.store.list()
        sql = self._sql()
        self.assertIn("CREATE SCHEMA IF NOT EXISTS pko_progress", sql)
        self.assertFalse(any(s.startswith("SET search_path") for s in sql))
        for statement in sql:
            if statement.startswith(("INSERT", "SELECT", "CREATE TABLE", "CREATE INDEX")):
                self.assertIn("pko_progress.disputes", statement, statement)

    def test_table_is_created_in_postgres_dialect(self) -> None:
        self.store.connect()
        ddl = "\n".join(self._sql())
        self.assertIn("BIGSERIAL", ddl)
        self.assertNotIn("AUTOINCREMENT", ddl)

    def test_placeholders_are_translated(self) -> None:
        """У libpq свои местозаполнители: `?` доедет до базы синтаксической ошибкой."""
        self.store.save(self._dispute())
        inserts = [sql for sql in self._sql() if sql.startswith("INSERT")]
        self.assertEqual(len(inserts), 1)
        self.assertIn("%s", inserts[0])
        self.assertNotIn("?", inserts[0])

    def test_generated_id_comes_from_returning(self) -> None:
        """`lastrowid` у Postgres пустой — идентификатор возвращает сам запрос."""
        first = self.store.save(self._dispute())
        second = self.store.save(self._dispute())
        self.assertEqual((first.id, second.id), (1, 2))
        self.assertIn("RETURNING id", self._sql()[-1])

    def test_round_trip(self) -> None:
        self.store.save(self._dispute(verdict="reject", comment="Пункт сделан в соседнем сервисе"))
        self.store.save(self._dispute(bullet_index=3))
        items = self.store.list()
        self.assertEqual([d.bullet_index for d in items], [3, 0])
        self.assertEqual(items[1].comment, "Пункт сделан в соседнем сервисе")
        self.assertEqual(items[1].to_dict()["verdict_label"], "Отклонить")

    def test_filter_by_analysis(self) -> None:
        self.store.save(self._dispute(analysis_id="an_1"))
        self.store.save(self._dispute(analysis_id="an_2"))
        self.assertEqual(len(self.store.list(analysis_id="an_2")), 1)
        self.assertEqual(len(self.store.list()), 2)

    def test_broken_connection_is_retried_once(self) -> None:
        """Соединение с внешней базой рвётся само — ответ человека из-за этого теряться не должен."""
        self.store.save(self._dispute())
        self.db.break_next = 1
        saved = self.store.save(self._dispute(bullet_index=7))
        self.assertEqual(saved.bullet_index, 7)
        self.assertEqual(len(self.db.connects), 2)

    def test_query_error_is_not_retried_and_is_named(self) -> None:
        """Ошибка запроса повтором не лечится: молчать о ней хуже, чем упасть.

        И причина уходит наружу понятной ошибкой PKO, а не трассировкой в
        500: на экране оставалось только «Не удалось сохранить ответ».
        """
        self.store.connect()

        def boom(self_: _FakeCursor, sql: str, params: tuple = ()) -> None:
            raise _FakeError("ошибка в запросе")

        original = _FakeCursor.execute
        _FakeCursor.execute = boom
        self.addCleanup(setattr, _FakeCursor, "execute", original)
        with self.assertRaises(PkoError) as ctx:
            self.store.save(self._dispute())
        self.assertIn("ошибка в запросе", ctx.exception.message)
        self.assertIn("/api/health/db", ctx.exception.hint)
        self.assertEqual(len(self.db.connects), 1)

    def test_ping_reports_the_real_cause(self) -> None:
        """«Не сохраняется» объясняется одним запросом, а не логами пода."""
        self.assertIn("pko_progress.disputes", self.store.ping())

        def refuse(driver: object, dsn: str) -> None:
            raise _FakeOperationalError("connection timed out")

        broken = feedback.FeedbackStore(dsn=DSN, schema="pko_progress")
        self.addCleanup(broken.close)
        with mock.patch.object(feedback, "_pg_connect", refuse):
            with self.assertRaises(PkoError) as ctx:
                broken.ping()
        self.assertIn("connection timed out", ctx.exception.message)

    def test_missing_ddl_rights_are_survivable(self) -> None:
        """Схему и таблицу мог завести DBA, а прав на DDL не дать."""
        self.db.fail_ddl = True
        self.store.connect()
        self.assertTrue(any(sql.startswith("SELECT") for sql in self._sql()))

    def test_rules_are_the_same_as_in_sqlite(self) -> None:
        """Проверка ответа — общая: до базы неполное возражение не доходит."""
        with self.assertRaises(PkoError):
            self.store.save(self._dispute(verdict="reject"))
        self.assertEqual(self.db.log, [])

    def test_password_never_leaves_the_store(self) -> None:
        self.assertNotIn("secret", self.store.describe())
        self.assertIn("***", self.store.describe())


class StoreSelectionTest(unittest.TestCase):
    """Что выбрано — Postgres или файл — решает окружение, и только оно."""

    def setUp(self) -> None:
        self.saved = {k: os.environ.get(k) for k in
                      ("PKO_DB_URL", "DATABASE_URL", "PKO_DB_SCHEMA",
                       "DB_SCHEMA", "PKO_FEEDBACK_DB")}
        for key in self.saved:
            os.environ.pop(key, None)
        self.addCleanup(self._restore)

    def _restore(self) -> None:
        for key, value in self.saved.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

    def test_file_by_default(self) -> None:
        self.assertEqual(feedback.default_store().kind(), "sqlite")

    def test_dsn_switches_to_postgres(self) -> None:
        os.environ["DATABASE_URL"] = DSN
        store = feedback.default_store()
        self.assertEqual(store.kind(), "postgres")
        self.assertEqual(store.schema, feedback.DEFAULT_SCHEMA)

    def test_own_variable_wins_over_the_common_one(self) -> None:
        """`DATABASE_URL` — имя общее и на чужой машине может смотреть не туда."""
        os.environ["DATABASE_URL"] = "postgresql://a:b@other/db"
        os.environ["PKO_DB_URL"] = DSN
        self.assertEqual(feedback.default_store().dsn, DSN)

    def test_sqlalchemy_dsn_is_normalised(self) -> None:
        """В корпоративном секрете DSN обычно лежит в форме SQLAlchemy."""
        os.environ["PKO_DB_URL"] = "postgresql+psycopg://pko:secret@db:5432/analytics"
        self.assertEqual(feedback.default_store().dsn,
                         "postgresql://pko:secret@db:5432/analytics")

    def test_schema_comes_from_the_stand_variable(self) -> None:
        os.environ["PKO_DB_URL"] = DSN
        os.environ["DB_SCHEMA"] = "Deep_Research"
        self.assertEqual(feedback.default_store().schema, "deep_research")

    def test_injection_in_schema_name_is_refused(self) -> None:
        """Имя схемы уходит в DDL подстановкой — параметром его не передать."""
        os.environ["PKO_DB_URL"] = DSN
        os.environ["DB_SCHEMA"] = "pko; DROP TABLE disputes"
        with self.assertRaises(PkoError):
            feedback.default_store()

    def test_foreign_dsn_is_refused(self) -> None:
        """Молча уехать в файл нельзя: ответы потерялись бы вместе с подом."""
        os.environ["PKO_DB_URL"] = "mysql://a:b@host/db"
        with self.assertRaises(PkoError):
            feedback.default_store()

    def test_file_path_is_still_honoured(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            os.environ["PKO_FEEDBACK_DB"] = str(Path(tmp) / "f.db")
            store = feedback.default_store()
            self.assertEqual(store.kind(), "sqlite")
            self.assertTrue(str(store.path).endswith("f.db"))


class HealthTest(unittest.TestCase):
    """`/health` говорит, куда именно уедут ответы команд."""

    def setUp(self) -> None:
        from fastapi.testclient import TestClient
        from pko.web.app import app

        self.client = TestClient(app)
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        feedback.reset_store(feedback.FeedbackStore(path=Path(self.tmp.name) / "f.db"))
        self.addCleanup(feedback.reset_store, None)

    def test_reports_the_chosen_storage(self) -> None:
        """В контейнере `sqlite` здесь означает потерянный DSN и потерянные ответы."""
        body = self.client.get("/health").json()
        self.assertEqual(body["status"], "ok")
        self.assertEqual(body["storage"], "sqlite")

    def test_postgres_target_comes_without_password(self) -> None:
        feedback.reset_store(feedback.FeedbackStore(dsn=DSN, schema="pko_progress"))
        body = self.client.get("/api/health").json()
        self.assertEqual(body["storage"], "postgres")
        self.assertNotIn("secret", body["storage_target"])

    def test_db_check_reads_the_store_for_real(self) -> None:
        body = self.client.get("/api/health/db").json()
        self.assertEqual(body["status"], "ok")
        self.assertEqual(body["storage"], "sqlite")

    def test_db_check_names_the_real_cause(self) -> None:
        """Живая проверка: таймаут, нет таблицы, нет прав — текстом, кодом 503."""
        def refuse(driver: object, dsn: str) -> None:
            raise _FakeOperationalError("connection timed out")

        with mock.patch.object(feedback, "_pg_connect", refuse), \
                mock.patch.object(feedback, "_load_driver", lambda: _FakeDriver):
            feedback.reset_store(feedback.FeedbackStore(dsn=DSN, schema="pko_progress"))
            resp = self.client.get("/api/health/db")
        self.assertEqual(resp.status_code, 503)
        self.assertIn("connection timed out", resp.json()["message"])
        self.assertNotIn("secret", resp.text)

    def test_broken_configuration_is_named_not_hidden(self) -> None:
        """Кривой DSN рестартом не лечится — про него надо сказать, а не падать."""
        feedback.reset_store(None)
        os.environ["PKO_DB_URL"] = "mysql://a:b@host/db"
        self.addCleanup(os.environ.pop, "PKO_DB_URL", None)
        body = self.client.get("/health").json()
        self.assertEqual(body["status"], "degraded")
        self.assertIn("Postgres", body["error"])


if __name__ == "__main__":
    unittest.main()

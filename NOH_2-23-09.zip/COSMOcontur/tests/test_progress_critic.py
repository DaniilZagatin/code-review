"""Строгая проверка (`progress.critic`): рецензент перечитывает код по ссылкам
первого агента и может только понижать статусы.

Транспорт подменяется так же, как у первого агента: `ChatClient._create`
отдаёт заготовленные ходы. Результат первого агента здесь не прогоняется, а
собирается руками — рецензенту нужны только вердикты и план.
"""

import os
import unittest
from dataclasses import replace

from fixture_support import ensure_fixture, scripted_responses
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress import critic
from pko.progress.critic import (
    build_critic_brief,
    collect_claims,
    load_critic_prompt,
    run_critic,
)
from pko.progress.matcher import AgentResult
from pko.progress.schema import (
    CriterionVerdict,
    EvidenceRef,
    ItemVerdict,
    PlanItem,
    ProjectSummary,
    calculate_progress,
    compute_decision,
    rated_criteria,
)
from test_progress_matcher import finish, tool_call

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")

BULLETS = ["Заявка попадает исполнителю", "Стороны видят статус"]
ROUTER = EvidenceRef(
    path="backend/src/api/v1/router.py", line=7,
    basis="функция start_task ставит задачу в обработку",
    verified=True, reason="", note="принимает заявку",
)
UNVERIFIED = EvidenceRef(path="backend/nope.py", line=1, basis="x", verified=False, reason="нет файла")

REASON = (
    "Обработчик принимает заявку и сразу возвращает заготовленный ответ: "
    "передачи исполнителю в нём нет, сквозной путь обрывается на приёме."
)


def verdict(statuses: list[str], evidence=None) -> ItemVerdict:
    criteria = []
    for status in statuses:
        c = CriterionVerdict(
            applicable=True, status=status,
            proof="Код есть и работает: путь от заявки до исполнителя проходит целиком.",
            how="Заявка попадает исполнителю сразу.",
            evidence=list(evidence) if evidence is not None else ([ROUTER] if status != "planned" else []),
        )
        criteria.append(c)
    return ItemVerdict(item_id="intake", applicable=True, criteria=criteria)


def result_of(*verdicts: ItemVerdict, plan=None) -> AgentResult:
    plan = plan or [PlanItem(id="intake", title="Постановка задачи", criteria=BULLETS, origin="user")]
    readiness = calculate_progress(rated_criteria(verdicts)) or 0
    return AgentResult(
        items=list(plan), verdicts=list(verdicts), plan=list(plan),
        summary=ProjectSummary(decision=compute_decision(readiness), conclusion=["а", "б", "в"]),
        summary_source="llm", source="llm",
    )


def challenge(item_id="intake", bullet=1, status="partial", reason=REASON, evidence=None) -> dict:
    args = {"item_id": item_id, "bullet": bullet, "status": status, "reason": reason}
    if evidence is not None:
        args["evidence"] = evidence
    return tool_call("submit_challenge", **args)


class CollectClaimsTest(unittest.TestCase):
    def test_only_grounded_applicable_with_verified_links(self):
        plan = [PlanItem(id="intake", title="Этап", criteria=["а", "б", "в", "г", "д"], origin="user")]
        v = ItemVerdict(item_id="intake", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="done", evidence=[ROUTER]),
            CriterionVerdict(applicable=True, status="planned"),
            CriterionVerdict(applicable=True, status="limited", evidence=[UNVERIFIED]),
            CriterionVerdict(applicable=False, na_reason="не про это"),
            CriterionVerdict(applicable=True, status="blocked", evidence=[ROUTER]),
        ])
        claims = collect_claims(plan, [v])
        self.assertEqual([(c.index, c.criterion.status) for c in claims], [(1, "done")])
        self.assertEqual(claims[0].text, "а")

    def test_sorted_done_first(self):
        plan = [PlanItem(id="intake", title="Этап", criteria=["а", "б", "в"], origin="user")]
        v = ItemVerdict(item_id="intake", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="unused", evidence=[ROUTER]),
            CriterionVerdict(applicable=True, status="done", evidence=[ROUTER]),
            CriterionVerdict(applicable=True, status="limited", evidence=[ROUTER]),
        ])
        statuses = [c.criterion.status for c in collect_claims(plan, [v])]
        self.assertEqual(statuses, ["done", "limited", "unused"])

    def test_inapplicable_stage_is_skipped(self):
        plan = [PlanItem(id="intake", title="Этап", criteria=["а"], origin="user")]
        v = ItemVerdict(item_id="intake", applicable=False, criteria=[
            CriterionVerdict(applicable=False, na_reason="чужой этап"),
        ])
        self.assertEqual(collect_claims(plan, [v]), [])

    def test_brief_lists_ids_texts_and_links(self):
        res = result_of(verdict(["done", "planned"]))
        brief = build_critic_brief(collect_claims(res.plan, res.verdicts))
        self.assertIn("Утверждений: 1", brief)
        self.assertIn("item_id=intake, bullet=1", brief)
        self.assertIn(BULLETS[0], brief)
        self.assertIn("backend/src/api/v1/router.py:7", brief)
        self.assertIn("принимает заявку", brief)

    def test_prompt_file_is_shipped(self):
        text, found = load_critic_prompt()
        self.assertTrue(found)
        self.assertIn("строгий рецензент", text)
        self.assertIn("submit_challenge", text)


class RunCriticTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        repo = GitRepo(ensure_fixture())
        cls.tree = Tree.at(repo, repo.resolve("master"))

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)
        self._env = os.environ.get("PKO_CRITIC")
        os.environ.pop("PKO_CRITIC", None)
        self.addCleanup(self._restore_env)

    def _restore_env(self):
        if self._env is None:
            os.environ.pop("PKO_CRITIC", None)
        else:
            os.environ["PKO_CRITIC"] = self._env

    def _run(self, result: AgentResult, *answers, **kwargs) -> AgentResult:
        ChatClient._create = scripted_responses(*answers)
        return run_critic(result, self.tree, SPEC, client=self.client, **kwargs)

    def test_no_challenges_keeps_statuses_and_reports_count(self):
        res = result_of(verdict(["done", "planned"]))
        out = self._run(res, finish())
        self.assertEqual([c.status for c in out.verdicts[0].criteria], ["done", "planned"])
        self.assertEqual(out.summary.decision, "GO")
        self.assertIn("перепроверено утверждений — 1, понижено — 0", " ".join(out.notes))
        self.assertNotIn("не завершена", " ".join(out.notes))

    def test_downgrade_changes_status_proof_and_decision(self):
        seen = []
        res = result_of(verdict(["done", "planned"]))
        out = self._run(res, challenge(status="partial"), finish(),
                        on_verdict=lambda item, v: seen.append((item.id, v.percent())))
        c = out.verdicts[0].criteria[0]
        self.assertEqual(c.status, "partial")
        self.assertEqual(c.status_before, "done")
        self.assertEqual(c.challenge, REASON)
        self.assertTrue(c.proof.startswith("Код есть и работает"))
        self.assertIn("Строгая проверка: " + REASON, c.proof)
        self.assertEqual(c.to_dict()["status_before"], "done")
        # (0.25 + 0) / 2 = 12.5% -> PIVOT: решение пересчитал код, не модель.
        self.assertEqual(out.summary.decision, "PIVOT")
        self.assertEqual(seen, [("intake", 12)])
        self.assertIn("Строгая проверка понизила: «Постановка задачи», буллит 1: "
                      "Работает → Не работает, реализовано частично", out.notes)

    def test_original_result_is_not_mutated(self):
        res = result_of(verdict(["done", "planned"]))
        self._run(res, challenge(status="planned"), finish())
        self.assertEqual(res.verdicts[0].criteria[0].status, "done")
        self.assertEqual(res.summary.decision, "GO")

    def test_cannot_raise_or_keep_same_status(self):
        res = result_of(verdict(["limited", "planned"]))
        out = self._run(res, challenge(status="limited"), finish())
        self.assertEqual(out.verdicts[0].criteria[0].status, "limited")
        self.assertIn("отклонённых попыток понижения — 1", " ".join(out.notes))

    def test_planned_bullet_is_not_a_claim(self):
        res = result_of(verdict(["done", "planned"]))
        out = self._run(res, challenge(bullet=2, status="partial"), finish())
        self.assertEqual(out.verdicts[0].criteria[1].status, "planned")
        self.assertIn("отклонённых попыток", " ".join(out.notes))

    def test_short_reason_is_rejected(self):
        res = result_of(verdict(["done", "planned"]))
        out = self._run(res, challenge(reason="заглушка"), finish())
        self.assertEqual(out.verdicts[0].criteria[0].status, "done")

    def test_reason_with_code_is_rejected(self):
        res = result_of(verdict(["done", "planned"]))
        bad = REASON + " Смотри функцию start_task() в router.py, там всё видно."
        out = self._run(res, challenge(reason=bad), finish())
        self.assertEqual(out.verdicts[0].criteria[0].status, "done")
        self.assertEqual(out.verdicts[0].criteria[0].challenge, "")

    def test_second_downgrade_goes_lower_but_keeps_first_status_before(self):
        res = result_of(verdict(["done", "planned"]))
        out = self._run(res, challenge(status="limited"), challenge(status="planned"), finish())
        c = out.verdicts[0].criteria[0]
        self.assertEqual(c.status, "planned")
        self.assertEqual(c.status_before, "done")
        self.assertEqual(out.summary.decision, "PIVOT")

    def test_new_verified_evidence_is_appended_unverified_dropped(self):
        res = result_of(verdict(["done", "planned"]))
        out = self._run(res, challenge(status="partial", evidence=[
            {"path": "backend/src/api/v1/router.py", "line": 7,
             "basis": "start_task", "note": "возвращает ответ сразу"},
            {"path": "backend/nope.py", "line": 1, "basis": "x"},
        ]), finish())
        paths = [e.path for e in out.verdicts[0].criteria[0].evidence]
        self.assertEqual(paths, ["backend/src/api/v1/router.py", "backend/src/api/v1/router.py"])
        self.assertTrue(all(e.verified for e in out.verdicts[0].criteria[0].evidence))

    def test_disabled_by_env(self):
        os.environ["PKO_CRITIC"] = "false"
        res = result_of(verdict(["done", "planned"]))
        out = self._run(res, challenge(status="planned"), finish())
        self.assertEqual(out.verdicts[0].criteria[0].status, "done")
        self.assertIn("выключена", " ".join(out.notes))

    def test_nothing_to_check_returns_note(self):
        res = result_of(verdict(["planned", "planned"]))
        out = self._run(res, challenge(status="partial"), finish())
        self.assertIn("перепроверять нечего", " ".join(out.notes))

    def test_repo_tools_work_and_first_agent_tools_are_refused(self):
        res = result_of(verdict(["done", "planned"]))
        out = self._run(
            res,
            tool_call("read_file", path="backend/src/api/v1/router.py"),
            # `tool_call` не примет аргумент `name` — он занят именем инструмента.
            {"content": None, "tool_calls": [{"id": "call_wc", "type": "function", "function": {
                "name": "who_calls", "arguments": '{"name": "start_task"}'}}]},
            tool_call("submit_stage", item_id="intake"),
            challenge(status="unused"),
            finish(),
        )
        self.assertEqual(out.verdicts[0].criteria[0].status, "unused")
        self.assertNotIn("не завершена", " ".join(out.notes))

    def test_silence_stops_session_with_note(self):
        res = result_of(verdict(["done", "planned"]))
        out = self._run(res, {"content": "думаю"}, {"content": "ещё"}, {"content": "и ещё"})
        self.assertEqual(out.verdicts[0].criteria[0].status, "done")
        self.assertIn("не вызвал инструмент", " ".join(out.notes))

    def test_step_budget_note(self):
        res = result_of(verdict(["done", "planned"]))
        out = self._run(res, tool_call("read_file", path="backend/src/api/v1/router.py"),
                        tool_call("read_file", path="backend/src/api/v1/router.py", offset=2),
                        max_steps=2)
        self.assertIn("бюджет шагов исчерпан", " ".join(out.notes))

    def test_zero_steps_disables(self):
        res = result_of(verdict(["done", "planned"]))
        out = self._run(res, challenge(status="planned"), finish(), max_steps=0)
        self.assertEqual(out.verdicts[0].criteria[0].status, "done")


if __name__ == "__main__":
    unittest.main()

import type { NextConfig } from "next";

// `pko serve` (FastAPI) слушает отдельным процессом — по умолчанию
// http://127.0.0.1:8000 (backend/pko/cli.py::cmd_serve). В проде оба
// процесса обычно стоят за одним обратным прокси, поэтому переменная
// окружения нужна только для локальной разработки.
const backendUrl = process.env.PKO_BACKEND_URL ?? "http://127.0.0.1:8000";

const nextConfig: NextConfig = {
  // Сборка для контейнера: Next кладёт минимальный сервер и только нужные в
  // рантайме модули в `.next/standalone`. На локальную разработку не влияет.
  output: "standalone",
  // На стенде `/api/*` забирает nginx перед фронтом — этот rewrite нужен
  // локальной разработке. Значение запекается на сборке, поэтому в образе
  // оно должно указывать на бэкенд в том же поде (см. ARG в Dockerfile).
  async rewrites() {
    return [{ source: "/api/:path*", destination: `${backendUrl}/api/:path*` }];
  },
};

export default nextConfig;

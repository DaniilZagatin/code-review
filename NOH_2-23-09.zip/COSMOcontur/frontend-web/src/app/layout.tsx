import type { Metadata } from "next";
import { GeistSans, GeistMono } from "geist/font";
import { Providers } from "./providers";
import "./globals.css";

export const metadata: Metadata = {
  title: "PKO — оценка готовности проекта",
  description: "Сравнение плана проекта с фактическим состоянием кода",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="ru"
      className={`${GeistSans.variable} ${GeistMono.variable} h-full antialiased`}
      suppressHydrationWarning
    >
      <body className="min-h-full flex flex-col">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}

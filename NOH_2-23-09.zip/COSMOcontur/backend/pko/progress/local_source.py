"""Загруженные файлы (включая ZIP-архивы) как источник evidence — с Git-репозиторием
или вместо него.

`ToolBox` (`progress/agent_tools.py`) и весь `extract_all`
(`extractors/runner.py`) трогают только `tree.files`/`tree.read(path)`/
`tree.match(...)` — ни разу не обращаются к `Tree.repo`/`Tree.sha` напрямую
(см. `extractors.base.FileTree`). Поэтому не-git источник — не отдельный
параллельный слой, а второй поставщик того же контракта: агенту после сборки
`TargetRepo` физически всё равно, что за ним стоит, git это, ZIP или файлы
россыпью — и не важно, единственный это источник или дополнение к репозиторию.

Форма загрузки даёт два независимых необязательных поля — репозиторий и
файлы проекта (см. `web/app.py::create_analysis`) — а не выбор одного из
трёх вариантов: у пользователя может быть и репозиторий, и результат
эксперимента, не попавший в него (`metrics.json`, `results.csv`). Если
заполнены оба — `merge_with_uploads` строит один объединённый workspace, а
не два вердикта по отдельности.
"""

from __future__ import annotations

import io
import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from pko.errors import PkoError
from pko.extractors.base import FileTree
from pko.extractors.runner import extract_all
from pko.progress.target_repo import TargetRepo

# Тот же порядок величины, что у `GitRepo.read_text`'s `max_bytes` (2MB) —
# один файл. Отдельно — лимиты на весь workspace, которых у git нет (клон
# читает объекты по одному, а загрузка разворачивается на диск целиком
# сразу): без них ZIP-бомба (маленький архив, огромное содержимое) исчерпает
# диск ещё до того, как агент успеет что-то прочитать.
MAX_FILE_BYTES = 2_000_000
MAX_WORKSPACE_FILES = 5000
MAX_WORKSPACE_BYTES = 200_000_000


@dataclass
class LocalTree:
    """Тот же контракт чтения, что у `extractors.base.Tree`, но с диска."""

    root: Path
    files: list[str] = field(default_factory=list)
    _text_cache: dict[str, str | None] = field(default_factory=dict, repr=False)
    _files_set: set[str] | None = field(default=None, repr=False)

    @property
    def files_set(self) -> set[str]:
        if self._files_set is None:
            self._files_set = set(self.files)
        return self._files_set

    def read(self, path: str) -> str | None:
        if path in self._text_cache:
            return self._text_cache[path]
        full = self.root / path
        try:
            if full.stat().st_size > MAX_FILE_BYTES:
                result = None
            else:
                # errors="replace" — тот же выбор, что и у GitRepo.run() для
                # содержимого файлов: бинарник не должен ронять чтение,
                # только прийти нечитаемой кашей вместо текста.
                result = full.read_text(encoding="utf-8", errors="replace")
        except OSError:
            result = None
        self._text_cache[path] = result
        return result

    def match(self, suffixes: Iterable[str] = (), names: Iterable[str] = ()) -> list[str]:
        suffixes = tuple(suffixes)
        names = {n.lower() for n in names}
        out: list[str] = []
        for p in self.files:
            base = p.rsplit("/", 1)[-1].lower()
            if suffixes and p.lower().endswith(suffixes):
                out.append(p)
            elif names and base in names:
                out.append(p)
        return out


@dataclass
class CombinedTree:
    """Git-дерево + слой загруженных файлов поверх — для случая, когда
    заполнены и репозиторий, и файлы. `overlay` побеждает при совпадении
    пути: то, что пользователь загрузил явно, важнее версии из репозитория.
    """

    primary: FileTree
    overlay: LocalTree
    files: list[str] = field(init=False)
    _files_set: set[str] | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        merged = dict.fromkeys(self.primary.files)
        merged.update(dict.fromkeys(self.overlay.files))
        self.files = sorted(merged)

    @property
    def files_set(self) -> set[str]:
        if self._files_set is None:
            self._files_set = set(self.files)
        return self._files_set

    def read(self, path: str) -> str | None:
        # Множество, а не список: чтение зовут экстракторы и агент сотни раз
        # за прогон, и перебор списка на каждом обращении заметен.
        if path in self.overlay.files_set:
            return self.overlay.read(path)
        return self.primary.read(path)

    def match(self, suffixes: Iterable[str] = (), names: Iterable[str] = ()) -> list[str]:
        suffixes = tuple(suffixes)
        names = {n.lower() for n in names}
        out: list[str] = []
        for p in self.files:
            base = p.rsplit("/", 1)[-1].lower()
            if suffixes and p.lower().endswith(suffixes):
                out.append(p)
            elif names and base in names:
                out.append(p)
        return out


def _safe_relative_path(name: str) -> str | None:
    """Нормализованный `/`-путь внутри workspace или `None`, если небезопасен.

    Отклоняет абсолютные пути, диски Windows (`C:\\...`) и любой `..`-сегмент
    после нормализации — не только буквальную подстроку `..`, которую можно
    обойти вариантами вроде `a/../../b`.
    """
    normalized = name.replace("\\", "/").strip("/")
    if not normalized or normalized.startswith("/") or ":" in normalized.split("/", 1)[0]:
        return None
    parts = [p for p in normalized.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts) or not parts:
        return None
    return "/".join(parts)


class _Budget:
    def __init__(self) -> None:
        self.files = 0
        self.bytes = 0

    def check(self, size: int) -> None:
        """Поместится ли ещё столько — до того, как это прочитано в память.

        `add` считает уже прочитанное, и для ZIP этого мало: `ZipFile.read`
        разворачивает элемент целиком в память, а объявленный размер известен
        заранее. Архив на сто килобайт с элементом на десять гигабайт убивал
        бы процесс до первой проверки бюджета — сам бюджет защищал диск, а
        не память.
        """
        if size > MAX_WORKSPACE_BYTES or self.bytes + size > MAX_WORKSPACE_BYTES:
            raise PkoError(
                "Загруженные материалы слишком большие в сумме.",
                hint=f"ограничение — {MAX_WORKSPACE_BYTES // 1_000_000} МБ суммарно",
            )

    def add(self, size: int) -> None:
        self.files += 1
        self.bytes += size
        if self.files > MAX_WORKSPACE_FILES:
            raise PkoError(
                "Слишком много файлов в загруженных материалах.",
                hint=f"ограничение — {MAX_WORKSPACE_FILES} файлов",
            )
        if self.bytes > MAX_WORKSPACE_BYTES:
            raise PkoError(
                "Загруженные материалы слишком большие в сумме.",
                hint=f"ограничение — {MAX_WORKSPACE_BYTES // 1_000_000} МБ суммарно",
            )


def _write(dest: Path, relative: str, data: bytes, budget: _Budget) -> str:
    budget.add(len(data))
    target = dest / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return relative


def _extract_zip_member(archive: zipfile.ZipFile, info: zipfile.ZipInfo,
                         dest: Path, budget: _Budget, prefix: str = "",
                         strip_root: str = "") -> str:
    relative = _safe_relative_path(info.filename)
    if relative is None:
        raise PkoError(
            "ZIP-архив содержит небезопасный путь.",
            hint=f"элемент архива: {info.filename!r}",
        )
    if strip_root and relative.startswith(strip_root + "/"):
        relative = relative[len(strip_root) + 1:]
    if prefix:
        relative = f"{prefix}/{relative}"
    # Сначала по объявленному размеру, только потом чтение: распакованный
    # элемент попадает в память целиком.
    budget.check(info.file_size)
    return _write(dest, relative, archive.read(info), budget)


def _archive_slug(filename: str) -> str:
    """Имя каталога для содержимого одного архива.

    Берётся из имени файла: оно единственное, чем один загруженный репозиторий
    отличается от другого.
    """
    stem = Path(filename.replace("\\", "/")).name
    if stem.lower().endswith(".zip"):
        stem = stem[:-4]
    slug = re.sub(r"[^\w.-]+", "-", stem, flags=re.UNICODE).strip("-.")
    return slug or "archive"


def _common_root(names: list[str]) -> str:
    """Единственный общий верхний каталог архива, если он есть.

    Архивы с гитхаба и битбакета кладут всё в одну папку `repo-main/`. Если
    добавить к ней ещё и префикс, получится `repo/repo-main/...` — глубже и
    без пользы. Такой корень снимаем и ставим свой.
    """
    roots = set()
    for name in names:
        clean = name.replace("\\", "/").strip("/")
        if not clean:
            continue
        head = clean.split("/", 1)
        if len(head) == 1:
            return ""          # файл лежит в корне архива — общего корня нет
        roots.add(head[0])
        if len(roots) > 1:
            return ""
    return next(iter(roots), "")


def _extract_uploads(
    uploads: list[tuple[str, bytes]], dest: Path, budget: _Budget,
    notes: list[str] | None = None,
) -> list[str]:
    """Записать загруженные файлы в `dest`; `.zip` распаковывается.

    Каждый архив уходит в свой каталог, если архивов больше одного. Раньше все
    распаковывались в общий корень, и файлы с одинаковыми путями молча затирали
    друг друга: у любых двух репозиториев есть `README.md`, `requirements.txt`
    и `src/main.py`. Для мультиагентной системы это ломало главное — понять,
    какой из агентов что делает: половина файлов оказывалась чужой.

    Один архив распаковывается как раньше, без префикса: пути в отчётах не
    должны меняться там, где менять их незачем.
    """
    archives = [f for f, _ in uploads if f.lower().endswith(".zip")]
    many = len(archives) > 1
    indexed: list[str] = []
    seen: set[str] = set()
    clashes = 0

    for filename, data in uploads:
        if filename.lower().endswith(".zip"):
            try:
                with zipfile.ZipFile(io.BytesIO(data)) as archive:
                    members = [i for i in archive.infolist() if not i.is_dir()]
                    prefix = _archive_slug(filename) if many else ""
                    strip = _common_root([i.filename for i in members]) if prefix else ""
                    for info in members:
                        path = _extract_zip_member(archive, info, dest, budget,
                                                   prefix=prefix, strip_root=strip)
                        if path in seen:
                            clashes += 1
                        seen.add(path)
                        indexed.append(path)
            except zipfile.BadZipFile as exc:
                raise PkoError(f"Не удалось прочитать ZIP-архив {filename!r}.", hint=str(exc)) from exc
            continue
        relative = _safe_relative_path(filename)
        if relative is None:
            raise PkoError("Недопустимое имя файла.", hint=f"получено: {filename!r}")
        path = _write(dest, relative, data, budget)
        if path in seen:
            clashes += 1
        seen.add(path)
        indexed.append(path)

    if notes is not None:
        if many:
            notes.append(
                "Загружено архивов: " + str(len(archives)) + " — каждый распакован "
                "в свой каталог (" + ", ".join(_archive_slug(a) for a in archives[:6]) + ")"
            )
        if clashes:
            notes.append(
                f"Файлов с совпадающими путями: {clashes} — более поздняя загрузка "
                "затёрла более раннюю. Проверьте, не загружены ли два архива с "
                "одинаковым содержимым."
            )
    return sorted(seen)


def as_uploads(items: Iterable[object]) -> list[tuple[str, bytes]]:
    """Привести источники к паре «имя, содержимое».

    Веб отдаёт файл формы, уже сложенный на диск, вместе с исходным именем —
    пара «имя, путь»; тесты передают пару «имя, байты»; CLI и пакетный прогон
    отдают пути на диске. Ветвить из-за этого весь дальнейший код незачем:
    различие снимается здесь, на входе.
    """
    out: list[tuple[str, bytes]] = []
    for item in items:
        if isinstance(item, (str, Path)):
            path = Path(item)
            if not path.is_file():
                raise PkoError(
                    f"Файл не найден: {path}",
                    hint="проверьте путь к архиву",
                )
            out.append((path.name, path.read_bytes()))
            continue
        name, data = item  # type: ignore[misc]
        if isinstance(data, (str, Path)):
            data = Path(data).read_bytes()
        out.append((str(name), bytes(data)))
    return out


def build_empty_workspace(dest: Path) -> TargetRepo:
    """Ни репозиторий, ни файлы не предоставлены — не ошибка запроса: агент
    всё равно запускается, просто видит пустой снимок материалов.

    Никакого специального сообщения сюда не подставляется — что писать в
    вердикт при пустом evidence, агент решает сам через уже существующую
    инструкцию `_AGENT_SYSTEM` ("если подтверждения не нашёл — отправь
    NOT_STARTED с пустым evidence"): это тот же путь, что и при обычном
    "в репозитории ничего не нашлось", просто изначально пусто.
    """
    dest.mkdir(parents=True, exist_ok=True)
    tree = LocalTree(root=dest, files=[])
    return TargetRepo(repo=None, sha="", branch="", tree=tree, extraction=extract_all(tree))


def build_target_repo_from_uploads(
    uploads: Iterable[object], dest: Path, junit_path: str | Path | None = None,
) -> TargetRepo:
    """Только загруженные файлы, без репозитория — `TargetRepo.repo=None`.

    `sha`/`branch` пустые — не заглушка ради заглушки: `run_progress` кладёт
    их только в `meta["commit"]`/`meta["branch"]`, а там пустое значение уже
    отображается как `—`/пусто и в футере CLI-отчёта, и в dashboard (поле
    убрано из шапки раньше).

    `junit_path` — отчёт о прогоне тестов, тот же, что принимает
    `load_target` для git-источника: у архива с кодом он не менее уместен.
    """
    dest.mkdir(parents=True, exist_ok=True)
    budget = _Budget()
    notes: list[str] = []
    files = _extract_uploads(as_uploads(uploads), dest, budget, notes)
    if not files:
        raise PkoError("Не выбрано ни одного файла.", hint="загрузите хотя бы один файл")
    tree = LocalTree(root=dest, files=sorted(files))
    extraction = extract_all(tree, junit_path=junit_path)
    # Как разложены архивы — часть картины: на мультиагентной системе читателю
    # отчёта важно знать, что репозиториев было несколько и какие именно.
    extraction.notes.extend(notes)
    return TargetRepo(repo=None, sha="", branch="", tree=tree, extraction=extraction)


def merge_with_uploads(target: TargetRepo, uploads: Iterable[object], dest: Path) -> TargetRepo:
    """Репозиторий + дополнительные файлы поверх — заполнены оба поля формы.

    Извлечение (`extract_all`) считается заново на объединённом дереве:
    экстракторы должны видеть и файлы из репозитория, и дополнительные
    загруженные — иначе `find_unclaimed_paths`/агентные инструменты видели бы
    только часть материалов в зависимости от того, кто спрашивает.
    """
    dest.mkdir(parents=True, exist_ok=True)
    budget = _Budget()
    notes: list[str] = []
    files = _extract_uploads(as_uploads(uploads), dest, budget, notes)
    if not files:
        return target
    overlay = LocalTree(root=dest, files=sorted(files))
    combined = CombinedTree(primary=target.tree, overlay=overlay)
    extraction = extract_all(combined)
    extraction.notes.extend(notes)
    return TargetRepo(
        repo=target.repo, sha=target.sha, branch=target.branch,
        tree=combined, extraction=extraction,
    )

"""Versioned hypotheses, not project evidence. No repository access or scoring."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from pko.errors import ValidationError

CATALOG_PATH = Path(__file__).with_name("risk_patterns.json")
MAX_PATTERNS_PER_CALL = 8
DOMAINS = {
    "general": "Общие механизмы",
    "deposits": "Вклады",
    "payments": "Платежи",
    "recommendations": "Рекомендации",
    "documents": "Документооборот",
    "ai_agents": "AI-агенты",
}
NOTICE = (
    "Библиотека гипотез, не доказательства проекта. Условия применимости нужно подтвердить "
    "прочитанными материалами конкретного узла или стыка. Возможные контроли ещё не найдены: "
    "проверь их наличие и охват. Неизвестное не означает отсутствие защиты. "
    "Шаблоны и их ID нельзя использовать как evidence риска."
)


def validate_catalog(data: Any) -> dict[str, Any]:
    """Reject broken bundled content before exposing it to the model."""
    def fail(detail: str) -> None:
        raise ValidationError("Некорректная библиотека рисков: " + detail,
                              "Проверьте risk_patterns.json и версию схемы.")

    if not isinstance(data, dict) or data.get("schema_version") != 1:
        fail("ожидается schema_version=1")
    if not isinstance(data.get("version"), str) or not data["version"].strip():
        fail("нет версии каталога")
    patterns = data.get("patterns")
    if not isinstance(patterns, list) or not patterns:
        fail("нет шаблонов")
    ids: set[str] = set()
    for item in patterns:
        if not isinstance(item, dict):
            fail("шаблон должен быть объектом")
        pid = item.get("id")
        if not isinstance(pid, str) or not re.fullmatch(r"[A-Z]{1,4}\d{2}", pid) or pid in ids:
            fail("неверный или повторный ID")
        ids.add(pid)
        if not isinstance(item.get("domain"), str) or item["domain"] not in DOMAINS:
            fail(f"{pid}: неизвестный предметный набор")
        for key in ("title", "mechanism"):
            if not isinstance(item.get(key), str) or not item[key].strip():
                fail(f"{pid}: отсутствует {key}")
        for key in ("applies_when", "facts_to_check", "possible_controls", "reject_when"):
            values = item.get(key)
            if not isinstance(values, list) or not values or any(
                not isinstance(v, str) or not v.strip() for v in values
            ):
                fail(f"{pid}: требуется непустой список {key}")
        related = item.get("related")
        if not isinstance(related, list) or any(not isinstance(v, str) for v in related):
            fail(f"{pid}: неверные related")
    for item in patterns:
        if any(pid not in ids or pid == item["id"] for pid in item["related"]):
            fail(f"{item['id']}: неизвестный или собственный related")
    return data


def load_catalog() -> dict[str, Any]:
    try:
        data = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ValidationError("Библиотека рисков недоступна или повреждена.",
                              "Восстановите risk_patterns.json из поставки PKO.") from exc
    return validate_catalog(data)


def render_index() -> str:
    catalog = load_catalog()
    lines = [f"Каталог гипотез операционного риска · {catalog['version']}", NOTICE,
             "Выбери по фактам, а не по названию проекта. Для подробностей вызови "
             "read_risk_patterns(ids=[…]), до 8 ID за вызов. Предметные наборы дополняют общие. "
             "Связанные шаблоны — другие вопросы к тому же механизму, не отдельные риски автоматически."]
    for domain, label in DOMAINS.items():
        lines.append(f"\n{label}:")
        for pattern in catalog["patterns"]:
            if pattern["domain"] == domain:
                lines.append(f"{pattern['id']} · {pattern['title']} — только если: "
                             + "; ".join(pattern["applies_when"]))
    return "\n".join(lines)


def read_patterns(ids: Any) -> str:
    if (not isinstance(ids, list) or not 1 <= len(ids) <= MAX_PATTERNS_PER_CALL
            or any(not isinstance(pid, str) for pid in ids)):
        raise ValidationError("Передай ids: от 1 до 8 ID из каталога.")
    catalog = load_catalog()
    by_id = {p["id"]: p for p in catalog["patterns"]}
    unknown = [pid for pid in ids if pid not in by_id]
    if unknown:
        raise ValidationError("Неизвестные ID шаблонов: " + ", ".join(unknown),
                              "Выберите ID из каталога после построения дерева.")
    return json.dumps({"catalog_version": catalog["version"], "notice": NOTICE,
                       "patterns": [by_id[pid] for pid in dict.fromkeys(ids)]},
                      ensure_ascii=False, indent=2)

"""Модель одного прогона: клиентский путь из образа результата и оценка его
этапов по материалам проекта.

Ключевой принцип новой версии — **тексты пути не пишет модель**. Названия
этапов, их описания и буллиты копируются из образа результата дословно и
живут в `PlanItem`; вердикт (`ItemVerdict`) добавляет к ним только две вещи:
относится ли пункт к рассматриваемой инициативе и в каком он состоянии. Текст
и оценка разведены по разным объектам, поэтому переформулировать буллет
физически нечем: в вердикте для текста просто нет поля.

Это заменило прежнюю конструкцию, где модель сама сочиняла и этапы, и
формулировки возможностей. Она давала либо технический язык, либо — после
починки языка — гладкий, но не тот текст: отчёт переставал совпадать с
образом результата, который команда согласовала и по которому себя мерит.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Iterable

# Шкала готовности: в каком состоянии буллит образа результата в коде.
# Граница проходит не по тому, есть ли у агента тул, а по тому, отрабатывает
# ли сквозной путь и задействован ли написанный код в рабочем сценарии.
# `blocked` — не «хуже, чем planned», а другое: отсутствие результата
# блокирует следующий шаг.
CRITERION_STATUSES = ("done", "limited", "unused", "partial", "planned", "blocked")

# Оценивается прототип, а спрашивают с него по-разному. Поэтому шкал две, и
# статус у буллита один: код считает по нему оба числа, модель не оценивает
# один и тот же пункт дважды и не может их рассогласовать.
#
# ПРОТОТИП — доказана ли идея. Ровные четверти: каждый шаг вниз по шкале
# стоит 25 пунктов, и пересказать такую шкалу можно с одного взгляда.
POC_WEIGHT = {
    "done": 1.0,       # Работает
    "limited": 0.75,   # Работает с ограничениями
    "unused": 0.5,     # Код реализован, но не используется
    "partial": 0.25,   # Не работает, реализовано частично
    "planned": 0.0,    # Не реализовано
    "blocked": 0.0,
}
# ПРОМ — получает ли пользователь результат, и ничего больше. Засчитывается
# только работающее; ограничение — половина. Всё остальное ноль: незаконченный
# и неподключённый код пользователю не виден вовсе, функции для него нет.
PROD_WEIGHT = {
    "done": 1.0,
    "limited": 0.5,
    "unused": 0.0,
    "partial": 0.0,
    "planned": 0.0,
    "blocked": 0.0,
}
# Главная шкала — прототипная: по ней считается процент в шапке, процент
# этапа и решение. Прежнее имя оставлено, чтобы не переписывать вызовы.
CRITERION_WEIGHT = POC_WEIGHT
STATUS_LABEL = {
    "done": "Работает",
    "limited": "Работает с ограничениями",
    "unused": "Код реализован, но не используется",
    "partial": "Не работает, реализовано частично",
    "planned": "Не реализовано",
    "blocked": "Блокирует",
}

# Статусы прежних версий: старые прогоны и сохранённые модели не должны
# падать при чтении. `scaffold` («Почти нет», 30%) ближе всего к «Не работает,
# реализовано частично». Прежний `partial` («код есть, но к агенту не
# подключён») по смыслу стал нынешним `unused`, но переименовать его нечем:
# имя занято другим статусом, и молчаливая подмена переписала бы старые отчёты.
STATUS_ALIASES = {"scaffold": "partial"}

# Статусы, требующие подтверждения ссылкой на код: всё, кроме «не реализовано».
# Отсутствие результата ссылкой не доказывается, наличие — обязано. Список
# выводится из шкалы, а не перечисляется руками: новый статус иначе тихо
# проедет мимо гейта (так `limited` и `unused` какое-то время проезжали).
GROUNDED_STATUSES = tuple(s for s in CRITERION_STATUSES if s != "planned")


# Код в тексте для бизнеса: имена функций, пути к файлам, вызовы, декораторы.
# Такой текст читателю без технического контекста ничего не объясняет.
# CamelCase сюда не входит намеренно: в деловом тексте законно встречаются
# названия продуктов — LibreOffice, CyberPort, AppSec, — и запрещать их значит
# мешать писать по-человечески. Ловим то, что бывает только кодом.
_CODE_IN_TEXT = re.compile(
    r"(?:\b[\w/]+\.(?:py|ts|tsx|java|sql|json|yaml|yml)\b"    # путь к файлу
    r"|\b[a-zA-Z]\w*_\w+\b"                                   # snake_case
    r"|\b\w+\(\)"                                             # вызов функции
    r"|@\w+)"                                                 # декоратор
)


def contains_code(text: str) -> str:
    """Первый найденный кодовый фрагмент в тексте, иначе пустая строка."""
    match = _CODE_IN_TEXT.search(text or "")
    return match.group(0) if match else ""

# Решений на текущем шаге два: порог пройден или нет. «NO GO» снят
# сознательно — правило «≥50% → GO, иначе PIVOT» должен уметь пересказать
# любой читатель отчёта, а третье значение из него не выводится.
DECISIONS = ("GO", "PIVOT")

# Верхнеуровневая оценка: соответствует ли код образу результата ПО СУТИ.
# Постатейный разбор считает буллиты, а этот ответ — про целое. Агент склонен
# сверять формулировки слово в слово, и без отдельного вопроса «делает ли
# система то, ради чего затевалась» отчёт превращается в придирки к словам.
MATCH_LEVELS = ("matches", "mostly", "mismatch")
MATCH_LABEL = {
    "matches": "Код соответствует образу результата",
    "mostly": "Код в основном соответствует образу результата",
    "mismatch": "Образ результата не соответствует предоставленному коду",
}

# Порог решения — по готовности прототипа: оценивается именно прототип, и
# спрашивать с него по промышленной планке на этом шаге не за что.
# Одно правило и ничего больше: так его может пересказать любой читатель
# отчёта, не заглядывая в документацию.
READY_THRESHOLD = 40


def scale_rows() -> list[dict[str, Any]]:
    """Шкала для легенды отчёта: ответ, оба веса и что он означает.

    Единственный источник и для расчёта, и для легенды: разойтись они не могут.
    `weight` — вес прототипа (по нему главный процент), `weight_prod` — вес
    промышленного решения.
    """
    # Короткая подпись — только для строки-легенды: полные названия статусов
    # («Код реализован, но не используется») в одну строку не помещаются, а
    # перенос превращает легенду в блок на три строки. В самом пункте
    # по-прежнему стоит полное название из STATUS_LABEL.
    short = {
        "done": "Работает",
        "limited": "С ограничениями",
        "unused": "Не используется",
        "partial": "Частично",
        "planned": "Не реализовано",
    }
    meaning = {
        "done": "работает целиком, ограничений не найдено",
        "limited": "работает, но есть понятное ограничение",
        "unused": "код написан, но в рабочем сценарии не задействован",
        "partial": "сделана часть, сквозной путь не отрабатывает",
        "planned": "в коде не найдено",
    }
    rows = [
        {
            "status": status,
            "label": STATUS_LABEL[status],
            "short": short[status],
            "weight": int(POC_WEIGHT[status] * 100),
            "weight_prod": int(PROD_WEIGHT[status] * 100),
            "meaning": meaning[status],
        }
        for status in ("done", "limited", "unused", "partial", "planned")
    ]
    rows.append({
        "status": "na",
        "label": "Не применимо",
        "short": "Не применимо",
        "weight": None,
        "weight_prod": None,
        "meaning": "пункт не про код — исключён из расчёта",
    })
    return rows


def compute_decision(readiness: int) -> str:
    """Решение по одному порогу готовности прототипа: ≥40% — GO, иначе PIVOT.

    Считает код, а не модель и не шаблон.
    """
    return "GO" if readiness >= READY_THRESHOLD else "PIVOT"


def decision_reason(readiness: int) -> str:
    """Строка расчёта под решением — чтобы бейдж не выглядел волшебным."""
    sign = "≥" if readiness >= READY_THRESHOLD else "<"
    return f"{readiness}% {sign} {READY_THRESHOLD}%"

# Столько тематических блоков помещается в отчёт, не превращая его в список
# из одного пункта на блок. Промпт просит того же, но одной просьбы мало:
# на живом прогоне модель выдала 11 групп на 12 буллитов.
MAX_GROUPS = 4
OTHER_GROUP = "Прочее"


def limit_groups(names: list[str], limit: int = MAX_GROUPS) -> dict[str, str]:
    """Свести группы к `limit` штукам. Возвращает отображение старое → новое.

    Крупные группы сохраняются как есть, мелкие сливаются в «Прочее».
    Порядок появления сохраняется, чтобы отчёт не перетасовывался между
    прогонами. Слияние честное: объединённый блок называется «Прочее», а не
    выдаёт разнородные пункты за одну тему.
    """
    order: list[str] = []
    counts: dict[str, int] = {}
    for name in names:
        clean = (name or "").strip() or "Функционал"
        if clean not in counts:
            counts[clean] = 0
            order.append(clean)
        counts[clean] += 1

    if len(order) <= limit:
        return {name: name for name in order}

    # Отдельным блоком остаётся только группа хотя бы из двух пунктов:
    # блок «1 из 1» ничего не группирует и место занимает зря. Из них
    # берутся самые крупные, при равенстве — встретившаяся раньше.
    ranked = sorted(
        (name for name in order if counts[name] > 1),
        key=lambda n: (-counts[n], order.index(n)),
    )
    keep = set(ranked[: limit - 1])
    return {name: (name if name in keep else OTHER_GROUP) for name in order}


def calculate_progress(
    criteria: list["CriterionVerdict"], weights: dict[str, float] | None = None,
) -> int | None:
    """Детерминированный расчёт готовности по списку буллитов.

    Формула — сумма весов на число применимых буллитов. Веса живут в
    `POC_WEIGHT` (по умолчанию) и `PROD_WEIGHT` и здесь не повторяются.

    Неприменимые буллиты (`applicable=False`) исключаются из знаменателя:
    декларация эффекта или список потребителей — не про код, и тянуть из-за
    них готовность вниз значит наказывать инициативу за формат слайда.
    Возвращает None, если применимых буллитов нет.
    """
    if not criteria:
        return None
    usable = [c for c in criteria if c.applicable]
    if not usable:
        return None
    table = weights if weights is not None else POC_WEIGHT
    total = sum(table.get(c.status, 0.0) for c in usable)
    return round(total / len(usable) * 100)


def calculate_prod_progress(criteria: list["CriterionVerdict"]) -> int | None:
    """Готовность промышленного решения — та же арифметика, строже веса."""
    return calculate_progress(criteria, PROD_WEIGHT)


def calculate_closed_share(criteria: list["CriterionVerdict"]) -> int | None:
    """Доля буллитов со статусом «Работает» — второе, более простое число.

    Расхождение с готовностью показывает, много ли пунктов держится на
    ограничениях, незадействованном коде и частичной реализации.
    """
    usable = [c for c in criteria if c.applicable]
    if not usable:
        return None
    return round(sum(1 for c in usable if c.status == "done") / len(usable) * 100)


@dataclass(frozen=True)
class PlanItem:
    """Один этап клиентского пути — дословно из текстового ввода.

    `criteria` — буллиты этапа в исходном порядке и исходной редакции. Они
    попадают сюда на фазе разбора текста и дальше не меняются: вердикт
    ссылается на них по позиции, а не пересылает текст заново.
    """

    id: str
    title: str
    description: str = ""
    criteria: list[str] = field(default_factory=list)
    origin: str = "user"

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "criteria": list(self.criteria),
            "origin": self.origin,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "PlanItem":
        return PlanItem(
            id=d["id"],
            title=d["title"],
            description=d.get("description", ""),
            criteria=list(d.get("criteria") or []),
            origin=d.get("origin", "user"),
        )


@dataclass(frozen=True)
class EvidenceRef:
    """Одна ссылка на материалы, подтверждающая состояние буллита.

    `verified=False` не отбрасывается — понижается и остаётся в модели с
    причиной: утверждение без доказательства не публикуется как «материалы
    показывают».
    """

    path: str
    line: int | None
    basis: str
    verified: bool
    reason: str
    # Роли («объявление», «подключение», «инструмент агента», «тест») здесь
    # были и убраны: они требовали от читателя знать разницу между ярлыками,
    # а от модели — расставлять их без ошибок. Не случилось ни того, ни
    # другого, зато один раз ярлык уже привёл к неверному понижению статуса.
    #
    # Что происходит в этой строке — одна фраза человеческим языком.
    # Без неё ссылка остаётся координатой: читатель видит «router.py:42»
    # и всё равно не знает, что там.
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path, "line": self.line, "basis": self.basis,
            "verified": self.verified, "reason": self.reason,
            "note": self.note,
        }


@dataclass
class CriterionVerdict:
    """Оценка одного буллита этапа: относится ли он к инициативе и что с ним.

    Текста здесь нет намеренно — он берётся из `PlanItem.criteria` по той же
    позиции. Модель не может ни переписать буллет, ни выбросить его, ни
    добавить новый: длина списка сверяется с планом.

    `applicable=False` — буллит не про эту инициативу. Тогда `status`
    игнорируется, пункт показывается серым и не участвует в расчёте
    готовности этапа. Это не «плохо» и не «не сделано»: чужой пункт не должен
    ни портить, ни улучшать картину.
    """

    applicable: bool = False
    status: str = ""
    # Раскрытие пункта — два буллита, и ничего больше:
    #   «Проверка»     → proof: есть ли код и работает ли он. Человеческим
    #                    языком: «код есть и работает», «код есть, но в
    #                    сценарии не задействован», «кода нет».
    #   «Как работает» → how: что система умеет и каким образом — обычными
    #                    словами, так, как это объяснили бы коллеге.
    # Ни в одном из двух нет ссылок на репозиторий: читатель отчёта не пойдёт
    # по пути к файлу, а проверка ссылок — дело кода, не глаз читателя.
    # Доказательства (`evidence`) остаются в модели и держат гейт статуса, но
    # на экран не выводятся.
    proof: str = ""
    how: str = ""
    # Почему пункт не про эту инициативу. Исключение из знаменателя — самый
    # сильный рычаг в руках модели: пункт исчезает из расчёта, и в отличие от
    # любого статуса подтверждения для этого не требуется. Значит требуется
    # хотя бы объяснение, и оно должно быть видно в отчёте.
    na_reason: str = ""
    # Поля прежних версий, читаются как запасной источник, чтобы сохранённые
    # прогоны не теряли текст: `business`/`comment` — это «как работает»,
    # `technical`/`why` — это «проверка».
    business: str = ""
    technical: str = ""
    why: str = ""
    comment: str = ""
    evidence: list[EvidenceRef] = field(default_factory=list)
    # Тематическая группа для вёрстки отчёта («Обработка запросов»).
    # Только оформление: на расчёт готовности не влияет никак.
    group: str = ""
    # След строгой проверки (`progress.critic`): если рецензент понизил статус,
    # здесь лежит прежний статус и его довод. Довод же дописывается в
    # «Проверку» — читатель видит, за что снято, а не только новый статус.
    status_before: str = ""
    challenge: str = ""

    def __post_init__(self) -> None:
        # Статусы прежних версий приводим к нынешним здесь, а не только при
        # разборе ответа модели: сохранённые `progress_model.json` читаются
        # тем же классом и не должны падать после смены шкалы.
        self.status = STATUS_ALIASES.get(self.status, self.status)
        if self.status and self.status not in CRITERION_STATUSES:
            raise ValueError(f"неизвестный статус буллита: {self.status}")

    @property
    def weight(self) -> float:
        """Вес по шкале прототипа — главной."""
        return POC_WEIGHT.get(self.status, 0.0)

    @property
    def prod_weight(self) -> float:
        return PROD_WEIGHT.get(self.status, 0.0)

    @property
    def verified_evidence(self) -> list[EvidenceRef]:
        return [e for e in self.evidence if e.verified]

    @property
    def is_grounded(self) -> bool:
        """Есть ли подтверждение у заявленного прогресса.

        «Не реализовано» подтверждать нечем — отсутствие ссылкой не
        доказывается. Остальным статусам нужна хотя бы одна проверенная
        ссылка на код.
        """
        if not self.applicable or self.status == "planned":
            return True
        return bool(self.verified_evidence)

    @property
    def proof_text(self) -> str:
        """«Проверка». Прежние прогоны клали это в `technical` или `why`."""
        return self.proof or self.technical or self.why

    @property
    def how_text(self) -> str:
        """«Как работает». Прежние прогоны клали это в `business`/`comment`."""
        return self.how or self.business or self.comment

    def to_dict(self) -> dict[str, Any]:
        return {
            "applicable": self.applicable,
            "na_reason": self.na_reason,
            "status": self.status,
            "status_label": STATUS_LABEL.get(self.status, self.status),
            "proof": self.proof_text,
            "how": self.how_text,
            "group": self.group,
            "status_before": self.status_before,
            "challenge": self.challenge,
            "evidence": [e.to_dict() for e in self.evidence],
        }


@dataclass
class ItemVerdict:
    """Оценка одного этапа: применимость этапа и состояние его буллитов."""

    item_id: str
    applicable: bool = False
    criteria: list[CriterionVerdict] = field(default_factory=list)

    @property
    def applicable_criteria(self) -> list[CriterionVerdict]:
        """Буллиты, входящие в расчёт. У неприменимого этапа их нет.

        Этап, не относящийся к инициативе, серый целиком (`percent()` даёт
        `None`), и его пункты не могут при этом тянуть общую готовность:
        флаг этапа и флаги буллитов читаются здесь вместе.
        """
        if not self.applicable:
            return []
        return [c for c in self.criteria if c.applicable]

    def percent(self) -> int | None:
        """Готовность этапа: `calculate_progress` по всем буллитам этапа.

        `None` — этап не относится к инициативе или в нём нет буллитов:
        серый, в расчёт не входит.
        """
        if not self.applicable:
            return None
        return calculate_progress(self.criteria)

    @property
    def evidence(self) -> list[EvidenceRef]:
        return [e for c in self.criteria for e in c.evidence]

    @property
    def ungrounded_count(self) -> int:
        return sum(1 for c in self.criteria if not c.is_grounded)

    def to_dict(self) -> dict[str, Any]:
        return {
            "item_id": self.item_id,
            "applicable": self.applicable,
            "percent": self.percent(),
            "criteria": [c.to_dict() for c in self.criteria],
        }


def rated_criteria(verdicts: Iterable["ItemVerdict"]) -> list[CriterionVerdict]:
    """Буллиты, которые входят в общий расчёт: только из применимых этапов.

    Единственный источник списка для готовности, доли закрытых и решения —
    и для `ProgressModel`, и для вердикта агента. Этап, отмеченный как не
    относящийся к инициативе, серый целиком (`ItemVerdict.percent()` даёт
    `None`), и общее число обязано считаться по тем же буллитам, что и
    проценты этапов: иначе серый этап показывался бы «не относится», а его
    пункты тянули бы общую готовность. Неприменимые буллиты внутри
    применимого этапа отсеивает уже `calculate_progress`.
    """
    return [c for v in verdicts if v.applicable for c in v.criteria]


@dataclass(frozen=True)
class UnclaimedGroup:
    """Группа файлов, не подтвердивших ни одного буллита плана.

    Не вердикт «сделано сверх плана» — только сырой кандидат для него.
    Детерминированная разница множеств, без суждения модели.
    """

    group: str
    example_paths: list[str]
    file_count: int

    def to_dict(self) -> dict[str, Any]:
        return {"group": self.group, "example_paths": self.example_paths,
                "file_count": self.file_count}


@dataclass(frozen=True)
class ProjectSummary:
    """Итог анализа: вердикт и его обоснование.

    `conclusion` — 3 коротких буллита (до 4 слов каждый): что подтверждено,
    что мешает, можно ли идти дальше.
    """

    decision: str = ""
    conclusion: list[str] = field(default_factory=list)
    # Строка расчёта под решением: «68% ≥ 50%».
    reason: str = ""
    # Верхнеуровневая оценка целого и одна фраза к ней. Это суждение модели,
    # а не расчёт: проценты считает код по буллитам, а здесь ответ на вопрос,
    # делает ли система то, ради чего затевалась.
    match: str = ""
    match_note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision,
            "conclusion": list(self.conclusion),
            "reason": self.reason,
            "match": self.match,
            "match_label": MATCH_LABEL.get(self.match, ""),
            "match_note": self.match_note,
        }


# ── Связность решения ──────────────────────────────────────────────────────
#
# Постатейный разбор отвечает на вопрос «сделан ли этот пункт». Он не отвечает
# на другой: **складываются ли сделанные пункты в работающую систему.** Код
# может быть написан по каждому буллиту и при этом не быть соединён: узел
# графа никто не вызывает, результат никуда не уходит, оркестратор ничем не
# управляет. Постатейно такая система набирает высокий процент, а замысла
# инициативы не выполняет.
#
# Уровни связности — суждение модели о целом, как и `match`. Подписи держит
# код.
INTEGRITY_LEVELS = ("coherent", "fragmented", "disconnected")
INTEGRITY_LABEL = {
    "coherent": "Решение связное",
    "fragmented": "Связность частичная",
    "disconnected": "Решение не собрано",
}
INTEGRITY_HINT = {
    "coherent": "Сквозной путь проходит целиком, части соединены",
    "fragmented": "Части работают, но соединены не все — сквозной путь рвётся",
    "disconnected": "Единого решения нет: набор частей без сквозного пути",
}

# Вес изъяна. `blocker` — замысел инициативы не выполняется, пока это так;
# `major` — заметная часть замысла не работает; `minor` — изъян назван, но на
# сквозной путь не влияет.
FLAW_SEVERITIES = ("blocker", "major", "minor")
SEVERITY_LABEL = {
    "blocker": "Блокирует замысел",
    "major": "Существенный изъян",
    "minor": "Замечание",
}

# Виды изъянов связности — чек-лист, по которому ревизор обязан пройти.
# Список закрытый: свободная формулировка вида превращает блок в мешок
# разнородных претензий, по которому нельзя ни сравнить инициативы между
# собой, ни собрать статистику по портфелю.
FLAW_KINDS = (
    "broken_chain",
    "no_orchestration",
    "state_lost",
    "one_way_integration",
    "result_not_delivered",
    "data_not_used",
    "stub_on_seam",
    "catalog_empty",
    "manual_trigger",
    "duplicate_logic",
    "scope_mismatch",
    "no_feedback_loop",
)
FLAW_KIND_LABEL = {
    "broken_chain": "Разрыв сквозного пути",
    "no_orchestration": "Оркестрации нет",
    "state_lost": "Состояние между шагами теряется",
    "one_way_integration": "Интеграция только на чтение",
    "result_not_delivered": "Результат не доходит до потребителя",
    "data_not_used": "Собранные данные в работу не идут",
    "stub_on_seam": "Заглушка на стыке",
    "catalog_empty": "Наполнение неполное",
    "manual_trigger": "Автономности нет, запуск ручной",
    "duplicate_logic": "Две расходящиеся реализации",
    "scope_mismatch": "Код решает другую задачу",
    "no_feedback_loop": "Результат не контролируется",
}


# Фактическое назначение системы по коду — против того, ради чего инициатива
# затевалась. Это второй, независимый ответ на вопрос о целом: первый агент
# отвечает на него, глядя на список буллитов (`match`), а ревизор — глядя на
# устройство кода, не зная оценок по пунктам наизусть. Два независимых ответа
# расходятся ровно там, где что-то не так, и расхождение видно читателю.
PURPOSE_VERDICTS = ("same_purpose", "narrower", "different")
PURPOSE_LABEL = {
    "same_purpose": "Назначение совпадает с замыслом",
    "narrower": "Система уже замысла",
    "different": "Система решает другую задачу",
}


@dataclass(frozen=True)
class SystemPurpose:
    """Что система делает на самом деле — по коду, своими словами.

    `does` — суммарная логика: что происходит от входа до результата и ради
    чего. `not_does` — чего в ней нет из того, что обещает инициатива.
    `verdict` — совпадает ли фактическое назначение с замыслом.
    """

    does: str = ""
    not_does: str = ""
    verdict: str = ""
    evidence: list[EvidenceRef] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "does": self.does,
            "not_does": self.not_does,
            "verdict": self.verdict,
            "verdict_label": PURPOSE_LABEL.get(self.verdict, ""),
            "links": [e.to_dict() for e in self.evidence if e.verified],
        }


@dataclass(frozen=True)
class SystemFlaw:
    """Один изъян связности: что не соединено и чем это подтверждается.

    Это не статус буллита и не процент: изъян ничего не пересчитывает. Он
    попадает в карточку отдельным блоком, потому что отвечает на вопрос, на
    который постатейный разбор ответить не может.
    """

    kind: str = ""
    severity: str = "major"
    title: str = ""
    detail: str = ""
    # Пункты образа результата, которых изъян касается — дословно, из плана.
    bullets: list[str] = field(default_factory=list)
    evidence: list[EvidenceRef] = field(default_factory=list)

    @property
    def verified_evidence(self) -> list["EvidenceRef"]:
        return [e for e in self.evidence if e.verified]

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "kind_label": FLAW_KIND_LABEL.get(self.kind, self.kind),
            "severity": self.severity,
            "severity_label": SEVERITY_LABEL.get(self.severity, self.severity),
            "title": self.title,
            "detail": self.detail,
            "bullets": list(self.bullets),
            "links": [e.to_dict() for e in self.verified_evidence],
        }


@dataclass(frozen=True)
class FlowTrace:
    """Сквозной путь системы, прослеженный по коду: вход → шаги → результат.

    Главная проверка связности и первое, что читает человек: если ревизор не
    может назвать точку входа и довести цепочку до результата, никакие
    проценты по буллитам этого не заменят.
    """

    entry: str = ""
    steps: list[str] = field(default_factory=list)
    outcome: str = ""
    complete: bool = False
    # Где рвётся, если путь неполон.
    break_point: str = ""
    evidence: list[EvidenceRef] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "entry": self.entry,
            "steps": list(self.steps),
            "outcome": self.outcome,
            "complete": self.complete,
            "break_point": self.break_point,
            "links": [e.to_dict() for e in self.evidence if e.verified],
        }


@dataclass
class IntegrityReview:
    """Итог ревизии связности: уровень, сквозной путь и список изъянов."""

    level: str = ""
    note: str = ""
    purpose: SystemPurpose | None = None
    flow: FlowTrace | None = None
    flaws: list[SystemFlaw] = field(default_factory=list)
    # Сколько подтверждённых пунктов ревизор держал перед глазами.
    checked: int = 0

    def severity_counts(self) -> dict[str, int]:
        out = {severity: 0 for severity in FLAW_SEVERITIES}
        for flaw in self.flaws:
            if flaw.severity in out:
                out[flaw.severity] += 1
        return out

    def sorted_flaws(self) -> list[SystemFlaw]:
        """Изъяны по весу: блокеры первыми. Порядок держит код — модель
        присылает их в том порядке, в каком нашла."""
        order = {severity: index for index, severity in enumerate(FLAW_SEVERITIES)}
        return sorted(self.flaws, key=lambda f: order.get(f.severity, len(order)))

    def to_dict(self) -> dict[str, Any]:
        return {
            "level": self.level,
            "level_label": INTEGRITY_LABEL.get(self.level, ""),
            "level_hint": INTEGRITY_HINT.get(self.level, ""),
            "note": self.note,
            "checked": self.checked,
            "counts": self.severity_counts(),
            "purpose": self.purpose.to_dict() if self.purpose else None,
            "flow": self.flow.to_dict() if self.flow else None,
            "flaws": [flaw.to_dict() for flaw in self.sorted_flaws()],
        }


def integrity_level_problem(level: str, flaws: list[SystemFlaw]) -> str:
    """Спорит ли объявленный уровень связности с собственным списком изъянов.

    Детерминированная проверка, а не вкус: уровень и список изъянов — два
    утверждения одной модели, и противоречить друг другу они не вправе.
    Пустая строка — противоречия нет.

    Средняя оценка норовит стать значением по умолчанию (так уже случилось с
    `match`: девять «в основном» из девяти), поэтому «частичная связность» без
    единого названного изъяна не принимается — это не оценка, а уклонение.
    """
    if level not in INTEGRITY_LEVELS:
        return (f"уровень {level!r} неизвестен, допустимы: "
                + ", ".join(INTEGRITY_LEVELS))
    blockers = [f for f in flaws if f.severity == "blocker"]
    if level == "coherent" and blockers:
        return ("связность объявлена полной, но назван изъян, блокирующий "
                "замысел — либо уровень ниже, либо изъян не блокер")
    if level == "coherent" and any(f.severity == "major" for f in flaws):
        return ("связность объявлена полной при существенных изъянах — "
                "это «частичная связность» (fragmented)")
    if level != "coherent" and not flaws:
        return ("связность объявлена неполной, но ни одного изъяна не названо: "
                "сначала submit_flaw, потом уровень")
    if level == "disconnected" and not blockers:
        return ("«решение не собрано» — сильное утверждение, и оно требует "
                "хотя бы одного изъяна с severity=blocker")
    return ""


def purpose_verdict_problem(verdict: str, flaws: list[SystemFlaw]) -> str:
    """Спорит ли вердикт о назначении с собственным списком изъянов.

    «Система решает другую задачу» — самое тяжёлое утверждение ревизии: оно
    означает, что анализировали не тот код или команда сделала не то. Такое
    заявление обязано быть предъявлено изъяном с видом `scope_mismatch`, где
    сказано, что именно система делает вместо заявленного. Иначе это ярлык без
    разбора.
    """
    if verdict not in PURPOSE_VERDICTS:
        return (f"вердикт {verdict!r} неизвестен, допустимы: "
                + ", ".join(PURPOSE_VERDICTS))
    if verdict == "different" and not any(f.kind == "scope_mismatch" for f in flaws):
        return ("«решает другую задачу» требует изъяна вида scope_mismatch — "
                "назови сначала его, там и скажешь, что система делает вместо")
    return ""


# ── Сквозная связность: целевые сценарии и стыки ─────────────────────────────
#
# Ревизия связности (`IntegrityReview`) отвечает на вопрос «собрана ли система»
# одним суждением и одним сквозным путём. Этого достаточно, чтобы увидеть
# проблему, но недостаточно, чтобы её измерить: у инициативы обычно не один
# обещанный сценарий, а несколько, и «связность частичная» не говорит, какие
# из них доходят до результата. Здесь — вторая, счётная часть той же ревизии.
#
# Единица оценки — **целевой сценарий из образа результата**: вход → шаги →
# проверяемый результат. Между соседними шагами — **стык** (`Handoff`), и на
# каждом стыке проверяется закрытый список вопросов (`HANDOFF_CHECKS`).
# Статус сценария и процент связности считает код по результатам проверок;
# модель предлагает сценарии, прослеживает стыки и приносит ссылки.
#
# Три правила, которые держат метрику честной:
# * сценарии выводятся из ОР (каждый обязан ссылаться на его пункты) и
#   привязаны к `source_digest` — разбить один сценарий на десять, чтобы
#   поднять процент, нельзя, а сравнивать между прогонами можно только при
#   том же составе;
# * отсутствие найденного вызова — не разрыв: `broken` требует ссылки на
#   место, где продолжение прекращается, иначе результат — `unknown`;
# * «собран» тоже требует доказательств: стык без подтверждённых ссылок и
#   без обязательных проверок остаётся `unknown`. Неизвестное стоит в
#   знаменателе и показывается отдельно — это не доказанный дефект.

# Проверки на стыке — вопросы, на которые отвечает ревизор по каждому переходу.
HANDOFF_CHECKS = (
    "reachability",      # вызывается ли следующий шаг из реального входа
    "contract",          # совпадают ли операция, адрес/топик, версия, поля
    "data_continuity",   # передаётся ли нужный объект и используется ли результат
    "sequence_state",    # выполнены ли предпосылки следующего шага
    "wiring",            # выбрана ли нужная реализация в оцениваемой сборке
    "obligation",        # возник ли обещанный результат
)
HANDOFF_CHECK_LABEL = {
    "reachability": "Достижимость",
    "contract": "Совместимость контракта",
    "data_continuity": "Непрерывность данных",
    "sequence_state": "Последовательность и состояние",
    "wiring": "Подключение в конфигурации",
    "obligation": "Завершение обязательства",
}
# Без этих трёх стык не считается подтверждённым, даже если остальные «ok»:
# достижимость без совместимости контракта и передачи данных — это вызов в
# никуда.
REQUIRED_CHECKS_FOR_OK = ("reachability", "contract", "data_continuity")

CHECK_RESULTS = ("ok", "broken", "unknown")
CHECK_RESULT_LABEL = {
    "ok": "Подтверждено",
    "broken": "Разрыв",
    "unknown": "Недостаточно данных",
}

# Семантическое основание допустимо, когда ревизор уверенно восстановил стык
# из уже прочитанного кода или из явного шага образа результата, но не может
# дать точную строку (например, граф собран декларативно). Это не заменяет
# ссылку для `broken`: критический разрыв по-прежнему требует проверяемого
# места обрыва.
CHECK_SUPPORTS = ("code", "result_image", "inference")
CHECK_CONFIDENCE = ("high", "medium", "low")

# Чем соединены шаги. Граница репозитория сама по себе не граница исполнения:
# HTTP, очередь, общее хранилище и расписание — такие же стыки, как вызов.
HANDOFF_KINDS = ("call", "http", "queue", "storage", "schedule", "config", "manual")
HANDOFF_KIND_LABEL = {
    "call": "Вызов в процессе",
    "http": "HTTP / RPC",
    "queue": "Очередь / событие",
    "storage": "Общее хранилище",
    "schedule": "Задание по расписанию",
    "config": "Подключение конфигурацией",
    "manual": "Ручная передача",
}

SCENARIO_STATUSES = ("assembled", "broken", "unknown")
SCENARIO_STATUS_LABEL = {
    "assembled": "Собран по коду",
    "broken": "Выявлен разрыв",
    "unknown": "Недостаточно данных",
}
SCENARIO_STATUS_HINT = {
    "assembled": "Для заданных условий прослежены обязательные действия, передачи данных и достижение результата",
    "broken": "Найден конкретный дефект, исключающий необходимое продолжение; обходного пути нет",
    "unknown": "Не хватает реализации внешней системы, конфигурации или разрешения динамического вызова",
}

# Основание проверки. `code` — статический разбор; `execution` — подтверждение
# исполнением (тесты, трассы). Второй этап: расчёт от основания не зависит.
CONNECTIVITY_BASES = ("code", "execution")
CONNECTIVITY_BASIS_LABEL = {"code": "анализ кода", "execution": "проверка исполнением"}

# Сколько сценариев принимается: меньше одного — нечего мерить, больше восьми
# — состав уже не выведен из ОР, а нарезан.
MIN_SCENARIOS = 1
MAX_SCENARIOS = 8


@dataclass(frozen=True)
class HandoffCheck:
    """Ответ на один вопрос чек-листа по одному стыку."""

    check: str
    result: str
    note: str = ""
    evidence: list[EvidenceRef] = field(default_factory=list)
    support: str = ""
    confidence: str = ""

    @property
    def verified_evidence(self) -> list[EvidenceRef]:
        return [e for e in self.evidence if e.verified]

    def to_dict(self) -> dict[str, Any]:
        return {
            "check": self.check,
            "check_label": HANDOFF_CHECK_LABEL.get(self.check, self.check),
            "result": self.result,
            "result_label": CHECK_RESULT_LABEL.get(self.result, self.result),
            "note": self.note,
            "support": self.support,
            "confidence": self.confidence,
            "links": [e.to_dict() for e in self.verified_evidence],
        }


@dataclass(frozen=True)
class Handoff:
    """Переход между соседними шагами сценария: `step` → `step + 1`."""

    step: int
    kind: str = "call"
    checks: list[HandoffCheck] = field(default_factory=list)
    basis: str = "code"

    @property
    def result(self) -> str:
        return handoff_result(self.checks)

    @property
    def break_check(self) -> HandoffCheck | None:
        for check in self.checks:
            if check.result == "broken":
                return check
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "step": self.step,
            "kind": self.kind,
            "kind_label": HANDOFF_KIND_LABEL.get(self.kind, self.kind),
            "basis": self.basis,
            "result": self.result,
            "result_label": CHECK_RESULT_LABEL.get(self.result, self.result),
            "checks": [c.to_dict() for c in self.checks],
        }


@dataclass(frozen=True)
class Scenario:
    """Целевой сценарий из образа результата с прослеженными стыками."""

    id: str
    title: str
    entry: str
    outcome: str
    steps: list[str] = field(default_factory=list)
    critical: bool = False
    # Пункты образа результата, из которых сценарий выведен — дословно.
    bullets: list[str] = field(default_factory=list)
    handoffs: list[Handoff] = field(default_factory=list)

    @property
    def status(self) -> str:
        return scenario_status(self.steps, self.handoffs)

    @property
    def transitions(self) -> int:
        return max(0, len(self.steps) - 1)

    def handoff_at(self, step: int) -> Handoff | None:
        for handoff in self.handoffs:
            if handoff.step == step:
                return handoff
        return None

    @property
    def break_point(self) -> str:
        """Где прекращается подтверждённое продолжение — человеческим языком."""
        for handoff in sorted(self.handoffs, key=lambda h: h.step):
            check = handoff.break_check
            if check is not None and 0 <= handoff.step < len(self.steps):
                nxt = self.steps[handoff.step + 1] if handoff.step + 1 < len(self.steps) else self.outcome
                where = f"«{self.steps[handoff.step]}» → «{nxt}»"
                return f"{where}: {check.note}" if check.note else where
        return ""

    def to_dict(self) -> dict[str, Any]:
        status = self.status
        traced = sum(1 for h in self.handoffs if h.result != "unknown")
        return {
            "id": self.id,
            "title": self.title,
            "entry": self.entry,
            "outcome": self.outcome,
            "steps": list(self.steps),
            "critical": self.critical,
            "bullets": list(self.bullets),
            "status": status,
            "status_label": SCENARIO_STATUS_LABEL.get(status, status),
            "status_hint": SCENARIO_STATUS_HINT.get(status, ""),
            "break_point": self.break_point,
            "transitions": self.transitions,
            "transitions_confirmed": traced,
            "handoffs": [h.to_dict() for h in sorted(self.handoffs, key=lambda h: h.step)],
        }


@dataclass
class ConnectivityReview:
    """Сквозная связность: список сценариев и всё, что из него считается."""

    scenarios: list[Scenario] = field(default_factory=list)
    # Отпечаток образа результата, из которого выведен состав сценариев.
    # Сравнение между прогонами допустимо только при совпадении.
    source_digest: str = ""
    basis: str = "code"

    def counts(self) -> dict[str, int]:
        out = {status: 0 for status in SCENARIO_STATUSES}
        for scenario in self.scenarios:
            out[scenario.status] += 1
        return out

    def percent(self) -> int | None:
        return calculate_connectivity(self.scenarios)

    def blocked(self) -> list[Scenario]:
        """Критические сценарии с разрывом: явный статус блокировки, который
        не снимается высокой общей долей."""
        return [s for s in self.scenarios if s.critical and s.status == "broken"]

    def handoff_coverage(self) -> tuple[int, int]:
        """Проверено стыков из необходимых — показатель прогресса, не оценки:
        два непроверенных стыка могут блокировать все сценарии."""
        total = sum(s.transitions for s in self.scenarios)
        done = sum(
            1 for s in self.scenarios for h in s.handoffs
            if 0 <= h.step < s.transitions and h.result != "unknown"
        )
        return done, total

    def to_dict(self) -> dict[str, Any]:
        done, total = self.handoff_coverage()
        return {
            "percent": self.percent(),
            "basis": self.basis,
            "basis_label": CONNECTIVITY_BASIS_LABEL.get(self.basis, self.basis),
            "source_digest": self.source_digest,
            "counts": self.counts(),
            "total": len(self.scenarios),
            "handoffs_confirmed": done,
            "handoffs_total": total,
            "blocked": [
                {"id": s.id, "title": s.title, "outcome": s.outcome}
                for s in self.blocked()
            ],
            "scenarios": [s.to_dict() for s in self.scenarios],
        }


def handoff_result(checks: list[HandoffCheck]) -> str:
    """Итог стыка по его проверкам. Разрыв сильнее неизвестного, неизвестное
    сильнее подтверждения; без обязательных проверок стык не подтверждён."""
    results = {c.check: c.result for c in checks}
    if any(r == "broken" for r in results.values()):
        return "broken"
    if any(r == "unknown" for r in results.values()):
        return "unknown"
    if not results or any(results.get(c) != "ok" for c in REQUIRED_CHECKS_FOR_OK):
        return "unknown"
    return "ok"


def scenario_status(steps: list[str], handoffs: list[Handoff]) -> str:
    """Статус сценария по стыкам. Разрыв на любом стыке — `broken`;
    непрослеженный или неизвестный стык — `unknown`; все переходы
    подтверждены — `assembled`."""
    transitions = max(0, len(steps) - 1)
    by_step = {h.step: h for h in handoffs}
    results = [by_step[i].result if i in by_step else "unknown" for i in range(transitions)]
    if any(r == "broken" for r in results):
        return "broken"
    if transitions == 0 or any(r == "unknown" for r in results):
        return "unknown"
    return "assembled"


def calculate_connectivity(scenarios: list[Scenario]) -> int | None:
    """Сквозная связность: доля сценариев, собранных до результата, среди всех
    целевых. Веса равные; неизвестное остаётся в знаменателе. None — сценариев
    нет."""
    if not scenarios:
        return None
    assembled = sum(1 for s in scenarios if s.status == "assembled")
    return int(round(100 * assembled / len(scenarios)))


@dataclass(frozen=True)
class SolutionAssessment:
    """Оценка отдельной схемы паспорта по полноте и связности.

    Два измерения не усредняются: среднее позволило бы высокой полноте
    скрыть несобранный путь и дважды наградило бы один и тот же работающий
    фрагмент. Итог ограничен более слабым измерением. Если связность не
    измерена, сохраняется прежняя оценка полноты, но это явно отмечается в
    контракте. Критические разрывы показываются отдельным счётчиком и не
    превращаются в собственный вердикт схемы.
    """

    score: int | None
    completeness: int
    connectivity: int | None
    critical_breaks: int = 0
    connectivity_measured: bool = False

    @property
    def reason(self) -> str:
        if not self.connectivity_measured:
            return f"полнота {self.completeness}%; связность не измерена — оценка схемы не сформирована"
        assert self.score is not None
        reason = (
            f"min(полнота {self.completeness}%, связность {self.connectivity}%) "
            f"= {self.score}%"
        )
        if self.critical_breaks:
            reason += f"; критических разрывов {self.critical_breaks}"
        return reason

    def to_dict(self) -> dict[str, Any]:
        return {
            "score": self.score,
            "completeness": self.completeness,
            "connectivity": self.connectivity,
            "connectivity_measured": self.connectivity_measured,
            "critical_breaks": self.critical_breaks,
            "reason": self.reason,
            "rule": "minimum",
            "rule_label": (
                "Оценка — меньшее из полноты и связности; критические разрывы показаны отдельно"
                if self.connectivity_measured else
                "Связность не измерена — оценка схемы не сформирована"
            ),
        }


def calculate_solution_assessment(
    completeness: int, connectivity: ConnectivityReview | None,
) -> SolutionAssessment:
    """Собрать интегральную оценку детерминированно.

    ``completeness`` — готовность пунктов ОР. ``connectivity`` — сценарии,
    восстановленные из того же ОР. Неизвестные сценарии уже остаются в
    знаменателе ``calculate_connectivity``. Отсутствие самой ревизии не
    превращается в доказанный ноль: это отдельное состояние «не измерено».
    """
    completeness = max(0, min(100, int(completeness)))
    measured = connectivity is not None and bool(connectivity.scenarios)
    connectivity_percent = connectivity.percent() if measured and connectivity else None
    score = min(completeness, connectivity_percent) if connectivity_percent is not None else None
    critical_breaks = len(connectivity.blocked()) if connectivity is not None else 0
    return SolutionAssessment(
        score=score,
        completeness=completeness,
        connectivity=connectivity_percent,
        critical_breaks=critical_breaks,
        connectivity_measured=measured,
    )


@dataclass
class ProgressModel:
    """Итоговая модель одного прогона.

    `readiness` — готовность прототипа, `readiness_prod` — готовность
    промышленного решения. Оба — арифметика по одним и тем же статусам,
    только по разным весам (`POC_WEIGHT` / `PROD_WEIGHT`), а не две оценки
    модели: рассогласовать их нечем.
    """

    meta: dict[str, Any] = field(default_factory=dict)
    items: dict[str, PlanItem] = field(default_factory=dict)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    unclaimed: list[UnclaimedGroup] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    readiness: int = 0
    readiness_prod: int = 0
    summary: ProjectSummary | None = None
    summary_source: str = "none"
    # Ревизия связности: складываются ли сделанные пункты в работающую
    # систему. Её проверяемые сценарии участвуют в отдельной оценке схемы
    # паспорта через `solution_assessment`, но не меняют основной GO/PIVOT.
    integrity: IntegrityReview | None = None
    # Сквозная связность: целевые сценарии из ОР и их стыки. Процент считает
    # код (`calculate_connectivity`). В отдельной оценке схемы он не
    # усредняется с полнотой: берётся минимум, а критические разрывы
    # показываются отдельным счётчиком без собственного вердикта схемы.
    connectivity: ConnectivityReview | None = None
    # Паспорт клиентского пути (`passport_agent`): дерево путь → процесс →
    # BBB → операция, потребности и ограничения, нормализованное
    # `passport_gate.normalize_passport`. `None` — паспортная сессия не
    # приняла ни одного узла; рендерер тогда заполняет паспорт
    # детерминированно и ставит бейдж «агент паспорт не заполнил».
    passport_data: dict[str, Any] | None = None

    def criterion_counts(self) -> dict[str, int]:
        """Сколько применимых буллитов в каждом состоянии — по всему пути."""
        out = {status: 0 for status in CRITERION_STATUSES}
        for verdict in self.verdicts:
            for criterion in verdict.applicable_criteria:
                if criterion.status in out:
                    out[criterion.status] += 1
        return out

    def all_criteria(self) -> list[CriterionVerdict]:
        """Все буллиты пути, включая пункты неприменимых этапов."""
        return [c for v in self.verdicts for c in v.criteria]

    def rated_criteria(self) -> list[CriterionVerdict]:
        """Буллиты, по которым считается готовность: см. `rated_criteria`."""
        return rated_criteria(self.verdicts)

    def overall_progress(self) -> int:
        """Готовность прототипа — главное число отчёта."""
        return calculate_progress(self.rated_criteria()) or 0

    def overall_progress_prod(self) -> int:
        """Готовность промышленного решения — то же по строгим весам."""
        return calculate_prod_progress(self.rated_criteria()) or 0

    def solution_assessment(self) -> SolutionAssessment:
        """Отдельная оценка схемы по полноте пунктов и связности сценариев."""
        return calculate_solution_assessment(self.readiness, self.connectivity)

    def closed_share(self) -> int:
        """Доля буллитов «Да» — сколько пунктов закрыто полностью."""
        return calculate_closed_share(self.rated_criteria()) or 0

    def not_applicable_count(self) -> int:
        """Сколько буллитов вне расчёта: свой флаг или флаг всего этапа."""
        return sum(
            1 for v in self.verdicts for c in v.criteria
            if not (v.applicable and c.applicable)
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "pko-progress-model/0.3",
            "meta": self.meta,
            "readiness": self.readiness,
            "readiness_prod": self.readiness_prod,
            "closed_share": self.closed_share(),
            "criterion_counts": self.criterion_counts(),
            "not_applicable": self.not_applicable_count(),
            "items": {item_id: item.to_dict() for item_id, item in self.items.items()},
            "verdicts": [v.to_dict() for v in self.verdicts],
            "unclaimed": [u.to_dict() for u in self.unclaimed],
            "gaps": self.gaps,
            "summary": self.summary.to_dict() if self.summary else None,
            "summary_source": self.summary_source,
            "integrity": self.integrity.to_dict() if self.integrity else None,
            "connectivity": self.connectivity.to_dict() if self.connectivity else None,
            "passport_data": self.passport_data,
        }

    def to_json(self) -> str:
        import json

        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2, sort_keys=False)


# Оценка реализации объектов паспорта. Все правила статусов живут здесь.
CRITICAL_FIELDS = {
    "process": {"4.3.4", "4.3.6"},
    "bbb": {"4.4.4", "4.4.6"},
    "operation": {"4.5.4", "4.5.5"},
}

SOURCE_LEVELS = (
    "Установлено",
    "Выведено",
    "Гипотеза",
    "Требует подтверждения владельца",
    "Не установлено",
)

_FIELD_LABEL = {
    "4.3.4": "Условия запуска", "4.3.6": "Допустимые BBB и режимы исполнения",
    "4.4.4": "Контракт выхода", "4.4.6": "Способы исполнения",
    "4.5.4": "Проверяемый эффект", "4.5.5": "Вход и выход", "4.5.6": "Повтор, отмена и компенсация",
}
# Уровни основания, при которых поле считается установленным.
_GROUNDED_LEVELS = ("Установлено", "Выведено")
NODE_IMPLEMENTATION_LABEL = {
    "implemented": "Реализован",
    "partial": "Реализован частично",
    "not_implemented": "Не реализован",
    "unknown": "Недостаточно данных",
}

_NOT_IMPLEMENTED_CODE = re.compile(
    r"закомментир|отключ[её]н|замен[её]н\w* (?:нул[её]м|констант)|"
    r"заглушк|stub\b|not implemented|в коде (?:отсутствует|нет)",
    re.IGNORECASE,
)
_PARTIAL_CODE = re.compile(
    r"частичн\w* реализ|реализован\w* только|todo\b|не заверш[её]н",
    re.IGNORECASE,
)


def passport_criteria_state(criteria: list[Any]) -> str:
    """Состояние связанных пунктов ОР как один из сигналов статуса узла."""
    statuses = [str(c.status) for c in criteria if getattr(c, "applicable", False)]
    if not statuses:
        return "unknown"
    if all(s == "done" for s in statuses):
        return "implemented"
    if all(s in ("planned", "blocked") for s in statuses):
        return "not_implemented"
    return "partial"


def combine_passport_states(states: list[str]) -> str:
    """Собрать несколько независимых сигналов без правила «худший победил».

    `unknown` не понижает подтверждённую оценку. Полностью отсутствующим узел
    считается лишь когда все содержательные сигналы говорят об отсутствии;
    смесь работающих и отсутствующих частей означает частичную реализацию.
    """
    known = [state for state in states if state in NODE_IMPLEMENTATION_LABEL and state != "unknown"]
    if not known:
        return "unknown"
    if "partial" in known:
        return "partial"
    if "implemented" in known and "not_implemented" in known:
        return "partial"
    if "implemented" in known:
        return "implemented"
    return "not_implemented"


def passport_code_state(raw: dict[str, Any], ntype: str, planned: bool) -> tuple[str, str]:
    """Готовность кода листа, независимо от соответствия пунктам ОР."""
    if planned:
        return "not_implemented", ""
    # «Установлено» описывает силу основания, в том числе доказанного
    # отсутствия эффекта. Это не синоним работающего кода. Смотрим только
    # основной эффект операции, не retry, владельца или соседнюю ветку.
    if ntype == "operation":
        fields = raw.get("fields") or {}
        effect = fields.get("4.5.4") or {}
        if isinstance(effect, dict) and _source_level(effect.get("source", "")) in _GROUNDED_LEVELS:
            text = str(effect.get("value") or "") + " " + str(effect.get("source") or "")
            # Не превращать условие отказа, прошлую версию или отрицание
            # отключения в утверждение о текущем основном эффекте.
            text = ". ".join(sentence for sentence in re.split(r"[.;\n]", text)
                             if not re.search(
                                 r"\b(?:если|возможно|может|раньше|ранее|был[ао]?)\b|"
                                 r"при (?:отказе|ошибке)|не\s+закомментирован|не\s+замен[её]н", sentence, re.I))
            absent = re.search(
                r"вызов[^.;\n]{0,80}закомментирован|вместо[^.;\n]{0,60}(?:возвращает\w*|подставля\w*) (?:ноль|0)\b|"
                r"(?:эффект|операция|загрузка|списание|открытие) (?:не выполняется|не реализован\w*|отсутствует)|"
                r"замен[её]н\w* (?:нул[её]м|нулев\w* значени\w*)", text, re.I,
            )
            if absent:
                return "not_implemented", "Основной эффект операции не выполняется: " + str(effect.get("value") or "")
    haystack = " ".join((
        str(raw.get("name") or ""),
        str(raw.get("basis") or ""),
        # Descriptions of retries/fallbacks, owners and versions are not
        # assertions about implementation. A negative word there is not a defect.
    ))
    if _NOT_IMPLEMENTED_CODE.search(haystack):
        # Непланируемый узел существует, поэтому упоминание отсутствующей или
        # отключённой части означает неполную реализацию, а не отсутствие
        # объекта целиком. Полностью отсутствующий объект агент обязан пометить
        # `planned`.
        return "partial", "В реализации отсутствует, отключена или заменена заглушкой часть поведения"
    if _PARTIAL_CODE.search(haystack):
        return "partial", "По описанию полей код узла реализован не полностью"
    state, note = _field_state(raw, ntype)
    return (state or "unknown"), note


def passport_requirement_counts(criteria: Iterable[CriterionVerdict]) -> dict[str, int | None]:
    """Доля полностью выполненных обещаний отдельно от взвешенной готовности.

    Каждый применимый пункт имеет один вес; число узлов декомпозиции на
    знаменатель не влияет. `limited` не является полностью выполненным.
    """
    applicable = [c for c in criteria if c.applicable]
    done = sum(c.status == "done" for c in applicable)
    return {"total": len(applicable), "done": done,
            "done_percent": calculate_closed_share(applicable)}


def passport_node_state(code_state: str, criterion_state: str, *, planned: bool = False) -> str:
    """Локальное доказанное отсутствие эффекта сильнее широкого пункта ОР."""
    if planned or code_state == "not_implemented":
        return "not_implemented"
    return combine_passport_states([code_state, criterion_state])


def _source_level(source: str) -> str | None:
    for level in SOURCE_LEVELS:
        if str(source or "").strip().startswith(level):
            return level
    return None


def _field_levels(raw: dict[str, Any]) -> dict[str, str | None]:
    fields = raw.get("fields") if isinstance(raw.get("fields"), dict) else {}
    out: dict[str, str | None] = {}
    for fid, cell in fields.items():
        if isinstance(cell, dict) and (str(cell.get("value") or "").strip() or str(cell.get("source") or "").strip()):
            out[str(fid)] = _source_level(str(cell.get("source") or ""))
    return out


def _critical_gap(raw: dict[str, Any], ntype: str) -> str:
    """Критичное поле не установлено (или отсутствует) — текст проблемы, иначе пусто."""
    levels = _field_levels(raw)
    if not levels:
        return ""
    gaps: list[str] = []
    for fid in sorted(CRITICAL_FIELDS.get(ntype, set())):
        if fid in levels and levels[fid] in (None, "Не установлено"):
            gaps.append(_FIELD_LABEL.get(fid, fid))
    if not gaps:
        return ""
    return ("Статус ограничен «недостаточно данных»: не установлено — " + ", ".join(gaps)
            + " (без этого путь не продолжается)")


def _field_state(raw: dict[str, Any], ntype: str) -> tuple[str, str]:
    """Статус листа без пунктов ОР — по уровням оснований его полей.

    Все критичные поля с уровнем «Установлено» или «Выведено» — реализован;
    «Гипотеза» или «Требует подтверждения» в критичном поле — недостаточно
    данных; «Не установлено» — потолок, объясняется отдельно.
    """
    levels = _field_levels(raw)
    critical = CRITICAL_FIELDS.get(ntype, set())
    if not levels or not critical or not critical <= set(levels):
        return "", ""
    gap = _critical_gap(raw, ntype)
    if gap:
        return "unknown", gap
    weak = [_FIELD_LABEL.get(fid, fid) for fid in sorted(critical) if levels.get(fid) not in _GROUNDED_LEVELS]
    if weak:
        return "unknown", "Статус по основаниям: гипотеза или неподтверждённое намерение в полях — " + ", ".join(weak)
    return "implemented", ""



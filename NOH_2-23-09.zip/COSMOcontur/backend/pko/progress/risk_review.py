"""Internal risk coverage, separate from executive findings and readiness."""
from __future__ import annotations
import re

CHECKS = {
    "input": "Ошибочные, неполные, устаревшие данные; неверный клиент или объект",
    "decision": "Ошибочное решение, параметры, права; недостоверный ответ модели",
    "execution": "Пропуск, задержка, повтор или нарушение порядка действия",
    "persistence": "Потеря, искажение результата; частичная запись или транзакция",
    "dependencies": "Отказ, задержка или нарушение контракта внешней зависимости",
    "detection": "Незамеченный сбой, ложный успех, распространение последствий",
    "recovery": "Небезопасный повтор, отмена, компенсация или восстановление",
}
RESULTS = ("finding", "no_finding", "unknown", "not_applicable")


def grounded_reference(where: str, known_paths: set[str]) -> bool:
    return any(re.search(r"(?<![\w/\\.-])" + re.escape(path) + r"(?=$|[:\s,;#()])", where)
               for path in known_paths)


def validate_review(review: object, processes: set[str], risks: list[dict],
                    known_paths: set[str] | None = None) -> list[str]:
    """Validate coverage, not truth: semantic conclusions remain evidence-based."""
    if not isinstance(review, list):
        return ["review: нужен внутренний чек-лист по каждому процессу"]
    errors: list[str] = []
    seen: set[str] = set()
    titles = {r["title"] for r in risks}
    referenced: set[str] = set()
    for row in review:
        if not isinstance(row, dict):
            errors.append("review: проверка должна быть объектом")
            continue
        node = row.get("node")
        if not isinstance(node, str) or node not in processes or node in seen:
            errors.append(f"review: неизвестный или повторный процесс {node}")
            continue
        seen.add(node)
        checked: set[str] = set()
        for item in row.get("checks", []) if isinstance(row.get("checks"), list) else []:
            if not isinstance(item, dict):
                errors.append(f"{node}: проверка должна быть объектом")
                continue
            key, result = item.get("check"), item.get("result")
            if not isinstance(key, str) or key not in CHECKS or key in checked:
                errors.append(f"{node}: неизвестная или повторная проверка {key}")
                continue
            checked.add(key)
            if result not in RESULTS or len(str(item.get("note") or "").strip()) < 20:
                errors.append(f"{node}/{key}: нужны результат и конкретное объяснение")
            evidence = item.get("evidence")
            if result in ("finding", "no_finding") and (
                not isinstance(evidence, list) or not evidence or
                any(not isinstance(e, dict) or not str(e.get("where") or "").strip()
                    or len(str(e.get("basis") or "").strip()) < 20 for e in evidence)
            ):
                errors.append(f"{node}/{key}: вывод требует места и наблюдаемого факта в evidence")
            if known_paths is not None and isinstance(evidence, list):
                for ev in evidence:
                    if isinstance(ev, dict) and not grounded_reference(str(ev.get("where") or ""), known_paths):
                        errors.append(f"{node}/{key}: место основания отсутствует в материалах оценки")
            refs = item.get("risk_titles") or []
            if not isinstance(refs, list) or any(not isinstance(t, str) or t not in titles for t in refs):
                errors.append(f"{node}/{key}: ссылка на неизвестный риск")
            elif result == "finding" and not refs:
                errors.append(f"{node}/{key}: finding должен ссылаться на переданный риск")
            elif result != "finding" and refs:
                errors.append(f"{node}/{key}: ссылки на риски допустимы только у finding")
            elif result == "finding":
                referenced.update(refs)
        if set(CHECKS) - checked:
            errors.append(f"{node}: не проверены {', '.join(sorted(set(CHECKS) - checked))}")
    if processes - seen:
        errors.append("review: отсутствуют процессы " + ", ".join(sorted(processes - seen)))
    if titles - referenced:
        errors.append("review: каждый риск должен быть связан с проверкой сценария")
    return errors

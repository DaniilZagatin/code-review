"""Строгая проверка: второй агент перечитывает код по ссылкам первого.

Первый агент (`matcher.run_agent`) ищет реализацию и выставляет статусы, а
его контр-проверка (`submit_review`) смотрит только в одну сторону — не
занижен ли статус. В другую сторону никто не смотрел: за «Работает» могла
стоять заглушка, метод с пустым телом, ветка, до которой не доходит
выполнение, или код, который делает соседнее, а не заявленное. На живом
прогоне такое всплывало только по добросовестности самой модели.

Рецензент закрывает эту дыру. Он получает **не репозиторий целиком, а список
утверждений**: каждый буллит со статусом, требующим подтверждения
(`schema.GROUNDED_STATUSES`), его «Проверку», «Как работает» и проверенные
ссылки на код. По каждому он обязан открыть указанное место и ответить, делает
ли код то, что заявлено, и доходит ли до него выполнение.

Ограничения — те же, что у первого агента, плюс одно своё:

* **Понижать можно, повышать нельзя.** Инструмент `submit_challenge`
  принимает только статус с меньшим весом (`schema.POC_WEIGHT`). Спорить с
  «не реализовано» рецензенту не дано — это работа контр-проверки первого.
* **Довод обязателен и проходит те же сторожа**, что тексты первого агента:
  без кода в тексте (`schema.contains_code`), без ссылок на несуществующие
  файлы (`report.guard.check_explanation`), не короче
  `_MIN_REASON_CHARS`. Довод дописывается в «Проверку» пункта: читатель
  должен видеть, за что снято, а не только новый статус.
* **Ссылки проверяются кодом** (`verify.verify_evidence`), как и у первого:
  новую ссылку рецензент может добавить, но подтверждённые прежние не
  трогает — они показывают, что именно он перечитал.
* **Готовность и решение пересчитывает код** (`matcher._reconcile_summary`)
  после сессии рецензента. Сам он ни процента, ни решения не называет.
* **Сомнение — не повод.** Отклонённый вызов ничего не меняет: статус
  остаётся тем, что поставил первый агент. Мягкого режима у рецензента нет.

Выключается `PKO_CRITIC=false`; бюджет шагов — `PKO_CRITIC_STEPS`, времени —
`PKO_CRITIC_SECONDS`.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Callable

from pko.errors import LlmError
from pko.extractors.base import Tree
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import trace_span
from pko.progress.agent_tools import TOOL_SCHEMAS as REPO_TOOL_SCHEMAS, ToolBox
from pko.progress.matcher import (
    max_tokens_for,
    AgentResult,
    _MAX_MALFORMED,
    _REPEAT_STOP,
    _START_CHARS_PER_TOKEN,
    _cap_tool_result,
    _clip,
    _history_budget,
    _measure_density,
    _message_size,
    _parse_evidence,
    _reconcile_summary,
    _signature,
    _trim_history,
)
from pko.progress.schema import (
    GROUNDED_STATUSES,
    POC_WEIGHT,
    STATUS_ALIASES,
    STATUS_LABEL,
    CriterionVerdict,
    ItemVerdict,
    PlanItem,
    contains_code,
)
from pko.report.guard import check_explanation

_PROMPT_PATH = Path(__file__).parent / "critic_system.md"

# Шагов у рецензента меньше, чем у первого агента: искать ему ничего не
# нужно, все места уже названы. Один пункт — открыть файл, посмотреть, кто
# вызывает, — два-три шага. Тридцати хватает на десяток-полтора пунктов с
# запасом на перечитывание; больше пунктов — приоритет у «Работает».
DEFAULT_CRITIC_STEPS = 60
# Потолок времени отдельный от первого агента: его сессия могла съесть весь
# свой бюджет, и рецензент не должен остаться без времени из-за этого.
DEFAULT_CRITIC_SECONDS = 600

# Довод к понижению: короче — отписка, длиннее — не читается в «Проверке».
_MIN_REASON_CHARS = 80
_MAX_REASON_CHARS = 400
# Сколько символов «Проверки» остаётся после дописывания довода.
_MAX_PROOF_WITH_CHALLENGE = 900
# Куда рецензент может понижать. `blocked` — суждение о следующем этапе, а не
# о коде этого пункта, рецензент такого не выносит.
_TARGET_STATUSES = ("limited", "unused", "partial", "planned")
# Пометка в «Проверке» перед доводом рецензента.
_CHALLENGE_PREFIX = "Строгая проверка:"

_SUBMIT_CHALLENGE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_challenge",
        "description": (
            "Понизить статус одного пункта, если по коду он не заслуживает "
            "того, что ему поставили. Вызывай ТОЛЬКО для понижения: пункты, к "
            "которым претензий нет, оставь как есть — для них вызов не нужен. "
            "Повышать статус нельзя. Один вызов — один пункт; повторный вызов "
            "по тому же пункту понижает ещё раз, если статус ниже предыдущего."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "item_id": {"type": "string", "description": "идентификатор этапа из списка утверждений"},
                "bullet": {"type": "integer", "description": "номер буллита в этапе, как в списке утверждений (с 1)"},
                "status": {
                    "type": "string", "enum": list(_TARGET_STATUSES),
                    "description": (
                        "Новый статус, строго ниже нынешнего. "
                        "limited — работает, но с ограничением, которого первый агент не назвал. "
                        "unused — код есть и рабочий, но до него не доходит выполнение: вызовов нет, "
                        "точка входа не подключена. "
                        "partial — сквозной путь не отрабатывает: часть логики есть, остальное "
                        "заглушка или отсутствует. "
                        "planned — по указанным ссылкам заявленной логики нет вовсе."
                    ),
                },
                "reason": {
                    "type": "string",
                    "description": (
                        "Довод: что именно код не делает из заявленного — по существу, "
                        "человеческим языком, от 80 до 400 символов. Он дописывается в "
                        "«Проверку» пункта и его прочтёт руководство, поэтому без имён "
                        "функций, путей, декораторов и snake_case. Не «код сомнительный», "
                        "а «метод сохранения возвращает заготовленный пример, в базу "
                        "ничего не пишет»."
                    ),
                },
                "evidence": {
                    "type": "array",
                    "description": (
                        "Необязательно: место, которое доказывает довод (заглушка, "
                        "жёстко зашитый ответ, неподключённый обработчик). Прежние ссылки "
                        "пункта сохраняются; эта добавляется к ним после проверки."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string"},
                            "line": {"type": "integer"},
                            "basis": {"type": "string", "description": "имя функции/класса/таблицы рядом со строкой — по нему ссылка проверяется"},
                            "note": {"type": "string", "description": "что в этой строке происходит, одной фразой"},
                        },
                    },
                },
            },
            "required": ["item_id", "bullet", "status", "reason"],
        },
    },
}

_FINISH_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "finish",
        "description": "Вызови, когда прошёл все пункты из списка утверждений: "
                       "и те, что понизил, и те, что оставил.",
        "parameters": {"type": "object", "properties": {}},
    },
}

_CRITIC_TOOL_SCHEMAS: list[dict[str, Any]] = (
    REPO_TOOL_SCHEMAS + [_SUBMIT_CHALLENGE_SCHEMA, _FINISH_SCHEMA]
)

_NUDGE = (
    "Нужно вызвать инструмент: read_file по ссылке из списка, who_calls или "
    "search для проверки подключения, submit_challenge для понижения, finish "
    "когда все пункты пройдены."
)

_FALLBACK_PROMPT = (
    "Ты — строгий рецензент. Проверь по коду каждое утверждение из списка и "
    "понизь через submit_challenge те, где код не делает заявленного. "
    "Повышать нельзя. Закончи вызовом finish."
)


def critic_enabled() -> bool:
    """`PKO_CRITIC`: выключить рецензента можно только явно."""
    raw = (os.environ.get("PKO_CRITIC") or "").strip().lower()
    return raw not in ("0", "false", "no", "off")


def _env_int(name: str, default: int) -> int:
    raw = (os.environ.get(name) or "").strip()
    try:
        return max(0, int(raw)) if raw else default
    except ValueError:
        return default


def load_critic_prompt() -> tuple[str, bool]:
    """Системный промпт рецензента и признак, что файл найден."""
    try:
        return _PROMPT_PATH.read_text(encoding="utf-8"), True
    except OSError:
        return _FALLBACK_PROMPT, False


@dataclass
class Claim:
    """Одно утверждение первого агента, которое рецензент обязан проверить."""

    item: PlanItem
    verdict: ItemVerdict
    index: int  # номер буллита в этапе, с 1
    criterion: CriterionVerdict

    @property
    def text(self) -> str:
        criteria = self.item.criteria
        return str(criteria[self.index - 1]) if self.index - 1 < len(criteria) else ""


def collect_claims(plan: list[PlanItem], verdicts: list[ItemVerdict]) -> list[Claim]:
    """Буллиты, за которые первый агент отвечает ссылкой: применимые, со
    статусом из `GROUNDED_STATUSES`. `planned` рецензент не трогает —
    поднимать статусы не его работа. `blocked` тоже: это суждение о
    следующем этапе, а не о том, работает ли код этого пункта.

    Порядок — по убыванию веса: если бюджета на все не хватит, «Работает»
    проверяется раньше «с ограничениями».
    """
    by_id = {item.id: item for item in plan}
    claims: list[Claim] = []
    for verdict in verdicts:
        item = by_id.get(verdict.item_id)
        if item is None or not verdict.applicable:
            continue
        for index, criterion in enumerate(verdict.criteria, start=1):
            if not criterion.applicable:
                continue
            if criterion.status not in GROUNDED_STATUSES or criterion.status == "blocked":
                continue
            if not criterion.verified_evidence:
                # Без проверенной ссылки утверждение и так помечено как
                # неподтверждённое (`ungrounded`): рецензенту нечего открывать.
                continue
            claims.append(Claim(item=item, verdict=verdict, index=index, criterion=criterion))
    claims.sort(key=lambda c: -POC_WEIGHT.get(c.criterion.status, 0.0))
    return claims


def build_critic_brief(claims: list[Claim]) -> str:
    """Список утверждений для рецензента: пункт, статус, тексты первого
    агента и проверенные ссылки — всё, что нужно, чтобы открыть код и
    сверить."""
    lines = [
        "Первый агент оценил пункты ниже как реализованные. Проверь каждый по "
        "его же ссылкам: делает ли код заявленное и доходит ли до него "
        "выполнение. Понижай через submit_challenge только то, где нашёл "
        "конкретный изъян; остальное оставь как есть.",
        "",
        f"Утверждений: {len(claims)}.",
        "",
    ]
    for number, claim in enumerate(claims, start=1):
        c = claim.criterion
        label = STATUS_LABEL.get(c.status, c.status)
        lines.append(
            f"{number}. Этап «{claim.item.title}», буллит {claim.index} "
            f"(item_id={claim.item.id}, bullet={claim.index})"
        )
        lines.append(f"   Пункт: {claim.text}")
        lines.append(f"   Статус: {c.status} — {label}")
        if c.proof_text:
            lines.append(f"   Проверка (первый агент): {c.proof_text}")
        if c.how_text:
            lines.append(f"   Как работает (первый агент): {c.how_text}")
        lines.append("   Ссылки:")
        for e in c.verified_evidence:
            loc = f"{e.path}:{e.line}" if e.line else e.path
            tail = f" — {e.note}" if getattr(e, "note", "") else ""
            lines.append(f"   - {loc} · {e.basis}{tail}")
        lines.append("")
    lines.append(
        "Пройди все пункты по порядку — сначала идут «Работает», у них цена "
        "ошибки выше. Когда закончишь, вызови finish."
    )
    return "\n".join(lines)


@dataclass
class _CriticSession:
    plan_by_id: dict[str, PlanItem]
    verdicts_by_id: dict[str, ItemVerdict]
    claims: list[Claim]
    tree: Tree
    tools: ToolBox
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None
    lowered: list[str] = field(default_factory=list)
    rejected: int = 0
    notes: list[str] = field(default_factory=list)
    finished: bool = False

    def claim_for(self, item_id: str, bullet: int) -> Claim | None:
        for claim in self.claims:
            if claim.item.id == item_id and claim.index == bullet:
                return claim
        return None


def _handle_challenge(state: _CriticSession, args: dict) -> str:
    """`submit_challenge` — понижение одного пункта. Любая ошибка — отказ
    без последствий: статус первого агента остаётся."""
    item_id = str(args.get("item_id") or "").strip()
    try:
        bullet = int(args.get("bullet"))
    except (TypeError, ValueError):
        bullet = 0
    claim = state.claim_for(item_id, bullet)
    if claim is None:
        state.rejected += 1
        return (
            f"понижение отклонено: пункт item_id={item_id!r}, bullet={bullet} "
            "не входит в список утверждений — проверять можно только пункты из него"
        )
    criterion = claim.criterion
    current = criterion.status
    status = str(args.get("status") or "").strip().lower()
    status = STATUS_ALIASES.get(status, status)
    if status not in _TARGET_STATUSES:
        state.rejected += 1
        return (
            f"понижение отклонено: статус {status!r} недопустим. Рецензент "
            f"ставит только {', '.join(_TARGET_STATUSES)}"
        )
    if POC_WEIGHT.get(status, 0.0) >= POC_WEIGHT.get(current, 0.0):
        state.rejected += 1
        return (
            f"понижение отклонено: у пункта уже статус «{STATUS_LABEL.get(current, current)}», "
            f"а «{STATUS_LABEL.get(status, status)}» не ниже него. Рецензент "
            "может только понижать"
        )

    reason = " ".join(str(args.get("reason") or "").split())
    if len(reason) < _MIN_REASON_CHARS:
        state.rejected += 1
        return (
            f"понижение отклонено: довод слишком короткий ({len(reason)} симв., "
            f"нужно от {_MIN_REASON_CHARS}). Напиши, что именно код не делает "
            "из заявленного"
        )
    code = contains_code(reason)
    if code:
        state.rejected += 1
        return (
            f"понижение отклонено: в доводе код («{code}»). Довод уходит в отчёт "
            "для читателя без технического контекста — перепиши обычными словами; "
            "путь и строку положи в evidence"
        )
    violations = check_explanation(reason, state.tree.files_set)
    if violations:
        state.rejected += 1
        return "понижение отклонено: " + "; ".join(v.render() for v in violations)
    reason = _clip(reason, _MAX_REASON_CHARS)

    new_evidence = [e for e in _parse_evidence(args.get("evidence"), state.tree) if e.verified]
    if status in GROUNDED_STATUSES and not (criterion.verified_evidence or new_evidence):
        state.rejected += 1
        return (
            "понижение отклонено: статус, утверждающий наличие кода, требует "
            "проверенной ссылки, а её нет"
        )

    if not criterion.status_before:
        criterion.status_before = current
    criterion.status = status
    criterion.challenge = reason
    criterion.proof = _clip(
        f"{criterion.proof_text} {_CHALLENGE_PREFIX} {reason}".strip(),
        _MAX_PROOF_WITH_CHALLENGE,
    )
    # Прежние поля-источники «Проверки» больше не должны перебивать новый текст.
    criterion.technical = ""
    criterion.why = ""
    criterion.evidence.extend(new_evidence)

    state.lowered.append(
        f"«{claim.item.title}», буллит {claim.index}: "
        f"{STATUS_LABEL.get(current, current)} → {STATUS_LABEL.get(status, status)}"
    )
    if state.on_verdict is not None:
        state.on_verdict(claim.item, claim.verdict)
    return (
        f"понижение принято: «{STATUS_LABEL.get(current, current)}» → "
        f"«{STATUS_LABEL.get(status, status)}». Переходи к следующему пункту."
    )


def _handle_finish(state: _CriticSession, args: dict) -> str:
    state.finished = True
    return "строгая проверка завершена"


_HANDLERS: dict[str, Callable[[_CriticSession, dict], str]] = {
    "submit_challenge": _handle_challenge,
    "finish": _handle_finish,
}


def _answer_call(state: _CriticSession, call: dict) -> dict[str, Any]:
    function = call.get("function") or {}
    name = str(function.get("name") or "")
    raw_args = function.get("arguments") or "{}"
    call_id = str(call.get("id") or "")
    try:
        args = json.loads(raw_args)
    except json.JSONDecodeError:
        return {"role": "tool", "tool_call_id": call_id,
                "content": f"аргументы инструмента не являются валидным JSON: {raw_args!r}"}
    args = args if isinstance(args, dict) else {}
    handler = _HANDLERS.get(name)
    if handler:
        content = handler(state, args)
    elif name in ("submit_stage", "submit_review", "submit_summary", "submit_groups", "submit_brief"):
        content = (f"инструмента {name!r} у рецензента нет: оценки уже выставлены. "
                   "Понижай через submit_challenge, заканчивай через finish")
    else:
        content = _cap_tool_result(state.tools.call(name, args).content)
    return {"role": "tool", "tool_call_id": call_id, "content": content}


def _copy_verdicts(verdicts: list[ItemVerdict]) -> list[ItemVerdict]:
    """Рецензент правит копию: результат первого агента остаётся как был,
    и след «до/после» лежит в самих полях `status_before`/`challenge`."""
    return [
        replace(v, criteria=[replace(c, evidence=list(c.evidence)) for c in v.criteria])
        for v in verdicts
    ]


def run_critic(
    result: AgentResult,
    tree: Tree,
    spec: ModelSpec | None,
    client: ChatClient | None = None,
    extraction: Extraction | None = None,
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None,
    on_event: Callable[[str, dict[str, Any]], None] | None = None,
    max_steps: int | None = None,
) -> AgentResult:
    """Прогнать рецензента по результату первого агента.

    Возвращает новый `AgentResult`: статусы, которые рецензент понизил,
    решение, пересчитанное по ним, и заметки о том, что проверено и что
    снято. Если рецензент выключен, модели нет или проверять нечего —
    результат возвращается как есть с заметкой.
    """
    if not critic_enabled():
        return replace(result, notes=list(result.notes) + [
            "Строгая проверка выключена (PKO_CRITIC=false): статусы первого агента "
            "не перепроверялись"
        ])
    if spec is None or not result.usable:
        return result
    verdicts = _copy_verdicts(result.verdicts)
    claims = collect_claims(result.plan, verdicts)
    if not claims:
        return replace(result, verdicts=verdicts, notes=list(result.notes) + [
            "Строгая проверка: подтверждённых ссылкой статусов нет, перепроверять нечего"
        ])

    if on_event is not None:
        on_event("phase", {"phase": "critic",
                           "label": "Строгая проверка: рецензент перечитывает код по ссылкам"})

    steps = max_steps if max_steps is not None else _env_int("PKO_CRITIC_STEPS", DEFAULT_CRITIC_STEPS)
    if steps <= 0:
        return replace(result, verdicts=verdicts, notes=list(result.notes) + [
            "Строгая проверка выключена (PKO_CRITIC_STEPS=0)"
        ])
    chat_client = client if client is not None else ChatClient(spec=spec)
    thinking_on = bool(
        spec.extra_body
        and spec.extra_body.get("chat_template_kwargs", {}).get("enable_thinking") is True
    )
    max_tokens = max_tokens_for(thinking_on)
    state = _run_critic_session(
        claims, verdicts, result.plan, tree, chat_client, steps, max_tokens,
        window_tokens=getattr(spec, "context_window", 0) or 0,
        extraction=extraction, on_verdict=on_verdict,
    )

    notes = list(result.notes)
    notes.append(
        f"Строгая проверка: перепроверено утверждений — {len(claims)}, "
        f"понижено — {len(state.lowered)}"
        + (f", отклонённых попыток понижения — {state.rejected}" if state.rejected else "")
    )
    notes.extend("Строгая проверка понизила: " + line for line in state.lowered)
    notes.extend(state.notes)
    return replace(
        result,
        verdicts=verdicts,
        summary=_reconcile_summary(result.summary, verdicts),
        notes=notes,
    )


def _run_critic_session(
    claims: list[Claim],
    verdicts: list[ItemVerdict],
    plan: list[PlanItem],
    tree: Tree,
    chat_client: ChatClient,
    max_steps: int,
    max_tokens: int,
    window_tokens: int = 0,
    extraction: Extraction | None = None,
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None,
) -> _CriticSession:
    """Цикл сессии рецензента — тот же, что у первого агента, но короче:
    без фаз, с двумя инструментами протокола. Бюджет истории считается так
    же (`matcher._history_budget`), потому что рецензент читает те же
    файлы и на большом репозитории упирается в то же окно."""
    state = _CriticSession(
        plan_by_id={item.id: item for item in plan},
        verdicts_by_id={v.item_id: v for v in verdicts},
        claims=claims, tree=tree,
        tools=ToolBox(tree, extraction=extraction),
        on_verdict=on_verdict,
    )
    system_prompt, found = load_critic_prompt()
    if not found:
        state.notes.append(
            "Строгая проверка: системный промпт рецензента не найден, "
            "использована краткая заготовка"
        )
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": build_critic_brief(claims)},
    ]
    overhead_chars = len(json.dumps(_CRITIC_TOOL_SCHEMAS, ensure_ascii=False))
    density = _START_CHARS_PER_TOKEN
    recent_calls: list[tuple[tuple[str, str], ...]] = []
    malformed = 0
    steps_done = 0
    budget_seconds = float(_env_int("PKO_CRITIC_SECONDS", DEFAULT_CRITIC_SECONDS))
    deadline = time.monotonic() + budget_seconds if budget_seconds else 0.0

    with trace_span("critic_session") as session_handle:
        for step in range(1, max(1, max_steps) + 1):
            steps_done = step
            if deadline and time.monotonic() > deadline:
                state.notes.append(
                    f"Строгая проверка: время исчерпано ({int(budget_seconds)} с) "
                    f"на шаге {step}, часть утверждений не перепроверена"
                )
                break
            sent_chars = sum(_message_size(m) for m in messages) + overhead_chars
            with trace_span("critic.step", step=step) as step_span:
                try:
                    result = chat_client.chat(
                        messages, tools=_CRITIC_TOOL_SCHEMAS, max_tokens=max_tokens,
                    )
                except LlmError as exc:
                    step_span.set_attribute("error", exc.message)
                    detail = f"{exc.message} {exc.hint}".strip()
                    state.notes.append(
                        f"Строгая проверка: рецензент недоступен на шаге {step}: {detail}"
                    )
                    break

            if not result.tool_calls:
                malformed += 1
                if malformed >= _MAX_MALFORMED:
                    state.notes.append(
                        f"Строгая проверка: рецензент не вызвал инструмент {malformed} "
                        "раз подряд — остановлено"
                    )
                    break
                messages.append({"role": "assistant", "content": result.text})
                messages.append({"role": "user", "content": _NUDGE})
                continue
            malformed = 0

            recent_calls.append(_signature(result.tool_calls))
            if len(recent_calls) >= _REPEAT_STOP and len(set(recent_calls[-_REPEAT_STOP:])) == 1:
                state.notes.append(
                    f"Строгая проверка: остановлено — {_REPEAT_STOP} одинаковых вызова подряд"
                )
                break

            messages.append({
                "role": "assistant",
                "content": result.text or None,
                "tool_calls": result.tool_calls,
                "reasoning_content": result.reasoning_content or None,
            })
            for call in result.tool_calls:
                messages.append(_answer_call(state, call))

            if result.usage:
                measured = _measure_density(
                    sent_chars, int(result.usage.get("prompt_tokens") or 0),
                )
                if measured:
                    density = measured
            _trim_history(messages, _history_budget(
                window_tokens=window_tokens, reserve_tokens=max_tokens,
                chars_per_token=density, overhead_chars=overhead_chars,
            ))

            if state.finished:
                break
        else:
            state.notes.append(
                f"Строгая проверка: бюджет шагов исчерпан ({max_steps}), "
                "часть утверждений могла остаться без перепроверки"
            )

        session_handle.set_attribute("steps_done", steps_done)
        session_handle.set_attribute("claims", len(claims))
        session_handle.set_attribute("lowered", len(state.lowered))
        session_handle.set_attribute("finished", state.finished)

    if not state.finished and not any("исчерпан" in n or "остановлено" in n or "недоступен" in n
                                      for n in state.notes):
        state.notes.append("Строгая проверка не завершена: finish не вызван")
    return state

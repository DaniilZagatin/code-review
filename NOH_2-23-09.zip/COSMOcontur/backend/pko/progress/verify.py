"""Проверка evidence, предложенной ролью matcher, по коду целевого репозитория.

Тот же принцип, что и в `pko.agent.verify` (`OBSERVED` означает «код это
показывает», а не «модель так сказала»): путь и строка обязаны существовать на
этом коммите, а рядом — находиться слово из основания. Но без привязки к
category/action/mechanism `pko.agent.verify.verify_facts` — пункт плана не
структурный факт кода с известным «механизмом», а утверждение более высокого
уровня («авторизация реализована»), которое может опираться на функцию, класс
или блок целиком. Поэтому здесь проверяется только путь/строка/якорь; заявленная
структурная привязка (§CHK-GRD-001 и подобные) к плану не относится.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from pko.extractors.base import Tree

ANCHOR_WINDOW = 5
MIN_ANCHOR = 4
# Сколько строк вверх смотреть в поисках объявления, внутри которого стоит
# указанная строка. Функции на 200+ строк в целевых репозиториях обычны.
ENCLOSING_SCAN = 300

_TOKEN = re.compile(r"[A-Za-z_][A-Za-z0-9_./-]{3,}")

# Объявление, внутри которого может лежать указанная строка. Один проход по
# трём формам, которые реально встречаются в целевых репозиториях:
# Python/JS (`def`/`class`/`function`), SQL (`CREATE PROCEDURE`) и
# Java/TS-сигнатура вида `public List<Row> loadRows(String id) {`.
_DEFINITION = re.compile(
    r"\b(?:def|class|function|procedure|interface|struct)\s+(?P<name>[A-Za-z_]\w*)",
    re.IGNORECASE,
)
_SQL_DEFINITION = re.compile(
    r"\bCREATE\s+(?:OR\s+REPLACE\s+)?(?:PROCEDURE|FUNCTION|TABLE|VIEW)\s+"
    r"(?:[\w\[\]\"`]+\.)*[\[\"`]?(?P<name>\w+)",
    re.IGNORECASE,
)
# Тело в конце строки обязательно: без него `return build(x)` внутри функции
# сошёл бы за её объявление, и ссылка подтверждалась бы вызовом, а не местом.
# Строка целиком закомментирована. Комментарий описывает намерение, а не
# реализацию: «# TODO: посчитать чувствительность» — не доказательство того,
# что чувствительность считается. Разбираются формы Python/SQL/JS/Java.
_COMMENT_LINE = re.compile(r"^\s*(?:#|//|--|\*|/\*)")

_SIGNATURE = re.compile(
    r"^\s*(?!(?:return|if|for|while|switch|catch|else|throw|new|await|yield)\b)"
    r"(?:[\w<>\[\],?@]+\s+)+(?P<name>\w+)\s*\([^;]*\)\s*"
    r"(?:throws\s+[\w,\s]+)?\{\s*$"
)


@dataclass(frozen=True)
class EvidenceVerdict:
    ok: bool
    path: str
    line: int | None
    basis: str
    reason: str


def verify_evidence(path: str, line: int | None, basis: str, tree: Tree) -> EvidenceVerdict:
    """Подтвердить одну evidence-ссылку, предложенную matcher'ом."""
    path = (path or "").strip()
    basis = (basis or "").strip()
    if not path:
        return EvidenceVerdict(False, path, line, basis, "пустой путь")
    if path not in tree.files_set:
        return EvidenceVerdict(False, path, line, basis, f"пути {path!r} нет на этом коммите")

    text = tree.read(path)
    if text is None:
        return EvidenceVerdict(False, path, line, basis, f"файл {path} не читается")

    lines = text.splitlines()
    if line is None:
        # «Ссылка на код без проверки не публикуется»: путь без строки
        # подтверждает лишь существование файла, а не утверждение буллита.
        # Прежний ok=True здесь был дырой — такая ссылка закрывала гейт
        # подтверждённости, ничего не проверяя.
        return EvidenceVerdict(
            False, path, None, basis,
            f"не указан номер строки в {path} — ссылкой без строки утверждение не подтверждается",
        )
    if line < 1 or line > len(lines):
        return EvidenceVerdict(
            False, path, line, basis, f"строка {line} вне файла {path} (всего {len(lines)})"
        )

    if _COMMENT_LINE.match(lines[line - 1]):
        return EvidenceVerdict(
            False, path, line, basis,
            f"{path}:{line} — это комментарий, а не код: он говорит о намерении, "
            "а не о реализации. Укажи строку с самим кодом",
        )

    anchor = _find_anchor(basis, lines, line)
    if anchor is None:
        return EvidenceVerdict(
            False, path, line, basis,
            f"в {path}:{line}±{ANCHOR_WINDOW} нет ни одного слова из основания "
            "и объемлющее объявление называется иначе",
        )
    return EvidenceVerdict(True, path, line, basis, f"подтверждено якорем «{anchor}»")


def _find_anchor(basis: str, lines: list[str], line: int) -> str | None:
    tokens = {t for t in _TOKEN.findall(basis) if len(t) >= MIN_ANCHOR}
    tokens.update(t for t in re.findall(r"[/\w.-]{4,}", basis) if any(c.isdigit() for c in t))

    # Составные имена вида `AgentGraph.classifier` или `module/handler` ищем
    # ещё и по частям: в коде рядом со строкой стоит `def classifier(...)`,
    # а не полное квалифицированное имя. Без этого верная ссылка отклонялась
    # как выдуманная — на реальном прогоне так отвалилось 11 ссылок из 24.
    for token in list(tokens):
        tokens.update(part for part in re.split(r"[^\w]+", token) if len(part) >= MIN_ANCHOR)

    if not tokens:
        return None
    low = max(1, line - ANCHOR_WINDOW)
    high = min(len(lines), line + ANCHOR_WINDOW)
    window = "\n".join(lines[low - 1: high]).lower()
    for token in sorted(tokens, key=len, reverse=True):
        if token.lower() in window:
            return token

    # Ссылка на строку в середине длинной функции: имени функции в окне ±5
    # нет, но ссылка верная. На живом прогоне так отклонились 9 ссылок из 27 —
    # все девять указывали внутрь функции, названной в основании.
    enclosing = _enclosing_name(lines, line)
    if enclosing and enclosing.lower() in {t.lower() for t in tokens}:
        return enclosing
    return None


def _enclosing_name(lines: list[str], line: int) -> str | None:
    """Имя ближайшего объявления выше указанной строки.

    Идём вверх до первого объявления — оно и есть то, внутри чего стоит
    строка. Проверку это не ослабляет: имя всё равно нужно взять из кода,
    угадать его нельзя.
    """
    top = max(0, line - ENCLOSING_SCAN)
    for index in range(min(line, len(lines)) - 1, top - 1, -1):
        text = lines[index]
        if not text.strip():
            continue
        # SQL проверяется первым: в «CREATE PROCEDURE dbo.calc_score» слово
        # `procedure` поймал бы общий шаблон и вернул бы «dbo» вместо имени.
        for pattern in (_SQL_DEFINITION, _DEFINITION, _SIGNATURE):
            match = pattern.search(text)
            if match:
                return match.group("name")
    return None

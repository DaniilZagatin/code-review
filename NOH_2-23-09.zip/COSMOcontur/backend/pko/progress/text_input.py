"""Общая часть разбора текстового ввода: чистка, маркеры, заголовки, слаг.

Форматов ввода два (`journey_text.py` — ручной путь, `agent_md.py` — файл
инициативы из колоды), но текст в них приходит из одних и тех же мест: Word,
презентация, письмо. Значит и чистить его надо одинаково.

Пока это лежало в двух модулях, оно и разошлось: маркеры списка отличались на
два символа (в колоде тире «–» считалось буллитом, в ручном пути — нет), а
таблицы транслитерации давали разные идентификаторы для одного названия
(«й» → `y` против `i`). Расхождение тихое: ввод разбирается, просто по-разному
в зависимости от того, какой парсер его подхватил.
"""

from __future__ import annotations

import re
import unicodedata

# Невидимые символы, которые приносит копирование из презентаций и Word:
# BOM, zero-width, мягкий перенос. Без вычистки они попадают в текст буллита,
# ломают якорный поиск evidence и видны в отчёте пустыми квадратами.
INVISIBLE = dict.fromkeys(map(ord, "﻿​‌‍⁠­"), None)

# Маркеры списка из реальных вводов. Кроме дефиса и «•» приходит «·»
# (U+00B7 MIDDLE DOT) — им размечают буллиты при копировании из презентаций,
# и тире «–»/«—», которым набирают списки в Word.
BULLET_MARKERS = "-*•·▪●‣⁃–—"
# Маркер + пробел: «-текст» без пробела — это чаще перенос слова, чем пункт.
BULLET = re.compile(rf"^\s*[{re.escape(BULLET_MARKERS)}]\s+(.+)$")

# Заголовок этапа без решётки: «Этап 3. Саммаризация», «Шаг 2) Проверка».
# Реальные вводы приходят и так, и через `##` — оба варианта равноправны.
PLAIN_STAGE = re.compile(r"^(?:этап|шаг|stage|step)\s+\d+\s*[.):-]?\s*(.+)$", re.IGNORECASE)
# Короче этого «название» — обрывок нумерации, а не заголовок этапа.
MIN_STAGE_TITLE = 3


def clean_line(raw_line: str) -> str:
    """Одна строка без невидимых символов и неразрывных пробелов."""
    return raw_line.translate(INVISIBLE).replace(" ", " ").strip()


def normalize(text: str) -> str:
    """NFKC + вычистка невидимых символов + унификация переносов и пробелов."""
    text = unicodedata.normalize("NFKC", text or "")
    text = text.translate(INVISIBLE).replace(" ", " ")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return "\n".join(re.sub(r"[ \t]+", " ", line).rstrip() for line in text.split("\n")).strip()


def bullet_text(line: str) -> str:
    """Текст пункта, если строка размечена маркером. Иначе пустая строка."""
    match = BULLET.match(line)
    return match.group(1).strip() if match else ""


def is_bullet(line: str) -> bool:
    return bool(BULLET.match(line))


def plain_stage_title(line: str) -> str:
    """Название этапа для строки вида «Этап 3. …». Иначе пустая строка."""
    match = PLAIN_STAGE.match(line.strip())
    if match and len(match.group(1).strip()) >= MIN_STAGE_TITLE:
        return match.group(0).strip()
    return ""


# Транслитерация для идентификаторов этапов. Одна на оба формата: два разных
# написания одного названия — это два разных id, и вердикт по этапу перестаёт
# находить свой этап.
_TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch",
    "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
}

MAX_SLUG_CHARS = 60


def slug(text: str, limit: int = MAX_SLUG_CHARS) -> str:
    """Название → короткий идентификатор латиницей, цифрами и дефисами.

    Только ASCII: идентификатор ездит в промпт агента и обратно, и кириллица
    в нём читается моделью как обычный текст, а не как метка.

    Длинное название режется по границе слова, а не по счётчику: обрывок
    «…po-pererazmesch» в идентификаторе объекта читается как опечатка.
    """
    translit = "".join(_TRANSLIT.get(char, char) for char in (text or "").lower())
    out = re.sub(r"[^A-Za-z0-9]+", "-", translit).strip("-").lower()
    if len(out) <= limit:
        return out
    cut = out[:limit]
    head = cut.rsplit("-", 1)[0] if "-" in cut else cut
    return head.strip("-") or cut

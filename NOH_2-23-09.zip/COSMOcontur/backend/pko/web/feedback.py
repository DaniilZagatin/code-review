"""Ответы команд на оценку: приняли, приняли с оговоркой или отклонили.

Отчёт — это утверждение о чужой работе, и у команды должно быть право с ним
не согласиться. Возражение не спорит с расчётом (он детерминированный), а
говорит о фактах: «этот пункт сделан, вот где» или «пункт не про нас».

Хранение — база, а не память процесса. Причина ровно та, из-за которой эту
механику и просили: возражения нужно обрабатывать **в одном месте**, а не
собирать руками по шестидесяти файлам. Реестр анализов живёт в памяти и
теряется при рестарте `pko serve` — возражения так терять нельзя.

**Две базы, одна логика.** На стенде это Postgres: файловая база в контейнере
лежала бы на эфемерном диске и умирала бы вместе с подом, а ответы команд
переживать рестарт обязаны. На ноутбуке аналитика Postgres'а нет, и там
остаётся SQLite-файл. Различаются только драйвер и текст DDL; проверки
ответа, обрезка полей и порядок выдачи — общие, поэтому поведение стенда и
ноутбука разойтись не может.

Выбор делает окружение: есть `PKO_DB_URL` (или `DATABASE_URL`) — Postgres,
нет — файл. Молчаливого отката с Postgres на файл нет: если DSN задан, а
подключиться не вышло, поднимается ошибка. Тихо записать возражения в
контейнерный файл и потерять их вместе с подом — худший из возможных исходов.

Схема плоская и денормализованная намеренно: строка возражения самодостаточна
и читается без джойнов даже простым `SELECT *`. Отчёт, к которому она
относится, к моменту разбора может быть давно перезапущен и забыт.
"""

from __future__ import annotations

import os
import re
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pko.errors import PkoError
from pko.util.paths import harden_dir, harden_file

# Три ответа, и ничего больше: любое расширение списка потребует объяснять
# читателю разницу, а сейчас она очевидна.
VERDICTS = ("accept", "accept_with_note", "reject")
VERDICT_LABEL = {
    "accept": "Принять",
    "accept_with_note": "Принять с оговоркой",
    "reject": "Отклонить",
}
# Комментарий обязателен для всего, кроме простого «принять».
VERDICTS_NEEDING_COMMENT = ("accept_with_note", "reject")

MAX_COMMENT_CHARS = 2000
MAX_AUTHOR_CHARS = 120


def clean_comment(text: str) -> str:
    """Комментарий в том виде, в каком он хранится: без лишних пробелов, с потолком.

    Одна функция на запись и на сравнение: сбор ответов из вернувшихся файлов
    ищет уже сохранённое по тому же виду, и разойтись им нельзя.
    """
    return " ".join((text or "").split())[:MAX_COMMENT_CHARS]


def clean_author(text: str) -> str:
    return " ".join((text or "").split())[:MAX_AUTHOR_CHARS]

DEFAULT_DB_PATH = Path.home() / ".pko" / "feedback.db"
# Схема Postgres по умолчанию. На стенде задаётся через `DB_SCHEMA`: в одной
# базе живёт несколько приложений, и таблицы не должны драться за `public`.
DEFAULT_SCHEMA = "pko"

# Порядок колонок в выборке. Позиционный доступ вместо `row["name"]` — потому
# что sqlite3 и драйверы Postgres возвращают строки по-разному, а список
# колонок один и тот же для обеих баз.
_COLUMNS = (
    "id", "created_at", "analysis_id", "project_name", "client_path",
    "bullet_index", "bullet_text", "agent_status", "verdict", "comment", "author",
)

# Имя таблицы в каждом запросе — полное, со схемой (`{table}` подставляет
# `FeedbackStore.table`). Полагаться на `SET search_path` нельзя: на стенде
# между приложением и базой стоит pgbouncer, а в режиме transaction pooling
# сессионная настройка живёт ровно одну транзакцию — в автокоммите это один
# запрос. DDL на старте проходил, а следующий `INSERT INTO disputes` уезжал
# в другое серверное соединение с `search_path` по умолчанию и падал с
# «relation "disputes" does not exist». В SQLite схемы нет, `{table}` там —
# просто `disputes`.
_SELECT = "SELECT " + ", ".join(_COLUMNS) + " FROM {table}"

_INSERT = (
    "INSERT INTO {table} (created_at, analysis_id, project_name, client_path, "
    "bullet_index, bullet_text, agent_status, verdict, comment, author) "
    "VALUES (?,?,?,?,?,?,?,?,?,?)"
)

_SCHEMA_SQLITE = (
    """CREATE TABLE IF NOT EXISTS {table} (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at      TEXT    NOT NULL,
        analysis_id     TEXT    NOT NULL,
        project_name    TEXT    NOT NULL DEFAULT '',
        client_path     TEXT    NOT NULL DEFAULT '',
        bullet_index    INTEGER NOT NULL,
        bullet_text     TEXT    NOT NULL DEFAULT '',
        agent_status    TEXT    NOT NULL DEFAULT '',
        verdict         TEXT    NOT NULL,
        comment         TEXT    NOT NULL DEFAULT '',
        author          TEXT    NOT NULL DEFAULT ''
    )""",
    "CREATE INDEX IF NOT EXISTS disputes_analysis ON {table}(analysis_id)",
    "CREATE INDEX IF NOT EXISTS disputes_verdict ON {table}(verdict)",
)

# То же самое на диалекте Postgres. `created_at` намеренно остаётся текстом:
# время проставляет приложение и отдаёт его в отчёт строкой, а `timestamptz`
# добавил бы разницу часовых поясов между стендом и ноутбуком там, где её
# сейчас нет. Индекс создаётся в схеме таблицы — имя индекса квалифицировать
# нельзя, Postgres это запрещает.
_SCHEMA_POSTGRES = (
    """CREATE TABLE IF NOT EXISTS {table} (
        id              BIGSERIAL PRIMARY KEY,
        created_at      TEXT    NOT NULL,
        analysis_id     TEXT    NOT NULL,
        project_name    TEXT    NOT NULL DEFAULT '',
        client_path     TEXT    NOT NULL DEFAULT '',
        bullet_index    INTEGER NOT NULL,
        bullet_text     TEXT    NOT NULL DEFAULT '',
        agent_status    TEXT    NOT NULL DEFAULT '',
        verdict         TEXT    NOT NULL,
        comment         TEXT    NOT NULL DEFAULT '',
        author          TEXT    NOT NULL DEFAULT ''
    )""",
    "CREATE INDEX IF NOT EXISTS disputes_analysis ON {table}(analysis_id)",
    "CREATE INDEX IF NOT EXISTS disputes_verdict ON {table}(verdict)",
)

# Сколько ждать соединения с базой. Без предела libpq ждёт TCP-таймаут —
# минуты, — и всё это время под замком хранилища висит запрос человека,
# а за ним копятся остальные: ответ «не сохраняется» превращался в «страница
# молчит». Десяти секунд для базы в том же контуре достаточно с запасом.
CONNECT_TIMEOUT_SECONDS = 10

# `postgresql+psycopg://` — форма SQLAlchemy. В корпоративных секретах DSN
# часто лежит именно так, а libpq суффикс драйвера не понимает.
_SQLA_DRIVER = re.compile(r"^(postgres(?:ql)?)\+[a-z0-9_]+://", re.IGNORECASE)
_DSN_PREFIXES = ("postgresql://", "postgres://")
# Имя схемы в DDL нельзя передать параметром — только подстановкой в текст.
# Поэтому оно проверяется по белому списку символов, а не экранируется.
_SCHEMA_RE = re.compile(r"^[a-z_][a-z0-9_]{0,62}$")
_PASSWORD_RE = re.compile(r"(://[^:/@]+):[^@]*@")


def normalize_dsn(dsn: str) -> str:
    """Привести DSN к виду, который понимает libpq."""
    clean = _SQLA_DRIVER.sub(r"\1://", (dsn or "").strip())
    if not clean.lower().startswith(_DSN_PREFIXES):
        raise PkoError(
            f"Строка подключения к базе не похожа на Postgres: {mask_dsn(clean)!r}.",
            hint="ожидается postgresql://пользователь:пароль@хост:порт/база",
        )
    return clean


def mask_dsn(dsn: str) -> str:
    """DSN без пароля — для сообщений об ошибке и для `/health`."""
    return _PASSWORD_RE.sub(r"\1:***@", dsn or "")


def check_schema(name: str) -> str:
    """Имя схемы Postgres: только то, что можно безопасно вписать в DDL."""
    clean = (name or "").strip().lower()
    if not _SCHEMA_RE.match(clean):
        raise PkoError(
            f"Недопустимое имя схемы базы: {name!r}.",
            hint="латиница, цифры и подчёркивание, начинается с буквы — "
                 "например deep_research",
        )
    return clean


def _load_driver() -> Any:
    """Драйвер Postgres: psycopg 3, а если его нет — psycopg2.

    Оба дают одинаковый DB-API и одинаковые `%s`-параметры, поэтому коду
    дальше всё равно, какой из них стоит. Ставить оба в закрытом контуре не
    всегда получается, а падать из-за имени пакета — обидно.
    """
    try:
        import psycopg  # type: ignore[import-not-found]

        return psycopg
    except ImportError:
        pass
    try:
        import psycopg2  # type: ignore[import-not-found]

        return psycopg2
    except ImportError as exc:
        raise PkoError(
            "Драйвер Postgres не установлен.",
            hint="выполните: pip install psycopg[binary] — подойдёт и psycopg2-binary",
        ) from exc


def _pg_connect(driver: Any, dsn: str) -> Any:
    """Отдельная функция ради тестов: подменяется фиктивным соединением."""
    kwargs: dict[str, Any] = {}
    if "connect_timeout" not in dsn:
        kwargs["connect_timeout"] = CONNECT_TIMEOUT_SECONDS
    conn = driver.connect(dsn, **kwargs)
    # psycopg 3 после нескольких повторов одного и того же запроса готовит
    # его на сервере под именем и дальше зовёт по имени. Через pgbouncer в
    # режиме transaction pooling следующая транзакция уходит в другое
    # серверное соединение, где такого имени нет: первые вставки проходят,
    # а с шестой — «prepared statement "_pg3_0" does not exist».
    if hasattr(conn, "prepare_threshold"):
        conn.prepare_threshold = None
    return conn


def _is_default_dir(directory: Path) -> bool:
    """Тот ли это `~/.pko`, права на который держит сам инструмент."""
    try:
        return Path(directory).resolve() == DEFAULT_DB_PATH.parent.resolve()
    except OSError:
        return False


@dataclass(frozen=True)
class Dispute:
    """Один ответ команды на оценку одного буллита."""

    analysis_id: str
    bullet_index: int
    verdict: str
    comment: str = ""
    author: str = ""
    project_name: str = ""
    client_path: str = ""
    bullet_text: str = ""
    agent_status: str = ""
    created_at: str = ""
    id: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "created_at": self.created_at,
            "analysis_id": self.analysis_id,
            "project_name": self.project_name,
            "client_path": self.client_path,
            "bullet_index": self.bullet_index,
            "bullet_text": self.bullet_text,
            "agent_status": self.agent_status,
            "verdict": self.verdict,
            "verdict_label": VERDICT_LABEL.get(self.verdict, self.verdict),
            "comment": self.comment,
            "author": self.author,
        }


@dataclass
class FeedbackStore:
    """Хранилище возражений: Postgres, если задан `dsn`, иначе файл.

    Соединение одно на процесс и защищено замком: `pko serve` выполняет анализ
    в отдельных потоках, а sqlite3 по умолчанию запрещает работу с соединением
    из чужого потока — у Postgres то же ограничение по смыслу, одно соединение
    не рассчитано на параллельные курсоры.
    """

    path: Path = field(default_factory=lambda: DEFAULT_DB_PATH)
    dsn: str = ""
    schema: str = DEFAULT_SCHEMA
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)
    _conn: Any = field(default=None, repr=False)
    _driver: Any = field(default=None, repr=False)

    def __post_init__(self) -> None:
        # Имя схемы попадает в текст каждого запроса подстановкой, поэтому
        # проверяется один раз при создании, а не при каждом обращении.
        if self.dsn:
            self.schema = check_schema(self.schema)

    @property
    def is_postgres(self) -> bool:
        return bool(self.dsn)

    @property
    def table(self) -> str:
        """Полное имя таблицы: со схемой в Postgres, голое в SQLite."""
        return f"{self.schema}.disputes" if self.is_postgres else "disputes"

    def _sql(self, template: str) -> str:
        return template.format(table=self.table)

    def describe(self) -> str:
        """Куда именно пишутся ответы — строкой для человека, без пароля."""
        if self.is_postgres:
            return f"Postgres {mask_dsn(self.dsn)}, таблица {self.table}"
        return str(self.path)

    def kind(self) -> str:
        return "postgres" if self.is_postgres else "sqlite"

    def _failure(self, action: str, exc: Exception) -> PkoError:
        """Ошибка базы — понятной ошибкой PKO, а не трассировкой в 500.

        Голое исключение драйвера уходило из обработчика как Internal Server
        Error, и на экране оставалось только «Не удалось сохранить ответ» —
        без причины. Причина здесь, вместе с адресом хранилища.
        """
        detail = f"{type(exc).__name__}: {exc}".strip()[:400]
        return PkoError(
            f"Не удалось {action}: {detail}",
            hint=f"хранилище — {self.describe()}. Живая проверка: GET /api/health/db",
        )

    # --- соединение -------------------------------------------------------
    def connect(self) -> Any:
        if self._conn is None:
            self._conn = self._open()
        return self._conn

    def _open(self) -> Any:
        if not self.is_postgres:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self.path), check_same_thread=False)
            self._prepare(conn, _SCHEMA_SQLITE)
            # В комментариях команд — сведения о внутренних системах, та же
            # конфиденциальность, что у кеша модели и зеркала репозитория.
            harden_file(self.path)
            # Каталог ужимаем только свой: `~/.pko` — то же место, что у
            # кеша модели и зеркал. Каталог, который оператор выбрал сам
            # (`PKO_FEEDBACK_DB=/data/feedback.db`), — его дело. Прежний
            # вызов закрывал ещё и родителя: при пути по умолчанию это
            # домашний каталог целиком, при `/tmp/feedback.db` — `/tmp` и `/`.
            if _is_default_dir(self.path.parent):
                harden_dir(self.path.parent)
            return conn

        if self._driver is None:
            self._driver = _load_driver()
        try:
            conn = _pg_connect(self._driver, self.dsn)
            # Автокоммит: каждая вставка сама по себе, и одна упавшая команда
            # не оставляет соединение в «idle in transaction».
            conn.autocommit = True
        except PkoError:
            raise
        except Exception as exc:
            raise PkoError(
                f"Не удалось подключиться к базе ответов: {exc}",
                hint=f"проверьте доступность {mask_dsn(self.dsn)} и права пользователя",
            ) from exc
        self._prepare(conn, _SCHEMA_POSTGRES)
        return conn

    def _prepare(self, conn: Any, ddl: tuple[str, ...]) -> None:
        """Создать схему и таблицу. Нет прав — работать с готовой.

        `search_path` не трогаем: таблица в каждом запросе названа полностью,
        и через pgbouncer это единственное, что работает.
        """
        cursor = conn.cursor()
        if self.is_postgres:
            try:
                cursor.execute(f"CREATE SCHEMA IF NOT EXISTS {self.schema}")
            except Exception:
                # Прав на создание схемы у прикладного пользователя может не
                # быть — тогда схему заводит DBA, и это нормальный сценарий.
                pass
        try:
            for statement in ddl:
                cursor.execute(self._sql(statement))
            if not self.is_postgres:
                conn.commit()
        except Exception as exc:
            # Таблицу мог создать DBA, а прав на DDL не дать. Тогда всё в
            # порядке ровно до тех пор, пока таблица читается.
            try:
                cursor.execute(self._sql(_SELECT) + " LIMIT 1")
                cursor.fetchall()
            except Exception:
                raise PkoError(
                    f"База ответов недоступна: {exc}",
                    hint=f"{self.describe()} — нужна таблица {self.table} и права на неё",
                ) from exc

    def _run(self, query: str, params: tuple[Any, ...], *, fetch: bool) -> Any:
        """Выполнить запрос, один раз переподключившись при обрыве связи.

        Соединение с внешним Postgres живёт часами и рвётся само: рестарт
        базы, таймаут простоя, сеть. Терять из-за этого возражение, которое
        человек только что написал, нельзя.

        Размен осознанный: если связь оборвалась после того, как база успела
        записать строку, повтор добавит дубль. Для комментария команды дубль
        в общем списке лучше, чем потерянное возражение.
        """
        sql = query.replace("?", "%s") if self.is_postgres else query
        try:
            return self._execute(sql, params, fetch=fetch)
        except Exception as exc:
            if not self._is_connection_error(exc):
                raise
            self._drop()
            return self._execute(sql, params, fetch=fetch)

    def _execute(self, sql: str, params: tuple[Any, ...], *, fetch: bool) -> Any:
        conn = self.connect()
        cursor = conn.cursor()
        cursor.execute(sql, params)
        rows = cursor.fetchall() if fetch else None
        if not self.is_postgres:
            conn.commit()
        return rows

    def _is_connection_error(self, exc: Exception) -> bool:
        """Обрыв связи, а не ошибка запроса: повторять имеет смысл только его."""
        if not self.is_postgres or self._driver is None:
            return False
        broken = tuple(
            error for error in (getattr(self._driver, "OperationalError", None),
                                getattr(self._driver, "InterfaceError", None))
            if isinstance(error, type)
        )
        return bool(broken) and isinstance(exc, broken)

    def _drop(self) -> None:
        try:
            if self._conn is not None:
                self._conn.close()
        except Exception:
            pass
        self._conn = None

    # --- операции ---------------------------------------------------------
    def save(self, dispute: Dispute) -> Dispute:
        verdict = (dispute.verdict or "").strip()
        if verdict not in VERDICTS:
            raise PkoError(
                f"Неизвестный ответ: {verdict!r}.",
                hint="допустимы: " + ", ".join(VERDICTS),
            )
        comment = clean_comment(dispute.comment)
        if verdict in VERDICTS_NEEDING_COMMENT and not comment:
            raise PkoError(
                f"Ответ «{VERDICT_LABEL[verdict]}» требует комментария.",
                hint="напишите, что именно не так с оценкой — без этого "
                     "возражение нечем обработать",
            )
        created = dispute.created_at or time.strftime("%Y-%m-%d %H:%M:%S")
        row = (
            created, dispute.analysis_id, dispute.project_name[:200],
            dispute.client_path[:200], int(dispute.bullet_index),
            dispute.bullet_text[:1000], dispute.agent_status[:40],
            verdict, comment, clean_author(dispute.author),
        )
        with self._lock:
            try:
                new_id = self._insert(row)
            except PkoError:
                raise
            except Exception as exc:
                raise self._failure("записать ответ в базу", exc) from exc
        return Dispute(
            id=new_id, created_at=created, analysis_id=dispute.analysis_id,
            project_name=dispute.project_name, client_path=dispute.client_path,
            bullet_index=dispute.bullet_index, bullet_text=dispute.bullet_text,
            agent_status=dispute.agent_status, verdict=verdict,
            comment=comment, author=dispute.author,
        )

    def _insert(self, row: tuple[Any, ...]) -> int:
        if self.is_postgres:
            rows = self._run(self._sql(_INSERT) + " RETURNING id", row, fetch=True)
            return int(rows[0][0]) if rows else 0
        # У sqlite3 идентификатор берётся у курсора, а не из ответа запроса.
        conn = self.connect()
        cursor = conn.execute(self._sql(_INSERT), row)
        conn.commit()
        return int(cursor.lastrowid or 0)

    def list(self, analysis_id: str = "", limit: int = 1000) -> list[Dispute]:
        """Возражения, свежие сверху. Без `analysis_id` — по всем анализам."""
        query = self._sql(_SELECT)
        params: tuple[Any, ...] = ()
        if analysis_id:
            query += " WHERE analysis_id = ?"
            params = (analysis_id,)
        query += " ORDER BY id DESC LIMIT ?"
        params = params + (max(1, min(limit, 10_000)),)
        with self._lock:
            try:
                rows = self._run(query, params, fetch=True) or []
            except PkoError:
                raise
            except Exception as exc:
                raise self._failure("прочитать ответы из базы", exc) from exc
        return [_as_dispute(row) for row in rows]

    def ping(self) -> str:
        """Живое обращение к базе: соединение, таблица, права на чтение.

        Для диагностики «не сохраняется», а не для проб готовности пода:
        `/health` в базу намеренно не ходит. Возвращает адрес хранилища,
        при отказе поднимает `PkoError` с настоящей причиной.
        """
        with self._lock:
            try:
                self._run(self._sql(_SELECT) + " LIMIT 1", (), fetch=True)
            except PkoError:
                raise
            except Exception as exc:
                raise self._failure("прочитать базу ответов", exc) from exc
        return self.describe()

    def close(self) -> None:
        with self._lock:
            self._drop()


def _as_dispute(row: Any) -> Dispute:
    """Строка выборки → объект. Колонки берутся по позиции: см. `_COLUMNS`."""
    return Dispute(
        id=int(row[0]), created_at=str(row[1]), analysis_id=str(row[2]),
        project_name=str(row[3]), client_path=str(row[4]),
        bullet_index=int(row[5]), bullet_text=str(row[6]),
        agent_status=str(row[7]), verdict=str(row[8]),
        comment=str(row[9]), author=str(row[10]),
    )


def _env(*names: str) -> str:
    for name in names:
        value = (os.environ.get(name) or "").strip()
        if value:
            return value
    return ""


def default_store() -> FeedbackStore:
    """Хранилище по умолчанию: Postgres по DSN из окружения, иначе файл.

    `PKO_DB_URL` идёт первым: `DATABASE_URL` — имя общее, и на чужой машине
    оно может указывать на постороннюю базу.
    """
    dsn = _env("PKO_DB_URL", "DATABASE_URL")
    if dsn:
        return FeedbackStore(
            dsn=normalize_dsn(dsn),
            schema=check_schema(_env("PKO_DB_SCHEMA", "DB_SCHEMA") or DEFAULT_SCHEMA),
        )
    raw = _env("PKO_FEEDBACK_DB")
    return FeedbackStore(path=Path(raw) if raw else DEFAULT_DB_PATH)


_STORE: FeedbackStore | None = None
# Хранилище создаётся при первом обращении, а обращения идут из пула потоков:
# два одновременных первых запроса без замка заводили бы два хранилища с
# двумя соединениями, и одно из них жило бы бесхозным.
_STORE_LOCK = threading.Lock()


def store() -> FeedbackStore:
    """Общее хранилище процесса — одно соединение на все запросы."""
    global _STORE
    with _STORE_LOCK:
        if _STORE is None:
            _STORE = default_store()
        return _STORE


def reset_store(new: FeedbackStore | None = None) -> None:
    """Подменить хранилище (тесты уводят базу во временный каталог)."""
    global _STORE
    with _STORE_LOCK:
        if _STORE is not None:
            _STORE.close()
        _STORE = new

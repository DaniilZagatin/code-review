"""Сбор ответов из вернувшихся HTML-отчётов в общую базу.

Отчёты уходят письмом и возвращаются письмом же — с ответами внутри файла.
Шестьдесят инициатив означают шестьдесят писем, и разбирать их поштучно никто
не станет. Эта команда читает вернувшиеся файлы и складывает ответы туда же,
куда их пишет веб-форма: в одну базу, из которой всё видно сразу.

Из файла берётся только то, что в нём есть достоверно: `window.__ANSWERS__`
(ответы) и `window.__DATA__` (кто оценивался и какие были буллиты). Ничего не
досочиняется: если файл не тот или ответов в нём нет, это так и говорится.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from pko.errors import PkoError
from pko.web.feedback import Dispute, FeedbackStore, clean_author, clean_comment

_ANSWERS_AT = re.compile(r"window\.__ANSWERS__\s*=\s*")
_DATA_AT = re.compile(r"window\.__DATA__\s*=\s*")


def _json_after(pattern: re.Pattern[str], html: str) -> str:
    """Объект JSON после маркера — по балансу скобок, а не по регулярке.

    Регулярка тут не работает: жадная захватывает всё до последней `}` в
    файле, ленивая останавливается на первой вложенной. В отчёте оба объекта
    вложенные, и оба соседствуют со скриптом страницы.

    Скобки внутри строк не считаются — иначе текст буллита с фигурной скобкой
    оборвал бы разбор на середине.
    """
    match = pattern.search(html)
    if not match:
        return ""
    start = html.find("{", match.end())
    if start < 0:
        return ""
    depth = 0
    in_string = False
    escaped = False
    for index in range(start, len(html)):
        char = html[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return html[start:index + 1]
    return ""


@dataclass
class CollectResult:
    """Итог разбора одной папки с вернувшимися отчётами."""

    saved: int = 0
    files_with_answers: int = 0
    files_without_answers: list[str] = field(default_factory=list)
    unreadable: list[str] = field(default_factory=list)
    # Ответы, которые база не приняла (например, «отклонить» без
    # комментария в файле, правленном руками): файл при этом дочитывается,
    # остальные его ответы сохраняются.
    skipped: list[str] = field(default_factory=list)


def answers_of(html: str) -> dict[str, dict]:
    """Ответы из файла. Пустой словарь — их там нет."""
    chunk = _json_after(_ANSWERS_AT, html)
    if not chunk:
        return {}
    try:
        raw = json.loads(chunk)
    except json.JSONDecodeError:
        return {}
    return {
        str(key): value for key, value in raw.items()
        if isinstance(value, dict) and value.get("verdict")
    }


def report_of(html: str) -> dict:
    """Данные отчёта: инициатива и тексты буллитов."""
    chunk = _json_after(_DATA_AT, html)
    if not chunk:
        return {}
    try:
        return json.loads(chunk)
    except json.JSONDecodeError:
        return {}


def collect_file(
    path: Path, store: FeedbackStore, analysis_id: str = "",
    skipped: list[str] | None = None,
) -> int:
    """Сохранить ответы одного файла. Вернуть, сколько их записано.

    Повторный сбор по той же папке ничего не удваивает: письма приходят по
    одному, а команда каждый раз запускает сбор по всей папке целиком.
    Ответ, который в базе уже лежит ровно в таком виде, второй раз не
    пишется. Изменённый ответ (другой вердикт или комментарий) пишется как
    новый — свежий сверху, и именно его экран считает текущим.
    """
    html = path.read_text(encoding="utf-8", errors="replace")
    answers = answers_of(html)
    if not answers:
        return 0

    data = report_of(html)
    meta = data.get("meta") or {}
    rows = [
        row
        for item in (data.get("items") or [])
        for row in (item.get("assessment") or [])
    ]
    # Имя файла — последняя зацепка, когда отчёт вернулся без внятной шапки:
    # по нему хотя бы понятно, из какого письма ответ.
    origin = analysis_id or str(meta.get("source_digest") or "")[:10] or path.stem
    known = {
        _fingerprint(existing)
        for existing in store.list(analysis_id=origin, limit=10_000)
    }

    saved = 0
    for key, answer in sorted(answers.items(), key=lambda kv: _as_int(kv[0])):
        index = _as_int(key)
        row = rows[index] if 0 <= index < len(rows) else {}
        dispute = Dispute(
            analysis_id=origin,
            bullet_index=index,
            verdict=str(answer.get("verdict") or ""),
            comment=str(answer.get("comment") or ""),
            author=str(answer.get("author") or ""),
            project_name=str(meta.get("project_name") or ""),
            client_path=str(meta.get("client_path_name") or ""),
            bullet_text=str(row.get("text") or ""),
            agent_status=str(row.get("status") or ""),
        )
        mark = _fingerprint(dispute)
        if mark in known:
            continue
        try:
            store.save(dispute)
        except PkoError as exc:
            # Один негодный ответ не должен обрывать разбор файла на середине:
            # тогда часть ответов записана, часть нет, а повтор непонятно с
            # чего начинать.
            if skipped is not None:
                skipped.append(f"{path.name}, пункт {index}: {exc.message}")
            continue
        known.add(mark)
        saved += 1
    return saved


def _fingerprint(dispute: Dispute) -> tuple[int, str, str, str]:
    """Чем один ответ отличается от другого — в том виде, в каком он хранится."""
    return (
        int(dispute.bullet_index),
        (dispute.verdict or "").strip(),
        clean_comment(dispute.comment),
        clean_author(dispute.author),
    )


def collect(paths: list[Path], store: FeedbackStore) -> CollectResult:
    """Собрать ответы из списка файлов и папок с ними."""
    result = CollectResult()
    for path in _expand(paths):
        try:
            count = collect_file(path, store, skipped=result.skipped)
        except (OSError, UnicodeError) as exc:
            result.unreadable.append(f"{path.name}: {exc}")
            continue
        if count:
            result.saved += count
            result.files_with_answers += 1
        else:
            result.files_without_answers.append(path.name)
    return result


def _expand(paths: list[Path]) -> list[Path]:
    out: list[Path] = []
    for path in paths:
        if path.is_dir():
            out.extend(sorted(path.rglob("*.html")))
        elif path.is_file():
            out.append(path)
    return out


def _as_int(value: object) -> int:
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return -1

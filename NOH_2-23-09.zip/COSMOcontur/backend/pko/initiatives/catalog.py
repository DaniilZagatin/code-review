"""Каталог инициатив: образы результата, вшитые в пакет.

Инициатив шестьдесят с лишним, и каждый раз искать нужный `.md`, копировать
его в форму и надеяться, что скопировался целиком, — лишняя работа и лишний
способ ошибиться. Каталог лежит рядом с кодом: выбрал по имени, запустил.

В каталоге только то, что нужно анализу: клиентский путь, название
инициативы, этапы, буллиты образа результата и дословный хвост из колоды.
Разметка презентации, оглавление и служебные файлы архива не хранятся.

Собирается командой `python scripts/build_initiatives.py <папка>` — колоды
SteerCo обновляются, и каталог должен пересобираться, а не править́ся руками.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any

from pko.errors import PkoError

CATALOG_PATH = Path(__file__).parent / "catalog.json"


@dataclass(frozen=True)
class Initiative:
    """Одна инициатива каталога."""

    id: str
    project: str
    client_path: str = ""
    source: str = ""
    stages: list[str] = field(default_factory=list)
    bullets: list[str] = field(default_factory=list)
    context_text: str = ""

    @property
    def title(self) -> str:
        """Как показывать в списке: путь и инициатива читаются вместе."""
        return f"{self.client_path}: {self.project}" if self.client_path else self.project

    def to_text(self) -> str:
        """Собрать образ результата обратно в текст формата колоды.

        Каталог хранит разобранные части, но дальше по пайплайну идёт тот же
        `parse_plan_text`, что и для файла из формы. Один разбор на оба
        источника: инициатива из каталога не может повести себя иначе, чем
        тот же текст, вставленный руками.
        """
        lines = [
            f"Клиентский путь: {self.client_path or 'Клиентский путь'}",
            f"Проект: {self.project}",
        ]
        lines.extend(f"## {stage}" for stage in self.stages)
        lines.extend(f"- {bullet}" for bullet in self.bullets)
        if self.context_text:
            lines.append(self.context_text)
        return "\n".join(lines) + "\n"

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "project": self.project, "client_path": self.client_path,
            "source": self.source, "title": self.title,
            "stages": list(self.stages), "bullets": list(self.bullets),
        }


@lru_cache(maxsize=1)
def _load() -> tuple[Initiative, ...]:
    if not CATALOG_PATH.is_file():
        return ()
    try:
        raw = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PkoError(
            "Каталог инициатив не читается.",
            hint=f"{CATALOG_PATH}: {exc}. Пересоберите: "
                 "python scripts/build_initiatives.py <папка с .md>",
        ) from exc
    return tuple(
        Initiative(
            id=str(item.get("id") or ""),
            project=str(item.get("project") or ""),
            client_path=str(item.get("client_path") or ""),
            source=str(item.get("source") or ""),
            stages=list(item.get("stages") or []),
            bullets=list(item.get("bullets") or []),
            context_text=str(item.get("context_text") or ""),
        )
        for item in raw.get("items") or []
        if item.get("id") and item.get("bullets")
    )


def all_initiatives() -> list[Initiative]:
    return list(_load())


def find(query: str) -> Initiative:
    """Инициатива по идентификатору или по части названия.

    Точное совпадение идентификатора важнее поиска по названию: скрипты и
    ссылки ходят по нему, и подмена «похожим» превратила бы воспроизводимый
    прогон в лотерею.
    """
    query = (query or "").strip()
    if not query:
        raise PkoError("Не указана инициатива.", hint="передайте идентификатор или часть названия")

    items = _load()
    if not items:
        raise PkoError(
            "Каталог инициатив пуст.",
            hint="соберите его: python scripts/build_initiatives.py <папка с .md>",
        )

    for item in items:
        if item.id == query:
            return item

    low = query.lower()
    matches = [i for i in items if low in i.project.lower() or low in i.id.lower()]
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise PkoError(
            f"Инициатива не найдена: {query!r}.",
            hint="полный список: pko initiatives",
        )
    raise PkoError(
        f"Под {query!r} подходит {len(matches)} инициатив.",
        hint="уточните запрос; например: "
             + ", ".join(i.id for i in matches[:3]),
    )

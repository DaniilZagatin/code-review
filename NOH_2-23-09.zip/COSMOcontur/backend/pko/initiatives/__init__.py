"""Каталог образов результата, вшитый в пакет."""

from pko.initiatives.catalog import Initiative, all_initiatives, find

__all__ = ["Initiative", "all_initiatives", "find"]

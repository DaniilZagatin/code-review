"""Единый паспорт клиентского пути — рендер HTML-шаблона v3.

Шаблон: ``passport-dpss-v3.html``. Использует ``data-fill``
атрибуты (не Mustache): каждый заполняемый элемент имеет
``data-fill="value|source|name|object-id|object-version|..."`` и
``data-placeholder``. Рендерер находит эти элементы и подставляет текст,
сохраняя CSS, структуру, классы и ``<template>``-доноры.

Иерархия объектов в шаблоне:
  journey (КП) → process (процесс) → bbb (бизнес-блок) → operation (операция)

Карточки потребности клиента (§ 4.1) и ограничения исполнения (§ 4.6),
которые есть в шаблоне, паспорт не выпускает: их контейнеры и заготовки
рендерер вырезает (`_strip_removed_sections`), сам шаблон не меняется.
Раздел «Основание паспорта» (область анализа, граница решения, дата,
образ результата) вырезается так же: заказчику он не нужен, репозиторий
и коммит остаются строкой в шапке.
Поверх дерева паспорт несёт связи: у узла может быть несколько родителей
(общий BBB в нескольких процессах), а между узлами — связи из
`passport_gate.RELATION_KINDS`; в реестре столбец «Родитель» перечисляет
всех родителей через запятую, связи идут в схему и карточку узла.

Два источника значений полей:
  1. **Паспортный агент** (``progress.passport_agent``, отдельная сессия
     после оценки, рецензента и ревизора) — модель заполняет смысловые поля
     по знаниям сессии оценки. Значения приходят как ``passport_data``
     (``ProgressModel.passport_data``) и преобразуются в ``llm_values``
     (плоский dict, ключи совпадают со схемой ``_fill_template``).
  2. **Детерминированное заполнение** (``_build_fill_values``) — fallback
     из ProgressModel + Extraction, если паспортная сессия не приняла ни
     одного узла.

Принцип тот же: код заполняет, не выдумывает. Агент предлагает содержания
полей, код подставляет их в HTML — модель не видит разметку и не может
её сломать.
"""

from __future__ import annotations

import html as _html
import re
import time
from pathlib import Path
from typing import Any

from pko.errors import PkoError
from pko.extractors.runner import Extraction
from pko.progress.passport_gate import PLANNED_FIELDS, audience_of, journey_name_of
from pko.render.passport_map import build_passport_map, nodes_json
from pko.render.passport_content import compact_template
from pko.render.dpss_theme import embedded_fonts
from pko.progress.plan_input import PlanInput
from pko.progress.schema import ProgressModel

_TEMPLATE_PATH = Path(__file__).resolve().parents[3] / "passport-dpss-v3.html"

_EMPTY = "Не установлено по доступным артефактам"
_NEEDS_OWNER = "Требуется подтверждение владельца"


def render_client_journey_passport(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str = "",
    llm_values: dict[str, str] | None = None,
    registry_rows: list[dict[str, str]] | None = None,
    tree_spec: list[dict[str, Any]] | None = None,
) -> str:
    """Собрать заполненный HTML-паспорт из модели и экстракции.

    ``llm_values`` — плоский dict значений полей от агента (ключи вида
    ``{node}:{field}:value``, ``{node}:name``, ``analysis-scope`` и т.д.).
    Если передан, значения LLM перекрывают детерминированные (только непустые).

    ``registry_rows`` — строки реестра узлов от агента. Если не передан,
    реестр строится детерминированно из известных узлов.

    ``tree_spec`` — спецификация дерева узлов от агента (произвольное число
    узлов каждого типа). Если передана, рендерер клонирует
    ``<template>``-заготовки и перестраивает дерево.
    """
    template = _strip_removed_sections(_TEMPLATE_PATH.read_text(encoding="utf-8"))
    values = _build_fill_values(model, plan_input, repo_name, extraction, commit, branch, model_name)
    filled_by_agent = bool(llm_values)
    if llm_values:
        for key, val in llm_values.items():
            if val:
                values[key] = val
    if tree_spec:
        template = _rebuild_tree(template, tree_spec)
    if registry_rows is None:
        registry_rows = _build_registry(values)
    schema = build_passport_map(model)
    # Статус узла остаётся в реестре и карточке. На самой схеме он не
    # показывается: там отдельным `!` отмечаются только разрывы сценария.
    status_by_id = {n["id"]: n.get("implementation_label", "") for n in schema.get("nodes", [])}
    template = _fill_registry(template, registry_rows, status_by_id)
    template = _fill_template(template, values)
    # Библиотека заготовок нужна только клонированию узлов; в выпуске её нет:
    # заготовка с унаследованным id и названием читается как пустой узел.
    template = _strip_templates(template)
    _assert_no_placeholders(template)
    template = _set_status_badge(template, filled_by_agent)
    template = _set_title(template, _initiative_title(plan_input, repo_name))
    summary = schema.get("summary") or {}
    schema["meta"] = {
        "filling": STATUS_BADGE_AGENT if filled_by_agent else STATUS_BADGE_FALLBACK,
        "filled_by_agent": filled_by_agent,
        "scope": values.get("analysis-scope", ""),
        "audience": audience_of(plan_input.context),
        "boundary": values.get("decision-boundary", ""),
        "date": values.get("analysis-date", ""),
        "analysis": _analysis_scope_lines(extraction, commit, summary),
        "planned_fields": {k: sorted(v) for k, v in PLANNED_FIELDS.items()},
        # Потребность и ограничения исполнения — уровни графа, их формулирует
        # паспортный агент (submit_need / submit_guardrail).
        "needs": list((model.passport_data or {}).get("needs") or []),
        "guardrails": list((model.passport_data or {}).get("guardrails") or []),
    }
    template = _finalize_html(template, schema)
    return template


def _initiative_title(plan_input: PlanInput, repo_name: str) -> str:
    """Название инициативы/проекта для шапки, отдельно от клиентского пути."""
    context = plan_input.context
    return str(context.get("project_name") or context.get("initiative_name") or repo_name or "Инициатива").strip()


_TEMPLATE_BLOCK_RE = re.compile(r'<template id="tpl-\w+">.*?</template>\s*', re.DOTALL)
_PLACEHOLDER_ID_RE = re.compile(r'id="(?:journey|process|bbb|operation)-N"')


def _strip_templates(template: str) -> str:
    """Убрать библиотеку заготовок. Сначала — комментарии: в них шаблон
    упоминает «<template id="tpl-journey">» текстом, и регулярка по тегам
    иначе съедает дерево до первого настоящего `</template>`."""
    return _TEMPLATE_BLOCK_RE.sub("", _COMMENT_RE.sub("", template))


def _assert_no_placeholders(template: str) -> None:
    """Ни один видимый узел не несёт `-N` в id — иначе в паспорт уехала заготовка."""
    stripped = _COMMENT_RE.sub("", template)
    if _PLACEHOLDER_ID_RE.search(stripped):
        raise PkoError(
            "в паспорт попала заготовка узла с id «-N»",
            "проверьте вставку узлов: заготовки клонируются только с реальным номером",
        )


def _analysis_scope_lines(extraction: Extraction, commit: str, summary: dict[str, Any]) -> list[str]:
    """Область анализа для шапки: что загружено и чего среди материалов нет.
    Явное «не проверялось» лучше молчания."""
    paths = {str(f.path) for f in getattr(extraction, "facts", []) or [] if getattr(f, "path", "")}
    lines = [f"файлов с фактами: {len(paths)}" if paths else "фактов из кода не извлечено"]
    if not commit:
        lines.append("git-история отсутствует: источник — архив или отдельные файлы, версия кода не привязана")
    total, unchecked = summary.get("handoffs_total") or 0, summary.get("wiring_unchecked") or 0
    if total and unchecked:
        lines.append(f"подключение в конфигурации сборки не проверено на {unchecked} из {total} передач")
    elif not total:
        lines.append("передачи между шагами не прослежены: целевых сценариев нет")
    return lines


_TITLE_RE = re.compile(r"(<h1\b[^>]*>)(.*?)(</h1>)", re.DOTALL)


def _set_title(html: str, name: str) -> str:
    """Заголовок страницы — «Паспорт инициативы «Название»».

    Название — из образа результата; в `<title>` оно же, чтобы вкладка и
    файл в письме опознавались без открытия.
    """
    title = f"Паспорт инициативы «{_html.escape(name)}»"
    html = _TITLE_RE.sub(lambda m: m.group(1) + title + m.group(3), html, count=1)
    return html.replace(
        "<title>Единый паспорт клиентского пути · ДПСС</title>",
        f"<title>{title}</title>", 1,
    )


def render_passport_from_model(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str = "",
) -> str:
    """Паспорт по итоговой модели прогона — общая точка для CLI и веба.

    Если паспортная сессия приняла хотя бы один узел (`model.passport_data`),
    дерево, реестр и поля берутся из него; иначе рендерер заполняет паспорт
    детерминированно из модели и экстракции и ставит бейдж «агент паспорт
    не заполнил».
    """
    data = model.passport_data
    return render_client_journey_passport(
        model, plan_input, repo_name, extraction,
        commit=commit, branch=branch, model_name=model_name,
        llm_values=flatten_passport_data(data) if data else None,
        registry_rows=passport_registry_rows(data) if data else None,
        tree_spec=passport_tree_spec(data) if data else None,
    )


# Бейдж в шапке. Шаблон приходит с «ЗАГОТОВКА · ПОЛЯ НЕ ЗАПОЛНЕНЫ», и
# заполненный паспорт уходил читателю с этой подписью. Статус переключает
# код: он один знает, кто заполнял поля.
STATUS_BADGE_TEMPLATE = "ЗАГОТОВКА · ПОЛЯ НЕ ЗАПОЛНЕНЫ"
STATUS_BADGE_AGENT = "ЗАПОЛНЕНО ПО КОДУ · БИЗНЕС-НАМЕРЕНИЕ ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ ВЛАДЕЛЬЦА"
STATUS_BADGE_FALLBACK = "ЗАПОЛНЕНО ДЕТЕРМИНИРОВАННО · АГЕНТ ПАСПОРТ НЕ ЗАПОЛНИЛ"


def _set_status_badge(html: str, filled_by_agent: bool) -> str:
    badge = STATUS_BADGE_AGENT if filled_by_agent else STATUS_BADGE_FALLBACK
    return html.replace(STATUS_BADGE_TEMPLATE, badge, 1)


# --- разделы шаблона, которых в паспорте нет -----------------------------------

# Контейнеры и заготовки потребности клиента и ограничения исполнения. Шаблон
# остаётся прежним (это стандарт заказчика), а из выпускаемого файла эти
# разделы вырезаются вместе с образцами need-1 и guardrail-1 внутри.
_REMOVED_CONTAINERS = ("related-needs", "related-guardrails")
_REMOVED_TEMPLATES = ("tpl-need", "tpl-guardrail")
# Разделы шаблона, которые вырезаются целиком по заголовку.
_REMOVED_SECTION_TITLES = ("Основание паспорта",)


def _strip_removed_sections(template: str) -> str:
    for container_id in _REMOVED_CONTAINERS:
        template = _remove_div_by_id(template, container_id)
    for tpl_id in _REMOVED_TEMPLATES:
        template = re.sub(
            rf'<template id="{tpl_id}">.*?</template>\s*', '', template, count=1, flags=re.DOTALL,
        )
    for title in _REMOVED_SECTION_TITLES:
        template = re.sub(
            rf'<section\b[^>]*>\s*<h2\b[^>]*>{re.escape(title)}</h2>.*?</section>\s*',
            '', template, count=1, flags=re.DOTALL,
        )
    return template


def _remove_div_by_id(template: str, element_id: str) -> str:
    """Убрать `<div id="…">…</div>` целиком, с учётом вложенных div."""
    m = re.search(rf'<div\b[^>]*id="{re.escape(element_id)}"[^>]*>', template)
    if not m:
        return template
    end = _closing_div_end(template, m.end())
    if end is None:
        return template
    return template[:m.start()] + template[end:]


def _closing_div_end(template: str, pos: int) -> int | None:
    """Позиция сразу после закрывающего `</div>` контейнера, открытого до `pos`."""
    depth = 1
    while depth > 0 and pos < len(template):
        open_m = re.search(r"<div\b", template[pos:])
        close_m = re.search(r"</div>", template[pos:])
        if close_m is None:
            return None
        if open_m and open_m.start() < close_m.start():
            depth += 1
            pos += open_m.end()
        else:
            depth -= 1
            pos += close_m.end()
            if depth == 0:
                return pos
    return None


# --- динамические узлы из ответа агента ---------------------------------------
#
# Агент может вернуть дерево с произвольным числом узлов каждого типа.
# Шаблон v3 содержит образцы (journey-1, process-1, bbb-1, ...) и
# <template>-заготовки для клонирования. Рендерер:
#   1. Находит узлы, которых ещё нет в HTML (по id).
#   2. Клонирует <template> нужного типа, заменяет -N на реальный номер.
#   3. Вставляет клон в data-children контейнер родителя.

_TEMPLATE_RE = re.compile(
    r'<template id="tpl-(\w+)">(.*?)</template>', re.DOTALL,
)

# HTML-комментарии: в шаблоне v3 внутри комментариев встречаются тексты
# вида «<template id="tpl-journey">» — они не теги, а подсказки агенту.
# Без удаления комментариев regex выше ловит их и ест половину файла.
_COMMENT_RE = re.compile(r'<!--.*?-->', re.DOTALL)


def _strip_comments(html: str) -> str:
    """Убрать HTML-комментарии, чтобы regex по тегам не матчил текст в них."""
    return _COMMENT_RE.sub("", html)


def _extract_templates(template: str) -> dict[str, str]:
    """Извлечь HTML-заготовки узлов из <template> элементов."""
    clean = _strip_comments(template)
    out: dict[str, str] = {}
    for m in _TEMPLATE_RE.finditer(clean):
        out[m.group(1)] = m.group(2)
    return out


def _clone_node(template_html: str, node_id: str) -> str:
    """Клонировать заготовку узла, заменив ``N`` в id на реальный номер."""
    number = node_id.rsplit("-", 1)[-1]
    return template_html.replace("-N", f"-{number}")


def _existing_node_ids(template: str) -> set[str]:
    """Найти id всех узлов, уже присутствующих в HTML (вне <template>)."""
    clean = _strip_comments(template)
    stripped = _TEMPLATE_RE.sub("", clean)
    return set(re.findall(
        r'id="((?:journey|process|bbb|operation)-\d+)"',
        stripped,
    ))


def _insert_extra_nodes(
    template: str,
    tree_spec: list[dict[str, Any]],
    registry_rows: list[dict[str, str]] | None,
) -> str:
    """Добавить недостающие узлы в HTML, клонируя <template>-заготовки.

    Работает с шаблоном v3, где нет ``id="tree"`` контейнера: узлы лежат
    напрямую в ``<section>``, а дочерние — в ``data-children`` контейнерах
    внутри родительского узла.
    """
    templates = _extract_templates(template)
    if not templates:
        return template

    existing = _existing_node_ids(template)

    # Собираем все id узлов из tree_spec и registry.
    all_nodes = _collect_all_node_ids(tree_spec, registry_rows)

    # Узлы, которые нужно добавить.
    missing = [nid for nid in all_nodes if nid not in existing]
    if not missing:
        return template

    # Для каждого недостающего узла: клонируем template и вставляем
    # в data-children контейнер родителя.
    for node_id in missing:
        node_type = _node_type(node_id)
        tpl = templates.get(node_type)
        if not tpl:
            continue
        clone = _clone_node(tpl, node_id)

        # Ищем родителя по registry. В столбце «Родитель» могут стоять
        # несколько узлов через запятую: карточка общего узла лежит под
        # первым, остальные родители — связи на схеме.
        parent_id = None
        for row in (registry_rows or []):
            if row.get("id") == node_id:
                parent_id = _first_parent(row.get("parent", ""))
                break

        if parent_id and parent_id != "—":
            # Вставляем в data-children="[type]" контейнер внутри родителя.
            template = _insert_into_parent(template, parent_id, node_type, clone)
        else:
            # Journey без родителя — вставляем после последнего journey.
            template = _insert_after_last_node(template, node_type, clone)

    return template


def _rebuild_tree(template: str, tree_spec: list[dict[str, Any]]) -> str:
    """Пересобрать дерево целиком из донорских карточек шаблона.

    Раньше рендерер только добавлял отсутствующие id. Четыре образцовые
    карточки ``journey-1/process-1/bbb-1/operation-1`` уже были в HTML и
    поэтому сохраняли структуру шаблона, даже если агент поместил ``bbb-1``
    до развилки прямо под путём. Реестр показывал правильного родителя, а
    карточка физически оставалась внутри process-1. Полная пересборка делает
    дерево единственным источником расположения и заодно исключает такие
    расхождения для любых id образца.
    """
    templates = _extract_templates(template)
    if not templates:
        return template

    def build(spec: dict[str, Any]) -> str:
        node_id = str(spec.get("id") or "")
        ntype = _node_type(node_id)
        donor = templates.get(ntype)
        if not node_id or not donor:
            return ""
        card = _clone_node(donor, node_id)
        for child in spec.get("children") or []:
            if not isinstance(child, dict):
                continue
            child_html = build(child)
            if child_html:
                card = _insert_into_parent(
                    card, node_id, _node_type(str(child.get("id") or "")), child_html,
                )
        return card

    roots = [build(root) for root in tree_spec if isinstance(root, dict)]
    roots = [root for root in roots if root]
    if not roots:
        return template

    # В шаблоне один образцовый корень. Находим весь его сбалансированный
    # div, включая статических потомков, и заменяем собранными корнями.
    root_m = re.search(
        r'<div\b[^>]*class="[^"]*\bnode\s+journey\b[^"]*"[^>]*id="journey-1"[^>]*>',
        template,
    )
    if root_m is None:
        return template
    root_end = _matching_div_end(template, root_m.end())
    if root_end is None:
        return template
    return template[:root_m.start()] + "\n".join(roots) + template[root_end:]


def _matching_div_end(source: str, open_end: int) -> int | None:
    """Позиция сразу после ``</div>`` для уже найденного открывающего div."""
    depth = 1
    pos = open_end
    tag_re = re.compile(r"<div\b|</div>")
    while depth:
        match = tag_re.search(source, pos)
        if match is None:
            return None
        if match.group(0).startswith("</"):
            depth -= 1
        else:
            depth += 1
        pos = match.end()
    return pos


def _insert_into_parent(
    template: str, parent_id: str, child_type: str, clone_html: str,
) -> str:
    """Вставить клон узла в data-children контейнер внутри родительского узла.

    Ищем ``<div ... data-children="child_type" ...>...</div>`` внутри HTML
    родительского узла (по id) и вставляем клон перед закрывающим ``</div>``.
    """
    # Находим позицию родительского узла по id.
    parent_re = re.compile(rf'id="{re.escape(parent_id)}"')
    parent_m = parent_re.search(template)
    if not parent_m:
        return template

    # После родительского id ищем data-children="child_type" контейнер.
    search_start = parent_m.end()
    container_re = re.compile(
        rf'(<div\b[^>]*data-children="{child_type}"[^>]*>)',
    )
    if child_type == "bbb" and _node_type(parent_id) == "journey":
        # Узел до развилки живёт под клиентским путём, а у пути в шаблоне
        # только контейнер процессов: свой контейнер BBB добавляется перед
        # ним. Искать первый попавшийся data-children="bbb" нельзя — он
        # окажется внутри первого процесса.
        process_m = re.compile(r'<div\b[^>]*data-children="process"[^>]*>').search(template, search_start)
        if not process_m:
            return template
        holder_re = re.compile(r'(<div\b[^>]*data-children="bbb" data-before-fork="true"[^>]*>)')
        container_m = holder_re.search(template, search_start, process_m.start())
        if not container_m:
            holder = ('<div class="children" data-children="bbb" data-before-fork="true" '
                      'style="margin:24px 0 0 12px;padding-left:24px;border-left:1px dashed var(--g3)"></div>\n')
            template = template[:process_m.start()] + holder + template[process_m.start():]
            container_m = holder_re.search(template, search_start)
    else:
        container_m = container_re.search(template, search_start)
    if not container_m:
        return template

    # От начала контейнера ищем его закрывающий </div> (с учётом вложенности).
    pos = container_m.end()
    depth = 1
    while depth > 0 and pos < len(template):
        open_m = re.search(r"<div\b", template[pos:])
        close_m = re.search(r"</div>", template[pos:])
        if close_m is None:
            break
        if open_m and open_m.start() < close_m.start():
            depth += 1
            pos += open_m.end()
        else:
            depth -= 1
            if depth == 0:
                # Это закрывающий тег контейнера — вставляем перед ним.
                insert_pos = pos + close_m.start()
                return (
                    template[:insert_pos]
                    + "\n" + clone_html + "\n"
                    + template[insert_pos:]
                )
            pos += close_m.end()

    return template


def _first_parent(raw: str) -> str:
    """Первый родитель из столбца «Родитель» реестра («process-1, process-2»)."""
    parts = [p.strip() for p in str(raw or "").replace(";", ",").replace("·", ",").split(",")]
    return next((p for p in parts if p), "")


def _insert_after_last_node(
    template: str, node_type: str, clone_html: str,
) -> str:
    """Вставить клон после последнего узла того же типа (fallback)."""
    # Ищем все id="type-N" вне <template>.
    stripped = _TEMPLATE_RE.sub("", template)
    matches = list(re.finditer(
        rf'id="({node_type}-\d+)"', stripped,
    ))
    if not matches:
        return template
    # Вставляем после конца последнего узла — после следующего </div>
    # на том же уровне. Простой подход: вставляем перед началом следующего
    # блока (следующий узел или конец section).
    last_pos = matches[-1].end()
    # Ищем следующий </div> на нужной глубине — грубо, ищем
    # "<!--#NODE:" или "<div id=\"related-" после последнего узла.
    after = re.search(
        r'(<!--#NODE:|</section)',
        template[last_pos:],
    )
    if after:
        insert_pos = last_pos + after.start()
        return (
            template[:insert_pos]
            + "\n" + clone_html + "\n"
            + template[insert_pos:]
        )
    return template


def _collect_all_node_ids(
    tree_spec: list[dict[str, Any]] | None,
    registry_rows: list[dict[str, str]] | None,
) -> list[str]:
    """Собрать все id узлов из tree_spec и/или registry, в порядке появления."""
    seen: list[str] = []
    seen_set: set[str] = set()

    def visit(node: dict[str, Any]) -> None:
        nid = node.get("id", "")
        if nid and nid not in seen_set:
            seen.append(nid)
            seen_set.add(nid)
        for child in (node.get("children") or []):
            if isinstance(child, dict):
                visit(child)

    if tree_spec:
        for node in tree_spec:
            if isinstance(node, dict):
                visit(node)

    if registry_rows:
        for row in registry_rows:
            nid = row.get("id", "")
            if nid and nid not in seen_set:
                seen.append(nid)
                seen_set.add(nid)

    return seen

    return html


# --- данные ------------------------------------------------------------------

def _build_fill_values(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str,
) -> dict[str, str]:
    """Сопоставить поля шаблона с данными модели.

    Ключи — составные: `{node_id}:{fill_type}` или `{node_id}:{field_id}:{fill_type}`.
    `fill_type` — value | source | name | object-id | object-version.
    """
    ctx = plan_input.context
    # Название клиентского пути — строго из образа результата инициативы.
    # Имя проекта и репозитория — только запасные варианты, когда в тексте
    # пути названия нет вовсе.
    journey_name = journey_name_of(ctx, repo_name)
    project_name = ctx.get("project_name") or journey_name
    generated = time.strftime("%Y-%m-%d %H:%M")
    v: dict[str, str] = {}

    # --- мета (в шапку: раздела «Основание паспорта» в выпуске нет) ---
    v["analysis-scope"] = f"{repo_name} · коммит {commit[:8] if commit else '—'} · {project_name}"
    v["decision-boundary"] = "END_TO_END_PROCESS"
    v["analysis-date"] = generated

    # --- journey-1 (Клиентский путь) ---
    v["journey-1:name"] = journey_name
    v["journey-1:object-id"] = _EMPTY
    v["journey-1:object-version"] = _EMPTY
    v["journey-1:4.2.1:value"] = ctx.get("before") or _EMPTY
    v["journey-1:4.2.1:source"] = "образ результата инициативы"
    v["journey-1:4.2.2:value"] = ctx.get("client_path_name") or _EMPTY
    v["journey-1:4.2.2:source"] = "образ результата инициативы"
    v["journey-1:4.2.3:value"] = _NEEDS_OWNER
    v["journey-1:4.2.3:source"] = _EMPTY
    v["journey-1:4.2.4:value"] = (
        f"До: {ctx.get('before', _EMPTY)}. После: {ctx.get('after', _EMPTY)}."
    )
    v["journey-1:4.2.4:source"] = "образ результата инициативы"
    v["journey-1:4.2.5:value"] = _summary_outcomes(model)
    v["journey-1:4.2.5:source"] = "оценка агента по коду репозитория"
    v["journey-1:4.2.6:value"] = _stages_text(plan_input)
    v["journey-1:4.2.6:source"] = "образ результата инициативы"
    v["journey-1:4.2.7:value"] = _interaction_moments(model)
    v["journey-1:4.2.7:source"] = "оценка агента по коду репозитория"
    v["journey-1:4.2.8:value"] = _EMPTY
    v["journey-1:4.2.8:source"] = _EMPTY

    # --- process-1 (Автономный процесс) ---
    v["process-1:name"] = project_name
    v["process-1:object-id"] = _EMPTY
    v["process-1:object-version"] = _EMPTY
    v["process-1:4.3.1:value"] = f"Собирает и исполняет решение для клиентского пути «{journey_name}»."
    v["process-1:4.3.1:source"] = "образ результата инициативы"
    v["process-1:4.3.2:value"] = f"Клиентский путь: {journey_name}"
    v["process-1:4.3.2:source"] = "образ результата инициативы"
    v["process-1:4.3.3:value"] = _NEEDS_OWNER
    v["process-1:4.3.3:source"] = _EMPTY
    v["process-1:4.3.4:value"] = _entry_conditions(extraction)
    v["process-1:4.3.4:source"] = _extraction_source(extraction, "ROUTE")
    v["process-1:4.3.5:value"] = _routing_logic(model, plan_input)
    v["process-1:4.3.5:source"] = _extraction_source(extraction, "GRAPH_NODE")
    v["process-1:4.3.6:value"] = _bbbs_and_modes(extraction)
    v["process-1:4.3.6:source"] = _extraction_source(extraction, "TOOL")
    v["process-1:4.3.7:value"] = _fallback(model, extraction)
    v["process-1:4.3.7:source"] = "оценка агента по коду репозитория"
    v["process-1:4.3.8:value"] = _EMPTY
    v["process-1:4.3.8:source"] = _EMPTY
    v["process-1:4.3.9:value"] = f"Коммит: {commit or '—'}"
    v["process-1:4.3.9:source"] = "git-коммит"

    # --- bbb-1 (первый бизнес-блок) ---
    _fill_bbb(v, "bbb-1", extraction, model, 0)
    # --- bbb-2 ---
    _fill_bbb(v, "bbb-2", extraction, model, 1)
    # --- bbb-3 ---
    _fill_bbb(v, "bbb-3", extraction, model, 2)

    # --- operation-1, operation-2 ---
    _fill_operation(v, "operation-1", extraction, 0)
    _fill_operation(v, "operation-2", extraction, 1)

    return v


def _fill_bbb(v: dict, node_id: str, extraction: Extraction, model: ProgressModel, index: int) -> None:
    tools = extraction.by_kind("TOOL") + extraction.by_kind("GRAPH_NODE")
    fact = tools[index] if index < len(tools) else None
    if fact:
        v[f"{node_id}:name"] = fact.key
        v[f"{node_id}:object-id"] = _EMPTY
        v[f"{node_id}:object-version"] = _EMPTY
        v[f"{node_id}:4.4.1:value"] = str(fact.value or _EMPTY)[:200] if isinstance(fact.value, (str, dict)) else _EMPTY
        v[f"{node_id}:4.4.1:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.2:value"] = _EMPTY
        v[f"{node_id}:4.4.2:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.3:value"] = _NEEDS_OWNER
        v[f"{node_id}:4.4.3:source"] = _EMPTY
        v[f"{node_id}:4.4.4:value"] = _EMPTY
        v[f"{node_id}:4.4.4:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.5:value"] = _EMPTY
        v[f"{node_id}:4.4.5:source"] = _EMPTY
        v[f"{node_id}:4.4.6:value"] = _EMPTY
        v[f"{node_id}:4.4.6:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.7:value"] = _EMPTY
        v[f"{node_id}:4.4.7:source"] = _EMPTY
    else:
        for fill in ("name", "object-id", "object-version"):
            v[f"{node_id}:{fill}"] = _EMPTY
        for field in ("4.4.1", "4.4.2", "4.4.3", "4.4.4", "4.4.5", "4.4.6", "4.4.7"):
            v[f"{node_id}:{field}:value"] = _EMPTY
            v[f"{node_id}:{field}:source"] = _EMPTY


def _fill_operation(v: dict, node_id: str, extraction: Extraction, index: int) -> None:
    funcs = [f for f in extraction.by_kind("FUNCTION") if f.value and isinstance(f.value, dict) and f.value.get("doc")]
    fact = funcs[index] if index < len(funcs) else None
    if fact:
        doc = str(fact.value.get("doc") or _EMPTY)[:200]
        v[f"{node_id}:name"] = fact.key
        v[f"{node_id}:object-id"] = _EMPTY
        v[f"{node_id}:object-version"] = _EMPTY
        v[f"{node_id}:4.5.1:value"] = doc
        v[f"{node_id}:4.5.1:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.2:value"] = _EMPTY
        v[f"{node_id}:4.5.2:source"] = _EMPTY
        v[f"{node_id}:4.5.3:value"] = _NEEDS_OWNER
        v[f"{node_id}:4.5.3:source"] = _EMPTY
        v[f"{node_id}:4.5.4:value"] = _EMPTY
        v[f"{node_id}:4.5.4:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.5:value"] = _EMPTY
        v[f"{node_id}:4.5.5:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.6:value"] = _EMPTY
        v[f"{node_id}:4.5.6:source"] = _EMPTY
    else:
        for fill in ("name", "object-id", "object-version"):
            v[f"{node_id}:{fill}"] = _EMPTY
        for field in ("4.5.1", "4.5.2", "4.5.3", "4.5.4", "4.5.5", "4.5.6"):
            v[f"{node_id}:{field}:value"] = _EMPTY
            v[f"{node_id}:{field}:source"] = _EMPTY


# --- вспомогательные ---------------------------------------------------------

def _summary_outcomes(model: ProgressModel) -> str:
    if not model.verdicts:
        return _EMPTY
    done = sum(1 for v in model.verdicts for c in v.criteria if c.applicable and c.status == "done")
    total = sum(1 for v in model.verdicts for c in v.criteria if c.applicable)
    if done == total:
        return f"Все {total} пунктов реализованы — путь завершается успешно."
    if done > 0:
        return f"Из {total} пунктов полностью работают {done} — результат достигается частично."
    return f"Из {total} пунктов ни один не работает полностью — результат не подтверждён."


def _stages_text(plan_input: PlanInput) -> str:
    if not plan_input.stages:
        return _EMPTY
    return "; ".join(f"{i}. {s}" for i, s in enumerate(plan_input.stages, 1))


def _interaction_moments(model: ProgressModel) -> str:
    moments: list[str] = []
    for v in model.verdicts:
        for c in v.criteria:
            if c.applicable and c.how_text:
                moments.append(c.how_text[:120])
    if not moments:
        return _EMPTY
    return "; ".join(moments[:5])


def _entry_conditions(extraction: Extraction) -> str:
    routes = extraction.by_kind("ROUTE")
    if not routes:
        return _EMPTY
    return "Точка входа: " + ", ".join(f.key for f in routes[:3])


def _routing_logic(model: ProgressModel, plan_input: PlanInput) -> str:
    parts: list[str] = []
    if plan_input.stages:
        parts.append("Этапы: " + " → ".join(plan_input.stages))
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        done = sum(1 for c in v.criteria if c.applicable and c.status == "done")
        total = sum(1 for c in v.criteria if c.applicable)
        parts.append(f"{item.title}: {done}/{total}")
    return "; ".join(parts[:5]) or _EMPTY


def _bbbs_and_modes(extraction: Extraction) -> str:
    tools = extraction.by_kind("TOOL")
    if not tools:
        return _EMPTY
    return ", ".join(f.key for f in tools[:5])


def _fallback(model: ProgressModel, extraction: Extraction) -> str:
    for v in model.verdicts:
        for c in v.criteria:
            if c.applicable and c.status in ("partial", "blocked"):
                return "Обнаружены нереализованные пункты — требуется ручная проверка"
    return _EMPTY


def _extraction_source(extraction: Extraction, kind: str) -> str:
    facts = extraction.by_kind(kind)
    if not facts:
        return _EMPTY
    f = facts[0]
    return f"{f.path}:{f.line}" if f.line else f.path


# --- реестр узлов ------------------------------------------------------------

_NODE_META = [
    ("journey-1", "Клиентский путь", "—"),
    ("process-1", "Автономный процесс", "journey-1"),
    ("bbb-1", "BBB", "process-1"),
    ("operation-1", "Атомарная операция", "bbb-1"),
]


def _build_registry(values: dict[str, str]) -> list[dict[str, str]]:
    """Построить реестр узлов из заполненных значений (fallback без LLM)."""
    rows: list[dict[str, str]] = []
    for node_id, type_label, parent in _NODE_META:
        name = values.get(f"{node_id}:name", "")
        rows.append({
            "id": node_id,
            "type": type_label,
            "name": name,
            "parent": parent,
            "basis": "обнаружен в коде репозитория",
        })
    return rows


_REGISTRY_TBODY_RE = re.compile(
    r"(<table[^>]*class=\"registry\"[^>]*>.*?<tbody>)(.*?)(</tbody>)",
    re.DOTALL,
)


_REGISTRY_STATUS_TH = (
    '<th style="width:14%;text-align:left;padding:0 16px 10px;font-size:17px;font-weight:700;'
    'color:#000;vertical-align:bottom;border-bottom:1px solid #000">Статус</th>'
)


def _fill_registry(template: str, rows: list[dict[str, str]],
                   status_by_id: dict[str, str] | None = None) -> str:
    """Заполнить таблицу реестра узлов строками.

    Заменяет содержимое ``<tbody>`` шаблона на строки из ``rows``.
    Сохраняет структуру ``<td data-col="...">`` для CSS. Столбец «Статус»
    (реализован / с ограничениями / частично / не реализован / недостаточно
    данных) добавляется кодом: в шаблоне его нет, а без него планируемый
    процесс стоит в одном ряду с работающими и отличим только по прозе.
    """
    if not rows:
        return template
    status_by_id = status_by_id or {}

    def replace_tbody(m: re.Match) -> str:
        open_tag = m.group(1)
        close_tag = m.group(3)

        col_names = ["HTML-id", "Тип", "Название", "Родитель", "Статус", "Основание"]
        col_keys = ["id", "type", "name", "parent", "status", "basis"]

        new_rows: list[str] = []
        for row in rows:
            row = {**row, "status": status_by_id.get(str(row.get("id", "")), "") or "—"}
            cells = []
            for col_name, col_key in zip(col_names, col_keys):
                val = _html.escape(str(row.get(col_key, "")), quote=False)
                cells.append(f'<td data-col="{col_name}">{val}</td>')
            new_rows.append("<tr>" + "".join(cells) + "</tr>")

        return open_tag + "\n" + "\n".join(new_rows) + "\n" + close_tag

    template = _REGISTRY_TBODY_RE.sub(replace_tbody, template, count=1)
    # Заголовок столбца — перед «Основание существования узла».
    return re.sub(
        r'(<th\b[^>]*>Основание существования узла</th>)',
        _REGISTRY_STATUS_TH + r'\1', template, count=1,
    )


# --- HTML-рендерер -----------------------------------------------------------
#
# Шаблон v3 использует <div class="node [type]" id="[type]-N"> вместо <details>.
# Линейный проход: отслеживаем текущий узел (по id на div.node) и поле
# (data-field), пропускаем HTML-комментарии.
#
# fill types:
#   name, object-id, object-version → ключ {node}:{fill} (без поля)
#   value, source                   → ключ {node}:{field}:{fill}
#   analysis-scope, decision-boundary, analysis-date → ключ {fill} (вне узлов)

# Узел: id="(journey|process|bbb|operation)-N" на любом теге.
# Поле: data-field="X.Y.Z". Заполнение: data-fill="value|source|name|...".

_TOKEN_RE = re.compile(
    r'(<!--.*?-->)'                                                  # 1: comment (skip)
    r'|(id="((?:journey|process|bbb|operation)-\d+)")'                # 2,3: node id
    r'|(data-field="([^"]+)")'                                       # 4,5: data-field
    r'|(data-fill="([^"]+)"[^>]*>)([^<]*)(</(?:div|span)>)',        # 6,7,8,9: data-fill element
    re.DOTALL,
)

_NODE_FILLS = {"name", "object-id", "object-version"}
_FIELD_FILLS = {"value", "source"}
_NODE_ID_RE = re.compile(
    r"^(?:journey|process|bbb|operation)-\d+$"
)


def _fill_template(template: str, values: dict[str, str]) -> str:
    """Заполнить data-fill элементы значениями из dict.

    Линейный проход: отслеживаем текущий узел (по id) и поле (data-field),
    пропускаем комментарии. Каждый data-fill заполняется по ключу
    {node}:{field}:{fill} или {node}:{fill} или {fill}.

    Работает с шаблоном v3, где узлы — ``<div class="node" id="X">``, а не
    ``<details>``: нет стека open/close, текущий узел обновляется при
    обнаружении нового id узла.
    """
    parts: list[str] = []
    last_end = 0
    current_node: str | None = None
    current_field: str | None = None

    for m in _TOKEN_RE.finditer(template):
        parts.append(template[last_end:m.start()])
        last_end = m.end()

        if m.group(1) is not None:
            # HTML-комментарий — пропускаем как есть
            parts.append(m.group(0))
        elif m.group(3) is not None:
            # id="journey-1" / id="process-2" и т.д. — вход в узел.
            # В v3 узлы не вкладываются через details, а идут последовательно:
            # новый id узла означает, что предыдущий закончился.
            current_node = m.group(3)
            current_field = None
            parts.append(m.group(0))
        elif m.group(5) is not None:
            # data-field="X.Y.Z"
            current_field = m.group(5)
            parts.append(m.group(0))
        elif m.group(7) is not None:
            # data-fill="..." element
            fill_type = m.group(7)
            open_tag = m.group(6)
            content = m.group(8)
            close_tag = m.group(9)
            key = _make_key(current_node, current_field, fill_type)
            val = values.get(key, "") if key else ""
            if val:
                safe = _html.escape(val, quote=False)
                parts.append(open_tag + safe + close_tag)
            else:
                parts.append(m.group(0))

    parts.append(template[last_end:])
    return "".join(parts)


def _make_key(node: str | None, field: str | None, fill: str) -> str | None:
    """Собрать ключ для values dict по контексту узла и поля."""
    if fill in _NODE_FILLS:
        return f"{node}:{fill}" if node else None
    if fill in _FIELD_FILLS:
        return f"{node}:{field}:{fill}" if node and field else None
    return fill


# --- разбор passport_data от агента ------------------------------------------
#
# Агент-матчер вызывает инструмент `submit_passport` с JSON-объектом,
# содержащим значения полей паспорта. Эти функции преобразуют его в плоский
# dict для `_fill_template` и в строки реестра.

_FIELD_MAP = {
    "journey": ["4.2.1", "4.2.2", "4.2.3", "4.2.4", "4.2.5", "4.2.6", "4.2.7", "4.2.8"],
    "process": ["4.3.1", "4.3.2", "4.3.3", "4.3.4", "4.3.5", "4.3.6", "4.3.7", "4.3.8", "4.3.9"],
    "bbb": ["4.4.1", "4.4.2", "4.4.3", "4.4.4", "4.4.5", "4.4.6", "4.4.7"],
    "operation": ["4.5.1", "4.5.2", "4.5.3", "4.5.4", "4.5.5", "4.5.6"],
}

_SAMPLE_NODES = {
    "journey-1": "journey",
    "process-1": "process",
    "bbb-1": "bbb",
    "operation-1": "operation",
}

_NODE_TYPE_PREFIXES = ("journey", "process", "bbb", "operation")


def _node_type(node_id: str) -> str:
    """Тип узла по id: journey-1 → journey, bbb-3 → bbb."""
    for prefix in _NODE_TYPE_PREFIXES:
        if node_id.startswith(prefix + "-"):
            return prefix
    return ""


def flatten_passport_data(data: dict[str, Any] | None) -> dict[str, str]:
    """Преобразовать JSON-ответ агента (``submit_passport``) в плоский dict.

    Ключи совпадают со схемой ``_fill_template``:
    - ``analysis-scope``, ``decision-boundary``, ``analysis-date``
    - ``{node}:name``, ``{node}:object-id``, ``{node}:object-version``
    - ``{node}:{field}:value``, ``{node}:{field}:source``

    Обрабатывает произвольное число узлов — агент может вернуть
    journey-1, journey-2, bbb-1, bbb-2, bbb-3 и т.д.
    """
    if not data or not isinstance(data, dict):
        return {}

    v: dict[str, str] = {}
    v["analysis-scope"] = str(data.get("analysis-scope", ""))
    v["decision-boundary"] = str(data.get("decision-boundary", ""))
    v["analysis-date"] = str(data.get("analysis-date", ""))

    nodes = data.get("nodes", {})
    if not isinstance(nodes, dict):
        return v

    for node_id, node in nodes.items():
        if not isinstance(node, dict):
            continue
        node_type = _node_type(str(node_id))
        if not node_type:
            continue
        v[f"{node_id}:name"] = str(node.get("name", ""))
        v[f"{node_id}:object-id"] = str(node.get("object-id", ""))
        v[f"{node_id}:object-version"] = str(node.get("object-version", ""))
        fields = node.get("fields", {})
        if not isinstance(fields, dict):
            continue
        for field_id in _FIELD_MAP.get(node_type, []):
            field = fields.get(field_id, {})
            if not isinstance(field, dict):
                continue
            v[f"{node_id}:{field_id}:value"] = str(field.get("value", ""))
            v[f"{node_id}:{field_id}:source"] = str(field.get("source", ""))

    return v


def passport_tree_spec(data: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Извлечь спецификацию дерева узлов из ответа агента.

    Возвращает список корневых узлов (journey), каждый может содержать
    ``children`` (process → bbb → operation). Используется ``rebuild_tree``
    для клонирования ``<template>``-заготовок.
    """
    if not data or not isinstance(data, dict):
        return []
    tree = data.get("tree")
    if isinstance(tree, list):
        return tree
    # Если tree нет, строим из nodes по известным образцам.
    nodes = data.get("nodes", {})
    if not isinstance(nodes, dict):
        return []
    tree_spec = []
    for node_id, node in nodes.items():
        if not isinstance(node, dict):
            continue
        node_type = _node_type(str(node_id))
        if node_type == "journey":
            tree_spec.append({"id": str(node_id), "type": "journey", "children": []})
    # Упрощённая сборка: процессы под первый journey, BBB под первый процесс.
    journeys = [n for n in tree_spec if n["type"] == "journey"]
    if not journeys:
        return []
    journey = journeys[0]
    processes = []
    for node_id, node in nodes.items():
        if _node_type(str(node_id)) == "process":
            processes.append({"id": str(node_id), "type": "process", "children": []})
    journey["children"] = processes
    for proc in processes:
        bbbs = []
        for node_id, node in nodes.items():
            if _node_type(str(node_id)) == "bbb":
                bbbs.append({"id": str(node_id), "type": "bbb", "children": []})
        proc["children"] = bbbs
        for bbb in bbbs:
            ops = []
            for node_id, node in nodes.items():
                if _node_type(str(node_id)) == "operation":
                    ops.append({"id": str(node_id), "type": "operation"})
            bbb["children"] = ops
        break  # только под первый BBB
    return tree_spec


def passport_registry_rows(data: dict[str, Any] | None) -> list[dict[str, str]]:
    """Строки реестра узлов из ответа агента."""
    if not data or not isinstance(data, dict):
        return []
    rows = data.get("registry", [])
    if not isinstance(rows, list):
        return []
    out: list[dict[str, str]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        out.append({
            "id": str(row.get("id", "")),
            "type": str(row.get("type", "")),
            "name": str(row.get("name", "")),
            "parent": str(row.get("parent", "")),
            "basis": str(row.get("basis", "")),
        })
    return out


# --- финализация HTML: убираем зависимость от DCLogic/support.js -------------
#
# Шаблон v3 — это DCLogic-компонент: Mustache-плейсхолдеры `{{ ... }}`,
# `style-hover` (нестандартный атрибут), внешний `support.js` и класс
# `Component extends DCLogic`. Без движка всё ломается: кнопки не работают,
# узлы не раскрываются, анимация не применяется.
#
# `_finalize_html` делает шаблон самодостаточным:
#   1. Убирает `<script src="./support.js">` и DCLogic-скрипт.
#   2. Заменяет Mustache-плейсхолдеры на статические значения.
#   3. Убирает `data-anim` / `data-uneditable` / `style-hover`.
#   4. Конвертирует `style-hover` в CSS `:hover`.
#   5. Добавляет свой `<script>` для сворачивания/разворачивания узлов.

_MUSTACHE_RE = re.compile(r"\{\{[^}]+\}\}")

# Статические значения для Mustache-плейсхолдеров. Узлы раскрыты по умолчанию
# (кроме operation и guardrail — их много, и они длинные).
_MUSTACHE_VALUES: dict[str, str] = {
    "allLabel": "Свернуть все",
    "panelRows": "0fr",
    "iconOpacity": ".65",
    "grayVal": "1",
    "grayPct": "100%",
    "oJourney": "1fr", "rJourney": "180deg",
    "oProcess": "1fr", "rProcess": "180deg",
    "oBbb": "1fr", "rBbb": "180deg",
    "oOperation": "0fr", "rOperation": "0deg",
    "oGuardrail": "0fr", "rGuardrail": "0deg",
}
# Callback-плейсхолдеры (onClick/onInput) — заменяем на пустые вызовы.
_MUSTACE_CALLBACKS = {
    "tJourney", "tProcess", "tBbb", "tOperation", "tGuardrail",
    "toggleAll", "onGray", "hidePanel", "showPanel",
}

# Раскладка отчёта — граф объектов стандарта рядами по уровням: потребность →
# клиентский путь → автономный процесс (он же сценарий) → BBB → атомарная
# операция → ограничение исполнения. Связи — плавные кривые между рядами;
# BBB и операция могут стоять в нескольких процессах и блоках, и каждая
# такая связь рисуется отдельно. Клик по объекту подсвечивает весь его
# сценарий (объекты, привязанные к тем же целевым сценариям, их родителей,
# потребность и ограничения), остальное приглушается; «Открыть описание»
# под объектом показывает карточку из шаблона в выезжающей панели.
# Карточки узлов из шаблона остаются в DOM скрытым хранилищем — JS
# клонирует их в панель. Статусы доступны в карточках и реестре, а разрывы
# и дефекты берутся из схемы, которую посчитал код.
_INLINE_CSS = """<style data-passport-fix>
:root{
--dpss-font:'SB Sans Display',sans-serif;
--dpss-surface:#FFF;--dpss-canvas:#F6FAF8;--dpss-text:#000;
--dpss-accent:#C17DF7;--dpss-accent-text:#8B3FD9;--dpss-danger:#EB3468;--dpss-warning:#FFC000;
--g1:#5A6D7C;--g2:#92A2B0;--g3:#B7C2CB;--g4:#D0D7DD;--g5:#E9ECEF;
--ll:#F3E5FD;--ly:#FFF2CC;--lr:#FBD6E1;--lt:#CFF5F3;
--dpss-control-radius:8px;--dpss-card-radius:12px;
}
*{box-sizing:border-box}
html,body{height:100%;margin:0;overflow:hidden;font-family:var(--dpss-font);color:var(--dpss-text);background:var(--dpss-surface)}
button,a,summary{-webkit-tap-highlight-color:transparent}
button{font:inherit;cursor:pointer}
button:disabled{cursor:default;opacity:.45}
button:focus-visible,a:focus-visible,summary:focus-visible{outline:3px solid var(--dpss-accent-text);outline-offset:3px}
[data-uneditable],#pko-store,.pko-hidden{display:none!important}
.pko-page{max-width:none!important;padding:0!important;margin:0!important;height:100dvh;display:flex;flex-direction:column;font-size:14px}
.pko-head{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:12px 24px;background:var(--dpss-surface);border-bottom:1px solid var(--g4)}
.pko-head>div:first-child{min-width:0;flex:1}
.pko-head-actions{display:flex;align-items:center;gap:24px;flex:none}
.pko-head .eyebrow{font-size:12px;color:var(--g1);margin-bottom:4px}
.pko-preview-note{font-size:12px;color:var(--g1);line-height:1.45;margin-top:8px;max-width:820px}
.pko-head h1{font-size:22px;line-height:1.2;font-weight:700;letter-spacing:-.025em;margin:0;max-width:900px;overflow-wrap:anywhere}
.pko-legend{display:flex;flex-wrap:wrap;gap:16px;font-size:12px;color:var(--g1);margin-top:8px}
.pko-legend b{display:inline-block;width:18px;border-top:1.5px solid var(--g3);vertical-align:middle;margin-right:6px}
.pko-legend i{display:inline-block;width:7px;height:7px;margin-right:6px;border-radius:50%}
.pko-legend .pin{display:inline-block;width:15px;height:15px;border-radius:50%;background:var(--dpss-danger);color:var(--dpss-text);text-align:center;margin-right:5px;font-weight:bold}
.pko-metrics{display:flex;gap:20px;flex:none}
.pko-metric span{display:block;font-size:12px;color:var(--g1);margin-bottom:6px}
.pko-metric strong{font-size:20px;font-weight:600}.pko-metric .danger{color:var(--dpss-danger)}
.tool{border:1px solid var(--g3);border-radius:var(--dpss-control-radius);padding:8px 12px;background:var(--dpss-surface);color:var(--g1);white-space:nowrap}
.pko-body{position:relative;flex:1;min-height:0;display:flex}
.pko-viewport{position:relative;flex:1;min-width:0;overflow:hidden;background:var(--dpss-canvas);touch-action:none;cursor:default;user-select:none}
.pko-viewport.dragging{cursor:default}
.pko-viewport .pko-object,.pko-viewport .pko-action{cursor:default}
.pko-canvas{position:absolute;top:0;left:0;transform-origin:0 0;isolation:isolate}
.pko-links{position:absolute;top:0;left:0;overflow:visible;pointer-events:none;z-index:0}
.pko-links .link{fill:none;stroke:var(--g3);stroke-width:1.4;transition:opacity .2s}
.pko-links .link.dim{opacity:.12}.pko-links .link.selected{stroke:var(--dpss-accent);stroke-width:1.8}
.pko-object{position:absolute;width:224px;min-height:88px;padding:12px 16px;background:var(--dpss-surface);border:1px solid var(--g3);border-radius:var(--dpss-card-radius);text-align:left;color:var(--dpss-text);z-index:1;transition:opacity .2s}
.pko-object:hover{border-color:var(--dpss-accent);box-shadow:0 8px 20px -12px rgba(193,125,247,.6)}
.pko-object .kind{display:block;font-size:11px;color:var(--g1)}
.pko-object strong{display:block;font-size:15px;line-height:1.35;font-weight:600;margin:7px 0;overflow-wrap:anywhere}
.pko-object small{display:block;color:var(--g1);font-size:11px}
.pko-object .badges{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:4px}
.pko-object .st{display:inline-flex;max-width:100%;padding:4px 8px;border-radius:var(--dpss-control-radius);font-size:12px;line-height:1.3;color:var(--dpss-text);background:var(--g5)}
.pko-object .st.implemented{background:var(--lt)}
.pko-object .st.partial{background:var(--ly)}
.pko-object .st.not_implemented{background:var(--lr)}
.pko-object .risk{display:inline-flex;align-items:center;gap:4px;padding:3px 7px;border-radius:var(--dpss-control-radius);background:var(--ly);font-size:12px;line-height:1.3;color:var(--dpss-text)}
.pko-object .risk svg,.pko-legend .risk-icon svg{display:block;width:15px;height:15px;flex:none}
.pko-legend .risk-icon{display:inline-block;vertical-align:middle;margin-right:5px}
.pko-object.dim{opacity:.18}.pko-object.dim:hover{opacity:.8}
.pko-object.related{border-color:var(--dpss-accent)}.pko-object.selected{background:rgba(193,125,247,.2)}
.pko-object.selected:hover{border-color:var(--g3);box-shadow:none}
.pko-row-title{position:absolute;font-size:12px;line-height:1.5;width:125px;color:var(--g1);pointer-events:none}
.pko-row-title .count{display:block;font-size:18px;color:var(--g2);font-weight:400;margin-top:3px}
.pko-pin{position:absolute;z-index:3;border:2px solid var(--dpss-surface);background:var(--dpss-danger);color:var(--dpss-text);border-radius:50%;width:25px;height:25px;font-size:15px;font-weight:bold;padding:0}
.pko-pin.dim{opacity:.15}
.pko-action{position:absolute;z-index:4;width:224px;height:30px;font-size:12px;border:1px solid var(--dpss-accent);border-radius:var(--dpss-control-radius);background:var(--dpss-surface);color:var(--dpss-accent-text)}
.pko-zoom{position:absolute;left:16px;bottom:16px;display:flex;align-items:center;background:var(--dpss-surface);border:1px solid var(--g4);padding:4px;border-radius:15px;z-index:2;box-shadow:0 2px 8px rgba(28,43,64,.04)}
.pko-zoom button{display:grid;place-items:center;border:0;background:transparent;min-width:40px;height:42px;border-radius:10px;color:#183454;font-size:20px;line-height:1}
.pko-zoom button:hover{background:var(--ll)}
.pko-zoom .fit{margin-left:3px;border-left:1px solid var(--g4);border-radius:0 10px 10px 0;min-width:43px}
.pko-zoom .fit svg{width:19px;height:19px}
.pko-zoom .lvl{min-width:58px;font-size:13px;font-weight:600;text-align:center;color:#183454;font-variant-numeric:tabular-nums}
.pko-empty{position:absolute;left:100px;top:100px;line-height:1.7;color:var(--g1)}
.pko-drawer{position:absolute;right:0;top:0;bottom:0;width:480px;max-width:100%;z-index:5;background:var(--dpss-surface);border-left:1px solid var(--g3);display:none;flex-direction:column;overflow:hidden;box-shadow:none}
.pko-drawer.open{display:flex}
.pko-drawer-head{display:flex;align-items:center;justify-content:space-between;padding:8px 20px;border-bottom:1px solid var(--g4);font-size:12px;color:var(--g1)}
.pko-drawer-close{border:0;background:var(--dpss-surface);width:36px;height:36px;font-size:24px;color:var(--g1)}
.pko-drawer-body{flex:1;min-height:0;overflow:auto;padding:18px 24px 28px}
.pko-clean-card,.pko-simple{font-size:13px;line-height:1.48;overflow-wrap:anywhere;text-wrap:pretty}
.pko-card-heading .type,.pko-simple .type{font-size:12px;color:var(--g1)}
.pko-card-heading h2,.pko-simple h2{font-size:20px;line-height:1.2;font-weight:700;letter-spacing:-.025em;margin:5px 0 16px}
.pko-card-tabs{display:flex;gap:4px;padding:3px;background:var(--g5);border-radius:var(--dpss-control-radius);margin:0 0 16px}
.pko-card-tabs button{flex:1;border:0;border-radius:var(--dpss-control-radius);background:none;color:var(--g1);padding:8px 10px;min-height:42px;font-size:13px}
.pko-card-tabs button[aria-selected=true]{background:var(--dpss-surface);color:var(--dpss-accent-text);font-weight:600}
.pko-tab-panel[hidden]{display:none!important}
.pko-tab-panel>.pko-node-risks{margin:0;padding:0;border:0}
.pko-node-assessment{padding:12px;background:var(--g5);border-radius:var(--dpss-card-radius);margin-bottom:16px}
.pko-node-assessment .state{font-weight:600;font-size:14px}
.pko-node-assessment ul{padding-left:17px;margin:6px 0 0}
.pko-node-flags{font-size:12px;color:var(--g1);margin-bottom:7px;display:flex;gap:8px;flex-wrap:wrap}
.pko-field{margin:0 0 16px}
.pko-field h3,.lbl{font-size:13px;font-weight:600;margin:0 0 6px;color:var(--dpss-text)}
.pko-field p{margin:0;white-space:pre-line}
.pko-evidence{margin-top:6px;font-size:12px;line-height:1.5;color:var(--g1)}
.pko-evidence summary{cursor:pointer;width:fit-content;color:var(--dpss-accent-text)}
.pko-evidence>div{padding:10px 0;white-space:pre-line;overflow-wrap:anywhere}
.pko-links-list,.pko-node-relations,.pko-node-scenarios,.pko-node-defects,.pko-node-risks,.pko-node-risk-links{margin:16px 0 0;padding-top:12px;border-top:1px solid var(--g4)}
.pko-tab-panel>.pko-links-list:first-child,.pko-tab-panel>.pko-node-scenarios:first-child,.pko-tab-panel>.pko-node-relations:first-child,.pko-tab-panel>.pko-node-links:first-child,.pko-tab-panel>.pko-node-risk-links:first-child{margin-top:0;padding-top:0;border-top:0}
.pko-node-relations ul,.pko-node-scenarios ul,.pko-node-risks ul{padding:0;margin:0;list-style:none}
.pko-node-relations li{margin:0 0 10px}.pko-node-relations .kind{color:var(--g1);font-size:12px}
.pko-clean-card a,.pko-simple a{color:var(--dpss-accent-text);text-underline-offset:3px}
.pko-node-scenarios .st{display:block;color:var(--g1);font-size:12px}
.pko-risk-card{padding:12px 0;border-bottom:1px solid var(--g4)}
.pko-risk-card:last-child{border-bottom:0}
.pko-risk-card h3{margin:0 0 6px;font-size:15px;line-height:1.35;font-weight:600}
.pko-node-risks.multi .pko-risk-card{padding:0}
.pko-risk-disclosure>summary{display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:48px;padding:10px 0;cursor:pointer;list-style:none;font-size:15px;line-height:1.35;font-weight:600}
.pko-risk-disclosure>summary::-webkit-details-marker{display:none}
.pko-risk-disclosure>summary::after{content:'';width:8px;height:8px;border-right:1.5px solid var(--g1);border-bottom:1.5px solid var(--g1);transform:rotate(45deg);flex:none;margin-right:4px}
.pko-risk-disclosure[open]>summary::after{transform:rotate(225deg)}
.pko-risk-details{padding:0 0 12px}
.pko-risk-link-item{margin:12px 0}
.pko-risk-link-item h3{font-size:13px;line-height:1.4;margin:0 0 5px}
.pko-risk-link-item p{margin:4px 0}
.pko-risk-card p{margin:8px 0}
.pko-risk-card .meta{font-size:12px;color:var(--g1)}
.pko-risk-card .gap{background:var(--ly);padding:12px;border-radius:var(--dpss-card-radius);color:var(--dpss-text)}
.pko-risk-card .risk-label{display:block;font-size:13px;font-weight:600;margin-bottom:3px}
.pko-risk-actions{margin-top:12px}.pko-risk-actions>summary{cursor:pointer;color:var(--dpss-accent-text);font-size:13px}
@media(max-width:700px){.pko-head{padding:12px 16px;gap:12px;align-items:stretch;flex-direction:column}.pko-head h1{font-size:18px}.pko-head-actions{justify-content:space-between;gap:12px}.pko-metrics{gap:16px}.pko-metric span{margin-bottom:2px}.pko-metric strong{font-size:18px}.pko-drawer{width:100%}.pko-drawer-body{padding:16px 20px 24px}.pko-legend{gap:8px;font-size:11px}}
@media(prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
"""

_INLINE_JS = r"""<script data-passport-fix>
(function(){
  'use strict';
  var SCHEMA=__PKO_SCHEMA__; var meta=SCHEMA.meta||{};
  var TYPE_ORDER=['need','journey','process','bbb','operation','guardrail'];
  var TYPE_NAME={need:'Потребности',journey:'Клиентский путь',process:'Автономные процессы',bbb:'BBB',operation:'Атомарные операции',guardrail:'Ограничения исполнения'};
  var TYPE_LABEL={need:'Потребность клиента',journey:'Клиентский путь',process:'Автономный процесс',bbb:'BBB',operation:'Атомарная операция',guardrail:'Ограничение исполнения'};
  var COLORS={need:'var(--g1)',journey:'var(--g1)',process:'var(--g1)',bbb:'var(--g1)',operation:'var(--g1)',guardrail:'var(--g1)'};
  var HIER={addresses:'закрывается путём',contains:'включает процесс',uses:'использует BBB',implements:'исполняется операцией',guards:'ограничивает'};

  // --- 1. Данные: карточки шаблона (DOM) + схема (код) ---
  var store=document.createElement('div'); store.id='pko-store';
  var els={};
  Array.prototype.forEach.call(document.querySelectorAll('.node[id]'),function(el){els[el.id]=el;});
  var byId={}, objects=[];
  function addObject(o){if(byId[o.id]) return; byId[o.id]=o; objects.push(o);}
  (SCHEMA.nodes||[]).forEach(function(n){
    addObject({id:n.id,type:n.type,name:n.name||n.id,parents:(n.parents||[]).slice(),children:[],data:n,
      steps:n.steps||[],scen:{},status:n.implementation_status||'',statusLabel:n.implementation_label||''});
  });
  objects.forEach(function(o){o.parents=o.parents.filter(function(p){return byId[p]}); o.parents.forEach(function(p){byId[p].children.push(o.id)});});
  var journey=objects.filter(function(o){return o.type==='journey'})[0]||null;
  (meta.needs||[]).forEach(function(nd){addObject({id:nd.id,type:'need',name:nd.name,text:nd.purpose||nd.text||'',source:nd.source,parents:[],children:[],targets:nd.targets||[],data:{},steps:[],scen:{}});});
  (meta.guardrails||[]).forEach(function(g){addObject({id:g.id,type:'guardrail',name:g.name,text:g.invariant||g.text||'',condition:g.condition||'',effect:g.effect_label||g.effect||'',source:g.source,parents:[],children:[],targets:g.targets||[],data:{},steps:[],scen:{}});});
  // Иерархические рёбра: один ко многим — BBB в нескольких процессах, операция в нескольких BBB.
  var edges=[];
  objects.forEach(function(o){
    if(o.type==='need') o.targets.forEach(function(t){if(byId[t]) edges.push({id:'e'+edges.length,source:o.id,target:t,type:'addresses'})});
    else if(o.type==='guardrail') o.targets.forEach(function(t){if(byId[t]) edges.push({id:'e'+edges.length,source:o.id,target:t,type:'guards'})});
    else o.parents.forEach(function(p){var pt=byId[p].type; var kind=pt==='journey'?'contains':pt==='process'?'uses':'implements'; edges.push({id:'e'+edges.length,source:p,target:o.id,type:kind});});
  });
  var relations=(SCHEMA.relations||[]).filter(function(r){return r.kind!=='includes'&&byId[r.from]&&byId[r.to]});
  var paths=SCHEMA.paths||[];
  var defects=SCHEMA.defects||[]; var defectById={}; defects.forEach(function(d){defectById[d.id]=d});
  var risks=SCHEMA.risks||[]; var riskById={}; risks.forEach(function(r){riskById[r.id]=r});
  // Принадлежность сценариям: узел — по шагам; предки — по потомкам.
  objects.forEach(function(o){o.steps.forEach(function(s){o.scen[s.scenario]=true})});
  function ancestors(id,out){out=out||{}; (byId[id]?byId[id].parents:[]).forEach(function(p){if(!out[p]){out[p]=true; ancestors(p,out);}}); return out;}
  function descendants(id,out){out=out||{}; (byId[id]?byId[id].children:[]).forEach(function(c){if(!out[c]){out[c]=true; descendants(c,out);}}); return out;}
  objects.forEach(function(o){ if(!Object.keys(o.scen).length) return; Object.keys(ancestors(o.id)).forEach(function(a){Object.keys(o.scen).forEach(function(s){byId[a].scen[s]=true})}); });
  objects.forEach(function(o){ if(o.type==='need'||o.type==='guardrail'){ o.targets.forEach(function(t){Object.keys((byId[t]||{scen:{}}).scen).forEach(function(s){o.scen[s]=true})}); } });
  // Разрывы отделены от статусов узлов: отсутствующий обязательный стык или
  // не реализованный обязательный шаг сценария. Неопределённость — не разрыв.
  var breakRows=Array.isArray(SCHEMA.breaks)?SCHEMA.breaks:[];
  var breaks={}; breakRows.forEach(function(br){ (br.nodes||[]).forEach(function(id){(breaks[id]=breaks[id]||[]).push(br)}); });
  var brokenCount=breakRows.length;

  // --- 2. Страница ---
  var header=document.querySelector('header'); var page=header?header.parentElement:document.body; page.classList.add('pko-page');
  var h1=header?header.querySelector('h1'):null; var badgeEl=header?header.querySelector('div>div:last-child'):null;
  Array.prototype.slice.call(page.children).forEach(function(el){store.appendChild(el)});
  function el(tag,cls,text){var n=document.createElement(tag); if(cls) n.className=cls; if(text!=null) n.textContent=text; return n;}
  function add(parent,tag,cls,text){var n=el(tag,cls,text); parent.appendChild(n); return n;}
  var riskIcon='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 2 19 18H1Z" fill="var(--dpss-warning)" stroke="#805C00" stroke-width="1.2"/><path d="M10 7v5m0 3v.1" stroke="#183454" stroke-width="1.7" stroke-linecap="round"/></svg>';
  var head=el('div','pko-head'); var hl=add(head,'div'); add(hl,'div','eyebrow','Паспорт инициативы'); add(hl,'h1',null,h1?h1.textContent.trim().replace(/^Паспорт инициативы\s*/, '').replace(/^«|»$/g,''):'Инициатива');
  if(meta.filled_by_agent===false) add(hl,'div','pko-preview-note','Агент не заполнил паспорт. Показаны только доступные данные оценки.');
  var legend=add(hl,'div','pko-legend');
  var lk=add(legend,'span'); add(lk,'b'); lk.appendChild(document.createTextNode('связь'));
  var lp=add(legend,'span'); add(lp,'span','pin','!'); lp.appendChild(document.createTextNode('разрыв процесса'));
  var lrisk=add(legend,'span'); add(lrisk,'span','risk-icon').innerHTML=riskIcon; lrisk.appendChild(document.createTextNode('операционный риск (количество)'));
  var relsHidden=false;
  var headActions=add(head,'div','pko-head-actions');
  var metrics=add(headActions,'div','pko-metrics');
  function metric(label,value,danger){var m=add(metrics,'div','pko-metric'); add(m,'span',null,label); add(m,'strong',danger?'danger':null,String(value));}
  metric('Процессов',objects.filter(function(o){return o.type==='process'}).length,false);
  metric('Разрывов',brokenCount,brokenCount>0);
  var resetBtn=add(headActions,'button','tool','Сбросить выбор'); resetBtn.type='button'; resetBtn.disabled=true;
  var body=el('div','pko-body'); var viewport=add(body,'div','pko-viewport'); viewport.tabIndex=0;
  var canvas=add(viewport,'div','pko-canvas');
  var zoomBox=add(viewport,'div','pko-zoom'); zoomBox.setAttribute('role','group'); zoomBox.setAttribute('aria-label','Масштаб графа');
  zoomBox.innerHTML='<button type="button" data-z="out" aria-label="Отдалить" title="Отдалить">−</button><span class="lvl" aria-label="Текущий масштаб">100%</span><button type="button" data-z="in" aria-label="Приблизить" title="Приблизить">+</button><button type="button" data-z="fit" class="fit" aria-label="Показать весь граф" title="Показать весь граф"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/></svg></button>';
  var drawer=add(body,'aside','pko-drawer'); var dh=add(drawer,'div','pko-drawer-head'); var dTitle=add(dh,'span',null,'Описание объекта'); var dClose=add(dh,'button','pko-drawer-close','×'); dClose.type='button'; var dBody=add(drawer,'div','pko-drawer-body');
  page.appendChild(head); page.appendChild(body); page.appendChild(store);

  // --- 3. Раскладка рядами по уровням; при выборе — перестроение ---
  // Карточки создаются один раз; положение задаёт layout(scope): без выбора
  // ряды центрированы, потомки под родителями; при выборе объекты его
  // сценария съезжают влево и выстраиваются под своими родителями, остальные
  // уезжают вправо за разрыв. Перестроение анимируется, рёбра пересчитываются
  // на каждом кадре — линии остаются гладкими кривыми без подписей.
  var positions={}, buttons={}, pins=[], svg=null, sceneW=1, sceneH=1, actionBtn=null;
  var edgeEls=[], relEls=[], rowsData=[], anim=null;
  var CARD=224, GAP=22, LABEL=142, OUTER=22, ROWGAP=40, SPLIT=110;
  function bary(o,prevPos){ var refs=o.type==='need'||o.type==='guardrail'?o.targets:o.parents; var xs=refs.map(function(p){return prevPos[p]}).filter(function(v){return v!=null}); return xs.length?xs.reduce(function(a,b){return a+b},0)/xs.length:null; }
  function orderRow(list,prevPos){
    var key={}; list.forEach(function(o,i){ var b=bary(o,prevPos); key[o.id]=b==null?1e9+i:b; });
    return list.slice().sort(function(a,b){return key[a.id]-key[b.id]||a.id.localeCompare(b.id,undefined,{numeric:true})});
  }
  function computeLayout(scopeIds){
    var target={}; var prevPos={}; var full=LABEL+OUTER;
    rowsData.forEach(function(row){
      var list=row.nodes;
      if(!scopeIds){
        var ordered=orderRow(list,prevPos); var start=full+(sceneW-LABEL-OUTER*2-(ordered.length*(CARD+GAP)-GAP))/2;
        ordered.forEach(function(o,i){target[o.id]=start+i*(CARD+GAP)});
      } else {
        var inn=orderRow(list.filter(function(o){return scopeIds[o.id]}),prevPos), out=orderRow(list.filter(function(o){return !scopeIds[o.id]}),prevPos);
        inn.forEach(function(o,i){target[o.id]=full+i*(CARD+GAP)});
        var x0=full+(inn.length?inn.length*(CARD+GAP)-GAP+SPLIT:0);
        out.forEach(function(o,i){target[o.id]=x0+i*(CARD+GAP)});
      }
      var rowPos={}; list.forEach(function(o){rowPos[o.id]=target[o.id]}); prevPos=rowPos;
    });
    return target;
  }
  function nodeStatusChip(o){
    return o.status?el('span','st '+o.status,o.statusLabel||o.status):null;
  }
  function svgEl(tag,attrs){var n=document.createElementNS('http://www.w3.org/2000/svg',tag); Object.keys(attrs||{}).forEach(function(k){n.setAttribute(k,attrs[k])}); return n;}
  function render(){
    canvas.innerHTML=''; positions={}; buttons={}; pins=[]; edgeEls=[]; relEls=[]; rowsData=[];
    svg=document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('class','pko-links'); canvas.appendChild(svg);
    var y=18;
    TYPE_ORDER.forEach(function(t){ var list=objects.filter(function(o){return o.type===t}); if(list.length) rowsData.push({type:t,nodes:list}); });
    sceneW=Math.max.apply(null,[1].concat(rowsData.map(function(r){return r.nodes.length})))*(CARD+GAP)-GAP+LABEL+OUTER*2+SPLIT;
    rowsData.forEach(function(row){
      var lab=add(canvas,'div','pko-row-title',TYPE_NAME[row.type]); lab.style.left=OUTER+'px'; lab.style.top=(y+12)+'px'; add(lab,'span','count',String(row.nodes.length));
      var maxH=0;
      row.nodes.forEach(function(o){
        var b=add(canvas,'button','pko-object'); b.type='button'; b.dataset.id=o.id; b.dataset.type=o.type; b.style.setProperty('--color',COLORS[o.type]); b.style.top=y+'px'; b.style.left='0px';
        add(b,'span','kind',TYPE_LABEL[o.type]); add(b,'strong',null,o.name);
        // Show the backend's node status unchanged; breaks remain separate `!` markers.
        var d=o.data||{};
        var chip=nodeStatusChip(o), riskCount=Array.isArray(d.risks)?d.risks.length:0;
        if(chip||riskCount){
          var badges=add(b,'span','badges'); if(chip) badges.appendChild(chip);
          if(riskCount){var riskBadge=add(badges,'span','risk'); riskBadge.innerHTML=riskIcon; add(riskBadge,'span',null,String(riskCount)); riskBadge.title='Операционных рисков: '+riskCount;}
        }
        b.title=o.name+(Array.isArray(d.risks)&&d.risks.length?' · операционных рисков: '+d.risks.length:'');
        b.setAttribute('aria-label',TYPE_LABEL[o.type]+' «'+o.name+'»'+(o.status?'; '+(o.statusLabel||o.status):'')+(breaks[o.id]?'; разрыв процесса':'')+(Array.isArray(d.risks)&&d.risks.length?'; операционных рисков: '+d.risks.length:''));
        b.addEventListener('click',function(e){if(!moved||e.detail===0) selectObject(o.id);});
        buttons[o.id]=b; positions[o.id]={x:0,y:y,w:CARD,h:b.offsetHeight}; maxH=Math.max(maxH,b.offsetHeight);
      });
      y+=maxH+ROWGAP;
    });
    sceneH=y+20; canvas.style.width=sceneW+'px'; canvas.style.height=sceneH+'px'; svg.setAttribute('width',sceneW); svg.setAttribute('height',sceneH);
    var drawnPairs={};
    function once(a,b){var key=[a,b].sort().join('|'); if(a===b||drawnPairs[key]) return false; drawnPairs[key]=true; return true;}
    edges.forEach(function(e){if(!once(e.source,e.target)) return; var p=svgEl('path',{'class':'link'}); p.dataset.edge=e.id; p.dataset.pair=[e.source,e.target].sort().join('|'); svg.appendChild(p); edgeEls.push({e:e,el:p}); });
    relations.forEach(function(r,i){if(!once(r.from,r.to)) return; var p=svgEl('path',{'class':'link'}); p.dataset.rel=String(i); p.dataset.pair=[r.from,r.to].sort().join('|'); svg.appendChild(p); relEls.push({r:r,i:i,el:p}); });
    if(!objects.length){var msg=add(canvas,'div','pko-empty','Объекты паспорта не собраны.'); msg.style.width='450px'; sceneW=600; sceneH=400;}
    Object.keys(breaks).forEach(function(id){ if(!positions[id]) return; var b=add(canvas,'button','pko-pin','!'); b.type='button'; var titles=breaks[id].map(function(h){return h.scenario_title}); b.title='Разрыв: '+titles.filter(function(v,i,a){return a.indexOf(v)===i}).join(', '); b.addEventListener('click',function(e){e.stopPropagation(); if(moved&&e.detail!==0) return; showBreaks(id);}); pins.push({id:id,button:b}); });
    var t0=computeLayout(null); Object.keys(t0).forEach(function(id){positions[id].x=t0[id]}); place(); selection(); requestAnimationFrame(fit);
  }
  function edgePath(e){
    var a=positions[e.source], b=positions[e.target]; if(!a||!b) return '';
    var x1=a.x+a.w/2, y1=a.y+a.h, x2=b.x+b.w/2, y2=b.y;
    if(e.type==='guards'){ var top=a.y<b.y?a:b, bottom=a.y<b.y?b:a; var lane=Math.max(top.x+top.w,bottom.x+bottom.w)+14; return 'M'+(top.x+top.w)+','+(top.y+top.h/2)+' C'+lane+','+(top.y+top.h/2)+' '+lane+','+(bottom.y+bottom.h/2)+' '+(bottom.x+bottom.w)+','+(bottom.y+bottom.h/2); }
    var mid=(y1+y2)/2; return 'M'+x1+','+y1+' C'+x1+','+mid+' '+x2+','+mid+' '+x2+','+y2;
  }
  function relPath(r,i){
    var a=positions[r.from], b=positions[r.to]; if(!a||!b) return '';
    if(Math.abs(a.y-b.y)<8){ var ltr=a.x<b.x; var x1=a.x+a.w*(ltr?.7:.3), x2=b.x+b.w*(ltr?.3:.7), yy=a.y, h=26+(i%3)*6; return 'M'+x1+','+yy+' C'+x1+','+(yy-h)+' '+x2+','+(yy-h)+' '+x2+','+yy; }
    var down=b.y>a.y; var sx=a.x+a.w/2, sy=down?a.y+a.h:a.y, tx2=b.x+b.w/2, ty2=down?b.y:b.y+b.h; var mid=(sy+ty2)/2; return 'M'+sx+','+sy+' C'+sx+','+mid+' '+tx2+','+mid+' '+tx2+','+ty2;
  }
  function place(){
    Object.keys(buttons).forEach(function(id){buttons[id].style.left=positions[id].x+'px'});
    edgeEls.forEach(function(x){x.el.setAttribute('d',edgePath(x.e))}); relEls.forEach(function(x){x.el.setAttribute('d',relPath(x.r,x.i))});
    pins.forEach(function(p){var pos=positions[p.id]; p.button.style.left=(pos.x-9)+'px'; p.button.style.top=(pos.y-8)+'px';});
    if(actionBtn&&focus&&positions[focus]){actionBtn.style.left=positions[focus].x+'px'; actionBtn.style.top=(positions[focus].y+positions[focus].h+6)+'px';}
  }
  function layout(scopeIds){
    var target=computeLayout(scopeIds); var from={}; Object.keys(positions).forEach(function(id){from[id]=positions[id].x});
    if(anim) cancelAnimationFrame(anim);
    var t0=performance.now(), dur=window.matchMedia('(prefers-reduced-motion: reduce)').matches?0:700;
    function frame(now){
      var k=dur?Math.min(1,(now-t0)/dur):1; var e=ease(k);
      Object.keys(target).forEach(function(id){positions[id].x=from[id]+(target[id]-from[id])*e});
      place(); if(k<1) anim=requestAnimationFrame(frame); else anim=null;
    }
    anim=requestAnimationFrame(frame);
    if(scopeIds) fitTo(scopeIds,target); else fit(true);
  }
  // Камера наводится на собранную группу: по её габаритам, не крупнее 100%.
  function fitTo(scopeIds,target){
    var minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
    Object.keys(scopeIds).forEach(function(id){var p=positions[id]; if(!p) return; var x=target?target[id]:p.x; minX=Math.min(minX,x); maxX=Math.max(maxX,x+p.w); minY=Math.min(minY,p.y); maxY=Math.max(maxY,p.y+p.h);});
    if(!isFinite(minX)) return;
    var pad=60, w=maxX-minX+pad*2, h=maxY-minY+pad*2;
    // Leave a bottom lane for the zoom controls and the node action.
    var visibleH=Math.max(240,viewport.clientHeight-108);
    var next=Math.max(.2,Math.min(1,(viewport.clientWidth-460)/w,(visibleH-40)/h));
    animateCamera(next,(viewport.clientWidth-460-w*next)/2-(minX-pad)*next,Math.max(12,(visibleH-h*next)/2-(minY-pad)*next));
  }
  // Плавность: ease-in-out (квинтика) — без рывка в начале и в конце.
  function ease(k){return k<.5?16*k*k*k*k*k:1-Math.pow(-2*k+2,5)/2;}
  var camAnim=null;
  function animateCamera(ns,ntx,nty){
    if(camAnim) cancelAnimationFrame(camAnim);
    var s0=scale,x0=tx,y0=ty,t0=performance.now(),dur=window.matchMedia('(prefers-reduced-motion: reduce)').matches?0:600;
    function frame(now){var k=dur?Math.min(1,(now-t0)/dur):1; var e=ease(k); scale=s0+(ns-s0)*e; tx=x0+(ntx-x0)*e; ty=y0+(nty-y0)*e; apply(); if(k<1) camAnim=requestAnimationFrame(frame); else camAnim=null;}
    camAnim=requestAnimationFrame(frame);
  }

  // --- 4. Выбор: весь сценарий объекта ---
  var focus=null, moved=false;
  // Процесс = сценарий: область выбора — процессы, в которые объект входит,
  // и всё их содержимое; у пути — все процессы, у BBB до развилки — те,
  // которые он запускает.
  function processesOf(id){
    var out={}; var o=byId[id]; if(!o) return out;
    if(o.type==='process'){out[id]=true; return out;}
    if(o.type==='journey'){objects.forEach(function(x){if(x.type==='process') out[x.id]=true}); return out;}
    if(o.type==='need'||o.type==='guardrail'){o.targets.forEach(function(t){Object.keys(processesOf(t)).forEach(function(k){out[k]=true})}); return out;}
    Object.keys(ancestors(id)).forEach(function(a){if(byId[a].type==='process') out[a]=true});
    if(o.data&&o.data.before_fork) relations.forEach(function(r){if(r.from===id&&r.kind==='triggers'&&byId[r.to]&&byId[r.to].type==='process') out[r.to]=true});
    return out;
  }
  function scope(id){
    var o=byId[id]; var ids={}; ids[id]=true; var procs=processesOf(id);
    Object.keys(procs).forEach(function(p){ ids[p]=true; Object.keys(descendants(p)).forEach(function(c){ids[c]=true}); Object.keys(ancestors(p)).forEach(function(a){ids[a]=true}); });
    Object.keys(ancestors(id)).forEach(function(a){ids[a]=true});
    if(o.type==='need'||o.type==='guardrail') o.targets.forEach(function(t){ids[t]=true; Object.keys(ancestors(t)).forEach(function(a){ids[a]=true});});
    if(o.type==='journey'||!Object.keys(procs).length) Object.keys(descendants(id)).forEach(function(c){ids[c]=true});
    objects.forEach(function(x){ if((x.type==='need'||x.type==='guardrail')&&x.targets.some(function(t){return ids[t]})) ids[x.id]=true; });
    var edgeSet={}; edges.forEach(function(e){ if(ids[e.source]&&ids[e.target]) edgeSet[e.id]=true; });
    var relSet={}; relations.forEach(function(r,i){ if(ids[r.from]&&ids[r.to]) relSet[i]=true; });
    return {ids:ids,edges:edgeSet,rels:relSet,procs:procs};
  }
  function selection(){
    var sc=focus?scope(focus):null;
    Object.keys(buttons).forEach(function(id){var b=buttons[id]; b.classList.toggle('dim',!!sc&&!sc.ids[id]); b.classList.toggle('related',!!sc&&!!sc.ids[id]&&id!==focus); b.classList.toggle('selected',focus===id);});
    edgeEls.forEach(function(x){ var active=sc&&sc.edges[x.e.id]; x.el.classList.toggle('dim',!!sc&&!active); x.el.classList.toggle('selected',!!sc&&!!active); });
    relEls.forEach(function(x){ var active=sc&&sc.rels[x.i]; x.el.classList.toggle('dim',!!sc&&!active); x.el.classList.toggle('selected',!!sc&&!!active); });
    pins.forEach(function(p){p.button.classList.toggle('dim',!!sc&&!sc.ids[p.id])});
    resetBtn.disabled=!focus;
    if(actionBtn){actionBtn.remove(); actionBtn=null;}
    if(!focus){ layout(null); return; }
    actionBtn=add(canvas,'button','pko-action','Открыть описание →'); actionBtn.type='button'; actionBtn.addEventListener('click',function(e){e.stopPropagation(); if(moved&&e.detail!==0) return; showObject(focus);});
    layout(sc.ids);
  }
  function selectObject(id){ if(!byId[id]) return; if(focus===id){reset(); return;} focus=id; closeDrawer(); selection(); history.replaceState(null,'',location.pathname+location.search+'#'+encodeURIComponent(id)); }
  function reset(){ focus=null; closeDrawer(); selection(); history.replaceState(null,'',location.pathname+location.search); }

  // --- 5. Описание объекта ---
  function link(id){var a=el('a',null,byId[id]?byId[id].name:id); a.href='#'+encodeURIComponent(id); a.addEventListener('click',function(e){e.preventDefault(); selectObject(id); showObject(id);}); return a;}
  function evidence(parent,text,label){if(!text) return null; var panel=add(parent,'details','pko-evidence'); add(panel,'summary',null,label||'Основание'); add(panel,'div',null,text); return panel;}
  function openDrawer(title){dTitle.textContent=title; dBody.innerHTML=''; drawer.classList.add('open'); dClose.focus({preventScroll:true}); Object.keys(buttons).forEach(function(k){buttons[k].classList.remove('inspected')});}
  function closeDrawer(){var hadFocus=drawer.contains(document.activeElement); drawer.classList.remove('open'); Object.keys(buttons).forEach(function(k){buttons[k].classList.remove('inspected')}); if(hadFocus&&focus&&buttons[focus]) buttons[focus].focus({preventScroll:true});}
  function cardTabs(card,id){
    var heading=card.querySelector('.pko-card-heading');
    var description=el('section','pko-tab-panel'), riskPanel=el('section','pko-tab-panel'), linksPanel=el('section','pko-tab-panel');
    Array.prototype.slice.call(card.children).forEach(function(child){
      if(child===heading) return;
      var cls=child.classList;
      (cls.contains('pko-node-risks')?riskPanel:
       cls.contains('pko-node-links')||cls.contains('pko-links-list')||cls.contains('pko-node-scenarios')||cls.contains('pko-node-relations')||cls.contains('pko-node-risk-links')?linksPanel:description).appendChild(child);
    });
    if(!riskPanel.childNodes.length) add(riskPanel,'p',null,'Для этого узла риски в отчёте не указаны.');
    if(!linksPanel.childNodes.length) add(linksPanel,'p',null,'Связи для этого объекта не указаны.');
    var tabs=add(card,'div','pko-card-tabs'); tabs.setAttribute('role','tablist'); tabs.setAttribute('aria-label','Разделы описания объекта');
    var panels=[description,riskPanel,linksPanel], buttons=[];
    function activate(index,moveFocus){
      buttons.forEach(function(button,i){var active=i===index; button.setAttribute('aria-selected',String(active)); button.tabIndex=active?0:-1; panels[i].hidden=!active;});
      dBody.scrollTop=0;
      if(moveFocus) buttons[index].focus({preventScroll:true});
    }
    ['Описание','Риски','Связи'].forEach(function(label,i){
      var button=add(tabs,'button',null,label); button.type='button'; button.id='pko-tab-'+id+'-'+i;
      button.setAttribute('role','tab'); button.setAttribute('aria-controls','pko-panel-'+id+'-'+i);
      panels[i].id='pko-panel-'+id+'-'+i; panels[i].setAttribute('role','tabpanel'); panels[i].setAttribute('aria-labelledby',button.id); panels[i].tabIndex=0;
      button.addEventListener('click',function(){activate(i,false)});
      button.addEventListener('keydown',function(e){
        var next=e.key==='Home'?0:e.key==='End'?2:e.key==='ArrowRight'?(i+1)%3:e.key==='ArrowLeft'?(i+2)%3:null;
        if(next!==null){e.preventDefault(); activate(next,true);}
      });
      buttons.push(button);
    });
    panels.forEach(function(panel){card.appendChild(panel)}); activate(0,false);
  }
  function showObject(id){
    var o=byId[id]; if(!o) return; openDrawer('Описание объекта'); if(buttons[id]) buttons[id].classList.add('inspected');
    if(o.type==='need'||o.type==='guardrail'){
      var box=add(dBody,'div','pko-simple'); var heading=add(box,'div','pko-card-heading'); add(heading,'div','type',TYPE_LABEL[o.type]); add(heading,'h2',null,o.name);
      if(o.type==='guardrail'){ add(box,'p',null,'Что защищаем: '+(o.text||'—')); add(box,'p',null,'Когда срабатывает: '+(o.condition||'—')); add(box,'p',null,'Эффект: '+(o.effect||'—')); }
      else add(box,'p',null,o.text||'');
      evidence(box,o.source);
      if(o.targets.length){var tl=add(box,'p','pko-node-links',(o.type==='need'?'Закрывается: ':'Ограничивает: ')); o.targets.forEach(function(t,i){if(i) tl.appendChild(document.createTextNode(', ')); tl.appendChild(link(t));});}
      appendRisks(box,risks.filter(function(r){return (r.linked_nodes||[]).indexOf(id)>=0||(r.guardrails||[]).indexOf(id)>=0}));
      cardTabs(box,id);
      return;
    }
    var src=els[id]; if(!src){add(dBody,'p',null,o.name); return;}
    var clone=el('article','node pko-clean-card');
    var chead=add(clone,'div','pko-card-heading'); add(chead,'div','type',TYPE_LABEL[o.type]); add(chead,'h2',null,o.name);
    var d=o.data||{};
    if(d.scenario_entry||d.scenario_outcome){
      function scenarioPoint(label,value){
        if(!value) return;
        var point=add(clone,'section','pko-field');
        add(point,'h3',null,label);
        add(point,'p',null,value);
      }
      scenarioPoint('Условие запуска',d.scenario_entry);
      scenarioPoint('Ожидаемый результат',d.scenario_outcome);
    }
    var hiddenFields=['4.2.3','4.3.2','4.3.3','4.3.6','4.3.9','4.4.2','4.4.3','4.4.4','4.4.6','4.4.7','4.5.2','4.5.3','4.5.5'];
    Array.prototype.forEach.call(src.querySelectorAll('[data-field]'),function(f){
      if(f.closest('.node')!==src) return;
      var fid=f.getAttribute('data-field'); if(hiddenFields.indexOf(fid)>=0) return;
      if(['4.2.1','4.2.5','4.3.1','4.4.1','4.5.1','4.5.4'].indexOf(fid)<0) return;
      if(d.planned&&((meta.planned_fields||{})[o.type]||[]).indexOf(fid)<0) return;
      var value=f.querySelector('[data-fill="value"]'), source=f.querySelector('[data-fill="source"]'), heading=f.querySelector('h4');
      if(!value||!value.textContent.trim()) return;
      var section=add(clone,'section','pko-field'); section.dataset.field=fid;
      var title=heading?heading.textContent.trim():'Описание';
      var text=value.textContent.trim();
      if(fid==='4.5.4') text=text.replace(/^Проверяемый эффект:\s*/i,'');
      add(section,'h3',null,title); add(section,'p',null,text);
      evidence(section,source?source.textContent.trim():'');
    });
    var assessment=el('div','pko-node-assessment'); var flags=el('div','pko-node-flags');
    if(d.before_fork) add(flags,'span',null,'до развилки · выполняется до выбора процесса');
    if(o.parents.length>1) add(flags,'span',null,'общий узел · родителей: '+o.parents.length);
    if(d.planned) add(flags,'span','planned','в коде нет · планируется');
    if(d.branching&&d.branching!=='sequence') add(flags,'span',null,d.branching_label||d.branching);
    add(assessment,'h3','lbl','Статус узла');
    add(assessment,'div','state',d.implementation_label||'Недостаточно данных');
    if(d.readiness!=null) add(assessment,'div',null,'Взвешенная полнота по пунктам: '+d.readiness+'%');
    if(d.requirements&&d.requirements.total) add(assessment,'div',null,'Полностью выполнено обещаний: '+d.requirements.done+' из '+d.requirements.total+' ('+d.requirements.done_percent+'%)');
    if(d.scenario_status_label) add(assessment,'div',null,'Связность сценария: '+d.scenario_status_label);
    if(Array.isArray(d.problems)&&d.problems.length){var ul=add(assessment,'ul'); d.problems.forEach(function(p){add(ul,'li',null,p)});}
    clone.appendChild(assessment);
    var links=el('div','pko-links-list');
    function list(label,ids){ if(!ids.length) return; links.appendChild(document.createTextNode(label)); ids.forEach(function(c,i){if(i) links.appendChild(document.createTextNode(', ')); links.appendChild(link(c));}); }
    list(o.parents.length>1?'Родители ('+o.parents.length+'): ':'Родитель: ',o.parents); list(' · Дети: ',o.children);
    if(flags.childNodes.length) links.prepend(flags);
    if(links.childNodes.length) clone.appendChild(links);
    if(o.type==='bbb'||o.type==='operation'){ var ps=Object.keys(processesOf(o.id)); if(ps.length){ var sbox=el('div','pko-node-scenarios'); add(sbox,'div','lbl','Процессы'); var sul=add(sbox,'ul'); ps.forEach(function(pid){var li=add(sul,'li'); li.appendChild(link(pid)); var chip=nodeStatusChip(byId[pid]); if(chip) li.appendChild(chip);}); clone.appendChild(sbox); } }
    var rels=relations.filter(function(r){return r.from===id||r.to===id});
    if(rels.length){ var rbox=el('div','pko-node-relations'); add(rbox,'div','lbl','Связи'); var rul=add(rbox,'ul'); rels.forEach(function(r){var li=add(rul,'li'); add(li,'span','kind',r.kind_label||r.kind); if(r.from===id){li.appendChild(document.createTextNode(' → ')); li.appendChild(link(r.to));} else {li.appendChild(document.createTextNode(' · ')); li.appendChild(link(r.from)); li.appendChild(document.createTextNode(' → этот объект'));} evidence(li,r.basis);}); clone.appendChild(rbox); }
    var dfs=(d.defects||[]).map(function(x){return defectById[x]}).filter(Boolean);
    if(dfs.length){ var dbox=el('div','pko-node-defects'); add(dbox,'div','lbl','Дефекты'); var dul=add(dbox,'ul'); dfs.forEach(function(df){add(dul,'li',null,df.title+(df.blocking?' — блокирует':''));}); clone.insertBefore(dbox,assessment.nextSibling); }
    var rks=(d.risks||[]).map(function(x){return riskById[x]}).filter(Boolean);
    appendRisks(clone,rks);
    var inherited=(d.descendant_risks||[]).map(function(x){return riskById[x]}).filter(Boolean);
    appendRisks(clone,inherited,'Риски дочерних шагов');
    cardTabs(clone,id);
    dBody.appendChild(clone); dBody.scrollTop=0;
  }
  function appendRisks(target,rks,heading){
    if(rks.length){
      var many=rks.length>1;
      var kbox=el('div','pko-node-risks'+(many?' multi':''));
      if(heading) add(kbox,'h3',null,heading);
      var kul=add(kbox,'ul');
      var riskLinks=el('section','pko-node-risk-links'), hasRiskLinks=false;
      add(riskLinks,'div','lbl','Связи по рискам');
      rks.forEach(function(rk){
        var li=add(kul,'li','pko-risk-card'), content=li;
        var problem=rk.problem||[rk.trigger||rk.cause,rk.negative_event,(rk.consequences||[])[0]].filter(Boolean).join(' → ')||rk.title;
        if(many){var disclosure=add(li,'details','pko-risk-disclosure'); add(disclosure,'summary',null,problem); content=add(disclosure,'div','pko-risk-details');}
        else add(li,'h3',null,problem);
        function riskText(label,text,cls,parent){if(!text) return; var p=add(parent||content,'p',cls); add(p,'span','risk-label',label); p.appendChild(document.createTextNode(text));}
        riskText('В чём пробел',rk.control_gap,'gap');
        if(rk.recommendation||rk.confirmation_needed||rk.closure_criterion){
          var actions=add(content,'details','pko-risk-actions'); add(actions,'summary',null,'Что сделать и проверить');
          riskText('Что изменить',rk.recommendation,null,actions);
          riskText('Что проверить',rk.confirmation_needed,null,actions);
          riskText('Критерий закрытия',rk.closure_criterion,null,actions);
        }
        var linked=(rk.display_nodes||rk.linked_nodes||[]).filter(function(nid){return !!byId[nid]});
        var gids=(rk.guardrails||[]).filter(function(gid){return !!byId[gid]});
        if(linked.length||gids.length){
          hasRiskLinks=true;
          var item=add(riskLinks,'div','pko-risk-link-item'); add(item,'h3',null,rk.title);
          if(linked.length){var np=add(item,'p',null,'Связанные узлы: '); linked.forEach(function(nid,i){if(i) np.appendChild(document.createTextNode(', ')); np.appendChild(link(nid));});}
          if(gids.length){var gp=add(item,'p',null,'Связанные ограничения: '); gids.forEach(function(gid,i){if(i) gp.appendChild(document.createTextNode(', ')); gp.appendChild(link(gid));});}
        }
        var proof=(rk.evidence||[]).map(function(ev){return ev.where+' — '+ev.basis}).join('; ');
        var ep=evidence(content,[rk.cause,rk.mechanism,rk.confidence_note,proof].filter(Boolean).join('\n\n'));
        if(ep&&(rk.existing_controls||[]).length) add(ep,'p',null,'Учтённые контроли: '+rk.existing_controls.map(function(c){return c.description+' — '+c.basis}).join('; '));
      });
      target.appendChild(kbox);
      if(hasRiskLinks) target.appendChild(riskLinks);
    }
  }
  function showBreaks(id){
    openDrawer('Разрыв процесса'); var box=add(dBody,'div','pko-simple'); add(box,'div','type','Точка разрыва'); add(box,'h2',null,byId[id].name);
    (breaks[id]||[]).forEach(function(br){
      var p=add(box,'p'); add(p,'strong',null,br.scenario_title+(br.critical?' · критический процесс':'')); p.appendChild(document.createElement('br'));
      if(br.kind==='node') p.appendChild(document.createTextNode(br.reason+(br.step_text?' — «'+br.step_text+'»':'')));
      else p.appendChild(document.createTextNode('Переход «'+br.from_step+'» → «'+br.to_step+'»'));
      var ul=add(box,'ul'); (br.checks||[]).forEach(function(c){ if(c.result==='broken'){ add(ul,'li',null,c.check_label+': '+c.result_label+(c.note?' — '+c.note:'')+((c.links||[]).length?' · '+c.links.map(function(l){return l.path+(l.line?':'+l.line:'')}).join(', '):'')); } });
    });
    var b=add(box,'button','tool','Открыть описание объекта'); b.type='button'; b.style.marginTop='12px'; b.addEventListener('click',function(){showObject(id)});
  }

  // --- 6. Масштаб и панорама ---
  var scale=1,tx=0,ty=0,drag=null;
  function apply(){canvas.style.transform='translate('+tx+'px,'+ty+'px) scale('+scale+')'; zoomBox.querySelector('.lvl').textContent=Math.round(scale*100)+'%';}
  function fit(smooth){ if(!viewport.clientWidth) return; var ns=Math.max(.2,Math.min(1,(viewport.clientWidth-24)/sceneW,(viewport.clientHeight-60)/sceneH)); var ntx=(viewport.clientWidth-sceneW*ns)/2, nty=Math.max(12,(viewport.clientHeight-48-sceneH*ns)/2); if(smooth===true){animateCamera(ns,ntx,nty); return;} scale=ns; tx=ntx; ty=nty; apply(); }
  function zoom(f,x,y){var next=Math.max(.15,Math.min(2.6,scale*f)); tx=x-(x-tx)*next/scale; ty=y-(y-ty)*next/scale; scale=next; apply();}
  viewport.addEventListener('wheel',function(e){e.preventDefault(); var r=viewport.getBoundingClientRect(); zoom(Math.exp(-e.deltaY*.0015),e.clientX-r.left,e.clientY-r.top);},{passive:false});
  viewport.addEventListener('pointerdown',function(e){ if(e.button!==0||e.target.closest('.pko-zoom')) return; drag={x:e.clientX,y:e.clientY,tx:tx,ty:ty}; moved=false; });
  window.addEventListener('pointermove',function(e){ if(!drag) return; var dx=e.clientX-drag.x, dy=e.clientY-drag.y; if(Math.abs(dx)+Math.abs(dy)>5) moved=true; if(moved){viewport.classList.add('dragging'); tx=drag.tx+dx; ty=drag.ty+dy; apply();} });
  window.addEventListener('pointerup',function(){ drag=null; viewport.classList.remove('dragging'); setTimeout(function(){moved=false},0); });
  window.addEventListener('pointercancel',function(){drag=null; moved=false; viewport.classList.remove('dragging');});
  viewport.addEventListener('click',function(e){ if(!moved&&!e.target.closest('button')&&focus) reset(); });
  zoomBox.addEventListener('click',function(e){var b=e.target.closest('button'); if(!b) return; if(b.dataset.z==='fit') fit(); else zoom(b.dataset.z==='in'?1.2:1/1.2,viewport.clientWidth/2,viewport.clientHeight/2);});
  window.addEventListener('resize',fit);
  resetBtn.addEventListener('click',reset); dClose.addEventListener('click',closeDrawer);
  dClose.setAttribute('aria-label','Закрыть описание');
  document.addEventListener('keydown',function(e){ if(e.key==='Escape'){ if(drawer.classList.contains('open')) closeDrawer(); else reset(); } });
  function start(){
    render();
    var initial=decodeURIComponent(location.hash.slice(1)); if(byId[initial]){focus=initial; selection();}
  }
  // Measure node geometry only after the embedded typeface is ready.
  if(document.fonts){
    Promise.all([400,600,700].map(function(weight){return document.fonts.load(weight+' 14px "SB Sans Display"');})).then(start,start);
  } else start();
})();
</script>
"""


def _finalize_html(html: str, schema: dict[str, Any] | None = None) -> str:
    """Сделать HTML самодостаточным: убрать DCLogic, заменить Mustache, добавить JS.

    Шаблон v3 рассчитан на внешний движок DCLogic (`support.js`). В
    статичном файле паспорта этого движка нет — функция убирает зависимость
    и добавляет собственный минималистичный JS.
    """
    # 1. Убираем внешний скрипт support.js и DCLogic-блок.
    html = re.sub(r'<script\s+src="./support\.js">\s*</script>', '', html)
    html = re.sub(
        r'<script type="text/x-dc"[^>]*>.*?</script>',
        '', html, flags=re.DOTALL,
    )

    # 2. Заменяем Mustache-плейсхолдеры.
    def replace_mustache(m: re.Match) -> str:
        key = m.group(0).strip("{} ").strip()
        if key in _MUSTACE_CALLBACKS:
            return ""  # onClick="{{ tJourney }}" → onClick=""
        return _MUSTACHE_VALUES.get(key, "")

    html = _MUSTACHE_RE.sub(replace_mustache, html)

    # 3. Убираем data-anim (анимация не нужна в статике).
    html = re.sub(r'\s+data-anim\b', '', html)

    # 4. Убираем style-hover (нестандартный атрибут) — hover в CSS.
    html = re.sub(r'\s+style-hover="[^"]*"', '', html)

    # 6. Убираем упоминания параграфов стандарта из видимых элементов.
    #    «§ 4.2.1», «§ 4.2 · 8 полей», «(§ 3.2.1)», «§§ 3.2, 4.0–4.6» и т.д.
    #    В заголовках полей: «<span ...>§ 4.2.1</span>» → убираем span целиком.
    html = re.sub(
        r'<span[^>]*>§+\s*[\d.,–-]*</span>',
        '', html,
    )
    # Footer с упоминанием стандарта целиком.
    html = re.sub(
        r'Источник:\s*Стандарт автономного процесса[^<]*',
        '', html,
    )
    # В тексте заголовков узлов: «§ 4.2 · 8 полей» → «8 полей»
    html = re.sub(r'§+\s*[\d.]+\s*·\s*', '', html)
    # Одиночные «§ 4.5», «§§ 3.2», «§ 4.0» в видимом тексте.
    html = re.sub(r'§+\s*[\d.,–-]+', '', html)

    # Keep only inert card text; the editor template and its old UI are not shipped.
    html = compact_template(html)
    # 7. Добавляем CSS и JS перед </body>.
    script = _INLINE_JS.replace("__PKO_SCHEMA__", nodes_json(schema or {"nodes": [], "paths": [], "relations": []}), 1)
    inject = embedded_fonts() + "\n" + _INLINE_CSS + "\n" + script
    html = html.replace("</body>", inject + "\n</body>", 1)

    return html

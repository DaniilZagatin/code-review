"""Small, inert card store extracted from the populated legacy template."""
from html import escape
from html.parser import HTMLParser

# Presentation only: the complete analysis remains in progress_model.json.
HIDDEN_FIELDS = {"4.2.3", "4.3.2", "4.3.3", "4.3.6", "4.3.9",
                 "4.4.2", "4.4.3", "4.4.4", "4.4.6", "4.4.7",
                 "4.5.2", "4.5.3", "4.5.5"}


class _Element:
    def __init__(self, tag, attrs=()):
        self.tag, self.attrs, self.children = tag, dict(attrs), []

    def text(self):
        return "".join(c if isinstance(c, str) else c.text() for c in self.children)

    def descendants(self):
        for child in self.children:
            if isinstance(child, _Element):
                yield child
                yield from child.descendants()


class _Document(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = _Element("document")
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        node = _Element(tag, attrs)
        self.stack[-1].children.append(node)
        if tag not in {"meta", "link", "img", "br", "hr", "input", "source", "wbr"}:
            self.stack.append(node)
        elif tag == "br":
            self.stack[-1].children.append("\n")

    def handle_startendtag(self, tag, attrs):
        self.stack[-1].children.append(_Element(tag, attrs))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)


def compact_template(html: str) -> str:
    """Remove template styles, editor UI, IDs/versions and descriptive chrome.

    Plain text only: no HTML/event handlers from field values are replayed.
    The hidden registry is retained for offline machine consumers.
    """
    parser = _Document()
    parser.feed(html)
    elements = list(parser.root.descendants())
    title = next((e.text().strip() for e in elements if e.tag == "h1"), "Паспорт инициативы")
    cards = []
    for node in elements:
        if "node" not in node.attrs.get("class", "").split() or not node.attrs.get("id"):
            continue
        parts = [f'<section class="node" id="{escape(node.attrs["id"], quote=True)}">']

        def own_fields(parent):
            for child in parent.children:
                if not isinstance(child, _Element) or "node" in child.attrs.get("class", "").split():
                    continue
                if "data-field" in child.attrs:
                    yield child
                else:
                    yield from own_fields(child)

        for field in own_fields(node):
            fid = field.attrs["data-field"]
            if fid in HIDDEN_FIELDS:
                continue
            content = list(field.descendants())
            heading = next((e.text().strip() for e in content if e.tag in ("h3", "h4")), "Описание")
            def text(key):
                return next((e.text().strip() for e in content if e.attrs.get("data-fill") == key), "")
            parts.append(f'<div data-field="{escape(fid, quote=True)}"><h4>{escape(heading)}</h4>'
                         f'<p data-fill="value">{escape(text("value"))}</p>'
                         f'<span data-fill="source">{escape(text("source"))}</span></div>')
        cards.append("".join(parts) + "</section>")
    registry = next((e for e in elements if e.tag == "table" and
                     "registry" in e.attrs.get("class", "").split()), None)
    registry_rows = []
    if registry:
        for row in registry.descendants():
            if row.tag != "tr":
                continue
            cells = []
            for cell in row.children:
                if not isinstance(cell, _Element) or cell.tag not in ("td", "th"):
                    continue
                attr = f' data-col="{escape(cell.attrs["data-col"], quote=True)}"' if "data-col" in cell.attrs else ""
                cells.append(f'<{cell.tag}{attr}>{escape(cell.text().strip())}</{cell.tag}>')
            registry_rows.append('<tr>' + ''.join(cells) + '</tr>')
    registry_html = '<table class="registry">' + ''.join(registry_rows) + '</table>' if registry else ''
    return ('<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>{escape(title)}</title></head><body><main><header><h1>{escape(title)}</h1></header>'
            + "\n".join(cards) + registry_html + '</main></body></html>')

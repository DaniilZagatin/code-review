"""Inventory an HTML passport and check annotation coverage, without running its JS.

This checks the presence of review records, not the semantic truth of an LLM review.
No imports from pko, no network, no third-party dependencies.
"""
from __future__ import annotations

import argparse
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys

VERSION = "1.3"
GLOBAL_CHECKS = {
    "source_scope": "Состав исходников, версии, исследованные и открытые границы",
    "promise_coverage": "Все обещания ОР сопоставлены с паспортом",
    "reverse_coverage": "Независимые маршруты, факты, условия и исключения сопоставлены",
    "business_structure": "Смысл и границы дерева в целом, включая обычные сервисы",
    "evidence_audit": "Основания, контраргументы и согласованность итогов перепроверены",
}
RISK_CHECKS = [f"D4.{i}" for i in range(1, 8)]
RISK_AREAS = ["input", "decision", "execution", "persistence", "dependencies", "detection", "recovery"]
RESULTS = {"верно", "частично", "ошибка", "неясно", "не проверено", "не применимо"}
CHECKS = {
    "identity": "Название, тип, назначение и границы объекта",
    "field_completeness": "Все поля и отсутствующие свойства узла",
    "structure": "Родители, дети, общий шаг и место до развилки",
    "relations": "Все входящие и исходящие связи",
    "scenarios": "Обещания ОР, сценарии и шаги",
    "implementation": "Реализация, статус и ограничения",
    "defects": "Дефекты, противоречия и потерянные детали",
    "risks": "Заявленные риски, контроли и поиск пропущенных рисков узла",
    "reverse_search": "Поиск отсутствующего и искажённого по исходникам",
}
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}


def clean(value: str) -> str:
    return " ".join(value.split())


class PassportParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.nodes = {}
        self.scripts = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        parent = self.stack[-1] if self.stack else {}
        frame = {"tag": tag, "node": parent.get("node"), "field": parent.get("field"),
                 "sink": parent.get("sink"), "skip": parent.get("skip", False),
                 "script": parent.get("script")}
        if tag == "script":
            self.scripts.append([])
            frame["script"] = self.scripts[-1]
        if tag in {"script", "style", "template"}:
            frame["skip"] = True
        if not frame["skip"]:
            nid = attrs.get("id")
            if nid and "node" in attrs.get("class", "").split():
                if nid in self.nodes:
                    raise ValueError(f"Повторный ID узла в HTML: {nid}")
                self.nodes[nid] = {"id": nid, "fields": {}}
                frame.update(node=nid, field=None, sink=None)
            if frame["node"] and "data-field" in attrs:
                fid = attrs["data-field"]
                fields = self.nodes[frame["node"]]["fields"]
                if fid in fields:
                    raise ValueError(f"Повторное поле: {frame['node']}/{fid}")
                fields[fid] = {"id": fid, "title": [], "value": [], "source": []}
                frame.update(field=fid, sink=None)
            if frame["field"]:
                if attrs.get("data-fill") in {"value", "source"}:
                    frame["sink"] = attrs["data-fill"]
                elif tag == "h4":
                    frame["sink"] = "title"
        if tag not in VOID:
            self.stack.append(frame)
        elif tag == "br":
            self.handle_data(" ")

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i]["tag"] == tag:
                self.stack = self.stack[:i]
                return

    def handle_data(self, data):
        if not self.stack:
            return
        frame = self.stack[-1]
        if frame.get("script") is not None:
            frame["script"].append(data)
        if not frame["skip"] and frame["node"] and frame["field"] and frame["sink"]:
            self.nodes[frame["node"]]["fields"][frame["field"]][frame["sink"]].append(data)


def inventory(html: str, passport_hash: str) -> dict:
    parser = PassportParser()
    parser.feed(html)
    parser.close()
    schemas = []
    for fragments in parser.scripts:
        script = "".join(fragments)
        for match in re.finditer(r"\b(?:var|let|const)\s+SCHEMA\s*=\s*", script):
            try:
                obj, _ = json.JSONDecoder().raw_decode(script[match.end():])
            except json.JSONDecodeError as exc:
                raise ValueError("SCHEMA в HTML не является читаемым JSON") from exc
            if not isinstance(obj, dict):
                raise ValueError("SCHEMA должна быть объектом")
            schemas.append(obj)
    if len(schemas) != 1:
        raise ValueError("Нужен HTML Белки с единственным встроенным объектом SCHEMA; формат не распознан")
    schema = schemas[0]
    if not isinstance(schema.get("nodes"), list) or not schema["nodes"]:
        raise ValueError("В SCHEMA отсутствует непустой список nodes")
    rows = [(n, None) for n in schema["nodes"]]
    meta = schema.get("meta") or {}
    rows += [(n, kind) for plural, kind in (("needs", "need"), ("guardrails", "guardrail"))
             for n in meta.get(plural, [])]
    nodes, ids = [], set()
    for raw, kind in rows:
        if not isinstance(raw, dict) or not isinstance(raw.get("id"), str) or not raw["id"]:
            raise ValueError("У объекта нет строкового ID")
        nid = raw["id"]
        if nid in ids:
            raise ValueError(f"Повторный ID в SCHEMA: {nid}")
        ids.add(nid)
        fields = []
        for field in parser.nodes.get(nid, {}).get("fields", {}).values():
            fields.append({key: clean(" ".join(val)) if isinstance(val, list) else val
                           for key, val in field.items()})
        # These properties are displayed on the map or explain its labels.
        extra = ("name", "basis", "implementation_label", "purpose", "invariant", "condition", "effect_label", "source")
        for key in extra:
            if key in raw and isinstance(raw[key], str):
                fields.append({"id": f"@{key}", "title": key, "value": raw[key], "source": ""})
        nodes.append({"id": nid, "type": kind or raw.get("type", "неизвестно"),
                      "name": raw.get("name", nid), "fields": fields, "metadata": raw,
                      "attachments": []})
    unmatched = set(parser.nodes) - ids
    if unmatched:
        raise ValueError("HTML содержит узлы вне SCHEMA: " + ", ".join(sorted(unmatched)))
    by_id = {n["id"]: n for n in nodes}

    def attach(key, content, targets):
        for target in set(targets):
            if target in by_id:
                by_id[target]["attachments"].append({"id": key, "content": content})

    for node in nodes:
        raw = node["metadata"]
        parents = raw.get("parents") or ([raw["parent"]] if raw.get("parent") else [])
        for parent in parents:
            attach(f"parent:{parent}->{node['id']}", {"from": parent, "to": node["id"], "kind": "parent"}, [parent, node["id"]])
        for target in raw.get("targets", []):
            attach(f"target:{node['id']}->{target}", {"from": node["id"], "to": target, "kind": node["type"]}, [node["id"], target])
        for i, step in enumerate(raw.get("steps", [])):
            attach(f"step:{i + 1}", step, [node["id"]])
        for i, bullet in enumerate(raw.get("bullets", [])):
            attach(f"bullet:{i + 1}", bullet, [node["id"]])
    for i, rel in enumerate(schema.get("relations", []), 1):
        attach(f"relation:{i}", rel, [rel.get("from"), rel.get("to")])
    for kind in ("risks", "defects"):
        for obj in schema.get(kind, []):
            key = obj.get("id")
            if not key:
                raise ValueError(f"Объект {kind} без ID")
            targets = list(obj.get("linked_nodes") or obj.get("nodes") or [])
            targets += list(obj.get("guardrails") or [])
            if obj.get("primary_node"):
                targets.append(obj["primary_node"])
            for node in nodes:
                refs = list(node["metadata"].get(kind) or [])
                if kind == "risks":
                    refs += list(node["metadata"].get("descendant_risks") or [])
                if any((ref.get("id") if isinstance(ref, dict) else ref) == key for ref in refs):
                    targets.append(node["id"])
            attach(f"{kind}:{key}", obj, targets)
    # Keep every top-level schema property in the review scope, including
    # objects with missing/broken node references and future schema additions.
    units = []
    for key, value in schema.items():
        if key == "nodes":
            continue
        entries = enumerate(value, 1) if isinstance(value, list) else [(1, value)]
        for position, content in entries:
            units.append({"id": f"/{key}/{position}", "kind": key, "content": content,
                          "checks": RISK_CHECKS if key == "risks" else ["content"]})
    for node in nodes:
        units.append({"id": f"/nodes/{node['id']}/metadata", "kind": "node_metadata",
                      "content": node["metadata"], "checks": ["content"]})
        if node["type"] == "process":
            units.append({"id": f"/nodes/{node['id']}/risk_search", "kind": "risk_search",
                          "content": {"process": node["id"]}, "checks": RISK_AREAS})
    return {"version": VERSION, "passport_sha256": passport_hash,
            "nodes": nodes, "relations": schema.get("relations", []),
            "paths": schema.get("paths", []), "defects": schema.get("defects", []),
            "risks": schema.get("risks", []), "meta": meta,
            "checks": CHECKS, "global_checks": GLOBAL_CHECKS, "units": units,
            "note": "Реестр фактически присутствующего. Отсутствующие объекты и поля ищет разметчик по коду и ОР."}


def pending() -> dict:
    return {"result": "не проверено", "note": "", "evidence": []}


def review_template(inv: dict) -> dict:
    return {"version": VERSION, "passport_sha256": inv["passport_sha256"],
            "global_checks": {key: pending() for key in GLOBAL_CHECKS},
            "units": [{"id": u["id"], "checks": {key: pending() for key in u["checks"]}}
                      for u in inv["units"]],
            "reviewer": "", "nodes": [
                {"id": n["id"], "checks": {key: pending() for key in CHECKS},
                 "fields": [{"id": f["id"], **pending(), "claims": []} for f in n["fields"]],
                 "attachments": [{"id": a["id"], **pending()} for a in n["attachments"]]}
                for n in inv["nodes"]]}


def indexed(rows, label, errors):
    result = {}
    if not isinstance(rows, list):
        errors.append(f"{label}: нужен массив")
        return result
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("id"), str):
            errors.append(f"{label}: запись без строкового ID")
            continue
        if row["id"] in result:
            errors.append(f"{label}: повтор ID {row['id']}")
        result[row["id"]] = row
    return result


def assess_record(record, label, errors):
    if not isinstance(record, dict) or record.get("result") not in RESULTS:
        errors.append(f"{label}: неверная оценка")
        return "не проверено"
    status = record["result"]
    if status == "не проверено":
        return status
    if not isinstance(record.get("note"), str) or not record["note"].strip():
        errors.append(f"{label}: нет объяснения")
    evidence = record.get("evidence")
    if not isinstance(evidence, list) or not evidence or any(not isinstance(e, str) or not e.strip() for e in evidence):
        errors.append(f"{label}: нужны адреса прочитанных источников или строк отчёта с основаниями")
    return status


def claim_coverage(field, reviewed, label, errors):
    """Check quotation coverage, not whether the text was semantically atomized."""
    texts = {part: clean(field.get(part, "")) for part in ("value", "source")}
    masks = {part: [False] * len(txt) for part, txt in texts.items()}
    claims = reviewed.get("claims")
    if not isinstance(claims, list):
        errors.append(f"{label}: нужен массив claims")
        return []
    statuses = []
    for number, claim in enumerate(claims, 1):
        clabel = f"{label}/claim-{number}"
        status = assess_record(claim, clabel, errors)
        statuses.append(status)
        if not isinstance(claim, dict):
            continue
        part = claim.get("part")
        quote = clean(claim.get("quote", "")) if isinstance(claim.get("quote"), str) else ""
        if part not in texts or not quote or quote not in texts[part]:
            errors.append(f"{clabel}: цитата не найдена дословно в value/source")
            continue
        if status == "не проверено":
            continue
        offset = 0
        while True:
            start = texts[part].find(quote, offset)
            if start < 0:
                break
            masks[part][start:start + len(quote)] = [True] * len(quote)
            offset = start + len(quote)
    for part, txt in texts.items():
        if any(not covered and not char.isspace() for covered, char in zip(masks[part], txt)):
            errors.append(f"{label}/{part}: остался текст без разметки")
    return statuses


def check_review(inv: dict, report: dict) -> dict:
    errors = []
    if not isinstance(report.get("reviewer"), str) or not report["reviewer"].strip():
        errors.append("Не указана модель разметчика в reviewer")
    if report.get("version") != VERSION or inv.get("version") != VERSION:
        errors.append("Версия реестра и отчёта должна быть " + VERSION)
    if report.get("passport_sha256") != inv.get("passport_sha256"):
        errors.append("Отчёт относится к другому HTML: SHA-256 не совпадает")
    unit_rows = []
    units = indexed(report.get("units"), "units", errors)
    expected_units = {u["id"] for u in inv["units"]}
    if set(units) - expected_units:
        errors.append("Неизвестные общие объекты: " + ", ".join(sorted(set(units) - expected_units)))
    expected_groups = [("global_checks", list(GLOBAL_CHECKS), report.get("global_checks"))]
    expected_groups += [(u["id"], u["checks"], units.get(u["id"], {}).get("checks")) for u in inv["units"]]
    for label, keys, records in expected_groups:
        before = len(errors)
        statuses = []
        if not isinstance(records, dict):
            errors.append(f"{label}: отсутствует объект checks")
            records = {}
        if set(records) - set(keys):
            errors.append(f"{label}: неизвестные проверки")
        for key in keys:
            status = assess_record(records.get(key), f"{label}/{key}", errors)
            if status == "не применимо" and (label == "global_checks" or key == "content"):
                errors.append(f"{label}/{key}: существующее содержание требует оценки")
            statuses.append(status)
        state = ("Не завершён" if len(errors) > before or "не проверено" in statuses else
                 "Остались вопросы" if "неясно" in statuses else "Проверен полностью")
        unit_rows.append({"id": label, "state": state,
                          "done": sum(s != "не проверено" for s in statuses), "total": len(keys),
                          "issues": any(s in {"ошибка", "частично"} for s in statuses)})
    actual = indexed(report.get("nodes"), "nodes", errors)
    expected = {n["id"] for n in inv["nodes"]}
    if set(actual) - expected:
        errors.append("Неизвестные узлы: " + ", ".join(sorted(set(actual) - expected)))
    rows = []
    for node in inv["nodes"]:
        nid = node["id"]
        local = []
        statuses = []
        got = actual.get(nid)
        fields_done = checks_done = attachments_done = 0
        if got is None:
            local.append(f"{nid}: узел отсутствует в отчёте")
            got = {}
        fields = indexed(got.get("fields", []), nid + "/fields", local)
        expected_fields = {f["id"] for f in node["fields"]}
        if set(fields) - expected_fields:
            local.append(f"{nid}: неизвестные поля " + ", ".join(sorted(set(fields) - expected_fields)))
        for field in node["fields"]:
            label = nid + "/" + field["id"]
            row = fields.get(field["id"])
            before = len(local)
            status = assess_record(row, label, local)
            statuses.append(status)
            claims = []
            if status != "не проверено":
                if status == "не применимо" and any(clean(field.get(part, "")) for part in ("value", "source")):
                    local.append(f"{label}: существующий текст требует содержательной оценки")
                claims = claim_coverage(field, row, label, local)
                statuses.extend(claims)
                if status in {"верно", "не применимо"} and any(s in {"частично", "ошибка", "неясно", "не проверено"} for s in claims):
                    local.append(f"{label}: итог поля скрывает замечание или неопределённость утверждения")
            if status != "не проверено" and len(local) == before and "не проверено" not in claims:
                fields_done += 1
        checks = got.get("checks", {})
        if not isinstance(checks, dict):
            local.append(f"{nid}: checks должен быть объектом")
            checks = {}
        if set(checks) - set(CHECKS):
            local.append(f"{nid}: неизвестные категории проверок")
        for key in CHECKS:
            before = len(local)
            status = assess_record(checks.get(key), nid + "/" + key, local)
            if status == "не применимо" and key in {"identity", "field_completeness", "reverse_search"}:
                local.append(f"{nid}/{key}: обязательная проверка не может быть неприменимой")
            statuses.append(status)
            if status != "не проверено" and len(local) == before:
                checks_done += 1
        attachments = indexed(got.get("attachments", []), nid + "/attachments", local)
        expected_attachments = {a["id"] for a in node["attachments"]}
        if set(attachments) - expected_attachments:
            local.append(f"{nid}: неизвестные связи или привязки")
        for item in node["attachments"]:
            before = len(local)
            status = assess_record(attachments.get(item["id"]), nid + "/" + item["id"], local)
            if status == "не применимо":
                local.append(f"{nid}/{item['id']}: существующая привязка требует оценки")
            statuses.append(status)
            if status != "не проверено" and len(local) == before:
                attachments_done += 1
        unresolved = statuses.count("неясно")
        issues = any(s in {"ошибка", "частично"} for s in statuses)
        if local or "не проверено" in statuses:
            state = "Не завершён"
        elif unresolved:
            state = "Остались вопросы"
        else:
            state = "Проверен полностью"
        rows.append({"id": nid, "name": node["name"], "type": node["type"],
                     "fields_done": fields_done, "fields_total": len(node["fields"]),
                     "attachments_done": attachments_done, "attachments_total": len(node["attachments"]),
                     "checks_done": checks_done, "checks_total": len(CHECKS),
                     "state": state, "issues": issues, "unresolved": unresolved})
        errors.extend(local)
    if errors:
        # A malformed packet cannot receive any global completion claim.
        complete = False
    else:
        complete = all(r["state"] == "Проверен полностью" for r in rows + unit_rows)
    return {"complete": complete, "rows": rows, "units": unit_rows, "errors": errors}


def coverage_markdown(result: dict) -> str:
    def esc(value):
        return str(value).replace("|", "\\|").replace("\n", " ")
    rows = result["rows"]
    totals = {state: sum(r["state"] == state for r in rows)
              for state in ("Проверен полностью", "Остались вопросы", "Не завершён")}
    lines = ["# Покрытие проверки узлов", "", f"Версия {VERSION}.", "",
             "**Сверка полного заполнения: " + ("пройдена" if result["complete"] else "не пройдена") + ".**", "",
             "Это проверка заполнения разметки. Истинность выводов и полноту смыслового поиска оценивают по основаниям.", "",
             "Всего объектов: " + str(len(rows)) + ". " + "; ".join(f"{k}: {v}" for k, v in totals.items()) + ".", "",
             "| Узел | Тип | Поля рассмотрены / всего | Связи и привязки / всего | Проверки / всего | Завершённость | Замечания |",
             "|---|---|---|---|---|---|---|"]
    for r in rows:
        lines.append(f"| {esc(r['id'])} · {esc(r['name'])} | {esc(r['type'])} | {r['fields_done']}/{r['fields_total']} | {r['attachments_done']}/{r['attachments_total']} | {r['checks_done']}/{r['checks_total']} | {r['state']} | {'Есть' if r['issues'] else 'Не отмечены'} |")
    lines += ["", "«Проверен полностью» означает наличие разметки всех перечисленных полей и девяти проверок без неразрешённых вопросов. Узел с доказанной ошибкой тоже может быть полностью проверен.", ""]
    lines += ["## Общие объекты и сквозные проверки", "",
              "Адреса соответствуют units в inventory.json. Метаданные узлов, все элементы SCHEMA, семь критериев каждого риска и семь областей поиска каждого процесса учитываются отдельно.", "",
              "| Адрес | Рассмотрено / всего | Завершённость | Замечания |", "|---|---|---|---|"]
    for r in result["units"]:
        lines.append(f"| {esc(r['id'])} | {r['done']}/{r['total']} | {r['state']} | {'Есть' if r['issues'] else 'Не отмечены'} |")
    lines += ["", "Успех этой сверки не подтверждает полноту исследования исходников или истинность оценок. Состояние всего исследования и открытые границы указываются в review.md.", ""]
    if result["errors"]:
        lines += ["## Нарушения формы", ""] + ["- " + esc(e) for e in result["errors"]]
    return "\n".join(lines) + "\n"


def dump(path: Path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main(argv=None):
    cli = argparse.ArgumentParser(description=__doc__)
    sub = cli.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare", help="Из HTML создать реестр и пустую форму разметки")
    prep.add_argument("--passport", type=Path, required=True)
    prep.add_argument("--out", type=Path, required=True)
    check = sub.add_parser("check", help="Проверить полноту заполнения формы")
    check.add_argument("--passport", type=Path, required=True, help="Тот же исходный HTML")
    check.add_argument("--review", type=Path, required=True)
    check.add_argument("--out", type=Path, required=True, help="Файл сводки Markdown")
    args = cli.parse_args(argv)
    try:
        data = args.passport.read_bytes()
        inv = inventory(data.decode("utf-8-sig"), hashlib.sha256(data).hexdigest())
        if args.command == "prepare":
            if args.out.exists() and any(args.out.iterdir()):
                raise ValueError("Выходная папка непуста; выберите новую папку")
            args.out.mkdir(parents=True, exist_ok=True)
            report = review_template(inv)
            dump(args.out / "inventory.json", inv)
            dump(args.out / "node-review-template.json", report)
            (args.out / "coverage.md").write_text(coverage_markdown(check_review(inv, report)), encoding="utf-8")
            print(f"Создан реестр: {len(inv['nodes'])} объектов. Папка: {args.out}")
            return 0
        if args.out.exists():
            raise ValueError("Файл сводки уже существует; выберите новый путь")
        report = json.loads(args.review.read_text(encoding="utf-8-sig"))
        if not isinstance(report, dict):
            raise ValueError("Отчёт должен быть объектом JSON")
        result = check_review(inv, report)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(coverage_markdown(result), encoding="utf-8")
        print(f"Полная разметка: {result['complete']}. Сводка: {args.out}")
        return 0 if result["complete"] else 2
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print("Ошибка: " + str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

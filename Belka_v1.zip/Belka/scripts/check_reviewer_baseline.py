"""Проверить зафиксированный код-ревьюер; только чтение, без обновления эталона."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path

BASELINE = Path("baselines/code-reviewer-v1")
ROOT = Path(__file__).resolve().parents[1]


def text_digest(path: Path) -> str:
    # Переводы строк и BOM не меняют смысл поставки Windows/Linux.
    text = path.read_text(encoding="utf-8-sig")
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _names(node: ast.AST) -> list[str]:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return [node.name]
    targets = node.targets if isinstance(node, ast.Assign) else (
        [node.target] if isinstance(node, ast.AnnAssign) else [])
    return [target.id for target in targets if isinstance(target, ast.Name)]


def _canonical(value):
    if isinstance(value, ast.AST):
        fields = {}
        for key, child in ast.iter_fields(value):
            if key == "body" and isinstance(value, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                if child and isinstance(child[0], ast.Expr) and isinstance(child[0].value, ast.Constant):
                    if isinstance(child[0].value.value, str):
                        child = child[1:]  # Описания не фиксируют поведение функции.
            # Новые версии Python добавляют пустые необязательные поля AST.
            if child is not None and child != []:
                fields[key] = _canonical(child)
        return {"type": type(value).__name__, **fields}
    if isinstance(value, list):
        return [_canonical(child) for child in value]
    if isinstance(value, bytes):
        return {"bytes": value.hex()}
    if value is Ellipsis:
        return {"ellipsis": True}
    return value


def symbol_digest(tree: ast.Module, selector: str) -> str:
    node: ast.AST = tree
    for part in selector.split("."):
        matches = [child for child in getattr(node, "body", []) if part in _names(child)]
        if len(matches) != 1:
            raise ValueError(f"{selector}: ожидалось одно определение {part}, найдено {len(matches)}")
        node = matches[0]
    payload = json.dumps(_canonical(node), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def check(root: Path = ROOT) -> list[str]:
    """Вернуть отличия защищённой части; паспортные функции не ограничиваются."""
    errors = []
    try:
        manifest = json.loads((root / BASELINE / "manifest.json").read_text(encoding="utf-8"))
        if manifest["baseline_id"] != "code-reviewer-v1" or manifest["format_version"] != 1:
            return ["Неизвестная версия эталона код-ревьюера"]
        archive = root / BASELINE / "sources.zip"
        if hashlib.sha256(archive.read_bytes()).hexdigest() != manifest["snapshot_sha256"]:
            errors.append("Повреждён снимок baselines/code-reviewer-v1/sources.zip")
        for name, expected in manifest["files"].items():
            try:
                if text_digest(root / name) != expected:
                    errors.append(f"Изменён файл ревьюера: {name}")
            except (OSError, UnicodeError) as exc:
                errors.append(f"Недоступен файл ревьюера {name}: {exc}")
        for name, symbols in manifest["symbols"].items():
            try:
                tree = ast.parse((root / name).read_text(encoding="utf-8-sig"))
                for selector, expected in symbols.items():
                    try:
                        if symbol_digest(tree, selector) != expected:
                            errors.append(f"Изменено правило ревьюера: {name}::{selector}")
                    except ValueError as exc:
                        errors.append(f"{name}: {exc}")
            except (OSError, UnicodeError, SyntaxError) as exc:
                errors.append(f"Не удалось проверить {name}: {exc}")
    except (OSError, UnicodeError, ValueError, KeyError, TypeError) as exc:
        errors.append(f"Не удалось прочитать эталон: {exc}")
    return errors


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT, help="Корень проверяемой копии Белки")
    args = parser.parse_args(argv)
    errors = check(args.root.resolve())
    if errors:
        print("Код-ревьюер отличается от code-reviewer-v1:")
        for error in errors:
            print(f"  - {error}")
        print("Не обновляйте эталон автоматически: проверьте, затрагивалась ли оценка кода намеренно.")
        return 1
    print("OK: код-ревьюер соответствует code-reviewer-v1")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

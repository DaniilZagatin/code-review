"""Общие настройки репозитория и LLM для CLI и аналитического конвейера.
"""

from __future__ import annotations

# Целевой репозиторий по умолчанию: клонируется зеркалом, read-only, через
# ssh-agent пользователя (см. pko/git/remote.py).
DEFAULT_REPOSITORY = "ssh://git@stash.delta.sbrf.ru:7999/dsd3k/dkkk_copilot.git"
DEFAULT_BRANCH = "copilot_dev"

# Эндпоинт роли matcher по умолчанию — внутренний AI Hub с GLM-5.2
# (OpenAI-совместимый /chat/completions). То же значение, что в .env проекта
# и scripts/run_tests_live.py. Ключ по-прежнему берётся только из переменных
# окружения (см. pko/llm/registry.py); без ключа эндпоинт работает по
# «not-needed», как и раньше.
GLM_BASE_URL = "http://tpgds-aihub0009.delta.sbrf.ru:2717/v1"
DEFAULT_MODEL = "GLM-5.2"

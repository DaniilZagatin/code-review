"""Параллельные CLI-прогоны сериализуют доступ к общему зеркалу."""
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock
from pko.git import remote


class MirrorLock(unittest.TestCase):
    """Два прогона по одному репозиторию не клонируют его одновременно."""

    def test_concurrent_clones_of_one_repo_are_serialised(self) -> None:
        url = "ssh://git@stash.local:7999/proj/repo.git"
        guard = threading.Lock()
        state = {"active": 0, "peak": 0}
        calls: list[str] = []

        def fake_run_git(args: list[str], timeout: int, ref: object) -> str:
            with guard:
                state["active"] += 1
                state["peak"] = max(state["peak"], state["active"])
            try:
                time.sleep(0.05)
                if args[0] == "clone":
                    dest = Path(args[-1])
                    dest.mkdir(parents=True, exist_ok=True)
                    (dest / "HEAD").write_text("ref: refs/heads/master\n", encoding="utf-8")
                    calls.append("clone")
                    return ""
                if "config" in args:
                    return url + "\n"
                if "update" in args:
                    calls.append("fetch")
                return ""
            finally:
                with guard:
                    state["active"] -= 1

        errors: list[BaseException] = []

        def run(root: Path) -> None:
            try:
                remote.ensure_mirror(url, cache_root=root)
            except BaseException as exc:  # noqa: BLE001 — нужен сам факт
                errors.append(exc)

        with tempfile.TemporaryDirectory() as raw, \
                mock.patch.object(remote, "_run_git", fake_run_git):
            root = Path(raw)
            threads = [threading.Thread(target=run, args=(root,)) for _ in range(3)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join(timeout=30)

        self.assertEqual(errors, [])
        self.assertEqual(state["peak"], 1, "git работал с одним зеркалом из двух потоков сразу")
        self.assertEqual(calls.count("clone"), 1)
        self.assertEqual(calls.count("fetch"), 2)


if __name__ == "__main__":
    unittest.main()

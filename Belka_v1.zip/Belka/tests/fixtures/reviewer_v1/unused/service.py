def register_request(text):
    return {"text": text, "status": "registered"}


def handle(text):
    return {"status": "manual"}

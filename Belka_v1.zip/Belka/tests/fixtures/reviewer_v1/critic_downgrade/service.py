def register_request(text):
    return {"text": text, "status": "registered"}


def deliver_request(request):
    raise NotImplementedError("delivery is not implemented")


def handle(text):
    return deliver_request(register_request(text))

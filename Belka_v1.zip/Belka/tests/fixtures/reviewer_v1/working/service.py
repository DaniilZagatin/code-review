def register_request(text):
    return {"text": text, "status": "registered"}


def deliver_request(request):
    request["status"] = "delivered"
    return request


def handle(text):
    return deliver_request(register_request(text))

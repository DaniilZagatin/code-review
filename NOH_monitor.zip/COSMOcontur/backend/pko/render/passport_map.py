"""Карта дерева паспорта — общий компонент для паспорта и CJ Hack.

Один и тот же CSS и JS рисуют схему путь → процесс → BBB → операция с
зумом (колесо, кнопки, FIT) и панорамой перетаскиванием. Дерево — каркас
раскладки: узел стоит под первым родителем; остальные родители (общий
BBB в нескольких процессах) и связи (`relations`: предшествует,
запускает, передаёт данные…) рисуются рёбрами поверх дерева, как и пути
сценариев. Узлы до развилки (`before_fork` — классификатор обращения,
проверка прав) стоят полосой между путём и процессами: они выполняются
до выбора процесса, и дерево это показывает, а не прячет в пятикратном
дублировании. Источник узлов у потребителей разный:

* паспорт (`client_journey_passport`) собирает узлы из карточек шаблона в
  DOM и по клику клонирует карточку в боковую панель;
* CJ Hack (`cjhack/build.py`) получает узлы из контракта дашборда
  (`passport.tree`) и показывает по клику название, основание и ссылку на
  полный паспорт.

Функция `pkoPassportMap(viewport, nodes, options)` строит карту в
контейнере и возвращает `{select, fit, nodes, relations}`;
`options.onSelect(node, byId, relations)` вызывается по клику на узел (не
по перетаскиванию); `options.relations` — список `{from, to, kind,
kind_label, basis}`; `options.paths` — пути сценариев.

Узел: `{id, type, name, basis, parent, parents: [id, …], before_fork,
planned}`; `type` — journey | process | bbb | operation. Статус
реализации остаётся данными узла для карточки и реестра; сама карта
показывает только подтверждённые разрывы знаком `!`.

Рёбра поверх дерева — со стрелкой и в цвете вида (`REL_STYLE` в JS,
легенда — из того же списка): предшествует, передаёт данные, запускает,
зависит от, запасной путь, подтверждает; второй родитель — пунктир.
Подпись вида стоит на каждой связи, наведение показывает основание,
выбор узла гасит всё, что к нему не относится. Рёбра одного узла
разводятся по параллельным полкам, пути сценариев — по своим.
"""

from __future__ import annotations

import json
import re
from typing import Any

from pko.progress.passport_gate import (
    BRANCHING_LABEL,
    CRITICAL_FIELDS,
    DEFECT_KIND_LABEL,
    RISK_CONFIDENCE_LABEL,
    RISK_SCOPE_LABEL,
    SOURCE_LEVELS,
)
from pko.progress.schema import (
    CHECK_RESULT_LABEL,
    HANDOFF_CHECK_LABEL,
    HANDOFF_CHECKS,
    HANDOFF_KIND_LABEL,
    SCENARIO_STATUS_LABEL,
    STATUS_LABEL,
    ProgressModel,
    calculate_progress,
)

# Подписи критичных полей — для объяснения, почему статус узла ограничен.
_FIELD_LABEL = {
    "4.3.4": "Условия запуска", "4.3.6": "Допустимые BBB и режимы исполнения",
    "4.4.4": "Контракт выхода", "4.4.6": "Способы исполнения",
    "4.5.4": "Проверяемый эффект", "4.5.5": "Вход и выход", "4.5.6": "Повтор, отмена и компенсация",
}
# Уровни основания, при которых поле считается установленным.
_GROUNDED_LEVELS = ("Установлено", "Выведено")
# Разрыв на стыке → вид дефекта.
_CHECK_DEFECT_KIND = {
    "reachability": "integration", "contract": "integration", "sequence_state": "integration",
    "data_continuity": "data", "wiring": "wiring", "obligation": "completeness",
}

PASSPORT_MAP_CSS = """
.pko-viewport{position:relative;flex:1;min-height:0;overflow:hidden;cursor:default;background:#F8FAFC;background-image:radial-gradient(#DCE3E9 .8px,transparent .8px);background-size:20px 20px;user-select:none;touch-action:none;color:#18232E}
.pko-viewport.dragging{cursor:default}
.pko-viewport .pko-box{cursor:default}
.pko-canvas{position:absolute;left:0;top:0;transform-origin:0 0;padding:88px 56px 40px;will-change:transform}
.pko-tree,.pko-tree ul{display:flex;justify-content:center;list-style:none;margin:0;padding:28px 0 0;position:relative}
.pko-tree{padding-top:0}
.pko-tree li{display:flex;flex-direction:column;align-items:center;padding:28px 8px 0;position:relative}
.pko-tree>li{padding-top:0}
.pko-tree li::before,.pko-tree li::after{content:'';position:absolute;top:0;right:50%;width:50%;height:28px;border-top:1px solid #AEBAC4}
.pko-tree li::after{right:auto;left:50%;border-left:1px solid #AEBAC4}
.pko-tree>li::before,.pko-tree>li::after{display:none}
.pko-tree li:only-child::before,.pko-tree li:only-child::after{border-top:0}
.pko-tree li:only-child::after{border-left:1px solid #AEBAC4}
.pko-tree li:first-child::before,.pko-tree li:last-child::after{border:0}
.pko-tree li:last-child::before{border-right:1px solid #AEBAC4;border-radius:0 8px 0 0}
.pko-tree li:first-child::after{border-radius:8px 0 0 0}
.pko-tree ul::before{content:'';position:absolute;top:0;left:50%;width:0;height:28px;border-left:1px solid #AEBAC4}
/* Полоса «до развилки»: узлы, которые выполняются до выбора процесса. */
.pko-gate{display:flex;flex-direction:column;align-items:center;gap:2px;padding:34px 14px 10px;border:1.5px dashed #8B78D8;border-radius:14px;background:rgba(240,236,255,.6)}
.pko-gate .gc{display:flex;flex-direction:column;align-items:center;gap:1px;margin-top:10px}
.pko-gate .gl{font-size:10px;font-weight:800;letter-spacing:.07em;text-transform:uppercase;color:#5C45B8}
.pko-gate .gs{font-size:10px;color:#6D7D8A}
.pko-tree ul.pko-gate-row{display:flex;gap:22px;padding:0}
.pko-tree ul.pko-gate-row::before{display:none}
.pko-tree ul.pko-gate-row>li{padding-top:0}
.pko-tree ul.pko-gate-row>li::before,.pko-tree ul.pko-gate-row>li::after{display:none}
.pko-box{display:flex;flex-direction:column;gap:6px;min-width:164px;max-width:228px;padding:11px 12px;border:1px solid #C8D1D9;border-radius:10px;background:#fff;cursor:pointer;text-align:left;font-family:inherit;color:#18232E;box-shadow:0 3px 10px rgba(30,48,65,.06);transition:box-shadow .16s ease,border-color .16s ease,background-color .16s ease,opacity .16s ease}
.pko-box:hover{border-color:#7C5CE6;box-shadow:0 8px 22px rgba(51,65,85,.14)}
.pko-box:focus-visible{outline:3px solid rgba(124,92,230,.38);outline-offset:2px;border-color:#7C5CE6}
.pko-box.active{border-color:#6D4BE0;background:#F8F5FF;box-shadow:0 0 0 3px rgba(124,92,230,.18),0 10px 24px rgba(51,65,85,.12)}
.pko-box.related{box-shadow:0 0 0 3px rgba(124,92,230,.22)}
.pko-box .sh{font-size:10px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;border-radius:5px;padding:2px 6px;align-self:flex-start;background:#EEF1FB;color:#3E4C9A}
.pko-box .sh.gate{background:#F0ECFF;color:#5C45B8}
.pko-box .sh.planned{background:#FCE5EB;color:#9C1833}
.pko-box .sh.branch{background:#FFF7E6;color:#8B5A00}
.pko-box .sh.defects{background:#FCE5EB;color:#9C1833;cursor:pointer}
.pko-box .sh.risks{background:#FFF1D6;color:#85510A}
.pko-tree li.pko-hidden{display:none}
.pko-box .t{font-size:10px;font-weight:800;letter-spacing:.07em;text-transform:uppercase;color:#6D4BE0;background:#F0ECFF;border-radius:5px;padding:2px 6px;align-self:flex-start}
.pko-box[data-type=process] .t{color:#5C45B8;background:#F0ECFF}
.pko-box[data-type=bbb] .t{color:#1769AA;background:#EAF4FF}
.pko-box[data-type=operation] .t{color:#08736E;background:#E2F6F4}
.pko-box .n{font-size:13px;font-weight:700;color:#18232E;line-height:1.28;overflow-wrap:anywhere}
.pko-box .i{display:none}
.pko-box .r{display:flex;align-items:center;gap:7px;font-size:11px;font-weight:800;color:#526373;font-variant-numeric:tabular-nums}
.pko-box .r .bar{flex:1;height:4px;border-radius:99px;background:#E7ECF0;overflow:hidden}
.pko-box .r .bar i{display:block;height:100%;background:#92A2B0}
.pko-box[data-band=good]{border-color:#2CB6B0}.pko-box[data-band=good] .r .bar i{background:#2CB6B0}
.pko-box[data-band=mid]{border-color:#E0A100}.pko-box[data-band=mid] .r .bar i{background:#E0A100}
.pko-box[data-band=bad]{border-color:#E2556F}.pko-box[data-band=bad] .r .bar i{background:#E2556F}
.pko-box[data-band=none] .r{color:#B7C2CB;font-weight:500}
.pko-box .s{font-size:10px;font-weight:800;line-height:1.25;border-radius:5px;padding:3px 6px;align-self:flex-start;background:#F0F2F2;color:#405160}
.pko-box[data-implementation=implemented]{border-color:#16857F}.pko-box[data-implementation=implemented] .s{background:#DDF5F2;color:#09615D}
.pko-box[data-implementation=partial]{border-color:#C66A1B}.pko-box[data-implementation=partial] .s{background:#FFF0E2;color:#8B430C}
.pko-box[data-implementation=not_implemented]{border-color:#C73955}.pko-box[data-implementation=not_implemented] .s{background:#FCE5EB;color:#9C1833}
.pko-box[data-implementation=unknown]{border-style:dashed;border-color:#7A8995}.pko-box[data-implementation=unknown] .s{background:#F0F2F2;color:#405160}
.pko-box[data-planned=true]{border-style:dashed;background:#FFFBFC}
.pko-box .m{font-size:10px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;border-radius:5px;padding:2px 6px;align-self:flex-start}
.pko-box .m.broken{background:#FCE5EB;color:#E2556F}
.pko-box .m.unknown{background:#F0F2F2;color:#5A6D7C}
.pko-box.dim{opacity:.28;filter:saturate(.35)}
.pko-viewport.focus .pko-box:not(.active):not(.related){opacity:.55}
/* Рёбра поверх дерева. Каждый вид связи — свой цвет и штрих, у всех стрелка. */
.pko-paths{position:absolute;left:0;top:0;overflow:visible;pointer-events:none;z-index:2}
.pko-paths path{fill:none;stroke-linecap:round;stroke-linejoin:round}
.pko-paths .hit{stroke:transparent;stroke-width:12;pointer-events:stroke;cursor:default}
.pko-paths .edge{stroke-width:3;transition:opacity .16s ease}
.pko-paths .edge.ok{stroke:#2CB6B0}.pko-paths .edge.broken{stroke:#E2556F;stroke-dasharray:7 5}.pko-paths .edge.unknown{stroke:#92A2B0;stroke-dasharray:2 5}
.pko-paths .parent-link{stroke:#6D4BE0;stroke-width:1.5;stroke-dasharray:6 4;opacity:.8;transition:opacity .16s ease}
.pko-paths .rel{stroke-width:1.75;opacity:.85;transition:opacity .16s ease,stroke-width .16s ease}
.pko-paths .rel.precedes{stroke:#475569}
.pko-paths .rel.feeds{stroke:#2563EB}
.pko-paths .rel.triggers{stroke:#C2410C;stroke-width:2.25}
.pko-paths .rel.depends_on{stroke:#7C3AED;stroke-dasharray:5 3}
.pko-paths .rel.fallback{stroke:#B45309;stroke-dasharray:9 4}
.pko-paths .rel.confirms{stroke:#15803D;stroke-dasharray:2 4}
.pko-paths .rel.hl,.pko-paths .parent-link.hl,.pko-paths .edge.hl{opacity:1;stroke-width:3}
.pko-paths .rel.hover,.pko-paths .parent-link.hover{opacity:1;stroke-width:3.5}
.pko-paths.focus .rel:not(.hl):not(.hover),.pko-paths.focus .parent-link:not(.hl):not(.hover){opacity:.1}
.pko-paths.focus .edge:not(.hl){opacity:.14}
.pko-paths.focus .lbl:not(.hl){display:none}
.pko-paths .lbl rect{fill:#fff;stroke:#CBD5DE;stroke-width:1;rx:4;ry:4}
.pko-paths .lbl text{font-size:10px;font-weight:700;font-family:inherit;fill:#334155;dominant-baseline:middle;text-anchor:middle}
.pko-paths .lbl.precedes text{fill:#475569}.pko-paths .lbl.precedes rect{stroke:#94A3B8}
.pko-paths .lbl.feeds text{fill:#1D4ED8}.pko-paths .lbl.feeds rect{stroke:#93C5FD}
.pko-paths .lbl.triggers text{fill:#C2410C}.pko-paths .lbl.triggers rect{stroke:#FDBA74}
.pko-paths .lbl.depends_on text{fill:#6D28D9}.pko-paths .lbl.depends_on rect{stroke:#C4B5FD}
.pko-paths .lbl.fallback text{fill:#B45309}.pko-paths .lbl.fallback rect{stroke:#FCD34D}
.pko-paths .lbl.confirms text{fill:#15803D}.pko-paths .lbl.confirms rect{stroke:#86EFAC}
.pko-paths .lbl.includes text{fill:#5C45B8}.pko-paths .lbl.includes rect{stroke:#C4B5FD;stroke-dasharray:3 2}
.pko-paths .lbl.hl rect{stroke-width:1.5}
.pko-paths.nolabels .lbl:not(.hl):not(.hover){display:none}
.pko-paths text.break-label{font-size:11px;font-weight:700;fill:#E2556F;font-family:inherit;paint-order:stroke;stroke:#F8FAFC;stroke-width:3px;text-anchor:middle}
.pko-paths text.skip-label{fill:#92A2B0;font-size:10px;font-weight:600;font-family:inherit;paint-order:stroke;stroke:#F8FAFC;stroke-width:3px;text-anchor:middle}
.pko-legend{position:absolute;left:14px;right:72px;top:12px;z-index:5;display:flex;flex-direction:column;gap:8px;width:max-content;max-width:calc(100% - 94px);padding:8px 10px;border:1px solid rgba(203,213,225,.9);border-radius:10px;background:rgba(255,255,255,.94);box-shadow:0 8px 24px rgba(30,48,65,.09);backdrop-filter:blur(8px)}
.pko-legend .row{display:flex;flex-wrap:wrap;gap:6px}
.pko-legend.inline{position:static;width:auto;max-width:none;padding:6px 0 0;border:0;background:transparent;box-shadow:none;backdrop-filter:none;gap:4px}
.pko-legend.inline .pko-key{font-size:10.5px;gap:3px 9px}
.pko-legend.inline .pko-chip{min-height:26px;padding:3px 8px;font-size:11px}
.pko-legend.inline .pko-chip.layer{min-height:24px;font-size:10.5px}
.pko-legend.inline .row{gap:4px}
.pko-chip{min-height:34px;display:inline-flex;align-items:center;gap:7px;font-size:12px;font-weight:650;padding:6px 10px;border:1px solid #CBD5DE;border-radius:8px;background:#fff;cursor:pointer;font-family:inherit;color:#263746;transition:border-color .16s ease,background-color .16s ease,box-shadow .16s ease}
.pko-chip:hover{border-color:#8B78D8}
.pko-chip:focus-visible{outline:3px solid rgba(124,92,230,.3);outline-offset:1px}
.pko-chip.on{border-color:#7C5CE6;background:#F5F1FF;box-shadow:inset 0 0 0 1px rgba(124,92,230,.08)}
.pko-chip.layer{min-height:28px;padding:3px 9px;font-size:11px}
.pko-chip .dot{width:8px;height:8px;border-radius:50%;background:#92A2B0}
.pko-chip .dot.assembled{background:#2CB6B0}.pko-chip .dot.broken{background:#E2556F}.pko-chip .dot.unknown{background:#92A2B0}
.pko-key{font-size:11px;color:#526373;display:flex;flex-wrap:wrap;gap:5px 12px;line-height:1.35;align-items:center}
.pko-key span{white-space:nowrap;display:inline-flex;align-items:center;gap:4px}
.pko-key b{display:inline-block;width:9px;height:9px;border-radius:3px;vertical-align:-1px}
.pko-key svg{width:26px;height:10px;overflow:visible}
.pko-key .kh{font-weight:800;color:#3B4A58;letter-spacing:.04em;text-transform:uppercase;font-size:10px}
.pko-zoom{position:absolute;right:14px;bottom:14px;display:flex;gap:6px;z-index:5;padding:5px;border:1px solid #D7DEE4;border-radius:11px;background:rgba(255,255,255,.94);box-shadow:0 8px 24px rgba(30,48,65,.10)}
.pko-zoom button{width:38px;height:38px;border:0;border-radius:7px;background:#fff;cursor:pointer;font-size:18px;line-height:1;color:#18232E;font-family:inherit}
.pko-zoom button:hover{background:#F0ECFF;color:#5C45B8}
.pko-zoom button:focus-visible{outline:3px solid rgba(124,92,230,.3);outline-offset:0}
.pko-zoom .pko-zoom-fit{font-size:12px;font-weight:700;letter-spacing:.04em}

.pko-hint{position:absolute;left:14px;bottom:14px;font-size:11px;color:#6D7D8A;background:rgba(255,255,255,.92);border:1px solid #E1E7EB;border-radius:8px;padding:6px 9px;pointer-events:none}
.pko-tip{position:absolute;z-index:6;max-width:340px;padding:8px 10px;border:1px solid #CBD5DE;border-radius:8px;background:#fff;box-shadow:0 8px 24px rgba(30,48,65,.14);font-size:12px;line-height:1.4;color:#18232E;pointer-events:none;display:none}
.pko-tip b{display:block;font-size:11px;letter-spacing:.04em;text-transform:uppercase;margin-bottom:3px}
.pko-tip .basis{color:#526373;margin-top:3px}
@media(max-width:768px){.pko-canvas{padding:116px 28px 36px}.pko-box{min-width:148px;max-width:194px}.pko-legend{right:14px;max-width:calc(100% - 28px)}.pko-hint{display:none}}
@media(prefers-reduced-motion:reduce){.pko-box,.pko-chip,.pko-paths path{transition:none!important}}
"""

PASSPORT_MAP_CSS += """
.pko-tree li::before,.pko-tree li::after,.pko-tree ul::before{display:none!important}
.pko-paths .connection{fill:none;stroke:#9ca7a1;stroke-width:1.4;stroke-dasharray:none;marker-end:none}
.pko-paths.focus .connection{opacity:.15}.pko-paths.focus .connection.hl{opacity:1;stroke:#506d5d;stroke-width:1.8}
"""

PASSPORT_MAP_JS = """
window.pkoPassportMap=function(viewport,nodes,options){
  options=options||{};
  var TYPE_LABEL={journey:'КП',process:'Процесс',bbb:'BBB',operation:'Операция'};
  // Виды связей: подпись и цвет — один список для рёбер, подписей и легенды.
  var REL_KINDS=[
    {kind:'precedes',label:'предшествует',color:'#475569',dash:''},
    {kind:'feeds',label:'передаёт данные',color:'#2563EB',dash:''},
    {kind:'triggers',label:'запускает',color:'#C2410C',dash:''},
    {kind:'depends_on',label:'зависит от',color:'#7C3AED',dash:'5 3'},
    {kind:'fallback',label:'запасной путь для',color:'#B45309',dash:'9 4'},
    {kind:'confirms',label:'подтверждает',color:'#15803D',dash:'2 4'}
  ];
  var REL_BY_KIND={}; REL_KINDS.forEach(function(k){REL_BY_KIND[k.kind]=k});
  var seq=(window.__pkoMapSeq=(window.__pkoMapSeq||0)+1), mid='pko'+seq+'-';
  var byId={}, order=[];
  (nodes||[]).forEach(function(n){
    if(!n||!n.id||byId[n.id]) return;
    var parents=(n.parents||(n.parent?[n.parent]:[])).slice();
    byId[n.id]={id:n.id,type:n.type||n.id.split('-')[0],name:n.name||'',basis:n.basis||'',parents:parents,parent:parents[0]||null,children:[],beforeFork:!!n.before_fork,planned:!!n.planned,branching:n.branching||'',data:n};
    order.push(n.id);
  });
  // Родитель, которого нет среди узлов («—» у корня в реестре), — не родитель.
  // Первый родитель — место узла в дереве; остальные — включения поверх дерева.
  order.forEach(function(id){var n=byId[id]; n.parents=n.parents.filter(function(p){return !!byId[p]}); n.parent=n.parents[0]||null; n.parents.forEach(function(p){byId[p].children.push(id);});});
  var relations=(options.relations||[]).filter(function(r){return r&&byId[r.from]&&byId[r.to]&&r.kind!=='includes'});
  var roots=order.filter(function(id){return byId[id].type==='journey'&&!byId[id].parent});

  viewport.classList.add('pko-viewport');
  var canvas=document.createElement('div'); canvas.className='pko-canvas';
  var moved=false, current=null, hovered=null;
  function box(n){
    var b=document.createElement('button'); b.type='button'; b.className='pko-box'; b.dataset.id=n.id; b.dataset.type=n.type;
    b.innerHTML='<span class="t"></span><span class="n"></span><span class="i"></span>';
    b.querySelector('.t').textContent=TYPE_LABEL[n.type]||n.type;
    b.querySelector('.n').textContent=n.name||'[без названия]';
    b.querySelector('.i').textContent=n.id;
    var d=n.data||{};
    if(n.beforeFork){var g=document.createElement('span'); g.className='sh gate'; g.textContent='до развилки'; b.appendChild(g);}
    if(n.parents.length>1){var sh=document.createElement('span'); sh.className='sh'; sh.textContent='общий · родителей: '+n.parents.length; b.appendChild(sh);}
    if(n.branching&&n.branching!=='sequence'){var br=document.createElement('span'); br.className='sh branch'; br.textContent=d.branching_label||n.branching; b.appendChild(br);}
    if(Array.isArray(d.defects)&&d.defects.length){var df=document.createElement('span'); df.className='sh defects'; df.textContent='дефектов: '+d.defects.length; b.appendChild(df);}
    if(Array.isArray(d.risks)&&d.risks.length){var rk=document.createElement('span'); rk.className='sh risks'; rk.textContent='рисков: '+d.risks.length; b.appendChild(rk);}
    b.setAttribute('aria-label',(TYPE_LABEL[n.type]||n.type)+' «'+(n.name||'[без названия]')+'»'+(d.mark==='broken'?'; разрыв процесса':'')+(Array.isArray(d.risks)&&d.risks.length?'; операционных рисков: '+d.risks.length:''));
    if(d.mark==='broken'){ var m=document.createElement('span'); m.className='m broken'; m.textContent='!'; m.title='Разрыв процесса'; b.appendChild(m); }
    b.addEventListener('click',function(e){if(e.detail===0) select(n.id);});
    return b;
  }
  function subtree(n){
    var item=document.createElement('li'); item.appendChild(box(n));
    // Общий узел раскрывается только под первым родителем: под остальными
    // его место показывает пунктирное ребро.
    var kids=n.children.filter(function(c){return byId[c].parent===n.id});
    if(n.type==='journey'){
      // Узлы до развилки — полосой между путём и процессами: они выполняются
      // до выбора процесса, и на схеме стоят раньше него.
      var gates=kids.filter(function(c){return byId[c].beforeFork}), procs=kids.filter(function(c){return !byId[c].beforeFork});
      if(gates.length){
        var lane=document.createElement('ul'); var laneLi=document.createElement('li'); laneLi.className='pko-lane';
        var gate=document.createElement('div'); gate.className='pko-gate';
        var row=document.createElement('ul'); row.className='pko-gate-row';
        gates.forEach(function(c){row.appendChild(subtree(byId[c]))});
        gate.appendChild(row);
        var cap=document.createElement('div'); cap.className='gc'; cap.innerHTML='<span class="gl">До развилки</span><span class="gs">выполняется до выбора процесса, для всех процессов</span>'; gate.appendChild(cap);
        laneLi.appendChild(gate);
        if(procs.length){var pul=document.createElement('ul'); procs.forEach(function(c){pul.appendChild(subtree(byId[c]))}); laneLi.appendChild(pul);}
        lane.appendChild(laneLi); item.appendChild(lane);
        return item;
      }
      kids=procs;
    }
    if(kids.length){var ul=document.createElement('ul'); kids.forEach(function(c){ul.appendChild(subtree(byId[c]))}); item.appendChild(ul);}
    return item;
  }
  var tree=document.createElement('ul'); tree.className='pko-tree';
  roots.forEach(function(id){tree.appendChild(subtree(byId[id]))});
  canvas.appendChild(tree);
  // Пути сценариев, вторые родители и связи — SVG поверх дерева в
  // координатах холста: масштаб и сдвиг применяются к холсту целиком,
  // пересчитывать линии при зуме не надо.
  var svg=document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('class','pko-paths'); canvas.appendChild(svg);
  var tip=document.createElement('div'); tip.className='pko-tip'; viewport.appendChild(tip);
  var paths=(options.paths||[]).slice();
  var activePaths={}; paths.forEach(function(p){activePaths[p.id]=true;});
  var layers={relations:true,labels:true,parents:true};
  // Уровень детализации: при отдалении узлы схлопываются до процессов, при
  // приближении раскрываются до операций. Рёбра к скрытому узлу ведут к его
  // ближайшему видимому предку.
  var LEVEL={journey:0,process:1,bbb:2,operation:3};
  var detail='operation', autoDetail=true;
  function visibleId(id){
    var n=byId[id];
    while(n&&LEVEL[n.type]>LEVEL[detail]&&n.parent) n=byId[n.parent];
    return n?n.id:id;
  }
  function applyDetail(){
    Array.prototype.forEach.call(viewport.querySelectorAll('.pko-tree li'),function(li){
      var b=li.querySelector(':scope > .pko-box'); if(!b) return;
      li.classList.toggle('pko-hidden',LEVEL[b.dataset.type]>LEVEL[detail]);
    });
  }
  function setDetail(next,manual){
    if(manual) autoDetail=false;
    if(next===detail){applyDetail(); return;}
    detail=next; applyDetail(); drawPaths();
  }
  function anchor(id){
    id=visibleId(id);
    var b=viewport.querySelector('.pko-box[data-id="'+id+'"]'); if(!b) return null;
    var r=b.getBoundingClientRect(), c=canvas.getBoundingClientRect();
    return {x:(r.left-c.left)/scale, y:(r.top-c.top)/scale, w:r.width/scale, h:r.height/scale};
  }
  // Разводка рёбер поверх дерева, всегда от a к b (стрелка на конце). Узлы
  // в одной строке соединяет дуга над ними; узлы на разных уровнях —
  // ортогональный маршрут: выход из узла вверх или вниз, полка над/под
  // строкой, спуск по коридору сбоку от целевого узла и вход в его боковую
  // грань. `off` — номер полки: рёбра одного узла и параллельные пути
  // сценариев идут по соседним полкам, а не друг по другу.
  var LANE=16, GUTTER=8, STEP=5;
  function curve(a,b,off){
    off=off||0;
    var ac=a.x+a.w/2, bc=b.x+b.w/2, o=off*STEP;
    if(Math.abs(a.y-b.y)<8){
      var ltr=a.x<b.x, x1=a.x+a.w*(ltr?.72:.28), x2=b.x+b.w*(ltr?.28:.72), y=Math.min(a.y,b.y), h=26+o;
      return {d:'M'+x1+','+y+' C'+x1+','+(y-h)+' '+x2+','+(y-h)+' '+x2+','+y, mx:(x1+x2)/2, my:y-h*.75-2};
    }
    if(b.y>a.y+a.h-1){
      var dir=bc>ac?1:-1, side=dir>0?b.x:b.x+b.w, gx=side-dir*(GUTTER+o), ly=a.y+a.h+LANE+o, ty=b.y+b.h/2;
      if(Math.abs(gx-ac)<8) return {d:'M'+ac+','+(a.y+a.h)+' L'+ac+','+b.y, mx:ac+6, my:(a.y+a.h+b.y)/2};
      return {d:'M'+ac+','+(a.y+a.h)+' L'+ac+','+ly+' L'+gx+','+ly+' L'+gx+','+ty+' L'+side+','+ty, mx:(ac+gx)/2, my:ly};
    }
    var dir2=bc>ac?1:-1, side2=dir2>0?b.x:b.x+b.w, gx2=side2-dir2*(GUTTER+o), ly2=a.y-LANE-o, ty2=b.y+b.h/2;
    if(gx2>a.x-GUTTER&&gx2<a.x+a.w+GUTTER){ dir2=-dir2; side2=dir2>0?b.x:b.x+b.w; gx2=side2-dir2*(GUTTER+o); }
    return {d:'M'+ac+','+a.y+' L'+ac+','+ly2+' L'+gx2+','+ly2+' L'+gx2+','+ty2+' L'+side2+','+ty2, mx:(ac+gx2)/2, my:ly2};
  }
  function svgEl(tag,cls){var el=document.createElementNS('http://www.w3.org/2000/svg',tag); if(cls) el.setAttribute('class',cls); return el;}
  function marker(id,color){
    var m=svgEl('marker'); m.setAttribute('id',id); m.setAttribute('viewBox','0 0 10 10'); m.setAttribute('refX','9'); m.setAttribute('refY','5');
    m.setAttribute('markerWidth','9'); m.setAttribute('markerHeight','9'); m.setAttribute('markerUnits','userSpaceOnUse'); m.setAttribute('orient','auto');
    var p=svgEl('path'); p.setAttribute('d','M0,0 L10,5 L0,10 z'); p.setAttribute('fill',color); m.appendChild(p); return m;
  }
  function defs(){
    var d=svgEl('defs');
    REL_KINDS.forEach(function(k){d.appendChild(marker(mid+k.kind,k.color))});
    d.appendChild(marker(mid+'includes','#6D4BE0'));
    d.appendChild(marker(mid+'ok','#2CB6B0')); d.appendChild(marker(mid+'broken','#E2556F')); d.appendChild(marker(mid+'unknown','#92A2B0'));
    return d;
  }
  function pill(cls,x,y,text){
    var g=svgEl('g','lbl '+cls); var w=Math.max(28,text.length*5.6+12);
    var r=svgEl('rect'); r.setAttribute('x',x-w/2); r.setAttribute('y',y-8); r.setAttribute('width',w); r.setAttribute('height',16);
    var t=svgEl('text'); t.setAttribute('x',x); t.setAttribute('y',y+.5); t.textContent=text;
    g.appendChild(r); g.appendChild(t); return g;
  }
  function label(cls,x,y,text){var t=svgEl('text',cls); t.setAttribute('x',x); t.setAttribute('y',y-5); t.textContent=text; return t;}
  function edgeKey(r){return r.from+'>'+r.to+'>'+r.kind}
  function showTip(e,html){tip.innerHTML=html; tip.style.display='block'; moveTip(e);}
  function moveTip(e){var r=viewport.getBoundingClientRect(); var x=e.clientX-r.left+14, y=e.clientY-r.top+14; if(x+tip.offsetWidth>r.width-8) x=Math.max(8,x-tip.offsetWidth-28); if(y+tip.offsetHeight>r.height-8) y=Math.max(8,y-tip.offsetHeight-28); tip.style.left=x+'px'; tip.style.top=y+'px';}
  function hideTip(){tip.style.display='none';}
  function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]});}
  function nodeName(id){return byId[id]?byId[id].name:id}
  function attachHover(hit,line,lbl,html){
    hit.addEventListener('pointerenter',function(e){line.classList.add('hover'); if(lbl) lbl.classList.add('hover'); showTip(e,html);});
    hit.addEventListener('pointermove',moveTip);
    hit.addEventListener('pointerleave',function(){line.classList.remove('hover'); if(lbl) lbl.classList.remove('hover'); hideTip();});
  }
  function drawPaths(){
    while(svg.firstChild) svg.removeChild(svg.firstChild);
    // SVG нулевого размера Chrome не рисует даже с overflow:visible —
    // оверлей растягивается на весь холст.
    svg.setAttribute('width',canvas.scrollWidth); svg.setAttribute('height',canvas.scrollHeight);
    var sel=current?byId[current]:null;
    svg.classList.toggle('focus',!!sel); viewport.classList.toggle('focus',!!sel);
    var drawnPairs={}, onPath={};
    function connect(from,to){
      var aId=visibleId(from), bId=visibleId(to), key=[aId,bId].sort().join('|');
      if(aId===bId||drawnPairs[key]) return;
      var a=anchor(aId), b=anchor(bId); if(!a||!b) return;
      drawnPairs[key]=true;
      var hl=sel&&(sel.id===aId||sel.id===bId);
      var path=svgEl('path','connection'+(hl?' hl':''));
      path.setAttribute('d',curve(a,b,0).d); path.dataset.pair=key; svg.appendChild(path);
    }
    order.forEach(function(id){byId[id].parents.forEach(function(parent){connect(parent,id)});});
    relations.forEach(function(r){connect(r.from,r.to)});
    paths.forEach(function(p){
      if(!activePaths[p.id]) return;
      (p.nodes||[]).forEach(function(n){onPath[n.id]=true});
      (p.edges||[]).forEach(function(e){connect(e.from,e.to)});
    });
    // Процесс задействован в сценарии, если на пути стоит хотя бы один его
    // узел (через любого из родителей); иначе он гаснет вместе с блоками.
    Object.keys(onPath).forEach(function(id){
      var frontier=[id], seen={};
      while(frontier.length){
        var cur=frontier.pop(); if(seen[cur]||!byId[cur]) continue; seen[cur]=true;
        if(byId[cur].type==='process') onPath[cur]=true; else frontier=frontier.concat(byId[cur].parents);
      }
    });
    var any=paths.some(function(p){return activePaths[p.id]});
    Array.prototype.forEach.call(viewport.querySelectorAll('.pko-box'),function(b){
      b.classList.toggle('dim',any&&paths.length>0&&!onPath[b.dataset.id]&&b.dataset.type!=='journey');
    });
  }
  viewport.appendChild(canvas);
  var legend=null, legendHost=options.legendHost||null;
  function sample(color,dash,width){return '<svg viewBox="0 0 26 10"><line x1="1" y1="5" x2="21" y2="5" stroke="'+color+'" stroke-width="'+(width||2)+'"'+(dash?' stroke-dasharray="'+dash+'"':'')+' stroke-linecap="round"/><path d="M20,1 L25,5 L20,9 z" fill="'+color+'"/></svg>';}
  if(paths.length||options.legend!==false){
    legend=document.createElement('div'); legend.className='pko-legend'+(legendHost?' inline':'');
    var key=document.createElement('div'); key.className='pko-key';
    // Статусы реализации остаются в карточках и реестре. На самой карте
    // единственная статусная отметка — подтверждённый разрыв.
    key.innerHTML='<span class="kh">обозначение</span><span title="Подтверждённо не работает обязательный переход либо не реализован обязательный шаг сценария"><b style="background:#E2556F;color:#fff;text-align:center;line-height:9px">!</b>разрыв процесса</span>';
    var lines=document.createElement('div'); lines.className='pko-key';
    lines.textContent='Линия — связь. Пояснения — в карточках узлов.';
    legend.appendChild(key); legend.appendChild(lines);
    var row=document.createElement('div'); row.className='row';
    function layerChip(key,text,title){
      var chip=document.createElement('button'); chip.type='button'; chip.className='pko-chip layer on'; chip.textContent=text; chip.title=title; chip.setAttribute('aria-pressed','true');
      chip.addEventListener('click',function(e){e.stopPropagation(); layers[key]=!layers[key]; chip.classList.toggle('on',layers[key]); chip.setAttribute('aria-pressed',String(layers[key])); drawPaths();});
      return chip;
    }
    paths.forEach(function(p){
      var chip=document.createElement('button'); chip.type='button'; chip.className='pko-chip on'; chip.dataset.path=p.id;
      chip.setAttribute('aria-pressed','true');
      chip.innerHTML='<span></span>';
      chip.lastChild.textContent=p.title+(p.critical?' · критический':'');
      chip.title=(p.status_label||'')+(p.critical?' · критический: без этого сценария замысел инициативы не выполняется':'')+(p.break_point?' — разрыв: '+p.break_point:'')+' · клик — скрыть/показать путь';
      chip.addEventListener('click',function(e){e.stopPropagation(); activePaths[p.id]=!activePaths[p.id]; chip.classList.toggle('on',activePaths[p.id]); chip.setAttribute('aria-pressed',String(activePaths[p.id])); drawPaths();});
      row.appendChild(chip);
    });
    legend.appendChild(row);
    (legendHost||viewport).appendChild(legend);
  }
  var zoom=document.createElement('div'); zoom.className='pko-zoom';
  zoom.innerHTML='<button type="button" data-z="in" title="Приблизить" aria-label="Приблизить">+</button><button type="button" data-z="out" title="Отдалить" aria-label="Отдалить">−</button><button type="button" data-z="fit" class="pko-zoom-fit" title="Вписать в окно" aria-label="Вписать схему в окно">FIT</button>';
  viewport.appendChild(zoom);
  var hint=document.createElement('div'); hint.className='pko-hint'; hint.textContent='Колесо — масштаб · перетаскивание — сдвиг · клик по узлу — паспорт узла · наведение на линию — основание связи'; viewport.appendChild(hint);

  var scale=1, tx=0, ty=0;
  function apply(){canvas.style.transform='translate('+tx+'px,'+ty+'px) scale('+scale+')';}
  function autoLevel(){return scale<.42?'process':scale<.68?'bbb':'operation';}
  function setScale(next,cx,cy){
    next=Math.min(3,Math.max(.2,next));
    if(cx===undefined){cx=viewport.clientWidth/2; cy=viewport.clientHeight/2;}
    tx=cx-(cx-tx)*next/scale; ty=cy-(cy-ty)*next/scale; scale=next; apply();
    if(autoDetail&&autoLevel()!==detail){detail=autoLevel(); applyDetail(); drawPaths();}
  }
  function place(minScale){
    var w=canvas.scrollWidth, h=canvas.scrollHeight, vw=viewport.clientWidth, vh=viewport.clientHeight;
    if(!w||!h||!vw||!vh) return;
    scale=Math.min(1.1,Math.max(minScale,Math.min(vw/w,vh/h)));
    var topInset=legend&&!legendHost?legend.offsetHeight+20:20;
    var padTop=vw<=768?116:88;
    var minTy=Math.max(0,topInset-padTop*scale);
    tx=(vw-w*scale)/2; ty=Math.max(minTy,(vh-h*scale)/2); apply(); drawPaths();
  }
  function fit(){place(.2);}
  function readable(){
    var shortViewport=viewport.clientHeight<560;
    place(viewport.clientWidth<=768?(shortViewport?.48:.64):(shortViewport?.56:.72));
  }
  zoom.addEventListener('click',function(e){
    var b=e.target.closest('button'); if(!b) return;
    if(b.dataset.z==='in') setScale(scale*1.2); else if(b.dataset.z==='out') setScale(scale/1.2); else fit();
  });
  viewport.addEventListener('wheel',function(e){
    e.preventDefault();
    var r=viewport.getBoundingClientRect();
    setScale(scale*(e.deltaY<0?1.1:1/1.1),e.clientX-r.left,e.clientY-r.top);
  },{passive:false});
  // Панорама и выбор узла — одной парой pointerdown/pointerup без захвата
  // указателя: с setPointerCapture click уходил на область, а не на узел.
  var drag=null;
  viewport.addEventListener('pointerdown',function(e){
    if(e.button!==0||e.target.closest('.pko-zoom')||e.target.closest('.pko-legend')) return;
    drag={x:e.clientX,y:e.clientY,tx:tx,ty:ty,target:e.target.closest('.pko-box')}; moved=false;
  });
  window.addEventListener('pointermove',function(e){
    if(!drag) return;
    var dx=e.clientX-drag.x, dy=e.clientY-drag.y;
    if(!moved&&Math.abs(dx)+Math.abs(dy)>4){moved=true; viewport.classList.add('dragging'); hideTip();}
    if(moved){tx=drag.tx+dx; ty=drag.ty+dy; apply();}
  });
  window.addEventListener('pointerup',function(){
    if(!drag) return;
    var target=drag.target, wasMoved=moved;
    drag=null; viewport.classList.remove('dragging'); moved=false;
    if(!wasMoved&&target&&target.dataset.id) select(target.dataset.id);
  });
  window.addEventListener('pointercancel',function(){drag=null; moved=false; viewport.classList.remove('dragging');});
  window.addEventListener('resize',readable);

  function relatedIds(n){
    var out={};
    n.parents.forEach(function(p){out[p]=true}); n.children.forEach(function(c){out[c]=true});
    relations.forEach(function(r){ if(r.from===n.id) out[r.to]=true; if(r.to===n.id) out[r.from]=true; });
    return out;
  }
  function highlight(id){
    var n=id?byId[id]:null, rel=n?relatedIds(n):{};
    Array.prototype.forEach.call(viewport.querySelectorAll('.pko-box'),function(b){
      b.classList.toggle('active',!!n&&b.dataset.id===id);
      b.classList.toggle('related',!!n&&b.dataset.id!==id&&!!rel[b.dataset.id]);
    });
    drawPaths();
  }
  function select(id){
    var n=byId[id]; if(!n) return; current=id;
    // Выбранный узел должен быть виден: раскрываем до его уровня.
    if(LEVEL[n.type]>LEVEL[detail]){detail=n.type; autoDetail=false; applyDetail();}
    highlight(id);
    if(options.onSelect) options.onSelect(n, byId, relations);
  }
  function clear(){current=null; highlight(null);}
  function showPaths(ids){
    paths.forEach(function(p){activePaths[p.id]=!ids||ids.indexOf(p.id)>=0;});
    Array.prototype.forEach.call(viewport.querySelectorAll('.pko-chip[data-path]'),function(chip){chip.classList.toggle('on',!!activePaths[chip.dataset.path]); chip.setAttribute('aria-pressed',String(!!activePaths[chip.dataset.path]));});
    drawPaths();
  }
  readable();
  return {select:select, clear:clear, fit:fit, redraw:drawPaths, nodes:byId, order:order, relations:relations, paths:paths, kinds:REL_KINDS, setDetail:function(d){setDetail(d,true)}, showPaths:showPaths};
};
"""


def passport_map_nodes(passport_data: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Узлы карты из `passport_data` — то, что идёт в контракт дашборда.

    Только структура: id, тип, название, основание и родители. Первый
    родитель — место в дереве, остальные — включения (общий узел в
    нескольких процессах или блоках). Поля карточек остаются в файле
    паспорта.
    """
    if not passport_data or not isinstance(passport_data, dict):
        return []
    rows = passport_data.get("registry") or []
    nodes_data = passport_data.get("nodes") or {}
    out: list[dict[str, Any]] = []
    known = {str(r.get("id")) for r in rows if isinstance(r, dict) and r.get("id")}
    for row in rows:
        if not isinstance(row, dict) or not row.get("id"):
            continue
        node_id = str(row["id"])
        # В реестре `type` — подпись для читателя («КП», «Процесс»); вид
        # узла — по префиксу id, как везде в паспорте.
        ntype = node_id.split("-")[0]
        node = nodes_data.get(node_id) if isinstance(nodes_data, dict) else None
        node = node if isinstance(node, dict) else {}
        parents = [str(x) for x in (node.get("parents") or []) if str(x) in known]
        if not parents:
            raw_parent = str(row.get("parent") or "").strip()
            parents = [x.strip() for x in raw_parent.replace(";", ",").replace("·", ",").split(",")
                       if x.strip() in known]
        basis = str(row.get("basis") or node.get("basis") or "")
        entry: dict[str, Any] = {
            "id": node_id, "type": ntype,
            "name": str(row.get("name") or node.get("name") or node_id),
            "basis": basis, "parent": parents[0] if parents else None, "parents": parents,
            "before_fork": bool(node.get("before_fork")) and ntype == "bbb",
            "planned": bool(node.get("planned")) and ntype != "journey",
            "scenario": str(node.get("scenario") or "") if ntype == "process" else "",
            "branching": str(node.get("branching") or ""),
            "branching_label": BRANCHING_LABEL.get(str(node.get("branching") or ""), ""),
        }
        out.append(entry)
    return out


def passport_map_relations(passport_data: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Связи поверх дерева — как их построил `normalize_passport`."""
    if not passport_data or not isinstance(passport_data, dict):
        return []
    out: list[dict[str, Any]] = []
    for rel in passport_data.get("relations") or []:
        if not isinstance(rel, dict) or not rel.get("from") or not rel.get("to"):
            continue
        out.append({
            "from": str(rel["from"]), "to": str(rel["to"]),
            "kind": str(rel.get("kind") or ""),
            "kind_label": str(rel.get("kind_label") or rel.get("kind") or ""),
            "basis": str(rel.get("basis") or ""),
            "field": str(rel.get("field") or ""),
        })
    return out


# Пороги раскраски узла по готовности — те же полосы, что у бейджа
# решения: зелёный от порога GO, красный ниже четверти.
_GOOD_FROM = 75
_WEAK_BELOW = 25

NODE_IMPLEMENTATION_LABEL = {
    "implemented": "Реализован",
    "partial": "Реализован частично",
    "not_implemented": "Не реализован",
    "unknown": "Недостаточно данных",
}

_NOT_IMPLEMENTED_CODE = re.compile(
    r"закомментир|отключ[её]н|замен[её]н\w* (?:нул[её]м|констант)|"
    r"заглушк|stub\b|not implemented|в коде (?:отсутствует|нет)",
    re.IGNORECASE,
)
_PARTIAL_CODE = re.compile(
    r"частичн\w* реализ|реализован\w* только|todo\b|не заверш[её]н",
    re.IGNORECASE,
)


def _band(readiness: int | None) -> str:
    if readiness is None:
        return "none"
    if readiness >= _GOOD_FROM:
        return "good"
    if readiness < _WEAK_BELOW:
        return "bad"
    return "mid"


def _implementation_state(criteria: list[Any]) -> str:
    """Состояние связанных пунктов ОР как один из сигналов статуса узла."""
    statuses = [str(c.status) for c in criteria if getattr(c, "applicable", False)]
    if not statuses:
        return "unknown"
    if all(s == "done" for s in statuses):
        return "implemented"
    if all(s in ("planned", "blocked") for s in statuses):
        return "not_implemented"
    return "partial"


def _combine_states(states: list[str]) -> str:
    """Собрать несколько независимых сигналов без правила «худший победил».

    `unknown` не понижает подтверждённую оценку. Полностью отсутствующим узел
    считается лишь когда все содержательные сигналы говорят об отсутствии;
    смесь работающих и отсутствующих частей означает частичную реализацию.
    """
    known = [state for state in states if state in NODE_IMPLEMENTATION_LABEL and state != "unknown"]
    if not known:
        return "unknown"
    if "partial" in known:
        return "partial"
    if "implemented" in known and "not_implemented" in known:
        return "partial"
    if "implemented" in known:
        return "implemented"
    return "not_implemented"


def _node_code_state(raw: dict[str, Any], ntype: str, planned: bool) -> tuple[str, str]:
    """Готовность кода листа, независимо от соответствия пунктам ОР."""
    if planned:
        return "not_implemented", ""
    haystack = " ".join((
        str(raw.get("name") or ""),
        str(raw.get("basis") or ""),
        # Descriptions of retries/fallbacks, owners and versions are not
        # assertions about implementation. A negative word there is not a defect.
    ))
    if _NOT_IMPLEMENTED_CODE.search(haystack):
        # Непланируемый узел существует, поэтому упоминание отсутствующей или
        # отключённой части означает неполную реализацию, а не отсутствие
        # объекта целиком. Полностью отсутствующий объект агент обязан пометить
        # `planned`.
        return "partial", "В реализации отсутствует, отключена или заменена заглушкой часть поведения"
    if _PARTIAL_CODE.search(haystack):
        return "partial", "По описанию полей код узла реализован не полностью"
    state, note = _field_state(raw, ntype)
    return (state or "unknown"), note


def build_passport_map(model: ProgressModel) -> dict[str, Any]:
    """Схема паспорта с оценкой: узлы с готовностью и проблемами, пути
    сценариев со стыками. Всё считает код по привязкам, которые дал
    паспортный агент (`bullets`, `scenario_steps`) и которые гейт сопоставил
    с планом и сценариями.

    Полнота соответствия ОР — `calculate_progress` по связанным пунктам,
    теми же весами, что и общая готовность. Статус реализации объединяет
    пункты ОР, основания полей и дочерние шаги; смесь готовых и отсутствующих
    частей становится частичной реализацией. Состояние сценария хранится
    отдельно и не подменяет статус узла.
    """
    nodes = passport_map_nodes(model.passport_data)
    relations = passport_map_relations(model.passport_data)
    if not nodes:
        return {
            "nodes": [], "paths": [], "relations": [], "defects": [], "risks": [], "handoffs": [], "breaks": [],
            "summary": {
                "functional_nodes": 0,
                "breaks_total": 0,
                "counts": {state: 0 for state in NODE_IMPLEMENTATION_LABEL},
                "requirements_mapped": 0,
                "requirements_total": len(model.rated_criteria()),
                "mapping_coverage": 0 if model.rated_criteria() else None,
                "scenario_steps_mapped": 0,
                "scenario_steps_total": _scenario_steps_total(model),
                "assessment": model.solution_assessment().to_dict(),
            },
        }
    raw_nodes = (model.passport_data or {}).get("nodes") or {}

    # Пункт ОР → его оценка (дословный текст плана — ключ, как везде).
    criterion_by_text: dict[str, Any] = {}
    for verdict in model.verdicts:
        item = model.items.get(verdict.item_id)
        if item is None or not verdict.applicable:
            continue
        for text, criterion in zip(item.criteria, verdict.criteria):
            if criterion.applicable:
                criterion_by_text[str(text)] = criterion

    scenarios = {s.id: s for s in (model.connectivity.scenarios if model.connectivity else [])}
    # (сценарий, шаг) → узлы, которые его выполняют.
    step_nodes: dict[tuple[str, int], list[str]] = {}

    by_id = {n["id"]: n for n in nodes}
    # Общий узел — ребёнок каждого из родителей: его пункты входят в
    # состояние всех процессов, куда он включён.
    children: dict[str, list[str]] = {nid: [] for nid in by_id}
    for node in nodes:
        for parent in node.get("parents") or []:
            if parent in children and node["id"] not in children[parent]:
                children[parent].append(node["id"])

    direct_texts: dict[str, list[str]] = {}
    for node in nodes:
        raw = raw_nodes.get(node["id"]) if isinstance(raw_nodes, dict) else None
        raw = raw if isinstance(raw, dict) else {}
        direct_texts[node["id"]] = [
            str(text) for text in (raw.get("bullets") or [])
            if str(text) in criterion_by_text
        ]

    def linked_texts(node_id: str, trail: set[str] | None = None) -> list[str]:
        """Прямая привязка; для контейнера — сумма детей, для листа —
        привязка ближайшего родителя. Так каждый функциональный узел получает
        объяснимое состояние, но источник связи остаётся виден в карточке.
        """
        trail = set(trail or ())
        if node_id in trail:
            return []
        trail.add(node_id)
        direct = direct_texts.get(node_id) or []
        if direct:
            return list(dict.fromkeys(direct))
        descendant: list[str] = []
        for child in children.get(node_id, []):
            descendant.extend(linked_texts(child, trail))
        # Статус сверху вниз не наследуется: лист без пунктов оценивается по
        # уровням оснований своих полей, а не по родителю — иначе весь процесс
        # получает одинаковую подпись протяжкой.
        return list(dict.fromkeys(descendant))

    for node in nodes:
        raw = raw_nodes.get(node["id"]) if isinstance(raw_nodes, dict) else None
        raw = raw if isinstance(raw, dict) else {}
        bullets: list[dict[str, Any]] = []
        criteria = []
        texts = linked_texts(node["id"])
        for text in texts:
            criterion = criterion_by_text.get(str(text))
            if criterion is None:
                continue
            criteria.append(criterion)
            bullets.append({"text": str(text), "status": criterion.status,
                            "status_label": STATUS_LABEL.get(criterion.status, criterion.status)})
        readiness = calculate_progress(criteria) if criteria else None
        node["bullets"] = bullets
        node["readiness"] = readiness
        node["band"] = _band(readiness)
        # Готовность кода и соответствие ОР — две разные оси. Пункты ОР
        # остаются в readiness/bullets, но статус узла определяется по
        # основаниям реализации и затем агрегируется снизу вверх по детям.
        code_state, code_note = _node_code_state(raw, node["type"], bool(node.get("planned")))
        criterion_state = _implementation_state(criteria)
        state = _combine_states([code_state, criterion_state])
        source = (
            "planned" if node.get("planned")
            else "criteria+fields" if code_state != "unknown" and criterion_state != "unknown"
            else "criteria" if criterion_state != "unknown"
            else "fields" if code_state != "unknown"
            else "unknown"
        )
        # Не показываем рядом с «Реализован» противоположное сообщение о
        # недостатке данных, если пункт ОР уже подтверждает реализацию.
        cap_problems: list[str] = (
            [code_note] if code_note and not (
                state == "implemented" and criterion_state == "implemented"
            ) else []
        )
        node["implementation_status"] = state
        node["implementation_label"] = NODE_IMPLEMENTATION_LABEL[state]
        node["assessment_source"] = source
        node["cap_problems"] = cap_problems
        node["steps"] = []
        for entry in raw.get("scenario_steps") or []:
            if not isinstance(entry, dict):
                continue
            sid, step = str(entry.get("scenario") or ""), entry.get("step")
            if sid in scenarios and isinstance(step, int):
                node["steps"].append({"scenario": sid, "step": step})
                step_nodes.setdefault((sid, step), []).append(node["id"])
        node["problems"] = [
            f"{b['status_label']}: {b['text']}" for b in bullets if b["status"] != "done"
        ]
        node["problems"].extend(node.pop("cap_problems"))
        if state == "unknown" and source == "unknown":
            node["problems"].append("Недостаточно данных для оценки узла")
        if node.get("planned") and any(b["status"] not in ("planned", "blocked") for b in bullets):
            node["problems"].append(
                "Паспорт называет узел планируемым, а привязанные пункты образа результата оценены иначе"
            )

    # Пути сценариев поверх дерева: узлы по шагам, рёбра между соседними
    # привязанными шагами с результатом стыка. Шаг без узла не пропадает:
    # ребро через него несёт список пропущенных шагов, а путь — покрытие
    # шагов схемой. Сценарий, у которого на схеме нет ни одного шага, —
    # отдельная проблема пути, а не молчание.
    paths: list[dict[str, Any]] = []
    steps_mapped_total = 0
    steps_total = 0
    for scenario in scenarios.values():
        path_nodes: list[dict[str, Any]] = []
        edges: list[dict[str, Any]] = []
        unmapped: list[dict[str, Any]] = []
        prev: list[str] = []
        prev_step = -1
        for index, step_text in enumerate(scenario.steps):
            ids = step_nodes.get((scenario.id, index), [])
            if not ids:
                unmapped.append({"step": index, "text": step_text})
            for nid in ids:
                path_nodes.append({"id": nid, "step": index, "text": step_text})
            # Шаг выполняют и BBB, и его операция — ребро идёт по операции:
            # линия к блоку и к каждой его операции — тот же переход дважды.
            # Блок остаётся узлом пути и на схеме не приглушается.
            ids = _finer_nodes(ids, by_id)
            if ids and prev:
                # Результат стыка — по переходам между prev_step и index:
                # разрыв сильнее неизвестного.
                results = []
                for t in range(prev_step, index):
                    handoff = scenario.handoff_at(t)
                    results.append(handoff.result if handoff else "unknown")
                result = ("broken" if "broken" in results
                          else "unknown" if "unknown" in results else "ok")
                handoff = next((scenario.handoff_at(t) for t in range(prev_step, index)
                                if scenario.handoff_at(t) and scenario.handoff_at(t).result == result), None)
                note = ""
                if handoff is not None:
                    check = handoff.break_check or next(
                        (c for c in handoff.checks if c.result == result), None)
                    note = check.note if check else ""
                skipped = list(range(prev_step + 1, index))
                for a in prev:
                    for b in ids:
                        # Узел, выполняющий два шага подряд, — не ребро в себя.
                        if a == b or any(e["from"] == a and e["to"] == b for e in edges):
                            continue
                        edges.append({"from": a, "to": b, "result": result,
                                      "result_label": CHECK_RESULT_LABEL.get(result, result),
                                      "note": note, "skipped": skipped})
                        # Подтверждённый разрыв попадёт в единый реестр
                        # дефектов. В карточке оставляем только неизвестный
                        # стык, иначе одно объяснение показывается дважды.
                        if result == "unknown" and a in by_id:
                            by_id[a]["problems"].append(
                                f"{scenario.title}: {CHECK_RESULT_LABEL.get(result, result).lower()} "
                                f"на переходе к «{step_text}»" + (f" — {note}" if note else "")
                            )
            if ids:
                prev, prev_step = ids, index
        mapped = len(scenario.steps) - len(unmapped)
        steps_mapped_total += mapped
        steps_total += len(scenario.steps)
        problems: list[str] = []
        if scenario.steps and not mapped:
            problems.append("ни один шаг сценария не привязан к узлу схемы")
        elif unmapped:
            problems.append("шаги без узла на схеме: " + "; ".join(
                f"{u['step']} «{u['text']}»" for u in unmapped))
        paths.append({
            "id": scenario.id, "title": scenario.title, "critical": scenario.critical,
            "status": scenario.status,
            "status_label": SCENARIO_STATUS_LABEL.get(scenario.status, scenario.status),
            "entry": scenario.entry, "outcome": scenario.outcome,
            "steps": list(scenario.steps), "nodes": path_nodes, "edges": edges,
            "unmapped_steps": unmapped,
            "steps_mapped": mapped, "steps_total": len(scenario.steps),
            "problems": problems,
            "break_point": scenario.break_point,
        })
    # Статус контейнера собирается из собственной оценки и детей. Один
    # отсутствующий шаг не превращает работающий процесс или весь путь в
    # «не реализован»: смесь работающих и отсутствующих частей — это
    # «реализован частично». `unknown` не понижает уже подтверждённый сигнал.
    by_id_nodes = {n["id"]: n for n in nodes}
    aggregated: dict[str, str] = {}

    def aggregate(node_id: str, trail: set[str] | None = None) -> str:
        if node_id in aggregated:
            return aggregated[node_id]
        trail = set(trail or ())
        if node_id in trail:  # защита от испорченного графа родителей
            return "unknown"
        trail.add(node_id)
        node = by_id_nodes[node_id]
        kids = [by_id_nodes[c] for c in children.get(node_id, []) if c in by_id_nodes]
        if not kids:
            aggregated[node_id] = node["implementation_status"]
            return aggregated[node_id]
        child_states = [aggregate(k["id"], trail) for k in kids]
        previous = node["implementation_status"]
        combined = _combine_states([previous, *child_states])
        node["implementation_status"] = combined
        node["implementation_label"] = NODE_IMPLEMENTATION_LABEL[combined]
        node["assessment_source"] = "children"
        weak = [k for k in kids if k["implementation_status"] != "implemented"]
        if weak and combined != previous:
            node["problems"].append(
                "Часть дочерних шагов реализована не полностью: "
                + ", ".join(f"«{k['name']}» — {k['implementation_label'].lower()}" for k in weak[:4])
            )
        aggregated[node_id] = combined
        return combined

    for node in nodes:
        aggregate(node["id"])

    # Process = scenario по составу, но не по шкале. Состояние сценария
    # храним отдельно: разрыв связи не переписывает статус реализации узла.
    for node in nodes:
        if node["type"] != "process":
            continue
        sid = str(node.get("scenario") or "")
        scenario = scenarios.get(sid)
        if scenario is None:
            continue
        node["scenario_status"] = scenario.status

    # Ещё раз собираем путь из процессов после агрегации их дочерних узлов.
    for node in nodes:
        if node["type"] != "journey":
            continue
        process_states = [
            by_id_nodes[c]["implementation_status"]
            for c in children.get(node["id"], [])
            if c in by_id_nodes and by_id_nodes[c]["type"] == "process"
        ]
        if process_states:
            combined = _combine_states([node["implementation_status"], *process_states])
            node["implementation_status"] = combined
            node["implementation_label"] = NODE_IMPLEMENTATION_LABEL[combined]

    for node in nodes:
        node["problems"] = list(dict.fromkeys(
            str(problem).strip() for problem in node.get("problems") or [] if str(problem).strip()
        ))
        node["mark"] = ""
    # Связи узла — в карточку: и исходящие, и входящие, словами.
    for node in nodes:
        node["relations"] = [
            {**rel, "direction": "out" if rel["from"] == node["id"] else "in"}
            for rel in relations if node["id"] in (rel["from"], rel["to"])
        ]
    defects = _build_defects(model, nodes, by_id, criterion_by_text, step_nodes, scenarios)
    for node in nodes:
        node["defects"] = [d["id"] for d in defects if node["id"] in d["nodes"]]
        if node["defects"]:
            # Подробная причина уже находится в едином объекте дефекта. Не
            # повторяем рядом краткую строку из того же пункта ОР.
            bullet_problems = {
                f"{bullet['status_label']}: {bullet['text']}"
                for bullet in node.get("bullets") or [] if bullet.get("status") != "done"
            }
            node["problems"] = [p for p in node.get("problems") or [] if p not in bullet_problems]
    risks = _build_risks(model, by_id)
    for node in nodes:
        # Риск — независимая от готовности ось: только ссылка для бейджа и
        # карточки на самом конкретном связанном узле, без изменения статуса.
        node["risks"] = [r["id"] for r in risks if node["id"] in r["display_nodes"]]
    handoffs = _build_handoffs(scenarios, step_nodes, relations)
    breaks = _build_breaks(nodes, handoffs, scenarios)
    break_nodes = {node_id for item in breaks for node_id in item["nodes"]}
    for node in nodes:
        node["mark"] = "broken" if node["id"] in break_nodes else ""
    functional = [n for n in nodes if n["type"] in ("journey", "process", "bbb", "operation")]
    counts = {state: 0 for state in NODE_IMPLEMENTATION_LABEL}
    for node in functional:
        counts[node["implementation_status"]] += 1
    mapped = {text for texts in direct_texts.values() for text in texts}
    total_bullets = len(criterion_by_text)
    mapping_coverage = round(100 * len(mapped) / total_bullets) if total_bullets else None
    checked = sum(1 for h in handoffs if h["checked"])
    return {
        "nodes": nodes,
        "paths": paths,
        "relations": relations,
        "defects": defects,
        "risks": risks,
        "handoffs": handoffs,
        "breaks": breaks,
        "summary": {
            "scenarios_total": len(scenarios),
            "scenarios_assembled": sum(1 for s in scenarios.values() if s.status == "assembled"),
            "scenarios_broken": sum(1 for s in scenarios.values() if s.status == "broken"),
            "blocking_breaks": sum(1 for s in scenarios.values() if s.status == "broken" and s.critical),
            "breaks_total": len(breaks),
            "unknown_nodes": counts["unknown"],
            "handoffs_total": len(handoffs),
            "handoffs_checked": checked,
            "wiring_unchecked": sum(1 for h in handoffs if h["wiring_unchecked"]),
            "defects_total": len(defects),
            "defects_blocking": sum(1 for d in defects if d["blocking"]),
            "risks_total": len(risks),
            "risks_local": sum(1 for r in risks if r["scope"] == "local"),
            "risks_cross_node": sum(1 for r in risks if r["scope"] == "cross_node"),
            "risks_established": sum(1 for r in risks if r["confidence"] == "established"),
            "risks_inferred": sum(1 for r in risks if r["confidence"] == "inferred"),
            "risks_requires_confirmation": sum(1 for r in risks if r["confidence"] == "requires_confirmation"),
            "functional_nodes": len(functional),
            "shared_nodes": sum(1 for n in functional if len(n.get("parents") or []) > 1),
            "before_fork_nodes": sum(1 for n in functional if n.get("before_fork")),
            "planned_nodes": sum(1 for n in functional if n.get("planned")),
            "relations_total": len(relations),
            "counts": counts,
            "requirements_mapped": len(mapped),
            "requirements_total": total_bullets,
            "mapping_coverage": mapping_coverage,
            "scenario_steps_mapped": steps_mapped_total,
            "scenario_steps_total": steps_total,
            "assessment": model.solution_assessment().to_dict(),
        },
    }


def _source_level(source: str) -> str | None:
    for level in SOURCE_LEVELS:
        if str(source or "").strip().startswith(level):
            return level
    return None


def _field_levels(raw: dict[str, Any]) -> dict[str, str | None]:
    fields = raw.get("fields") if isinstance(raw.get("fields"), dict) else {}
    out: dict[str, str | None] = {}
    for fid, cell in fields.items():
        if isinstance(cell, dict) and (str(cell.get("value") or "").strip() or str(cell.get("source") or "").strip()):
            out[str(fid)] = _source_level(str(cell.get("source") or ""))
    return out


def _critical_gap(raw: dict[str, Any], ntype: str) -> str:
    """Критичное поле не установлено (или отсутствует) — текст проблемы, иначе пусто."""
    levels = _field_levels(raw)
    if not levels:
        return ""
    gaps: list[str] = []
    for fid in sorted(CRITICAL_FIELDS.get(ntype, set())):
        if fid in levels and levels[fid] in (None, "Не установлено"):
            gaps.append(_FIELD_LABEL.get(fid, fid))
    if not gaps:
        return ""
    return ("Статус ограничен «недостаточно данных»: не установлено — " + ", ".join(gaps)
            + " (без этого путь не продолжается)")


def _field_state(raw: dict[str, Any], ntype: str) -> tuple[str, str]:
    """Статус листа без пунктов ОР — по уровням оснований его полей.

    Все критичные поля с уровнем «Установлено» или «Выведено» — реализован;
    «Гипотеза» или «Требует подтверждения» в критичном поле — недостаточно
    данных; «Не установлено» — потолок, объясняется отдельно.
    """
    levels = _field_levels(raw)
    critical = CRITICAL_FIELDS.get(ntype, set())
    if not levels or not critical or not critical <= set(levels):
        return "", ""
    gap = _critical_gap(raw, ntype)
    if gap:
        return "unknown", gap
    weak = [_FIELD_LABEL.get(fid, fid) for fid in sorted(critical) if levels.get(fid) not in _GROUNDED_LEVELS]
    if weak:
        return "unknown", "Статус по основаниям: гипотеза или неподтверждённое намерение в полях — " + ", ".join(weak)
    return "implemented", ""


def _most_specific_risk_nodes(linked: list[str], by_id: dict[str, dict[str, Any]]) -> list[str]:
    """Не показывать риск на предке, если он уже показан на его потомке.

    У общего BBB несколько родителей, поэтому проверяем все ветки ``parents``.
    Несвязанные ветки сохраняются: сквозной риск виден в каждом затронутом
    конкретном узле.
    """
    ancestors: set[str] = set()
    for node_id in linked:
        pending = list(by_id[node_id].get("parents") or [])
        visited: set[str] = set()
        while pending:
            parent = pending.pop()
            if parent in visited or parent not in by_id:
                continue
            visited.add(parent)
            ancestors.add(parent)
            pending.extend(by_id[parent].get("parents") or [])
    return [node_id for node_id in linked if node_id not in ancestors]


_RISK_NODE_REF = re.compile(r"\b(?:(?P<in>[Вв])\s+)?(?P<id>(?:journey|process|bbb|operation)-\d+)\b")


def _readable_risk_text(text: str, by_id: dict[str, dict[str, Any]]) -> str:
    """Для старых паспортов заменить внутренний ID названием объекта."""
    in_kind = {"journey": "клиентском пути", "process": "процессе",
               "bbb": "бизнес-блоке", "operation": "операции"}

    def replace(match: re.Match[str]) -> str:
        node = by_id.get(match.group("id"))
        if node is None:
            return match.group(0)
        name = str(node.get("name") or match.group("id"))
        if match.group("in"):
            return f"{match.group('in')} {in_kind[node['type']]} «{name}»"
        return f"«{name}»"

    return _RISK_NODE_REF.sub(replace, text)


def _build_risks(model: ProgressModel, by_id: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """Безопасный контракт рисков для графа и карточек.

    Нормализация уже выполнила смысловой гейт; здесь только отбрасываются
    осиротевшие ссылки из старых/ручных моделей и добавляются подписи.
    """
    out: list[dict[str, Any]] = []
    for raw in (model.passport_data or {}).get("risks") or []:
        if not isinstance(raw, dict) or not str(raw.get("title") or "").strip():
            continue
        if raw.get("disposition") in ("controlled", "closed"):
            continue
        linked = [nid for nid in raw.get("linked_nodes") or [] if nid in by_id]
        primary = str(raw.get("primary_node") or "")
        if primary in by_id and primary not in linked:
            linked.insert(0, primary)
        if not linked:
            continue
        linked = list(dict.fromkeys(linked))
        scope = str(raw.get("scope") or "")
        confidence = str(raw.get("confidence") or "")
        shown = {
            **raw,
            "linked_nodes": linked,
            "display_nodes": _most_specific_risk_nodes(linked, by_id),
            "primary_node": primary if primary in by_id else linked[0],
            "scope_label": str(raw.get("scope_label") or RISK_SCOPE_LABEL.get(scope, scope)),
            "confidence_label": str(raw.get("confidence_label") or RISK_CONFIDENCE_LABEL.get(confidence, confidence)),
        }
        for key in ("title", "problem", "cause", "trigger", "mechanism", "negative_event",
                    "control_gap", "recommendation", "confirmation_needed", "closure_criterion",
                    "confidence_note"):
            if isinstance(shown.get(key), str):
                shown[key] = _readable_risk_text(shown[key], by_id)
        if isinstance(shown.get("consequences"), list):
            shown["consequences"] = [
                _readable_risk_text(value, by_id) if isinstance(value, str) else value
                for value in shown["consequences"]
            ]
        if isinstance(shown.get("existing_controls"), list):
            shown["existing_controls"] = [
                {**control, "description": _readable_risk_text(str(control.get("description") or ""), by_id)}
                if isinstance(control, dict) else control
                for control in shown["existing_controls"]
            ]
        out.append(shown)
    return out


def _build_defects(model: ProgressModel, nodes: list[dict[str, Any]], by_id: dict[str, dict[str, Any]],
                   criterion_by_text: dict[str, Any], step_nodes: dict[tuple[str, int], list[str]],
                   scenarios: dict[str, Any]) -> list[dict[str, Any]]:
    """Реестр дефектов: заведённые агентом плюс те, что код знает сам —
    обещания образа результата без реализации (полнота) и разрывы стыков
    (по виду проверки). Один дефект — одна строка."""
    out: list[dict[str, Any]] = []
    for defect in (model.passport_data or {}).get("defects") or []:
        if isinstance(defect, dict) and defect.get("title"):
            out.append({**defect, "nodes": [n for n in defect.get("nodes") or [] if n in by_id],
                        "scenarios": [s for s in defect.get("scenarios") or [] if s in scenarios]})
    counter = len(out)

    def add(title: str, kind: str, node_ids: list[str], sids: list[str], where: str, blocking: bool) -> None:
        nonlocal counter
        node_ids = list(dict.fromkeys(node_ids))
        sids = list(dict.fromkeys(sids))
        # Паспортный агент уже формулирует дефект человеческим языком. Если
        # автоматический разрыв относится к тому же сценарию и тем же узлам,
        # усиливаем существующую запись, а не повторяем её технической фразой.
        for existing in out:
            same_title = re.sub(r"\W+", "", str(existing.get("title") or "").lower()) == re.sub(
                r"\W+", "", title.lower()
            )
            overlaps = bool(set(existing.get("nodes") or []) & set(node_ids)) and bool(
                set(existing.get("scenarios") or []) & set(sids)
            )
            if same_title or overlaps:
                existing["nodes"] = list(dict.fromkeys([*(existing.get("nodes") or []), *node_ids]))
                existing["scenarios"] = list(dict.fromkeys([*(existing.get("scenarios") or []), *sids]))
                existing["blocking"] = bool(existing.get("blocking")) or blocking
                if where and not existing.get("where"):
                    existing["where"] = where
                return
        counter += 1
        out.append({
            "id": f"defect-{counter}", "title": title, "kind": kind,
            "kind_label": DEFECT_KIND_LABEL.get(kind, kind), "where": where,
            "nodes": node_ids, "scenarios": sids,
            "blocking": blocking, "source": "code",
        })

    # Обещание без реализации: планируемый узел, чей родитель не планируемый.
    for node in nodes:
        if not node.get("planned"):
            continue
        parents = node.get("parents") or []
        if any(by_id.get(p, {}).get("planned") for p in parents):
            continue
        bullets = [b["text"] for b in node.get("bullets") or []]
        sids = [sid for (sid, _), ids in step_nodes.items() if node["id"] in ids]
        for sid, scenario in scenarios.items():
            if any(b in scenario.bullets for b in bullets) and sid not in sids:
                sids.append(sid)
        add(
            f"Обещание образа результата без реализации: «{node['name']}»"
            + (" — " + "; ".join(bullets[:2]) if bullets else ""),
            "completeness", [node["id"]], sids, "", False,
        )
    # Разрывы стыков — по результату ревизии связности.
    for sid, scenario in scenarios.items():
        for index in range(max(0, len(scenario.steps) - 1)):
            handoff = scenario.handoff_at(index)
            if handoff is None or handoff.result != "broken":
                continue
            check = handoff.break_check
            kind = _CHECK_DEFECT_KIND.get(check.check if check else "", "integration")
            where = ""
            if check and check.verified_evidence:
                ev = check.verified_evidence[0]
                where = f"{ev.path}:{ev.line}" if ev.line else ev.path
            label = HANDOFF_CHECK_LABEL.get(check.check, check.check) if check else "разрыв"
            title = (f"{scenario.title}: на переходе «{scenario.steps[index]}» → «{scenario.steps[index + 1]}» "
                     f"{label.lower()} не подтверждена" + (f" — {check.note}" if check and check.note else ""))
            add(title, kind, step_nodes.get((sid, index), []) + step_nodes.get((sid, index + 1), []),
                [sid], where, bool(scenario.critical))
    return out


def _build_handoffs(scenarios: dict[str, Any], step_nodes: dict[tuple[str, int], list[str]],
                    relations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Таблица передач: строка — переход между соседними шагами сценария с
    шестью проверками ревизии связности, узлами на схеме и полем состояния
    из связи `feeds` между ними."""
    rows: list[dict[str, Any]] = []
    for sid, scenario in scenarios.items():
        for index in range(max(0, len(scenario.steps) - 1)):
            handoff = scenario.handoff_at(index)
            src = step_nodes.get((sid, index), [])
            dst = step_nodes.get((sid, index + 1), [])
            fields = [r["field"] for r in relations
                      if r.get("kind") == "feeds" and r.get("field") and r["from"] in src and r["to"] in dst]
            by_check = {c.check: c for c in (handoff.checks if handoff else [])}
            checks = []
            for name in HANDOFF_CHECKS:
                c = by_check.get(name)
                checks.append({
                    "check": name, "check_label": HANDOFF_CHECK_LABEL[name],
                    "result": c.result if c else "unknown",
                    "result_label": CHECK_RESULT_LABEL.get(c.result, c.result) if c else "не проверялось",
                    "note": c.note if c else "",
                    "links": [e.to_dict() for e in c.verified_evidence] if c else [],
                })
            result = handoff.result if handoff else "unknown"
            rows.append({
                "scenario": sid, "scenario_title": scenario.title, "critical": scenario.critical,
                "step": index, "from_step": scenario.steps[index], "to_step": scenario.steps[index + 1],
                "from_nodes": src, "to_nodes": dst,
                "kind": handoff.kind if handoff else "", "kind_label": HANDOFF_KIND_LABEL.get(handoff.kind, handoff.kind) if handoff else "",
                "field": ", ".join(dict.fromkeys(fields)),
                "checks": checks, "result": result,
                "result_label": CHECK_RESULT_LABEL.get(result, result),
                "checked": handoff is not None and any(c["result"] != "unknown" for c in checks),
                "wiring_unchecked": "wiring" not in by_check or by_check["wiring"].result == "unknown",
            })
    return rows


def _build_breaks(nodes: list[dict[str, Any]], handoffs: list[dict[str, Any]],
                  scenarios: dict[str, Any]) -> list[dict[str, Any]]:
    """Собрать подтверждённые точки разрыва для карты.

    Разрыв — это сломанный обязательный стык либо обязательный шаг сценария,
    чей узел не реализован. ``unknown`` и просто не найденный вызов разрывом
    не становятся.
    """
    out: list[dict[str, Any]] = []
    process_by_scenario = {
        str(node.get("scenario") or ""): node["id"]
        for node in nodes if node.get("type") == "process" and node.get("scenario")
    }
    for handoff in handoffs:
        if handoff.get("result") != "broken":
            continue
        anchors = list(dict.fromkeys(handoff.get("from_nodes") or handoff.get("to_nodes") or []))
        scenario_id = str(handoff.get("scenario") or "")
        if not anchors and process_by_scenario.get(scenario_id):
            anchors = [process_by_scenario[scenario_id]]
        out.append({
            "id": f"break-{len(out) + 1}", "kind": "handoff",
            "scenario": scenario_id, "scenario_title": handoff["scenario_title"],
            "critical": bool(handoff.get("critical")), "nodes": anchors,
            "from_step": handoff["from_step"], "to_step": handoff["to_step"],
            "checks": handoff.get("checks") or [],
            "reason": "Обязательный переход между шагами подтверждённо не работает",
        })
    for node in nodes:
        if node.get("type") not in ("bbb", "operation"):
            continue
        if node.get("implementation_status") != "not_implemented":
            continue
        seen: set[str] = set()
        for step_ref in node.get("steps") or []:
            scenario_id = str(step_ref.get("scenario") or "")
            step = step_ref.get("step")
            if not scenario_id or scenario_id in seen or scenario_id not in scenarios:
                continue
            seen.add(scenario_id)
            scenario = scenarios[scenario_id]
            step_text = scenario.steps[step] if isinstance(step, int) and 0 <= step < len(scenario.steps) else ""
            out.append({
                "id": f"break-{len(out) + 1}", "kind": "node",
                "scenario": scenario_id, "scenario_title": scenario.title,
                "critical": bool(scenario.critical), "nodes": [node["id"]],
                "node": node["id"], "step": step, "step_text": step_text,
                "reason": "Обязательный шаг сценария не реализован",
            })
    return out


def _finer_nodes(ids: list[str], by_id: dict[str, dict[str, Any]]) -> list[str]:
    """Из узлов одного шага убрать BBB, чья операция тоже привязана к шагу."""
    parents_of_ops = {p for nid in ids for p in (by_id.get(nid, {}).get("parents") or [])
                      if by_id.get(nid, {}).get("type") == "operation"}
    kept = [nid for nid in ids if not (by_id.get(nid, {}).get("type") == "bbb" and nid in parents_of_ops)]
    return list(dict.fromkeys(kept)) or list(dict.fromkeys(ids))


def _scenario_steps_total(model: ProgressModel) -> int:
    if model.connectivity is None:
        return 0
    return sum(len(s.steps) for s in model.connectivity.scenarios)


def nodes_json(nodes: Any) -> str:
    """JSON для вставки в `<script>` — без `</` и U+2028/2029."""
    text = json.dumps(nodes, ensure_ascii=False, separators=(",", ":"))
    return text.replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")

"""OpenAI-совместимый клиент с кешированием по (модель, промпт).

Использует `openai` SDK — это даёт автоинструментацию Phoenix
(`phoenix.otel.register(auto_instrument=True)` перехватывает все вызовы
`chat.completions.create`), без ручных спанов в коде. Ответы кешируются по
(model, payload) — при `temperature=0` это даёт воспроизводимость отчёта,
которой требует §5.2.2.
"""

from __future__ import annotations

import hashlib
import json
import ssl
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
import openai

from pko.errors import LlmError
from pko.llm.registry import ModelSpec
from pko.monitoring import record_llm_call
from pko.util.paths import harden_dir, harden_file

DEFAULT_CACHE_DIR = Path.home() / ".pko" / "llm-cache"


@dataclass
class ChatResult:
    """Ответ модели вместе с расходом токенов.

    Агентскому циклу мало текста: в трассу нужно записать, сколько стоил шаг и
    что именно вернул endpoint, иначе разбирать неудачный прогон не по чему.
    `reasoning_content` — внутренняя цепочка рассуждений модели (thinking),
    сохраняется для последующего анализа, но не подменяет `text`/`tool_calls`.
    """

    text: str
    usage: dict[str, Any]
    from_cache: bool = False
    tool_calls: list[dict[str, Any]] | None = None
    reasoning_content: str = ""


# Бюджет ответа по умолчанию. Прежние 2000 не оставляли места тексту, когда
# у роли включён режим рассуждения: рассуждение съедало лимит целиком, и
# `content` приходил пустым.
DEFAULT_MAX_TOKENS = 8192

# Таймаут одного обращения к модели. Прежние 120с оказались недостаточны для
# thinking-режима при больших промптах: модель не успевала ответить, сессия
# агента обрывалась на таймауте, не доходя до submit_summary — и общий вывод
# (Итог/риски/следующий шаг) пропадал. 180с + повторы дают модели шанс дойти
# до конца сессии.
DEFAULT_TIMEOUT = 180

# Повторы при таймауте: помимо первой попытки, делаем ещё `_TIMEOUT_RETRIES`
# запросов с экспоненциальной задержкой. Только для APITimeoutError — прочие
# ошибки (BadRequest/Auth/Connection) не разрешатся повтором и падают сразу,
# как и раньше. Идея: таймаут часто транзитен (длинный thinking, кратковременная
# нагрузка на endpoint), и один повтор возвращает сессию на рельсы — агент
# доходит до submit_summary, блок «Итог» не пропадает.
_TIMEOUT_RETRIES = 2
_TIMEOUT_BACKOFF_BASE = 2.0


@dataclass
class ChatClient:
    spec: ModelSpec
    timeout: int = DEFAULT_TIMEOUT
    cache_dir: Path | None = None
    use_cache: bool = True

    def __post_init__(self) -> None:
        # Единственная точка создания openai-клиента — Phoenix auto_instrument
        # перехватывает его вызовы, если init_phoenix_tracing() уже отработал.
        #
        # mTLS (DeepSeek в AI Hub и т.п.): эндпоинт требует клиентского серта.
        # Рабочая комбинация — verify=CERT_NONE + клиентский серт через
        # load_cert_chain (см. DEEPSEEK_MIGRATION.md §4: при verify=путь-к-CA
        # httpx НЕ шлёт client cert → TLSV13_ALERT_CERTIFICATE_REQUIRED).
        # Передаём httpx.Client в openai SDK — одна точка патча, и все вызовы
        # (chat.completions.create, models.list) идут с сертом. Без сертов —
        # клиент строится как раньше, без http_client=, обратная совместимость.
        self._client = openai.OpenAI(
            base_url=self.spec.base_url,
            api_key=self.spec.api_key or "not-needed",
            timeout=self.timeout,
            http_client=self._build_http_client(),
        )

    def _build_http_client(self) -> httpx.Client | None:
        """httpx-клиент с mTLS, если роль сконфигурирована под сертовый эндпоинт.

        `None` — эндпоинт без mTLS: openai SDK создаст свой httpx-клиент по
        умолчанию (старое поведение, обратная совместимость для GLM/sglang).
        """
        if not self.spec.client_cert:
            return None
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        ctx.load_cert_chain(certfile=self.spec.client_cert, keyfile=self.spec.client_key)
        return httpx.Client(verify=ctx, timeout=self.timeout)

    def health(self) -> bool:
        """Проверка доступности endpoint'а: `GET {base_url}/models`."""
        try:
            self._client.models.list()
            return True
        except Exception:
            return False

    def complete(self, system: str, user: str, temperature: float = 0.0,
                 max_tokens: int = DEFAULT_MAX_TOKENS) -> str:
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        payload: dict[str, Any] = {
            "model": self.spec.upstream_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        extra_body = self.spec.extra_body

        key = self._cache_key(payload, extra_body, method="complete")
        cached = self._read_cache(key)
        if cached is not None:
            # Пустой ответ мог попасть в кеш прошлыми прогонами — он такой же
            # отказ, как и пустой ответ из сети, и молча возвращать его нельзя.
            self._require_text(cached, {})
            return cached

        response = self._create(payload, extra_body=extra_body)
        text = self._text_of(response)
        self._write_cache(key, text)
        return text

    def chat(self, messages: list[dict[str, Any]], temperature: float = 0.0,
             max_tokens: int = DEFAULT_MAX_TOKENS,
             tools: list[dict[str, Any]] | None = None) -> ChatResult:
        """Обмен с произвольной историей — основа агентского цикла.

        `tools` — нативный OpenAI-совместимый tool calling: схемы уходят в
        `tools`/`tool_choice="auto"`, модель сама решает, вызывать инструмент
        или ответить текстом. Кеш изолирован от `complete()` по методу в ключе,
        поэтому повторный прогон того же коммита не тратит ни одного вызова.
        """
        started = time.monotonic()
        try:
            answer = self._chat_impl(messages, temperature, max_tokens, tools)
        except Exception as exc:
            record_llm_call(duration_seconds=time.monotonic() - started,
                            result="error", error_type=type(exc).__name__)
            raise
        record_llm_call(duration_seconds=time.monotonic() - started,
                        result="success", from_cache=answer.from_cache,
                        usage=answer.usage)
        return answer

    def _chat_impl(self, messages: list[dict[str, Any]], temperature: float,
                   max_tokens: int, tools: list[dict[str, Any]] | None) -> ChatResult:
        payload: dict[str, Any] = {
            "model": self.spec.upstream_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        extra_body = self.spec.extra_body

        key = self._cache_key(payload, extra_body, method="chat")
        cached = self._read_cache(key)
        if cached is not None:
            envelope = self._decode_chat_cache(cached)
            if envelope is not None:
                text, tool_calls, reasoning = envelope
                self._require_chat_result(text, tool_calls, {})
                return ChatResult(text=text, usage={}, from_cache=True,
                                  tool_calls=tool_calls, reasoning_content=reasoning)
            # Битый кеш (не JSON-конверт) — трактуем как промах, не роняем прогон.

        response = self._create(payload, extra_body=extra_body)
        text, tool_calls, reasoning = self._message_of(response)
        self._write_cache(key, json.dumps({"content": text, "tool_calls": tool_calls,
                                           "reasoning": reasoning}, ensure_ascii=False))
        usage = self._usage_of(response)
        return ChatResult(text=text, usage=usage, tool_calls=tool_calls,
                          reasoning_content=reasoning)

    # --- вызов модели -----------------------------------------------------

    def _create(self, payload: dict[str, Any], extra_body: dict[str, Any] | None = None) -> Any:
        """Вызов `chat.completions.create` с обработкой ошибок OpenAI SDK.

        `extra_body` — нестандартные параметры (chat_template_kwargs и т.п.),
        передаются через `extra_body` openai SDK, а не как прямые kwargs:
        SDK не знает `chat_template_kwargs` и упадёт с unexpected keyword
        argument. Phoenix auto_instrument перехватывает этот вызов — спан
        создаётся автоматически с моделью, сообщениями, токенами и latency.

        Повторы: только `APITimeoutError` перепытывается (до `_TIMEOUT_RETRIES`
        раз с экспоненциальной задержкой) — таймаут часто транзитен, и повтор
        спасает сессию агента от обрыва до submit_summary. Остальные ошибки
        (BadRequest/Auth/Connection/прочие) не разрешатся повтором — падают
        сразу, как и раньше."""
        kwargs = dict(payload)
        if extra_body:
            kwargs["extra_body"] = extra_body
        for attempt in range(_TIMEOUT_RETRIES + 1):
            try:
                return self._client.chat.completions.create(**kwargs)
            except openai.APITimeoutError as exc:
                if attempt < _TIMEOUT_RETRIES:
                    time.sleep(_TIMEOUT_BACKOFF_BASE * (2 ** attempt))
                    continue
                raise LlmError(
                    f"Таймаут при обращении к {self.spec.base_url} "
                    f"после {_TIMEOUT_RETRIES + 1} попыток.",
                    f"Проверьте подключение к внутренней сети (timeout={self.timeout}с).",
                ) from exc
            except openai.BadRequestError as exc:
                raise LlmError(
                    f"Модель {self.spec.model} отклонила запрос.",
                    str(exc)[:300] or "Проверьте base_url, имя модели и формат запроса.",
                ) from exc
            except openai.APIConnectionError as exc:
                raise LlmError(
                    f"Не удалось обратиться к {self.spec.base_url}.",
                    f"{exc}. Проверьте подключение к внутренней сети.",
                ) from exc
            except openai.AuthenticationError as exc:
                raise LlmError(
                    f"Модель {self.spec.model}: ошибка аутентификации.",
                    "Проверьте API-ключ роли.",
                ) from exc
            except Exception as exc:
                raise LlmError(
                    f"Модель {self.spec.model} вернула ошибку.",
                    str(exc)[:300] or "неизвестная ошибка",
                ) from exc
        # Недостижимо: каждая итерация либо возвращает результат, либо raise'ит.
        raise LlmError(
            f"Неожиданный выход из цикла повторов в _create ({self.spec.model}).",
            "Внутренняя ошибка клиента — сообщите разработчикам.",
        )

    # --- разбор ответа ----------------------------------------------------
    def _text_of(self, response: Any) -> str:
        """Текст ответа. Пустой ответ — отказ, а не пустая строка.

        Тихая деградация обходилась дороже отказа: writer с включённым
        рассуждением возвращал пустой `content`, весь бюджет уходил в
        рассуждение, отчёт молча собирался шаблоном, а пустая строка ещё и
        оседала в кеше — повторный прогон давал тот же результат.
        """
        try:
            message = response.choices[0].message
            finish = str(response.choices[0].finish_reason or "")
        except (AttributeError, IndexError) as exc:
            raise LlmError(
                f"Неожиданный ответ модели {self.spec.model}.",
                "Проверьте, что endpoint OpenAI-совместим.",
            ) from exc

        # `reasoning_content` — внутренняя цепочка рассуждений, а не ответ
        # роли. Публиковать и кешировать её вместо `content` нельзя: endpoint,
        # исчерпавший бюджет на thinking, тем самым не выполнил запрос.
        text = str(message.content or "").strip()
        self._require_text(text, {"finish_reason": finish})
        return text

    def _require_text(self, text: str, context: dict[str, str]) -> None:
        if text and text.strip():
            return
        finish = context.get("finish_reason", "")
        hint = "Проверьте лимит длины ответа и режим рассуждения для этой роли."
        if finish == "length":
            hint = ("Ответ оборван по длине: увеличьте max_tokens или отключите "
                    "режим рассуждения для этой роли.")
        raise LlmError(
            f"Модель {self.spec.model} (роль {self.spec.role}) вернула пустой ответ.",
            hint,
        )

    def _message_of(self, response: Any) -> tuple[str, list[dict[str, Any]] | None, str]:
        """Текст, tool_calls и reasoning_content ответа для `chat()`.

        Пустой `content` при непустом `tool_calls` — штатная форма ответа при
        вызове инструмента (многие OpenAI-совместимые бэкенды отдают именно
        `content: null`), не отказ. Отказ — только когда пусты оба поля разом.
        `reasoning_content` — цепочка рассуждений модели, сохраняется отдельно
        для анализа; она не подменяет `content` (endpoint, исчерпавший бюджет
        на thinking, тем самым не выполнил запрос — `_require_chat_result`
        это поймает по пустым content+tool_calls)."""
        try:
            message = response.choices[0].message
            finish = str(response.choices[0].finish_reason or "")
        except (AttributeError, IndexError) as exc:
            raise LlmError(
                f"Неожиданный ответ модели {self.spec.model}.",
                "Проверьте, что endpoint OpenAI-совместим.",
            ) from exc

        text = str(message.content or "").strip()
        raw_tool_calls = message.tool_calls if hasattr(message, "tool_calls") else None
        tool_calls = self._serialize_tool_calls(raw_tool_calls)
        reasoning = str(getattr(message, "reasoning_content", "") or getattr(message, "reasoning", "") or "")
        self._require_chat_result(text, tool_calls, {"finish_reason": finish})
        return text, tool_calls, reasoning

    def _serialize_tool_calls(self, raw: Any) -> list[dict[str, Any]] | None:
        """Привести tool_calls из openai SDK к dict-формату для истории сессии.

        openai SDK отдаёт Pydantic-модели; агентский цикл работает с dict'ами
        (JSON-сообщения). Без нормализации `message.tool_calls` осел бы в
        history как объект, а не dict."""
        if not raw:
            return None
        out: list[dict[str, Any]] = []
        for tc in raw:
            out.append({
                "id": str(getattr(tc, "id", "") or ""),
                "type": "function",
                "function": {
                    "name": str(getattr(tc.function, "name", "") or ""),
                    "arguments": str(getattr(tc.function, "arguments", "") or ""),
                },
            })
        return out or None

    def _usage_of(self, response: Any) -> dict[str, Any]:
        usage = getattr(response, "usage", None)
        if usage is None:
            return {}
        return {
            "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
            "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
            "total_tokens": getattr(usage, "total_tokens", 0) or 0,
        }

    def _require_chat_result(self, text: str, tool_calls: list[dict[str, Any]] | None,
                              context: dict[str, str]) -> None:
        if tool_calls or (text and text.strip()):
            return
        self._require_text(text, context)

    def _decode_chat_cache(self, cached: str) -> tuple[str, list[dict[str, Any]] | None, str] | None:
        try:
            envelope = json.loads(cached)
        except json.JSONDecodeError:
            return None
        if not isinstance(envelope, dict):
            return None
        text = str(envelope.get("content") or "")
        raw_tool_calls = envelope.get("tool_calls")
        tool_calls = raw_tool_calls if isinstance(raw_tool_calls, list) and raw_tool_calls else None
        reasoning = str(envelope.get("reasoning") or "")
        return text, tool_calls, reasoning

    # --- кеш ---------------------------------------------------------------
    def _cache_key(self, payload: dict[str, Any], extra_body: dict[str, Any] | None = None,
                   method: str = "complete") -> str:
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True)
        if extra_body:
            raw += "|extra:" + json.dumps(extra_body, ensure_ascii=False, sort_keys=True)
        return hashlib.sha256(f"{method}|{self.spec.base_url}|{raw}".encode("utf-8")).hexdigest()

    def _cache_file(self, key: str) -> Path:
        root = self.cache_dir or DEFAULT_CACHE_DIR
        return root / f"{key}.txt"

    def _read_cache(self, key: str) -> str | None:
        if not self.use_cache:
            return None
        path = self._cache_file(key)
        if path.exists():
            try:
                return path.read_text(encoding="utf-8")
            except OSError:
                return None
        return None

    def _write_cache(self, key: str, text: str) -> None:
        if not self.use_cache:
            return
        path = self._cache_file(key)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
        except OSError:
            return
        # Кеш содержит описание корпоративной системы, полученное моделью, —
        # та же конфиденциальность, что и у зеркала репозитория.
        harden_dir(path.parent, path.parent.parent)
        harden_file(path)


def chat(spec: ModelSpec, system: str, user: str, **kwargs: Any) -> str:
    return ChatClient(spec=spec).complete(system=system, user=user, **kwargs)

"""Prometheus exporter for completed and active CLI runs in JSONL journals.

The CLI exits after each analysis, so scraping its process directly would lose
the final measurements. This small server replays existing files at startup and
tails new records on every scrape. It has no external Python dependencies.
"""

from __future__ import annotations

import argparse
import json
import threading
import time
from collections import Counter
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from pko.monitoring import monitor_dir


PASSES = ("matcher", "critic", "coherence", "passport")
PASS_LABELS = {
    "setup": "Подготовка",
    "matcher": "1 · Разбор пунктов",
    "critic": "2 · Строгая проверка",
    "coherence": "3 · Связность",
    "passport": "4 · Построение паспорта",
    "between_passes": "Переход к следующему этапу",
    "finished": "Прогон завершён",
}
RUN_RESULTS = ("success", "error", "interrupted")
CALL_RESULTS = ("success", "error")
BUCKETS = (1, 5, 10, 30, 60, 120, 300, 600, 1200, 1800, 3600)
STALE_AFTER_SECONDS = 30 * 60
MAX_VISIBLE_RUNS = 20


@dataclass
class Histogram:
    count: int = 0
    total: float = 0.0
    buckets: Counter[float] = field(default_factory=Counter)

    def observe(self, value: Any) -> None:
        try:
            number = float(value)
        except (TypeError, ValueError):
            return
        if number < 0:
            return
        self.count += 1
        self.total += number
        for bound in BUCKETS:
            if number <= bound:
                self.buckets[bound] += 1


@dataclass
class RunState:
    started_at: float
    last_event_at: float
    phase: str = "setup"
    step: int = 0
    finished: bool = False
    result: str = "running"
    finished_at: float = 0.0
    duration: float = 0.0
    step_started_at: float = 0.0
    nodes: int = 0
    tokens: Counter[tuple[str, str]] = field(default_factory=Counter)
    step_durations: dict[tuple[str, int], float] = field(default_factory=dict)


class EventMetrics:
    def __init__(self, directory: Path) -> None:
        self.directory = directory
        self.offsets: dict[Path, int] = {}
        self.runs: dict[str, RunState] = {}
        self.run_results: Counter[str] = Counter()
        self.pass_results: Counter[tuple[str, str]] = Counter()
        self.steps: Counter[str] = Counter()
        self.calls: Counter[tuple[str, str, str]] = Counter()
        self.tokens: Counter[tuple[str, str]] = Counter()
        self.gate_rejections: Counter[tuple[str, str]] = Counter()
        self.passports_without_data = 0
        self.passport_render_errors = 0
        self.run_duration = Histogram()
        self.pass_duration = {name: Histogram() for name in PASSES}
        self.step_duration = {name: Histogram() for name in PASSES}
        self.llm_duration = {name: Histogram() for name in PASSES}
        self.last_run_duration = 0.0
        self.last_run_finished_at = 0.0

    def refresh(self) -> None:
        if not self.directory.is_dir():
            return
        for path in sorted(self.directory.glob("run_*.jsonl")):
            try:
                with path.open("rb") as stream:
                    stream.seek(self.offsets.get(path, 0))
                    while True:
                        position = stream.tell()
                        raw = stream.readline()
                        if not raw:
                            break
                        if not raw.endswith(b"\n"):
                            stream.seek(position)
                            break
                        try:
                            record = json.loads(raw)
                        except (UnicodeDecodeError, json.JSONDecodeError):
                            continue
                        if isinstance(record, dict):
                            self.ingest(record)
                    self.offsets[path] = stream.tell()
            except OSError:
                continue

    def ingest(self, record: dict[str, Any]) -> None:
        event = record.get("event")
        run_id = record.get("run_id")
        if not isinstance(run_id, str) or not run_id.startswith("run_"):
            return
        try:
            at = float(record.get("at") or 0)
        except (TypeError, ValueError):
            return
        if event == "run_started":
            self.runs[run_id] = RunState(started_at=at, last_event_at=at)
            return
        run = self.runs.get(run_id)
        if run is None:
            return
        run.last_event_at = max(run.last_event_at, at)
        phase = record.get("pass")
        valid_phase = phase if isinstance(phase, str) and phase in PASSES else ""
        if event == "pass_started" and valid_phase:
            run.phase, run.step = valid_phase, 0
            run.step_started_at = 0.0
        elif event == "step_started" and valid_phase:
            run.phase = valid_phase
            try:
                run.step = max(run.step, int(record.get("step") or 0))
                run.step_started_at = at
            except (TypeError, ValueError):
                pass
        elif event == "step_finished" and valid_phase:
            self.steps[valid_phase] += 1
            duration = record.get("duration_seconds")
            self.step_duration[valid_phase].observe(duration)
            try:
                run.step_durations[valid_phase, int(record.get("step") or 0)] = max(0.0, float(duration))
            except (TypeError, ValueError):
                pass
            run.step_started_at = 0.0
        elif event == "pass_finished" and valid_phase:
            self.pass_duration[valid_phase].observe(record.get("duration_seconds"))
            finished = record.get("finished")
            result = "error" if record.get("result") == "error" else (
                "incomplete" if finished is False else "completed"
            )
            self.pass_results[valid_phase, result] += 1
            run.phase = "between_passes"
            run.step_started_at = 0.0
            try:
                run.nodes = max(run.nodes, int(record.get("nodes") or 0))
            except (TypeError, ValueError):
                pass
        elif event == "llm_call_finished" and valid_phase:
            result = record.get("result")
            if result in CALL_RESULTS:
                cache = "hit" if record.get("from_cache") else "miss"
                self.calls[valid_phase, result, cache] += 1
                self.llm_duration[valid_phase].observe(record.get("duration_seconds"))
                for token_type in ("prompt", "completion"):
                    try:
                        amount = max(0, int(record.get(f"{token_type}_tokens") or 0))
                    except (TypeError, ValueError):
                        amount = 0
                    self.tokens[valid_phase, token_type] += amount
                    run.tokens[valid_phase, token_type] += amount
        elif event == "gate_event" and valid_phase:
            kind = record.get("kind")
            if isinstance(kind, str) and kind.endswith("_rejected"):
                self.gate_rejections[valid_phase, kind] += 1
            if kind == "node_accepted":
                try:
                    run.nodes = max(run.nodes, int(record.get("count") or 0))
                except (TypeError, ValueError):
                    pass
        elif event == "heartbeat":
            if valid_phase:
                run.phase = valid_phase
            try:
                run.step = max(run.step, int(record.get("step") or 0))
                run.nodes = max(run.nodes, int(record.get("nodes") or 0))
            except (TypeError, ValueError):
                pass
        elif event == "model_ready":
            if record.get("passport_present") is False:
                self.passports_without_data += 1
        elif event == "passport_render_failed":
            self.passport_render_errors += 1
        elif event == "run_finished":
            result = record.get("result")
            if result in RUN_RESULTS:
                self.run_results[result] += 1
            self.run_duration.observe(record.get("duration_seconds"))
            if at >= self.last_run_finished_at:
                self.last_run_duration = float(record.get("duration_seconds") or 0)
                self.last_run_finished_at = at
            run.phase = "finished"
            run.finished = True
            run.result = result if result in RUN_RESULTS else "error"
            run.finished_at = at
            try:
                run.duration = max(0.0, float(record.get("duration_seconds") or 0))
            except (TypeError, ValueError):
                run.duration = max(0.0, at - run.started_at)

    def render(self, now: float | None = None) -> str:
        self.refresh()
        now = time.time() if now is None else now
        rows: list[str] = []

        def escaped(value: Any) -> str:
            return str(value).replace("\\", "\\\\").replace("\n", "\\n").replace('"', '\\"')

        def labels(**values: Any) -> str:
            return "{" + ",".join(f'{key}="{escaped(value)}"' for key, value in values.items()) + "}"

        def metric(name: str, kind: str, help_text: str, samples: list[tuple[str, int | float]]) -> None:
            rows.extend((f"# HELP {name} {help_text}", f"# TYPE {name} {kind}"))
            rows.extend(f"{name}{labels} {value}" for labels, value in samples)

        metric("pko_runs_total", "counter", "Completed CLI runs by result.",
               [(f'{{result="{result}"}}', self.run_results[result]) for result in RUN_RESULTS])
        metric("pko_pass_results_total", "counter", "Pass completion results.",
               [(f'{{pass="{phase}",result="{result}"}}', self.pass_results[phase, result])
                for phase in PASSES for result in ("completed", "incomplete", "error")])
        active = [run for run in self.runs.values() if not run.finished and
                  now - run.last_event_at < STALE_AFTER_SECONDS]
        stale = [run for run in self.runs.values() if not run.finished and
                 now - run.last_event_at >= STALE_AFTER_SECONDS]
        metric("pko_active_runs", "gauge", "CLI runs with recent events.", [("", len(active))])
        metric("pko_stale_runs", "gauge", "Unfinished runs with no events for 30 minutes.",
               [("", len(stale))])
        metric("pko_active_pass", "gauge", "Active runs by current pass.",
               [(f'{{pass="{phase}"}}', sum(run.phase == phase for run in active))
                for phase in PASSES])
        metric("pko_active_step", "gauge", "Highest current step among active runs by pass.",
               [(f'{{pass="{phase}"}}', max((run.step for run in active if run.phase == phase), default=0))
                for phase in PASSES])
        metric("pko_oldest_active_run_seconds", "gauge", "Age of oldest active run.",
               [("", round(max((now - run.started_at for run in active), default=0), 3))])
        metric("pko_steps_total", "counter", "Completed agent steps by pass.",
               [(f'{{pass="{phase}"}}', self.steps[phase]) for phase in PASSES])

        visible = sorted(self.runs.items(), key=lambda item: item[1].last_event_at, reverse=True)[:MAX_VISIBLE_RUNS]
        latest_id = max(self.runs, key=lambda key: self.runs[key].started_at) if self.runs else ""
        result_labels = {
            "running": "Выполняется", "success": "Завершён успешно",
            "error": "Ошибка", "interrupted": "Остановлен",
        }
        metric("pko_latest_run_info", "gauge", "Newest observed CLI run.",
               [(labels(run_id=latest_id), 1)] if latest_id else [])
        metric("pko_run_info", "gauge", "Recent CLI runs and their result.", [
            (labels(run_id=run_id, result=run.result,
                    result_label=result_labels.get(run.result, run.result)), 1)
            for run_id, run in visible
        ])
        status_codes = {"running": 1, "success": 2, "error": 3, "interrupted": 4}
        metric("pko_run_status_code", "gauge", "Numeric state of a recent CLI run.", [
            (labels(run_id=run_id), status_codes.get(run.result, 3))
            for run_id, run in visible
        ])
        metric("pko_run_active", "gauge", "Whether a recent CLI run is active.", [
            (labels(run_id=run_id), int(not run.finished and now - run.last_event_at < STALE_AFTER_SECONDS))
            for run_id, run in visible
        ])
        metric("pko_run_current_pass_info", "gauge", "Current pass of a recent CLI run.", [
            (labels(run_id=run_id, **{"pass": run.phase},
                    pass_label=PASS_LABELS.get(run.phase, run.phase)), 1)
            for run_id, run in visible
        ])
        metric("pko_run_current_step", "gauge", "Current agent step of a recent CLI run.", [
            (labels(run_id=run_id, **{"pass": run.phase},
                    pass_label=PASS_LABELS.get(run.phase, run.phase)), run.step)
            for run_id, run in visible
        ])
        metric("pko_run_current_step_elapsed_seconds", "gauge", "Elapsed time of the current step.", [
            (labels(run_id=run_id), round(max(0.0, now - run.step_started_at), 3) if run.step_started_at else 0)
            for run_id, run in visible
        ])
        metric("pko_run_nodes", "gauge", "Accepted passport nodes in a recent CLI run.", [
            (labels(run_id=run_id), run.nodes) for run_id, run in visible
        ])
        metric("pko_run_elapsed_seconds", "gauge", "Elapsed duration of a recent CLI run.", [
            (labels(run_id=run_id), round(run.duration if run.finished else max(0.0, now - run.started_at), 3))
            for run_id, run in visible
        ])
        metric("pko_run_last_event_age_seconds", "gauge", "Seconds since the last event or heartbeat.", [
            (labels(run_id=run_id), round(max(0.0, now - run.last_event_at), 3))
            for run_id, run in visible
        ])
        metric("pko_run_step_duration_seconds", "gauge", "Duration of each completed step in recent runs.", [
            (labels(run_id=run_id, **{"pass": phase}, pass_label=PASS_LABELS[phase], step=step), duration)
            for run_id, run in visible for (phase, step), duration in sorted(run.step_durations.items())
        ])
        token_labels = {"prompt": "Вход", "completion": "Ответ"}
        metric("pko_run_llm_tokens_total", "counter", "LLM tokens accumulated inside recent runs.", [
            (labels(run_id=run_id, **{"pass": phase}, pass_label=PASS_LABELS[phase],
                    type=token_type, type_label=token_labels[token_type]), amount)
            for run_id, run in visible for (phase, token_type), amount in sorted(run.tokens.items())
        ])
        metric("pko_llm_calls_total", "counter", "LLM calls by pass, result and cache use.",
               [(f'{{pass="{phase}",result="{result}",cache="{cache}"}}',
                 self.calls[phase, result, cache])
                for phase in PASSES for result in CALL_RESULTS for cache in ("hit", "miss")])
        metric("pko_llm_tokens_total", "counter", "Reported LLM tokens by pass and type.",
               [(f'{{pass="{phase}",type="{token_type}"}}', self.tokens[phase, token_type])
                for phase in PASSES for token_type in ("prompt", "completion")])
        metric("pko_gate_rejections_total", "counter", "Rejected passport submissions.",
               [(f'{{pass="{phase}",kind="{kind}"}}', count)
                for (phase, kind), count in sorted(self.gate_rejections.items())])
        metric("pko_passports_without_data_total", "counter", "Runs with no agent passport data.",
               [("", self.passports_without_data)])
        metric("pko_passport_render_errors_total", "counter", "Passport HTML render failures.",
               [("", self.passport_render_errors)])
        metric("pko_last_run_duration_seconds", "gauge", "Duration of latest completed run.",
               [("", self.last_run_duration)])
        metric("pko_last_run_finished_timestamp_seconds", "gauge", "Time of latest completed run.",
               [("", self.last_run_finished_at)])

        def histogram(name: str, help_text: str, series: list[tuple[str, Histogram]]) -> None:
            rows.extend((f"# HELP {name} {help_text}", f"# TYPE {name} histogram"))
            for labels, item in series:
                prefix = labels + "," if labels else "{"
                for bound in BUCKETS:
                    rows.append(f'{name}_bucket{prefix}le="{bound}"}} {item.buckets[bound]}')
                rows.append(f'{name}_bucket{prefix}le="+Inf"}} {item.count}')
                suffix = labels + "}" if labels else ""
                rows.append(f"{name}_sum{suffix} {item.total}")
                rows.append(f"{name}_count{suffix} {item.count}")

        histogram("pko_run_duration_seconds", "Whole CLI run duration.", [("", self.run_duration)])
        histogram("pko_pass_duration_seconds", "Agent pass duration.",
                  [('{pass="' + phase + '"', self.pass_duration[phase]) for phase in PASSES])
        histogram("pko_step_duration_seconds", "Agent step duration.",
                  [('{pass="' + phase + '"', self.step_duration[phase]) for phase in PASSES])
        histogram("pko_llm_call_duration_seconds", "LLM call duration.",
                  [('{pass="' + phase + '"', self.llm_duration[phase]) for phase in PASSES])
        return "\n".join(rows) + "\n"


def serve(directory: Path, host: str = "0.0.0.0", port: int = 9108) -> None:
    metrics = EventMetrics(directory)
    scrape_lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802 — BaseHTTPRequestHandler contract
            if self.path == "/metrics":
                with scrape_lock:
                    body = metrics.render().encode("utf-8")
                content_type = "text/plain; version=0.0.4; charset=utf-8"
            elif self.path == "/healthz":
                body = b"ok\n"
                content_type = "text/plain; charset=utf-8"
            else:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    ThreadingHTTPServer((host, port), Handler).serve_forever()


def main() -> None:
    parser = argparse.ArgumentParser(description="Prometheus metrics for PKO CLI runs")
    parser.add_argument("--dir", type=Path, default=monitor_dir())
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=9108)
    args = parser.parse_args()
    serve(args.dir, args.host, args.port)


if __name__ == "__main__":
    main()

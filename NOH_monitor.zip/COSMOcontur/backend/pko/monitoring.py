"""Small, CLI-first event journal for local Grafana monitoring.

Each run owns one JSONL file. Monitoring is deliberately independent of SSE and
Phoenix: a short-lived CLI process can be watched while it runs and inspected
after it exits. Only bounded operational fields are written, never prompts,
source code, model answers, credentials, or exception messages.
"""

from __future__ import annotations

import json
import os
import sys
import threading
import time
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator


SESSION_PASSES = {
    "agent_session": "matcher",
    "critic_session": "critic",
    "coherence_session": "coherence",
    "passport_session": "passport",
}
STEP_PASSES = {
    "agent.step": "matcher",
    "critic.step": "critic",
    "coherence.step": "coherence",
    "passport.step": "passport",
}
SAFE_ATTRIBUTES = {
    "steps_done", "finished", "nodes", "relations", "defects", "risks",
    "risks_reviewed", "verdicts", "claims", "lowered", "flaws", "scenarios",
}
SAFE_GATE_EVENTS = {
    "node_rejected", "node_accepted", "children_rejected", "children_declared",
    "relation_rejected", "relation_accepted", "defect_rejected", "defect_accepted",
    "need_accepted", "guardrail_accepted", "risks_rejected", "risks_accepted",
}

_CURRENT_RUN: ContextVar[RunJournal | None] = ContextVar("pko_monitor_run", default=None)
_CURRENT_PASS: ContextVar[str] = ContextVar("pko_monitor_pass", default="")


def monitor_dir() -> Path:
    configured = (os.environ.get("PKO_MONITOR_DIR") or "").strip()
    return Path(configured).expanduser().resolve() if configured else Path.home() / ".pko" / "monitoring"


@dataclass
class RunJournal:
    run_id: str
    path: Path | None
    started: float = field(default_factory=time.monotonic)
    _warned: bool = False
    phase: str = "setup"
    step: int = 0
    nodes: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def emit(self, event: str, **fields: Any) -> None:
        with self._lock:
            if self.path is None:
                return
            phase = fields.get("pass")
            if event == "pass_started" and isinstance(phase, str):
                self.phase, self.step = phase, 0
            elif event == "step_started" and isinstance(phase, str):
                self.phase = phase
                try:
                    self.step = max(0, int(fields.get("step") or 0))
                except (TypeError, ValueError):
                    pass
            elif event == "gate_event" and fields.get("kind") == "node_accepted":
                try:
                    self.nodes = max(self.nodes, int(fields.get("count") or 0))
                except (TypeError, ValueError):
                    pass
            elif event == "pass_finished":
                try:
                    self.nodes = max(self.nodes, int(fields.get("nodes") or 0))
                except (TypeError, ValueError):
                    pass
            payload = {
                "ts": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                "at": time.time(),
                "run_id": self.run_id,
                "source": "cli",
                "event": event,
                **fields,
            }
            try:
                # Heartbeat and the CLI thread can write at the same time. The
                # lock keeps each JSONL record whole and immediately visible.
                with self.path.open("a", encoding="utf-8", newline="\n") as stream:
                    stream.write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")
            except (OSError, TypeError, ValueError) as exc:
                if not self._warned:
                    print(f"Мониторинг недоступен: {exc}", file=sys.stderr)
                    self._warned = True
                self.path = None

    def heartbeat(self) -> None:
        self.emit("heartbeat", **{"pass": self.phase}, step=self.step, nodes=self.nodes)


@contextmanager
def monitored_cli_run() -> Iterator[RunJournal]:
    run_id = "run_" + uuid.uuid4().hex[:12]
    path: Path | None = None
    try:
        directory = monitor_dir()
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{run_id}.jsonl"
    except OSError as exc:
        print(f"Мониторинг недоступен: {exc}", file=sys.stderr)
    journal = RunJournal(run_id=run_id, path=path)
    token = _CURRENT_RUN.set(journal)
    journal.emit("run_started")
    heartbeat_stop = threading.Event()

    def heartbeat_loop() -> None:
        while not heartbeat_stop.wait(15):
            journal.heartbeat()

    heartbeat_thread = threading.Thread(
        target=heartbeat_loop, name=f"pko-monitor-{run_id}", daemon=True,
    )
    heartbeat_thread.start()
    try:
        yield journal
    except BaseException as exc:
        result = "interrupted" if isinstance(exc, KeyboardInterrupt) else "error"
        journal.emit("run_finished", result=result, error_type=type(exc).__name__,
                     duration_seconds=round(time.monotonic() - journal.started, 3))
        raise
    else:
        journal.emit("run_finished", result="success",
                     duration_seconds=round(time.monotonic() - journal.started, 3))
    finally:
        heartbeat_stop.set()
        heartbeat_thread.join(timeout=1)
        _CURRENT_RUN.reset(token)


def current_run() -> RunJournal | None:
    return _CURRENT_RUN.get()


def record_llm_call(*, duration_seconds: float, result: str, from_cache: bool = False,
                    usage: dict[str, Any] | None = None, error_type: str = "") -> None:
    journal = current_run()
    if journal is None:
        return
    usage = usage or {}
    def tokens(key: str) -> int:
        try:
            return max(0, int(usage.get(key) or 0))
        except (TypeError, ValueError):
            return 0

    journal.emit(
        "llm_call_finished", **{"pass": _CURRENT_PASS.get()}, result=result,
        from_cache=bool(from_cache), duration_seconds=round(duration_seconds, 3),
        prompt_tokens=tokens("prompt_tokens"),
        completion_tokens=tokens("completion_tokens"),
        error_type=error_type,
    )


@dataclass
class SpanObservation:
    journal: RunJournal | None
    phase: str = ""
    step: int = 0
    kind: str = ""
    started: float = field(default_factory=time.monotonic)
    attributes: dict[str, Any] = field(default_factory=dict)

    def set_attribute(self, key: str, value: Any) -> None:
        if key in SAFE_ATTRIBUTES and isinstance(value, (str, int, float, bool)):
            self.attributes[key] = value

    def add_event(self, name: str, attributes: dict[str, Any]) -> None:
        if self.journal is None or name not in SAFE_GATE_EVENTS:
            return
        fields: dict[str, Any] = {"pass": self.phase, "kind": name}
        for key in ("count", "attempts", "remarks"):
            value = attributes.get(key)
            if isinstance(value, int):
                fields[key] = value
        self.journal.emit("gate_event", **fields)


@contextmanager
def observe_span(name: str, attributes: dict[str, Any]) -> Iterator[SpanObservation]:
    journal = current_run()
    phase = SESSION_PASSES.get(name) or STEP_PASSES.get(name) or ""
    kind = "pass" if name in SESSION_PASSES else "step" if name in STEP_PASSES else ""
    observation = SpanObservation(journal=journal, phase=phase, kind=kind)
    token = None
    if journal is not None and kind == "pass":
        token = _CURRENT_PASS.set(phase)
        journal.emit("pass_started", **{"pass": phase})
    elif journal is not None and kind == "step":
        observation.step = int(attributes.get("step") or 0)
        journal.emit("step_started", **{"pass": phase}, step=observation.step)
    failed = False
    try:
        yield observation
    except BaseException:
        failed = True
        raise
    finally:
        if journal is not None and kind:
            fields = {"pass": phase, "duration_seconds": round(time.monotonic() - observation.started, 3)}
            if kind == "step":
                fields["step"] = observation.step
            else:
                fields.update(observation.attributes)
            fields["result"] = "error" if failed else "completed"
            journal.emit(f"{kind}_finished", **fields)
        if token is not None:
            _CURRENT_PASS.reset(token)

# Проверенные источники кейсов операционного риска

Этот файл нужен человеку для аудита библиотеки примеров. Паспортный агент читает только `backend/pko/progress/risk_hypothesis_guide.md` и не получает эти ссылки. Инцидент другой организации никогда не является основанием риска анализируемого проекта.

| Кейс | Первичный источник | Что подтверждает |
|---|---|---|
| TSB, 2018 | [FCA: итог расследования миграции](https://www.fca.org.uk/news/press-releases/tsb-fined-48m-operational-resilience-failings), [FCA Final Notice](https://www.fca.org.uk/publication/final-notices/tsb-bank-plc-2022.pdf) | Сбои после миграции, недоступность каналов, проблемы подготовки и управления аутсорсингом. |
| RBS/NatWest/Ulster, 2012 | [FCA: меры за ИТ-сбой](https://www.fca.org.uk/news/press-releases/fca-fines-rbs-natwest-and-ulster-bank-ltd-%C2%A342-million-it-failures), [FCA Final Notice](https://www.fca.org.uk/publication/final-notices/rbs-natwest-ulster-final-notice.pdf) | Несовместимый откат планировщика, пропущенные задания и нарушение обработки счетов. |
| Citibank/Revlon, 2020 | [Отчёт Citigroup в SEC](https://www.sec.gov/Archives/edgar/data/831001/000083100120000110/c-20200930.htm) | Ошибочный перевод около 894 млн долларов; названные Citi факторы: человек, поставщик, система. |
| Wells Fargo, 2016 | [Сообщение CFPB](https://www.consumerfinance.gov/archive/newsroom/consumer-financial-protection-bureau-fines-wells-fargo-100-million-widespread-illegal-practice-secretly-opening-unauthorized-accounts/), [согласованное предписание](https://files.consumerfinance.gov/f/documents/092016_cfpb_WFBconsentorder.pdf) | Открытие счетов и перевод средств без согласия клиента, влияние целей продаж. |
| Knight Capital, 2012 | [Приказ SEC](https://www.sec.gov/Archives/edgar/data/1569391/000119312513401173/d613486dex101.htm), [сообщение SEC](https://www.sec.gov/newsroom/press-releases/2013-222) | Неполное развертывание кода, массовые ошибочные заявки и убытки. |
| Bangladesh Bank, 2016 | [Обвинительный акт Минюста США](https://www.justice.gov/usao-cdca/press-release/file/1091951/dl?inline=) | Компрометация терминалов и отправка поддельных SWIFT-сообщений. |
| Московская биржа, август 2024 | [Сообщение биржи](https://www.moex.com/n71971) | Ошибка работы с памятью серверов доступа и временная остановка фондовых торгов. |
| Московская биржа, ноябрь 2024 | [Сообщение биржи](https://www.moex.com/n75020) | Аппаратная ошибка сервера предварительной проверки рисков, переход на резервное оборудование. |
| Банк России/ФинЦЕРТ, февраль 2021 | [Сообщение Банка России](https://www.cbr.ru/press/event/?id=12548) | Обнаружение подозрительной активности и остановка платежей; причина атаки не раскрыта. |

Каталог 25 сценариев не является статистическим топом. Для российского контекста при отборе использованы [разъяснения Банка России по 716-П](https://www.cbr.ru/faq_ufr/dbrnfaq/doc?number=716-%D0%9F) (в том числе ошибки реквизитов и задвоение платежа) и [обзор компьютерных атак и инцидентов операционной надёжности за 2024 год](https://www.cbr.ru/Collection/Collection/File/55129/Attack_2024.pdf). Они задают темы проверки, но не служат доказательством риска конкретного проекта.

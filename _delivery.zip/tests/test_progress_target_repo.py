"""Чтение целевого репозитория для пайплайна прогресса — тонкая обвязка над
уже проверенными git/extractors, поэтому проверяется только само подключение.
"""

import unittest

from fixture_support import ensure_fixture
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.progress.target_repo import load_target


class LoadTargetTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.repo = GitRepo(ensure_fixture())

    def test_loads_pinned_commit_with_facts(self):
        target = load_target(self.repo, branch="master")
        self.assertEqual(target.branch, "master")
        self.assertTrue(target.sha)
        self.assertEqual(target.tree.sha, target.sha)
        self.assertGreater(len(target.tree.files), 0)
        self.assertGreater(len(target.extraction.facts), 0)

    def test_default_branch_used_when_not_specified(self):
        target = load_target(self.repo)
        self.assertTrue(target.branch)


class RussianTextSurvivesReading(unittest.TestCase):
    """Кириллица из кода не должна приезжать как «РќР°Р№С‚Рё».

    `subprocess.run(text=True)` без явной кодировки берёт кодировку системы:
    под Windows это cp1251, и весь русский текст файлов превращается в мусор.
    Агент после этого не может искать по смыслу — искать не в чем, — а
    evidence с кириллическим основанием не подтверждается.
    """

    def test_docstring_in_russian_is_read_as_utf8(self) -> None:
        repo = GitRepo(ensure_fixture())
        tree = Tree.at(repo, repo.resolve("master"))
        text = tree.read("backend/src/agent/tools.py") or ""
        self.assertIn("Найти подходящие таблицы", text)
        self.assertNotIn("РќР°Р№С‚Рё", text)

    def test_batch_and_single_reader_agree(self) -> None:
        """Два пути чтения не должны расходиться в кодировке."""
        repo = GitRepo(ensure_fixture())
        sha = repo.resolve("master")
        path = "backend/src/agent/tools.py"
        self.assertEqual(repo.read_text(sha, path),
                         repo.read_text_batch(sha, [path])[path])


if __name__ == "__main__":
    unittest.main()

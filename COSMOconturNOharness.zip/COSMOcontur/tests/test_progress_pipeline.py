"""`run_progress` — сквозная сборка ProgressModel, с фокусом на `on_event`.

Проверяет колбэк живого прогресса напрямую через `run_progress`, без CLI/HTTP
обвязки.
"""

import unittest

import pko.llm.client as client_module
from agent_script import (
    AFTER,
    BEFORE,
    BULLETS,
    CLIENT_PATH_NAME,
    CONCLUSION,
    CONTEXT,
    DESCRIPTION,
    JOURNEY_TEXT,
    NOW,
    PROJECT_NAME,
    STAGE_TITLE,
    full_session,
    stage_args,
    summary_args,
    tool_call,
)
from fixture_support import ensure_fixture, scripted_responses
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress import pipeline
from pko.progress.pipeline import run_progress
from pko.progress.target_repo import TargetRepo, load_target

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")


class RunProgressOnEventTest(unittest.TestCase):
    def setUp(self):
        repo = GitRepo(ensure_fixture())
        self.target: TargetRepo = load_target(repo, "master")

        import tempfile
        from pathlib import Path
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

        self._original_cache_dir = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = Path(self.tmp.name) / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._original_cache_dir)

        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)

    def test_on_event_receives_phases_and_claims_in_order(self):
        ChatClient._create = scripted_responses(*full_session(with_brief=True))

        events: list[tuple[str, dict]] = []
        model = run_progress(
            JOURNEY_TEXT, "demo-repo", self.target, SPEC,
            on_event=lambda kind, data: events.append((kind, data)),
            description=DESCRIPTION,
        )

        # После вердикта первого агента — строгая проверка (рецензент), затем
        # ревизия связности, затем паспортная сессия: по событию на каждый
        # принятый узел (6 в `passport_session`) и итог.
        kinds = [kind for kind, _ in events]
        self.assertEqual(kinds[:5], [
            "plan_ready", "claim_verified", "summary_ready", "phase", "phase",
        ])
        self.assertEqual(events[3][1]["phase"], "critic")
        self.assertEqual(events[4][1]["phase"], "coherence")
        self.assertEqual(kinds[5], "passport_started")
        self.assertEqual(kinds[6:-1], ["passport_node"] * 6)
        self.assertEqual(events[-1], ("passport_ready", {"nodes": 6}))
        self.assertEqual(events[6][1], {"id": "journey-1", "name": CLIENT_PATH_NAME})
        # Название пути — строго из образа результата: имя, присланное моделью
        # для корня, не принимается.
        self.assertEqual(model.passport_data["nodes"]["journey-1"]["name"], CLIENT_PATH_NAME)
        # Дерево паспорта — в модели, нормализованное кодом: реестр и
        # object-id строит `normalize_passport`, а не модель.
        self.assertEqual(model.passport_data["decision-boundary"], "END_TO_END_PROCESS")
        rows = {r["id"]: r for r in model.passport_data["registry"]}
        self.assertEqual(rows["operation-2"]["parent"], "bbb-2")
        self.assertEqual(set(rows), {"journey-1", "process-1", "bbb-1", "bbb-2",
                                     "operation-1", "operation-2"})
        self.assertEqual([r["kind"] for r in model.passport_data["relations"]], ["precedes"])
        self.assertFalse(any("паспорт не завершён" in g for g in model.gaps), model.gaps)
        self.assertEqual(events[0][1]["item_count"], 1)
        self.assertEqual(events[0][1]["items"][0], {
            "title": STAGE_TITLE, "origin": "user", "criteria": 2,
        })
        # Один буллит done, второй planned -> (1 + 0) / 2 = 50%.
        self.assertEqual(events[1][1], {
            "title": STAGE_TITLE, "applicable": True, "percent": 50, "criteria": 2,
        })
        self.assertEqual(events[2][1]["decision"], "GO")

        # readiness считается кодом: («Да» 100 + «Нет» 0) / 2 = 50%.
        self.assertEqual(model.readiness, 50)
        self.assertEqual(model.summary.decision, "GO")
        self.assertEqual(model.summary.conclusion, CONCLUSION)
        self.assertIsInstance(model.summary.conclusion, list)
        self.assertEqual(model.summary_source, "llm")
        self.assertEqual(model.meta["client_path_name"], CLIENT_PATH_NAME)
        self.assertEqual(model.meta["project_name"], PROJECT_NAME)
        # submit_brief перезаписал before/now/after в meta.
        self.assertEqual(model.meta["before"], BEFORE)
        self.assertEqual(model.meta["now"], NOW)
        self.assertEqual(model.meta["after"], AFTER)
        self.assertEqual(model.criterion_counts()["done"], 1)

    def test_deck_stage_titles_stay_a_list_in_meta(self):
        """Разбор колоды кладёт в контекст свою строку `stages`; список
        этапов из `PlanInput` не должен ею затираться. В живых отчётах из
        колоды `meta.stages` приезжал строкой во всех прогонах."""
        from pko.progress.plan_input import parse_plan_text
        deck = "\n".join([
            f"Клиентский путь: {CLIENT_PATH_NAME}",
            f"Проект: {PROJECT_NAME}",
            "## Первый этап",
            "## Второй этап",
            f"- {BULLETS[0]}",
            f"- {BULLETS[1]}",
            "Дословный хвост колоды.",
        ])
        [item] = parse_plan_text(deck).items
        ChatClient._create = scripted_responses(
            tool_call("call_stage", "submit_stage", **stage_args(item_id=item.id)),
            tool_call("call_review", "submit_review", confirmed=True),
            tool_call("call_summary", "submit_summary", **summary_args()),
            tool_call("call_finish", "finish"),
        )
        model = run_progress(deck, "demo-repo", self.target, SPEC)
        self.assertEqual(model.meta["source_format"], "agent_md")
        self.assertEqual(model.meta["stages"], ["Первый этап", "Второй этап"])
        self.assertEqual(model.meta["project_name"], PROJECT_NAME)

    def test_without_on_event_behaves_exactly_as_before(self):
        ChatClient._create = scripted_responses(
            *full_session(stage={"statuses": ["planned", "planned"]},
                          summary={"decision": "NO GO"})
        )
        model = run_progress(JOURNEY_TEXT, "demo-repo", self.target, SPEC)
        # Все planned -> 0%.
        self.assertEqual(model.readiness, 0)
        # Ниже порога — PIVOT. NO GO на текущем шаге не выдаётся.
        self.assertEqual(model.summary.decision, "PIVOT")
        self.assertEqual(model.verdicts[0].percent(), 0)


class FailureHintTest(unittest.TestCase):
    """Совет при обрыве должен указывать на настоящую причину."""

    def test_context_overflow_is_named_as_such(self):
        hint = pipeline._failure_hint([
            "агент недоступен на шаге 30: Модель Kimi-K3 отклонила запрос. "
            "maximum context length is 131072 tokens",
        ])
        self.assertIn("переполненного контекста", hint)
        self.assertIn("PKO_HISTORY_BUDGET", hint)
        self.assertNotIn("проверьте доступность LLM", hint)

    def test_other_failures_keep_the_old_advice(self):
        hint = pipeline._failure_hint(["агент недоступен на шаге 3: таймаут"])
        self.assertIn("доступность LLM", hint)

    def test_empty_notes_do_not_crash(self):
        self.assertIn("неизвестна", pipeline._failure_hint([]))


if __name__ == "__main__":
    unittest.main()

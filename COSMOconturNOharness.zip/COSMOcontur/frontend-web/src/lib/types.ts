// Зеркало JSON-контракта backend/pko/render/dashboard_data.py::build_dashboard_data и
// событий SSE из backend/pko/web/app.py::stream_analysis_events.

// Статус буллита — шкала согласия. Веса и подписи приходят с бэкенда
// (`meta.scale`): здесь их дублировать нельзя, разойдутся.
export type CriterionStatus =
  | "done"      // работает
  | "limited"   // работает с ограничениями
  | "unused"    // код реализован, но не используется
  | "partial"   // не работает, реализовано частично
  | "planned"   // не реализовано
  | "blocked";

// Одна ссылка на код в шторке пункта: файл, строка, имя и что там
// происходит. Неподтверждённые ссылки в контракт не попадают вовсе, поэтому
// поля `verified`/`reason` здесь нет — показывать нечего.
export interface CodeLink {
  path: string;
  line: number | null;
  basis: string;
  note: string;
}

// Ответ команды на оценку одного пункта. Отчёт — утверждение о чужой работе,
// и у команды должно быть право с ним не согласиться.
export type DisputeVerdict = "accept" | "accept_with_note" | "reject";

export interface Dispute {
  id: number;
  created_at: string;
  analysis_id: string;
  bullet_index: number;
  verdict: DisputeVerdict;
  verdict_label: string;
  comment: string;
}

// Один буллит этапа — дословный текст из ввода плюс оценка.
// `applicable` приходит только у пунктов, относящихся к анализируемой
// инициативе: у остальных полей нет вовсе, они серые и в расчёт не входят.
export interface AssessmentItem {
  text: string;
  applicable?: boolean;
  // Почему пункт не оценивался. Приходит только у неприменимых: они выходят
  // из знаменателя готовности, и причина должна быть видна читателю.
  na_reason?: string;
  status?: CriterionStatus;
  status_label?: string;
  // Раскрытие пункта — два буллита: «Проверка» (есть ли код и работает ли он)
  // и «Как работает» (обычными словами). Ссылки на код лежат ниже, в
  // отдельной шторке, и приходят только подтверждённые.
  proof?: string;
  how?: string;
  links?: CodeLink[];
  // Поля прежних версий — запасной источник, чтобы старые отчёты не теряли
  // текст: `technical`/`why` это «проверка», `business`/`comment` — «как
  // работает».
  technical?: string;
  why?: string;
  business?: string;
  comment?: string;
  group?: string;
}

export interface StageItem {
  title: string;
  description: string;
  applicable?: boolean;
  // Процент считает бэкенд. Экран его только показывает: вторая формула
  // на фронте неизбежно расходится с первой.
  percent?: number | null;
  assessment: AssessmentItem[];
}

export interface ScaleRow {
  status: CriterionStatus | "na";
  label: string;
  // Короткая подпись для строки-легенды: полные названия в одну строку не
  // помещаются. В самом пункте показывается полное.
  short?: string;
  // Два веса на статус: `weight` — прототип (по нему главный процент и
  // решение), `weight_prod` — промышленное решение.
  weight: number | null;
  weight_prod?: number | null;
  meaning: string;
}

export interface AnalysisMeta {
  repo: string;
  branch: string;
  commit: string;
  generated_at: string;
  client_path_name?: string;
  project_name?: string;
  before?: string;
  now?: string;
  after?: string;
  decision?: "GO" | "PIVOT" | "NO GO";
  // Верхнеуровневая оценка целого: суждение модели, а не расчёт по буллитам.
  match?: "matches" | "mostly" | "mismatch";
  match_label?: string;
  match_note?: string;


  closed_share?: number;
  source_digest?: string;
  scale?: ScaleRow[];
  counts?: Record<string, number>;
  not_applicable?: number;
}

export interface ProjectSummary {
  conclusion: string[];
  reason?: string;
}

// Связность решения: складываются ли закрытые пункты в работающую систему.
// Отдельный вопрос от процента готовности — тот считается по буллитам и про
// соединение частей ничего не знает. Подписи (`level_label`, `severity_label`,
// `kind_label`) приходят из бэкенда: вторая таблица подписей здесь разошлась
// бы с первой.
export type IntegrityLevel = "coherent" | "fragmented" | "disconnected";
export type FlawSeverity = "blocker" | "major" | "minor";

export interface FlowTrace {
  entry: string;
  steps: string[];
  outcome: string;
  complete: boolean;
  break_point?: string;
  links?: CodeLink[];
}

export interface SystemFlaw {
  kind: string;
  kind_label?: string;
  severity: FlawSeverity;
  severity_label?: string;
  title: string;
  detail: string;
  bullets?: string[];
  links?: CodeLink[];
}

// Фактическое назначение системы по коду — независимый ответ о целом рядом с
// оценкой по буллитам.
export type PurposeVerdict = "same_purpose" | "narrower" | "different";

export interface SystemPurpose {
  does: string;
  not_does?: string;
  verdict: PurposeVerdict;
  verdict_label?: string;
  links?: CodeLink[];
}

export interface IntegrityReview {
  level: IntegrityLevel;
  purpose?: SystemPurpose | null;
  level_label?: string;
  level_hint?: string;
  note?: string;
  checked?: number;
  counts?: Record<FlawSeverity, number>;
  flow?: FlowTrace | null;
  flaws?: SystemFlaw[];
}

// Сквозная связность: целевые сценарии из образа результата и их стыки.
// Статусы и процент считает бэкенд (`schema.calculate_connectivity`).
export type ScenarioStatus = "assembled" | "broken" | "unknown";
export type CheckResult = "ok" | "broken" | "unknown";

export interface HandoffCheck {
  check: string;
  check_label?: string;
  result: CheckResult;
  result_label?: string;
  note?: string;
  links?: CodeLink[];
}

export interface Handoff {
  step: number;
  kind: string;
  kind_label?: string;
  basis?: string;
  result: CheckResult;
  result_label?: string;
  checks: HandoffCheck[];
}

export interface Scenario {
  id: string;
  title: string;
  entry: string;
  outcome: string;
  steps: string[];
  critical: boolean;
  bullets?: string[];
  status: ScenarioStatus;
  status_label?: string;
  status_hint?: string;
  break_point?: string;
  transitions: number;
  transitions_confirmed: number;
  handoffs: Handoff[];
}

export interface ConnectivityReview {
  percent: number | null;
  basis?: string;
  basis_label?: string;
  source_digest?: string;
  counts: Record<ScenarioStatus, number>;
  total: number;
  handoffs_confirmed: number;
  handoffs_total: number;
  blocked: { id: string; title: string; outcome: string }[];
  scenarios: Scenario[];
}

export interface SolutionAssessment {
  score: number | null;
  completeness: number;
  connectivity: number | null;
  connectivity_measured: boolean;
  critical_breaks: number;
  reason: string;
  rule: "minimum";
  rule_label: string;
}

export interface AnalysisResult {
  status: "READY";
  meta: AnalysisMeta;
  // Две готовности из одних и тех же статусов: прототип (главное число, по
  // нему решение) и промышленное решение (строгие веса).
  readiness: number;
  readiness_prod?: number;
  items: StageItem[];
  summary?: ProjectSummary;
  integrity?: IntegrityReview | null;
  connectivity?: ConnectivityReview | null;
  // Паспорт клиентского пути — отдельный файл (`/passport.html`); здесь
  // только сводка для кнопки: заполнял ли его агент и сколько узлов принято.
  passport?: PassportSummary;
  gaps?: string[];
}

export interface PassportSummary {
  filled_by_agent: boolean;
  nodes: number;
  summary?: {
    functional_nodes: number;
    counts: Record<string, number>;
    requirements_mapped: number;
    requirements_total: number;
    mapping_coverage: number | null;
    assessment: SolutionAssessment;
  };
}

export interface AnalysisPending {
  status: "PROCESSING";
}

export interface AnalysisFailed {
  status: "ERROR";
  message: string;
  hint: string;
}

export type Analysis = AnalysisResult | AnalysisPending | AnalysisFailed;

export interface CreateAnalysisResponse {
  analysis_id: string;
  status: "PROCESSING";
}

export interface ApiErrorBody {
  message: string;
  hint: string;
}

// События SSE (`GET /api/analyses/{id}/events`).
// `queued` — прогонов одновременно идёт ограниченное число, и ожидание своей
// очереди честнее показать, чем крутить кружок молча.
export type PhaseName =
  | "queued"
  | "materials_loading"
  | "materials_ready"
  | "critic"
  | "coherence";

export type AnalysisEvent =
  | { type: "phase"; phase: PhaseName; label: string }
  | {
      type: "plan_ready";
      item_count: number;
      items: {
        title: string;
        origin: "user";
        criteria: number;
      }[];
    }
  | {
      type: "claim_verified";
      title: string;
      applicable: boolean;
      percent: number | null;
      criteria: number;
    }
  | { type: "summary_ready"; text: string; decision: string }
  // Паспортная сессия: старт, каждый принятый узел, итог.
  | { type: "passport_started" }
  | { type: "passport_node"; id: string; name: string }
  | { type: "passport_ready"; nodes: number }
  | { type: "passport_error"; message: string }
  | { type: "analysis_ready" }
  | { type: "error"; message: string; hint: string };

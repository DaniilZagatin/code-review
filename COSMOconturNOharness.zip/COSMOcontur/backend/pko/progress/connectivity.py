"""Сквозная связность: целевые сценарии из ОР и проверка стыков.

Счётная часть ревизии связности (`progress.coherence`). Ревизор, кроме
одного сквозного пути и списка изъянов, теперь:

1. **Выводит целевые сценарии из образа результата** (`submit_scenarios`):
   вход → шаги → проверяемый результат, признак критичности и пункты ОР,
   из которых сценарий следует. Один вызов на сессию, состав фиксируется.
2. **Прослеживает стыки каждого сценария** (`submit_trace`): по каждому
   переходу между соседними шагами — чем соединены и ответы на чек-лист
   (`schema.HANDOFF_CHECKS`) с ссылками на код.

Статусы сценариев и процент считает код (`schema.scenario_status`,
`schema.calculate_connectivity`). Здесь — только гейт, который держит
метрику честной:

* сценарий без привязки к пунктам ОР не принимается — состав выводится из
  обещанного, а не из найденного кода, иначе подсказчик получит 100% за
  то, что хорошо показывает справку;
* **отсутствие найденного вызова — не разрыв**: `broken` без проверенной
  ссылки на место обрыва понижается до `unknown`, и модели об этом
  сообщается;
* **«подтверждено» тоже требует ссылки**: `ok` без проверенной ссылки —
  `unknown`;
* тексты проходят те же сторожа, что и остальные проходы: без кода в
  тексте для читателя, без несуществующих путей.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from pko.extractors.base import Tree
from pko.progress.matcher import _clip, _parse_evidence
from pko.progress.schema import (
    CHECK_RESULTS,
    HANDOFF_CHECKS,
    HANDOFF_KINDS,
    MAX_SCENARIOS,
    MIN_SCENARIOS,
    ConnectivityReview,
    Handoff,
    HandoffCheck,
    Scenario,
    contains_code,
)
from pko.report.guard import check_explanation

_MIN_STEPS = 2
_MAX_STEPS = 7
_MAX_STEP_CHARS = 160
_MAX_TITLE_CHARS = 80
_MAX_NOTE_CHARS = 300

_SUBMIT_SCENARIOS_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_scenarios",
        "description": (
            "Целевые сценарии инициативы — ОДИН вызов, после submit_system и до "
            "submit_flow. Сценарии выводятся из ОБРАЗА РЕЗУЛЬТАТА, а не из "
            "найденного кода: если обещан автономный процесс, сценарий — "
            "автономный процесс, даже когда в коде только справка. Каждый "
            f"сценарий обязан ссылаться на пункты ОР. От {MIN_SCENARIOS} до "
            f"{MAX_SCENARIOS} сценариев: один на каждый обещанный результат, "
            "не дробить."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "scenarios": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "title": {"type": "string", "description": "Название сценария назывной фразой, до 80 символов"},
                            "entry": {"type": "string", "description": "Что запускает процесс и кто: человеческим языком"},
                            "outcome": {"type": "string", "description": "Проверяемое конечное состояние: что должно возникнуть"},
                            "steps": {
                                "type": "array", "items": {"type": "string"},
                                "description": "2–7 обязательных действий и передач по порядку, от входа к результату. Без имён функций и путей.",
                            },
                            "critical": {"type": "boolean", "description": "true — без этого сценария замысел инициативы не выполняется"},
                            "bullets": {
                                "type": "array", "items": {"type": "string"},
                                "description": "Пункты образа результата, из которых сценарий выведен — дословно из списка в задании. Обязателен хотя бы один.",
                            },
                        },
                        "required": ["title", "entry", "outcome", "steps", "critical", "bullets"],
                    },
                },
            },
            "required": ["scenarios"],
        },
    },
}

_SUBMIT_TRACE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_trace",
        "description": (
            "Прослеженные стыки ОДНОГО сценария — по вызову на сценарий, после "
            "submit_scenarios. Стык — переход между соседними шагами (step — "
            "номер шага, с которого переход начинается, с нуля). По каждому "
            "стыку — чем соединены шаги и ответы на чек-лист. Правила: "
            "broken требует проверенной ссылки на место, где продолжение "
            "прекращается (заглушка, другой топик, неиспользуемый результат) — "
            "отсутствие найденного вызова разрывом НЕ считается; ok тоже "
            "требует ссылки; если проверить нельзя (внешняя система, "
            "динамическая регистрация, нет конфигурации) — unknown с "
            "объяснением. Стык без reachability, contract и data_continuity "
            "подтверждённым не считается."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "scenario_id": {"type": "string", "description": "id сценария из ответа кода: scenario-1, scenario-2 …"},
                "handoffs": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "step": {"type": "integer", "description": "Номер шага, с которого переход начинается (0 — первый шаг)"},
                            "kind": {
                                "type": "string", "enum": list(HANDOFF_KINDS),
                                "description": "call — вызов в процессе; http — HTTP/RPC; queue — очередь или событие; "
                                               "storage — общее хранилище; schedule — задание по расписанию; "
                                               "config — подключение конфигурацией; manual — ручная передача человеком",
                            },
                            "checks": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "check": {
                                            "type": "string", "enum": list(HANDOFF_CHECKS),
                                            "description": "reachability — вызывается ли следующий шаг из реального входа; "
                                                           "contract — совпадают ли операция, адрес/топик, версия и поля; "
                                                           "data_continuity — передаётся ли нужный объект и используется ли результат; "
                                                           "sequence_state — выполнены ли предпосылки следующего шага; "
                                                           "wiring — выбрана ли нужная реализация в оцениваемой сборке; "
                                                           "obligation — возник ли обещанный результат",
                                        },
                                        "result": {"type": "string", "enum": list(CHECK_RESULTS)},
                                        "note": {"type": "string", "description": "Что найдено, одной-двумя фразами, без кода. Для broken и unknown обязательно."},
                                        "evidence": {
                                            "type": "array",
                                            "items": {
                                                "type": "object",
                                                "properties": {
                                                    "path": {"type": "string"},
                                                    "line": {"type": "integer"},
                                                    "basis": {"type": "string", "description": "имя функции/класса/маршрута рядом со строкой"},
                                                    "note": {"type": "string", "description": "что здесь происходит, одной фразой"},
                                                },
                                            },
                                        },
                                    },
                                    "required": ["check", "result"],
                                },
                            },
                        },
                        "required": ["step", "kind", "checks"],
                    },
                },
            },
            "required": ["scenario_id", "handoffs"],
        },
    },
}

CONNECTIVITY_TOOL_SCHEMAS: list[dict[str, Any]] = [_SUBMIT_SCENARIOS_SCHEMA, _SUBMIT_TRACE_SCHEMA]


@dataclass
class ConnectivityState:
    """Сценарии, объявленные ревизором, и стыки по каждому из них."""

    plan_bullets: list[str]
    tree: Tree
    source_digest: str = ""
    scenarios: dict[str, Scenario] = field(default_factory=dict)
    order: list[str] = field(default_factory=list)
    traced: set[str] = field(default_factory=set)
    rejected: int = 0
    # Понижения `broken`/`ok` → `unknown` за отсутствие ссылок: в заметки прогона.
    downgraded: int = 0

    @property
    def declared(self) -> bool:
        return bool(self.order)

    @property
    def untraced(self) -> list[str]:
        return [sid for sid in self.order if sid not in self.traced]

    def review(self) -> ConnectivityReview | None:
        if not self.declared:
            return None
        return ConnectivityReview(
            scenarios=[self.scenarios[sid] for sid in self.order],
            source_digest=self.source_digest,
        )


def _clean(value: object, limit: int) -> str:
    return _clip(" ".join(str(value or "").split()), limit)


def _text_problem(label: str, value: str, tree: Tree) -> str:
    code = contains_code(value)
    if code:
        return (f"{label} содержит код («{code}») — перепиши обычными словами, "
                "путь и строку положи в evidence")
    violations = check_explanation(value, tree.files_set)
    if violations:
        return f"{label}: " + "; ".join(v.render() for v in violations)
    return ""


def match_bullets(raw: object, plan_bullets: list[str]) -> list[str]:
    """Сопоставить названные пункты с планом — тот же приём, что у изъянов:
    в карточку идёт текст плана, а не пересказ модели."""
    if not isinstance(raw, list):
        return []
    normalized = {re.sub(r"\W+", "", text).lower(): text for text in plan_bullets}
    out: list[str] = []
    for entry in raw:
        key = re.sub(r"\W+", "", str(entry or "")).lower()
        if not key:
            continue
        hit = normalized.get(key)
        if hit is None:
            for norm_key, text in normalized.items():
                if key in norm_key or norm_key in key:
                    hit = text
                    break
        if hit is not None and hit not in out:
            out.append(hit)
    return out


def handle_scenarios(state: ConnectivityState, args: dict) -> str:
    """`submit_scenarios` — состав целевых сценариев из ОР."""
    if state.declared:
        state.rejected += 1
        return ("сценарии отклонены: состав уже зафиксирован — " + ", ".join(
            f"{sid} «{state.scenarios[sid].title}»" for sid in state.order
        ) + ". Дальше submit_trace по каждому")
    raw = args.get("scenarios")
    if not isinstance(raw, list) or not raw:
        state.rejected += 1
        return "сценарии отклонены: scenarios должен быть непустым списком"
    if not (MIN_SCENARIOS <= len(raw) <= MAX_SCENARIOS):
        state.rejected += 1
        return (f"сценарии отклонены: их должно быть от {MIN_SCENARIOS} до {MAX_SCENARIOS}, "
                f"прислано {len(raw)} — один сценарий на обещанный результат, не дробить")

    accepted: list[Scenario] = []
    seen_titles: set[str] = set()
    for index, entry in enumerate(raw, start=1):
        if not isinstance(entry, dict):
            state.rejected += 1
            return f"сценарии отклонены: элемент {index} не объект"
        title = _clean(entry.get("title"), _MAX_TITLE_CHARS)
        entry_text = _clean(entry.get("entry"), _MAX_STEP_CHARS)
        outcome = _clean(entry.get("outcome"), _MAX_STEP_CHARS)
        if not title or not entry_text or not outcome:
            state.rejected += 1
            return f"сценарии отклонены: у сценария {index} нужны title, entry и outcome"
        if title.lower() in seen_titles:
            state.rejected += 1
            return f"сценарии отклонены: сценарий «{title}» назван дважды"
        seen_titles.add(title.lower())
        raw_steps = entry.get("steps")
        if not isinstance(raw_steps, list):
            state.rejected += 1
            return f"сценарии отклонены: у сценария «{title}» steps должен быть списком"
        steps = [s for s in (_clean(x, _MAX_STEP_CHARS) for x in raw_steps) if s]
        if not (_MIN_STEPS <= len(steps) <= _MAX_STEPS):
            state.rejected += 1
            return (f"сценарии отклонены: у сценария «{title}» шагов должно быть от "
                    f"{_MIN_STEPS} до {_MAX_STEPS}, прислано {len(steps)}")
        for label, value in ((f"«{title}»: title", title), ("entry", entry_text),
                             ("outcome", outcome), *((f"шаг {i}", s) for i, s in enumerate(steps, 1))):
            problem = _text_problem(label, value, state.tree)
            if problem:
                state.rejected += 1
                return f"сценарии отклонены: {problem}"
        bullets = match_bullets(entry.get("bullets"), state.plan_bullets)
        if not bullets:
            state.rejected += 1
            return (f"сценарии отклонены: сценарий «{title}» не привязан ни к одному "
                    "пункту образа результата — назови пункты дословно из задания. "
                    "Сценарии выводятся из обещанного, а не из найденного кода")
        accepted.append(Scenario(
            id=f"scenario-{index}", title=title, entry=entry_text, outcome=outcome,
            steps=steps, critical=bool(entry.get("critical")), bullets=bullets,
        ))

    for scenario in accepted:
        state.scenarios[scenario.id] = scenario
        state.order.append(scenario.id)
    listed = "; ".join(
        f"{s.id} «{s.title}» ({s.transitions} стык." + (", критический" if s.critical else "") + ")"
        for s in accepted
    )
    return (f"состав зафиксирован: {listed}. Теперь по каждому сценарию пройди "
            "стыки по коду и вызови submit_trace(scenario_id=…). Затем submit_flow.")


def _parse_checks(state: ConnectivityState, raw: object, where: str) -> tuple[list[HandoffCheck], str, int]:
    """Разобрать проверки стыка. Возвращает (проверки, ошибка, понижений)."""
    if not isinstance(raw, list) or not raw:
        return [], f"{where}: checks должен быть непустым списком", 0
    checks: list[HandoffCheck] = []
    seen: set[str] = set()
    downgraded = 0
    for item in raw:
        if not isinstance(item, dict):
            continue
        check = str(item.get("check") or "").strip().lower()
        if check not in HANDOFF_CHECKS:
            return [], f"{where}: проверка {check!r} не из списка: " + ", ".join(HANDOFF_CHECKS), 0
        if check in seen:
            return [], f"{where}: проверка {check} названа дважды", 0
        seen.add(check)
        result = str(item.get("result") or "").strip().lower()
        if result not in CHECK_RESULTS:
            return [], f"{where}: результат {result!r} у {check} неизвестен, допустимы: " + ", ".join(CHECK_RESULTS), 0
        note = _clean(item.get("note"), _MAX_NOTE_CHARS)
        if note:
            problem = _text_problem(f"{where}, {check}, note", note, state.tree)
            if problem:
                return [], problem, 0
        if result in ("broken", "unknown") and not note:
            return [], f"{where}: у {check}={result} обязателен note — что именно найдено или почему проверить нельзя", 0
        evidence = _parse_evidence(item.get("evidence"), state.tree)
        verified = [e for e in evidence if e.verified]
        if result in ("broken", "ok") and not verified:
            # Отсутствие найденного вызова — не разрыв; утверждение без места —
            # не подтверждение. Оба случая — «недостаточно данных».
            downgraded += 1
            reason = ("разрыв без проверенной ссылки на место обрыва"
                      if result == "broken" else "подтверждение без проверенной ссылки")
            note = (note + " " if note else "") + f"(понижено кодом до unknown: {reason})"
            result = "unknown"
        checks.append(HandoffCheck(check=check, result=result, note=note, evidence=evidence))
    if not checks:
        return [], f"{where}: ни одной разобранной проверки", 0
    return checks, "", downgraded


def handle_trace(state: ConnectivityState, args: dict) -> str:
    """`submit_trace` — стыки одного сценария."""
    if not state.declared:
        state.rejected += 1
        return "стыки отклонены: сначала submit_scenarios — состав сценариев не зафиксирован"
    sid = str(args.get("scenario_id") or "").strip()
    scenario = state.scenarios.get(sid)
    if scenario is None:
        state.rejected += 1
        return ("стыки отклонены: сценария " + (f"{sid!r}" if sid else "без id") + " нет. Есть: "
                + ", ".join(state.order))
    raw = args.get("handoffs")
    if not isinstance(raw, list) or not raw:
        state.rejected += 1
        return f"стыки отклонены: у {sid} handoffs должен быть непустым списком"

    handoffs: list[Handoff] = []
    seen_steps: set[int] = set()
    downgraded_total = 0
    for item in raw:
        if not isinstance(item, dict):
            continue
        try:
            step = int(item.get("step"))
        except (TypeError, ValueError):
            state.rejected += 1
            return f"стыки отклонены: у {sid} step должен быть целым числом"
        if not (0 <= step < scenario.transitions):
            state.rejected += 1
            return (f"стыки отклонены: у {sid} step={step} вне диапазона — переходов "
                    f"{scenario.transitions} (step от 0 до {scenario.transitions - 1})")
        if step in seen_steps:
            state.rejected += 1
            return f"стыки отклонены: у {sid} переход {step} описан дважды"
        seen_steps.add(step)
        kind = str(item.get("kind") or "").strip().lower()
        if kind not in HANDOFF_KINDS:
            state.rejected += 1
            return f"стыки отклонены: у {sid} вид стыка {kind!r} не из списка: " + ", ".join(HANDOFF_KINDS)
        where = f"{sid}, переход {step} («{scenario.steps[step]}» → «{scenario.steps[step + 1]}»)"
        checks, problem, downgraded = _parse_checks(state, item.get("checks"), where)
        if problem:
            state.rejected += 1
            return f"стыки отклонены: {problem}"
        downgraded_total += downgraded
        handoffs.append(Handoff(step=step, kind=kind, checks=checks))

    if not handoffs:
        state.rejected += 1
        return f"стыки отклонены: у {sid} ни одного разобранного перехода"
    state.downgraded += downgraded_total
    updated = Scenario(
        id=scenario.id, title=scenario.title, entry=scenario.entry, outcome=scenario.outcome,
        steps=list(scenario.steps), critical=scenario.critical, bullets=list(scenario.bullets),
        handoffs=sorted(handoffs, key=lambda h: h.step),
    )
    state.scenarios[sid] = updated
    state.traced.add(sid)

    status = updated.status
    missing = [i for i in range(updated.transitions) if updated.handoff_at(i) is None]
    reply = [f"{sid}: стыков принято {len(handoffs)} из {updated.transitions}, статус — {status}."]
    if downgraded_total:
        reply.append(f"Понижено до unknown за отсутствие проверенных ссылок: {downgraded_total}.")
    if missing:
        reply.append("Не описаны переходы: " + ", ".join(str(i) for i in missing)
                     + " — без них сценарий остаётся unknown; можно дополнить повторным submit_trace.")
    # Все ответы «ok», а стык всё равно unknown — не хватает обязательных проверок.
    weak = [h.step for h in handoffs
            if h.result == "unknown" and all(c.result == "ok" for c in h.checks)]
    if weak:
        reply.append("Стыки без обязательных проверок (reachability, contract, data_continuity): "
                     + ", ".join(str(s) for s in weak) + " — они не подтверждены.")
    rest = state.untraced
    if rest:
        reply.append("Дальше: " + ", ".join(rest) + ".")
    else:
        reply.append("Все сценарии прослежены. Дальше submit_flow, изъяны и submit_integrity.")
    return " ".join(reply)


def finish_problem(state: ConnectivityState) -> str:
    """Что мешает завершить ревизию по части сценариев. Пустая строка — ничего."""
    if not state.declared:
        return ("целевые сценарии не объявлены — вызови submit_scenarios: без них "
                "сквозная связность не измерена")
    rest = state.untraced
    if rest:
        return "не прослежены стыки сценариев: " + ", ".join(rest) + " — submit_trace по каждому"
    return ""


def brief_lines() -> list[str]:
    """Что сказать ревизору в задании про сценарии."""
    return [
        "Сквозная связность измеряется по целевым сценариям. Сценарии выводятся "
        "из образа результата (что обещано), а не из найденного кода: если "
        "обещан автономный процесс, а в коде справка, сценарий — автономный "
        "процесс, и он разорван или не подтверждён. Один сценарий на обещанный "
        "результат; у каждого — пункты ОР, из которых он следует.",
        "По каждому переходу между шагами проверь: достижимость (вызывается ли "
        "следующий шаг из реального входа), совместимость контракта (операция, "
        "адрес/топик, версия, поля), непрерывность данных (передаётся ли нужный "
        "объект и используется ли результат), последовательность и состояние "
        "(выполнены ли предпосылки), подключение в конфигурации (выбрана ли "
        "нужная реализация, не заглушка), завершение обязательства (возник ли "
        "обещанный результат, а не текст о нём).",
        "Разрыв доказывается местом: broken без проверенной ссылки код понизит "
        "до unknown. Если продолжение требует, чтобы сотрудник перенёс данные "
        "руками, а обещана автономность — это стык вида manual и разрыв.",
    ]

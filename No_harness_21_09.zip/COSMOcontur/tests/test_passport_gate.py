"""Гейт паспорта клиентского пути: модель предлагает, код проверяет.

* структурные нарушения (BBB без операций, дубли уровней, связи в
  несуществующие узлы или не из списка, «Установлено» на намерении)
  отклоняются с объяснением;
* у узла может быть несколько родителей: общий BBB объявляется ссылкой
  `{ref}` или связью `includes`, в дереве стоит под первым, в реестре
  перечислены все;
* узел до развилки (классификатор, права) стоит под клиентским путём и
  запускает процессы связью `triggers`; процесс, содержащий собственный
  триггер, отклоняется;
* планируемый узел теряет поля о поведении кода, а «в коде нет» при
  работающем пункте ОР отклоняется; критерии результата без статусов;
* нормализация строит нумерацию, ID объектов, связи и реестр из дерева;
* сессия агента ведёт очередь, принимает связи и привязку шагов сценариев,
  а `finish` при шагах без узла отклоняет один раз;
* рендерер переключает бейдж, вырезает потребности и ограничения из
  шаблона и кладёт всех родителей в реестр.
"""

from __future__ import annotations

import json
import unittest

from fixture_support import scripted_responses
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress.passport_agent import render_evaluation_digest, run_passport_agent
from pko.progress.passport_gate import (
    RELATION_KINDS,
    audience_of,
    check_defect,
    check_passport,
    check_risk,
    journey_name_of,
    normalize_passport,
    PassportCheck,
)
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import (
    ConnectivityReview,
    CriterionVerdict,
    EvidenceRef,
    Handoff,
    HandoffCheck,
    ItemVerdict,
    PlanItem,
    ProgressModel,
    Scenario,
)
from pko.render.client_journey_passport import (
    STATUS_BADGE_AGENT,
    STATUS_BADGE_FALLBACK,
    STATUS_BADGE_TEMPLATE,
    flatten_passport_data,
    passport_registry_rows,
    passport_tree_spec,
    render_client_journey_passport,
)
from pko.render.passport_map import build_passport_map, passport_map_nodes


SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")


def _f(value: str, source: str) -> dict:
    return {"value": value, "source": source}


EST = "Установлено: portfolio_creator.py, collect_portfolio — собирает продукты по долям"
OWNER = "Требует подтверждения владельца: владелец продукта вкладов, назначение вне кода"


def _valid() -> dict:
    """Паспорт, проходящий гейт: то, каким его ждёт код.

    Два процесса делят BBB «Получение профиля клиента» (bbb-1): в дереве он
    под process-1, у process-2 числится через `parents`. Классификатор
    «Определение сценария обращения» (bbb-4) стоит до развилки — под
    клиентским путём — и запускает оба процесса связью `triggers`.
    """
    return {
        "analysis-scope": "repo · abc1234 · проект",
        "decision-boundary": "COMPONENT_BBB",
        "analysis-date": "2026-09-15",
        "tree": [
            {"id": "journey-1", "type": "journey", "children": [
                {"id": "process-1", "type": "process", "children": [
                    {"id": "bbb-1", "type": "bbb", "children": [
                        {"id": "operation-1", "type": "operation"},
                    ]},
                    {"id": "bbb-2", "type": "bbb", "children": [
                        {"id": "operation-2", "type": "operation"},
                    ]},
                ]},
                {"id": "process-2", "type": "process", "children": [
                    {"id": "bbb-3", "type": "bbb", "children": [
                        {"id": "operation-3", "type": "operation"},
                    ]},
                ]},
                {"id": "bbb-4", "type": "bbb", "children": [
                    {"id": "operation-4", "type": "operation"},
                ]},
            ]},
        ],
        "nodes": {
            "journey-1": {"name": "Размещение сбережений в диалоге", "basis": "путь задан образом результата",
                          "fields": {"4.2.3": _f("Предложение: владелец продукта", OWNER)}},
            "process-1": {"name": "Портфельное предложение", "basis": "сценарий с собственной точкой входа",
                          "fields": {
                              "4.3.3": _f("Предложение: владелец продукта", OWNER),
                              "4.3.6": _f("Сборка портфеля — AUTO; оформление — CONFIRM, ждёт кнопки.",
                                          "Выведено: opener.py ждёт нажатия кнопки перед открытием"),
                              "4.3.8": _f("Не установлено: передачи человеку нет, клиент остаётся с ботом.",
                                          "Не установлено"),
                          }},
            "process-2": {"name": "Ответы на вопросы о продуктах", "basis": "сценарий без оформления, со своим завершением",
                          "fields": {
                              "4.3.3": _f("Предложение: владелец продукта", OWNER),
                              "4.3.6": _f("Определение сценария — AUTO; ответ — AUTO.",
                                          "Выведено: подтверждения перед ответом в коде нет"),
                          }},
            "bbb-1": {"name": "Получение профиля клиента", "basis": "общий блок: профиль нужен и подбору, и ответам",
                      "parents": ["process-1", "process-2"],
                      "fields": {"4.4.1": _f("Читает счета и карты клиента.", EST)}},
            "bbb-4": {"name": "Определение сценария обращения", "basis": "выбирает процесс по реплике",
                      "before_fork": True, "parents": ["journey-1"],
                      "fields": {"4.4.1": _f("Относит реплику к сценарию.", EST)}},
            "bbb-2": {"name": "Сборка портфеля", "basis": "переиспользуемое действие с контрактом",
                      "fields": {"4.4.1": _f("Собирает набор продуктов.", EST)}},
            "bbb-3": {"name": "Ответ по справочнику продуктов", "basis": "генерация текста по данным",
                      "fields": {"4.4.1": _f("Отвечает на вопрос о продукте.", EST)}},
            "operation-1": {"name": "Чтение профиля из витрины", "basis": "результат виден снаружи блока",
                            "fields": {"4.5.1": _f("Возвращает счета и карты.", EST)}},
            "operation-4": {"name": "Классификация реплики", "basis": "результат виден снаружи блока",
                            "fields": {"4.5.1": _f("Определяет категорию.", EST)}},
            "operation-2": {"name": "Расчёт долей портфеля", "basis": "отдельный расчёт с собственным отказом",
                            "fields": {"4.5.6": _f("Повтор безопасен: расчёт без внешнего эффекта.", EST)}},
            "operation-3": {"name": "Текст ответа клиенту", "basis": "сообщение — внешний результат",
                            "fields": {"4.5.1": _f("Формирует текст ответа.", EST)}},
        },
        "relations": [
            {"from": "bbb-4", "to": "process-1", "kind": "triggers",
             "basis": "по категории PICKER граф вызывает подбор"},
            {"from": "bbb-4", "to": "process-2", "kind": "triggers",
             "basis": "по категории FAQ граф вызывает ответы"},
            {"from": "operation-2", "to": "bbb-2", "kind": "feeds",
             "basis": "доли возвращаются в сборку портфеля"},
        ],
    }


class CheckPassportTest(unittest.TestCase):

    def test_valid_passport_passes(self):
        check = check_passport(_valid())
        self.assertEqual(check.errors, [], check.errors)

    def test_bbb_without_operation_rejected(self):
        data = _valid()
        data["tree"][0]["children"][0]["children"][1]["children"] = []
        errors = check_passport(data).errors
        self.assertTrue(any("bbb-2: BBB без атомарных операций" in e for e in errors), errors)

    def test_child_duplicating_parent_rejected(self):
        data = _valid()
        data["nodes"]["operation-2"]["name"] = "Сборка портфеля"
        errors = check_passport(data).errors
        self.assertTrue(any("названы одинаково" in e for e in errors), errors)

    def test_single_bbb_with_parent_basis_rejected(self):
        data = _valid()
        data["tree"][0]["children"][0]["children"] = [data["tree"][0]["children"][0]["children"][1]]
        del data["nodes"]["bbb-1"], data["nodes"]["operation-1"]
        data["relations"] = []
        data["nodes"]["bbb-2"]["basis"] = data["nodes"]["process-1"]["basis"]
        errors = check_passport(data).errors
        self.assertTrue(any("средний уровень пустой" in e for e in errors), errors)

    def test_shared_node_counts_as_child_of_every_parent(self):
        # У process-2 в tree только bbb-3; без второго родителя у bbb-1 он бы
        # прошёл и так, но пустой процесс, чьи BBB — только общие, тоже полный.
        data = _valid()
        data["tree"][0]["children"][1]["children"] = []
        del data["nodes"]["bbb-3"], data["nodes"]["operation-3"]
        errors = check_passport(data).errors
        self.assertFalse(any("process-2: процесс без BBB" in e for e in errors), errors)

    def test_parents_must_match_tree_and_type(self):
        data = _valid()
        data["nodes"]["bbb-1"]["parents"] = ["process-2", "process-1"]
        errors = check_passport(data).errors
        self.assertTrue(any("первый в parents должен быть родителем из tree" in e for e in errors), errors)
        data = _valid()
        data["nodes"]["bbb-1"]["parents"] = ["process-1", "bbb-2"]
        errors = check_passport(data).errors
        self.assertTrue(any("родитель должен быть типа process" in e for e in errors), errors)
        data = _valid()
        data["nodes"]["bbb-1"]["parents"] = ["process-1", "process-9"]
        errors = check_passport(data).errors
        self.assertTrue(any("process-9 не существует" in e for e in errors), errors)

    def test_relation_kind_outside_list_rejected(self):
        data = _valid()
        data["relations"][0]["kind"] = "связано как-то"
        errors = check_passport(data).errors
        self.assertTrue(any("вид «связано как-то» не из списка" in e for e in errors), errors)
        self.assertIn("includes", RELATION_KINDS)

    def test_relation_to_unknown_or_self_rejected(self):
        data = _valid()
        data["relations"].append({"from": "bbb-2", "to": "bbb-9", "kind": "precedes", "basis": "вызов после сборки"})
        data["relations"].append({"from": "bbb-2", "to": "bbb-2", "kind": "precedes", "basis": "вызов после сборки"})
        errors = check_passport(data).errors
        self.assertTrue(any("узла bbb-9 нет" in e for e in errors), errors)
        self.assertTrue(any("с самим собой" in e for e in errors), errors)

    def test_relation_without_basis_or_duplicate_rejected(self):
        data = _valid()
        data["relations"][0]["basis"] = "да"
        data["relations"].append(dict(data["relations"][1]))
        errors = check_passport(data).errors
        self.assertTrue(any("нет basis" in e for e in errors), errors)
        self.assertTrue(any("уже объявлена" in e for e in errors), errors)

    def test_relation_with_journey_rejected(self):
        data = _valid()
        data["relations"].append({"from": "journey-1", "to": "bbb-2", "kind": "precedes", "basis": "путь начинается со сборки"})
        errors = check_passport(data).errors
        self.assertTrue(any("клиентским путём" in e for e in errors), errors)

    def test_includes_requires_parent_level(self):
        data = _valid()
        data["relations"].append({"from": "bbb-2", "to": "operation-3", "kind": "includes", "basis": "текст ответа нужен и в сборке"})
        self.assertEqual(check_passport(data).errors, [])
        data["relations"].append({"from": "process-2", "to": "operation-2", "kind": "includes", "basis": "расчёт нужен и в ответах"})
        errors = check_passport(data).errors
        self.assertTrue(any("includes — второй родитель" in e for e in errors), errors)

    def test_bare_level_without_detail_rejected(self):
        data = _valid()
        data["nodes"]["bbb-2"]["fields"]["4.4.1"]["source"] = "Выведено"
        errors = check_passport(data).errors
        self.assertTrue(any("«Выведено» без привязки" in e for e in errors), errors)

    def test_source_without_level_rejected(self):
        data = _valid()
        data["nodes"]["bbb-2"]["fields"]["4.4.1"]["source"] = "portfolio_creator.py"
        errors = check_passport(data).errors
        self.assertTrue(any("должно начинаться с уровня" in e for e in errors), errors)

    def test_owner_established_rejected(self):
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.3"]["source"] = "Установлено: CODEOWNERS, команда депозитов"
        errors = check_passport(data).errors
        self.assertTrue(any("process-1 4.3.3" in e for e in errors), errors)

    def test_process_without_execution_mode_rejected(self):
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.6"]["value"] = "Сборка портфеля, оформление."
        errors = check_passport(data).errors
        self.assertTrue(any("режим исполнения" in e for e in errors), errors)

    def test_bad_decision_boundary_rejected(self):
        data = _valid()
        data["decision-boundary"] = "ВЕСЬ ПУТЬ"
        self.assertTrue(any("decision-boundary" in e for e in check_passport(data).errors))

    def test_handoff_as_scenario_transition_is_remark(self):
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.8"]["value"] = "Переход к оформлению по кнопке."
        check = check_passport(data)
        self.assertEqual(check.errors, [])
        self.assertTrue(any("4.3.8" in r for r in check.remarks), check.remarks)

    def test_status_rollback_is_not_compensation_remark(self):
        data = _valid()
        data["nodes"]["operation-2"]["name"] = "Перевод средств"
        data["nodes"]["operation-2"]["fields"]["4.5.4"] = _f("Средства переведены на источник.", EST)
        data["nodes"]["operation-2"]["fields"]["4.5.6"]["value"] = "При ошибке статус откатывается."
        remarks = check_passport(data).remarks
        self.assertTrue(any("откат статуса — не компенсация" in r for r in remarks), remarks)

    def test_router_mentioned_without_node_is_remark(self):
        data = _valid()
        data["nodes"]["bbb-4"]["name"] = "Подбор вклада"
        data["nodes"]["bbb-4"]["basis"] = "переиспользуемое действие"
        data["nodes"]["process-1"]["fields"]["4.3.4"] = _f(
            "Запрос на портфель.", "Установлено: prompts/scenario.py классификатор категорий")
        remarks = check_passport(data).remarks
        self.assertTrue(any("классификатор" in r for r in remarks), remarks)
        # Узел с ролью маршрутизатора есть — замечания нет.
        self.assertFalse(any("классификатор" in r for r in check_passport(_valid()).remarks))

    def test_before_fork_node_under_journey_cannot_join_processes(self):
        # Узел до развилки не бывает общим ребёнком процессов…
        data = _valid()
        data["nodes"]["bbb-4"]["parents"] = ["journey-1", "process-1"]
        errors = check_passport(data).errors
        self.assertTrue(any("bbb-4: узел до развилки" in e for e in errors), errors)
        # …и не включается в процесс связью.
        data = _valid()
        data["relations"].append({"from": "process-2", "to": "bbb-4", "kind": "includes",
                                  "basis": "классификатор нужен и ответам"})
        errors = check_passport(data).errors
        self.assertTrue(any("узел до развилки" in e and "triggers" in e for e in errors), errors)
        # Без before_fork BBB под путём — ошибка уровня.
        data = _valid()
        data["nodes"]["bbb-4"].pop("before_fork")
        errors = check_passport(data).errors
        self.assertTrue(any("bbb-4: родитель должен быть типа process" in e for e in errors), errors)

    def test_process_containing_its_own_trigger_rejected(self):
        # Общий ребёнок процессов, который их же запускает, — замкнутая конструкция.
        data = _valid()
        data["relations"].append({"from": "bbb-1", "to": "process-2", "kind": "triggers",
                                  "basis": "после профиля граф вызывает ответы"})
        errors = check_passport(data).errors
        self.assertTrue(any("собственный триггер" in e and "before_fork" in e for e in errors), errors)

    def test_criteria_with_implementation_statuses_rejected(self):
        data = _valid()
        data["nodes"]["journey-1"]["fields"]["4.2.5"] = _f(
            "Портфель подобран (done), оформление последовательное (limited).", EST)
        errors = check_passport(data).errors
        self.assertTrue(any("journey-1 4.2.5" in e and "статусы" in e for e in errors), errors)
        data["nodes"]["journey-1"]["fields"]["4.2.5"]["value"] = (
            "Портфель открыт и средства размещены; доля клиентов, дошедших до открытия, — целевое значение у владельца.")
        self.assertEqual(check_passport(data).errors, [])

    def test_planned_node_keeps_only_business_fields(self):
        data = _valid()
        data["nodes"]["process-2"]["planned"] = True
        data["nodes"]["process-2"]["fields"]["4.3.7"] = _f("Планируется: повтор через сутки.", "Гипотеза: из описания инициативы")
        check = check_passport(data)
        self.assertEqual(check.errors, [], check.errors)
        self.assertTrue(any("process-2 4.3.6" in r and "планируемого" in r for r in check.remarks), check.remarks)
        norm = normalize_passport(data)
        self.assertTrue(norm["nodes"]["process-2"]["planned"])
        self.assertEqual(set(norm["nodes"]["process-2"]["fields"]), {"4.3.3"})
        self.assertFalse(norm["nodes"]["process-1"]["planned"])
        self.assertTrue(norm["nodes"]["bbb-4"]["before_fork"])
        self.assertFalse(norm["nodes"]["bbb-1"]["before_fork"])
        data["nodes"]["journey-1"]["planned"] = True
        self.assertTrue(any("не бывает планируемым" in e for e in check_passport(data).errors))

    def test_fallback_proved_only_by_legacy_name_is_rejected(self):
        data = _valid()
        data["relations"].append({"from": "operation-1", "to": "operation-2", "kind": "fallback",
                                  "basis": "функция помечена как legacy-алгоритм подбора"})
        check = check_passport(data)
        self.assertTrue(any("запасной путь обоснован тем" in e for e in check.errors), check.errors)
        data["relations"][-1]["basis"] = "legacy-подбор вызывается в except при ошибке нового селектора"
        self.assertFalse(any("запасной путь обоснован" in e for e in check_passport(data).errors))

    def test_fallback_field_requires_runtime_switch(self):
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.7"] = _f(
            "Legacy _select_deposit_old — запасной путь.",
            "Выведено: имя старой функции указывает на предыдущую версию",
        )
        errors = check_passport(data).errors
        self.assertTrue(any("legacy/_old не является fallback" in e for e in errors), errors)
        data["nodes"]["process-1"]["fields"]["4.3.7"] = _f(
            "При ошибке нового селектора вызывается старая реализация.",
            "Установлено: selector.py вызывает _select_deposit_old в except",
        )
        self.assertFalse(any("legacy/_old не является fallback" in e for e in check_passport(data).errors))

    def test_technical_bbb_boundary_and_non_atomic_operation_rejected(self):
        data = _valid()
        data["nodes"]["bbb-2"]["basis"] = (
            "детерминированная сборка, отличающаяся от генерации текста моделью"
        )
        errors = check_passport(data).errors
        self.assertTrue(any("граница BBB проведена по устройству кода" in e for e in errors), errors)
        data = _valid()
        data["nodes"]["operation-2"]["name"] = "Перевод средств и открытие вклада"
        errors = check_passport(data).errors
        self.assertTrue(any("два внешних эффекта" in e for e in errors), errors)
        data["nodes"]["operation-2"]["name"] = (
            "Подбор краткосрочного, среднесрочного вклада и счёта до востребования"
        )
        errors = check_passport(data).errors
        self.assertTrue(any("разных типов продуктов" in e for e in errors), errors)

    def test_weak_source_does_not_prove_runtime_route(self):
        data = _valid()
        data["nodes"]["bbb-2"]["fields"]["4.4.4"] = _f(
            "Портфель передаётся в предложение.",
            "Установлено: поиск ScenarioEnum.OPENER находит 22 совпадения",
        )
        errors = check_passport(data).errors
        self.assertTrue(any("основание не подтверждает утверждение" in e for e in errors), errors)

    def test_defect_entity_validated_and_normalized(self):
        check = PassportCheck()
        check_defect(check, {"title": "коротко", "kind": "data", "nodes": ["bbb-1"]}, {"bbb-1"}, set())
        self.assertTrue(any("короче" in e for e in check.errors), check.errors)
        check = PassportCheck()
        check_defect(check, {"title": "анализ трат отключён: доли портфеля считаются по нулевым тратам",
                             "kind": "странный", "nodes": ["bbb-9"]}, {"bbb-1"}, {"scenario-1"})
        self.assertTrue(any("тип должен быть" in e for e in check.errors), check.errors)
        self.assertTrue(any("узла bbb-9 нет" in e for e in check.errors), check.errors)
        check = PassportCheck()
        check_defect(check, {"title": "анализ трат отключён: доли портфеля считаются по нулевым тратам",
                             "kind": "data", "nodes": ["bbb-1"], "where": "portfolio_utils.py:30"},
                     {"bbb-1"}, set(), {"app.py"})
        self.assertEqual(check.errors, [])
        self.assertTrue(any("не встречается в материалах" in r for r in check.remarks), check.remarks)
        data = _valid()
        data["defects"] = [{"title": "анализ трат отключён: доли портфеля считаются по нулевым тратам",
                            "kind": "data", "nodes": ["bbb-2"], "blocking": False}]
        norm = normalize_passport(data)
        self.assertEqual(norm["defects"][0]["id"], "defect-1")
        self.assertEqual(norm["defects"][0]["kind_label"], "данные")
        self.assertEqual(norm["defects"][0]["nodes"], ["bbb-2"])

    def test_operational_risk_chain_validated_and_normalized(self):
        risk = {
            "title": "Повторное списание после неопределённого ответа",
            "scope": "cross_node",
            "cause": "Результат внешнего списания неизвестен после тайм-аута, а повтор разрешён",
            "negative_event": "Повтор запроса создаёт второе списание по одной клиентской операции",
            "consequences": ["Клиент теряет деньги до ручного возврата, банк нарушает обязательство по корректному списанию"],
            "primary_node": "operation-1", "linked_nodes": ["operation-1", "operation-2"],
            "existing_controls": [{"description": "Повтор ограничен тремя попытками в одном процессе",
                                   "basis": "app.py:3 — обработчик ограничивает число вызовов"}],
            "control_gap": "Сквозной ключ идемпотентности и сверка результата внешнего списания не подтверждены",
            "guardrails": ["guardrail-1"],
            "evidence": [{"where": "app.py:3", "basis": "после тайм-аута обработчик повторяет внешний вызов"}],
            "confidence": "inferred", "confidence_note": "Повтор подтверждён, поведение внешнего исполнителя не видно",
            "confirmation_needed": "",
        }
        check = PassportCheck()
        check_risk(check, risk, {"operation-1", "operation-2"}, {"guardrail-1"}, {"app.py"})
        self.assertEqual(check.errors, [])

        broken = {**risk, "scope": "local", "linked_nodes": ["operation-1", "operation-2"],
                  "confidence": "established", "evidence": []}
        check = PassportCheck()
        check_risk(check, broken, {"operation-1", "operation-2"}, {"guardrail-1"})
        self.assertTrue(any("ровно к одному" in e for e in check.errors), check.errors)
        self.assertTrue(any("требует проверяемого основания" in e for e in check.errors), check.errors)

        data = _valid()
        data["guardrails"] = [{"name": "Не повторять необратимый эффект", "invariant": "Одна клиентская операция создаёт не больше одного списания",
                               "condition": "После тайм-аута внешнего исполнителя", "effect": "SAFE_STOP",
                               "targets": ["operation-1"], "source": "Установлено: app.py:3 останавливает повтор"}]
        data["risks"] = [risk]
        norm = normalize_passport(data)
        self.assertEqual(norm["risks"][0]["id"], "risk-1")
        self.assertEqual(norm["risks"][0]["scope_label"], "сквозной")
        self.assertEqual(norm["risks"][0]["confidence_label"], "Выведено")
        self.assertEqual(norm["risks"][0]["linked_nodes"], ["operation-1", "operation-2"])
        self.assertEqual(norm["risks"][0]["guardrails"], ["guardrail-1"])

    def test_branching_kind_checked_and_kept(self):
        data = _valid()
        data["nodes"]["process-1"]["branching"] = "как-нибудь"
        self.assertTrue(any("тип ветвления" in e for e in check_passport(data).errors))
        data["nodes"]["process-1"]["branching"] = "mandatory_parallel"
        self.assertEqual(check_passport(data).errors, [])
        self.assertEqual(normalize_passport(data)["nodes"]["process-1"]["branching"], "mandatory_parallel")

    def test_planned_process_may_have_no_children(self):
        data = _valid()
        data["tree"][0]["children"][1]["children"] = []
        del data["nodes"]["bbb-3"], data["nodes"]["operation-3"]
        data["nodes"]["bbb-1"]["parents"] = ["process-1"]
        data["nodes"]["process-2"]["planned"] = True
        errors = check_passport(data).errors
        self.assertFalse(any("process-2: процесс без BBB" in e for e in errors), errors)

    def test_feeds_without_field_is_remark(self):
        data = _valid()
        remarks = check_passport(data).remarks
        self.assertTrue(any("не названо поле состояния" in r for r in remarks), remarks)
        data["relations"][2]["field"] = "portfolio_shares"
        self.assertFalse(any("не названо поле состояния" in r for r in check_passport(data).remarks))
        self.assertEqual(normalize_passport(data)["relations"][2]["field"], "portfolio_shares")

    def test_need_and_guardrail_gates(self):
        from pko.progress.passport_gate import check_need, check_guardrail
        check = PassportCheck()
        check_need(check, {"name": "все клиенты МП СБОЛ", "purpose": "коротко", "source": "Установлено: app.py"})
        self.assertTrue(any("аудитория" in e for e in check.errors), check.errors)
        self.assertTrue(any("нельзя установить по коду" in e for e in check.errors), check.errors)
        self.assertTrue(any("короче" in e for e in check.errors), check.errors)
        check = PassportCheck()
        check_need(check, {"name": "Разместить сбережения", "purpose": "Человек хочет выгодно разместить свободные деньги, не разбираясь в продуктах.", "source": "Выведено: образ результата, пункт про подбор вклада"})
        self.assertEqual(check.errors, [])
        check = PassportCheck()
        check_guardrail(check, {"name": "Без подтверждения не открывать", "invariant": "коротко", "condition": "Перед каждым переводом средств клиента", "effect": "STOP", "targets": ["bbb-9"], "source": "Установлено"}, {"bbb-2"})
        self.assertTrue(any("invariant" in e for e in check.errors), check.errors)
        self.assertTrue(any("effect должен быть" in e for e in check.errors), check.errors)
        self.assertTrue(any("узла bbb-9 нет" in e for e in check.errors), check.errors)
        self.assertTrue(any("без привязки" in e for e in check.errors), check.errors)

    def test_journey_name_prefers_path_but_not_audience(self):
        self.assertEqual(journey_name_of({"client_path_name": "Размещение сбережений", "project_name": "Демо"}),
                         "Размещение сбережений")
        ctx = {
            "client_path_name": "все клиенты МП СБОЛ",
            "project_name": "AI-агент по вкладам",
            "after": "Клиент может разместить сбережения в подобранные вклады. Агент объясняет выбор.",
        }
        self.assertEqual(journey_name_of(ctx), "Разместить сбережения в подобранные вклады")
        self.assertEqual(audience_of(ctx), "все клиенты МП СБОЛ")
        self.assertEqual(
            journey_name_of({"client_path_name": "все клиенты", "project_name": "AI-агент"}),
            "Путь клиента к целевому результату",
        )
        self.assertEqual(audience_of({"client_path_name": "Размещение сбережений", "project_name": "Демо"}), "")

    def test_legacy_need_and_guardrail_nodes_rejected(self):
        data = _valid()
        data["nodes"]["need-1"] = {"name": "Разместить деньги", "basis": "существует до продукта", "fields": {}}
        errors = check_passport(data).errors
        # Тип не опознан: в дерево не входит, в nodes лишний.
        self.assertTrue(errors, errors)

    def test_empty_or_wrong_type_rejected(self):
        self.assertTrue(check_passport(None).errors)
        self.assertTrue(check_passport({"nodes": {}}).errors)
        self.assertTrue(check_passport({"nodes": {"journey-1": {"name": "x"}}}).errors)


class NormalizePassportTest(unittest.TestCase):

    def test_registry_lists_all_parents_and_relations_kept(self):
        norm = normalize_passport(_valid())
        rows = {row["id"]: row for row in norm["registry"]}
        self.assertEqual(rows["journey-1"]["parent"], "—")
        self.assertEqual(rows["process-1"]["parent"], "journey-1")
        self.assertEqual(rows["bbb-1"]["parent"], "process-1, process-2")
        self.assertEqual(rows["operation-2"]["parent"], "bbb-2")
        self.assertEqual(rows["bbb-2"]["basis"], "переиспользуемое действие с контрактом")
        self.assertEqual(norm["nodes"]["bbb-1"]["parents"], ["process-1", "process-2"])
        self.assertEqual(norm["nodes"]["bbb-2"]["parents"], ["process-1"])
        self.assertEqual([r["kind"] for r in norm["relations"]], ["triggers", "triggers", "feeds"])
        self.assertEqual(norm["relations"][0]["kind_label"], "запускает")
        self.assertNotIn("need-1", rows)

    def test_includes_relation_adds_parent(self):
        data = _valid()
        data["nodes"]["bbb-1"].pop("parents")
        data["relations"].append({"from": "process-2", "to": "bbb-1", "kind": "includes",
                                  "basis": "определение сценария общее для процессов"})
        norm = normalize_passport(data)
        self.assertEqual(norm["nodes"]["bbb-1"]["parents"], ["process-1", "process-2"])
        rows = {row["id"]: row for row in norm["registry"]}
        self.assertEqual(rows["bbb-1"]["parent"], "process-1, process-2")

    def test_agent_registry_ignored(self):
        data = _valid()
        data["registry"] = [{"id": "bbb-1", "type": "X", "name": "Y", "parent": "—", "basis": "чужое"}]
        rows = {row["id"]: row for row in normalize_passport(data)["registry"]}
        self.assertEqual(rows["bbb-1"]["parent"], "process-1, process-2")
        self.assertEqual(rows["bbb-1"]["basis"], "общий блок: профиль нужен и подбору, и ответам")
        self.assertEqual(rows["bbb-4"]["parent"], "journey-1")
        self.assertEqual(len(rows), 11)

    def test_renumbering_and_object_ids(self):
        data = _valid()
        # Агент нумерует с дыр: bbb-7 — код пересчитывает вместе со связями.
        data["tree"][0]["children"][0]["children"][1]["id"] = "bbb-7"
        data["nodes"]["bbb-7"] = data["nodes"].pop("bbb-2")
        data["relations"][2]["to"] = "bbb-7"
        norm = normalize_passport(data)
        self.assertIn("bbb-2", norm["nodes"])
        self.assertNotIn("bbb-7", norm["nodes"])
        self.assertEqual(norm["relations"][2]["to"], "bbb-2")
        self.assertEqual(norm["nodes"]["bbb-2"]["object-id"], "bbb.sborka-portfelya")
        self.assertEqual(norm["tree"][0]["children"][0]["children"][1]["id"], "bbb-2")

    def test_object_ids_unique_and_cut_at_word_boundary(self):
        data = _valid()
        data["nodes"]["bbb-3"]["name"] = "Получение профиля клиента"
        data["nodes"]["operation-3"]["name"] = "Формирование текста и виджета предложения по переразмещению вклада клиента"
        norm = normalize_passport(data)
        self.assertEqual(norm["nodes"]["bbb-1"]["object-id"], "bbb.poluchenie-profilya-klienta")
        self.assertEqual(norm["nodes"]["bbb-3"]["object-id"], "bbb.poluchenie-profilya-klienta-2")
        oid = norm["nodes"]["operation-3"]["object-id"]
        self.assertTrue(oid.endswith("-po") or not oid.endswith("pererazmesch"), oid)
        self.assertLessEqual(len(oid), len("operation.") + 60)
        self.assertFalse(oid.endswith("-"))

    def test_unknown_relation_dropped_silently_in_normalize(self):
        data = _valid()
        data["relations"].append({"from": "bbb-2", "to": "bbb-9", "kind": "precedes", "basis": "мимо"})
        norm = normalize_passport(data)
        self.assertEqual(len(norm["relations"]), 3)


def _node_call(node_id: str, name: str, basis: str, fields: dict, **extra) -> dict:
    args = {"id": node_id, "name": name, "basis": basis, "fields": fields, **extra}
    return {"content": None, "tool_calls": [{
        "id": f"call_{node_id}", "type": "function",
        "function": {"name": "submit_node", "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


def _children_call(parent: str, *children) -> dict:
    """Ребёнок: `"bbb-N"` — ссылка, `(name, basis)` — новый, `(name, basis, True)` — до развилки."""
    items = []
    for c in children:
        if isinstance(c, str):
            items.append({"ref": c})
        elif len(c) == 3:
            items.append({"name": c[0], "basis": c[1], "before_fork": bool(c[2])})
        else:
            items.append({"name": c[0], "basis": c[1]})
    args = {"parent": parent, "children": items}
    return {"content": None, "tool_calls": [{
        "id": f"call_children_{parent}", "type": "function",
        "function": {"name": "declare_children", "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


def _tool_call(tool: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": f"call_{tool}_{abs(hash(json.dumps(args, sort_keys=True))) % 10_000}", "type": "function",
        "function": {"name": tool, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


def _link_call(src: str, dst: str, kind: str, basis: str = "вызов после успешного шага в graph.py") -> dict:
    return _tool_call("link_nodes", **{"from": src, "to": dst, "kind": kind, "basis": basis})


def _finish_call() -> dict:
    return _tool_call("finish")


def _risk_review_call(*risks: dict) -> dict:
    return _tool_call("submit_risks", risks=list(risks))


PROCESS_FIELDS = {
    "4.3.3": _f("Предложение: владелец продукта", OWNER),
    "4.3.6": _f("Определение сценария — AUTO; сборка — AUTO.", "Выведено: подтверждения перед действием нет"),
    "4.3.8": _f("Не установлено: передачи человеку нет.", "Не установлено"),
}
BBB_FIELDS = {"4.4.1": _f("Делает одно действие.", EST)}
OP_FIELDS = {"4.5.1": _f("Шаг с наблюдаемым результатом.", EST)}


def _happy_script() -> list[dict]:
    """Полный обход: journey → process → 2 BBB × 1 операция → связь → finish."""
    return [
        _node_call("journey-1", "Размещение сбережений", "путь из образа результата",
                   {"4.2.3": _f("Предложение: владелец продукта", OWNER)},
                   decision_boundary="COMPONENT_BBB"),
        _children_call("journey-1", ("Портфельное предложение", "сценарий со своим входом")),
        _node_call("process-1", "Портфельное предложение", "сценарий со своим входом", PROCESS_FIELDS),
        _children_call("process-1",
                       ("Определение сценария обращения", "выбирает процесс по реплике"),
                       ("Сборка портфеля", "собирает набор продуктов")),
        _node_call("bbb-1", "Определение сценария обращения", "выбирает процесс по реплике", BBB_FIELDS),
        _children_call("bbb-1", ("Классификация реплики", "результат виден снаружи")),
        _node_call("operation-1", "Классификация реплики", "результат виден снаружи", OP_FIELDS),
        _node_call("bbb-2", "Сборка портфеля", "собирает набор продуктов", BBB_FIELDS),
        _children_call("bbb-2", ("Расчёт долей портфеля", "отдельный расчёт")),
        _node_call("operation-2", "Расчёт долей портфеля", "отдельный расчёт", OP_FIELDS),
        _link_call("bbb-1", "bbb-2", "triggers"),
        _risk_review_call(),
        _finish_call(),
    ]


def _shared_script() -> list[dict]:
    """Узел до развилки, два процесса и общий BBB через {ref}:
    journey → bbb-1 (до развилки) → process-1 (bbb-2, bbb-3) →
    process-2 (ref bbb-2, bbb-4) → triggers от bbb-1 к процессам → finish."""
    return [
        _node_call("journey-1", "Размещение сбережений", "путь из образа результата",
                   {"4.2.3": _f("Предложение: владелец продукта", OWNER)},
                   decision_boundary="COMPONENT_BBB"),
        _children_call("journey-1", ("Портфельное предложение", "сценарий со своим входом"),
                       ("Ответы на вопросы", "сценарий без оформления"),
                       ("Определение сценария обращения", "выбирает процесс по реплике", True)),
        _node_call("bbb-1", "Определение сценария обращения", "выбирает процесс по реплике", BBB_FIELDS),
        _children_call("bbb-1", ("Классификация реплики", "результат виден снаружи")),
        _node_call("operation-1", "Классификация реплики", "результат виден снаружи", OP_FIELDS),
        _node_call("process-1", "Портфельное предложение", "сценарий со своим входом", PROCESS_FIELDS),
        _children_call("process-1",
                       ("Получение профиля клиента", "общий блок: профиль нужен и подбору, и ответам"),
                       ("Сборка портфеля", "собирает набор продуктов")),
        _node_call("bbb-2", "Получение профиля клиента", "общий блок", BBB_FIELDS),
        _children_call("bbb-2", ("Чтение профиля из витрины", "результат виден снаружи блока")),
        _node_call("operation-2", "Чтение профиля из витрины", "результат виден снаружи блока", OP_FIELDS),
        _node_call("bbb-3", "Сборка портфеля", "собирает набор продуктов", BBB_FIELDS),
        _children_call("bbb-3", ("Расчёт долей портфеля", "отдельный расчёт")),
        _node_call("operation-3", "Расчёт долей портфеля", "отдельный расчёт", OP_FIELDS),
        _node_call("process-2", "Ответы на вопросы", "сценарий без оформления", PROCESS_FIELDS),
        _children_call("process-2", "bbb-2", ("Ответ по справочнику", "генерация текста по данным")),
        _node_call("bbb-4", "Ответ по справочнику", "генерация текста по данным", BBB_FIELDS),
        _children_call("bbb-4", ("Текст ответа клиенту", "сообщение — внешний результат")),
        _node_call("operation-4", "Текст ответа клиенту", "сообщение — внешний результат", OP_FIELDS),
        _link_call("bbb-1", "process-1", "triggers", "категория PICKER запускает подбор"),
        _link_call("bbb-1", "process-2", "triggers", "категория FAQ запускает ответы"),
        _risk_review_call(),
        _finish_call(),
    ]


def _scenario(steps: list[str], results: list[str] | None = None) -> Scenario:
    handoffs = []
    for index in range(len(steps) - 1):
        result = (results or ["ok"] * (len(steps) - 1))[index]
        handoffs.append(Handoff(step=index, kind="call", checks=[
            HandoffCheck(check=c, result=result, note="", evidence=[])
            for c in ("reachability", "contract", "data_continuity")
        ]))
    return Scenario(id="scenario-1", title="Подбор портфеля", entry="вход", outcome="итог",
                    steps=steps, critical=True, bullets=["Подобран продукт."], handoffs=handoffs)


class PassportAgentTest(unittest.TestCase):
    """Отдельная сессия: обход сверху вниз, очередь ведёт код."""

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)
        self.plan = [PlanItem(id="s1", title="Подбор", criteria=["Подобран продукт."], origin="user")]
        self.verdicts = [ItemVerdict(item_id="s1", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="done", proof="Код есть.", how="Подбирает.",
                             evidence=[EvidenceRef(path="app.py", line=3, basis="select",
                                                   verified=True, reason="ок", note="подбирает вклад")]),
        ])]

    def _run(self, *answers, **kwargs):
        ChatClient._create = scripted_responses(*answers)
        return run_passport_agent(
            self.plan, {"client_path_name": "Размещение сбережений", "project_name": "Демо"},
            self.verdicts, None, SPEC, client=self.client,
            knowledge=["[read_file app.py:1-40 — def select()]"], repo_name="demo", commit="abc1234",
            **kwargs,
        )

    def test_full_walk_builds_tree_registry_and_ids(self):
        result = self._run(*_happy_script())
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertFalse(any("не завершён" in n for n in result.notes), result.notes)
        self.assertEqual(data["decision-boundary"], "COMPONENT_BBB")
        rows = {r["id"]: r for r in data["registry"]}
        self.assertEqual(set(rows), {"journey-1", "process-1", "bbb-1", "bbb-2",
                                     "operation-1", "operation-2"})
        self.assertEqual(rows["operation-2"]["parent"], "bbb-2")
        self.assertEqual(data["nodes"]["bbb-2"]["object-id"], "bbb.sborka-portfelya")
        self.assertEqual(data["tree"][0]["children"][0]["children"][1]["children"][0]["id"], "operation-2")
        self.assertEqual(data["relations"], [{
            "from": "bbb-1", "to": "bbb-2", "kind": "triggers", "kind_label": "запускает",
            "basis": "вызов после успешного шага в graph.py", "field": "",
        }])
        self.assertEqual(data["defects"], [])

    def test_shared_node_via_ref_gets_two_parents_once_in_tree(self):
        result = self._run(*_shared_script())
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertFalse(any("не завершён" in n or "с нарушениями" in n for n in result.notes), result.notes)
        self.assertEqual(data["nodes"]["bbb-2"]["parents"], ["process-1", "process-2"])
        rows = {r["id"]: r for r in data["registry"]}
        self.assertEqual(rows["bbb-2"]["parent"], "process-1, process-2")
        # Узел до развилки — первый ребёнок пути, под ним свои операции.
        kids = data["tree"][0]["children"]
        self.assertEqual([c["id"] for c in kids], ["bbb-1", "process-1", "process-2"])
        self.assertTrue(data["nodes"]["bbb-1"]["before_fork"])
        self.assertEqual(data["nodes"]["bbb-1"]["parents"], ["journey-1"])
        self.assertEqual(rows["bbb-1"]["parent"], "journey-1")
        # В дереве общий узел стоит под первым родителем, под вторым — нет.
        self.assertEqual([c["id"] for c in kids[1]["children"]], ["bbb-2", "bbb-3"])
        self.assertEqual([c["id"] for c in kids[2]["children"]], ["bbb-4"])
        self.assertEqual(len(data["nodes"]), 11)
        self.assertEqual([r["kind"] for r in data["relations"]], ["triggers", "triggers"])
        # Связанный КП и связанный BBB заполнил код — одно имя из одного места.
        self.assertIn("«Размещение сбережений»", data["nodes"]["process-2"]["fields"]["4.3.2"]["value"])
        self.assertIn("«Получение профиля клиента»", data["nodes"]["operation-2"]["fields"]["4.5.2"]["value"])
        self.assertEqual(data["nodes"]["operation-2"]["object-version"], "коммит abc1234")

    def test_ref_to_unknown_or_wrong_level_rejected(self):
        script = _shared_script()
        # Сначала ref на несуществующий узел и на узел до развилки — отклонение,
        # затем верный вызов.
        script.insert(14, _children_call("process-2", "bbb-9", ("Ответ по справочнику", "генерация текста")))
        script.insert(15, _children_call("process-2", "bbb-1", ("Ответ по справочнику", "генерация текста")))
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertEqual(result.passport_data["nodes"]["bbb-2"]["parents"], ["process-1", "process-2"])
        self.assertEqual(result.passport_data["nodes"]["bbb-1"]["parents"], ["journey-1"])
        self.assertFalse(any("с нарушениями" in n for n in result.notes), result.notes)

    def test_trigger_to_own_parent_rejected_in_session(self):
        script = _happy_script()
        script.insert(-1, _link_call("bbb-1", "process-1", "triggers", "категория PICKER запускает подбор"))
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertEqual([r["kind"] for r in result.passport_data["relations"]], ["triggers"])
        self.assertEqual(result.passport_data["relations"][0]["to"], "bbb-2")

    def test_planned_node_conflicting_with_working_bullet_rejected(self):
        script = _happy_script()
        # Пункт «Подобран продукт.» оценён done — «в коде нет» с ним спорит; без
        # пункта planned принимается, поля поведения отброшены.
        script.insert(7, _node_call("bbb-2", "Сборка портфеля", "собирает набор продуктов", BBB_FIELDS,
                                    planned=True, bullets=["Подобран продукт."]))
        script[8] = _node_call("bbb-2", "Сборка портфеля", "собирает набор продуктов",
                               {**BBB_FIELDS, "4.4.6": _f("Планируется: расчёт по долям.", "Гипотеза: из описания")},
                               planned=True)
        result = self._run(*script)
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertFalse(any("с нарушениями" in n for n in result.notes), result.notes)
        self.assertTrue(data["nodes"]["bbb-2"]["planned"])
        self.assertNotIn("4.4.6", data["nodes"]["bbb-2"]["fields"])
        self.assertIn("4.4.1", data["nodes"]["bbb-2"]["fields"])
        self.assertFalse(data["nodes"]["bbb-1"]["planned"])

    def test_defects_submitted_after_tree(self):
        script = _happy_script()
        # До дерева дефект не принимается; после — принимается один раз.
        script.insert(1, _tool_call("submit_defect", title="анализ трат отключён: доли считаются по нулевым тратам",
                                    kind="data", nodes=["bbb-1"]))
        script.insert(-1, _tool_call("submit_defect", title="анализ трат отключён: доли считаются по нулевым тратам",
                                     kind="data", nodes=["bbb-2"], where="app.py:3", blocking=True))
        script.insert(-1, _tool_call("submit_defect", title="анализ трат отключён: доли считаются по нулевым тратам",
                                     kind="data", nodes=["bbb-2"]))
        script.insert(-1, _tool_call("submit_defect", title="в коде что-то", kind="data", nodes=["bbb-2"]))
        result = self._run(*script)
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertEqual(len(data["defects"]), 1)
        self.assertEqual(data["defects"][0]["id"], "defect-1")
        self.assertTrue(data["defects"][0]["blocking"])
        self.assertEqual(data["defects"][0]["nodes"], ["bbb-2"])
        self.assertFalse(any("не встречается в материалах" in n for n in result.notes), result.notes)

    def test_risk_review_required_and_risk_saved_without_changing_status(self):
        risk = {
            "title": "Повторное применение расчёта после потери ответа",
            "scope": "local",
            "cause": "После потери ответа вызывающая сторона может повторить уже выполненный расчёт",
            "negative_event": "Одна клиентская операция повторно изменяет рассчитанные доли портфеля",
            "consequences": ["Клиент получает предложение с противоречивым составом и может выбрать неподходящее размещение средств"],
            "primary_node": "operation-2", "linked_nodes": ["operation-2"],
            "existing_controls": [],
            "control_gap": "Идемпотентность повторного запуска в проанализированном контуре не подтверждена",
            "guardrails": [],
            "evidence": [{"where": "app.py:3", "basis": "вызывающая сторона повторяет расчёт после ошибки ответа"}],
            "confidence": "inferred", "confidence_note": "Механизм повтора виден, фактический двойной эффект напрямую не показан",
            "confirmation_needed": "",
        }
        script = _happy_script()
        script[-2] = _risk_review_call(risk)
        result = self._run(*script)
        self.assertFalse(any("не завершён" in n for n in result.notes), result.notes)
        self.assertEqual(result.passport_data["risks"][0]["id"], "risk-1")
        model = ProgressModel(meta={}, items={}, verdicts=[])
        model.passport_data = result.passport_data
        schema = build_passport_map(model)
        by_id = {n["id"]: n for n in schema["nodes"]}
        self.assertEqual(by_id["operation-2"]["risks"], ["risk-1"])
        self.assertEqual(schema["summary"]["risks_total"], 1)
        without_risk = ProgressModel(meta={}, items={}, verdicts=[])
        without_risk.passport_data = {**result.passport_data, "risks": []}
        plain_by_id = {n["id"]: n for n in build_passport_map(without_risk)["nodes"]}
        self.assertEqual(by_id["operation-2"]["implementation_status"],
                         plain_by_id["operation-2"]["implementation_status"])

        without_review = _happy_script()
        del without_review[-2]
        result = self._run(*without_review)
        self.assertTrue(any("не завершён" in n for n in result.notes), result.notes)

    def test_need_and_guardrail_accepted_after_tree_and_audience_journey_rejected(self):
        script = _happy_script()
        script.insert(-1, _tool_call("submit_need", **{"name": "Разместить сбережения выгодно",
                                     "purpose": "Человек хочет выгодно разместить свободные деньги, не разбираясь в продуктах.",
                                     "source": "Выведено: образ результата — сценарий подбора вклада"}))
        script.insert(-1, _tool_call("submit_guardrail", **{"name": "Открытие только после подтверждения",
                                     "invariant": "Продукт не открывается без явного согласия клиента",
                                     "condition": "Перед каждым переводом средств клиента", "effect": "REQUIRE_CONFIRMATION",
                                     "targets": ["bbb-2"], "source": "Установлено: opener.py ждёт нажатия кнопки"}))
        result = self._run(*script)
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertEqual(data["needs"][0]["id"], "need-1")
        self.assertEqual(data["needs"][0]["targets"], ["journey-1"])
        self.assertEqual(data["guardrails"][0]["effect_label"], "требуется подтверждение")
        self.assertFalse(any("потребность клиента не сформулирована" in n for n in result.notes), result.notes)
        # Путь называет агент; аудитория вместо пути отклоняется, затем принимается название результата.
        script = _happy_script()
        script.insert(0, _node_call("journey-1", "все клиенты МП СБОЛ", "путь из образа результата",
                                    {"4.2.3": _f("Предложение: владелец продукта", OWNER)}, decision_boundary="COMPONENT_BBB"))
        result = self._run(*script)
        self.assertEqual(result.passport_data["nodes"]["journey-1"]["name"], "Размещение сбережений")
        script = _happy_script()
        script.insert(0, _node_call("journey-1", "Путь, как его назвала модель", "путь из образа результата",
                                    {"4.2.3": _f("Предложение: владелец продукта", OWNER)},
                                    decision_boundary="COMPONENT_BBB"))
        result = self._run(*script)
        self.assertEqual(result.passport_data["nodes"]["journey-1"]["name"], "Размещение сбережений")
        # Название инициативы тоже не является названием пути.
        script = _happy_script()
        script.insert(0, _node_call("journey-1", "Демо", "путь из образа результата",
                                    {"4.2.3": _f("Предложение: владелец продукта", OWNER)},
                                    decision_boundary="COMPONENT_BBB"))
        result = self._run(*script)
        self.assertEqual(result.passport_data["nodes"]["journey-1"]["name"], "Размещение сбережений")

    def test_branching_declared_with_children(self):
        script = _happy_script()
        script[3] = _children_call("process-1",
                                   ("Определение сценария обращения", "выбирает процесс по реплике"),
                                   ("Сборка портфеля", "собирает набор продуктов"))
        script[3]["tool_calls"][0]["function"]["arguments"] = json.dumps(
            {**json.loads(script[3]["tool_calls"][0]["function"]["arguments"]), "branching": "mandatory_parallel"},
            ensure_ascii=False)
        result = self._run(*script)
        self.assertEqual(result.passport_data["nodes"]["process-1"]["branching"], "mandatory_parallel")
        self.assertFalse(any("тип ветвления не назван" in n for n in result.notes), result.notes)

    def test_planned_node_gets_no_children_step(self):
        script = _happy_script()
        script[2] = _node_call("process-1", "Портфельное предложение", "сценарий со своим входом",
                               {"4.3.3": PROCESS_FIELDS["4.3.3"]}, planned=True)
        # declare_children и BBB больше не ждут: дерево готово, дальше связи и finish.
        script = script[:3] + [_risk_review_call(), _finish_call()]
        result = self._run(*script)
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertFalse(any("не завершён" in n for n in result.notes), result.notes)
        self.assertTrue(data["nodes"]["process-1"]["planned"])
        self.assertEqual(data["tree"][0]["children"][0].get("children", []), [])

    def test_input_contract_reference_outside_process_is_reported(self):
        from pko.progress.passport_agent import _PassportSession, _Node, _after_tree_text
        state = _PassportSession(tree_done=True)
        state.nodes["journey-1"] = _Node(id="journey-1", name="Путь", basis="б", filled=True)
        for pid in ("process-1", "process-2"):
            state.nodes[pid] = _Node(id=pid, name=pid, basis="б", parents=["journey-1"], filled=True)
        state.nodes["bbb-1"] = _Node(id="bbb-1", name="Профиль", basis="б", parents=["process-1"], filled=True)
        state.nodes["bbb-2"] = _Node(id="bbb-2", name="Оформление", basis="б", parents=["process-2"], filled=True,
                                     data={"fields": {"4.4.2": _f("Профиль клиента из bbb-1.", EST)}})
        text = _after_tree_text(state)
        self.assertIn("bbb-1 упомянут в контракте входа bbb-2, но не входит в process-2", text)
        state.relations.append({"from": "bbb-1", "to": "bbb-2", "kind": "feeds", "basis": "профиль уходит в оформление"})
        self.assertNotIn("упомянут в контракте входа", _after_tree_text(state))

    def test_includes_link_adds_parent_after_tree(self):
        script = _happy_script()
        script.insert(-1, _link_call("process-1", "bbb-1", "includes", "уже родитель — должно отклониться"))
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        # Дублирование дерева связью отклонено: связей осталась одна.
        self.assertEqual(len(result.passport_data["relations"]), 1)

    def test_bad_relation_rejected_without_losing_step(self):
        script = _happy_script()
        script.insert(-1, _link_call("bbb-1", "bbb-7", "precedes"))
        script.insert(-1, _link_call("bbb-1", "bbb-2", "как-то связаны"))
        script.insert(-1, _link_call("bbb-1", "bbb-2", "triggers"))  # дубль
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertEqual(len(result.passport_data["relations"]), 1)
        self.assertFalse(any("не завершён" in n for n in result.notes), result.notes)

    def test_children_required_for_intermediate_nodes(self):
        script = _happy_script()
        script.insert(5, _children_call("bbb-1"))  # пустое объявление детей у BBB
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertIn("operation-1", result.passport_data["nodes"])
        self.assertEqual(result.passport_data["nodes"]["bbb-1"]["name"], "Определение сценария обращения")

    def test_wrong_node_id_rejected_and_queue_kept(self):
        script = _happy_script()
        # Модель пытается заполнить bbb-2 раньше очереди — код не принимает.
        script.insert(4, _node_call("bbb-2", "Сборка портфеля", "собирает", BBB_FIELDS))
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertEqual(result.passport_data["nodes"]["bbb-1"]["name"], "Определение сценария обращения")
        self.assertEqual(len(result.passport_data["registry"]), 6)

    def test_bad_node_rejected_then_fixed(self):
        script = _happy_script()
        bad = _node_call("bbb-2", "Портфельное предложение", "как процесс", BBB_FIELDS)
        script.insert(7, bad)
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertEqual(result.passport_data["nodes"]["bbb-2"]["name"], "Сборка портфеля")
        self.assertFalse(any("с нарушениями" in n for n in result.notes), result.notes)

    def test_interrupted_session_keeps_declared_nodes(self):
        result = self._run(*_happy_script()[:6])
        data = result.passport_data
        self.assertIsNotNone(data)
        self.assertIn("bbb-2", data["nodes"])
        self.assertIn("Не заполнено", data["nodes"]["bbb-2"].get("object-version", ""))
        self.assertTrue(any("не завершён" in n for n in result.notes), result.notes)
        self.assertTrue(any("не заполнены" in n for n in result.notes), result.notes)

    def test_single_bbb_process_gets_remark(self):
        script = [
            _node_call("journey-1", "Размещение сбережений", "путь из образа результата",
                       {"4.2.3": _f("Предложение: владелец продукта", OWNER)},
                       decision_boundary="COMPONENT_BBB"),
            _children_call("journey-1", ("Портфельное предложение", "сценарий со своим входом")),
            _node_call("process-1", "Портфельное предложение", "сценарий со своим входом", PROCESS_FIELDS),
            _children_call("process-1", ("Сборка портфеля", "собирает набор продуктов")),
            _node_call("bbb-1", "Сборка портфеля", "собирает набор продуктов", BBB_FIELDS),
            _children_call("bbb-1", ("Расчёт долей портфеля", "отдельный расчёт")),
            _node_call("operation-1", "Расчёт долей портфеля", "отдельный расчёт", OP_FIELDS),
            _risk_review_call(),
            _finish_call(),
        ]
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertTrue(any("один BBB на процесс" in n for n in result.notes), result.notes)

    def test_finish_rejected_once_for_unbound_scenario_steps(self):
        review = ConnectivityReview(scenarios=[_scenario(["Реплика классифицируется", "Собирается портфель", "Показан оффер"])])
        script = _happy_script()
        # bbb-1 берёт шаг 0; шаги 1 и 2 без узла. Первый finish отклоняется,
        # модель привязывает шаг 1 и завершает — шаг 2 остаётся в замечаниях.
        script[4] = _node_call("bbb-1", "Определение сценария обращения", "выбирает процесс по реплике",
                               BBB_FIELDS, scenario_steps=[{"scenario": "scenario-1", "step": 0}])
        script.insert(-1, _finish_call())
        script.insert(-1, _tool_call("bind_scenario_step", scenario="scenario-1", step=1, nodes=["bbb-2", "operation-2"]))
        result = self._run(*script, connectivity=review)
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertFalse(any("не завершён" in n for n in result.notes), result.notes)
        self.assertEqual(data["nodes"]["bbb-2"]["scenario_steps"], [{"scenario": "scenario-1", "step": 1}])
        self.assertEqual(data["nodes"]["operation-2"]["scenario_steps"], [{"scenario": "scenario-1", "step": 1}])
        self.assertTrue(any("шаг 2 «Показан оффер»" in n for n in result.notes), result.notes)

    def test_bind_scenario_step_rejects_containers_and_unknown_steps(self):
        review = ConnectivityReview(scenarios=[_scenario(["Реплика классифицируется", "Собирается портфель"])])
        script = _happy_script()
        script.insert(-1, _tool_call("bind_scenario_step", scenario="scenario-1", step=0, nodes=["process-1"]))
        script.insert(-1, _tool_call("bind_scenario_step", scenario="scenario-1", step=5, nodes=["bbb-1"]))
        script.insert(-1, _tool_call("bind_scenario_step", scenario="scenario-1", step=0, nodes=["bbb-1"]))
        script.insert(-1, _tool_call("bind_scenario_step", scenario="scenario-1", step=1, nodes=["bbb-2"]))
        result = self._run(*script, connectivity=review)
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertFalse(any("шаги сценариев без узла" in n for n in result.notes), result.notes)
        self.assertEqual(data["nodes"]["bbb-1"]["scenario_steps"], [{"scenario": "scenario-1", "step": 0}])
        self.assertEqual(data["nodes"]["process-1"].get("scenario_steps", []), [])

    def test_no_spec_returns_note(self):
        result = run_passport_agent(self.plan, {}, self.verdicts, None, None)
        self.assertIsNone(result.passport_data)
        self.assertTrue(result.notes)

    def test_digest_contains_evidence_and_knowledge(self):
        text = render_evaluation_digest(self.plan, self.verdicts, None, ["[read_file app.py:1-40 — def select()]"])
        self.assertIn("app.py:3 — select — подбирает вклад", text)
        self.assertIn("[read_file app.py", text)
        self.assertIn("Подобран продукт. — done", text)


class PassportMapTest(unittest.TestCase):
    """Схема: общий узел под первым родителем, связи в контракте, пропуски
    шагов сценария на пути."""

    def _model(self, data: dict, scenario: Scenario | None = None) -> ProgressModel:
        plan = PlanItem(id="s1", title="Подбор", criteria=["Подобран продукт.", "Показан оффер."], origin="user")
        verdicts = [ItemVerdict(item_id="s1", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="done", proof="", how=""),
            CriterionVerdict(applicable=True, status="planned", proof="", how=""),
        ])]
        model = ProgressModel(meta={}, items={"s1": plan}, verdicts=verdicts)
        model.passport_data = data
        if scenario is not None:
            model.connectivity = ConnectivityReview(scenarios=[scenario])
        return model

    def test_nodes_carry_all_parents_and_relations(self):
        norm = normalize_passport(_valid())
        nodes = {n["id"]: n for n in passport_map_nodes(norm)}
        self.assertEqual(nodes["bbb-1"]["parents"], ["process-1", "process-2"])
        self.assertEqual(nodes["bbb-1"]["parent"], "process-1")
        self.assertIsNone(nodes["journey-1"]["parent"])
        self.assertTrue(nodes["bbb-4"]["before_fork"])
        self.assertEqual(nodes["bbb-4"]["parent"], "journey-1")
        schema = build_passport_map(self._model(norm))
        self.assertEqual([r["kind"] for r in schema["relations"]], ["triggers", "triggers", "feeds"])
        by_id = {n["id"]: n for n in schema["nodes"]}
        self.assertEqual(len(by_id["bbb-4"]["relations"]), 2)
        self.assertEqual(schema["summary"]["shared_nodes"], 1)
        self.assertEqual(schema["summary"]["before_fork_nodes"], 1)
        self.assertEqual(schema["summary"]["relations_total"], 3)

    def test_confirmed_or_bullet_can_ground_status_without_redundant_confirmation(self):
        data = _valid()
        data["nodes"]["bbb-1"]["bullets"] = ["Подобран продукт."]
        norm = normalize_passport(data)
        by_id = {n["id"]: n for n in build_passport_map(self._model(norm))["nodes"]}
        # Подтверждённый пункт ОР достаточен для статуса контейнера; отдельная
        # операция без привязки и критичных полей остаётся неизвестной.
        self.assertEqual(by_id["bbb-1"]["readiness"], 100)
        self.assertEqual(by_id["process-1"]["implementation_status"], "implemented")
        self.assertEqual(by_id["process-2"]["implementation_status"], "partial")
        self.assertEqual(by_id["process-2"]["assessment_source"], "children")
        self.assertEqual(by_id["operation-1"]["implementation_status"], "unknown")

    def test_leaf_status_by_field_levels_and_critical_cap(self):
        data = _valid()
        est = "Установлено: opener.py открывает продукт"
        data["nodes"]["operation-2"]["fields"] = {
            "4.5.4": _f("Продукт открыт.", est), "4.5.5": _f("Вход — заявка, выход — договор.", est),
            "4.5.6": _f("Повтор безопасен.", est),
        }
        by_id = {n["id"]: n for n in build_passport_map(self._model(normalize_passport(data)))["nodes"]}
        self.assertEqual(by_id["operation-2"]["implementation_status"], "implemented")
        self.assertEqual(by_id["operation-2"]["assessment_source"], "fields")
        # Подтверждённый пункт ОР снимает требование повторного подтверждения
        # для статуса, поэтому карточка не противоречит зелёному бейджу.
        data["nodes"]["operation-2"]["bullets"] = ["Подобран продукт."]
        data["nodes"]["operation-2"]["fields"]["4.5.6"] = _f("Защита от двойного списания не установлена.", "Не установлено")
        by_id = {n["id"]: n for n in build_passport_map(self._model(normalize_passport(data)))["nodes"]}
        self.assertEqual(by_id["operation-2"]["implementation_status"], "implemented")
        self.assertFalse(any("недостаточно данных" in p.lower() for p in by_id["operation-2"]["problems"]))

    def test_parent_with_working_and_missing_parts_is_partial(self):
        data = _valid()
        est = "Установлено: runtime.py вызывает операцию и проверяет результат"
        for op in ("operation-1", "operation-2", "operation-3", "operation-4"):
            data["nodes"][op]["fields"] = {
                "4.5.4": _f("Эффект подтверждается ответом исполнителя.", est),
                "4.5.5": _f("Вход — запрос, выход — подтверждённый результат.", est),
                "4.5.6": _f("Повтор и компенсация описаны обработчиком.", est),
            }
        data["nodes"]["operation-2"]["basis"] = "код закомментирован и заменён заглушкой"
        by_id = {n["id"]: n for n in build_passport_map(self._model(normalize_passport(data)))["nodes"]}
        self.assertEqual(by_id["operation-2"]["implementation_status"], "partial")
        self.assertEqual(by_id["bbb-2"]["implementation_status"], "partial")
        self.assertEqual(by_id["process-1"]["implementation_status"], "partial")
        self.assertEqual(by_id["process-2"]["implementation_status"], "partial")
        self.assertTrue(any("реализована не полностью" in p for p in by_id["process-1"]["problems"]))

    def test_defects_registry_includes_promises_and_breaks(self):
        data = _valid()
        data["nodes"]["process-2"]["planned"] = True
        data["nodes"]["process-2"]["bullets"] = ["Показан оффер."]
        data["defects"] = [{"title": "анализ трат отключён: доли считаются по нулевым тратам", "kind": "data",
                            "nodes": ["bbb-2"], "scenarios": ["scenario-1"]}]
        data["nodes"]["bbb-1"]["scenario_steps"] = [{"scenario": "scenario-1", "step": 0}]
        data["nodes"]["bbb-2"]["scenario_steps"] = [{"scenario": "scenario-1", "step": 1}]
        scenario = _scenario(["Классификация", "Сборка портфеля"], ["broken"])
        schema = build_passport_map(self._model(normalize_passport(data), scenario))
        kinds = [(d["kind"], d["source"], d["blocking"]) for d in schema["defects"]]
        # Автоматический разрыв усиливает уже сформулированный агентом дефект,
        # а не дублирует его второй технической строкой.
        self.assertEqual(kinds[0], ("data", "agent", True))
        self.assertIn(("completeness", "code", False), kinds)
        by_id = {n["id"]: n for n in schema["nodes"]}
        self.assertIn("defect-1", by_id["bbb-2"]["defects"])
        self.assertFalse(any("Показан оффер" in p for p in by_id["process-2"]["problems"]))
        self.assertEqual(schema["summary"]["defects_total"], 2)
        self.assertEqual(schema["summary"]["defects_blocking"], 1)
        self.assertEqual(schema["summary"]["blocking_breaks"], 1)

    def test_handoffs_table_from_connectivity(self):
        data = _valid()
        data["nodes"]["bbb-1"]["scenario_steps"] = [{"scenario": "scenario-1", "step": 0}]
        data["nodes"]["bbb-2"]["scenario_steps"] = [{"scenario": "scenario-1", "step": 1}]
        data["relations"].append({"from": "bbb-1", "to": "bbb-2", "kind": "feeds",
                                  "basis": "профиль уходит в сборку", "field": "client_profile"})
        scenario = _scenario(["Классификация", "Сборка портфеля"])
        schema = build_passport_map(self._model(normalize_passport(data), scenario))
        [row] = schema["handoffs"]
        self.assertEqual((row["from_nodes"], row["to_nodes"]), (["bbb-1"], ["bbb-2"]))
        self.assertEqual(row["field"], "client_profile")
        self.assertEqual([c["check"] for c in row["checks"]][:3], ["reachability", "contract", "data_continuity"])
        self.assertEqual(row["checks"][4]["result_label"], "не проверялось")
        self.assertTrue(row["checked"])
        self.assertTrue(row["wiring_unchecked"])
        self.assertEqual(schema["summary"]["handoffs_checked"], 1)
        self.assertEqual(schema["summary"]["wiring_unchecked"], 1)

    def test_unmapped_scenario_steps_are_explicit(self):
        data = _valid()
        data["nodes"]["bbb-1"]["scenario_steps"] = [{"scenario": "scenario-1", "step": 0}]
        data["nodes"]["bbb-2"]["scenario_steps"] = [{"scenario": "scenario-1", "step": 2}]
        scenario = _scenario(["Классификация", "Профиль клиента", "Сборка портфеля"], ["ok", "broken"])
        schema = build_passport_map(self._model(normalize_passport(data), scenario))
        [path] = schema["paths"]
        self.assertEqual(path["steps_mapped"], 2)
        self.assertEqual(path["steps_total"], 3)
        self.assertEqual(path["unmapped_steps"], [{"step": 1, "text": "Профиль клиента"}])
        self.assertTrue(any("Профиль клиента" in p for p in path["problems"]), path["problems"])
        [edge] = path["edges"]
        self.assertEqual((edge["from"], edge["to"], edge["result"], edge["skipped"]), ("bbb-1", "bbb-2", "broken", [1]))
        self.assertEqual(schema["summary"]["scenario_steps_mapped"], 2)
        self.assertEqual(schema["summary"]["scenario_steps_total"], 3)

    def test_scenario_without_any_node_is_a_path_problem(self):
        scenario = _scenario(["Классификация", "Сборка портфеля"])
        schema = build_passport_map(self._model(normalize_passport(_valid()), scenario))
        [path] = schema["paths"]
        self.assertEqual(path["steps_mapped"], 0)
        self.assertEqual(path["problems"], ["ни один шаг сценария не привязан к узлу схемы"])


_JOURNEY = """\
Клиентский путь: Размещение сбережений
Проект: Демо-проект
## Подбор
- Подобран продукт.
"""


class RenderWithGateTest(unittest.TestCase):

    def _render(self, data):
        model = ProgressModel(meta={}, items={}, verdicts=[])
        model.passport_data = data
        plan = parse_plan_text(_JOURNEY)
        return render_client_journey_passport(
            model, plan, "demo/repo", Extraction(facts=[]),
            commit="abc1234", branch="main",
            llm_values=flatten_passport_data(data) if data else None,
            registry_rows=passport_registry_rows(data) if data else None,
            tree_spec=passport_tree_spec(data) if data else None,
        )

    def test_badge_switches_by_source(self):
        html = self._render(normalize_passport(_valid()))
        self.assertIn(STATUS_BADGE_AGENT, html)
        self.assertNotIn(STATUS_BADGE_TEMPLATE, html)
        html = self._render(None)
        self.assertIn(STATUS_BADGE_FALLBACK, html)

    def test_all_parents_in_registry_and_shared_node_rendered_once(self):
        html = self._render(normalize_passport(_valid()))
        self.assertIn('<td data-col="Родитель">process-1, process-2</td>', html)
        self.assertEqual(html.count('id="bbb-1"'), 1)
        self.assertIn("Ответ по справочнику продуктов", html)
        self.assertIn("bbb.sborka-portfelya", html)
        self.assertIn('"kind_label":"запускает"', html)

    def test_needs_and_guardrails_removed_from_output(self):
        for data in (normalize_passport(_valid()), None):
            html = self._render(data)
            self.assertNotIn('id="related-needs"', html)
            self.assertNotIn('id="related-guardrails"', html)
            self.assertNotIn('id="need-1"', html)
            self.assertNotIn('id="guardrail-1"', html)
            self.assertNotIn('id="tpl-need"', html)
            self.assertNotIn('id="tpl-guardrail"', html)
            # Дерево на месте, библиотека заготовок в выпуск не идёт.
            self.assertNotIn('id="tpl-operation"', html)
            self.assertNotIn('<template', html)
            self.assertNotIn('id="operation-N"', html)
            self.assertIn('id="journey-1"', html)

    def test_basis_section_removed_and_scope_kept_in_header(self):
        html = self._render(normalize_passport(_valid()))
        self.assertNotIn("Основание паспорта", html)
        self.assertNotIn('data-fill="initiative-basis"', html)
        self.assertNotIn('data-fill="analysis-scope"', html)
        self.assertIn('"scope":"repo · abc1234 · проект"', html)

    def test_header_uses_initiative_name_and_keeps_journey_name_separate(self):
        data = _valid()
        data["nodes"]["journey-1"]["name"] = "Размещение сбережений в подобранные вклады"
        html = self._render(normalize_passport(data))
        self.assertIn("Паспорт инициативы «Демо-проект»", html)
        self.assertIn("Размещение сбережений в подобранные вклады", html)
        self.assertIn("'Паспорт инициативы'", html)

    def test_registry_has_status_column_from_map(self):
        html = self._render(normalize_passport(_valid()))
        self.assertIn(">Статус</th>", html)
        self.assertIn('<td data-col="Статус">', html)
        self.assertLess(html.index(">Статус</th>"), html.index("Основание существования узла"))

    def test_before_fork_node_rendered_under_journey(self):
        html = self._render(normalize_passport(_valid()))
        self.assertEqual(html.count('id="bbb-4"'), 1)
        self.assertIn('data-children="bbb" data-before-fork="true"', html)
        journey_start = html.index('id="journey-1"')
        gate = html.index('id="bbb-4"')
        first_process = html.index('id="process-1"')
        self.assertLess(journey_start, gate)
        self.assertLess(gate, first_process)
        self.assertIn('"before_fork":true', html)
        self.assertIn('<td data-col="Родитель">journey-1</td>', html)

    def test_existing_bbb_one_is_relocated_from_template_before_process(self):
        data = _valid()
        root_children = data["tree"][0]["children"]
        # Если узел до развилки идёт первым, после нормализации он получает
        # id bbb-1 — тот же id, который уже есть в статическом шаблоне.
        data["tree"][0]["children"] = [root_children[2], root_children[0], root_children[1]]
        norm = normalize_passport(data)
        self.assertTrue(norm["nodes"]["bbb-1"]["before_fork"])
        html = self._render(norm)
        self.assertEqual(html.count('id="bbb-1"'), 1)
        self.assertLess(html.index('id="bbb-1"'), html.index('id="process-1"'))
        self.assertIn('<td data-col="Родитель">journey-1</td>', html)

    def test_graph_levels_needs_and_guardrails_from_fields(self):
        html = self._render(normalize_passport(_valid()))
        self.assertNotIn("Вердикт схемы", html)
        # Шесть уровней графа, объекты потребности и ограничений — из полей.
        for label in ("Потребность клиента", "Клиентский путь", "Автономный процесс", "Атомарная операция", "Ограничение исполнения"):
            self.assertIn(label, html)
        self.assertIn('"needs":[', html)
        self.assertIn('"guardrails":[', html)
        self.assertIn('"handoffs":[', html)
        self.assertIn('"defects":[', html)
        self.assertIn("planned_fields", html)
        self.assertIn("Открыть описание", html)
        self.assertIn("Показать весь граф", html)
        self.assertNotIn("Реестр дефектов", html)
        self.assertNotIn("Таблица передач", html)
        # Потребность и ограничение — объекты, которые сформулировал агент.
        data = _valid()
        data["needs"] = [{"name": "Разместить сбережения без разбора продуктов", "purpose": "Человек хочет выгодно разместить свободные деньги, не разбираясь в линейке вкладов.", "source": "Выведено: образ результата — базовый сценарий подбора вклада"}]
        data["guardrails"] = [{"name": "Открытие только после подтверждения", "invariant": "Продукт не открывается без явного согласия клиента", "condition": "Перед каждым переводом средств", "effect": "REQUIRE_CONFIRMATION", "targets": ["bbb-2"], "source": "Установлено: opener.py ждёт нажатия кнопки"}]
        html = self._render(normalize_passport(data))
        self.assertIn('"id":"need-1","name":"Разместить сбережения без разбора продуктов"', html)
        self.assertIn('"id":"guardrail-1","name":"Открытие только после подтверждения"', html)
        self.assertIn('"effect_label":"требуется подтверждение"', html)
        self.assertIn('"targets":["bbb-2"]', html)
        self.assertNotIn("pko-badge", html.split("<script data-passport-fix>")[-1])

    def test_operational_risk_is_shown_on_graph_and_in_node_card(self):
        data = _valid()
        data["risks"] = [{
            "title": "Повторное списание после неопределённого ответа",
            "scope": "local", "cause": "После тайм-аута результат внешнего списания остаётся неизвестным",
            "negative_event": "Повтор запроса создаёт второе списание по одной операции клиента",
            "consequences": ["Клиент теряет деньги до ручного возврата, банк нарушает обязательство по корректному списанию"],
            "primary_node": "operation-2", "linked_nodes": ["operation-2"],
            "existing_controls": [{"description": "Число повторов ограничено в вызывающем процессе",
                                   "basis": "app.py:3 — обработчик ограничивает число попыток"}],
            "control_gap": "Сквозная идемпотентность и сверка результата внешнего списания не подтверждены",
            "guardrails": [], "evidence": [{"where": "app.py:3", "basis": "после тайм-аута выполняется повторный вызов"}],
            "confidence": "inferred", "confidence_note": "Повтор подтверждён, внешний результат напрямую не наблюдается",
            "confirmation_needed": "",
        }]
        html = self._render(normalize_passport(data))
        self.assertIn('"id":"risk-1"', html)
        self.assertIn('"risks":["risk-1"]', html)
        self.assertIn("Повторное списание после неопределённого ответа", html)
        self.assertIn("Операционные риски · статус реализации не меняют", html)
        self.assertIn("операционных рисков: ", html)
        self.assertNotIn("metric('Операционных рисков'", html)


if __name__ == "__main__":
    unittest.main()

"""CJ Hack для проекта: PKO-отчёт + редакторский слой → набор данных v4 → HTML.

Что делает CJ Hack: сравнивает лучшую практику ИИ-процесса (каталог аспектов),
образ результата инициативы (ОР, пункты нашего отчёта) и реализацию (наша
проверка кода). Два числа — покрытие ОР лучшей практикой и готовность
реализации по ОР — считает viewer сам из данных; здесь они не вычисляются.

Разделение труда, как в исходном проекте CJ_Hack_Run6:

* **механическая часть** — из PKO-дашборда без изменений: архив отчёта
  (`documents`), пункты ОР с исходной оценкой (`sourceRequirements`), дословные
  цитаты «текст / проверка / как работает» (`evidence`), ссылки на код
  (`codeReferences`), связки для сравнения (`comparisons`);
* **редакторская часть** — файл `projects/<код>.json`: этапы клиентского пути,
  каталог аспектов лучшей практики с бенчмарками, привязка пунктов ОР к
  аспектам, статусы реализации и короткие формулировки (до семи слов).

Ничего не выдумывается: цитаты берутся дословно и проверяются валидатором
viewer (`validate.mjs`), адреса бенчмарков — только из `products.json`.

    python cjhack/build.py --reports <папка с отчётами> [--only АГ-40]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "backend"))

from pko.render.passport_map import (  # noqa: E402
    PASSPORT_MAP_CSS,
    PASSPORT_MAP_JS,
    nodes_json,
)
from pko.web.collect import report_of  # noqa: E402

APPLICATION = {
    "name": "CJ Hack",
    "mission": "Переосмыслить свой процесс или клиентский путь с помощью ИИ",
}
BASELINE_LABEL = "ОР Сбера"
SCHEMA_VERSION = "4.0.1"
SOURCE_ID = "src-readiness"
DECK_SOURCE_ID = "src-deck"
SCOPE_OR = "SCOPE-OR"
SCOPE_REVIEW = "SCOPE-REVIEW"
_SHORT = re.compile(r"^\S+(?:\s+\S+){0,6}$")
_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")

# Статус реализации аспекта по статусам привязанных пунктов PKO, если
# редактор не задал его явно.
_PRESENT_STATUSES = ("done", "limited", "unused", "partial")
_GAP_STATUSES = ("planned", "blocked", "partial", "unused")


class SpecError(ValueError):
    pass


def short(text: str, where: str) -> str:
    text = " ".join((text or "").split())
    if not text or not _SHORT.match(text):
        raise SpecError(f"{where}: нужна формулировка от одного до семи слов, получено: {text!r}")
    return text


def ident(value: str, where: str) -> str:
    if not value or not _ID.match(value):
        raise SpecError(f"{where}: идентификатор {value!r} — только латиница, цифры, точка, дефис, подчёркивание")
    return value


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# Имена папок и файлов — только латиница: кириллица в пути уезжает в адрес
# percent-кодировкой, и на стенде такие адреса отдавали 404. На экране имена
# не видны — там названия инициатив из реестра, а не имена файлов.
_TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch",
    "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
}


def slug(text: str) -> str:
    """Имя файла или папки латиницей: «АГ-37_Агент_ОСАГО» → «AG-37_Agent_OSAGO»."""
    out: list[str] = []
    for ch in str(text):
        lower = ch.lower()
        if lower in _TRANSLIT:
            latin = _TRANSLIT[lower]
            out.append(latin.upper() if ch.isupper() and latin else latin)
        elif ch.isascii() and (ch.isalnum() or ch in "._-"):
            out.append(ch)
        else:
            out.append("_")
    return re.sub(r"_{2,}", "_", "".join(out)).strip("_.") or "report"


# --- механическая часть -------------------------------------------------------
def normalize_row(row: dict[str, Any]) -> dict[str, Any]:
    """Строка PKO-дашборда → `originalAssessment` контракта (ровно его поля)."""
    applicable = row.get("applicable") is True
    status = str(row.get("status") or "")
    if not applicable:
        status = "na"
    links = [
        {"path": str(l["path"]), "line": int(l["line"]), "basis": str(l.get("basis") or ""),
         "note": str(l.get("note") or "")}
        for l in (row.get("links") or []) if l.get("line") is not None
    ]
    return {
        "text": str(row["text"]),
        "group": str(row.get("group") or ""),
        "applicable": applicable,
        "status": status,
        "status_label": str(row.get("status_label") or ("Не применимо" if not applicable else "")),
        "proof": str(row.get("proof") or (row.get("na_reason") or "" if not applicable else "")),
        "how": str(row.get("how") or ""),
        "links": links,
    }


def archive(report: dict[str, Any]) -> dict[str, Any]:
    """Архив PKO-отчёта в формате `sourceArchive`: meta со шкалой и items."""
    meta = dict(report.get("meta") or {})
    meta["scale"] = [
        {"status": s["status"], "label": s["label"], "weight": s.get("weight"),
         "weight_prod": s.get("weight_prod"), "meaning": s.get("meaning") or ""}
        for s in (meta.get("scale") or [])
    ]
    items = []
    for item in report.get("items") or []:
        items.append({
            "title": item.get("title"), "description": item.get("description"),
            "percent": item.get("percent"), "applicable": bool(item.get("applicable")),
            "assessment": [normalize_row(r) for r in item.get("assessment") or []],
        })
    return {"meta": meta, "items": items}


def requirements(doc: dict[str, Any]) -> list[dict[str, Any]]:
    """R01..Rnn — пункты ОР с исходной оценкой и готовностью по шкале источника."""
    scale = {s["status"]: s for s in doc["meta"]["scale"]}
    out = []
    n = 0
    for item in doc["items"]:
        for original in item["assessment"]:
            n += 1
            rid = f"R{n:02d}"
            if original["applicable"]:
                weight = scale.get(original["status"], {}).get("weight")
                if weight is None:
                    raise SpecError(f"{rid}: статусу {original['status']!r} нет веса в шкале отчёта")
                readiness = {"state": "known", "percent": weight, "method": "source_scale",
                             "sourceStatus": original["status"], "scaleField": "weight"}
            else:
                readiness = {"state": "na", "percent": None, "method": "not_applicable",
                             "sourceStatus": original["status"], "scaleField": None}
            out.append({"id": rid, "sourceId": SOURCE_ID, "text": original["text"],
                        "originalAssessment": original, "readiness": readiness})
    texts = [r["text"] for r in out]
    if len(set(texts)) != len(texts):
        raise SpecError("в отчёте два пункта с одинаковым текстом — контракт требует уникальности")
    return out


def quote_evidence(reqs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Дословные цитаты: текст пункта, «Проверка», «Как работает»."""
    out = []
    for r in reqs:
        o = r["originalAssessment"]
        out.append({"id": f"TXT-{r['id']}", "sourceId": SOURCE_ID, "sourceRequirementId": r["id"],
                    "field": "text", "quote": o["text"], "locator": f"Пункт {r['id']}"})
        if o["applicable"]:
            if o["proof"]:
                out.append({"id": f"PROOF-{r['id']}", "sourceId": SOURCE_ID, "sourceRequirementId": r["id"],
                            "field": "proof", "quote": o["proof"], "locator": f"Проверка {r['id']}"})
            if o["how"]:
                out.append({"id": f"HOW-{r['id']}", "sourceId": SOURCE_ID, "sourceRequirementId": r["id"],
                            "field": "how", "quote": o["how"], "locator": f"Как работает {r['id']}"})
    return out


def code_references(reqs: list[dict[str, Any]], impl_evidence: dict[str, list[str]]) -> list[dict[str, Any]]:
    out = []
    for r in reqs:
        for index, link in enumerate(r["originalAssessment"]["links"]):
            out.append({
                "id": f"CODE-{r['id']}-{index + 1:02d}", "sourceRequirementId": r["id"],
                "originalLinkIndex": index, "path": link["path"], "lineStart": link["line"],
                "lineEnd": None, "basis": link["basis"], "note": link["note"],
                "evidenceIds": list(impl_evidence.get(r["id"], [])),
                "url": None, "excerpt": None, "revision": None, "enrichmentSourceId": None,
            })
    return out


# --- редакторская часть -------------------------------------------------------
def load_products() -> dict[str, dict[str, str]]:
    raw = json.loads((HERE / "products.json").read_text(encoding="utf-8"))
    return {k: v for k, v in raw.items() if not k.startswith("_")}


def build_aspect(
    spec: dict[str, Any], req_by_id: dict[str, dict[str, Any]], impl_ev: dict[str, list[str]],
    scope_ids: list[str], products: dict[str, dict[str, str]],
) -> dict[str, Any]:
    aid = ident(spec["id"], "aspect.id")
    where = f"аспект {aid}"
    kind = spec.get("kind", "functional")
    if kind not in ("functional", "nfr"):
        raise SpecError(f"{where}: kind должен быть functional или nfr")
    role = spec.get("role")
    if kind == "functional" and role not in ("ai", "enabling", "human_loop"):
        raise SpecError(f"{where}: функциональному аспекту нужна роль ai / enabling / human_loop")
    if kind == "nfr":
        role = None

    benchmark = spec.get("benchmark")
    if benchmark not in products:
        raise SpecError(f"{where}: бенчмарк {benchmark!r} не описан в products.json")

    reqs = list(spec.get("requirements") or [])
    for rid in reqs:
        if rid not in req_by_id:
            raise SpecError(f"{where}: пункта {rid} нет в отчёте")
        if not req_by_id[rid]["originalAssessment"]["applicable"]:
            raise SpecError(f"{where}: пункт {rid} неприменим в отчёте и привязан быть не может")
    coverage = spec.get("coverage")
    if coverage not in ("covered", "partial", "not_covered", "unknown"):
        raise SpecError(f"{where}: coverage должен быть covered / partial / not_covered / unknown")
    planned = coverage in ("covered", "partial")
    if planned != bool(reqs):
        raise SpecError(f"{where}: covered/partial требуют пунктов ОР, not_covered/unknown — их отсутствия")

    base_ev = [f"TXT-{rid}" for rid in reqs]
    context = [] if coverage == "covered" else list(scope_ids)
    planned_part = None
    if planned:
        planned_part = {
            "summary": short(spec.get("planSummary", ""), f"{where}.planSummary"),
            "description": spec.get("planRationale") or spec.get("planSummary"),
            "evidenceIds": base_ev,
        }
    unplanned_part = None
    if coverage in ("partial", "not_covered"):
        u = spec.get("unplanned") or {}
        unplanned_part = {
            "summary": short(u.get("summary", ""), f"{where}.unplanned.summary"),
            "description": u.get("description") or u.get("summary"),
            "evidenceIds": list(scope_ids),
        }
    applicability = "undetermined" if coverage == "unknown" else ("in_scope" if planned else "na")

    implementation: dict[str, Any]
    if applicability != "in_scope":
        implementation = {"applicability": applicability, "status": "nd", "summary": "n/a",
                          "present": None, "gap": None, "evidenceIds": [], "limitations": []}
    else:
        statuses = {rid: req_by_id[rid]["originalAssessment"]["status"] for rid in reqs}
        limitations_spec = spec.get("limitations") or []
        limited_covered = {rid for l in limitations_spec for rid in l.get("requirements", [])}
        status = spec.get("status")
        if not status:
            if all(s == "done" or (s == "limited" and rid in limited_covered) for rid, s in statuses.items()):
                status = "implemented"
            elif all(s in ("planned", "blocked") for s in statuses.values()):
                status = "absent"
            else:
                status = "partial"
        if status not in ("implemented", "partial", "absent", "nd"):
            raise SpecError(f"{where}: status должен быть implemented / partial / absent / nd")
        all_ev = [e for rid in reqs for e in impl_ev.get(rid, [])]

        def evidence_for(rids: list[str], fields: tuple[str, ...]) -> list[str]:
            return [e for rid in rids for e in impl_ev.get(rid, [])
                    if e.split("-", 1)[0] in fields]

        present_reqs = spec.get("presentRequirements") or [
            rid for rid, s in statuses.items() if s in _PRESENT_STATUSES]
        gap_reqs = spec.get("gapRequirements") or [
            rid for rid, s in statuses.items() if s in _GAP_STATUSES] or reqs
        present = gap = None
        if status in ("implemented", "partial") and spec.get("present"):
            present = {"summary": short(spec["present"], f"{where}.present"),
                       "evidenceIds": evidence_for(present_reqs, ("PROOF", "HOW"))}
        if status in ("absent", "partial") and spec.get("gap"):
            gap = {"summary": short(spec["gap"], f"{where}.gap"),
                   "evidenceIds": evidence_for(gap_reqs, ("PROOF",))}
        # Статус аспекта выводится из статусов пунктов отчёта, а формулировки
        # пишет редактор заранее. Значит, перепрогон инициативы может обрушить
        # спецификацию, написанную под прошлый отчёт: пункт был «работает», стал
        # «не реализовано» — и спека, где есть только `present`, перестаёт
        # собираться. Поэтому в ошибку идут статусы пунктов: без них непонятно,
        # что именно изменилось и какую формулировку дописывать.
        def because() -> str:
            rows = ", ".join(f"{rid}={statuses[rid]}" for rid in reqs) or "нет пунктов"
            return f" (по отчёту: {rows})"

        if status == "implemented" and (present is None or gap is not None):
            raise SpecError(f"{where}: implemented требует present и не допускает gap" + because())
        if status == "absent" and gap is None:
            raise SpecError(f"{where}: absent требует gap" + because())
        if status == "partial" and present is None and gap is None:
            raise SpecError(f"{where}: partial требует present или gap" + because())
        if status == "nd":
            present = gap = None
        limitations = [
            {"summary": short(l["summary"], f"{where}.limitations"),
             "evidenceIds": evidence_for(l.get("requirements") or reqs, ("PROOF",))}
            for l in limitations_spec
        ]
        for fact in [present, gap, *limitations]:
            if fact and not fact["evidenceIds"]:
                raise SpecError(f"{where}: факту «{fact['summary']}» не нашлось цитат проверки")
        implementation = {
            "applicability": "in_scope", "status": status,
            "summary": short(spec.get("implSummary") or (present or gap or {}).get("summary", "n/a"),
                             f"{where}.implSummary"),
            "present": present, "gap": gap, "evidenceIds": all_ev, "limitations": limitations,
        }

    practice = products[benchmark]
    return {
        "id": aid, "kind": kind, "label": spec["label"], "role": role,
        "legacyFeatureIds": [],
        "bestPractice": {
            "summary": short(spec.get("practiceSummary") or spec["label"], f"{where}.practiceSummary"),
            "description": spec.get("practice") or spec["label"],
            "basis": spec.get("basis", "adaptation_for_autotracking"),
            "benchmarks": [{"productId": benchmark, "evidenceIds": [f"REF-{benchmark}"]}],
        },
        "baseline": {
            "coverage": coverage,
            "summary": short(spec.get("planSummary") or "Не предусмотрено в ОР", f"{where}.planSummary"),
            "rationale": spec.get("planRationale") or spec.get("planSummary")
                         or "Отдельного пункта в образе результата нет.",
            "sourceRequirementIds": reqs, "evidenceIds": base_ev, "contextEvidenceIds": context,
            "plannedPart": planned_part, "unplannedPart": unplanned_part,
        },
        "implementation": implementation,
        "_practiceLocator": practice["locator"],
    }


def build_capability(spec: dict[str, Any], aspects: dict[str, dict[str, Any]], step_ids: set[str]) -> dict[str, Any]:
    cid = ident(spec["id"], "capability.id")
    where = f"функция {cid}"
    step = spec["step"]
    if step not in step_ids:
        raise SpecError(f"{where}: этапа {step!r} нет в journeySteps")
    ids = list(spec.get("aspects") or [])
    if not ids:
        raise SpecError(f"{where}: нужен хотя бы один аспект")
    for aid in ids:
        if aid not in aspects:
            raise SpecError(f"{where}: аспект {aid} не описан")

    def fact(key: str, pick):
        chosen = [aid for aid in ids if pick(aspects[aid])]
        text = spec.get(key)
        if not chosen:
            return None
        if not text:
            raise SpecError(f"{where}: есть аспекты для «{key}» ({', '.join(chosen)}), нужна формулировка")
        evidence: list[str] = []
        for aid in chosen:
            a = aspects[aid]
            source = (a["baseline"]["unplannedPart"] if key == "unplanned"
                      else a["implementation"]["present"] if key == "implemented"
                      else a["implementation"]["gap"])
            for e in source["evidenceIds"]:
                if e not in evidence:
                    evidence.append(e)
        return {"summary": short(text, f"{where}.{key}"), "aspectIds": chosen, "evidenceIds": evidence}

    return {
        "id": cid, "stepId": step, "title": spec["title"], "aspectIds": ids,
        "summary": {
            "implemented": fact("implemented", lambda a: a["implementation"]["present"] is not None),
            "unimplemented": fact("unimplemented", lambda a: a["implementation"]["applicability"] == "in_scope"
                                  and a["implementation"]["gap"] is not None),
            "unplanned": fact("unplanned", lambda a: a["baseline"]["unplannedPart"] is not None),
        },
    }


def comparisons(aspects: list[dict[str, Any]], reqs: list[dict[str, Any]],
                impl_ev: dict[str, list[str]], codes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    codes_by_req: dict[str, list[str]] = {}
    for c in codes:
        codes_by_req.setdefault(c["sourceRequirementId"], []).append(c["id"])
    out = []
    for a in aspects:
        out.append({
            "id": f"CMP-{a['id']}", "aspectId": a["id"],
            "bestPracticeEvidenceIds": [e for b in a["bestPractice"]["benchmarks"] for e in b["evidenceIds"]],
            "baselineLinks": [
                {"sourceRequirementId": rid, "baselineEvidenceIds": [f"TXT-{rid}"],
                 "implementationEvidenceIds": list(impl_ev.get(rid, [])),
                 "codeReferenceIds": codes_by_req.get(rid, []), "granularity": "source_requirement"}
                for rid in a["baseline"]["sourceRequirementIds"]
            ],
            "scopeEvidenceIds": list(a["baseline"]["contextEvidenceIds"]),
            "supportingEvidenceIds": [],
        })
    return out


def journey_steps(spec: dict[str, Any], report: dict[str, Any]) -> list[dict[str, Any]]:
    steps = spec.get("steps")
    if not steps:
        stages = (report.get("meta") or {}).get("stages") or []
        if not isinstance(stages, list) or not stages:
            raise SpecError("этапы пути не заданы ни в спецификации, ни в отчёте")
        steps = [{"id": f"step{i + 1}", "title": s, "value": s} for i, s in enumerate(stages)]
    return [{"id": ident(s["id"], "step.id"), "title": s["title"], "order": i + 1,
             "value": s.get("value") or s["title"]} for i, s in enumerate(steps)]


# --- сборка --------------------------------------------------------------------
def build_dataset(spec: dict[str, Any], report_path: Path) -> dict[str, Any]:
    raw = report_path.read_bytes()
    report = report_of(raw.decode("utf-8", errors="replace"))
    if not report:
        raise SpecError(f"{report_path.name}: это не PKO-дашборд, window.__DATA__ не найден")
    meta = report.get("meta") or {}
    products = load_products()
    doc = archive(report)
    reqs = requirements(doc)
    req_by_id = {r["id"]: r for r in reqs}
    evidence = quote_evidence(reqs)
    impl_ev: dict[str, list[str]] = {}
    for e in evidence:
        if e["field"] in ("proof", "how"):
            impl_ev.setdefault(e["sourceRequirementId"], []).append(e["id"])
    codes = code_references(reqs, impl_ev)

    steps = journey_steps(spec, report)
    total_applicable = sum(1 for r in reqs if r["originalAssessment"]["applicable"])
    generated = str(meta.get("generated_at") or "")[:10] or None
    stage_titles = ", ".join(s["title"] for s in steps)
    scope_evidence = [
        {"id": SCOPE_OR, "sourceId": DECK_SOURCE_ID, "sourceRequirementId": None, "field": "scope", "quote": None,
         "locator": f"Образ результата инициативы: {len(reqs)} пунктов; этапы клиентского пути: {stage_titles}"},
        {"id": SCOPE_REVIEW, "sourceId": SOURCE_ID, "sourceRequirementId": None, "field": "scope", "quote": None,
         "locator": f"Проверка кода по {total_applicable} применимым пунктам образа результата; "
                    "полный аудит репозитория не проводился"},
    ]
    scope_ids = [SCOPE_OR, SCOPE_REVIEW]

    aspects_list = [build_aspect(a, req_by_id, impl_ev, scope_ids, products) for a in spec.get("aspects") or []]
    aspects = {a["id"]: a for a in aspects_list}
    if len(aspects) != len(aspects_list):
        raise SpecError("идентификаторы аспектов повторяются")
    used_products = []
    for a in aspects_list:
        for b in a["bestPractice"]["benchmarks"]:
            if b["productId"] not in used_products:
                used_products.append(b["productId"])
    for a in aspects_list:
        a.pop("_practiceLocator", None)
    step_ids = {s["id"] for s in steps}
    caps = [build_capability(c, aspects, step_ids) for c in spec.get("capabilities") or []]

    unmapped = [r["id"] for r in reqs if r["originalAssessment"]["applicable"]
                and not any(r["id"] in a["baseline"]["sourceRequirementIds"] for a in aspects_list)]
    if unmapped:
        raise SpecError("не привязаны к аспектам применимые пункты: " + ", ".join(unmapped))

    subject = dict(spec["subject"])
    subject.setdefault("baselineLabel", BASELINE_LABEL)
    ident(subject["id"], "subject.id")
    if subject.get("clientText") and subject["clientText"] not in (subject.get("focus") or subject["mission"]):
        raise SpecError("subject.clientText должен встречаться в focus (или в mission, если focus нет)")

    sources = [
        {"id": SOURCE_ID, "kind": "implementation_report", "title": "Основания оценки готовности (PKO progress)",
         "url": None, "fileName": report_path.name, "version": None, "asOf": generated},
        {"id": DECK_SOURCE_ID, "kind": "user_document",
         "title": f"Образ результата инициативы «{meta.get('project_name') or subject['name']}»",
         "url": None, "fileName": None, "version": spec.get("deckVersion"), "asOf": None},
    ]
    ref_evidence = []
    for pid in used_products:
        p = products[pid]
        sources.append({"id": f"src-{pid}", "kind": "official_product_document",
                        "title": f"{p['company']} · {p['name']}", "url": p["url"],
                        "fileName": None, "version": None, "asOf": None})
        ref_evidence.append({"id": f"REF-{pid}", "sourceId": f"src-{pid}", "sourceRequirementId": None,
                             "field": "reference", "quote": None, "locator": p["locator"]})

    digest = sha256(raw)
    code = spec["code"]
    dataset_id = ident(spec.get("datasetId") or f"{subject['id']}-r1", "datasetId")
    data = {
        "$schema": "CJ_Boom_Data_v4.schema.json",
        "schemaVersion": SCHEMA_VERSION,
        "application": APPLICATION,
        "subject": subject,
        "dataset": {
            "id": dataset_id, "revision": int(spec.get("revision") or 1), "asOf": generated or "1970-01-01",
            "sourceDatasetVersion": "pko-progress-model/0.3",
            "reviewScope": spec.get("reviewScope") or (
                f"Образ результата инициативы {code} ({len(reqs)} пунктов) и проверка кода PKO progress "
                f"по {total_applicable} применимым пунктам. Готовность взята из шкалы отчёта; "
                "самостоятельный аудит репозитория не выполнялся."),
            "provenance": {"baselineFile": report_path.name, "baselineSha256": digest,
                           "originalFile": report_path.name, "originalSha256": digest},
        },
        "journeySteps": steps,
        "sources": sources,
        "documents": [{"id": "doc-readiness", "sourceId": SOURCE_ID, "content": doc}],
        "sourceRequirements": reqs,
        "products": [{"id": pid, "company": products[pid]["company"], "name": products[pid]["name"],
                      "url": products[pid]["url"]} for pid in used_products],
        "evidence": evidence + scope_evidence + ref_evidence,
        "aspects": aspects_list,
        "capabilities": caps,
        "scoringPolicy": {
            "id": "cj-boom-equal-units", "version": "1.0.0",
            "plan": {"unit": "unique_functional_aspect",
                     "weights": {"covered": 1, "partial": 0.5, "not_covered": 0, "unknown": 0},
                     "unknown": "include_as_zero", "nfr": "exclude"},
            "implementation": {"unit": "unique_source_requirement", "weights": "equal",
                               "percent": "source_readiness", "na": "exclude", "nd": "include_as_zero"},
            "display": {"decimals": 0, "preventFalseComplete": True},
        },
        "codeReferences": codes,
        "comparisons": comparisons(aspects_list, reqs, impl_ev, codes),
        # Первый выпуск набора: предыдущей версии нет, поэтому «откуда» указывает
        # на сам исходный отчёт, а список изменений пуст.
        "migration": {"fromVersion": SCHEMA_VERSION, "fromDatasetId": f"{subject['id']}-r0",
                      "fromDatasetSha256": digest, "changes": []},
    }
    return data


def embed_json(data: dict[str, Any]) -> str:
    """JSON для `<script type=application/json>` — как в build.mjs исходного проекта."""
    text = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return (text.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
            .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))


# Экран «Инициативы» из оболочки убираем: внутри отчёта он повторял бы главный
# экран, но вшитым в поставку набором — то есть заведомо устаревшим. Оболочка
# это поддерживает сама: без элемента `cj-screen-tabs` она поднимается в
# одноэкранном режиме. На место вкладок встаёт возврат к списку инициатив.
SCREEN_TABS = re.compile(r'<nav id="cj-screen-tabs".*?</nav>', re.S)
INITIATIVES_PANEL = re.compile(r'<section id="initiatives-panel".*?</section>', re.S)
BACK_LINK = (
    '<a class="cj-back" href="../index.html" title="Вернуться к списку инициатив">'
    '<svg aria-hidden="true" viewBox="0 0 24 24"><path d="m15 6-6 6 6 6"></path></svg>'
    '<span>Инициативы</span></a>'
)
BACK_CSS = (
    # Раскладку экрана в оболочке задаёт правило `#page:has(#cj-screen-tabs)`;
    # вкладок больше нет, поэтому ту же сетку прописываем явно, иначе панель
    # инсайтов сжимается в ноль.
    "<style>#page{grid-template-rows:auto minmax(0,1fr)}"
    ".cj-back{display:inline-flex;align-items:center;gap:6px;font-size:.9375rem;"
    "font-weight:500;line-height:1.2;min-height:38px;padding:8px 11px;color:var(--muted);"
    "border-radius:9px;white-space:nowrap;text-decoration:none}"
    ".cj-back:hover{background:#ffffff55;color:var(--ink)}"
    ".cj-back:focus-visible{outline:2px solid var(--plan-fill);outline-offset:2px}"
    ".cj-back svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2;"
    "stroke-linecap:round;stroke-linejoin:round}</style>"
)

# Набор подаём тем же путём, что и внутренний автозапуск оболочки: `loadFile`
# с текстом скрипта. Скрипт данных стоит после кода приложения, поэтому её
# собственный автозапуск его не видит и загрузка не задваивается.
BOOTSTRAP = """<script>(function(){
var el=document.getElementById("initial-data");
var app=globalThis.__CJ_BOOM_APP__;
if(el&&app&&typeof app.loadFile==="function"){
var bytes=new TextEncoder().encode(el.textContent);
app.loadFile({size:bytes.byteLength,arrayBuffer:function(){return Promise.resolve(bytes.buffer);}});
}
// Возврат: если пришли со списка инициатив, отдаём его истории — так
// сохраняются раскрытия и прокрутка. Иначе идём по относительной ссылке.
var back=document.querySelector("a.cj-back");
if(back)back.addEventListener("click",function(e){
if(history.length>1&&document.referrer&&document.referrer.indexOf("index.html")>=0){
e.preventDefault();history.back();}
});
})();</script>
"""


# ── Не подключённый прототип схемы пути ─────────────────────────────────────
#
# Оценённая карта живёт в самостоятельном паспорте. Эти помощники оставлены
# как заготовка для возможного будущего подключения, но `render_html` и
# `main` их намеренно не вызывают: текущая поставка CJ Hack не содержит ни
# кнопки, ни слоя схемы.
#
# Данные схемы берутся из контракта PKO-дашборда (`passport.tree`): в набор
# viewer они не входят — схема v4.0.1 закрыта, и оболочка про паспорт не
# знает. Поэтому кнопка и слой добавляются в HTML оболочки, как ссылка
# «Инициативы». Отчёты без дерева (старые прогоны) получают CJ Hack без кнопки.
PASSPORT_BUTTON = (
    '<button type="button" class="cj-passport-btn" id="cj-passport-btn" '
    'title="Схема клиентского пути из паспорта инициативы">'
    '<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M12 3v6M6 15v-3h12v3M6 15v3M12 15v3M18 15v3"/>'
    '<rect x="9" y="3" width="6" height="4" rx="1"/><rect x="3" y="17" width="6" height="4" rx="1"/>'
    '<rect x="9" y="17" width="6" height="4" rx="1"/><rect x="15" y="17" width="6" height="4" rx="1"/></svg>'
    '<span>Схема пути</span></button>'
)

PASSPORT_CSS = (
    "<style>"
    ".cj-passport-btn{display:inline-flex;align-items:center;gap:6px;font-size:.9375rem;"
    "font-weight:500;line-height:1.2;min-height:38px;padding:8px 11px;color:var(--muted);"
    "border:0;background:none;border-radius:9px;white-space:nowrap;cursor:pointer;font-family:inherit}"
    ".cj-passport-btn:hover{background:#ffffff55;color:var(--ink)}"
    ".cj-passport-btn svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:1.8;"
    "stroke-linecap:round;stroke-linejoin:round}"
    "#pko-overlay{position:fixed;inset:0;z-index:10000;background:#fff;display:none;flex-direction:column;"
    "font-family:inherit;color:#000}"
    "#pko-overlay.open{display:flex}"
    ".pko-ov-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:12px 20px;"
    "border-bottom:1px solid #D0D7DD;flex:none}"
    ".pko-ov-head h2{margin:0;font-size:18px;font-weight:700;line-height:1.2;overflow-wrap:anywhere}"
    ".pko-ov-head .pko-ov-sub{font-size:12px;color:#92A2B0;margin-top:2px}"
    ".pko-ov-tools{display:flex;align-items:center;gap:10px;flex:none}"
    ".pko-ov-link{font-size:13px;color:#7C5CE6;text-decoration:none;border-bottom:1px dotted #7C5CE6}"
    ".pko-ov-close{width:32px;height:32px;border:1px solid #D0D7DD;border-radius:8px;background:#fff;"
    "cursor:pointer;font-size:18px;line-height:1;font-family:inherit}"
    ".pko-ov-body{flex:1;min-height:0;display:flex}"
    ".pko-ov-map{flex:1;min-width:0;display:flex;flex-direction:column}"
    ".pko-ov-card{width:min(380px,40vw);flex:none;border-left:1px solid #D0D7DD;overflow:auto;padding:18px 20px;"
    "display:none}"
    ".pko-ov-card.open{display:block}"
    ".pko-ov-card .t{display:inline-block;font-size:11px;font-weight:700;letter-spacing:.06em;color:#fff;"
    "background:#C17DF7;border-radius:6px;padding:2px 7px;margin-bottom:8px}"
    ".pko-ov-card[data-type=process] .t{background:#7C5CE6}.pko-ov-card[data-type=bbb] .t{background:#3D8BFD}"
    ".pko-ov-card[data-type=operation] .t{background:#2CB6B0}"
    ".pko-ov-card h3{margin:0 0 6px;font-size:17px;font-weight:700;line-height:1.25;overflow-wrap:anywhere}"
    ".pko-ov-card .id{font-size:12px;color:#92A2B0;margin-bottom:12px}"
    ".pko-ov-card .lbl{font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#92A2B0;margin:14px 0 4px}"
    ".pko-ov-card .basis{font-size:14px;line-height:1.45;color:#5A6D7C}"
    ".pko-ov-card .state{display:inline-flex;margin:0 0 10px;padding:4px 8px;border-radius:7px;"
    "font-size:12px;font-weight:700;background:#F0F2F2;color:#405160}"
    ".pko-ov-card .metric{font-size:13px;color:#405160;margin:-4px 0 8px}"
    ".pko-ov-card ul{margin:4px 0 0;padding-left:20px}.pko-ov-card li{margin:4px 0;font-size:13px;line-height:1.4}"
    ".pko-ov-card a{color:#7C5CE6;text-decoration:none;border-bottom:1px dotted #7C5CE6;cursor:pointer;font-size:13px}"
    "@media(max-width:700px){.pko-ov-body{flex-direction:column}.pko-ov-card{width:auto;border-left:0;border-top:1px solid #D0D7DD;max-height:45vh}}"
    + PASSPORT_MAP_CSS +
    "</style>"
)


def passport_overlay(
    nodes: list[dict[str, Any]], paths: list[dict[str, Any]], summary: dict[str, Any],
    title: str, passport_file: str | None, relations: list[dict[str, Any]] | None = None,
) -> str:
    """HTML слоя со схемой: заголовок, карта, карточка узла."""
    link = (f'<a class="pko-ov-link" href="{html_escape(passport_file)}" target="_blank" rel="noopener">'
            'Открыть полный паспорт</a>' if passport_file else "")
    assessment = summary.get("assessment") if isinstance(summary, dict) else {}
    assessment = assessment if isinstance(assessment, dict) else {}
    score = assessment.get("score")
    completeness = assessment.get("completeness")
    connectivity = assessment.get("connectivity")
    score_text = (
        f"Итог {score}% · полнота {completeness}% · связность "
        + (f"{connectivity}%" if connectivity is not None else "не измерена")
        if score is not None and completeness is not None else
        "Состояния узлов и стыков рассчитаны по материалам проверки"
    )
    return (
        '<div id="pko-overlay" role="dialog" aria-modal="true" aria-label="Схема клиентского пути">'
        '<div class="pko-ov-head"><div><h2>Схема пути · ' + html_escape(title) + '</h2>'
        '<div class="pko-ov-sub">' + html_escape(score_text) + '. Путь → процесс → BBB → операция; '
        'клик по узлу — статус и проблемы.</div></div>'
        '<div class="pko-ov-tools">' + link +
        '<button type="button" class="pko-ov-close" id="pko-ov-close" title="Закрыть">×</button></div></div>'
        '<div class="pko-ov-body"><div class="pko-ov-map"><div id="pko-ov-viewport"></div></div>'
        '<aside class="pko-ov-card" id="pko-ov-card"></aside></div></div>'
        '<script>' + PASSPORT_MAP_JS + '''
(function(){
var NODES=''' + nodes_json(nodes) + ''';
var PATHS=''' + nodes_json(paths) + ''';
var RELATIONS=''' + nodes_json(relations or []) + ''';
var TYPE_LABEL={journey:'Клиентский путь',process:'Автономный процесс',bbb:'Бизнес-блок',operation:'Атомарная операция'};
var btn=document.getElementById('cj-passport-btn'), ov=document.getElementById('pko-overlay');
var card=document.getElementById('pko-ov-card'), viewport=document.getElementById('pko-ov-viewport');
var map=null;
function esc(s){var d=document.createElement('div'); d.textContent=s==null?'':String(s); return d.innerHTML;}
function showCard(n,byId,relations){
  card.dataset.type=n.type;
  var html='<span class="t">'+esc(TYPE_LABEL[n.type]||n.type)+'</span><h3>'+esc(n.name)+'</h3><div class="id">'+esc(n.id)+'</div>';
  var d=n.data||{};
  if(d.implementation_label){html+='<div class="state">'+esc(d.implementation_label)+'</div>';}
  if(d.readiness!=null){html+='<div class="metric">Полнота узла: <b>'+esc(d.readiness)+'%</b></div>';}
  if(n.basis){html+='<div class="lbl">Почему отдельный объект</div><div class="basis">'+esc(n.basis)+'</div>';}
  if(Array.isArray(d.bullets)&&d.bullets.length){html+='<div class="lbl">Связанные пункты ОР</div><ul>'+d.bullets.map(function(b){return '<li><b>'+esc(b.status_label||b.status)+':</b> '+esc(b.text)+'</li>';}).join('')+'</ul>';}
  if(Array.isArray(d.problems)&&d.problems.length){html+='<div class="lbl">Проблемы</div><ul>'+d.problems.map(function(p){return '<li>'+esc(p)+'</li>';}).join('')+'</ul>';}
  function refs(label,ids){ if(!ids.length) return ''; return '<div class="lbl">'+label+'</div><div>'+ids.map(function(id){return '<a data-go="'+esc(id)+'">'+esc((byId[id]?byId[id].name:id))+'</a>';}).join(' · ')+'</div>'; }
  if(n.parents.length) html+=refs(n.parents.length>1?'Родители (общий узел)':'Родитель',n.parents);
  if(n.children.length) html+=refs('Дети',n.children);
  var rels=(relations||[]).filter(function(r){return r.from===n.id||r.to===n.id});
  if(rels.length){html+='<div class="lbl">Связи</div><ul>'+rels.map(function(r){return '<li>'+(r.from===n.id?esc(r.kind_label||r.kind)+' → <a data-go="'+esc(r.to)+'">'+esc(byId[r.to]?byId[r.to].name:r.to)+'</a>':'<a data-go="'+esc(r.from)+'">'+esc(byId[r.from]?byId[r.from].name:r.from)+'</a> '+esc(r.kind_label||r.kind)+' → этот узел')+'</li>';}).join('')+'</ul>';}
  card.innerHTML=html; card.classList.add('open');
  Array.prototype.forEach.call(card.querySelectorAll('a[data-go]'),function(a){a.addEventListener('click',function(){map.select(a.dataset.go)});});
}
function open(){ ov.classList.add('open'); if(!map){ map=window.pkoPassportMap(viewport,NODES,{paths:PATHS,relations:RELATIONS,onSelect:showCard}); } else { map.fit(); } }
function close(){ ov.classList.remove('open'); card.classList.remove('open'); if(map) map.clear(); }
if(btn) btn.addEventListener('click',open);
document.getElementById('pko-ov-close').addEventListener('click',close);
document.addEventListener('keydown',function(e){ if(e.key==='Escape'&&ov.classList.contains('open')) close(); });
})();
</script>'''
    )


def html_escape(text: str) -> str:
    return (str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def passport_of(report_path: Path) -> tuple[
    list[dict[str, Any]], list[dict[str, Any]], dict[str, Any], str, Path | None,
]:
    """Дерево паспорта из PKO-дашборда, название пути и файл полного паспорта
    рядом с отчётом, если он есть в поставке."""
    report = report_of(report_path.read_text(encoding="utf-8", errors="replace")) or {}
    passport = report.get("passport") or {}
    nodes = passport.get("tree") if isinstance(passport, dict) else None
    paths = passport.get("paths") if isinstance(passport, dict) else None
    summary = passport.get("summary") if isinstance(passport, dict) else None
    meta = report.get("meta") or {}
    title = str(meta.get("client_path_name") or meta.get("project_name") or "")
    candidates = [
        report_path.with_name(report_path.stem + "_passport.html"),
        report_path.with_name(report_path.stem + "_client_journey_passport.html"),
        report_path.with_name("client_journey_passport.html"),
    ]
    file = next((c for c in candidates if c.is_file()), None)
    return (
        nodes if isinstance(nodes, list) else [],
        paths if isinstance(paths, list) else [],
        summary if isinstance(summary, dict) else {},
        title,
        file,
    )


def render_html(data: dict[str, Any]) -> str:
    """Собрать CJ Hack без схемы паспорта.

    Оценённая карта выпускается самостоятельным паспортом. В CJ Hack её
    пока не встраиваем, чтобы независимо проверить методику и представление.
    """
    shell = (HERE / "vendor" / "viewer-shell.html").read_text(encoding="utf-8")
    back = BACK_LINK
    shell, tabs = SCREEN_TABS.subn(back, shell)
    shell, panel = INITIATIVES_PANEL.subn("", shell)
    if not tabs or not panel:
        raise SpecError("в оболочке viewer не найден экран инициатив — версия изменилась")
    head = shell.find("</head>")
    if head < 0:
        raise SpecError("в оболочке viewer нет закрывающего head")
    shell = shell[:head] + BACK_CSS + shell[head:]
    marker = "</body>"
    index = shell.rfind(marker)
    if index < 0:
        raise SpecError("в оболочке viewer нет закрывающего body")
    block = ('<script type="application/json" id="initial-data" data-example-kind="observed">'
             + embed_json(data) + "</script>\n" + BOOTSTRAP)
    return shell[:index] + block + shell[index:]


def validate(path: Path) -> dict[str, Any]:
    try:
        proc = subprocess.run(["node", str(HERE / "validate.mjs"), str(path)],
                              capture_output=True, text=True, encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return {"valid": False, "errors": [{"code": "NODE", "message": (
            "не найден node — валидатор набора данных написан на JS. "
            "Поставьте Node.js 20 и выше")}]}
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError:
        raw = (proc.stderr or proc.stdout)
        # Стек Node на полстраницы читателю ничего не говорит, а причина почти
        # всегда одна: в cjhack не ставили зависимости. Говорим это прямо.
        if "ERR_MODULE_NOT_FOUND" in raw or "Cannot find package" in raw:
            return {"valid": False, "errors": [{"code": "DEPS", "message": (
                "не установлены зависимости валидатора: выполните "
                "`npm install` в каталоге cjhack")}]}
        return {"valid": False, "errors": [{"code": "RUN", "message": raw[:800]}]}


def find_report(reports_dir: Path, spec: dict[str, Any]) -> Path:
    name = spec.get("report")
    if name:
        path = reports_dir / name
        if path.is_file():
            return path
    code = spec["code"].replace("/", "_").replace(" ", "")
    matches = sorted(p for p in reports_dir.glob("*.html") if p.name.startswith(code + "_"))
    if len(matches) != 1:
        raise SpecError(f"{spec['code']}: отчёт не найден или их несколько в {reports_dir}: {matches}")
    return matches[0]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--reports", required=True, help="Папка с PKO-дашбордами (Review_reports)")
    parser.add_argument("--projects", default=str(HERE / "projects"))
    parser.add_argument("--out", default=str(HERE / "out"))
    parser.add_argument("--only", default="", help="Код проекта, например АГ-40")
    args = parser.parse_args(argv)

    reports_dir = Path(args.reports)
    out_root = Path(args.out)
    specs = sorted(Path(args.projects).glob("*.json"))
    if args.only:
        specs = [p for p in specs if p.stem == args.only]
    if not specs:
        print("спецификаций не найдено", file=sys.stderr)
        return 1
    failures = 0
    built: list[str] = []
    failed: list[str] = []
    for spec_path in specs:
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
        code = spec["code"]
        try:
            report_path = find_report(reports_dir, spec)
            data = build_dataset(spec, report_path)
        except SpecError as exc:
            failures += 1
            failed.append(code)
            print(f"[{code}] ошибка спецификации: {exc}")
            continue
        # Папка на каждый исходный отчёт — по его имени: рядом лежат набор
        # данных, готовый CJ Hack и копия самого PKO-отчёта, из которого он
        # собран, чтобы папка была самодостаточной.
        # Имя папки — код инициативы: короткий, латиницей, уникальный. Длинные
        # имена из заголовка отчёта давали пути под 140 символов, а с корнем
        # распаковки такие пути упираются в ограничения файловых систем.
        name = slug(code)
        out_dir = out_root / name
        out_dir.mkdir(parents=True, exist_ok=True)
        json_path = out_dir / "cj-boom.json"
        json_path.write_text(json.dumps(data, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        result = validate(json_path)
        if not result.get("valid"):
            failures += 1
            failed.append(code)
            print(f"[{code}] набор не прошёл проверку ({result.get('errorCount')} ошибок):")
            for e in result.get("errors", [])[:12]:
                print("   ", e)
            continue
        html_path = out_dir / f"CJ_Hack_{name}.html"
        # Оценённая схема паспорта — отдельная функция и отдельный файл
        # основного PKO-прогона. В CJ Hack её пока не встраиваем.
        html_path.write_text(render_html(data), encoding="utf-8")
        shutil.copy2(report_path, out_dir / f"PKO_{name}.html")
        print(f"[{code}] покрытие ОР {result['coverage']}, готовность {result['readiness']} → {html_path}")
        built.append(code)
    # Итог отдельной строкой и в stderr: одна строка «ошибка спецификации»
    # среди сорока успешных терялась, инициатива молча выпадала из сборки, а
    # трекер потом просто не показывал её — и выглядело это как «CJ Hack
    # сломался», хотя сломалась одна спека.
    total = len(specs)
    if failures:
        print(f"\nсобрано {len(built)} из {total}, не собрано {failures}", file=sys.stderr)
        print("не собраны: " + ", ".join(failed), file=sys.stderr)
    else:
        print(f"\nсобрано {len(built)} из {total}, ошибок нет")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())

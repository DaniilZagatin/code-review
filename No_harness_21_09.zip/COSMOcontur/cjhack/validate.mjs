// Проверка набора данных CJ Hack тем же кодом, что и сам viewer:
// JSON Schema v4 (ajv) плюс семантические правила `validateDataset` из
// исходников CJ_Hack_Run6 (vendor/cj-boom-v4.js, скопирован без правок).
// Печатает JSON: {valid, errors, coverage, readiness}. Код выхода 1 при ошибках.
//
//   node validate.mjs out/АГ-40/cj-boom.json
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import Ajv2020 from 'ajv/dist/2020.js';
import addFormats from 'ajv-formats';
import {validateDataset, deriveDataset} from './vendor/cj-boom-v4.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const file = process.argv[2];
if (!file) {
  console.error('usage: node validate.mjs <cj-boom.json>');
  process.exit(2);
}
const schema = JSON.parse(fs.readFileSync(path.join(here, 'vendor/CJ_Boom_Data_v4.schema.json'), 'utf8'));
const ajv = new Ajv2020({strict: false, allErrors: true, validateFormats: true});
addFormats(ajv);
const schemaValidator = ajv.compile(schema);
const data = JSON.parse(fs.readFileSync(file, 'utf8'));
const result = validateDataset(data, schemaValidator);
const report = {valid: result.valid, errors: result.errors.slice(0, 40), errorCount: result.errors.length};
if (result.valid) {
  const derived = deriveDataset(data);
  report.coverage = derived.total.coverage.display;
  report.coveragePercent = derived.total.coverage.percent;
  report.readiness = derived.total.readiness.display;
  report.readinessPercent = derived.total.readiness.percent;
  report.stages = data.journeySteps.map((s) => ({
    id: s.id,
    coverage: derived.stages.get(s.id).coverage.display,
    readiness: derived.stages.get(s.id).readiness.display,
  }));
}
console.log(JSON.stringify(report, null, 1));
process.exit(result.valid ? 0 : 1);

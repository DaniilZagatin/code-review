// Поведение экрана «Инициативы»: поиск, фильтры, сводки по видимой выборке.
// Разметка и стили — из поставки viewer 0.7.3, её компонент не подключается
// (он требует ровно четыре булевых отметки и не умеет ни процентов, ни ссылок).
(function () {
  var root = document.querySelector('.ci-app');
  if (!root) return;

  var groups = root.querySelector('.ci-groups');
  var empty = root.querySelector('.ci-empty');
  var live = root.querySelector('.ci-live');
  var info = root.querySelector('.ci-filter-info');
  var infoText = info.querySelector('span');
  var footer = root.querySelector('.ci-footer');
  var panel = root.querySelector('.ci-filter-panel');
  var trigger = root.querySelector('.ci-filter-trigger');
  var dot = root.querySelector('.ci-filter-dot');
  var expand = root.querySelector('[data-action="expand"]');
  var expandLabel = expand.querySelector('span');
  var searchBox = root.querySelector('.ci-search');
  var searchTrigger = searchBox.querySelector('.ci-search-trigger');
  var editor = searchBox.querySelector('.ci-search-editor');
  var input = editor.querySelector('input');

  var rows = [].slice.call(root.querySelectorAll('tr.ci-item'));
  var paths = [].slice.call(root.querySelectorAll('details.ci-path'));
  var blocks = [].slice.call(root.querySelectorAll('details.ci-block'));
  var stageNames = [].slice.call(root.querySelectorAll('.ci-matrix-head > div')).slice(2, 4)
    .map(function (d) { return d.textContent.trim(); });

  var state = { q: '', block: 'all', stage: 'all', mark: 'all' };
  var restore = null;

  function plural(n, one, few, many) {
    var a = Math.abs(n) % 100, b = a % 10;
    if (a > 10 && a < 20) return many;
    if (b > 1 && b < 5) return few;
    return b === 1 ? one : many;
  }

  function filtered() {
    return state.q !== '' || state.block !== 'all' || state.stage !== 'all' || state.mark !== 'all';
  }

  function fits(r) {
    if (state.q && r.dataset.search.indexOf(state.q) < 0) return false;
    if (state.block !== 'all' && r.closest('details.ci-block').dataset.block !== state.block) return false;
    if (state.mark !== 'all') {
      var want = state.mark === 'confirmed';
      var marks = [r.dataset.m0 === '1', r.dataset.m1 === '1'];
      if (state.stage === 'all') {
        if (marks.indexOf(want) < 0) return false;
      } else if (marks[Number(state.stage)] !== want) return false;
    }
    return true;
  }

  function average(list, key) {
    var vals = [];
    list.forEach(function (r) { if (r.dataset[key] !== undefined) vals.push(Number(r.dataset[key])); });
    if (!vals.length) return null;
    var sum = 0;
    vals.forEach(function (v) { sum += v; });
    return Math.round(sum / vals.length);
  }

  function setSummary(sum, list) {
    var n = list.length;
    var q = sum.querySelector('.ci-quantity');
    if (q) {
      q.setAttribute('aria-label', n + ' ' + plural(n, 'инициатива', 'инициативы', 'инициатив'));
      q.lastElementChild.textContent = n;
    }
    [0, 1].forEach(function (i) {
      var cell = sum.querySelector('[data-sum="m' + i + '"]');
      if (!cell) return;
      var done = 0;
      list.forEach(function (r) { if (r.dataset['m' + i] === '1') done++; });
      var gap = n - done;
      cell.classList.toggle('is-empty', done === 0);
      cell.setAttribute('aria-label', cell.dataset.label + ': подтверждено ' + done + ', без отметки ' + gap);
      cell.querySelector('.ci-stage-value').innerHTML =
        done + (gap ? '<small class="ci-gap">ещё ' + gap + '</small>' : '');
    });
    [['cov', 'cov'], ['rdy', 'rdy']].forEach(function (pair) {
      var cell = sum.querySelector('[data-sum="' + pair[0] + '"]');
      if (!cell) return;
      var avg = average(list, pair[1]);
      var text = avg === null ? '—' : avg + '%';
      cell.classList.toggle('is-empty', avg === null);
      cell.setAttribute('aria-label', cell.dataset.label + (avg === null ? ': нет данных' : ': в среднем ' + text));
      cell.querySelector('.ci-stage-value').textContent = text;
    });
  }

  function describe(shown, total) {
    var parts = ['Показано ' + shown + ' из ' + total];
    if (state.q) parts.push('поиск «' + input.value.trim() + '»');
    if (state.block !== 'all') {
      var b = groups.querySelector('details.ci-block[data-block="' + state.block + '"]');
      if (b) parts.push('блок «' + b.querySelector('.ci-block-title').textContent + '»');
    }
    if (state.stage !== 'all') parts.push('этап «' + stageNames[Number(state.stage)] + '»');
    if (state.mark !== 'all') parts.push(state.mark === 'confirmed' ? 'есть отметка' : 'нет отметки');
    return parts.join(' · ');
  }

  function apply() {
    var visible = [];
    rows.forEach(function (r) {
      var ok = fits(r);
      r.hidden = !ok;
      if (ok) visible.push(r);
    });
    paths.forEach(function (p) {
      var list = [].slice.call(p.querySelectorAll('tr.ci-item')).filter(function (r) { return !r.hidden; });
      p.hidden = list.length === 0;
      setSummary(p.querySelector('summary'), list);
    });
    blocks.forEach(function (b) {
      var list = [].slice.call(b.querySelectorAll('tr.ci-item')).filter(function (r) { return !r.hidden; });
      b.hidden = list.length === 0;
      setSummary(b.querySelector('summary'), list);
    });
    setSummary(footer, visible);

    var on = filtered();
    if (on && restore === null) {
      restore = blocks.concat(paths).map(function (d) { return d.open; });
      blocks.concat(paths).forEach(function (d) { d.open = true; });
    } else if (!on && restore !== null) {
      blocks.concat(paths).forEach(function (d, i) { d.open = restore[i]; });
      restore = null;
    }

    empty.hidden = visible.length > 0;
    info.hidden = !on;
    if (on) infoText.textContent = describe(visible.length, rows.length);
    dot.hidden = state.block === 'all' && state.stage === 'all' && state.mark === 'all';
    live.textContent = visible.length + ' из ' + rows.length + ' инициатив';
  }

  function reset() {
    state = { q: '', block: 'all', stage: 'all', mark: 'all' };
    input.value = '';
    closeSearch();
    root.querySelectorAll('.ci-option').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.dataset.value === 'all'));
    });
    apply();
  }

  function openSearch() {
    searchTrigger.hidden = true;
    editor.hidden = false;
    searchTrigger.setAttribute('aria-expanded', 'true');
    input.focus();
    input.select();
  }

  function closeSearch() {
    editor.hidden = true;
    searchTrigger.hidden = false;
    searchTrigger.setAttribute('aria-expanded', 'false');
  }

  searchTrigger.addEventListener('click', openSearch);
  editor.querySelector('[data-action="close-search"]').addEventListener('click', function () {
    input.value = '';
    state.q = '';
    closeSearch();
    apply();
  });
  input.addEventListener('input', function () {
    state.q = input.value.trim().toLowerCase().split('ё').join('е');
    apply();
  });
  input.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      input.value = '';
      state.q = '';
      closeSearch();
      apply();
    }
  });
  document.addEventListener('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K' || e.key === 'л' || e.key === 'Л')) {
      e.preventDefault();
      openSearch();
    }
  });

  trigger.addEventListener('click', function () {
    var open = panel.hidden;
    panel.hidden = !open;
    trigger.setAttribute('aria-expanded', String(open));
  });
  panel.querySelector('[data-action="close-filters"]').addEventListener('click', function () {
    panel.hidden = true;
    trigger.setAttribute('aria-expanded', 'false');
  });
  root.addEventListener('click', function (e) {
    var option = e.target.closest('.ci-option');
    if (option) {
      var kind = option.dataset.filter;
      state[kind] = option.dataset.value;
      panel.querySelectorAll('.ci-option[data-filter="' + kind + '"]').forEach(function (b) {
        b.setAttribute('aria-pressed', String(b === option));
      });
      apply();
      return;
    }
    if (e.target.closest('[data-action="reset"]')) reset();
  });

  expand.addEventListener('click', function () {
    var open = expandLabel.textContent.indexOf('Показать') === 0;
    blocks.concat(paths).forEach(function (d) { d.open = open; });
    expandLabel.textContent = open ? 'Свернуть пути' : 'Показать пути';
    if (restore !== null) restore = blocks.concat(paths).map(function (d) { return d.open; });
  });

  groups.addEventListener('click', function (e) {
    var row = e.target.closest('tr.ci-item');
    if (!row || !row.dataset.href) return;
    if (e.target.closest('a')) return;
    window.location.href = row.dataset.href;
  });

  apply();
})();

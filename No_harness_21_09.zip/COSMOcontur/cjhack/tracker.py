"""Экран «Инициативы» из поставки viewer 0.7.3 — с нашими колонками результата.

Визуал, стили и реестр инициатив взяты из `@cj-boom/viewer` 0.7.3
(`vendor/viewer.css`, `vendor/initiatives-source.json`): это тот же экран, что
открывается во вкладке «Инициативы» внутри поставки.

Почему не его компонент, а своя сборка той же вёрстки: компонент принимает
ровно четыре булевых отметки на инициативу, не умеет ни процентов, ни ссылок —
поэтому убрать «ОС» и добавить два числа результата через его данные нельзя.
Разметка, классы и стили повторены один в один; поиск, фильтры и пустое
состояние — его же, поведение написано заново.

Что на экране:

* «Доступ предоставлен» и «Код проверен» — отметки из реестра поставки;
* «Соответствие ОР лучшим практикам» и «Готовность ОР» — два числа из CJ Hack
  по этой инициативе; их отдаёт валидатор viewer, здесь они не считаются;
* клик по строке открывает CJ Hack инициативы (вкладку «Инсайты»), оттуда
  ссылка «Инициативы» возвращает сюда;
* поиск (⌘K) и фильтры по блоку, этапу и отметке; сводки блока, пути и
  «Итого» считаются по видимой выборке.

    python cjhack/build.py --reports <папка с отчётами>   # сначала отчёты
    python cjhack/tracker.py                              # потом экран
"""

from __future__ import annotations

import argparse
import html
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any
from urllib.parse import quote

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / "backend"))

from build import slug  # noqa: E402  — одно правило именования на сборку и экран

ICON = {
    "search": '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
    "check": '<path d="m5 12 4 4L19 6"/>',
    "minus": '<path d="M7 12h10"/>',
    "filter": '<path d="M4 7h16M7 12h10M10 17h4"/>',
    "close": '<path d="m6 6 12 12M6 18 18 6"/>',
    "eye": '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/>',
    "expand": '<path d="m8 4 4 4 4-4M8 10l4 4 4-4M8 16l4 4 4-4"/>',
}
COLUMNS = ("Соответствие ОР лучшим практикам", "Готовность ОР")
SHORT = ("Соответствие ОР", "Готовность ОР")

# Числа результата рисуются в языке самого экрана: то же место и размер, что у
# чисел этапов. Добавлены только цвет решения и приглушённый прочерк.
EXTRA_CSS = """
.ci-metric{font-weight:600;font-size:15px;line-height:1;color:#146a26;font-variant-numeric:tabular-nums}
.ci-metric.is-pivot{color:#b03a2e}
.ci-metric.is-plan{color:#2f6f3e}
.ci-metric.is-none{color:#b3b7bd;font-weight:400}
.ci-metric-cell{text-align:center}
a.ci-name-button{text-decoration:none;color:inherit;width:100%;cursor:pointer}
tr.ci-item[data-href]{cursor:pointer}
tr.ci-item[data-href]:hover{background:rgba(33,160,56,.06)}
tr.ci-item[data-href]:focus-within{background:rgba(33,160,56,.09)}
/* Строка без отчёта никуда не ведёт — и не должна выглядеть кликабельной:
   курсор в поставке задан на кнопке имени, поэтому перебиваем явно. */
tr.ci-item:not([data-href]),
tr.ci-item:not([data-href]) .ci-name-button,
tr.ci-item:not([data-href]) .ci-chevron{cursor:default}
tr.ci-item:not([data-href]) .ci-name{color:#7a7f87}
tr.ci-item:not([data-href]) .ci-chevron{opacity:.35}
.ci-docs{display:block;margin-top:3px;font-size:11.5px;font-weight:400;color:#7a7f87}
.ci-docs b{font-weight:600;color:#5f646b}
"""


def icon(name: str) -> str:
    return f'<svg aria-hidden="true" viewBox="0 0 24 24">{ICON[name]}</svg>'


def esc(text: Any) -> str:
    return html.escape(str(text or ""), quote=True)


def plural(n: int, one: str, few: str, many: str) -> str:
    a, b = abs(n) % 100, abs(n) % 10
    if 10 < a < 20:
        return many
    if 1 < b < 5:
        return few
    return one if b == 1 else many


def norm(code: str) -> str:
    """«АГ-74 / АГ-75» → «АГ-74_75»: как называются наши спецификации."""
    parts = [p.strip() for p in code.split("/") if p.strip()]
    if not parts:
        return ""
    head, tail = parts[0], [re.sub(r"^АГ-", "", p) for p in parts[1:]]
    return "_".join([head, *tail])


def numbers(dataset: Path) -> dict[str, int]:
    """Покрытие и готовность — от валидатора viewer, без собственного счёта."""
    proc = subprocess.run(["node", str(HERE / "validate.mjs"), str(dataset)],
                          capture_output=True, text=True, encoding="utf-8", errors="replace")
    try:
        result = json.loads(proc.stdout)
    except json.JSONDecodeError:
        raise SystemExit(f"{dataset}: валидатор не ответил JSON:\n{proc.stdout}\n{proc.stderr}")
    if not result.get("valid"):
        raise SystemExit(f"{dataset}: набор не проходит проверку, сначала пересобери отчёты")
    # Берём готовые строки валидатора («13%»), а не округляем сами: у него
    # половина идёт вверх, у Python — к чётному, и 12,5% разошлись бы с экраном.
    return {"coverage": int(str(result["coverage"]).rstrip("%")),
            "readiness": int(str(result["readiness"]).rstrip("%"))}


def collect(out_root: Path, projects: Path,
            unbuilt: list[str] | None = None) -> dict[str, dict[str, Any]]:
    """Код инициативы → числа результата, решение и адрес CJ Hack.

    Спецификация есть, а собранной папки нет — это **не** «инициативу не
    проверяли», а «сборка по ней упала». Разница принципиальная: в первом
    случае строка законно остаётся без ссылки, во втором страница молча теряет
    инициативу, и выглядит это как «CJ Hack сломался». Такие коды копятся в
    `unbuilt`, и вызывающий обязан на них среагировать.
    """
    from pko.web.collect import report_of

    found: dict[str, dict[str, Any]] = {}
    for spec_path in sorted(projects.glob("*.json")):
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
        code, stem = spec["code"], slug(spec["code"])
        folder = out_root / stem
        cj, pko, data = (folder / f"CJ_Hack_{stem}.html", folder / f"PKO_{stem}.html",
                         folder / "cj-boom.json")
        if not (cj.exists() and pko.exists() and data.exists()):
            print(f"[{code}] нет собранного отчёта в {folder} — пропускаю")
            if unbuilt is not None:
                unbuilt.append(code)
            continue
        report = report_of(pko.read_text(encoding="utf-8"))
        meta, summary = report.get("meta") or {}, report.get("summary") or {}
        found[code] = {
            **numbers(data),
            "decision": str(summary.get("decision") or meta.get("decision") or ""),
            "generated_at": str(meta.get("generated_at") or ""),
            "href": f"{quote(stem)}/{quote(cj.name)}",
        }
    return found


def mark_cell(label: str, short: str, code: str, confirmed: bool) -> str:
    state = "подтверждено" if confirmed else "нет отметки"
    word = "Подтверждено" if confirmed else "Нет отметки"
    mark = "" if confirmed else "ci-status-unknown"
    return (f'<td class="ci-status-cell" data-label="{esc(short)}">'
            f'<span class="ci-status" aria-label="{esc(code)}. {esc(label)}: {state}" '
            f'title="{esc(label)}: {state}">'
            f'<span class="ci-status-mark {mark}">{icon("check") if confirmed else icon("minus")}</span>'
            f'<span class="ci-status-word" aria-hidden="true">{word}</span></span></td>')


def metric_cell(short: str, value: int | None, kind: str, title: str) -> str:
    inner = (f'<span class="ci-metric is-none" title="{esc(title)}">—</span>' if value is None
             else f'<span class="ci-metric {kind}" title="{esc(title)}">{value}%</span>')
    return f'<td class="ci-status-cell ci-metric-cell" data-label="{esc(short)}">{inner}</td>'


def count_cell(key: str, label: str, short: str, done: int, total: int) -> str:
    gap = total - done
    empty = " is-empty" if not done else ""
    tail = f'<small class="ci-gap">ещё {gap}</small>' if gap else ""
    return (f'<span class="ci-summary-count{empty}" data-sum="{key}" '
            f'data-label="{esc(label)}" '
            f'aria-label="{esc(label)}: подтверждено {done}, без отметки {gap}">'
            f'<span class="ci-mobile-stage" aria-hidden="true">{esc(short)}</span>'
            f'<span class="ci-stage-value" aria-hidden="true">{done}{tail}</span></span>')


def metric_summary(key: str, short: str, values: list[int]) -> str:
    empty = "" if values else " is-empty"
    text = f"{round(sum(values) / len(values))}%" if values else "—"
    label = f"{short}: в среднем {text}" if values else f"{short}: нет данных"
    return (f'<span class="ci-summary-count{empty}" data-sum="{key}" data-label="{esc(short)}" '
            f'aria-label="{esc(label)}">'
            f'<span class="ci-mobile-stage" aria-hidden="true">{esc(short)}</span>'
            f'<span class="ci-stage-value" aria-hidden="true">{text}</span></span>')


def quantity(n: int) -> str:
    return (f'<span class="ci-quantity" aria-label="{n} {plural(n, "инициатива", "инициативы", "инициатив")}">'
            f'<span class="ci-mobile-stage" aria-hidden="true">Инициатив</span>'
            f'<span aria-hidden="true">{n}</span></span>')


def totals(items: list[dict[str, Any]], stages: list[str]) -> str:
    """Шесть ячеек сводки: количество, две отметки, два средних."""
    n = len(items)
    cells = [quantity(n)]
    for i, (label, short) in enumerate(zip(stages, ("Доступ", "Код"))):
        cells.append(count_cell(f"m{i}", label, short, sum(1 for it in items if it["marks"][i]), n))
    cells.append(metric_summary("cov", SHORT[0], [it["coverage"] for it in items if it["coverage"] is not None]))
    cells.append(metric_summary("rdy", SHORT[1], [it["readiness"] for it in items if it["readiness"] is not None]))
    return "".join(cells)


def row(item: dict[str, Any], stages: list[str], path_name: str, block_name: str) -> str:
    code = item["code"]
    docs = esc(item.get("docs_text") or "") or " · ".join(
        f'<b>{esc(d["label"])}</b> {esc(d["value"])}' + (f' {esc(d["detail"])}' if d.get("detail") else "")
        for d in item.get("documents") or []
    )
    name = (f'<span class="ci-name">{esc(item["name"])} <span class="ci-code">{esc(code)}</span>'
            + (f'<span class="ci-docs">{docs}</span>' if docs else "") + "</span>")
    head = (f'<a class="ci-name-button" href="{item["href"]}" '
            f'title="Открыть CJ Hack: {esc(item["name"])}">'
            f'<i class="ci-chevron" aria-hidden="true"></i>{name}</a>'
            ) if item.get("href") else (
        '<span class="ci-name-button" '
        'title="Проверка кода по инициативе не проводилась — открывать нечего">'
        f'{name}</span>')

    if item["coverage"] is None:
        note = "Проверка кода по инициативе не проводилась"
        cov, rdy = metric_cell(SHORT[0], None, "", note), metric_cell(SHORT[1], None, "", note)
        data = ""
    else:
        when = f' · отчёт от {item["generated_at"]}' if item.get("generated_at") else ""
        hint = f' · {item["hint"]}' if item.get("hint") else ""
        # По одной инициативе доля лучшей практики не говорит ничего: практика
        # описана для процесса целиком, и часть её к отдельной инициативе просто
        # не относится. Поэтому в строке инициативы число не печатается — оно
        # остаётся в data-атрибуте и складывается в среднее по пути, блоку и
        # «Итого», где и имеет смысл.
        cov = metric_cell(SHORT[0], None, "",
                          f'{COLUMNS[0]} считается по процессу целиком — '
                          f'смотрите строку пути и блока')
        kind = "is-pivot" if item.get("decision") == "PIVOT" else ""
        rdy = metric_cell(SHORT[1], item["readiness"], kind,
                          f'{COLUMNS[1]}: {item["readiness"]}%'
                          + (f' · решение {item["decision"]}' if item.get("decision") else "")
                          + when + hint)
        data = f' data-cov="{item["coverage"]}" data-rdy="{item["readiness"]}"'

    search = " ".join([code, item["name"], re.sub(r"<[^>]+>", " ", docs), path_name, block_name])
    search = esc(" ".join(search.lower().replace("ё", "е").split()))
    href = f' data-href="{item["href"]}"' if item.get("href") else ""
    return (f'<tr class="ci-item" data-item="{esc(item["id"])}"{href}{data}'
            f' data-m0="{int(item["marks"][0])}" data-m1="{int(item["marks"][1])}"'
            f' data-search="{search}">'
            f'<th scope="row" class="ci-item-head">{head}</th>'
            f'<td class="ci-item-quantity"><span class="sr-only">1 инициатива</span></td>'
            + mark_cell(stages[0], "Доступ", code, item["marks"][0])
            + mark_cell(stages[1], "Код", code, item["marks"][1])
            + cov + rdy + "</tr>")


def assemble(register: dict[str, Any], data: dict[str, dict[str, Any]],
             extras: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[str]]:
    """Реестр поставки + наши числа + строки вне реестра → блоки для разметки."""
    missing: list[str] = []
    blocks: list[dict[str, Any]] = []
    for block in register["blocks"]:
        paths = []
        for path in block["paths"]:
            items = []
            for it in path["items"]:
                entry = data.get(norm(it["code"]))
                if entry is None:
                    missing.append(it["code"])
                items.append({
                    "id": it["id"], "code": it["code"], "name": it["name"],
                    "documents": it.get("documents") or [],
                    "marks": [bool(m["confirmed"]) for m in it["marks"]][:2],
                    "coverage": entry["coverage"] if entry else None,
                    "readiness": entry["readiness"] if entry else None,
                    "decision": entry["decision"] if entry else "",
                    "generated_at": entry["generated_at"] if entry else "",
                    "href": entry["href"] if entry else "",
                })
            paths.append({"id": path["id"], "name": path["name"], "items": items})
        blocks.append({"id": block["id"], "name": block["name"], "paths": paths})

    for extra in extras:
        marks = [bool(m) for m in (extra.get("marks") or [False, False])][:2]
        item = {
            "id": "extra-" + re.sub(r"\W+", "-", extra["name"]).lower(),
            "code": extra.get("code") or "—", "name": extra["name"],
            "documents": [], "docs_text": extra.get("sub") or "", "marks": marks,
            "coverage": extra["coverage"], "readiness": extra["readiness"],
            "decision": "", "generated_at": "", "href": extra["href"],
            "hint": extra.get("note") or "",
        }
        block = next((b for b in blocks if b["name"] == extra["block"]), None)
        if block is None:
            block = {"id": "extra-block", "name": extra["block"], "paths": []}
            blocks.append(block)
        path = next((p for p in block["paths"] if p["name"] == extra["path"]), None)
        if path is None:
            path = {"id": "extra-path", "name": extra["path"], "items": []}
            block["paths"].append(path)
        path["items"].append(item)
    return blocks, missing


def groups_html(blocks: list[dict[str, Any]], stages: list[str]) -> str:
    head = "".join(f'<th scope="col">{esc(t)}</th>' for t in
                   ["Инициатива", "Инициатив", stages[0], stages[1], *COLUMNS])
    out: list[str] = []
    for block in blocks:
        items = [it for p in block["paths"] for it in p["items"]]
        out.append(f'<details class="ci-block" data-block="{esc(block["id"])}">'
                   f'<summary class="ci-summary"><div class="ci-summary-main">'
                   f'<i class="ci-chevron" aria-hidden="true"></i>'
                   f'<span class="ci-block-title">{esc(block["name"])}</span></div>'
                   f'{totals(items, stages)}</summary><div class="ci-paths">')
        for path in block["paths"]:
            rows = "".join(row(it, stages, path["name"], block["name"]) for it in path["items"])
            out.append(
                f'<details class="ci-path" data-path="{esc(path["id"])}" '
                f'data-block-id="{esc(block["id"])}"><summary class="ci-summary">'
                f'<div class="ci-summary-main"><i class="ci-chevron" aria-hidden="true"></i>'
                f'<span class="ci-path-title">{esc(path["name"])}</span></div>'
                f'{totals(path["items"], stages)}</summary>'
                f'<div class="ci-table-wrap"><table class="ci-table">'
                f'<caption>{esc(block["name"])}: {esc(path["name"])}</caption>'
                f'<colgroup><col><col><col><col><col><col></colgroup>'
                f'<thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table></div></details>'
            )
        out.append("</div></details>")
    return "".join(out)


def option(kind: str, value: str, label: str, pressed: bool = False) -> str:
    return (f'<button class="ci-option" type="button" data-filter="{kind}" data-value="{esc(value)}" '
            f'aria-pressed="{str(pressed).lower()}">{esc(label)}</button>')


def render(register: dict[str, Any], data: dict[str, dict[str, Any]],
           extras: list[dict[str, Any]], css: str, script: str) -> tuple[str, list[str]]:
    stages = list(register["stages"])[:2]
    blocks, missing = assemble(register, data, extras)
    items = [it for b in blocks for p in b["paths"] for it in p["items"]]

    search = (
        '<div class="ci-search-slot"><div class="ci-search">'
        '<button class="ci-search-trigger" type="button" aria-label="Поиск по инициативам" '
        f'aria-expanded="false">{icon("search")}<span>Поиск по инициативам</span>'
        '<kbd>⌘K</kbd></button>'
        f'<div class="ci-search-editor" hidden>{icon("search")}'
        '<input type="search" aria-label="Поиск по инициативам" placeholder="Код, инициатива, путь…" '
        'autocomplete="off" spellcheck="false">'
        '<button type="button" data-action="close-search">Отмена</button></div></div></div>'
    )
    stage_options = "".join(option("stage", str(i), s) for i, s in enumerate(stages))
    block_options = "".join(option("block", b["id"], b["name"]) for b in blocks)
    filters = (
        '<section class="ci-filter-panel ci-glass" id="ci-filters" aria-label="Фильтры инициатив" hidden>'
        f'<div class="ci-panel-title">Фильтры<button class="ci-icon-button" type="button" '
        f'data-action="close-filters" aria-label="Закрыть фильтры">{icon("close")}</button></div>'
        '<fieldset><legend>Блок</legend><div class="ci-options">'
        + option("block", "all", "Все блоки", True) + block_options + '</div></fieldset>'
        '<fieldset><legend>Этап</legend><div class="ci-options">'
        + option("stage", "all", "Любой этап", True) + stage_options + '</div></fieldset>'
        '<fieldset><legend>Отметка выбранного этапа</legend><div class="ci-options">'
        + option("mark", "all", "Любая", True)
        + option("mark", "confirmed", "Есть отметка")
        + option("mark", "unmarked", "Нет отметки")
        + '</div></fieldset>'
        '<button class="ci-panel-reset" type="button" data-action="reset">Сбросить фильтры</button></section>'
    )
    head_cells = "".join([
        "<div>Инициативы и этапы</div>",
        "<div><strong>Инициатив</strong></div>",
        "<div><strong>Доступ</strong><span>предоставлен</span></div>",
        "<div><strong>Код</strong><span>проверен</span></div>",
        "<div><strong>Соответствие ОР</strong><span>лучшим практикам</span></div>",
        "<div><strong>Готовность</strong><span>ОР</span></div>",
    ])
    body = f"""<section class="ci-app">
<header class="ci-topbar"><div class="ci-brand"><small>CJ HACK</small><h1>Инициативы</h1></div>{search}</header>
<div class="ci-context"><div class="ci-context-main"><strong>{esc(register.get("context") or "Первая волна демо")}</strong><span class="ci-view-mode">{icon("eye")}Только просмотр</span></div></div>
<main class="ci-surface" aria-label="Блоки, пути и инициативы">
<div class="ci-toolbar"><h2 class="ci-location">Блоки и пути</h2><div class="ci-actions">
<button class="ci-text-button" type="button" data-action="expand" aria-label="Показать пути">{icon("expand")}<span>Показать пути</span></button>
<button class="ci-text-button ci-filter-trigger" type="button" data-action="filters" aria-expanded="false" aria-controls="ci-filters" aria-label="Фильтры">{icon("filter")}<span>Фильтры</span><i class="ci-filter-dot" hidden></i></button>
</div>{filters}</div>
<div class="ci-filter-info" hidden><span></span><button type="button" data-action="reset">Сбросить</button></div>
<div class="ci-matrix-head" aria-hidden="true">{head_cells}</div>
<div class="ci-scroll" tabindex="0" aria-label="Список инициатив"><div class="ci-groups">{groups_html(blocks, stages)}</div>
<div class="ci-empty" hidden><strong>Нет подходящих инициатив</strong><p>Попробуйте другой блок или этап.</p><button type="button" data-action="reset">Сбросить фильтры</button></div></div>
<footer class="ci-footer" aria-label="Итоги по текущей выборке"><strong class="ci-total-label">Итого</strong>{totals(items, stages)}</footer>
<p class="sr-only ci-live" aria-live="polite"></p>
</main></section>"""
    page = ('<!DOCTYPE html>\n<html lang="ru"><head><meta charset="utf-8">\n'
            '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
            "<title>CJ Hack · Инициативы</title>\n<style>" + css + EXTRA_CSS + "</style>\n"
            "</head><body>\n" + body + "\n<script>" + script + "</script>\n</body></html>\n")
    return page, missing


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--register", default=str(HERE / "vendor" / "initiatives-source.json"))
    parser.add_argument("--css", default=str(HERE / "vendor" / "viewer.css"))
    parser.add_argument("--script", default=str(HERE / "tracker.js"))
    parser.add_argument("--out", default=str(HERE / "out" / "index.html"))
    parser.add_argument("--projects", default=str(HERE / "projects"))
    parser.add_argument("--extras", default=str(HERE / "tracker-extras.json"))
    args = parser.parse_args()

    out_path = Path(args.out)
    unbuilt: list[str] = []
    data = collect(out_path.parent, Path(args.projects), unbuilt)
    if not data:
        print("отчётов не найдено: сначала python cjhack/build.py --reports <папка>", file=sys.stderr)
        return 1

    extras: list[dict[str, Any]] = []
    config = Path(args.extras)
    if config.exists():
        for extra in json.loads(config.read_text(encoding="utf-8")):
            folder = out_path.parent / extra["folder"]
            if not (folder / extra["file"]).exists() or not (folder / "cj-boom.json").exists():
                print(f"[{extra['name']}] нет файлов в {folder} — строка пропущена")
                continue
            extras.append({**extra, **numbers(folder / "cj-boom.json"),
                           "href": f'{quote(extra["folder"])}/{quote(extra["file"])}'})

    register = json.loads(Path(args.register).read_text(encoding="utf-8"))
    page, missing = render(register, data, extras,
                           Path(args.css).read_text(encoding="utf-8"),
                           Path(args.script).read_text(encoding="utf-8"))
    out_path.write_text(page, encoding="utf-8")

    codes = {norm(it["code"]) for b in register["blocks"] for p in b["paths"] for it in p["items"]}
    print(f"экран инициатив: строк {len(codes) + len(extras)}, из них с отчётом {len(codes & set(data))}")
    if missing:
        print("без отчёта:", ", ".join(dict.fromkeys(missing)))
    unused = sorted(set(data) - codes)
    if unused:
        print("отчёты вне реестра:", ", ".join(unused))
    print("→", out_path)
    # У этих инициатив спецификация есть, а собранной папки нет: страница
    # выйдет без них и об этом никто не узнает, если не сказать громко.
    if unbuilt:
        print(f"\nспецификация есть, сборки нет: {', '.join(unbuilt)}", file=sys.stderr)
        print("страница собрана без них — сначала почините сборку "
              "(python cjhack/build.py --reports <папка> --only <код>)", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Оптимизации сокращают обмен с моделью, сохраняя гейты и готовый паспорт."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import replace
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import httpx
import openai

from agent_script import risk_review
from fixture_support import make_openai_response, scripted_responses
from pko.errors import LlmError
from pko.llm.client import ChatClient
from pko.monitoring import monitored_cli_run
from pko.progress import passport_agent as agent
from test_passport_gate import SPEC, _happy_script, _shared_script, _tool_call


def call(state, name, **args):
    return agent._answer_call(state, _tool_call(name, **args)["tool_calls"][0])["content"]


def tree():
    state = agent._PassportSession(compact_replies=True, known_paths={"app.py"})
    root = state.new_id("journey")
    state.nodes[root] = agent._Node(root, "Размещение сбережений", "Образ результата")
    state.queue.append(root)
    agent._advance(state)
    for response in _happy_script()[:10]:
        for item in response["tool_calls"]:
            agent._answer_call(state, item)
    assert state.tree_done
    return state


def relation(source="bbb-1", target="bbb-2", kind="triggers"):
    return {"from": source, "to": target, "kind": kind,
            "basis": "вызов после успешного шага в graph.py"}


def defect(**changes):
    return {"title": "Анализ трат отключён: доли считаются по нулевым тратам",
            "kind": "data", "nodes": ["bbb-2"], "where": "app.py:3",
            "blocking": True, **changes}


def risk():
    return {
        "title": "Повторное применение расчёта после потери ответа",
        "problem": "Если ответ теряется после расчёта долей, повторный запуск может изменить уже рассчитанный портфель и дать клиенту противоречивое предложение",
        "scope": "local", "primary_node": "operation-2", "linked_nodes": ["operation-2"],
        "trigger": "Вызывающая сторона не получает ответ после изменения долей",
        "cause": "После потери ответа вызывающая сторона может повторить уже выполненный расчёт",
        "mechanism": "Повторный вызов применяет изменение долей к уже изменённому портфелю",
        "negative_event": "Одна клиентская операция повторно изменяет рассчитанные доли портфеля",
        "consequences": ["Клиент получает предложение с противоречивым составом и может выбрать неподходящее размещение средств"],
        "existing_controls": [], "guardrails": [],
        "control_gap": "Идемпотентность повторного запуска в проанализированном контуре не подтверждена",
        "recommendation": "Связать повтор с результатом исходного расчёта по ключу операции",
        "closure_criterion": "При потере ответа повтор возвращает прежний результат без изменения долей",
        "evidence": [{"where": "app.py:3", "basis": "вызывающая сторона повторяет расчёт после ошибки ответа"}],
        "confidence": "inferred", "confidence_note": "Механизм повтора виден, фактический двойной эффект напрямую не показан",
        "confirmation_needed": "",
    }


class PassportOptimizationTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.env = patch.dict(os.environ, {
            "PKO_PASSPORT_MAX_SECONDS": "0", "PKO_PASSPORT_MAX_STEPS": "128",
            "PKO_PASSPORT_THINKING": "inherit", "PKO_PASSPORT_FIELDS_THINKING": "inherit",
            "PKO_MONITOR_DIR": self.tmp.name,
        })
        self.env.start()
        self.addCleanup(self.env.stop)

    def run_script(self, script, *, seen=None, **kwargs):
        scripted = scripted_responses(*script)
        def capture(client, payload, extra_body=None):
            if seen is not None:
                seen.append(deepcopy((payload, extra_body)))
            return scripted(client, payload, extra_body=extra_body)
        client = ChatClient(spec=SPEC, use_cache=False)
        self.addCleanup(client._client.close)
        with patch.object(ChatClient, "_create", capture):
            return agent.run_passport_agent([], {"project_name": "Демо"}, [], None, SPEC,
                client=client, knowledge=["[read_file app.py:1-40 — def select()]"], **kwargs)

    def test_batches_match_single_calls_and_keep_valid_items_on_error(self):
        single, batch = tree(), tree()
        for state in (single, batch):
            self.assertFalse(state.relations)
        call(single, "link_nodes", **relation())
        reply = call(batch, "link_nodes_batch", relations=[relation(), relation(target="bbb-999")])
        self.assertIn("[1] связь отклонена", reply)
        self.assertEqual(single.relations, batch.relations)
        call(single, "submit_defect", **defect())
        reply = call(batch, "submit_defects", defects=[defect(), defect(nodes=["bbb-999"])])
        self.assertIn("[1] дефект отклонён", reply)
        self.assertEqual(single.defects, batch.defects)
        self.assertIn("уже принят", call(batch, "link_nodes_batch", relations=[relation()]))
        self.assertIn("уже принят", call(batch, "submit_defects", defects=[defect()]))
        self.assertEqual(len(batch.defects), 1)
        self.assertEqual(len(batch.relations), 1)

    def test_batch_gate_rejects_unknown_kinds_tree_edges_and_large_batches(self):
        state = tree()
        for item in (relation(kind="invented"), relation(source="journey-1"),
                     relation(source="process-1", target="bbb-1", kind="includes")):
            self.assertIn("отклонена", call(state, "link_nodes_batch", relations=[item]))
        self.assertIn("пакет отклонён", call(state, "link_nodes_batch", relations=[relation()] * 17))
        self.assertFalse(state.relations)

    def test_includes_cannot_turn_existing_trigger_into_self_trigger(self):
        state = tree()
        state.nodes["process-2"] = agent._Node("process-2", "Второй процесс", "Другой сценарий", filled=True)
        self.assertIn("связь принята", call(state, "link_nodes", **relation(target="process-2")))
        reply = call(state, "link_nodes_batch", relations=[relation("process-2", "bbb-1", "includes")])
        self.assertIn("отклонена", reply)
        self.assertEqual(state.nodes["bbb-1"].parents, ["process-1"])

    def test_partial_node_edit_preserves_sources_other_fields_and_rejects_stale_version(self):
        state = tree()
        before = deepcopy(state.nodes["operation-2"].data)
        reply = call(state, "patch_node", id="operation-2", version=1,
                     changes={"fields": {"4.5.1": {"value": "Расчёт целевых долей портфеля клиента."}}})
        self.assertNotIn("отклонён", reply)
        after = state.nodes["operation-2"].data
        self.assertEqual(after["fields"]["4.5.1"]["source"], before["fields"]["4.5.1"]["source"])
        self.assertEqual(after["fields"]["4.5.2"], before["fields"]["4.5.2"])
        self.assertEqual(after["basis"], before["basis"])
        saved = deepcopy(after)
        self.assertIn("устаревшая", call(state, "patch_node", id="operation-2", version=1, changes={"name": "Старое имя"}))
        self.assertEqual(saved, state.nodes["operation-2"].data)

    def test_repeated_invalid_patch_never_replaces_accepted_node(self):
        state = tree()
        saved = deepcopy(state.nodes["operation-2"].data)
        for version in range(1, 6):
            reply = call(state, "patch_node", id="operation-2", version=version,
                         changes={"fields": {"4.5.1": {"source": "Установлено"}}})
            self.assertIn("отклонён", reply)
            self.assertEqual(saved, state.nodes["operation-2"].data)

    def test_partial_edit_preserves_bindings_added_after_initial_submission(self):
        state = tree()
        state.scenarios = {"scenario-1": ["Расчёт", "Подтверждение"]}
        state.nodes["process-1"].data["scenario"] = "scenario-1"
        call(state, "bind_scenario_step", scenario="scenario-1", step=0, nodes=["operation-2"])
        call(state, "bind_scenario_step", scenario="scenario-1", step=1, nodes=["operation-2"])
        bindings = deepcopy(state.nodes["operation-2"].data["scenario_steps"])
        self.assertEqual(len(bindings), 2)
        self.assertIn("устаревшая", call(state, "patch_node", id="operation-2", version=1, changes={"name": "Расчёт"}))
        reply = call(state, "patch_node", id="operation-2", version=3,
                     changes={"fields": {"4.5.1": {"value": "Расчёт целевых долей портфеля клиента."}}})
        self.assertNotIn("отклонён", reply)
        self.assertEqual(bindings, state.nodes["operation-2"].data["scenario_steps"])

    def test_risk_patch_repairs_one_field_and_one_review_check(self):
        state = tree()
        original = risk()
        broken = {**original, "closure_criterion": ""}
        review = risk_review(risks=[original])
        broken_review = deepcopy(review)
        broken_review[0]["checks"][-1]["result"] = "invalid"
        self.assertIn("отклонён", call(state, "submit_risks", risks=[broken], review=broken_review))
        self.assertIn("отклонён", call(state, "finish"))
        reply = call(state, "patch_risks", version=1,
                     risks=[{"index": 0, "changes": {"closure_criterion": original["closure_criterion"]}}],
                     review=[{"node": "process-1", "checks": [review[0]["checks"][-1]]}])
        self.assertNotIn("отклонён", reply)
        self.assertTrue(state.risk_reviewed)
        self.assertEqual(state.risk_draft["risks"], [original])
        self.assertEqual(len(state.risk_review[0]["checks"]), 7)
        self.assertEqual(state.risks[0]["evidence"], original["evidence"])
        self.assertIn("устаревшая", call(state, "patch_risks", version=1, risks=[{"index": 0, "changes": {"title": "замена"}}]))
        self.assertEqual(state.risk_version, 2)

    def test_new_invalid_risk_evidence_blocks_finish_without_dropping_previous_result(self):
        state = tree()
        original = risk()
        call(state, "submit_risks", risks=[original], review=risk_review(risks=[original]))
        saved = deepcopy(state.risks)
        self.assertTrue(state.risk_reviewed)
        reply = call(state, "patch_risks", version=1, risks=[{"index": 0, "changes": {
            "evidence": [{"where": "invented.py:999", "basis": "неизвестный источник"}]}}])
        self.assertIn("отклонён", reply)
        self.assertFalse(state.risk_reviewed)
        self.assertEqual(state.risks, saved)
        self.assertIn("отклонён", call(state, "finish"))

    def test_node_change_requires_risk_review_again(self):
        state = tree()
        call(state, "submit_risks", risks=[], review=risk_review())
        self.assertTrue(state.risk_reviewed)
        call(state, "patch_node", id="operation-2", version=1,
             changes={"fields": {"4.5.1": {"value": "Расчёт целевых долей портфеля клиента."}}})
        self.assertFalse(state.risk_reviewed)
        self.assertIn("отклонён", call(state, "finish"))

    def test_batched_full_walk_has_same_normalized_passport(self):
        script = _shared_script()
        batched = deepcopy(script[:-4])
        relations = [json.loads(s["tool_calls"][0]["function"]["arguments"]) for s in script[-4:-2]]
        batched.extend([_tool_call("link_nodes_batch", relations=relations), *script[-2:]])
        single, batch = self.run_script(script), self.run_script(batched)
        self.assertTrue(single.passport_data["session"]["finished"], single.notes)
        self.assertTrue(batch.passport_data["session"]["finished"], batch.notes)
        self.assertEqual(single.steps - batch.steps, 1)
        self.assertEqual({k: v for k, v in single.passport_data.items() if k != "session"},
                         {k: v for k, v in batch.passport_data.items() if k != "session"})

    def test_soft_step_threshold_does_not_interrupt_successful_walk(self):
        with patch.dict(os.environ, {"PKO_PASSPORT_MAX_STEPS": "3"}):
            result = self.run_script(_happy_script())
        self.assertEqual(result.steps, 13)
        self.assertTrue(result.passport_data["session"]["finished"], result.notes)
        limited = self.run_script(_happy_script(), max_steps=3)
        self.assertEqual(limited.steps, 3)
        self.assertFalse(limited.passport_data["session"]["finished"])
        self.assertEqual(agent.DEFAULT_PASSPORT_SECONDS, 0)

    def test_duplicate_actions_stop_with_partial_data_retained(self):
        script = _happy_script()[:11] + [_tool_call("link_nodes_batch", relations=[relation()])] * 20
        result = self.run_script(script)
        self.assertTrue(any("без продвижения" in note for note in result.notes), result.notes)
        self.assertEqual(result.steps, 11 + agent.MAX_NO_PROGRESS_STEPS)
        self.assertEqual(len(result.passport_data["nodes"]), 6)
        self.assertEqual(len(result.passport_data["relations"]), 1)
        self.assertFalse(result.passport_data["session"]["finished"])

    def test_phase_tools_risk_brief_once_and_reasoning_history_preserved(self):
        seen = []
        script = _happy_script()
        script[0]["reasoning_content"] = "Рассуждение первого шага"
        self.run_script(script, seen=seen)
        self.assertLess(len(seen[0][0]["tools"]), len(seen[-1][0]["tools"]))
        for payload, _ in seen[10:]:
            briefs = [m for m in payload["messages"] if "Опорные факты для поиска рисков" in str(m.get("content"))]
            self.assertEqual(len(briefs), 1)
            self.assertEqual(briefs[0]["role"], "user")
        self.assertEqual(seen[-1][0]["messages"][2]["reasoning_content"], "Рассуждение первого шага")

    def test_thinking_override_applies_only_to_fields_and_journal_has_no_text(self):
        seen = []
        with patch.dict(os.environ, {"PKO_PASSPORT_FIELDS_THINKING": "false"}):
            with monitored_cli_run() as journal:
                result = self.run_script(_happy_script(), seen=seen)
        records = [json.loads(line) for line in journal.path.read_text(encoding="utf-8").splitlines()]
        steps = [r for r in records if r["event"] == "step_finished"]
        self.assertEqual(len(steps), result.steps)
        self.assertEqual({r["subphase"] for r in steps}, {"structure", "fields", "relations", "risks"})
        for step, (_, extra) in zip(steps, seen):
            self.assertIn("input_chars", step)
            if step["subphase"] == "fields":
                self.assertIs(extra["chat_template_kwargs"]["enable_thinking"], False)
            else:
                self.assertEqual(extra, SPEC.extra_body)
        self.assertNotIn("Размещение сбережений", journal.path.read_text(encoding="utf-8"))


class ClientOptimizationTest(unittest.TestCase):
    def make_client(self, spec=SPEC):
        client = ChatClient(spec=spec, use_cache=False)
        self.addCleanup(client._client.close)
        return client

    def test_sdk_does_not_multiply_timeout_retries(self):
        calls = []
        def request(req):
            calls.append(req)
            raise httpx.ReadTimeout("Тестовый таймаут", request=req)
        client = self.make_client()
        client._client.close()
        client._client = openai.OpenAI(base_url="https://example.invalid/v1", api_key="test",
            max_retries=client._client.max_retries,
            http_client=httpx.Client(transport=httpx.MockTransport(request)))
        self.addCleanup(client._client.close)
        with patch("pko.llm.client.time.sleep"), self.assertRaises(LlmError):
            client.chat([{"role": "user", "content": "Тест"}])
        self.assertEqual(len(calls), 3)

    def test_retryable_statuses_retry_but_authentication_does_not(self):
        for status, expected in ((408, 3), (409, 3), (429, 3), (503, 3), (401, 1), (400, 1)):
            with self.subTest(status=status):
                client = self.make_client()
                response = httpx.Response(status, request=httpx.Request("POST", "https://example.invalid"))
                error = openai.APIStatusError("Тест", response=response, body=None)
                with patch.object(client._client.chat.completions, "create", side_effect=error) as create:
                    with patch("pko.llm.client.time.sleep"), self.assertRaises(LlmError):
                        client.chat([{"role": "user", "content": "Тест"}])
                self.assertEqual(create.call_count, expected)

    def test_override_keeps_shared_spec_and_cache_separate(self):
        extra = {"chat_template_kwargs": {"enable_thinking": True, "custom": "preserve"}}
        spec = replace(SPEC, extra_body=deepcopy(extra))
        client = self.make_client(spec)
        with tempfile.TemporaryDirectory() as tmp:
            client.cache_dir, client.use_cache = Path(tmp), True
            with patch.object(client, "_create", return_value=make_openai_response("Ответ")) as create:
                messages = [{"role": "user", "content": "Тест"}]
                client.chat(messages, thinking=False)
                sent = create.call_args.kwargs["extra_body"]
                self.assertIs(sent["chat_template_kwargs"]["enable_thinking"], False)
                self.assertEqual(sent["chat_template_kwargs"]["custom"], "preserve")
                client.chat(messages)
                self.assertEqual(create.call_count, 2)
                self.assertTrue(client.chat(messages, thinking=False).from_cache)
        self.assertEqual(spec.extra_body, extra)

    def test_missing_optional_usage_is_not_zero(self):
        client = self.make_client()
        usage = SimpleNamespace(prompt_tokens=30, completion_tokens=12, total_tokens=42)
        response = SimpleNamespace(usage=usage)
        self.assertNotIn("reasoning_tokens", client._usage_of(response))
        self.assertNotIn("cached_tokens", client._usage_of(response))
        usage.prompt_tokens_details = SimpleNamespace(cached_tokens=0)
        usage.completion_tokens_details = {"reasoning_tokens": 9}
        self.assertEqual(client._usage_of(response)["cached_tokens"], 0)
        self.assertEqual(client._usage_of(response)["reasoning_tokens"], 9)

    def test_benchmark_cache_switch_preserves_existing_cache(self):
        client = self.make_client()
        with tempfile.TemporaryDirectory() as tmp:
            client.cache_dir, client.use_cache = Path(tmp), True
            with patch.dict(os.environ, {"PKO_LLM_CACHE": "true"}):
                client._write_cache("test-key", "Сохранённый ответ")
                with patch.dict(os.environ, {"PKO_LLM_CACHE": "false"}):
                    self.assertIsNone(client._read_cache("test-key"))
                    client._write_cache("test-key", "Новый ответ")
                self.assertEqual(client._read_cache("test-key"), "Сохранённый ответ")


if __name__ == "__main__":
    unittest.main()

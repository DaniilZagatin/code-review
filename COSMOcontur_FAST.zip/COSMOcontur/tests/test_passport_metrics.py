"""Сводка не смешивает кеш с сетью и не подменяет неизвестные метрики нулями."""
import json
from pathlib import Path
import runpy
import tempfile
import unittest

SCRIPT = runpy.run_path(str(Path(__file__).resolve().parents[1] / "scripts" / "summarize_passport_run.py"))


class PassportMetricsTest(unittest.TestCase):
    def test_cached_calls_excluded_from_latency_and_usage(self):
        rows = [
            {"pass": "passport", "event": "llm_call_finished", "duration_seconds": 60, "prompt_tokens": 100, "cached_tokens": 0},
            {"pass": "passport", "event": "llm_call_finished", "duration_seconds": 90, "prompt_tokens": 110},
            {"pass": "passport", "event": "llm_call_finished", "duration_seconds": .01, "from_cache": True, "prompt_tokens": 1000},
            {"pass": "matcher", "event": "llm_call_finished", "duration_seconds": 1},
            {"pass": "passport", "event": "llm_attempt", "attempt": 1},
            {"pass": "passport", "event": "llm_attempt", "attempt": 1},
            {"pass": "passport", "event": "llm_attempt", "attempt": 2},
        ]
        result = SCRIPT["summarize"](rows)
        self.assertEqual(result["network_median_seconds"], 75)
        self.assertEqual(result["network_p95_seconds"], 90)
        self.assertEqual(result["physical_attempts"], 3)
        self.assertEqual(result["local_cache_hits"], 1)
        self.assertEqual(result["usage"]["prompt_tokens"]["total"], 210)
        self.assertEqual(result["usage"]["cached_tokens"], {"total": 0, "reported_calls": 1})
        self.assertIsNone(result["usage"]["reasoning_tokens"]["total"])
        self.assertIsNone(result["finished"])

    def test_live_journal_ignores_partial_last_line(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "run.jsonl"
            path.write_text(json.dumps({"event": "run_started"}) + '\n{"event":', encoding="utf-8")
            rows, ignored = SCRIPT["read_events"](path)
        self.assertEqual(ignored, 1)
        self.assertEqual(len(rows), 1)
        self.assertFalse(SCRIPT["summarize"](rows)["passport_present"])

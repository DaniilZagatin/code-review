"""Сводка этапа 4 из локального JSONL-журнала; модель и сеть не используются."""
from __future__ import annotations

import argparse
from collections import Counter
import json
import math
import os
from pathlib import Path
from statistics import median


def summarize(events: list[dict]) -> dict:
    rows = [r for r in events if r.get("pass") == "passport"]
    steps = [r for r in rows if r.get("event") == "step_finished"]
    calls = [r for r in rows if r.get("event") == "llm_call_finished"]
    network = [r for r in calls if not r.get("from_cache")]
    attempts = [r for r in rows if r.get("event") == "llm_attempt"]
    ends = [r for r in rows if r.get("event") == "pass_finished"]
    end = ends[-1] if ends else {}
    durations = sorted(float(r["duration_seconds"]) for r in network if isinstance(r.get("duration_seconds"), (int, float)))
    phases = {}
    for row in steps:
        phase = row.get("subphase", "unknown")
        bucket = phases.setdefault(phase, {"steps": 0, "seconds": 0.0})
        bucket["steps"] += 1
        bucket["seconds"] = round(bucket["seconds"] + float(row.get("duration_seconds", 0)), 3)
    usage = {}
    for key in ("prompt_tokens", "completion_tokens", "cached_tokens", "reasoning_tokens"):
        known = [r[key] for r in network if isinstance(r.get(key), int)]
        usage[key] = {"total": sum(known) if known else None, "reported_calls": len(known)}
    rejections = Counter(r.get("kind") for r in rows
                         if r.get("event") == "gate_event" and str(r.get("kind", "")).endswith("_rejected"))
    return {
        "run_id": next((r.get("run_id") for r in events if r.get("run_id")), None),
        "passport_present": bool(rows), "finished": end.get("finished"),
        "risks_reviewed": end.get("risks_reviewed"), "nodes": end.get("nodes"),
        "duration_seconds": end.get("duration_seconds"), "steps": len(steps),
        "network_calls": len(network), "local_cache_hits": len(calls) - len(network),
        "physical_attempts": len(attempts) if attempts or not network else None,
        "network_median_seconds": round(median(durations), 3) if durations else None,
        "network_p95_seconds": round(durations[math.ceil(len(durations) * .95) - 1], 3) if durations else None,
        "phases": phases, "usage": usage, "rejections": dict(rejections),
        "thinking": dict(Counter(r.get("thinking", "unknown") for r in steps)),
    }


def read_events(path: Path) -> tuple[list[dict], int]:
    rows, ignored = [], 0
    with path.open(encoding="utf-8-sig") as stream:
        for line in stream:
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                ignored += 1
                continue
            if isinstance(value, dict):
                rows.append(value)
            else:
                ignored += 1
    return rows, ignored


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("journal", nargs="?", type=Path, help="JSONL-файл; по умолчанию последний журнал PKO")
    parser.add_argument("--json", action="store_true", help="Вывести машиночитаемую сводку")
    args = parser.parse_args()
    path = args.journal
    if path is None:
        root = Path(os.environ.get("PKO_MONITOR_DIR") or Path.home() / ".pko" / "monitoring").expanduser()
        candidates = list(root.glob("*.jsonl"))
        if not candidates:
            parser.error("Журналы не найдены: укажите JSONL-файл или PKO_MONITOR_DIR.")
        path = max(candidates, key=lambda item: item.stat().st_mtime)
    try:
        events, ignored = read_events(path)
    except OSError as exc:
        parser.error(f"Журнал недоступен: {exc}")
    result = summarize(events)
    result["ignored_lines"] = ignored
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    def show(value):
        return "нет данных" if value is None else str(value)
    print(f"Журнал: {path}")
    print(f"Этап 4 завершён: {show(result['finished'])}; риски проверены: {show(result['risks_reviewed'])}")
    print(f"Время этапа: {show(result['duration_seconds'])} с; шагов: {result['steps']}; узлов: {show(result['nodes'])}")
    print(f"Запросов к модели: {result['network_calls']}; физических попыток: {show(result['physical_attempts'])}; ответов из локального кеша: {result['local_cache_hits']}")
    print(f"Ответ модели: медиана {show(result['network_median_seconds'])} с; p95 {show(result['network_p95_seconds'])} с")
    for phase, bucket in result["phases"].items():
        print(f"  {phase}: {bucket['steps']} шагов, {bucket['seconds']} с")
    for key, metric in result["usage"].items():
        print(f"  {key}: {show(metric['total'])}; сообщено в {metric['reported_calls']} ответах")
    print("Отклонения: " + (json.dumps(result["rejections"], ensure_ascii=False) if result["rejections"] else "нет"))
    if ignored:
        print(f"Пропущено незавершённых или повреждённых строк: {ignored}")
    print("p95 на малом числе ответов предварителен. Прогоны с локальным кешем не измеряют скорость новой генерации.")


if __name__ == "__main__":
    main()

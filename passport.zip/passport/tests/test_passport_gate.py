"""Гейт паспорта клиентского пути: модель предлагает, код проверяет.

* структурные нарушения (BBB без операций, дубли уровней, потребности с
  процессов, ограничения без области, «Установлено» на намерении)
  отклоняются с объяснением;
* нормализация строит нумерацию, ID объектов и реестр из дерева и связей;
* обработчик `submit_passport` отклоняет, а после предела принимает с
  заметкой; рендерер переключает бейдж и кладёт область ограничения в реестр.
"""

from __future__ import annotations

import copy
import unittest

from pko.extractors.runner import Extraction
from pko.progress.matcher import _Session, _handle_passport
from pko.progress.passport_gate import (
    MAX_NEEDS,
    MAX_PASSPORT_REJECTIONS,
    check_passport,
    normalize_passport,
)
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import ProgressModel
from pko.render.client_journey_passport import (
    STATUS_BADGE_AGENT,
    STATUS_BADGE_FALLBACK,
    STATUS_BADGE_TEMPLATE,
    flatten_passport_data,
    passport_registry_rows,
    passport_tree_spec,
    render_client_journey_passport,
)


def _f(value: str, source: str) -> dict:
    return {"value": value, "source": source}


EST = "Установлено: portfolio_creator.py, collect_portfolio — собирает продукты по долям"
OWNER = "Требует подтверждения владельца: владелец продукта вкладов, назначение вне кода"


def _valid() -> dict:
    """Паспорт, проходящий гейт: то, каким его ждёт код."""
    return {
        "analysis-scope": "repo · abc1234 · проект",
        "decision-boundary": "COMPONENT_BBB",
        "analysis-date": "2026-09-15",
        "tree": [
            {"id": "journey-1", "type": "journey", "children": [
                {"id": "process-1", "type": "process", "children": [
                    {"id": "bbb-1", "type": "bbb", "children": [
                        {"id": "operation-1", "type": "operation"},
                    ]},
                    {"id": "bbb-2", "type": "bbb", "children": [
                        {"id": "operation-2", "type": "operation"},
                    ]},
                ]},
            ]},
        ],
        "nodes": {
            "journey-1": {"name": "Размещение сбережений в диалоге", "basis": "путь задан образом результата",
                          "fields": {"4.2.3": _f("Предложение: владелец продукта", OWNER)}},
            "process-1": {"name": "Портфельное предложение", "basis": "сценарий с собственной точкой входа",
                          "fields": {
                              "4.3.3": _f("Предложение: владелец продукта", OWNER),
                              "4.3.6": _f("Сборка портфеля — AUTO; оформление — CONFIRM, ждёт кнопки.",
                                          "Выведено: opener.py ждёт нажатия кнопки перед открытием"),
                              "4.3.8": _f("Не установлено: передачи человеку нет, клиент остаётся с ботом.",
                                          "Не установлено"),
                          }},
            "bbb-1": {"name": "Определение сценария обращения", "basis": "выбирает процесс по реплике",
                      "fields": {"4.4.1": _f("Относит реплику к сценарию.", EST)}},
            "bbb-2": {"name": "Сборка портфеля", "basis": "переиспользуемое действие с контрактом",
                      "fields": {"4.4.1": _f("Собирает набор продуктов.", EST)}},
            "operation-1": {"name": "Классификация реплики", "basis": "результат виден снаружи блока",
                            "fields": {"4.5.1": _f("Определяет категорию.", EST)}},
            "operation-2": {"name": "Расчёт долей портфеля", "basis": "отдельный расчёт с собственным отказом",
                            "fields": {"4.5.6": _f("Повтор безопасен: расчёт без внешнего эффекта.", EST)}},
            "need-1": {"name": "Разместить свободные деньги с доходом и доступом к части суммы",
                       "basis": "существует до продукта", "journeys": ["journey-1"],
                       "fields": {
                           "4.1.1": _f("Клиент хочет, чтобы деньги приносили доход и часть оставалась доступной.",
                                       "Требует подтверждения владельца: подтверждается исследованием потребностей"),
                           "4.1.7": _f("Не применяется при отсутствии свободных средств.",
                                       "Гипотеза: проверить по аналитике обращений"),
                       }},
            "guardrail-1": {"name": "Портфель не собирается меньше чем из двух продуктов",
                            "basis": "исполняемая проверка", "scope": ["bbb-2"],
                            "fields": {
                                "4.6.2": _f("Портфель из одного продукта не предлагается.",
                                            "Выведено: проверка числа продуктов перед показом"),
                                "4.6.3": _f("Предложение: владелец продукта", OWNER),
                                "4.6.8": _f("DENY — портфель не показывается.", EST),
                            }},
        },
    }


class CheckPassportTest(unittest.TestCase):

    def test_valid_passport_passes(self):
        check = check_passport(_valid())
        self.assertEqual(check.errors, [], check.errors)

    def test_bbb_without_operation_rejected(self):
        data = _valid()
        data["tree"][0]["children"][0]["children"][1]["children"] = []
        errors = check_passport(data).errors
        self.assertTrue(any("bbb-2: BBB без атомарных операций" in e for e in errors), errors)

    def test_child_duplicating_parent_rejected(self):
        data = _valid()
        data["nodes"]["operation-2"]["name"] = "Сборка портфеля"
        errors = check_passport(data).errors
        self.assertTrue(any("названы одинаково" in e for e in errors), errors)

    def test_single_bbb_with_parent_basis_rejected(self):
        data = _valid()
        data["tree"][0]["children"][0]["children"] = [data["tree"][0]["children"][0]["children"][1]]
        del data["nodes"]["bbb-1"], data["nodes"]["operation-1"]
        data["nodes"]["bbb-2"]["basis"] = data["nodes"]["process-1"]["basis"]
        errors = check_passport(data).errors
        self.assertTrue(any("средний уровень пустой" in e for e in errors), errors)

    def test_too_many_needs_rejected(self):
        data = _valid()
        for n in range(2, MAX_NEEDS + 2):
            node = copy.deepcopy(data["nodes"]["need-1"])
            node["name"] = f"Потребность {n}"
            data["nodes"][f"need-{n}"] = node
        errors = check_passport(data).errors
        self.assertTrue(any("допустимо не больше" in e for e in errors), errors)

    def test_need_in_system_language_rejected(self):
        data = _valid()
        data["nodes"]["need-1"]["fields"]["4.1.7"]["value"] = (
            "Портфель доступен только при включённом праве ALLOW_PORTFOLIO."
        )
        errors = check_passport(data).errors
        self.assertTrue(any("ALLOW_PORTFOLIO" in e for e in errors), errors)

    def test_need_grounded_in_classifier_rejected(self):
        data = _valid()
        data["nodes"]["need-1"]["fields"]["4.1.1"]["source"] = "Установлено: сценарий PICKER в классификаторе"
        errors = check_passport(data).errors
        self.assertTrue(any("сценарий или классификатор" in e for e in errors), errors)
        # «Установлено» на потребности отклоняется и само по себе.
        self.assertTrue(any("бизнес-намерение" in e for e in errors), errors)

    def test_need_named_after_process_rejected(self):
        data = _valid()
        data["nodes"]["need-1"]["name"] = "Портфельное предложение"
        errors = check_passport(data).errors
        self.assertTrue(any("переписана с процесса" in e for e in errors), errors)

    def test_need_without_journey_rejected(self):
        data = _valid()
        data["nodes"]["need-1"].pop("journeys")
        errors = check_passport(data).errors
        self.assertTrue(any("need-1: не указано, какой клиентский путь" in e for e in errors), errors)

    def test_guardrail_without_scope_rejected(self):
        data = _valid()
        data["nodes"]["guardrail-1"]["scope"] = []
        errors = check_passport(data).errors
        self.assertTrue(any("не указана область действия" in e for e in errors), errors)

    def test_guardrail_scope_from_registry_fallback(self):
        data = _valid()
        data["nodes"]["guardrail-1"].pop("scope")
        data["registry"] = [{"id": "guardrail-1", "parent": "bbb-2", "basis": "из реестра"}]
        self.assertEqual(check_passport(data).errors, [])
        norm = normalize_passport(data)
        self.assertEqual(norm["nodes"]["guardrail-1"]["scope"], ["bbb-2"])

    def test_guardrail_named_after_exception_rejected(self):
        data = _valid()
        data["nodes"]["guardrail-1"]["name"] = "PortfolioNotAvailableError"
        errors = check_passport(data).errors
        self.assertTrue(any("имя из кода" in e for e in errors), errors)

    def test_guardrail_effect_outside_list_rejected(self):
        data = _valid()
        data["nodes"]["guardrail-1"]["fields"]["4.6.8"]["value"] = "Сообщение об ошибке."
        errors = check_passport(data).errors
        self.assertTrue(any("4.6.8" in e for e in errors), errors)

    def test_bare_level_without_detail_rejected(self):
        data = _valid()
        data["nodes"]["bbb-2"]["fields"]["4.4.1"]["source"] = "Выведено"
        errors = check_passport(data).errors
        self.assertTrue(any("«Выведено» без привязки" in e for e in errors), errors)

    def test_source_without_level_rejected(self):
        data = _valid()
        data["nodes"]["bbb-2"]["fields"]["4.4.1"]["source"] = "portfolio_creator.py"
        errors = check_passport(data).errors
        self.assertTrue(any("должно начинаться с уровня" in e for e in errors), errors)

    def test_owner_established_rejected(self):
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.3"]["source"] = "Установлено: CODEOWNERS, команда депозитов"
        errors = check_passport(data).errors
        self.assertTrue(any("process-1 4.3.3" in e for e in errors), errors)

    def test_process_without_execution_mode_rejected(self):
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.6"]["value"] = "Сборка портфеля, оформление."
        errors = check_passport(data).errors
        self.assertTrue(any("режим исполнения" in e for e in errors), errors)

    def test_bad_decision_boundary_rejected(self):
        data = _valid()
        data["decision-boundary"] = "ВЕСЬ ПУТЬ"
        self.assertTrue(any("decision-boundary" in e for e in check_passport(data).errors))

    def test_handoff_as_scenario_transition_is_remark(self):
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.8"]["value"] = "Переход к оформлению по кнопке."
        check = check_passport(data)
        self.assertEqual(check.errors, [])
        self.assertTrue(any("4.3.8" in r for r in check.remarks), check.remarks)

    def test_status_rollback_is_not_compensation_remark(self):
        data = _valid()
        data["nodes"]["operation-2"]["name"] = "Перевод средств"
        data["nodes"]["operation-2"]["fields"]["4.5.4"] = _f("Средства переведены на источник.", EST)
        data["nodes"]["operation-2"]["fields"]["4.5.6"]["value"] = "При ошибке статус откатывается."
        remarks = check_passport(data).remarks
        self.assertTrue(any("откат статуса — не компенсация" in r for r in remarks), remarks)

    def test_router_mentioned_without_node_is_remark(self):
        data = _valid()
        data["nodes"]["bbb-1"]["name"] = "Подбор вклада"
        data["nodes"]["bbb-1"]["basis"] = "переиспользуемое действие"
        data["nodes"]["process-1"]["fields"]["4.3.4"] = _f(
            "Запрос на портфель.", "Установлено: prompts/scenario.py классификатор категорий")
        remarks = check_passport(data).remarks
        self.assertTrue(any("классификатор" in r for r in remarks), remarks)
        # Узел с ролью маршрутизатора есть — замечания нет.
        self.assertFalse(any("классификатор" in r for r in check_passport(_valid()).remarks))

    def test_empty_or_wrong_type_rejected(self):
        self.assertTrue(check_passport(None).errors)
        self.assertTrue(check_passport({"nodes": {}}).errors)
        self.assertTrue(check_passport({"nodes": {"journey-1": {"name": "x"}}}).errors)


class NormalizePassportTest(unittest.TestCase):

    def test_registry_derived_from_tree_and_links(self):
        norm = normalize_passport(_valid())
        rows = {row["id"]: row for row in norm["registry"]}
        self.assertEqual(rows["journey-1"]["parent"], "—")
        self.assertEqual(rows["process-1"]["parent"], "journey-1")
        self.assertEqual(rows["operation-2"]["parent"], "bbb-2")
        self.assertEqual(rows["need-1"]["parent"], "journey-1")
        self.assertEqual(rows["guardrail-1"]["parent"], "bbb-2")
        self.assertEqual(rows["guardrail-1"]["type"], "Ограничение исполнения")
        self.assertEqual(rows["bbb-2"]["basis"], "переиспользуемое действие с контрактом")

    def test_agent_registry_ignored(self):
        data = _valid()
        data["registry"] = [{"id": "guardrail-1", "type": "X", "name": "Y", "parent": "—", "basis": "чужое"}]
        rows = {row["id"]: row for row in normalize_passport(data)["registry"]}
        self.assertEqual(rows["guardrail-1"]["parent"], "bbb-2")
        self.assertEqual(rows["guardrail-1"]["basis"], "исполняемая проверка")
        self.assertEqual(len(rows), 8)

    def test_renumbering_and_object_ids(self):
        data = _valid()
        # Агент нумерует с дыр: bbb-7, guardrail-4 — код пересчитывает.
        data["tree"][0]["children"][0]["children"][1]["id"] = "bbb-7"
        data["nodes"]["bbb-7"] = data["nodes"].pop("bbb-2")
        data["nodes"]["guardrail-4"] = data["nodes"].pop("guardrail-1")
        data["nodes"]["guardrail-4"]["scope"] = ["bbb-7"]
        norm = normalize_passport(data)
        self.assertIn("bbb-2", norm["nodes"])
        self.assertNotIn("bbb-7", norm["nodes"])
        self.assertEqual(norm["nodes"]["guardrail-1"]["scope"], ["bbb-2"])
        self.assertEqual(norm["nodes"]["bbb-2"]["object-id"], "bbb.sborka-portfelya")
        self.assertEqual(norm["nodes"]["need-1"]["object-id"][:5], "need.")
        self.assertEqual(norm["tree"][0]["children"][0]["children"][1]["id"], "bbb-2")


class HandlePassportTest(unittest.TestCase):

    def _session(self) -> _Session:
        return _Session(plan_items=[], tree=None, tools=None)

    def test_valid_passport_accepted_and_normalized(self):
        state = self._session()
        reply = _handle_passport(state, {"passport": _valid()})
        self.assertIn("паспорт принят", reply)
        self.assertIsNotNone(state.passport_data)
        self.assertEqual(len(state.passport_data["registry"]), 8)

    def test_invalid_rejected_then_accepted_with_note(self):
        state = self._session()
        bad = _valid()
        bad["nodes"]["guardrail-1"]["scope"] = []
        for _ in range(MAX_PASSPORT_REJECTIONS):
            reply = _handle_passport(state, {"passport": bad})
            self.assertIn("паспорт отклонён", reply)
            self.assertIsNone(state.passport_data)
        reply = _handle_passport(state, {"passport": bad})
        self.assertIn("паспорт принят", reply)
        self.assertIsNotNone(state.passport_data)
        self.assertTrue(any("принят с нарушениями" in n for n in state.notes), state.notes)

    def test_remarks_returned_but_accepted(self):
        state = self._session()
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.8"]["value"] = "Переход к оформлению по кнопке."
        reply = _handle_passport(state, {"passport": data})
        self.assertIn("замечаний", reply)
        self.assertIsNotNone(state.passport_data)
        self.assertTrue(state.passport_remarks)


_JOURNEY = """\
Клиентский путь: Размещение сбережений
Проект: Демо-проект
## Подбор
- Подобран продукт.
"""


class RenderWithGateTest(unittest.TestCase):

    def _render(self, data):
        model = ProgressModel(meta={}, items={}, verdicts=[])
        plan = parse_plan_text(_JOURNEY)
        return render_client_journey_passport(
            model, plan, "demo/repo", Extraction(facts=[]),
            commit="abc1234", branch="main",
            llm_values=flatten_passport_data(data) if data else None,
            registry_rows=passport_registry_rows(data) if data else None,
            tree_spec=passport_tree_spec(data) if data else None,
        )

    def test_badge_switches_by_source(self):
        html = self._render(normalize_passport(_valid()))
        self.assertIn(STATUS_BADGE_AGENT, html)
        self.assertNotIn(STATUS_BADGE_TEMPLATE, html)
        html = self._render(None)
        self.assertIn(STATUS_BADGE_FALLBACK, html)

    def test_guardrail_scope_in_registry_and_node_rendered(self):
        html = self._render(normalize_passport(_valid()))
        self.assertIn('<td data-col="Родитель">bbb-2</td>', html)
        self.assertIn("Портфель не собирается меньше чем из двух продуктов", html)
        self.assertIn("bbb.sborka-portfelya", html)
        self.assertNotIn("Сквозной объект", html)

    def test_initiative_basis_in_header(self):
        html = self._render(normalize_passport(_valid()))
        self.assertIn("Образ результата инициативы", html)
        self.assertIn("Размещение сбережений; Подбор; пунктов образа результата: 1", html)


if __name__ == "__main__":
    unittest.main()

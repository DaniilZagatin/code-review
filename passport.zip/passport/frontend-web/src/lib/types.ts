// Зеркало JSON-контракта backend/pko/render/dashboard_data.py::build_dashboard_data и
// событий SSE из backend/pko/web/app.py::stream_analysis_events.

// Статус буллита — шкала согласия. Веса и подписи приходят с бэкенда
// (`meta.scale`): здесь их дублировать нельзя, разойдутся.
export type CriterionStatus =
  | "done"      // работает
  | "limited"   // работает с ограничениями
  | "unused"    // код реализован, но не используется
  | "partial"   // не работает, реализовано частично
  | "planned"   // не реализовано
  | "blocked";

// Одна ссылка на код в шторке пункта: файл, строка, имя и что там
// происходит. Неподтверждённые ссылки в контракт не попадают вовсе, поэтому
// поля `verified`/`reason` здесь нет — показывать нечего.
export interface CodeLink {
  path: string;
  line: number | null;
  basis: string;
  note: string;
}

// Ответ команды на оценку одного пункта. Отчёт — утверждение о чужой работе,
// и у команды должно быть право с ним не согласиться.
export type DisputeVerdict = "accept" | "accept_with_note" | "reject";

export interface Dispute {
  id: number;
  created_at: string;
  analysis_id: string;
  bullet_index: number;
  verdict: DisputeVerdict;
  verdict_label: string;
  comment: string;
}

// Один буллит этапа — дословный текст из ввода плюс оценка.
// `applicable` приходит только у пунктов, относящихся к анализируемой
// инициативе: у остальных полей нет вовсе, они серые и в расчёт не входят.
export interface AssessmentItem {
  text: string;
  applicable?: boolean;
  // Почему пункт не оценивался. Приходит только у неприменимых: они выходят
  // из знаменателя готовности, и причина должна быть видна читателю.
  na_reason?: string;
  status?: CriterionStatus;
  status_label?: string;
  // Раскрытие пункта — два буллита: «Проверка» (есть ли код и работает ли он)
  // и «Как работает» (обычными словами). Ссылки на код лежат ниже, в
  // отдельной шторке, и приходят только подтверждённые.
  proof?: string;
  how?: string;
  links?: CodeLink[];
  // Поля прежних версий — запасной источник, чтобы старые отчёты не теряли
  // текст: `technical`/`why` это «проверка», `business`/`comment` — «как
  // работает».
  technical?: string;
  why?: string;
  business?: string;
  comment?: string;
  group?: string;
}

export interface StageItem {
  title: string;
  description: string;
  applicable?: boolean;
  // Процент считает бэкенд. Экран его только показывает: вторая формула
  // на фронте неизбежно расходится с первой.
  percent?: number | null;
  assessment: AssessmentItem[];
}

export interface ScaleRow {
  status: CriterionStatus | "na";
  label: string;
  // Короткая подпись для строки-легенды: полные названия в одну строку не
  // помещаются. В самом пункте показывается полное.
  short?: string;
  // Два веса на статус: `weight` — прототип (по нему главный процент и
  // решение), `weight_prod` — промышленное решение.
  weight: number | null;
  weight_prod?: number | null;
  meaning: string;
}

export interface AnalysisMeta {
  repo: string;
  branch: string;
  commit: string;
  generated_at: string;
  client_path_name?: string;
  project_name?: string;
  before?: string;
  now?: string;
  after?: string;
  decision?: "GO" | "PIVOT" | "NO GO";
  // Верхнеуровневая оценка целого: суждение модели, а не расчёт по буллитам.
  match?: "matches" | "mostly" | "mismatch";
  match_label?: string;
  match_note?: string;


  closed_share?: number;
  source_digest?: string;
  scale?: ScaleRow[];
  counts?: Record<string, number>;
  not_applicable?: number;
}

export interface ProjectSummary {
  conclusion: string[];
  reason?: string;
}

export interface AnalysisResult {
  status: "READY";
  meta: AnalysisMeta;
  // Две готовности из одних и тех же статусов: прототип (главное число, по
  // нему решение) и промышленное решение (строгие веса).
  readiness: number;
  readiness_prod?: number;
  items: StageItem[];
  summary?: ProjectSummary;
  gaps?: string[];
}

export interface AnalysisPending {
  status: "PROCESSING";
}

export interface AnalysisFailed {
  status: "ERROR";
  message: string;
  hint: string;
}

export type Analysis = AnalysisResult | AnalysisPending | AnalysisFailed;

export interface CreateAnalysisResponse {
  analysis_id: string;
  status: "PROCESSING";
}

export interface ApiErrorBody {
  message: string;
  hint: string;
}

// События SSE (`GET /api/analyses/{id}/events`).
// `queued` — прогонов одновременно идёт ограниченное число, и ожидание своей
// очереди честнее показать, чем крутить кружок молча.
export type PhaseName = "queued" | "materials_loading" | "materials_ready";

export type AnalysisEvent =
  | { type: "phase"; phase: PhaseName; label: string }
  | {
      type: "plan_ready";
      item_count: number;
      items: {
        title: string;
        origin: "user";
        criteria: number;
      }[];
    }
  | {
      type: "claim_verified";
      title: string;
      applicable: boolean;
      percent: number | null;
      criteria: number;
    }
  | { type: "summary_ready"; text: string; decision: string }
  | { type: "analysis_ready" }
  | { type: "error"; message: string; hint: string };

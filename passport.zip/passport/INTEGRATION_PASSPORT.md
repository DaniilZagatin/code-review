# Инструкция: интеграция заполнения паспорта клиентского пути в агента

## Что это

Интеграция позволяет агенту-матчеру (который анализирует код и оценивает
готовность инициативы) заполнять **паспорт клиентского пути** — HTML-файл по
шаблону `passport-dpss-v3.html` — в той же сессии, без отдельного LLM-вызова.

Агент анализирует код инструментами (`list_files`, `read_file`, `search`,
`who_calls`, `show_facts`), оценивает этапы (`submit_stage`), выносит вердикт
(`submit_summary`), а затем заполняет паспорт (`submit_passport`) и завершает
сессию (`finish`). Паспорт формируется в одном вызове с дашбордом и отчётом.

## Изменённые файлы

| Файл | Что изменилось |
|---|---|
| `backend/pko/progress/matcher.py` | Добавлен инструмент `submit_passport` (схема, обработчик, активация после `submit_summary`); поля `passport_data` в `_Session`, `_SessionOutcome`, `AgentResult`; импорт `MAX_READ_LINES` и хелпер `_as_int` (bugfix); обновлён текст `_handle_summary` → направляет к паспорту |
| `backend/pko/progress/pipeline.py` | `passport_data` передаётся из `AgentResult` в `ProgressModel` |
| `backend/pko/progress/schema.py` | Поле `passport_data` в `ProgressModel`; сериализация в `to_dict()`/`to_json()` |
| `backend/pko/progress/agent_system.md` | Раздел «Шаг 2.5. submit_passport» — формат JSON, поля по типам узлов, уровни обоснования, правило создания множественных узлов |
| `backend/pko/render/client_journey_passport.py` | Переключён на шаблон `passport-dpss-v3.html`; рендерер переписан под `<div>`-структуру v3 (вместо `<details>`); добавлены: `_insert_extra_nodes` (клонирование `<template>`-заготовок для новых узлов), `flatten_passport_data`, `passport_registry_rows`, `passport_tree_spec`, `_fill_registry`, `_strip_comments` |
| `backend/pko/cli.py` | В `_cmd_progress` паспорт берёт `passport_data` из модели (не отдельный LLM-вызов); передаёт `tree_spec` в рендерер |
| `passport-dpss-v3.html` | Новый шаблон паспорта v3 (режим «только код», `<template>`-библиотека, `data-fill`/`data-field`/`data-children`) |
| `instrukciya-zapolneniya-pasporta-v3.md` | Инструкция по заполнению v3 — уровни обоснования, правила реконструкции из кода |

## Как встроить в новый проект

### 1. Скопировать файлы

```
passport-dpss-v3.html              → корень проекта
instrukciya-zapolneniya-pasporta-v3.md → корень проекта
backend/pko/render/client_journey_passport.py → рендерер
backend/pko/progress/matcher.py    → агент (если уже есть — смерджить)
backend/pko/progress/pipeline.py   → пайплайн
backend/pko/progress/schema.py     → модель данных
backend/pko/progress/agent_system.md → системный промпт
backend/pko/cli.py                 → CLI
```

### 2. Проверить путь к шаблону

В `client_journey_passport.py`:

```python
_TEMPLATE_PATH = Path(__file__).resolve().parents[3] / "passport-dpss-v3.html"
```

`parents[3]` — это корень проекта (3 уровня вверх от `backend/pko/render/`).
Если структура другая — поправить путь.

### 3. Добавить инструмент в сессию агента

В `matcher.py`:

**Схема** (`_SUBMIT_PASSPORT_SCHEMA`): описывает параметр `passport` —
JSON-объект с `tree` и `nodes` (`journeys` у потребности, `scope` у ограничения).

**Активация** в `_active_tool_schemas`: `submit_passport` появляется после
`submit_summary` (когда `state.summary is not None`), до `finish`.

**Обработчик** `_handle_passport`: прогоняет `args["passport"]` через
`passport_gate.check_passport`, при нарушениях возвращает их агенту (до
`MAX_PASSPORT_REJECTIONS` раз), принятый паспорт нормализует
(`normalize_passport`) и кладёт в `state.passport_data`. Незаполненные поля
остаются заглушками рендерера.

**Протокол** в `_PROTOCOL_HANDLERS` и `_SCHEMA_BY_NAME`.

### 4. Провести passport_data через цепочку

```
_Session.passport_data
  → _SessionOutcome.passport_data
    → AgentResult.passport_data
      → ProgressModel.passport_data (pipeline.py)
        → render_client_journey_passport(model.passport_data)
```

### 5. Рендеринг в CLI

```python
from pko.render.client_journey_passport import (
    flatten_passport_data,
    passport_registry_rows,
    passport_tree_spec,
)
llm_vals = flatten_passport_data(model.passport_data)  # если есть
reg_rows = passport_registry_rows(model.passport_data)
tree_spec = passport_tree_spec(model.passport_data)
cj_html = render_client_journey_passport(
    model, plan_input, name, target.extraction,
    commit=target.sha, branch=target.branch,
    llm_values=llm_vals, registry_rows=reg_rows, tree_spec=tree_spec,
)
```

## Как это работает

### Поток данных

```
Агент анализирует код
  → submit_stage (оценка этапов)
  → submit_review (контр-проверка)
  → submit_summary (вердикт)
  → submit_passport (заполнение паспорта)     ← НОВОЕ
  → finish
```

`submit_passport` вызывается **один раз**, после `submit_summary`. Агент
получает схему инструмента только когда вердикт уже принят — раньше
схема не видна и не отвлекает.

### Гейт: модель предлагает, код проверяет

`backend/pko/progress/passport_gate.py` — `check_passport` отклоняет
паспорт-реверс-инжиниринг (BBB без операций, потребности с процессов и на
языке системы, ограничения без `scope`, «Установлено» на намерении, голое
«Выведено», процесс без режима исполнения) и возвращает агенту список
нарушений; после `MAX_PASSPORT_REJECTIONS` принимает с заметкой.
`normalize_passport` строит нумерацию, `object-id` и реестр из дерева и
связей — `registry` от агента не используется.

### Формат ответа агента

```json
{
  "analysis-scope": "репозиторий · проект",
  "decision-boundary": "END_TO_END_PROCESS",
  "analysis-date": "2026-09-14",
  "tree": [
    {"id": "journey-1", "type": "journey", "children": [
      {"id": "process-1", "type": "process", "children": [
        {"id": "bbb-1", "type": "bbb", "children": [
          {"id": "operation-1", "type": "operation"}
        ]}
      ]}
    ]}
  ],
  "nodes": {
    "journey-1": {"name": "...", "basis": "...", "object-version": "...",
                   "fields": {"4.2.1": {"value": "...", "source": "..."}}},
    "bbb-1": {"name": "...", "basis": "...", ...},
    "need-1": {"name": "...", "basis": "...", "journeys": ["journey-1"], ...},
    "guardrail-1": {"name": "...", "basis": "...", "scope": ["bbb-1"], ...}
  }
}
```

`registry` и `object-id` агент не присылает — их строит `normalize_passport`.

### Рендерер: три прохода

1. **`_insert_extra_nodes`** — клонирует `<template>`-заготовки для узлов,
   которых нет в шаблоне (process-2, bbb-2, bbb-3, ...). Вставляет клон в
   `data-children` контейнер родителя.
2. **`_fill_registry`** — заполняет таблицу реестра узлов строками из `registry`.
3. **`_fill_template`** — линейный проход по HTML: отслеживает текущий узел
   (по `id`) и поле (по `data-field`), подставляет значения в `data-fill`
   элементы.

### Fallback

Если агент не вызвал `submit_passport` (не хватило шагов / таймаут сессии),
паспорт формируется детерминированно из `ProgressModel` + `Extraction`:
6 образцов узлов, поля из контекста инициативы и фактов кода.

## Запуск

### DeepSeek (mTLS)

```bash
export PKO_MATCHER_BASE_URL="https://ingressgateway-ai-hub-ci11758197-models-ift.apps.bbwo1z5h.k8s.delta.sbrf.ru/deepseek-v4-flash/v1"
export PKO_MATCHER_MODEL="deepseek-ai/DeepSeek-V4-Flash"
export PKO_MATCHER_CLIENT_CERT="certs/deepsearch-gp-sberca-client.crt"
export PKO_MATCHER_CLIENT_KEY="certs/deepsearch-gp-sberca-client.key"
export PKO_THINKING=true
export PKO_MAX_SESSION_SECONDS=3600
export PKO_CONTEXT_WINDOW=128000

pko progress \
  --initiative agent-kontr-offera \
  --zip projects/.../credit_counter_offer.zip \
  --zip projects/.../depo_counter_offer.zip \
  --out results \
  --thinking \
  --max-steps 80
```

### GLM-5.2 (HTTP, без сертов)

```bash
# .env: PKO_THINKING=true, эндпоинт из defaults.py
pko progress \
  --initiative agent-kontr-offera \
  --zip projects/.../code.zip \
  --out results \
  --thinking \
  --max-steps 80
```

### Результат

В `results/`:

- `<slug>_client_journey_passport.html` — паспорт (шаблон v3, заполнен агентом)
- `<slug>_dashboard.html` — дашборд готовности
- `<slug>_progress_report.html` — отчёт
- `<slug>_progress_model.json` — модель (включая `passport_data`)

## Параметры запуска

| Параметр | Значение | Зачем |
|---|---|---|
| `--max-steps 80` | 80 шагов | Агенту нужно ~40 шагов на анализ + ~10 на паспорт |
| `--thinking` | включить reasoning | DeepSeek/GLM с thinking — глубже анализ, но медленнее |
| `PKO_MAX_SESSION_SECONDS=3600` | 1 час | Thinking-режим: ~1-2 мин на шаг |
| `PKO_CONTEXT_WINDOW=128000` | окно модели | Бюджет истории агента |

## Ограничения

- Агент может не дойти до `submit_passport` при нехватке шагов или таймауте —
  тогда паспорт формируется детерминированно (заглушки).
- Кеш LLM инвалидируется при изменении `agent_system.md` — повторный прогон
  того же коммита после правки промпта снова вызывает модель.
- Сертификаты `certs/*.key` не коммитить (в `.gitignore`).

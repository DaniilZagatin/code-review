import type { Analysis, ApiErrorBody, CreateAnalysisResponse } from "./types";

// `/api/*` — в dev проксируется на FastAPI через rewrites() в next.config.ts,
// в проде оба процесса стоят за одним обратным прокси (см. README) — здесь
// достаточно относительного пути, свой базовый URL не нужен.

export class ApiError extends Error {
  hint: string;
  constructor(body: ApiErrorBody) {
    super(body.message);
    this.hint = body.hint;
  }
}

async function parseOrThrow<T>(resp: Response): Promise<T> {
  const text = await resp.text();
  let body: unknown;
  try {
    body = text ? JSON.parse(text) : {};
  } catch {
    throw new ApiError({
      message: `Сервер вернул не-JSON ответ (HTTP ${resp.status}).`,
      hint: text.slice(0, 500) || resp.statusText,
    });
  }
  if (!resp.ok) {
    throw new ApiError(body as ApiErrorBody);
  }
  return body as T;
}

export async function createAnalysis(
  journeyText: string,
  repository: string,
  branch: string,
  files: File[],
  thinking: boolean = false,
  description: string = "",
): Promise<CreateAnalysisResponse> {
  // Репозиторий и файлы — два независимых необязательных источника evidence
  // (см. backend/pko/web/analyses.py::create_analysis) — можно и репозиторий,
  // и файлы поверх; оба можно оставить пустыми.
  // `journeyText` — клиентский путь текстом: название, этапы (##) и буллиты (-).
  // `description` — описание инициативы: из него агент формулирует «Было/Стало».
  // `thinking` — переключатель режима рассуждения (кнопка в форме).
  const form = new FormData();
  form.set("journey_text", journeyText);
  form.set("repository", repository);
  form.set("branch", branch);
  form.set("thinking", thinking ? "true" : "false");
  form.set("description", description);
  for (const file of files) {
    form.append("files", file);
  }
  const resp = await fetch("/api/analyses", { method: "POST", body: form });
  return parseOrThrow<CreateAnalysisResponse>(resp);
}

export async function getAnalysis(analysisId: string): Promise<Analysis> {
  const resp = await fetch(`/api/analyses/${analysisId}`);
  const body = await resp.json();
  if (!resp.ok && body.status !== "ERROR") {
    throw new ApiError(body as ApiErrorBody);
  }
  return body as Analysis;
}

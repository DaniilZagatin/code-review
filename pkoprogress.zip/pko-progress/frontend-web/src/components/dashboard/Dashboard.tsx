"use client";

import { useState } from "react";
import type {
  AnalysisResult,
  AssessmentItem,
  CodeLink,
  ScaleRow,
  StageItem,
} from "@/lib/types";
import { cn } from "@/lib/utils";
import { Download } from "lucide-react";
import "./dashboard.css";

// Веб-экран результатов — тот же отчёт, что и скачиваемый HTML
// (`backend/pko/render/dashboard_template.html`), только на React. Разметка и
// эстетика совпадают намеренно: руководство не должно видеть две разные
// картинки от одного инструмента.
//
// Здесь НИЧЕГО не вычисляется. Проценты, готовность, решение и шкала с весами
// приходят готовыми из данных. Раньше этот файл считал процент этапа сам
// (`done=1, partial=0.5`, неприменимые в знаменателе) и выводил решение по
// порогам 80/40 — обе формулы разошлись с бэкендом и давали другой отчёт.

type StatusKey = "done" | "limited" | "unused" | "partial" | "planned" | "blocked" | "na";

// Подписи дублируют бэкенд только для aria-label и запасного варианта:
// на экран идёт `status_label` из данных.
const STATUS_LABEL: Record<StatusKey, string> = {
  done: "работает",
  limited: "работает с ограничениями",
  unused: "код реализован, но не используется",
  partial: "не работает, реализовано частично",
  planned: "не реализовано",
  blocked: "блокирует",
  na: "не оценивается",
};

function statusKey(item: AssessmentItem): StatusKey {
  if (item.applicable !== true) return "na";
  const raw = String(item.status || "").toLowerCase();
  if (raw === "scaffold") return "partial";  // статус прежних прогонов
  if (["done", "limited", "unused", "partial", "blocked"].includes(raw)) {
    return raw as StatusKey;
  }
  return "planned";
}

function Mark({ status, big }: { status: StatusKey; big?: boolean }) {
  return <span className={cn("mark", status, big && "lg")} title={STATUS_LABEL[status]} />;
}

// Сплошной текст длиннее двух фраз читается плохо — режем на пункты.
function splitSentences(text: string): string[] {
  return String(text || "")
    .split(/(?<=[.!?;])\s+(?=[А-ЯA-Z«(])/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function Comment({ text }: { text: string }) {
  const parts = splitSentences(text);
  if (parts.length <= 1) return <div className="detail-line">{text}</div>;
  return (
    <ul className="detail-list">
      {parts.map((part, i) => <li key={i}>{part}</li>)}
    </ul>
  );
}

// Шторка со ссылками на код: закрыта по умолчанию, открывается отдельно от
// самого пункта. Отчёт читается без неё, а тому, кто хочет проверить, ссылки
// под рукой. Приходят только подтверждённые — неподтверждённая ссылка ничего
// не доказывает, а рядом со статусом читается как доказательство.
function Links({ items }: { items: CodeLink[] }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="links">
      <button
        type="button"
        className="links-toggle"
        aria-expanded={open}
        onClick={(e) => {
          // Клик по шторке не должен схлопывать сам пункт.
          e.stopPropagation();
          setOpen((v) => !v);
        }}
      >
        <span className="links-caret">{open ? "▾" : "▸"}</span>
        Ссылки на код · {items.length}
      </button>
      {open && (
        <div className="links-body">
          {items.map((item, i) => (
            <div key={i} className="link-item">
              <div className="link-where">
                <span className="link-path">
                  {item.path}{item.line ? `:${item.line}` : ""}
                </span>
                {item.basis && (
                  <>
                    {" · "}
                    <span className="link-symbol">{item.basis}</span>
                  </>
                )}
              </div>
              {item.note && <div className="link-note">{item.note}</div>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Один буллит разбора: подпись слева, содержимое справа.
function Part({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="part">
      <div className="part-label">{label}</div>
      <div className="part-body">{children}</div>
    </div>
  );
}

function Row({ item }: { item: AssessmentItem }) {
  const [open, setOpen] = useState(false);
  const status = statusKey(item);
  // Раскрытие — два буллита человеческим языком, ссылки ниже в шторке.
  const proof = item.proof || item.technical || item.why || "";
  const how = item.how || item.business || item.comment || "";
  const links = item.links || [];
  const hasDetail = Boolean(proof) || Boolean(how) || links.length > 0;

  return (
    <div
      className={cn("row", status, open && "open")}
      style={hasDetail ? undefined : { cursor: "default" }}
      role={hasDetail ? "button" : undefined}
      tabIndex={hasDetail ? 0 : undefined}
      aria-expanded={hasDetail ? open : undefined}
      aria-label={STATUS_LABEL[status]}
      onClick={() => hasDetail && setOpen((v) => !v)}
      onKeyDown={(e) => {
        if (!hasDetail) return;
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          setOpen((v) => !v);
        }
      }}
    >
      <div>
        <div className="row-text">{item.text || "Без описания"}</div>
        {hasDetail && (
          // Разбор открывается по клику: список остаётся читаемым, а
          // объяснение никуда не спрятано. Структура пункта одинакова
          // везде: статус — проверка — как работает — ссылки на код.
          <div className="detail">
            {proof && (
              <Part label="Проверка">
                <div className="part-head">
                  <span className="part-status">
                    {item.status_label || STATUS_LABEL[status]}
                  </span>
                </div>
                <Comment text={proof} />
              </Part>
            )}
            {how && (
              <Part label="Как работает">
                <Comment text={how} />
              </Part>
            )}
            {links.length > 0 && <Links items={links} />}
          </div>
        )}
      </div>
      <div className="row-mark">
        <Mark status={status} big />
      </div>
    </div>
  );
}

function chipFor(rows: AssessmentItem[]): { text: string; cls: string } {
  const usable = rows.filter((r) => r.applicable === true);
  if (!usable.length) return { text: "не оценивается", cls: "" };
  const done = usable.filter((r) => r.status === "done").length;
  // «В работе» — всё между «работает» и «не реализовано».
  const work = usable.filter((r) =>
    ["limited", "unused", "partial", "scaffold"].includes(String(r.status)),
  ).length;
  if (done === usable.length) return { text: `${done} из ${done}`, cls: "all-done" };
  if (done === 0 && work === 0) return { text: "не реализовано", cls: "" };
  if (done === 0) return { text: `${work} в работе`, cls: "in-work" };
  return { text: `${done} из ${usable.length}`, cls: "" };
}

function groupRows(items: StageItem[]): { name: string; rows: AssessmentItem[] }[] {
  const order: string[] = [];
  const byName = new Map<string, AssessmentItem[]>();
  for (const item of items) {
    for (const row of item.assessment || []) {
      const name = (row.group || "").trim() || "Функционал";
      if (!byName.has(name)) {
        byName.set(name, []);
        order.push(name);
      }
      byName.get(name)!.push(row);
    }
  }
  return order.map((name) => ({ name, rows: byName.get(name)! }));
}

function Ring({ percent }: { percent: number }) {
  const r = 36;
  const c = 2 * Math.PI * r;
  return (
    <div className="ring">
      <svg viewBox="0 0 84 84">
        <circle className="ring-track" cx="42" cy="42" r={r} />
        <circle
          className="ring-value"
          cx="42" cy="42" r={r}
          strokeDasharray={c}
          strokeDashoffset={c * (1 - percent / 100)}
        />
      </svg>
      <div className="ring-num">{percent}%</div>
    </div>
  );
}

// Шкала — одна строка-легенда: расшифровки убраны, они дублировали сами
// названия статусов и мешали отчёту помещаться на один экран. Веса два —
// прототип и пром, чтобы читатель мог пересчитать оба числа сам.
function weightPair(row: ScaleRow): string {
  if (row.weight === null || row.weight === undefined) return "—";
  const prod = row.weight_prod;
  if (prod === null || prod === undefined || prod === row.weight) return `${row.weight}%`;
  return `${row.weight}/${prod}%`;
}

function Scale({ rows }: { rows: ScaleRow[] }) {
  return (
    <div className="scale">
      <span className="scale-title">Шкала прототип / пром</span>
      {rows.map((row) => (
        <span key={row.status} className="scale-item">
          <Mark status={row.status as StatusKey} />
          <span>{row.label}</span>
          <span className="scale-weight">{weightPair(row)}</span>
        </span>
      ))}
    </div>
  );
}

function downloadName(meta: AnalysisResult["meta"]): string {
  const base = (meta.project_name || meta.client_path_name || meta.repo || "project")
    .replace(/[^A-Za-z0-9А-Яа-я]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "project";
  return `pko-dashboard-${base}.html`;
}

export function Dashboard({
  analysis,
  analysisId,
}: {
  analysis: AnalysisResult;
  analysisId: string;
}) {
  const { meta, readiness, items } = analysis;
  const percent = Math.max(0, Math.min(100, Math.round(readiness)));
  const percentProd =
    typeof analysis.readiness_prod === "number"
      ? Math.max(0, Math.min(100, Math.round(analysis.readiness_prod)))
      : null;
  const scale = meta.scale || [];
  const groups = groupRows(items);

  // Решение приходит из данных. Фолбэка по проценту здесь нет и быть не должно:
  // вторая формула вердикта — регресс, а не подстраховка.
  const decision = String(meta.decision || "").toUpperCase().replace("NO-GO", "NO GO");
  const decisionClass =
    decision === "GO" ? "go" : decision === "PIVOT" ? "pivot" : decision === "NO GO" ? "no-go" : "";

  return (
    <div className="dashboard-root">
      <main className="shell">
        <section className="sheet">
          <div className="tags">
            <span className="tag dark">Программа AI-эффективность</span>
            <span className="tag plain">Готовность функционала</span>
          </div>

          <div className="head">
            <div>
              <h1>
                Анализ готовности функционала
                {meta.project_name ? ` · ${meta.project_name}` : ""}
              </h1>
              {meta.client_path_name && (
                <p className="subtitle">Клиентский путь · {meta.client_path_name}</p>
              )}
            </div>
            <div className="score">
              <Ring percent={percent} />
              <div className="score-text">
                <div className="score-title">ИИ-оценка кода</div>
                <div className="score-verdict">
                  {decisionClass ? (
                    // Строки расчёта («71% ≥ 40%») рядом с бейджем нет: два
                    // числа готовности ниже говорят то же самое.
                    <span className={cn("badge", decisionClass)}>{decision}</span>
                  ) : (
                    <span className="badge none">Решение не сформировано</span>
                  )}
                </div>
                {/* Оценивается прототип — по нему решение; промышленная
                    планка идёт справочно, чтобы «71%» не читали как «до
                    прома осталось 29%». */}
                <div className="score-pair">
                  <span className="score-metric">
                    <span className="score-metric-label">Прототип</span>
                    <span className="score-metric-value">{percent}%</span>
                  </span>
                  {percentProd !== null && (
                    <span className="score-metric">
                      <span className="score-metric-label">Промышленное решение</span>
                      <span className="score-metric-value">{percentProd}%</span>
                    </span>
                  )}
                </div>

              </div>
            </div>
          </div>

          {scale.length > 0 && <Scale rows={scale} />}

          {groups.length === 0 ? (
            <div className="empty">Буллиты образа результата не найдены.</div>
          ) : (
            <div className="groups">
              {groups.map((group, index) => {
                const chip = chipFor(group.rows);
                return (
                  <div key={group.name} className="group">
                    <div className="group-head">
                      <div className="group-name">
                        <span className="group-num">{String(index + 1).padStart(2, "0")}</span>
                        <span className="group-title">{group.name}</span>
                      </div>
                      <span className={cn("chip", chip.cls)}>{chip.text}</span>
                    </div>
                    {group.rows.map((row, i) => <Row key={i} item={row} />)}
                  </div>
                );
              })}
            </div>
          )}

          <div className="foot">
            {meta.repo && <span>Репозиторий <b>{meta.repo}</b></span>}
            {meta.branch && <span>Ветка <b>{meta.branch}</b></span>}
            {meta.commit && <span>Коммит <b>{meta.commit.slice(0, 8)}</b></span>}
            {meta.source_digest && (
              <span>Образ результата <b>{meta.source_digest.slice(0, 10)}</b></span>
            )}
            {meta.generated_at && <span>Отчёт от <b>{meta.generated_at}</b></span>}
            <a
              href={`/api/analyses/${analysisId}/dashboard.html`}
              download={downloadName(meta)}
              className="download-btn"
            >
              <Download className="size-4" aria-hidden="true" />
              Скачать отчёт
            </a>
          </div>
        </section>
      </main>
    </div>
  );
}

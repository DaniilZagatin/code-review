"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { createAnalysis, ApiError } from "@/lib/api";
import { FileDropzone } from "./FileDropzone";
import { RepositoryInput } from "./RepositoryInput";

// Репозиторий и файлы проекта — два независимых необязательных источника
// evidence (backend/pko/web/analyses.py::create_analysis). Оба можно оставить
// пустыми — это не ошибка: агент получает пустой снимок материалов.
export function ProjectUploadForm() {
  const router = useRouter();
  const [journeyText, setJourneyText] = useState("");
  const [description, setDescription] = useState("");
  const [repository, setRepository] = useState("");
  const [branch, setBranch] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState<{ message: string; hint: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const canSubmit = journeyText.trim().length > 0 && !submitting;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit) return;
    setSubmitting(true);
    setError(null);
    try {
      const { analysis_id } = await createAnalysis(
        journeyText, repository, branch, files, thinking, description,
      );
      router.push(`/analysis/${analysis_id}`);
    } catch (err) {
      setError(err instanceof ApiError ? { message: err.message, hint: err.hint } : {
        message: "Не удалось отправить запрос.", hint: String(err),
      });
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6 rounded-2xl border border-border bg-card p-7">
      <div>
        <h2 className="text-base font-semibold mb-2.5">Клиентский путь</h2>
        <p className="text-muted-foreground text-xs mb-2.5">
          Введите название пути, этапы и их пункты. Этап — через <code className="text-foreground">##</code>,
          пункт — через <code className="text-foreground">-</code>. У этапа может не быть пунктов.
        </p>
        <textarea
          value={journeyText}
          onChange={(e) => setJourneyText(e.target.value)}
          rows={12}
          placeholder={JOURNEY_PLACEHOLDER}
          className="w-full min-w-0 resize-y rounded-lg border border-input bg-transparent px-3 py-2.5 font-mono text-sm leading-6 transition-colors outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 dark:bg-input/30"
        />
      </div>
      <div>
        <h2 className="text-base font-semibold mb-2.5">Описание инициативы</h2>
        <p className="text-muted-foreground text-xs mb-2.5">
          Опишите инициативу своими словами — агент сформулирует короткие «Было» и «Стало»
          для шапки дашборда. Необязательно, если они уже есть в тексте пути выше.
        </p>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={4}
          placeholder="Раньше руководитель собирал данные вручную по нескольким системам перед встречей, тратил час. Теперь дашборд собирает метрики автоматически и показывает всё за минуту."
          className="w-full min-w-0 resize-y rounded-lg border border-input bg-transparent px-3 py-2.5 text-sm leading-6 transition-colors outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 dark:bg-input/30"
        />
      </div>
      <div>
        <h2 className="text-base font-semibold mb-2.5">Репозиторий</h2>
        <RepositoryInput
          repository={repository}
          onRepositoryChange={setRepository}
          branch={branch}
          onBranchChange={setBranch}
        />
      </div>
      <div>
        <h2 className="text-base font-semibold mb-2.5">Файлы проекта</h2>
        <FileDropzone
          files={files}
          onChange={setFiles}
          multiple
          label="Перетащите файлы сюда"
          hint="код, ZIP-архив, метрики, отчёты — что угодно, чем можно подтвердить готовность"
        />
      </div>
      <div className="flex items-center justify-between gap-3.5">
        <div className="min-w-0">
          <h2 className="text-base font-semibold">Режим рассуждения (thinking)</h2>
          <p className="text-muted-foreground text-xs mt-1">
            Цепочка рассуждений модели: медленнее, но детальнее. По умолчанию выключен.
          </p>
        </div>
        <Button
          type="button"
          variant={thinking ? "default" : "outline"}
          aria-pressed={thinking}
          onClick={() => setThinking((v) => !v)}
          className="h-10 shrink-0 px-4 text-sm"
        >
          {thinking ? "Включён" : "Выключен"}
        </Button>
      </div>
      {error && (
        <div className="rounded-lg bg-destructive/10 text-destructive text-sm p-3.5 whitespace-pre-wrap">
          {error.message}
          {error.hint ? `\n${error.hint}` : ""}
        </div>
      )}
      <Button type="submit" disabled={!canSubmit} className="self-start h-11 px-5 text-sm">
        {submitting ? "Отправляем…" : "Начать анализ"}
      </Button>
    </form>
  );
}

const JOURNEY_PLACEHOLDER = [
  "Клиентский путь: Подготовка руководителя к встрече",
  "Проект: Пульс 2.0",
  "",
  "## Сбор данных",
  "- Автоматический сбор метрик из системы",
  "- Формирование дашборда",
  "",
  "## Анализ",
  "- Сопоставление с планом",
  "",
  "## Решения",
].join("\n");

import type { NextRequest } from "next/server";

const backendUrl = process.env.PKO_BACKEND_URL ?? "http://127.0.0.1:8000";

// `rewrites()` в next.config.ts проксирует `/api/*` на FastAPI, но dev-прокси
// Next.js падает (500 plain-text) на multipart-телах крупнее ~8 МБ. Route
// Handler перехватывает POST (встроенные маршруты матчатся раньше rewrites) и
// стримит тело запроса на бэкенд через fetch, минуя лимит прокси. GET-запросы
// (`/api/analyses/{id}`, `/api/analyses/{id}/events`) идут через rewrites как
// раньше — у них нет тела и лимит не срабатывает.
export async function POST(request: NextRequest) {
  const headers: Record<string, string> = {};
  const contentType = request.headers.get("content-type");
  if (contentType) {
    headers["content-type"] = contentType;
  }

  try {
    const resp = await fetch(`${backendUrl}/api/analyses`, {
      method: "POST",
      body: request.body,
      headers,
      duplex: "half",
    } as RequestInit);

    const text = await resp.text();
    return new Response(text, {
      status: resp.status,
      headers: {
        "content-type": resp.headers.get("content-type") ?? "application/json",
      },
    });
  } catch {
    return new Response(
      JSON.stringify({
        message: "Бэкенд недоступен.",
        hint: `проверьте, что pko serve запущен на ${backendUrl}`,
      }),
      { status: 502, headers: { "content-type": "application/json" } },
    );
  }
}

# CLAUDE.md — PKO progress

Контекст проекта для Claude Code. Лежит в корне репозитория.

## Что это

Инструмент сверяет **образ результата инициативы** (этапы и буллиты текстом)
с кодом целевого репозитория и выпускает отчёт о готовности с решением
**GO / PIVOT**.

Три команды:

- `pko parse` — разобрать файл инициативы, ничего не запуская: видно, какой
  формат опознан, сколько буллитов и что попало в дословный хвост.
- `pko progress` — полный прогон: репозиторий/ZIP + текст → HTML-отчёт.
- `pko serve` — веб-интерфейс (загрузка → SSE-прогресс → дашборд).

## Главный принцип: LLM предлагает, код проверяет

Это не лозунг, а архитектурное ограничение. Нарушать его нельзя ни в бэкенде,
ни в шаблонах, ни во фронтенде.

1. **Клон только на чтение.** Мутирующие git-подкоманды падают до запуска git
   (`ALLOWED_SUBCOMMANDS` в `git/repo.py`). Мутации разрешены только в
   `git/remote.py` (`clone --mirror`, `fetch`). Инструменты агента не имеют
   пишущих операций; секреты маскируются; `.env*`, `*.pem`, `*.key` не читаются.
2. **Статус без проверенной ссылки не принимается.** Каждая evidence проходит
   `progress/verify.py`: путь и строка обязаны существовать, а рядом со
   строкой (или в имени объемлющего объявления) обязан найтись токен из
   основания. Список статусов, требующих подтверждения, выводится из шкалы —
   `schema.GROUNDED_STATUSES`, всё кроме `planned`.
3. **Свободный текст тоже проверяется.** Оба буллита раскрытия проходят
   `report/guard.py` (упоминание несуществующих путей) и `contains_code`
   (имена функций, пути, декораторы в тексте для человека).
4. **Готовность и решение вычисляет код.** `calculate_progress` и
   `compute_decision` — детерминированные функции в `progress/schema.py`. Ни
   модель, ни шаблон, ни JS не имеют права считать это самостоятельно.

Если правка добавляет вычисление статуса/процента/решения вне
`progress/schema.py` — это регресс, а не фича.

## Карта репозитория

```
backend/pko/
  cli.py           pko parse / progress / serve
  defaults.py      дефолтные репозиторий, ветка, LLM-эндпоинт
  errors.py        PkoError + GitError/SshAccessError/UrlError/
                   ExtractionError/ValidationError/LlmError
  git/             read-only обёртка: repo.py, remote.py, url.py
  extractors/      детерминированные факты из кода
                   base.py, runner.py, python_code.py, sql_code.py,
                   java_code.py, deps.py, contracts.py, policy_specs.py,
                   ownership.py, prompts.py, test_reports.py
  llm/             registry.py (ModelSpec), client.py (кеш), tracing.py
  progress/        text_input.py    общая чистка текста, маркеры, слаг
                   journey_text.py  ручной клиентский путь
                   agent_md.py      файл инициативы из колоды
                   plan_input.py    выбор формата по структуре
                   schema.py        модель + все детерминированные расчёты
                   verify.py        проверка ссылок на код
                   agent_tools.py   read-only инструменты агента
                   matcher.py       сессия агента и смысловые гейты
                   pipeline.py      текст + репозиторий → ProgressModel
                   target_repo.py, local_source.py
                   agent_system.md  системный промпт
  report/guard.py  сторож текста
  render/          base.py, progress_report.py,
                   dashboard_data.py     контракт отчёта (общий для веба и CLI)
                   dashboard_html.py     самодостаточный HTML
                   dashboard_template.html
  output/          publisher.py (атомарная запись отчётов)
  web/             app.py (FastAPI), analyses.py
  util/            env.py, paths.py, sources.py, yamlmini.py
  model/, intent/  наследие прежнего инструмента; живьём используется только
                   `model.taxonomy` и `model.schema` из экстракторов
frontend-web/      Next.js 16: загрузка → SSE прогресс → дашборд
frontend-app/      Vite + React: компонент пути для оффлайн-отчёта CLI
tests/             unittest, герметичный (без сети и без реального LLM)
```

## Команды

```bash
pip install -e .                  # editable-установка, даёт бинарь pko
python tests/run_tests.py         # 302 теста, должны быть зелёными
pko serve --port 8000             # бэкенд
cd frontend-web && npm run dev    # фронт на :3000, проксирует /api на :8000
cd frontend-web && npm run lint && npm run build
cd frontend-app && npm run build  # → dist/index.html, нужен для CLI-отчёта

pko parse --journey-file initiative.md
pko progress --journey-file initiative.md --repo-path /path/to/repo
```

## Ключевые контракты

**`build_dashboard_data(model)`** в `render/dashboard_data.py` — контракт между
бэкендом и обоими отчётами (`dashboard_template.html` и `Dashboard.tsx`).
Отдаёт `meta`, `readiness`, `items` (со строками `assessment`), `summary`,
`gaps`. Любое поле, которое читает шаблон, обязано появиться здесь; шаблон не
имеет права достраивать недостающее вычислением.

**Две шкалы весов** (`schema.py`), обе попадают в легенду отчёта через
`scale_rows()` — один источник для расчёта и для картинки:

| Статус | Подпись | Прототип | Пром |
|---|---|---|---|
| `done` | Работает | 100 | 100 |
| `limited` | Работает с ограничениями | 90 | 70 |
| `unused` | Код реализован, но не используется | 70 | 30 |
| `partial` | Не работает, реализовано частично | 50 | 20 |
| `planned` | Не реализовано | 0 | 0 |
| `blocked` | Блокирует | 0 | 0 |

Оценивается **прототип**, поэтому чисел два: `readiness` (по `POC_WEIGHT`) и
`readiness_prod` (по `PROD_WEIGHT`). Статус у буллита при этом один — модель
не оценивает пункт дважды и не может рассогласовать оценки, разницу держат
веса. Пром строже там, где пользователь результата не получает: ограничение —
дыра, неподключённый код для него не существует.

`calculate_progress` — сумма весов на число применимых буллитов; неприменимые
(`applicable=False`) **исключаются из знаменателя**. `READY_THRESHOLD = 40`,
решение считается по готовности прототипа: ≥40% → GO, иначе PIVOT.

**Раскрытие пункта — два буллита и шторка**, тексты человеческим языком:

- **«Проверка»** (`proof`) — есть ли код и работает ли он;
- **«Как работает»** (`how`) — что система умеет и каким образом;
- **«Ссылки на код»** (`links`) — закрытая шторка с `путь:строка · имя` и
  фразой, что там происходит.

Код в тексте любого из двух буллитов отклоняется гейтом: пути и имена живут в
шторке, а не в тексте для читателя.

**В шторку идут только подтверждённые ссылки.** Отклонённая остаётся в
`progress_model.json` (там нужен полный след проверки), но на экран не едет:
она ничего не доказывает, а рядом со статусом читается как доказательство.

**Четыре тематических блока.** Держится в двух местах: инструмент
`submit_groups` (модель объявляет 2–4 темы, дальше `group` обязана быть одной
из них) и `schema.limit_groups` как страховка, если инструмент не вызван.

## Подводные камни

- **`PKO_THINKING=False` обязателен для GLM-5.2.** С включённым thinking модель
  съедает бюджет на рассуждения и возвращает пустой ответ.
- **Кеш LLM** в `~/.pko/llm-cache`, ключ — sha256 payload (system prompt входит
  в payload, поэтому правка `agent_system.md` кеш инвалидирует). Повторный
  прогон того же коммита = 0 вызовов. Права 0o600 — там корпоративные данные.
- **Промпт и код обязаны совпадать.** Один живой прогон уже прошёл со старым
  промптом: он не упоминал полей `proof`/`how` — и модель не заполнила
  технический блок ни разу из двенадцати. Меняешь схему инструмента — правь
  `agent_system.md` в том же коммите.
- **BOM в CSS ломает первый блок правил.** В бандле он не в начале файла, и
  селектор превращается в `﻿ .dashboard-root` — правило не совпадает ни с
  чем, переменные не определяются, страница едет. Файлы фронтенда сохранять
  без BOM.
- **Тесты герметичны:** `ChatClient._create` подменяется скриптованными
  ответами из `tests/agent_script.py`, кеш уводится во временный каталог,
  фикстура `tests/fixtures/mini_repo` создаётся автоматически. Не добавлять
  тесты, которые ходят в сеть или клонируют реальный репозиторий.
- **`yamlmini.py`** — свой минимальный парсер вместо PyYAML. Не поддерживает
  anchors, merge keys, flow style. Не расширять его молча: на неподдерживаемом
  синтаксисе нужна явная ошибка, а не тихая деградация.
- **Задачи веба живут в памяти** (`MAX_JOBS = 100`, `queue.Queue`,
  daemon-поток). Рестарт сервера теряет всё, включая готовые анализы.
- **`frontend-app/dist/index.html`** должен быть собран, иначе
  `render_progress_report` падает с `PkoError("Дашборд-путь не собран")`.

## Пороги (справочник)

| Константа | Значение | Где |
|---|---|---|
| `DEFAULT_MAX_STEPS` | 80 | matcher |
| `MAX_TOKENS_DEFAULT` / `MAX_TOKENS_THINKING` | 8192 / 16384 | matcher |
| `_MAX_MALFORMED` / `_REPEAT_STOP` | 3 / 3 | matcher |
| `_MAX_GATE_REJECTIONS` | 1 | matcher |
| `READY_THRESHOLD` | 40% | schema |
| `MAX_GROUPS` | 4 | schema |
| `MAX_LIST_FILES` / `MAX_READ_LINES` | 400 / 400 | agent_tools |
| `SEARCH_MAX_MATCHES` / `SEARCH_TIMEOUT_SECONDS` | 200 / 5.0 | agent_tools |
| `ANCHOR_WINDOW` / `MIN_ANCHOR` / `ENCLOSING_SCAN` | 5 строк / 4 символа / 300 строк | verify |
| `MAX_STAGES` / `MAX_BULLETS` | 20 / 60 | agent_md |
| `MAX_FILE_BYTES` | 2 МБ | чтение файла |
| `MAX_WORKSPACE_FILES` / `MAX_WORKSPACE_BYTES` | 5000 / 200 МБ | ZIP-гвард |

## Стиль работы

- Язык интерфейса, ошибок и отчётов — русский. Имена в коде — английские.
- Ошибки бросать как `PkoError(message, hint)`: `message` — что случилось,
  `hint` — что делать человеку.
- Новый детерминированный расчёт — в `schema.py`, с тестом.
- Правка шаблона `dashboard_template.html` не должна вводить вычислений,
  дублирующих бэкенд; `Dashboard.tsx` и шаблон обязаны совпадать.
- После правок: `python tests/run_tests.py`, затем `npm run lint && npm run
  build` в `frontend-web`.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Генерация Excel-таблицы из test_results.txt.

Структура:
  - по вертикали (строки) — все 12 пунктов (буллитов)
  - по горизонтали — 4 конфигурации моделей, для каждой колонки "Результат" и "Комментарий"

Данные (результат + комментарий) взяты из одноимённых секций test_results.txt.
"""
import os

try:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
except ImportError as e:  # pragma: no cover
    raise SystemExit(
        "Не установлена библиотека openpyxl. Установите её командой: "
        "pip install openpyxl (исходная ошибка: %s)" % e
    )


# --------------------------------------------------------------------------- #
# Данные: 12 пунктов (буллитов) по 4 конфигурациям моделей.
# --------------------------------------------------------------------------- #

PUNKTS = [
    "Принимает от пользователя модель и запрос в произвольной текстовой форме.",
    "Производит необходимые расчёты по модели.",
    "Представляет пользователю детальные результаты выполненных расчётов.",
    "По запросу пользователя создаёт описание модели с анализом чувствительности.",
    "Выполняет сценарный анализ модели.",
    "В рамках сценарного анализа выполняет прямую оценку влияния inputs на outputs.",
    "Выполняет обратный подбор inputs для достижения заданных outputs.",
    "Позволяет корректировать параметры модели по запросу пользователя.",
    "Интегрирован с моделью консистентных inputs при её готовности.",
    "Формирует готовые для применения в материалах сделки формы документов.",
    "Реализованный функционал является основой для построения на следующих этапах "
    "автономного агента по созданию и анализу моделей.",
    "На следующих этапах автономный агент сможет выполнять создание и анализ моделей "
    "с учётом данных внешней среды и конкретного проекта.",
]

MODELS = ["GLM-5.2\nreasoning",
          "GLM-5.2\nno-reasoning",
          "DeepSeek-V4-Flash\nreasoning",
          "DeepSeek-V4-Flash\nno-reasoning"]


# Каждый кортеж: (пункт, [ (res_glm_r, comm_glm_r), (res_glm_nr, comm_glm_nr),
#                         (res_ds_r, comm_ds_r), (res_ds_nr, comm_ds_nr) ])
DATA = [
    (0, [
        ("done", "POST /upload принимает .xlsx, POST /invoke-agent принимает message "
                 "в произвольной текстовой форме (routers.py:24, 147)."),
        ("done", "POST /invoke-agent принимает message (произвольный текст), файл "
                 "загружается через /upload. Граф classifier→extract_excel_data→route→"
                 "analyze→reviewer обрабатывает запрос."),
        ("done", "POST /upload принимает xlsx, POST /invoke-agent принимает "
                 "произвольный текст message (router.py:120,148)."),
        ("done", "POST /upload принимает Excel-файл, POST /invoke-agent принимает "
                 "текстовый запрос в произвольной форме."),
    ]),
    (1, [
        ("done", "analyze_excel_model пересчитывает модель через LibreOffice Calc "
                 "(excel_handler.py:155 calculate). Тесты проверяют корректность "
                 "значений (test_tools_performance.py:131)."),
        ("done", "analyze_excel_model (tools.py:624) пересчитывает формулы через "
                 "compiled LibreOffice function, проходит все сценарии с "
                 "set_cell→calculate→get_cell."),
        ("done", "analyze_excel_model пересчитывает модель через LO compiled func "
                 "(tools.py:624,800)."),
        ("done", "Расчёты через LibreOffice Calc engine (lo_backend.py), сценарный "
                 "анализ и обратный подбор."),
    ]),
    (2, [
        ("done", "Результаты форматируются в текстовую таблицу (tools.py:876) и "
                 "сохраняются в Excel (tools.py:842). Текст возвращается пользователю "
                 "через txt_response.txt."),
        ("done", "Результаты форматируются в текстовую таблицу (tools.py:876), "
                 "reviewer (main_graph.py:272) формирует финальный ответ пользователю "
                 "на основе расчётов."),
        ("done", "reviewer формирует ответ, invoke_agent упаковывает txt_response.txt "
                 "(main_graph.py:272, router.py:192)."),
        ("done", "Reviewer форматирует результаты, ответ возвращается ZIP с "
                 "txt_response.txt."),
    ]),
    (3, [
        ("partial", "Описание модели есть (describe_outputs_sheet: горизонт, типы), "
                    "граф зависимостей есть, но нет формального анализа "
                    "чувствительности (эластичность, tornado). Описание базовое."),
        ("partial", "describe_outputs_sheet даёт описание модели, "
                    "generate_min_max_scenarios — min/max анализ, "
                    "build_dependency_graph — граф зависимостей. Но нет явного "
                    "анализа чувствительности как отдельного инструмента."),
        ("partial", "describe_outputs_sheet даёт описание модели, min/max сценарии — "
                    "частичная чувствительность; полноценного анализа "
                    "чувствительности нет."),
        ("partial", "describe_outputs_sheet даёт описание модели (горизонт, outputs), "
                    "но анализ чувствительности не выделен как отдельная функция — "
                    "только через сценарный анализ."),
    ]),
    (4, [
        ("done", "analyze_excel_model — «ГЛАВНЫЙ инструмент для сценарного анализа "
                 "что-если» (tools.py:624). Генерирует все комбинации входов "
                 "(tools.py:785), оценивает выходы."),
        ("done", "analyze_excel_model — главный инструмент сценарного анализа "
                 "«что-если»: генерирует все комбинации входных параметров (product) "
                 "и пересчитывает outputs для каждого сценария."),
        ("done", "analyze_excel_model генерирует комбинации сценариев и считает "
                 "outputs (tools.py:785)."),
        ("done", "analyze_excel_model выполняет сценарный анализ «что-если» с "
                 "пересчётом формул."),
    ]),
    (5, [
        ("done", "Прямая оценка: цикл по комбинациям inputs → func(*values) → чтение "
                 "outputs (tools.py:803-828). Compiled func: set inputs → calculateAll "
                 "→ read outputs (excel_handler.py:185)."),
        ("done", "analyze_excel_model меняет inputs (set_cell) и получает outputs "
                 "(func(*values)) для каждого сценария — прямая оценка влияния inputs "
                 "на outputs."),
        ("done", "для каждого набора inputs вычисляются outputs — прямая оценка "
                 "влияния (tools.py:802-828)."),
        ("done", "Прямая оценка: варьирует inputs, читает outputs через compiled func."),
    ]),
    (6, [
        ("done", "analyze_model_inputs_for_target подбирает inputs для целевого output: "
                 "grid search + scipy minimize (tools.py:170, 509). Тест: EBITDA "
                 "2026=1000, отклонение ~0% (test_tools_performance.py:192)."),
        ("done", "analyze_model_inputs_for_target (tools.py:170) + "
                 "optimize_with_regression (scipy minimize, tools.py:509) подбирают "
                 "inputs для целевого output. Тест (test_tools_performance.py:250) "
                 "подтверждает: EBITDA близко к целевому значению."),
        ("done", "analyze_model_inputs_for_target + optimize_with_regression подбирают "
                 "inputs под целевой output (tools.py:170,509)."),
        ("done", "Обратный подбор inputs для достижения целевого output через "
                 "generate_scenarios + optimize_with_regression."),
    ]),
    (7, [
        ("done", "modify_excel_input_value применяет выражения к inputs и возвращает "
                 "старые/новые outputs (tools.py:1485). Тест проверяет корректность "
                 "(test_tools_performance.py:262)."),
        ("done", "modify_excel_input_value (tools.py:1485) применяет выражения к inputs "
                 "и возвращает пересчитанные outputs. Тест (test_tools_performance.py:"
                 "262) верифицирует: x+100 для метанола, EBITDA 2025: 1083→1409."),
        ("done", "modify_excel_input_value корректирует inputs по выражению и "
                 "пересчитывает outputs (tools.py:1485)."),
        ("done", "modify_excel_input_value корректирует параметры модели по выражениям "
                 "(x+100 и т.д.)."),
    ]),
    (8, [
        ("planned", "Интеграция с моделью консистентных inputs не реализована — в коде "
                    "нет следов (поиск consistent/консистентн в src/ не дал "
                    "результатов)."),
        ("planned", "В коде нет упоминаний модели консистентных inputs. Поиск по "
                    "'consist' и 'консистентн' не нашёл интеграционного кода — только "
                    "упоминание 'консистентно' в AGENTS.md:57."),
        ("planned", "Модель консистентных inputs не реализована — упоминаний в коде "
                    "нет."),
        ("planned", "Интеграция с моделью консистентных inputs не реализована — нет "
                    "кода или ссылок на такую модель."),
    ]),
    (9, [
        ("partial", "Excel-документы генерируются (save_analysis_results:925, "
                    "create_scenario_matrix:1416), но invoke-agent возвращает ПУСТОЙ "
                    "Excel (routers.py:182). Результаты не доходят до клиента."),
        ("partial", "create_scenario_matrix и save_analysis_results генерируют "
                    "Excel-файлы с результатами. НО в router.py:195 ZIP-ответ содержит "
                    "ПУСТОЙ DataFrame (pd.DataFrame().to_excel) — реальные файлы не "
                    "отдаются пользователю."),
        ("planned", "Формы документов для материалов сделки не формируются; в ZIP "
                    "только txt_response и пустой agent_output.xlsx (router.py:192-196)."),
        ("partial", "agent_output.xlsx в ZIP — пустой DataFrame, не формируются готовые "
                    "формы документов для материалов сделки."),
    ]),
    (10, [
        ("done", "Набор инструментов (анализ, подбор, модификация, граф) + "
                 "LangGraph-агент (services.py:332) образуют основу для автономного "
                 "агента."),
        ("done", "Мультиагентный LangGraph (classifier→subagents→reviewer) с двумя "
                 "сабагентами (EMA и IFT) — архитектурная основа для автономного "
                 "агента. Граф компилируется и работает end-to-end."),
        ("planned", "Автономный агент по созданию/анализу моделей — заявлен как "
                    "будущий этап, не реализован."),
        ("done", "Мультиагентный граф (classifier → subagents → reviewer) — основа для "
                 "автономного агента."),
    ]),
    (11, [
        ("planned", "Автономное создание моделей и интеграция данных внешней среды не "
                    "реализованы — следующий этап. В коде нет следов external/внешн "
                    "интеграции."),
        ("planned", "В коде нет упоминаний автономного агента, внешних данных или "
                    "конкретного проекта. Поиск 'autonom', 'автономн', 'external "
                    "environ', 'внешн сред' — 0 совпадений. Это следующая фаза, не "
                    "реализована."),
        ("planned", "Учёт внешней среды и конкретного проекта автономным агентом — "
                    "будущий этап, не реализован."),
        ("planned", "Учёт данных внешней среды и конкретного проекта не реализован — "
                    "нет интеграции с внешними источниками данных."),
    ]),
]


# --------------------------------------------------------------------------- #
# Стили
# --------------------------------------------------------------------------- #
HEADER_FILL = PatternFill("solid", fgColor="305496")
HEADER_FONT = Font(bold=True, color="FFFFFF", size=11)
PUNKT_FONT = Font(bold=True, size=10)
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical="top", horizontal="left")
CENTER = Alignment(wrap_text=True, vertical="top", horizontal="center")

# Цвета статусов
STATUS_FILL = {
    "done": PatternFill("solid", fgColor="C6EFCE"),
    "partial": PatternFill("solid", fgColor="FFEB9C"),
    "planned": PatternFill("solid", fgColor="FFC7CE"),
}


def build_workbook():
    wb = Workbook()
    ws = wb.active
    ws.title = "Тест моделей"

    # Шапка: 1 строка — названия моделей (объединённые по 2 колонки),
    # 2 строка — "Результат" / "Комментарий"
    ws.cell(row=1, column=1, value="Пункт")
    col = 2
    for m in MODELS:
        ws.merge_cells(start_row=1, start_column=col, end_row=1, end_column=col + 1)
        cell = ws.cell(row=1, column=col, value=m)
        ws.cell(row=2, column=col, value="Результат")
        ws.cell(row=2, column=col + 1, value="Комментарий (подтверждение в коде)")
        col += 2

    # Стиль шапки
    for c in range(1, 9 + 1):
        h1 = ws.cell(row=1, column=c)
        h2 = ws.cell(row=2, column=c)
        h1.fill, h1.font = HEADER_FILL, HEADER_FONT
        h1.alignment = CENTER
        h1.border = BORDER
        h2.fill, h2.font = HEADER_FILL, HEADER_FONT
        h2.alignment = CENTER
        h2.border = BORDER

    # Данные
    for i, entry in enumerate(DATA):
        p_index, cells = entry
        row = 3 + i
        pc = ws.cell(row=row, column=1, value="[%d] %s" % (i + 1, PUNKTS[p_index]))
        pc.font = PUNKT_FONT
        pc.alignment = WRAP
        pc.border = BORDER

        col = 2
        for (status, comment) in cells:
            sc = ws.cell(row=row, column=col, value=status)
            sc.fill = STATUS_FILL.get(status, PatternFill())
            sc.alignment = CENTER
            sc.border = BORDER
            cc = ws.cell(row=row, column=col + 1, value=comment)
            cc.alignment = WRAP
            cc.border = BORDER
            col += 2

    # Ширины колонок
    ws.column_dimensions["A"].width = 55
    for idx in range(2, 10):
        letter = get_column_letter(idx)
        ws.column_dimensions[letter].width = 16 if idx % 2 == 0 else 70

    # Фиксация шапки
    ws.freeze_panes = "A3"

    return wb


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out_path = os.path.join(root, "reports", "test_results_models.xlsx")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    build_workbook().save(out_path)
    print("Готово:", out_path)


if __name__ == "__main__":
    main()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Проверка роли matcher через рабочую цепочку проекта (см. DEEPSEEK_MIGRATION.md §8).

Отличается от scripts/smoke_deepseek.py тем, что идёт не сырым httpx, а через
`load_env()` → `registry.get_spec()` → `ChatClient`: подтверждает, что `.env`,
mTLS-серты и режим рассуждения подхватываются из нужных мест, а не только что
эндпоинт жив.

Кеш ответов отключён — иначе промахнётся мимо сети и ничего не проверит.

Запуск:
    .venv/bin/python scripts/verify_model.py
    .venv/bin/python scripts/verify_model.py --thinking
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

from pko.llm.client import ChatClient          # noqa: E402
from pko.llm.registry import get_spec          # noqa: E402
from pko.util.env import load_env              # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Проверка LLM-роли matcher")
    parser.add_argument("--thinking", action="store_true",
                        help="проверить с включённым рассуждением (PKO_THINKING)")
    args = parser.parse_args()

    load_env()
    spec = get_spec("matcher", thinking=True if args.thinking else None)
    if spec is None:
        print("Роль matcher не настроена: endpoint не задан.", file=sys.stderr)
        return 2

    print("Конфигурация роли:")
    for key, value in spec.masked().items():
        print(f"  {key}: {value}")
    print(f"  upstream_model: {spec.upstream_model!r}")
    print(f"  extra_body: {spec.extra_body}")

    client = ChatClient(spec=spec, use_cache=False)
    if not client.health():
        print("\nhealth: НЕВЕРНО — GET /models недоступен (сеть, mTLS, base_url).",
              file=sys.stderr)
        return 1
    print("\nhealth: OK (GET /models с клиентским сертификатом)")

    # max_tokens заведомо с запасом: при включённом thinking рассуждение съедает
    # бюджет целиком и content приходит пустым (§7.2).
    result = client.chat([{"role": "user", "content": "Скажи 'пинг' и больше ничего."}],
                         max_tokens=4096)
    print(f"ответ: {result.text[:120]!r}")
    print(f"рассуждение: {'есть' if result.reasoning_content else 'нет'}")
    print(f"токены: {result.usage}")
    if not result.text:
        print("Пустой content: увеличьте max_tokens или выключите thinking.", file=sys.stderr)
        return 1
    print("\nВывод: роль работает на сконфигурированной модели.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Smoke-тест mTLS-эндпоинта DeepSeek-V4-Flash (см. certs/DEEPSEEK_MIGRATION.md §3).

Проверяет все четыре комбинации verify/cert, чтобы подтвердить:
  (а) эндпоинт требует mTLS, (б) серты из certs/ к нему подходят,
  (в) рабочая комбинация — verify=CERT_NONE + клиентский серт.

Запуск:
    .venv/bin/python scripts/smoke_deepseek.py
    .venv/bin/python scripts/smoke_deepseek.py --chat     # + POST /chat/completions
"""
from __future__ import annotations

import argparse
import ssl
import sys
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent.parent
CERT_DIR = ROOT / "certs"
CLIENT_CRT = CERT_DIR / "deepsearch-gp-sberca-client.crt"
CLIENT_KEY = CERT_DIR / "deepsearch-gp-sberca-client.key"
CA_CRT = CERT_DIR / "deepsearch-gp-sberca-ca.crt"

BASE = ("https://ingressgateway-ai-hub-ci11758197-models-ift"
        ".apps.bbwo1z5h.k8s.delta.sbrf.ru/deepseek-v4-flash/v1")
TIMEOUT = 20.0


def _ctx(*, verify_ca: bool, with_cert: bool) -> ssl.SSLContext:
    """SSLContext: verify=CA либо CERT_NONE, с клиентским сертом либо без."""
    ctx = ssl.create_default_context()
    if verify_ca:
        ctx.load_verify_locations(cafile=str(CA_CRT))
    else:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    if with_cert:
        ctx.load_cert_chain(certfile=str(CLIENT_CRT), keyfile=str(CLIENT_KEY))
    return ctx


def probe(label: str, *, verify_ca: bool, with_cert: bool) -> str | None:
    try:
        with httpx.Client(verify=_ctx(verify_ca=verify_ca, with_cert=with_cert),
                          timeout=TIMEOUT) as client:
            resp = client.get(f"{BASE}/models")
        print(f"[{label}] HTTP {resp.status_code}  body[:160]={resp.text[:160]!r}")
        return resp.text if resp.status_code == 200 else None
    except Exception as exc:  # noqa: BLE001 — smoke-тест показывает всё как есть
        cause = getattr(exc, "__cause__", None) or exc
        text = str(cause)
        print(f"[{label}] EXC {type(exc).__name__}: {exc}")
        if cause is not exc:
            print(f"          cause: {type(cause).__name__}: {cause}")
        return None


def chat_probe() -> None:
    """POST /chat/completions через рабочую комбинацию (§7.2: max_tokens >= 4096)."""
    with httpx.Client(verify=_ctx(verify_ca=False, with_cert=True), timeout=120.0) as client:
        resp = client.post(f"{BASE}/chat/completions", json={
            "model": "",
            "messages": [{"role": "user", "content": "Скажи 'пинг' и больше ничего."}],
            "temperature": 0.0,
            "max_tokens": 4096,
            "chat_template_kwargs": {"enable_thinking": False},
        })
    print(f"\n[chat] HTTP {resp.status_code}")
    if resp.status_code != 200:
        print(f"  body[:300]={resp.text[:300]!r}")
        return
    message = resp.json()["choices"][0]["message"]
    print(f"  content={str(message.get('content'))[:120]!r}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Smoke-тест DeepSeek mTLS")
    parser.add_argument("--chat", action="store_true",
                        help="дополнительно проверить POST /chat/completions")
    args = parser.parse_args()

    for path in (CLIENT_CRT, CLIENT_KEY, CA_CRT):
        if not path.exists():
            print(f"Нет файла: {path}", file=sys.stderr)
            return 2

    print("== A) verify=CA, без клиентского серта ==")
    probe("verify=CA, no-cert", verify_ca=True, with_cert=False)
    print("\n== B) verify=CA + клиентский серт ==")
    probe("verify=CA + cert", verify_ca=True, with_cert=True)
    print("\n== C) verify=CERT_NONE + клиентский серт  (ожидаемо рабочая) ==")
    body = probe("CERT_NONE + cert", verify_ca=False, with_cert=True)
    print("\n== D) verify=CERT_NONE, без клиентского серта ==")
    probe("CERT_NONE, no-cert", verify_ca=False, with_cert=False)

    if args.chat and body:
        chat_probe()

    if body:
        print("\nВывод: [C] вернул 200 — серты подходят, можно переключаться на DeepSeek.")
        return 0
    print("\nВывод: рабочая комбинация не ответила 200 — проверьте сеть/сертификаты.",
          file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
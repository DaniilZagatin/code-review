#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Переключение LLM-роли агента (matcher) между GLM и сертовым DeepSeek.

`.env` подхватывается с `override=True` (pko/util/env.py) и потому является
источником истины для развёрнутого агента: что в нём — то и работает. Правим
его точечно: только переменные LLM-роли, остальные строки (в том числе ключи
других сервисов) сохраняются байт в байт.

Значения в консоль не печатаются — замаскировано всё, что не является путём,
эндпоинтом или именем модели. Перед записью создаётся `.env.bak` (0600, в
gitignore через `*.bak`), поэтому возврат к прежней конфигурации не теряет
ключ GLM.

Запуск:
    .venv/bin/python scripts/use_deepseek.py --dry-run   # что изменится
    .venv/bin/python scripts/use_deepseek.py             # переключить на DeepSeek
    .venv/bin/python scripts/use_deepseek.py --to glm    # вернуть на GLM
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

from pko.util.paths import harden_file  # noqa: E402

ENV_FILE = ROOT / ".env"
BACKUP_FILE = ROOT / ".env.bak"

DEEPSEEK_BASE_URL = ("https://ingressgateway-ai-hub-ci11758197-models-ift"
                     ".apps.bbwo1z5h.k8s.delta.sbrf.ru/deepseek-v4-flash/v1")
GLM_BASE_URL = "http://tpgds-aihub0009.delta.sbrf.ru:2717/v1"

# Ключевые слова профиля: (окончание переменной → значение).
PROFILES = {
    "deepseek": {
        "BASE_URL": DEEPSEEK_BASE_URL,
        "MODEL": "deepseek-v4-flash",
        # mTLS: ключ эндпоинту не нужен, но пустое поле registry.py прочитает
        # как «ключа нет» и возьмёт следующую по списку переменную — а там
        # настоящий ключ GLM (GLM_API_KEY), который улетел бы в DeepSeek.
        # Заглушка перекрывает цепочку поиска и одновременно сохраняет
        # прежний ключ для возврата на GLM.
        "API_KEY": "1",
        "CLIENT_CERT": str(ROOT / "certs" / "deepsearch-gp-sberca-client.crt"),
        "CLIENT_KEY": str(ROOT / "certs" / "deepsearch-gp-sberca-client.key"),
    },
    "glm": {
        "BASE_URL": GLM_BASE_URL,
        "MODEL": "GLM-5.2",
        "API_KEY": "1",
        # Пустые пути — «эндпоинт без mTLS»: registry.py не строит http_client,
        # клиент работает как раньше (обратная совместимость).
        "CLIENT_CERT": "",
        "CLIENT_KEY": "",
    },
}

FAMILIES = ("PKO_ASSEMBLER", "PKO_MATCHER")
# Роль matcher читает PKO_MATCHER_* поверх общих PKO_ASSEMBLER_*: если такая
# переменная в .env есть, она перекроет переключение, поэтому её тоже правим.
GENERIC_CERT_VARS = {"PKO_CLIENT_CERT": "CLIENT_CERT", "PKO_CLIENT_KEY": "CLIENT_KEY"}

# Не секреты: их показываем открыто, остальное — маскируем.
OPEN_SUFFIXES = ("BASE_URL", "MODEL", "CLIENT_CERT", "CLIENT_KEY")


def _mask(key: str, value: str) -> str:
    if key.endswith(OPEN_SUFFIXES):
        return value if value else "<пусто>"
    return "***" if value else "<пусто>"


def _line_re(var: str) -> re.Pattern[str]:
    """Строка вида `KEY=value` / `export KEY=value` (не комментарий)."""
    return re.compile(rf"^(\s*(?:export\s+)?{re.escape(var)}\s*=)(.*)$")


def _plan_vars(to: str) -> dict[str, str]:
    """Переменные, которые нужно установить: family.SUFFIX → значение."""
    profile = PROFILES[to]
    return {f"{family}_{suffix}": value
            for family in FAMILIES for suffix, value in profile.items()}


def switch(to: str, *, dry_run: bool, backup: bool) -> int:
    if not ENV_FILE.exists():
        print(f"Нет файла {ENV_FILE} — переключать нечего; создайте его из "
              f".env.example.", file=sys.stderr)
        return 2

    lines = ENV_FILE.read_text(encoding="utf-8").splitlines()
    wanted = _plan_vars(to)
    # Только те, чьё значение действительно отличается от текущего — иначе
    # «переключили» ради ничего и потеряли полезную информацию в диффе.
    current = _read_vars(lines)
    changes = {var: val for var, val in wanted.items()
               if var in current and current[var] != val}
    # PKO_MATCHER_* и PKO_CLIENT_* правим, только если они уже заданы:
    # добавлять их с нуля значит создать переменную, которой оператор не хотел.
    changes = {var: val for var, val in changes.items()
               if var.startswith("PKO_ASSEMBLER_") or var in current}

    # Чего не хватает вовсе — добавим в конец (ASSEMBLER-семья обязательна).
    missing = {var: val for var, val in wanted.items()
               if var not in current and var.startswith("PKO_ASSEMBLER_")}

    if not changes and not missing:
        print(f"Уже настроено на {to}: переменные LLM-роли соответствуют.")
        return 0

    out: list[str] = []
    seen: set[str] = set()
    for line in lines:
        var, value = _split(line)
        if var in wanted:
            if var in seen:
                # Дубль той же переменной: dotenv побеждает последнее, то есть
                # строка ниже. Оставлять две с разными значениями — ловушка.
                print(f"  удалён дубль {var}={_mask(var, value)}")
                continue
            seen.add(var)
            new_value = wanted[var]
            out.append(f"{var}={new_value}")
            if var in changes:
                print(f"  {var}: {_mask(var, value)} → {_mask(var, new_value)}")
            continue
        out.append(line)

    if missing:
        out.append("")
        out.append(f"# LLM-роль matcher: {to} (добавлено scripts/use_deepseek.py)")
        for var, value in missing.items():
            out.append(f"{var}={value}")
            print(f"  + {var}={_mask(var, value)}")

    print(f"\nПрофиль: {to}")
    for var, value in wanted.items():
        if var.startswith("PKO_ASSEMBLER_") or var in current:
            print(f"  {var} = {_mask(var, value)}")

    if dry_run:
        print("\n--dry-run: файл не изменён.")
        return 0

    if backup:
        BACKUP_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
        harden_file(BACKUP_FILE)
        print(f"Резервная копия: {BACKUP_FILE}")

    ENV_FILE.write_text("\n".join(out) + "\n", encoding="utf-8")
    harden_file(ENV_FILE)
    print(f"Записано: {ENV_FILE}")
    print("Перезапустите `pko serve` — переменные читаются при старте процесса.")
    return 0


def _split(line: str) -> tuple[str | None, str]:
    """Имя переменной и значение из строки; None — не присваивание/комментарий."""
    match = re.match(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=(.*)$", line)
    if not match:
        return None, ""
    return match.group(1), match.group(2).strip().strip("'\"")


def _read_vars(lines: list[str]) -> dict[str, str]:
    """Текущие значения: при дублях — то, что реально победит (последнее)."""
    found: dict[str, str] = {}
    for line in lines:
        var, value = _split(line)
        if var:
            found[var] = value
    return found


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Переключение LLM-роли агента между GLM и сертовым DeepSeek")
    parser.add_argument("--to", choices=tuple(PROFILES), default="deepseek",
                        help="целевой профиль (по умолчанию deepseek)")
    parser.add_argument("--dry-run", action="store_true", help="только показать изменения")
    parser.add_argument("--no-backup", action="store_true",
                        help="не создавать .env.bak")
    args = parser.parse_args()

    cert = PROFILES[args.to].get("CLIENT_CERT", "")
    if cert and not Path(cert).exists():
        print(f"Нет файла сертификата: {cert}", file=sys.stderr)
        return 2
    key = PROFILES[args.to].get("CLIENT_KEY", "")
    if key and not Path(key).exists():
        print(f"Нет файла ключа: {key}", file=sys.stderr)
        return 2

    return switch(args.to, dry_run=args.dry_run, backup=not args.no_backup)


if __name__ == "__main__":
    raise SystemExit(main())
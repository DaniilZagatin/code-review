#!/usr/bin/env python3
"""Тестовый прогон: 10 на GLM, 10 на DeepSeek, по 5 с reasoning и без.

Запуск:
    PYTHONPATH=backend .venv/bin/python scripts/run_tests_live.py

Результат — в файле test_results.txt.
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

JOURNEY_TEXT = """Клиентский путь
## Подготовка клиента к встречи
## Решение вопроса клиента
## Определение подходящего предложения
## Детальный анализ сделки
- Принимает от пользователя модель и запрос в произвольной текстовой форме.
- Производит необходимые расчёты по модели.
- Представляет пользователю детальные результаты выполненных расчётов.
- По запросу пользователя создаёт описание модели с анализом чувствительности.
- Выполняет сценарный анализ модели.
- В рамках сценарного анализа выполняет прямую оценку влияния inputs на outputs.
- Выполняет обратный подбор inputs для достижения заданных outputs.
- Позволяет корректировать параметры модели по запросу пользователя.
- Интегрирован с моделью консистентных inputs при её готовности.
- Формирует готовые для применения в материалах сделки формы документов.
- Реализованный функционал является основой для построения на следующих этапах автономного агента по созданию и анализу моделей.
- На следующих этапах автономный агент сможет выполнять создание и анализ моделей с учётом данных внешней среды и конкретного проекта.
"""

REPO_URL = "ssh://git@stash.delta.sbrf.ru:7999/dsd3k/dkkk_copilot.git"
BRANCH = "copilot_dev"

GLM_CONFIG = {
    "PKO_ASSEMBLER_BASE_URL": "http://tpgds-aihub0009.delta.sbrf.ru:2717/v1",
    "PKO_ASSEMBLER_MODEL": "GLM-5.2",
    "PKO_ASSEMBLER_API_KEY": "1",
    "PKO_ASSEMBLER_CLIENT_CERT": "",
    "PKO_ASSEMBLER_CLIENT_KEY": "",
}

DEEPSEEK_CONFIG = {
    "PKO_ASSEMBLER_BASE_URL": "https://ingressgateway-ai-hub-ci11758197-models-ift.apps.bbwo1z5h.k8s.delta.sbrf.ru/deepseek-v4-flash/v1",
    "PKO_ASSEMBLER_MODEL": "deepseek-v4-flash",
    "PKO_ASSEMBLER_API_KEY": "1",
    "PKO_ASSEMBLER_CLIENT_CERT": str(ROOT / "certs" / "deepsearch-gp-sberca-client.crt"),
    "PKO_ASSEMBLER_CLIENT_KEY": str(ROOT / "certs" / "deepsearch-gp-sberca-client.key"),
}

OUTPUT_FILE = ROOT / "test_results.txt"
OUTPUT_FILE_WAVE2 = ROOT / "test_results_wave2.txt"
OUTPUT_FILE_WAVE3 = ROOT / "test_results_wave3.txt"

LLM_CACHE_DIR = Path.home() / ".pko" / "llm-cache"

OUTPUT_BY_WAVE = {1: OUTPUT_FILE, 2: OUTPUT_FILE_WAVE2, 3: OUTPUT_FILE_WAVE3}


def set_env(config: dict[str, str]) -> None:
    for key, val in config.items():
        if val:
            os.environ[key] = val
        else:
            os.environ.pop(key, None)


def format_run(label: str, thinking: bool, start_str: str, elapsed: float,
               model, error: str | None) -> str:
    lines: list[str] = []
    lines.append("=" * 70)
    lines.append(f"Модель: {label}")
    lines.append(f"Reasoning: {'включён' if thinking else 'выключен'}")
    lines.append(f"Запуск: {start_str}")
    lines.append(f"Длительность: {elapsed:.1f}с")

    if error:
        lines.append(f"Ошибка: {error}")
        lines.append("")
        return "\n".join(lines)

    lines.append(f"Готовность: {model.readiness}%")
    decision = model.summary.decision if model.summary else "—"
    lines.append(f"Решение: {decision}")
    lines.append("")

    for verdict in model.verdicts:
        item = model.items.get(verdict.item_id)
        if item is None:
            continue
        lines.append(f"Этап: {item.title}")
        for text, criterion in zip(item.criteria, verdict.criteria):
            status = criterion.status if criterion.applicable else "неприменим"
            lines.append(f"  [{status}] {text}")
            if criterion.comment:
                lines.append(f"       ↳ {criterion.comment}")
        lines.append("")

    if model.summary:
        lines.append("Вывод:")
        for b in model.summary.conclusion:
            lines.append(f"  - {b}")

    lines.append("")
    return "\n".join(lines)


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Тестовый прогон моделей")
    parser.add_argument("--wave", type=int, default=1, choices=[1, 2, 3],
                        help="волна: 1 — с кэшем, 2 — с очисткой кэша, 3 — то же + новый детерминированный вердикт")
    args_wave = parser.parse_args()

    clear_cache = args_wave.wave in (2, 3)
    output_file = ROOT / f"test_results_wave{args_wave.wave}.txt"

    from pko.git.remote import DEFAULT_CACHE_ROOT, ensure_mirror
    from pko.git.repo import GitRepo
    from pko.git.url import parse_repo_url
    from pko.llm.registry import get_spec
    from pko.progress.pipeline import run_progress
    from pko.progress.target_repo import load_target

    ref = parse_repo_url(REPO_URL)
    print(f"Подготовка репозитория {ref.slug}…")
    info = ensure_mirror(
        REPO_URL,
        cache_root=Path(str(DEFAULT_CACHE_ROOT)).expanduser(),
        fetch=True, timeout=900,
    )
    repo = GitRepo(info.path, timeout=900)
    target = load_target(repo, BRANCH)
    name = ref.repo
    print(f"Готово: {name} · {target.branch} · {target.sha[:8]}")

    runs: list[tuple[str, dict, bool]] = []

    # 5 GLM с reasoning
    for i in range(5):
        runs.append((f"GLM-5.2 #{i+1} reasoning", GLM_CONFIG, True))
    # 5 GLM без reasoning
    for i in range(5):
        runs.append((f"GLM-5.2 #{i+1} no-reasoning", GLM_CONFIG, False))
    # 5 DeepSeek с reasoning
    for i in range(5):
        runs.append((f"DeepSeek-V4-Flash #{i+1} reasoning", DEEPSEEK_CONFIG, True))
    # 5 DeepSeek без reasoning
    for i in range(5):
        runs.append((f"DeepSeek-V4-Flash #{i+1} no-reasoning", DEEPSEEK_CONFIG, False))

    results: list[str] = []
    total = len(runs)

    # Прогресс-файл — пишем после каждого прогона, чтобы можно было следить.
    progress_file = ROOT / "test_results_wave3_progress.txt"

    header = (
        f"Тестирование моделей: GLM-5.2 vs DeepSeek-V4-Flash\n"
        f"Волна: {args_wave.wave} ({'с очисткой кэша' if clear_cache else 'с кэшем'})\n"
        f"Дата: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"Репозиторий: {REPO_URL} · ветка: {BRANCH}\n"
        f"Всего прогонов: {total}\n\n"
    )
    progress_file.write_text(header, encoding="utf-8")

    for idx, (label, config, thinking) in enumerate(runs, start=1):
        print(f"[{idx}/{total}] {label}…", flush=True)
        set_env(config)

        # Очистка кэша LLM перед каждым прогоном (волна 2/3).
        if clear_cache and LLM_CACHE_DIR.exists():
            import shutil
            shutil.rmtree(LLM_CACHE_DIR, ignore_errors=True)
            print(f"  кэш очищен: {LLM_CACHE_DIR}", flush=True)

        spec = get_spec("matcher", thinking=thinking)
        if spec is None:
            run_text = format_run(label, thinking, time.strftime("%Y-%m-%d %H:%M:%S"),
                                  0.0, None, "LLM не настроен")
            results.append(run_text)
            progress_file.write_text(header + "\n".join(results), encoding="utf-8")
            continue

        start = time.time()
        start_str = time.strftime("%Y-%m-%d %H:%M:%S")
        try:
            model = run_progress(JOURNEY_TEXT, name, target, spec, max_steps=60)
            elapsed = time.time() - start
            run_text = format_run(label, thinking, start_str, elapsed, model, None)
            results.append(run_text)
            print(f"  готовность {model.readiness}% · решение {model.decision} за {elapsed:.0f}с", flush=True)
        except Exception as exc:
            elapsed = time.time() - start
            run_text = format_run(label, thinking, start_str, elapsed, None, str(exc))
            results.append(run_text)
            print(f"  ошибка: {exc}", flush=True)

        # Дописываем результат в файл после каждого прогона.
        progress_file.write_text(header + "\n".join(results) + "\n", encoding="utf-8")

    output_file.write_text(header + "\n".join(results), encoding="utf-8")
    print(f"\nРезультаты: {output_file.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

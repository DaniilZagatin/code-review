"""Разбор файла инициативы в формате распарсенных колод SteerCo.

Формат отличается от того, что понимает `journey_text.py`. Там буллиты лежат
**под** каждым `##`; здесь сначала идут все заголовки этапов, затем все буллиты
образа результата, затем дословный хвост из колоды::

    Клиентский путь: Key Clients
    Проект: Copilot сотрудника ДККК по расчету CF моделей
    ## Подготовка к встрече с клиентом      ← 0..10 заголовков подряд
    ## Детальный анализ сделки
    - Принимает от пользователя модель…     ← 4..21 буллитов подряд
    - Производит необходимые расчёты…
    Длительный и ручной процесс CF-моделирования (до 36 часов)…  ← хвост
    - Принимает от пользователя модель…, производит расчеты

Ловушка, на которой ломается `parse_journey_text`: **дословный хвост сам
содержит строки с дефисом** — это буллиты исходного слайда. На корпусе из 102
файлов старый парсер падал на 20 и во всех 82 остальных затягивал хвост в
буллиты (в эталонном ДККК — 18 буллитов вместо 12, из них «Текущий опыт»
как будто это требование к системе, и дубль «Интегрирован с моделью
консистентных inputs»). Знаменатель готовности раздувался на 50%.

Граница проходит по первой непустой строке, которая не является буллитом.
Проверено на всех 102 файлах корпуса: разделение однозначно везде.

Этапы `##` идут до всех буллитов и с ними не связаны — привязать буллит к
этапу детерминированно невозможно, этой связи в файле нет. Поэтому этапы
хранятся как контекст пути, а буллиты образа результата — как критерии одного
`PlanItem` инициативы.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field

from pko.errors import PkoError
from pko.progress.journey_text import JourneyParse
from pko.progress.schema import PlanItem
from pko.progress.text_input import (
    bullet_text,
    is_bullet,
    normalize,
    plain_stage_title,
    slug as _slug,
)

_HASH_STAGE = re.compile(r"^##+\s*(.+)$")


def _stage_title(line: str) -> str:
    """Название этапа, если строка — заголовок. Иначе пустая строка."""
    match = _HASH_STAGE.match(line)
    if match:
        return match.group(1).strip()
    return plain_stage_title(line)


def _is_stage(line: str) -> bool:
    return bool(_stage_title(line))


_JOURNEY_KEYS = {"клиентский путь", "путь"}
_PROJECT_KEYS = {"проект", "инициатива"}

MAX_STAGES = 20
MAX_BULLETS = 60
MAX_BULLET_CHARS = 600
MAX_TITLE_CHARS = 200

# Маркеры блока эффекта в дословном хвосте. Эффект цитируется, не считается —
# см. METHODOLOGY.md §8.
_EFFECT_MARKERS = (
    "ключевые источники эффекта", "ожидаемый эффект", "ожидания:",
    "эффект:", "as is", "to be", "value to cost",
)


@dataclass(frozen=True)
class AgentPlan:
    """Разобранный файл инициативы."""

    journey: str
    project: str
    stages: list[str] = field(default_factory=list)
    bullets: list[str] = field(default_factory=list)
    context: dict[str, str] = field(default_factory=dict)
    source_text: str = ""
    source_digest: str = ""
    notes: list[str] = field(default_factory=list)

    @property
    def effect_quotes(self) -> list[str]:
        found: list[str] = []
        for chunk in _split_sentences(self.source_text):
            if any(marker in chunk.lower() for marker in _EFFECT_MARKERS):
                cleaned = chunk.strip()
                if cleaned and cleaned not in found:
                    found.append(cleaned)
        return found[:6]

    def to_journey_parse(self) -> JourneyParse:
        """Привести к контракту, который ждёт остальной пайплайн."""
        context = {
            "client_path_name": self.journey,
            "project_name": self.project,
            "source_digest": self.source_digest,
        }
        context.update(self.context)
        if self.stages:
            context["stages"] = " · ".join(self.stages)
        item = PlanItem(
            id=_slug(self.project) or "initiative",
            title=self.project,
            description="",
            criteria=list(self.bullets),
            origin="agent_md",
        )
        return JourneyParse(items=[item], context=context)


def looks_like_agent_md(text: str) -> bool:
    """Отличить формат колоды от ручного клиентского пути.

    По шапке различить нельзя: «Клиентский путь:» и «Проект:» есть у обоих.
    Различает структура:

    * в формате колоды все `##` идут подряд до первого буллита, а буллиты —
      сплошным блоком, за которым следует дословный хвост;
    * в ручном формате буллиты лежат под каждым `##`, то есть хотя бы один
      буллет встречается раньше последнего заголовка.

    Ошибиться нельзя в обе стороны: принять ручной путь за колоду — свалить
    все этапы в один; принять колоду за ручной путь — затянуть дословный
    хвост в буллиты и раздуть знаменатель готовности.
    """
    normalized = normalize(text)
    lines = normalized.split("\n")

    head = lines[:12]
    has_journey = any(_key_of(line) in _JOURNEY_KEYS for line in head)
    has_project = any(_key_of(line) in _PROJECT_KEYS for line in head)
    if not (has_journey and has_project):
        # Шапки может не быть вовсе: пользователь вставляет название пути,
        # под ним названия этапов обычными строками, а буллиты — маркером.
        # Тогда формат опознаётся по разметке: всё немаркированное сверху,
        # все маркированные буллиты снизу.
        return _looks_like_bare_deck(lines)

    stage_positions = [i for i, line in enumerate(lines) if _is_stage(line)]
    # Буллиты приходят и без дефиса: обычная строка под этапом — тоже пункт.
    bullet_positions = [
        i for i, line in enumerate(lines)
        if line.strip() and not _is_stage(line) and (is_bullet(line) or not _key_of(line))
    ]
    if not bullet_positions:
        return False

    if len(stage_positions) >= 2:
        # В ручном формате буллиты лежат под каждым этапом, поэтому хотя бы
        # один встречается раньше последнего заголовка. В колоде — ни одного.
        return bullet_positions[0] > stage_positions[-1]

    if stage_positions:
        # Один этап: оба разбора дают одно и то же, различает только хвост.
        return _has_tail(lines, bullet_positions[0])

    # Без заголовков ручной формат вообще не читается (он требует этапов).
    return True


def _looks_like_bare_deck(lines: list[str]) -> bool:
    """Формат без шапки: заголовки сверху обычными строками, буллиты снизу.

    Требуется, чтобы буллиты были явно размечены маркером и ни одной
    немаркированной строки после первого из них не встречалось: иначе это
    ручной путь с этапами между пунктами, и разбирать его надо иначе.
    """
    marked = [i for i, line in enumerate(lines) if is_bullet(line)]
    if len(marked) < 2:
        return False
    bare = [
        i for i, line in enumerate(lines)
        if line.strip() and not is_bullet(line)
    ]
    if not bare:
        return False
    return max(bare) < min(marked)


def _has_tail(lines: list[str], first_bullet: int) -> bool:
    """Есть ли дословный хвост после сплошного блока дефисных буллитов."""
    index = first_bullet
    while index < len(lines) and (is_bullet(lines[index]) or not lines[index].strip()):
        index += 1
    return index < len(lines)


def _key_of(line: str) -> str:
    key, sep, _ = line.strip().partition(":")
    return key.strip().lower() if sep else ""


def parse_agent_md(text: str, filename: str = "") -> AgentPlan:
    if not (text or "").strip():
        raise PkoError(
            "Файл инициативы пуст.",
            hint="ожидается файл с «Клиентский путь:», «Проект:» и списком буллитов",
        )

    normalized = normalize(text)
    lines = normalized.split("\n")
    total = len(lines)
    notes: list[str] = []

    journey = ""
    project = ""
    context: dict[str, str] = {}

    index = 0
    while index < total:
        line = lines[index]
        stripped = line.strip()
        if not stripped:
            index += 1
            continue
        if _is_stage(line) or is_bullet(line):
            break
        key, sep, value = stripped.partition(":")
        if not sep or len(key) > 60:
            break
        low = key.strip().lower()
        if low in _JOURNEY_KEYS and not journey:
            journey = value.strip()
        elif low in _PROJECT_KEYS and not project:
            project = value.strip()
        else:
            context[key.strip()] = value.strip()
        index += 1

    stages: list[str] = []

    if not journey and not project and _looks_like_bare_deck(lines):
        # Шапки нет: первая обычная строка — название пути, следующие до
        # первого маркированного буллита — названия этапов.
        bare: list[str] = []
        while index < total and not is_bullet(lines[index]):
            stripped = lines[index].strip()
            if stripped:
                bare.append(_stage_title(lines[index]) or stripped)
            index += 1
        if bare:
            journey = bare[0]
            stages = [name[:MAX_TITLE_CHARS] for name in bare[1:]]
        # Отдельного названия инициативы во вводе нет — берём название пути,
        # иначе у отчёта не будет заголовка.
        project = journey
        notes.append(
            "В тексте нет строк «Клиентский путь:» и «Проект:» — название пути "
            "взято из первой строки, названия этапов из следующих."
        )

    while index < total:
        title = _stage_title(lines[index])
        if title:
            stages.append(title[:MAX_TITLE_CHARS])
            index += 1
            continue
        if not lines[index].strip():
            index += 1
            continue
        break

    raw_bullets: list[str] = []
    dashed = any(is_bullet(line) for line in lines[index:])
    if dashed:
        # Буллиты помечены дефисом: блок заканчивается на первой непустой
        # строке без дефиса — дальше дословный хвост из колоды, который сам
        # содержит строки с дефисом и в оценку попадать не должен.
        started = False
        while index < total:
            line = lines[index]
            text_of_bullet = bullet_text(line)
            if text_of_bullet:
                raw_bullets.append(text_of_bullet)
                started = True
                index += 1
                continue
            if not line.strip():
                if not started:
                    index += 1
                    continue
                look = index
                while look < total and not lines[look].strip():
                    look += 1
                if look < total and is_bullet(lines[look]):
                    index = look
                    continue
                break
            break
    else:
        # Буллиты без дефиса: пунктом считается каждая непустая строка после
        # заголовков. Хвоста в таком вводе нет — отделять нечего.
        while index < total:
            line = lines[index].strip()
            if line:
                raw_bullets.append(line)
            index += 1

    source_text = "\n".join(lines[index:]).strip()

    where = f" ({filename})" if filename else ""
    if not journey:
        raise PkoError(
            f"В файле нет строки «Клиентский путь:»{where}.",
            hint="первая строка файла — «Клиентский путь: <название>»",
        )
    if not project:
        raise PkoError(
            f"В файле нет строки «Проект:»{where}.",
            hint="вторая строка файла — «Проект: <название инициативы>»",
        )
    if not raw_bullets:
        raise PkoError(
            f"В файле нет ни одного буллита образа результата{where}.",
            hint="буллиты — строки, начинающиеся с «- ». Без них оценивать нечего",
        )

    if len(stages) > MAX_STAGES:
        notes.append(f"Этапов больше {MAX_STAGES}, лишние отброшены.")
        stages = stages[:MAX_STAGES]
    if len(raw_bullets) > MAX_BULLETS:
        notes.append(f"Буллитов больше {MAX_BULLETS}, лишние отброшены.")
        raw_bullets = raw_bullets[:MAX_BULLETS]
    if not source_text:
        notes.append("В файле нет дословного текста образа результата из колоды.")

    bullets: list[str] = []
    seen: dict[str, int] = {}
    for number, raw in enumerate(raw_bullets, start=1):
        cleaned = raw.strip()
        if len(cleaned) > MAX_BULLET_CHARS:
            cleaned = cleaned[:MAX_BULLET_CHARS].rstrip() + "…"
            notes.append(f"Буллит {number} обрезан до {MAX_BULLET_CHARS} символов.")
        key = re.sub(r"\W+", "", cleaned.lower())
        if key and key in seen:
            notes.append(f"Буллит {number} дублирует буллит {seen[key]}.")
        elif key:
            seen[key] = number
        bullets.append(cleaned)

    return AgentPlan(
        journey=journey[:MAX_TITLE_CHARS],
        project=project[:MAX_TITLE_CHARS],
        stages=stages,
        bullets=bullets,
        context=context,
        source_text=source_text,
        source_digest=hashlib.sha256(normalized.encode("utf-8")).hexdigest(),
        notes=notes,
    )


def _split_sentences(text: str) -> list[str]:
    parts: list[str] = []
    for line in (text or "").split("\n"):
        line = line.strip()
        if not line:
            continue
        for piece in re.split(r"(?<=[.;])\s+(?=[А-ЯA-Z«])", line):
            piece = piece.strip()
            if piece:
                parts.append(piece)
    return parts

"""Модель одного прогона: клиентский путь из образа результата и оценка его
этапов по материалам проекта.

Ключевой принцип новой версии — **тексты пути не пишет модель**. Названия
этапов, их описания и буллиты копируются из образа результата дословно и
живут в `PlanItem`; вердикт (`ItemVerdict`) добавляет к ним только две вещи:
относится ли пункт к рассматриваемой инициативе и в каком он состоянии. Текст
и оценка разведены по разным объектам, поэтому переформулировать буллет
физически нечем: в вердикте для текста просто нет поля.

Это заменило прежнюю конструкцию, где модель сама сочиняла и этапы, и
формулировки возможностей. Она давала либо технический язык, либо — после
починки языка — гладкий, но не тот текст: отчёт переставал совпадать с
образом результата, который команда согласовала и по которому себя мерит.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

# Шкала готовности: в каком состоянии буллит образа результата в коде.
# Граница проходит не по тому, есть ли у агента тул, а по тому, отрабатывает
# ли сквозной путь и задействован ли написанный код в рабочем сценарии.
# `blocked` — не «хуже, чем planned», а другое: отсутствие результата
# блокирует следующий шаг.
CRITERION_STATUSES = ("done", "limited", "unused", "partial", "planned", "blocked")

# Оценивается прототип, а спрашивают с него по-разному. Поэтому шкал две, и
# статус у буллита один: код считает по нему оба числа, модель не оценивает
# один и тот же пункт дважды и не может их рассогласовать.
#
# ПРОТОТИП — доказана ли идея. Ограничение прототипу почти не мешает,
# написанный и рабочий код засчитывается, даже если его ещё не подключили.
POC_WEIGHT = {
    "done": 1.0,       # Работает
    "limited": 0.9,    # Работает с ограничениями
    "unused": 0.7,     # Код реализован, но не используется
    "partial": 0.5,    # Не работает, реализовано частично
    "planned": 0.0,    # Не реализовано
    "blocked": 0.0,
}
# ПРОМ — получает ли пользователь результат. Здесь ограничение это дыра, а
# неподключённый код пользователю не виден вовсе: функции для него нет.
PROD_WEIGHT = {
    "done": 1.0,
    "limited": 0.7,
    "unused": 0.3,
    "partial": 0.2,
    "planned": 0.0,
    "blocked": 0.0,
}
# Главная шкала — прототипная: по ней считается процент в шапке, процент
# этапа и решение. Прежнее имя оставлено, чтобы не переписывать вызовы.
CRITERION_WEIGHT = POC_WEIGHT
STATUS_LABEL = {
    "done": "Работает",
    "limited": "Работает с ограничениями",
    "unused": "Код реализован, но не используется",
    "partial": "Не работает, реализовано частично",
    "planned": "Не реализовано",
    "blocked": "Блокирует",
}

# Статусы прежних версий: старые прогоны и сохранённые модели не должны
# падать при чтении. `scaffold` («Почти нет», 30%) ближе всего к «Не работает,
# реализовано частично». Прежний `partial` («код есть, но к агенту не
# подключён») по смыслу стал нынешним `unused`, но переименовать его нечем:
# имя занято другим статусом, и молчаливая подмена переписала бы старые отчёты.
STATUS_ALIASES = {"scaffold": "partial"}

# Статусы, требующие подтверждения ссылкой на код: всё, кроме «не реализовано».
# Отсутствие результата ссылкой не доказывается, наличие — обязано. Список
# выводится из шкалы, а не перечисляется руками: новый статус иначе тихо
# проедет мимо гейта (так `limited` и `unused` какое-то время проезжали).
GROUNDED_STATUSES = tuple(s for s in CRITERION_STATUSES if s != "planned")


# Код в тексте для бизнеса: имена функций, пути к файлам, вызовы, декораторы.
# Такой текст читателю без технического контекста ничего не объясняет.
# CamelCase сюда не входит намеренно: в деловом тексте законно встречаются
# названия продуктов — LibreOffice, CyberPort, AppSec, — и запрещать их значит
# мешать писать по-человечески. Ловим то, что бывает только кодом.
_CODE_IN_TEXT = re.compile(
    r"(?:\b[\w/]+\.(?:py|ts|tsx|java|sql|json|yaml|yml)\b"    # путь к файлу
    r"|\b[a-zA-Z]\w*_\w+\b"                                   # snake_case
    r"|\b\w+\(\)"                                             # вызов функции
    r"|@\w+)"                                                 # декоратор
)


def contains_code(text: str) -> str:
    """Первый найденный кодовый фрагмент в тексте, иначе пустая строка."""
    match = _CODE_IN_TEXT.search(text or "")
    return match.group(0) if match else ""

# Решений на текущем шаге два: порог пройден или нет. «NO GO» снят
# сознательно — правило «≥50% → GO, иначе PIVOT» должен уметь пересказать
# любой читатель отчёта, а третье значение из него не выводится.
DECISIONS = ("GO", "PIVOT")

# Порог решения — по готовности прототипа: оценивается именно прототип, и
# спрашивать с него по промышленной планке на этом шаге не за что.
# Одно правило и ничего больше: так его может пересказать любой читатель
# отчёта, не заглядывая в документацию.
READY_THRESHOLD = 40


def scale_rows() -> list[dict[str, Any]]:
    """Шкала для легенды отчёта: ответ, оба веса и что он означает.

    Единственный источник и для расчёта, и для легенды: разойтись они не могут.
    `weight` — вес прототипа (по нему главный процент), `weight_prod` — вес
    промышленного решения.
    """
    meaning = {
        "done": "работает целиком, ограничений не найдено",
        "limited": "работает, но есть понятное ограничение",
        "unused": "код написан, но в рабочем сценарии не задействован",
        "partial": "сделана часть, сквозной путь не отрабатывает",
        "planned": "в коде не найдено",
    }
    rows = [
        {
            "status": status,
            "label": STATUS_LABEL[status],
            "weight": int(POC_WEIGHT[status] * 100),
            "weight_prod": int(PROD_WEIGHT[status] * 100),
            "meaning": meaning[status],
        }
        for status in ("done", "limited", "unused", "partial", "planned")
    ]
    rows.append({
        "status": "na",
        "label": "Не применимо",
        "weight": None,
        "weight_prod": None,
        "meaning": "пункт не про код — исключён из расчёта",
    })
    return rows


def compute_decision(readiness: int) -> str:
    """Решение по одному порогу готовности прототипа: ≥40% — GO, иначе PIVOT.

    Считает код, а не модель и не шаблон.
    """
    return "GO" if readiness >= READY_THRESHOLD else "PIVOT"


def decision_reason(readiness: int) -> str:
    """Строка расчёта под решением — чтобы бейдж не выглядел волшебным."""
    sign = "≥" if readiness >= READY_THRESHOLD else "<"
    return f"{readiness}% {sign} {READY_THRESHOLD}%"

# Столько тематических блоков помещается в отчёт, не превращая его в список
# из одного пункта на блок. Промпт просит того же, но одной просьбы мало:
# на живом прогоне модель выдала 11 групп на 12 буллитов.
MAX_GROUPS = 4
OTHER_GROUP = "Прочее"


def limit_groups(names: list[str], limit: int = MAX_GROUPS) -> dict[str, str]:
    """Свести группы к `limit` штукам. Возвращает отображение старое → новое.

    Крупные группы сохраняются как есть, мелкие сливаются в «Прочее».
    Порядок появления сохраняется, чтобы отчёт не перетасовывался между
    прогонами. Слияние честное: объединённый блок называется «Прочее», а не
    выдаёт разнородные пункты за одну тему.
    """
    order: list[str] = []
    counts: dict[str, int] = {}
    for name in names:
        clean = (name or "").strip() or "Функционал"
        if clean not in counts:
            counts[clean] = 0
            order.append(clean)
        counts[clean] += 1

    if len(order) <= limit:
        return {name: name for name in order}

    # Отдельным блоком остаётся только группа хотя бы из двух пунктов:
    # блок «1 из 1» ничего не группирует и место занимает зря. Из них
    # берутся самые крупные, при равенстве — встретившаяся раньше.
    ranked = sorted(
        (name for name in order if counts[name] > 1),
        key=lambda n: (-counts[n], order.index(n)),
    )
    keep = set(ranked[: limit - 1])
    return {name: (name if name in keep else OTHER_GROUP) for name in order}


def calculate_progress(
    criteria: list["CriterionVerdict"], weights: dict[str, float] | None = None,
) -> int | None:
    """Детерминированный расчёт готовности по списку буллитов.

    Формула — сумма весов на число применимых буллитов. Веса живут в
    `POC_WEIGHT` (по умолчанию) и `PROD_WEIGHT` и здесь не повторяются.

    Неприменимые буллиты (`applicable=False`) исключаются из знаменателя:
    декларация эффекта или список потребителей — не про код, и тянуть из-за
    них готовность вниз значит наказывать инициативу за формат слайда.
    Возвращает None, если применимых буллитов нет.
    """
    if not criteria:
        return None
    usable = [c for c in criteria if c.applicable]
    if not usable:
        return None
    table = weights if weights is not None else POC_WEIGHT
    total = sum(table.get(c.status, 0.0) for c in usable)
    return round(total / len(usable) * 100)


def calculate_prod_progress(criteria: list["CriterionVerdict"]) -> int | None:
    """Готовность промышленного решения — та же арифметика, строже веса."""
    return calculate_progress(criteria, PROD_WEIGHT)


def calculate_closed_share(criteria: list["CriterionVerdict"]) -> int | None:
    """Доля буллитов со статусом «Работает» — второе, более простое число.

    Расхождение с готовностью показывает, много ли пунктов держится на
    ограничениях, незадействованном коде и частичной реализации.
    """
    usable = [c for c in criteria if c.applicable]
    if not usable:
        return None
    return round(sum(1 for c in usable if c.status == "done") / len(usable) * 100)


@dataclass(frozen=True)
class PlanItem:
    """Один этап клиентского пути — дословно из текстового ввода.

    `criteria` — буллиты этапа в исходном порядке и исходной редакции. Они
    попадают сюда на фазе разбора текста и дальше не меняются: вердикт
    ссылается на них по позиции, а не пересылает текст заново.
    """

    id: str
    title: str
    description: str = ""
    criteria: list[str] = field(default_factory=list)
    origin: str = "user"

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "criteria": list(self.criteria),
            "origin": self.origin,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "PlanItem":
        return PlanItem(
            id=d["id"],
            title=d["title"],
            description=d.get("description", ""),
            criteria=list(d.get("criteria") or []),
            origin=d.get("origin", "user"),
        )


@dataclass(frozen=True)
class EvidenceRef:
    """Одна ссылка на материалы, подтверждающая состояние буллита.

    `verified=False` не отбрасывается — понижается и остаётся в модели с
    причиной: утверждение без доказательства не публикуется как «материалы
    показывают».
    """

    path: str
    line: int | None
    basis: str
    verified: bool
    reason: str
    # Роли («объявление», «подключение», «инструмент агента», «тест») здесь
    # были и убраны: они требовали от читателя знать разницу между ярлыками,
    # а от модели — расставлять их без ошибок. Не случилось ни того, ни
    # другого, зато один раз ярлык уже привёл к неверному понижению статуса.
    #
    # Что происходит в этой строке — одна фраза человеческим языком.
    # Без неё ссылка остаётся координатой: читатель видит «router.py:42»
    # и всё равно не знает, что там.
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path, "line": self.line, "basis": self.basis,
            "verified": self.verified, "reason": self.reason,
            "note": self.note,
        }


@dataclass
class CriterionVerdict:
    """Оценка одного буллита этапа: относится ли он к инициативе и что с ним.

    Текста здесь нет намеренно — он берётся из `PlanItem.criteria` по той же
    позиции. Модель не может ни переписать буллет, ни выбросить его, ни
    добавить новый: длина списка сверяется с планом.

    `applicable=False` — буллит не про эту инициативу. Тогда `status`
    игнорируется, пункт показывается серым и не участвует в расчёте
    готовности этапа. Это не «плохо» и не «не сделано»: чужой пункт не должен
    ни портить, ни улучшать картину.
    """

    applicable: bool = False
    status: str = ""
    # Раскрытие пункта — два буллита, и ничего больше:
    #   «Проверка»     → proof: есть ли код и работает ли он. Человеческим
    #                    языком: «код есть и работает», «код есть, но в
    #                    сценарии не задействован», «кода нет».
    #   «Как работает» → how: что система умеет и каким образом — обычными
    #                    словами, так, как это объяснили бы коллеге.
    # Ни в одном из двух нет ссылок на репозиторий: читатель отчёта не пойдёт
    # по пути к файлу, а проверка ссылок — дело кода, не глаз читателя.
    # Доказательства (`evidence`) остаются в модели и держат гейт статуса, но
    # на экран не выводятся.
    proof: str = ""
    how: str = ""
    # Поля прежних версий, читаются как запасной источник, чтобы сохранённые
    # прогоны не теряли текст: `business`/`comment` — это «как работает»,
    # `technical`/`why` — это «проверка».
    business: str = ""
    technical: str = ""
    why: str = ""
    comment: str = ""
    evidence: list[EvidenceRef] = field(default_factory=list)
    # Тематическая группа для вёрстки отчёта («Обработка запросов»).
    # Только оформление: на расчёт готовности не влияет никак.
    group: str = ""

    def __post_init__(self) -> None:
        # Статусы прежних версий приводим к нынешним здесь, а не только при
        # разборе ответа модели: сохранённые `progress_model.json` читаются
        # тем же классом и не должны падать после смены шкалы.
        self.status = STATUS_ALIASES.get(self.status, self.status)
        if self.status and self.status not in CRITERION_STATUSES:
            raise ValueError(f"неизвестный статус буллита: {self.status}")

    @property
    def weight(self) -> float:
        """Вес по шкале прототипа — главной."""
        return POC_WEIGHT.get(self.status, 0.0)

    @property
    def prod_weight(self) -> float:
        return PROD_WEIGHT.get(self.status, 0.0)

    @property
    def verified_evidence(self) -> list[EvidenceRef]:
        return [e for e in self.evidence if e.verified]

    @property
    def is_grounded(self) -> bool:
        """Есть ли подтверждение у заявленного прогресса.

        «Не реализовано» подтверждать нечем — отсутствие ссылкой не
        доказывается. Остальным статусам нужна хотя бы одна проверенная
        ссылка на код.
        """
        if not self.applicable or self.status == "planned":
            return True
        return bool(self.verified_evidence)

    @property
    def proof_text(self) -> str:
        """«Проверка». Прежние прогоны клали это в `technical` или `why`."""
        return self.proof or self.technical or self.why

    @property
    def how_text(self) -> str:
        """«Как работает». Прежние прогоны клали это в `business`/`comment`."""
        return self.how or self.business or self.comment

    def to_dict(self) -> dict[str, Any]:
        return {
            "applicable": self.applicable,
            "status": self.status,
            "status_label": STATUS_LABEL.get(self.status, self.status),
            "proof": self.proof_text,
            "how": self.how_text,
            "group": self.group,
            "evidence": [e.to_dict() for e in self.evidence],
        }


@dataclass
class ItemVerdict:
    """Оценка одного этапа: применимость этапа и состояние его буллитов."""

    item_id: str
    applicable: bool = False
    criteria: list[CriterionVerdict] = field(default_factory=list)

    @property
    def applicable_criteria(self) -> list[CriterionVerdict]:
        return [c for c in self.criteria if c.applicable]

    def percent(self) -> int | None:
        """Готовность этапа: `calculate_progress` по всем буллитам этапа.

        `None` — этап не относится к инициативе или в нём нет буллитов:
        серый, в расчёт не входит.
        """
        if not self.applicable:
            return None
        return calculate_progress(self.criteria)

    @property
    def evidence(self) -> list[EvidenceRef]:
        return [e for c in self.criteria for e in c.evidence]

    @property
    def ungrounded_count(self) -> int:
        return sum(1 for c in self.criteria if not c.is_grounded)

    def to_dict(self) -> dict[str, Any]:
        return {
            "item_id": self.item_id,
            "applicable": self.applicable,
            "percent": self.percent(),
            "criteria": [c.to_dict() for c in self.criteria],
        }


@dataclass(frozen=True)
class UnclaimedGroup:
    """Группа файлов, не подтвердивших ни одного буллита плана.

    Не вердикт «сделано сверх плана» — только сырой кандидат для него.
    Детерминированная разница множеств, без суждения модели.
    """

    group: str
    example_paths: list[str]
    file_count: int

    def to_dict(self) -> dict[str, Any]:
        return {"group": self.group, "example_paths": self.example_paths,
                "file_count": self.file_count}


@dataclass(frozen=True)
class ProjectSummary:
    """Итог анализа: вердикт и его обоснование.

    `conclusion` — 3 коротких буллита (до 4 слов каждый): что подтверждено,
    что мешает, можно ли идти дальше.
    """

    decision: str = ""
    conclusion: list[str] = field(default_factory=list)
    # Строка расчёта под решением: «68% ≥ 50%».
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision,
            "conclusion": list(self.conclusion),
            "reason": self.reason,
        }


@dataclass
class ProgressModel:
    """Итоговая модель одного прогона.

    `readiness` — готовность прототипа, `readiness_prod` — готовность
    промышленного решения. Оба — арифметика по одним и тем же статусам,
    только по разным весам (`POC_WEIGHT` / `PROD_WEIGHT`), а не две оценки
    модели: рассогласовать их нечем.
    """

    meta: dict[str, Any] = field(default_factory=dict)
    items: dict[str, PlanItem] = field(default_factory=dict)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    unclaimed: list[UnclaimedGroup] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    readiness: int = 0
    readiness_prod: int = 0
    summary: ProjectSummary | None = None
    summary_source: str = "none"

    def criterion_counts(self) -> dict[str, int]:
        """Сколько применимых буллитов в каждом состоянии — по всему пути."""
        out = {status: 0 for status in CRITERION_STATUSES}
        for verdict in self.verdicts:
            for criterion in verdict.applicable_criteria:
                if criterion.status in out:
                    out[criterion.status] += 1
        return out

    def all_criteria(self) -> list[CriterionVerdict]:
        return [c for v in self.verdicts for c in v.criteria]

    def overall_progress(self) -> int:
        """Готовность прототипа — главное число отчёта."""
        return calculate_progress(self.all_criteria()) or 0

    def overall_progress_prod(self) -> int:
        """Готовность промышленного решения — то же по строгим весам."""
        return calculate_prod_progress(self.all_criteria()) or 0

    def closed_share(self) -> int:
        """Доля буллитов «Да» — сколько пунктов закрыто полностью."""
        return calculate_closed_share(self.all_criteria()) or 0

    def not_applicable_count(self) -> int:
        return sum(1 for c in self.all_criteria() if not c.applicable)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "pko-progress-model/0.3",
            "meta": self.meta,
            "readiness": self.readiness,
            "readiness_prod": self.readiness_prod,
            "closed_share": self.closed_share(),
            "criterion_counts": self.criterion_counts(),
            "not_applicable": self.not_applicable_count(),
            "items": {item_id: item.to_dict() for item_id, item in self.items.items()},
            "verdicts": [v.to_dict() for v in self.verdicts],
            "unclaimed": [u.to_dict() for u in self.unclaimed],
            "gaps": self.gaps,
            "summary": self.summary.to_dict() if self.summary else None,
            "summary_source": self.summary_source,
        }

    def to_json(self) -> str:
        import json

        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2, sort_keys=False)

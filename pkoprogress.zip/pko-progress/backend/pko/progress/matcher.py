"""Единый агент: получает готовый клиентский путь из текстового ввода,
оценивает его этапы по материалам проекта и выносит вердикт — одна сессия.

Работа идёт в четыре фазы:
  0. ТЕМЫ — `submit_groups`: модель смотрит на все буллиты сразу и объявляет
     2–4 темы отчёта. Дальше `group` каждого буллита обязана быть одной из
     них. Ограничение держится кодом, а не просьбой в промпте: на живом
     прогоне модель выдала 11 тем на 12 буллитов.
  1. ОЦЕНКА — по каждому этапу агент собирает факты инструментами и вызывает
     `submit_stage`: относится ли этап к инициативе и что с каждым его
     буллитом (статус из `CRITERION_STATUSES` либо «не относится»).
  2. КОНТР-ПРОВЕРКА НА ЗАНИЖЕНИЕ — после всех `submit_stage` агент получает
     сводку со своими оценками, списком непроцитированных фактов (точки
     входа, инструменты, SQL, LLM-вызовы — готовые подсказки, где могла
     быть пропущена реализация) и непроцитированных файлов (слепые зоны).
     Проверяет каждый `planned` (не пропущен ли существующий код) и каждый
     `partial` (не выше ли он на самом деле). Если нашёл — исправляет через
     повторный `submit_stage`, подтверждает через `submit_review`.
     `submit_summary` не принимается без `submit_review`.
  3. ВЕРДИКТ — `submit_summary`: три буллита вывода. Затем `finish`.

Тексты пути (названия этапов, буллиты) приходят из текстового поля, разбираются
кодом в `PlanItem` и передаются агенту уже готовыми. Модель ничего не
придумывает по ним — только проверяет готовность пунктов.

Готовность и решение считает код (`schema.calculate_progress` и
`schema.compute_decision`), а не модель: `submit_summary` не принимает ни
процент, ни решение — только текст вывода.

Ни одна evidence-ссылка не публикуется без проверки: `progress.verify.verify_evidence`
подтверждает её структурно. Неподтверждённая ссылка остаётся в модели с
`verified=False` и причиной.

Смысловые гейты кода (`_accept_stage`/`_accept_summary`):
* статус, утверждающий результат (всё, кроме `planned`), не принимается без
  проверенной ссылки — список берётся из `schema.GROUNDED_STATUSES`;
* деловой блок не принимается с кодом внутри (`schema.contains_code`);
* свободные тексты (описание, подтверждение, вывод) проверяются сторожем
  `report.guard` на упоминание данных, которых нет в материалах.

Нарушение отклоняет вызов с объяснением; после `_MAX_GATE_REJECTIONS`
отклонений оценка принимается, но нарушившее поле заменяется пометкой —
оценка этапа не теряется из-за формулировки.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from pko.errors import LlmError
from pko.extractors.base import Tree
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import trace_span
from pko.progress.agent_tools import TOOL_SCHEMAS as REPO_TOOL_SCHEMAS, ToolBox
from pko.progress.journey_text import render_plan_brief
from pko.progress.schema import (
    CRITERION_STATUSES,
    GROUNDED_STATUSES,
    MAX_GROUPS,
    STATUS_ALIASES,
    STATUS_LABEL,
    calculate_progress,
    compute_decision,
    contains_code,
    decision_reason,
    CriterionVerdict,
    EvidenceRef,
    ItemVerdict,
    PlanItem,
    ProjectSummary,
    UnclaimedGroup,
)
from pko.progress.verify import verify_evidence
from pko.report.guard import check_explanation, check_summary_text

# Системный промпт — один редактируемый Markdown-файл рядом с этим модулем.
_PROMPT_PARTS = ("agent_system.md",)
_PROMPT_DIR = Path(__file__).parent


def load_system_prompt() -> tuple[str, list[str]]:
    """Системный промпт и список ненайденных частей."""
    parts: list[str] = []
    missing: list[str] = []
    for name in _PROMPT_PARTS:
        try:
            parts.append((_PROMPT_DIR / name).read_text(encoding="utf-8"))
        except OSError:
            missing.append(name)
    if not parts:
        parts.append("Ты — агент, который проверяет готовность пунктов "
                     "клиентского пути по материалам проекта.")
    return "\n\n---\n\n".join(parts), missing


# Бюджет шагов агента на всю сессию (обход всех этапов + контр-проверка + вердикт).
DEFAULT_MAX_STEPS = 80

MAX_TOKENS_DEFAULT = 8192
MAX_TOKENS_THINKING = 16384

_SUBMIT_GROUPS_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_groups",
        "description": (
            "ПЕРВЫЙ вызов сессии. Посмотри на весь список буллитов образа результата "
            "и назови темы, на которые они делятся. Ровно столько тем, сколько "
            "нужно, но не больше четырёх: отчёт рисует по одному блоку на тему, "
            "и блок из одного буллита ничего не группирует. Дальше у каждого "
            "буллита в submit_stage поле group обязано быть одной из этих тем."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "groups": {
                    "type": "array",
                    "description": "2–4 темы, 1–3 слова каждая: «Обработка запросов», «Сценарный анализ», «Документы», «Развитие и интеграции»",
                    "items": {"type": "string"},
                },
            },
            "required": ["groups"],
        },
    },
}

_SUBMIT_STAGE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_stage",
        "description": "Оценка одного этапа — ОДИН вызов на этап, после того как ты собрал "
                       "факты инструментами. Тексты пунктов уже известны из плана, здесь "
                       "только применимость и статусы по позициям. Список criteria обязан "
                       "совпадать по длине и порядку с буллитами этого этапа в плане. "
                       "applicable=true ставь только тем этапам и буллитам, которые "
                       "относятся к анализируемой инициативе; остальные оставь "
                       "неприменимыми — они станут серыми и в расчёт не войдут. Повторный "
                       "вызов с тем же item_id заменяет предыдущую оценку.",
        "parameters": {
            "type": "object",
            "properties": {
                "item_id": {"type": "string", "description": "идентификатор этапа из плана"},
                "applicable": {"type": "boolean", "description": "относится ли этап к анализируемой инициативе"},
                "criteria": {
                    "type": "array",
                    "description": "оценки буллитов этапа строго по позициям плана: столько же элементов и в том же порядке",
                    "items": {
                        "type": "object",
                        "properties": {
                            "applicable": {"type": "boolean", "description": "относится ли буллит к анализируемой инициативе; если нет — статус не нужен, пункт станет серым"},
                            "status": {
                                "type": "string", "enum": list(CRITERION_STATUSES),
                                "description": (
                                    "Состояние пункта в коде. "
                                    "done — Работает: сквозной путь отрабатывает, ограничений не найдено. "
                                    "limited — Работает с ограничениями: отрабатывает, но есть понятное ограничение (назови его). "
                                    "unused — Код реализован, но не используется: написан и рабочий, а в сценарии не задействован. "
                                    "partial — Не работает, реализовано частично: сделана часть, сквозной путь не отрабатывает. "
                                    "planned — Не реализовано: в коде не найдено. "
                                    "blocked — отсутствие результата блокирует следующий этап. "
                                    "Целевые метрики (сроки, доли, проценты) на статус НЕ влияют — их место в поле proof."
                                ),
                            },
                            "evidence": {
                                "type": "array",
                                "description": "чем подтверждён статус: реальные путь и строка из прочитанного кода. Любому статусу кроме planned нужна хотя бы одна проверенная ссылка. Для planned оставь пустым — отсутствие ссылкой не доказывается.",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "path": {"type": "string"},
                                        "line": {"type": "integer"},
                                        "basis": {"type": "string", "description": "конкретное имя (функции/класса/таблицы/процедуры) рядом со строкой — по нему ссылка проверяется"},
                                        "note": {"type": "string", "description": "что происходит в этой строке, одной фразой: «принимает модель и запрос от пользователя», «регистрирует расчёт как инструмент агента». Без неё ссылка остаётся координатой."},
                                    },
                                },
                            },
                            "proof": {"type": "string", "description": "ПРОВЕРКА — первый буллит раскрытия. Есть ли код и работает ли он, человеческим языком, ОДНА фраза. Примеры: «Код есть и работает — путь от запроса до ответа проходит целиком»; «Код написан и рабочий, но в сценарии не задействован»; «В коде такого не нашлось». ЗАПРЕЩЕНЫ имена функций, классов, файлов, пути и декораторы: ссылки на репозиторий в отчёт не выводятся. Если в буллите есть целевое число (срок, доля, процент) — второй фразой скажи, подтверждается ли оно по коду. До 300 символов."},
                            "how": {"type": "string", "description": "КАК РАБОТАЕТ — второй буллит раскрытия. Обычными словами, как объяснил бы коллеге: что система умеет и каким образом. Примеры: «Агент умеет работать с Excel-моделью: открывает файл, меняет входные параметры и считает результат»; «Запрос разбирает языковая модель по заранее заданной инструкции и отправляет нужному исполнителю». ЗАПРЕЩЕНЫ имена функций, классов, файлов и декораторы. Одна-две фразы, до 300 символов."},
                            "comment": {"type": "string", "description": "Устаревшее поле, оставлено для совместимости. Заполняй `proof` и `how` вместо него."},
                            "group": {"type": "string", "description": "тематическая группа для вёрстки отчёта, 1–3 слова («Обработка запросов», «Сценарный анализ», «Документы и чувствительность», «Развитие и интеграции»). НА ВСЮ ИНИЦИАТИВУ ГРУПП ДОЛЖНО БЫТЬ НЕ БОЛЬШЕ ЧЕТЫРЁХ, по 2–4 буллита в каждой. Группа из одного буллита — признак слишком мелкого дробления. Лишние группы код сольёт в «Прочее». На расчёт не влияет."},
                        },
                        "required": ["applicable"],
                    },
                },
                "notes": {"type": "string", "description": "краткие наблюдения для себя — служебное поле, в отчёт не идёт"},
            },
            "required": ["item_id", "applicable", "criteria"],
        },
    },
}

_SUBMIT_SUMMARY_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_summary",
        "description": "Вывод по проекту — вызывай ОДИН раз после submit_review и ДО "
                       "finish. Только текст вывода: и готовность, и решение GO/PIVOT "
                       "считает код по твоим статусам, называть их не нужно.",
        "parameters": {
            "type": "object",
            "properties": {
                "conclusion": {
                    "type": "array",
                    "minItems": 3,
                    "maxItems": 3,
                    "items": {"type": "string"},
                    "description": "Ровно 3 буллита, каждый максимум 4 слова: что подтверждено, что мешает, можно ли идти дальше. Не предложения, а короткие тезисы.",
                },
            },
            "required": ["conclusion"],
        },
    },
}

_FINISH_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "finish",
        "description": "Вызови, когда оценил все этапы пути и отправил вердикт "
                       "(submit_summary) — сессия завершена.",
        "parameters": {"type": "object", "properties": {}},
    },
}

_SUBMIT_BRIEF_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_brief",
        "description": "Сформулируй из описания инициативы три коротких тезиса — «AS IS» "
                       "(исходное состояние), «Now» (текущее состояние после частичной "
                       "реализации) и «To Be» (целевое состояние). По одному понятному "
                       "предложению каждое. Вызови ОДИН раз в самом начале сессии, до "
                       "submit_stage. Если описания нет — не вызывай. Формулировки "
                       "попадают в шапку дашборда: конкретно, без воды, одно предложение.",
        "parameters": {
            "type": "object",
            "properties": {
                "before": {
                    "type": "string",
                    "description": "AS IS — исходное состояние до инициативы, одно предложение до 200 символов.",
                },
                "now": {
                    "type": "string",
                    "description": "Now — текущее состояние после частичной реализации, одно предложение до 200 символов.",
                },
                "after": {
                    "type": "string",
                    "description": "To Be — целевое состояние после инициативы, одно предложение до 200 символов.",
                },
            },
            "required": ["before", "now", "after"],
        },
    },
}

_SUBMIT_REVIEW_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_review",
        "description": "Контр-проверка на занижение статусов — вызови ОДИН раз после всех "
                       "submit_stage и ДО submit_summary. Проверь каждый planned (не "
                       "пропущена ли реализация) и каждый partial (не является ли он на "
                       "самом деле done). Тебе передана сводка с непроцитированными фактами "
                       "и файлами — отсмотри их. Если нашёл код, который пропустил, или "
                       "убедился, что partial — это done — исправь статус через повторный "
                       "submit_stage, потом вызови submit_review с confirmed=true. Если всё "
                       "подтверждается — сразу confirmed=true. Без submit_review вердикт "
                       "(submit_summary) не принимается, если есть хотя бы один done/partial.",
        "parameters": {
            "type": "object",
            "properties": {
                "confirmed": {
                    "type": "boolean",
                    "description": "true — все planned/partial перепроверены на занижение (или исправлены через повторный submit_stage); false — найдена пропущенная реализация или заниженный статус, нужно исправить перед подтверждением",
                },
                "notes": {
                    "type": "string",
                    "description": "что проверял и что нашёл, до 500 символов. Служебное поле, в отчёт не идёт.",
                },
            },
            "required": ["confirmed"],
        },
    },
}

_SESSION_TOOL_SCHEMAS: list[dict[str, Any]] = (
    REPO_TOOL_SCHEMAS
    + [_SUBMIT_GROUPS_SCHEMA, _SUBMIT_BRIEF_SCHEMA, _SUBMIT_STAGE_SCHEMA, _SUBMIT_REVIEW_SCHEMA,
       _SUBMIT_SUMMARY_SCHEMA, _FINISH_SCHEMA]
)

_MAX_MALFORMED = 3
_REPEAT_STOP = 3

# Жёсткие смысловые гейты («LLM предлагает, код проверяет» — не только про
# структуру полей, но и про содержание). Первое нарушение — отклонение вызова
# с объяснением; повторная отправка с тем же нарушением (после `_MAX_GATE_
# REJECTIONS` отклонений) принимается, но нарушившее поле заменяется пометкой —
# оценка этапа или вердикт не теряются из-за формулировки.
_MAX_GATE_REJECTIONS = 1

# Длина свободных текстов. Вывод — телеграфный: три тезиса по четыре слова
# читаются с одного взгляда, предложения — нет.
_MAX_CONCLUSION_BULLETS = 3
_MAX_CONCLUSION_WORDS = 4
_MAX_BRIEF_CHARS = 200
_MAX_EXPLANATION_CHARS = 400
_MAX_GROUP_CHARS = 60
_MAX_NOTE_CHARS = 160

_COMMENT_STRUCK = "Комментарий снят сторожем: ссылка на данные, которых нет в материалах"
_ITEM_STRUCK = "Пункт снят сторожем: ссылка на данные, которых нет в материалах"


@dataclass
class AgentResult:
    items: list[PlanItem] = field(default_factory=list)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    plan: list[PlanItem] = field(default_factory=list)
    summary: ProjectSummary | None = None
    summary_source: str = "none"
    context: dict[str, str] = field(default_factory=dict)
    source: str = "none"
    notes: list[str] = field(default_factory=list)

    @property
    def usable(self) -> bool:
        return bool(self.items)


def run_agent(
    plan_items: list[PlanItem],
    context: dict[str, str],
    tree: Tree,
    spec: ModelSpec | None,
    client: ChatClient | None = None,
    max_steps: int = DEFAULT_MAX_STEPS,
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None,
    on_summary: Callable[[ProjectSummary], None] | None = None,
    extraction: Extraction | None = None,
    description: str | None = None,
) -> AgentResult:
    """Проверить готовность пунктов готового клиентского пути по материалам
    проекта и вынести вердикт — одна сессия.

    `plan_items` — этапы пути, разобранные кодом из текстового поля. Модель
    не придумывает их, только проверяет. `context` — название пути, проект,
    «было → стало» (для шапки дашборда и вердикта). `description` — описание
    инициативы: из него агент формулирует «было → стало» первым шагом
    (`submit_brief`), если поля ещё не заданы в `context`.
    """
    if spec is None:
        return AgentResult(
            notes=["Matcher не настроен: оценки не получены"],
        )
    if not plan_items:
        return AgentResult(notes=["План пуст: этапы не заданы"])

    user_brief = render_plan_brief(plan_items, context)
    preface = (
        "Клиентский путь уже разобран и передан ниже. Тебе не нужно "
        "копировать его — только проверь готовность каждого пункта по "
        "материалам проекта инструментами и вызови submit_stage по каждому "
        "этапу, затем submit_summary и finish.\n\n"
    )
    if description and description.strip():
        preface += (
            "Описание инициативы (из него первым шагом сформулируй «Было» и "
            "«Стало» через submit_brief — по одному понятному предложению):\n"
            + description.strip() + "\n\n"
        )
    user_brief = preface + user_brief

    chat_client = client if client is not None else ChatClient(spec=spec)
    thinking_on = bool(
        spec.extra_body
        and spec.extra_body.get("chat_template_kwargs", {}).get("enable_thinking") is True
    )
    max_tokens = MAX_TOKENS_THINKING if thinking_on else MAX_TOKENS_DEFAULT
    outcome = _run_session(
        user_brief, plan_items, tree, chat_client, max_steps, max_tokens,
        on_verdict=on_verdict, on_summary=on_summary, extraction=extraction,
        context=dict(context),
    )

    notes = outcome.notes
    ungrounded = sum(v.ungrounded_count for v in outcome.verdicts)
    if ungrounded:
        notes.append(
            f"Буллитов со статусом «сделано»/«в работе»/«блокер» без единой подтверждённой "
            f"ссылки на материалы: {ungrounded} — агент утверждает состояние, но материалы "
            "его не показывают; нужна ручная проверка"
        )
    return AgentResult(
        items=outcome.items, verdicts=outcome.verdicts, plan=plan_items,
        summary=outcome.summary, summary_source=outcome.summary_source,
        context=outcome.context,
        source="llm" if outcome.items else "none", notes=notes,
    )


def find_unclaimed_paths(
    extraction: Extraction, verdicts: list[ItemVerdict], limit: int = 20
) -> list[UnclaimedGroup]:
    """Файлы-кандидаты, не процитированные ни одной подтверждённой evidence."""
    claimed = {
        e.path for v in verdicts for e in v.evidence if e.verified and e.path
    }
    candidate_paths = sorted({f.path for f in extraction.facts if f.path})
    unclaimed = [p for p in candidate_paths if p not in claimed]

    groups: dict[str, list[str]] = {}
    for path in unclaimed:
        segments = path.split("/")
        key = "/".join(segments[:2]) if len(segments) > 1 else segments[0]
        groups.setdefault(key, []).append(path)

    ranked = sorted(groups.items(), key=lambda kv: -len(kv[1]))[:limit]
    return [
        UnclaimedGroup(group=key, example_paths=paths[:3], file_count=len(paths))
        for key, paths in ranked
    ]


@dataclass
class _SessionOutcome:
    """Итог одной сессии агента."""

    items: list[PlanItem] = field(default_factory=list)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    summary: ProjectSummary | None = None
    summary_source: str = "none"
    context: dict[str, str] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)


@dataclass
class _Session:
    """Состояние одной сессии агента: всё, что накапливают обработчики вызовов.

    Раньше это были полтора десятка локальных переменных в теле цикла, и
    каждая ветка дописывала их вперемешку с разбором ответа модели. Собранные
    в один объект, они позволяют держать обработчик каждого инструмента
    отдельной функцией: ветка отвечает за свой инструмент и возвращает текст,
    который увидит модель.
    """

    plan_items: list[PlanItem]
    tree: Tree
    tools: ToolBox
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None
    on_summary: Callable[[ProjectSummary], None] | None = None

    items_by_id: dict[str, PlanItem] = field(default_factory=dict)
    verdicts_by_id: dict[str, ItemVerdict] = field(default_factory=dict)
    context: dict[str, str] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    # Темы отчёта, объявленные моделью через `submit_groups`. Пустой список —
    # модель их не объявила: тогда группы сводит код (`schema.limit_groups`).
    declared_groups: list[str] = field(default_factory=list)
    summary: ProjectSummary | None = None
    summary_source: str = "none"
    # Сколько раз оценка этапа отклонялась именно смысловым гейтом (а не
    # структурой): после `_MAX_GATE_REJECTIONS` включается tolerant-режим.
    gate_attempts: dict[str, int] = field(default_factory=dict)
    summary_gate_attempts: int = 0
    review_done: bool = False
    finished: bool = False

    @property
    def plan_by_id(self) -> dict[str, PlanItem]:
        return {item.id: item for item in self.plan_items}

    @property
    def all_stages_rated(self) -> bool:
        return len(self.verdicts_by_id) == len(self.plan_items)


def _handle_brief(state: _Session, args: dict) -> str:
    """`submit_brief` — «AS IS / Now / To Be» для шапки отчёта."""
    fields = {
        key: " ".join(str(args.get(key) or "").split())[:_MAX_BRIEF_CHARS]
        for key in ("before", "now", "after")
    }
    if not all(fields.values()):
        return ("brief отклонён: все три поля (before, now, after) должны быть "
                "непустыми, по одному предложению каждое")
    state.context.update(fields)
    return ("brief принят: «AS IS», «Now» и «To Be» зафиксированы. "
            "Переходи к оценке этапов (submit_stage).")


def _handle_groups(state: _Session, args: dict) -> str:
    """`submit_groups` — темы отчёта, объявленные до оценки этапов."""
    names, error = _accept_groups(args)
    if error:
        return f"темы отклонены: {error}"
    state.declared_groups[:] = names
    return ("темы приняты: " + ", ".join(names)
            + ". Теперь оценивай этапы: у каждого буллита поле "
              "group обязано быть одной из этих тем.")


def _handle_stage(state: _Session, args: dict) -> str:
    """`submit_stage` — оценка одного этапа."""
    item_id = str(args.get("item_id") or "").strip()
    plan_by_id = state.plan_by_id
    if not item_id or item_id not in plan_by_id:
        return (f"оценка отклонена: item_id {item_id!r} не найден в плане. "
                f"Доступные этапы: {', '.join(plan_by_id.keys())}")
    item = plan_by_id[item_id]
    tolerant = state.gate_attempts.get(item_id, 0) >= _MAX_GATE_REJECTIONS
    verdict, error, gate_hit = _accept_stage(
        item, args, state.tree, tolerant=tolerant, groups=state.declared_groups,
    )
    if error or verdict is None:
        if gate_hit:
            state.gate_attempts[item_id] = state.gate_attempts.get(item_id, 0) + 1
        return f"оценка отклонена: {error}"
    state.items_by_id[item_id] = item
    state.verdicts_by_id[item_id] = verdict
    if state.on_verdict is not None:
        state.on_verdict(item, verdict)
    return "оценка принята. Переходи к следующему этапу."


def _handle_review(state: _Session, args: dict) -> str:
    """`submit_review` — контр-проверка оценок на занижение."""
    if not bool(args.get("confirmed")):
        return ("нашёл пропущенную реализацию или заниженный статус — "
                "исправь через повторный submit_stage, потом вызови "
                "submit_review с confirmed=true")
    state.review_done = True
    return "контр-проверка завершена. Переходи к submit_summary."


def _handle_summary(state: _Session, args: dict) -> str:
    """`submit_summary` — текст вывода; решение и процент считает код."""
    if state.all_stages_rated and not state.review_done:
        return ("сначала вызови submit_review для контр-проверки "
                "оценок, потом submit_summary")
    tolerant = state.summary_gate_attempts >= _MAX_GATE_REJECTIONS
    parsed, error, gate_hit = _accept_summary(
        args, set(state.items_by_id), state.verdicts_by_id, tolerant=tolerant,
    )
    if error or parsed is None:
        if gate_hit:
            state.summary_gate_attempts += 1
        return f"вердикт отклонён: {error}"
    state.summary = parsed
    state.summary_source = "llm"
    if state.on_summary is not None:
        state.on_summary(parsed)
    return "вердикт принят. Теперь вызови finish."


def _handle_finish(state: _Session, args: dict) -> str:
    state.finished = True
    return "сессия завершена"


# Инструменты протокола сессии: код разбирает их сам. Всё, чего здесь нет,
# уходит в `ToolBox` — read-only доступ к репозиторию.
_PROTOCOL_HANDLERS: dict[str, Callable[[_Session, dict], str]] = {
    "submit_brief": _handle_brief,
    "submit_groups": _handle_groups,
    "submit_stage": _handle_stage,
    "submit_review": _handle_review,
    "submit_summary": _handle_summary,
    "finish": _handle_finish,
}


def _run_session(
    user_brief: str,
    plan_items: list[PlanItem],
    tree: Tree,
    chat_client: ChatClient,
    max_steps: int,
    max_tokens: int,
    on_verdict: Callable[[PlanItem, ItemVerdict], None] | None = None,
    on_summary: Callable[[ProjectSummary], None] | None = None,
    extraction: Extraction | None = None,
    context: dict[str, str] | None = None,
) -> _SessionOutcome:
    """Фаза 0: `submit_groups` + `submit_brief` (опц.) → Фаза 1: `submit_stage`
    по каждому этапу → Фаза 1.5: `submit_review` контр-проверка → Фаза 2:
    `submit_summary` (вывод) → `finish`.

    Здесь остался только цикл: получить ответ модели, разложить его на вызовы
    и ответить на каждый. Что делает каждый инструмент протокола — в
    `_PROTOCOL_HANDLERS`; что делают инструменты репозитория — в `ToolBox`.

    `context` — входный контекст пути; если агент вызвал `submit_brief`,
    поля `before`/`now`/`after` в нём обновляются и возвращаются наружу.
    """
    state = _Session(
        plan_items=plan_items,
        tree=tree,
        tools=ToolBox(tree, extraction=extraction),
        on_verdict=on_verdict,
        on_summary=on_summary,
        context=dict(context or {}),
    )
    system_prompt, missing_parts = load_system_prompt()
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_brief},
    ]
    if missing_parts:
        state.notes.append(
            "Части системного промпта не найдены и в анализ не попали: "
            + ", ".join(missing_parts)
        )
    recent_calls: list[tuple[tuple[str, str], ...]] = []
    malformed = 0
    steps_done = 0
    review_injected = False

    with trace_span("agent_session") as session_handle:
        for step in range(1, max(1, max_steps) + 1):
            steps_done = step
            with trace_span("agent.step", step=step) as step_span:
                try:
                    result = chat_client.chat(
                        messages, tools=_SESSION_TOOL_SCHEMAS, max_tokens=max_tokens,
                    )
                except LlmError as exc:
                    step_span.set_attribute("error", exc.message)
                    state.notes.append(f"агент недоступен на шаге {step}: {exc.message}")
                    break
                _trace_step(step_span, result)

            if not result.tool_calls:
                malformed += 1
                if malformed >= _MAX_MALFORMED:
                    state.notes.append(
                        f"агент не вызвал инструмент {malformed} раз подряд — остановлено"
                    )
                    break
                messages.append({"role": "assistant", "content": result.text})
                messages.append({"role": "user", "content": _NUDGE})
                continue
            malformed = 0

            recent_calls.append(_signature(result.tool_calls))
            if len(recent_calls) >= _REPEAT_STOP and len(set(recent_calls[-_REPEAT_STOP:])) == 1:
                state.notes.append(f"остановлено — {_REPEAT_STOP} одинаковых вызова подряд")
                break

            messages.append({
                "role": "assistant",
                "content": result.text or None,
                "tool_calls": result.tool_calls,
                "reasoning_content": result.reasoning_content or None,
            })
            for call in result.tool_calls:
                messages.append(_answer_call(state, call))

            # Все этапы оценены — подкладываем сводку для контр-проверки на
            # занижение. Один раз за сессию: повтор превратил бы её в петлю.
            if not review_injected and not state.finished and state.all_stages_rated:
                review_injected = True
                messages.append({
                    "role": "user",
                    "content": _build_review_brief(plan_items, state.verdicts_by_id, extraction),
                })

            if state.finished:
                break
        else:
            state.notes.append(f"бюджет шагов исчерпан ({max_steps})")

        session_handle.set_attribute("steps_done", steps_done)
        session_handle.set_attribute("verdicts", len(state.verdicts_by_id))
        session_handle.set_attribute("summary_source", state.summary_source)
        session_handle.set_attribute("finished", state.finished)

    if not state.verdicts_by_id:
        state.notes.append("Этапы не оценены (submit_stage не вызывался)")
    if not state.summary:
        state.notes.append("Вердикт не сформирован (submit_summary не вызывался или отклонён)")
    if review_injected and not state.review_done:
        state.notes.append("Контр-проверка не завершена: submit_review не вызван")
    unrated = [p.title for p in plan_items if p.id not in state.verdicts_by_id]
    if unrated:
        state.notes.append("Этапы пути остались без оценки: " + ", ".join(unrated[:5]))
    return _SessionOutcome(
        items=list(state.items_by_id.values()),
        verdicts=list(state.verdicts_by_id.values()),
        summary=state.summary, summary_source=state.summary_source,
        notes=state.notes, context=state.context,
    )


_NUDGE = (
    "Нужно вызвать инструмент — по каждому этапу submit_stage (применимость "
    "и статусы по позициям), потом submit_summary (вывод) и finish."
)


def _answer_call(state: _Session, call: dict) -> dict[str, Any]:
    """Выполнить один вызов инструмента и собрать ответ для модели."""
    function = call.get("function") or {}
    name = str(function.get("name") or "")
    raw_args = function.get("arguments") or "{}"
    call_id = str(call.get("id") or "")
    try:
        args = json.loads(raw_args)
    except json.JSONDecodeError:
        return {
            "role": "tool", "tool_call_id": call_id,
            "content": f"аргументы инструмента не являются валидным JSON: {raw_args!r}",
        }
    args = args if isinstance(args, dict) else {}

    handler = _PROTOCOL_HANDLERS.get(name)
    content = handler(state, args) if handler else state.tools.call(name, args).content
    return {"role": "tool", "tool_call_id": call_id, "content": content}


def _signature(tool_calls: list[dict]) -> tuple[tuple[str, str], ...]:
    """Отпечаток набора вызовов — по нему ловится зацикливание агента."""
    return tuple(sorted(
        (str((c.get("function") or {}).get("name") or ""),
         str((c.get("function") or {}).get("arguments") or ""))
        for c in tool_calls
    ))


def _trace_step(span: Any, result: Any) -> None:
    """Атрибуты одного шага в трассировку — цена и форма ответа модели."""
    span.set_attribute("from_cache", result.from_cache)
    span.set_attribute("text_chars", len(result.text or ""))
    span.set_attribute("reasoning_chars", len(result.reasoning_content or ""))
    names = ",".join(
        str((c.get("function") or {}).get("name") or "") for c in (result.tool_calls or [])
    )
    span.set_attribute("tool_calls", names)
    span.set_attribute("tool_call_count", len(result.tool_calls or []))
    if result.usage:
        span.set_attribute("total_tokens", result.usage.get("total_tokens", 0))


def _build_review_brief(
    plan_items: list[PlanItem],
    verdicts_by_id: dict[str, ItemVerdict],
    extraction: Extraction | None,
) -> str:
    """Сводка для контр-проверки на занижение: текущие оценки + непроцитированные
    факты и файлы как подсказки, где могла быть пропущена реализация.

    Вставляется как user-сообщение после того, как все этапы оценены.
    Агент видит свои статусы (особенно `planned` и `partial`), непроцитированные
    точки входа/интеграции (ROUTE, TOOL, SQL, LLM_CALL — готовые path:line) и
    непроцитированные файлы (слепые зоны), после чего обязан проверить:
      - каждый `planned` — не пропущен ли существующий код;
      - каждый `partial` — не является ли он на самом деле `done` (путь
        end-to-end работает, ограничений нет).
    Вызывает `submit_review`.
    """
    lines = [
        "Все этапы оценены. Перед вердиктом — контр-проверка на занижение статусов.",
        "",
        "Твои текущие оценки:",
    ]
    check_count = 0
    for item in plan_items:
        v = verdicts_by_id.get(item.id)
        if not v:
            continue
        parts: list[str] = []
        for idx, c in enumerate(v.criteria, start=1):
            if not (c.applicable and c.status):
                continue
            tag = f"буллит {idx}={c.status}"
            if c.status == "planned":
                check_count += 1
                tag += " ← проверь, не пропущена ли реализация"
            elif c.status == "partial":
                check_count += 1
                tag += " ← проверь, не является ли он done (ограничений нет?)"
            parts.append(tag)
        lines.append(f"- {item.title}: {', '.join(parts) or 'нет оценок'}")

    if check_count == 0:
        lines.append("")
        lines.append("planned и partial пунктов нет — контр-проверка не требуется.")
        lines.append("Вызови submit_review с confirmed=true.")
        return "\n".join(lines)

    lines.append("")
    lines.append(
        f"У тебя {check_count} пунктов с возможным занижением. "
        "Проверь каждый по подсказкам ниже."
    )

    if extraction is not None:
        claimed = {
            e.path for v in verdicts_by_id.values()
            for e in v.evidence if e.verified and e.path
        }
        hint_kinds = ("ROUTE", "TOOL", "SQL_WRITE", "SQL_READ", "LLM_CALL",
                       "GRAPH_NODE", "EXTERNAL", "MODULE")
        unclaimed_facts = [
            f for f in extraction.facts
            if f.path and f.path not in claimed and f.kind in hint_kinds
        ]
        if unclaimed_facts:
            lines.append("")
            lines.append("Непроцитированные факты — точки входа и интеграции, которые ты не смотрел:")
            for f in unclaimed_facts[:20]:
                loc = f"{f.path}:{f.line}" if f.line else f.path
                value_str = _format_review_fact_value(f.value)
                row = f"- {f.kind} | {loc} | {f.key}"
                if value_str:
                    row += f" = {value_str}"
                lines.append(row)

        unclaimed = find_unclaimed_paths(extraction, list(verdicts_by_id.values()))
        if unclaimed:
            lines.append("")
            lines.append("Непроцитированные файлы (слепые зоны — открой те, что рядом с planned/partial):")
            for g in unclaimed[:8]:
                lines.append(f"- {g.group} — {g.file_count} файл(ов)")

    lines.extend([
        "",
        "Действуй:",
        "1. show_facts с kind из подсказок выше — готовые точки входа с path:line",
        "2. read_file по пути из подсказки — посмотри реализацию",
        "3. search по синонимам буллита, если подсказок нет",
        "4. Для partial: проверь, есть ли реальное ограничение. Если путь end-to-end",
        "   работает и ограничений нет — это done, исправь через submit_stage",
        "5. Для planned: если нашёл код — исправь статус через submit_stage",
        "6. Затем вызови submit_review с confirmed=true",
    ])
    return "\n".join(lines)


def _format_review_fact_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value[:120]
    if isinstance(value, (list, tuple)):
        return ", ".join(str(v) for v in value)[:120]
    return str(value)[:120]


def _accept_groups(args: dict) -> tuple[list[str], str | None]:
    """Разобрать `submit_groups` — темы отчёта, объявленные моделью.

    Ограничение в четыре темы держится здесь, а не в просьбе промпта: на живом
    прогоне модель выдала 11 тем на 12 буллитов, и отчёт превратился в список
    блоков по одному пункту.
    """
    raw = args.get("groups")
    if not isinstance(raw, list):
        return [], "groups должен быть списком тем"

    names: list[str] = []
    for value in raw:
        name = " ".join(str(value or "").split())[:60]
        if not name:
            continue
        if name.lower() not in {n.lower() for n in names}:
            names.append(name)

    if not 2 <= len(names) <= MAX_GROUPS:
        return [], (
            f"тем должно быть от 2 до {MAX_GROUPS}, прислано {len(names)}. "
            "Объедини близкие: отчёт рисует по блоку на тему"
        )
    return names, None


def _match_group(value: str, groups: list[str]) -> str | None:
    """Сопоставить группу буллита с объявленной темой без учёта регистра."""
    clean = " ".join(str(value or "").split())
    if not clean:
        return None
    for name in groups:
        if name.lower() == clean.lower():
            return name
    return None


def _accept_stage(
    item: PlanItem, args: dict, tree: Tree, tolerant: bool = False,
    groups: list[str] | None = None,
) -> tuple[ItemVerdict | None, str | None, bool]:
    """Разобрать `submit_stage` в `ItemVerdict`.

    Возвращает `(вердикт, ошибка, нарушен ли смысловой гейт)`.

    Структурные проверки (`gate_violation=False` — их tolerant-режим не
    смягчает): совпадение числа оценок с числом буллитов этапа и известные
    статусы. Смысловые гейты — в `_stage_problems`.

    В `tolerant` режиме (после `_MAX_GATE_REJECTIONS` отклонений того же
    этапа) гейты не отклоняют вызов: нарушившие тексты заменяются пометкой,
    неподтверждённые статусы остаются с флагом ungrounded — их видно в `gaps`.
    """
    raw_criteria = args.get("criteria")
    if not isinstance(raw_criteria, list):
        return None, "criteria должен быть списком оценок по позициям буллитов этапа", False
    expected = len(item.criteria)
    if len(raw_criteria) != expected:
        return None, (
            f"у этапа «{item.title}» {expected} буллитов, а прислано оценок: "
            f"{len(raw_criteria)}. Нужен ровно один элемент на буллет, в том же порядке."
        ), False

    criteria: list[CriterionVerdict] = []
    for index, raw in enumerate(raw_criteria, start=1):
        criterion, error = _parse_criterion(raw, index, tree)
        if error:
            return None, error, False
        criteria.append(criterion)

    group_misses = _match_groups(criteria, groups or [])
    problems = _stage_problems(criteria, tree, groups or [], group_misses)
    if problems and not tolerant:
        return None, " | ".join(problems[:3]), True

    # В мягком режиме несовпавшую тему не теряем и новый блок не заводим:
    # ставим первую объявленную, чтобы блоков осталось ровно столько, сколько
    # объявила модель.
    if groups:
        for index, _ in group_misses:
            criteria[index - 1].group = groups[0]

    return ItemVerdict(
        item_id=item.id,
        applicable=bool(args.get("applicable")),
        criteria=criteria,
    ), None, False


def _parse_criterion(
    raw: object, index: int, tree: Tree,
) -> tuple[CriterionVerdict, str | None]:
    """Одна оценка буллита из ответа модели. Ошибка — только структурная."""
    raw = raw if isinstance(raw, dict) else {}
    applicable = bool(raw.get("applicable"))
    status = str(raw.get("status") or "").strip().lower()
    status = STATUS_ALIASES.get(status, status)
    if applicable and status not in CRITERION_STATUSES:
        return CriterionVerdict(), (
            f"буллит {index} отмечен как относящийся к инициативе, но его статус "
            f"{status!r} неизвестен (допустимы: {', '.join(CRITERION_STATUSES)})"
        )

    def text_of(key: str, limit: int = _MAX_EXPLANATION_CHARS) -> str:
        return " ".join(str(raw.get(key) or "").split())[:limit] if applicable else ""

    return CriterionVerdict(
        applicable=applicable,
        status=status if applicable else "",
        # `business`/`technical`/`why` — поля прежних версий: старый прогон
        # не должен терять текст только потому, что поля переименовали.
        proof=text_of("proof") or text_of("technical") or text_of("why"),
        how=text_of("how") or text_of("business"),
        comment=text_of("comment"),
        evidence=_parse_evidence(raw.get("evidence"), tree) if applicable else [],
        group=" ".join(str(raw.get("group") or "").split())[:_MAX_GROUP_CHARS],
    ), None


def _match_groups(
    criteria: list[CriterionVerdict], groups: list[str],
) -> list[tuple[int, str]]:
    """Привести группы буллитов к объявленным темам.

    Возвращает список несовпавших `(номер буллита, что прислала модель)`.
    Без объявленных тем не делает ничего: свести группы всё равно сможет
    `schema.limit_groups` на выходе.
    """
    misses: list[tuple[int, str]] = []
    if not groups:
        return misses
    for index, criterion in enumerate(criteria, start=1):
        matched = _match_group(criterion.group, groups)
        if matched:
            criterion.group = matched
        else:
            misses.append((index, criterion.group))
    return misses


def _stage_problems(
    criteria: list[CriterionVerdict],
    tree: Tree,
    groups: list[str],
    group_misses: list[tuple[int, str]],
) -> list[str]:
    """Смысловые гейты этапа. Пустой список — оценку можно принимать.

    Нарушившие сторожа тексты здесь же заменяются пометкой: если вызов всё
    равно будет принят (tolerant-режим), в отчёт не должна уехать ссылка на
    файл, которого в материалах нет.
    """
    problems: list[str] = []
    for index, criterion in enumerate(criteria, start=1):
        if not criterion.applicable:
            continue

        # Подтверждения требует любой статус, кроме «не реализовано»: и
        # «работает с ограничениями» (90% веса), и «код реализован, но не
        # используется» (70%) — иначе вес приходит в расчёт без единой
        # проверенной строки кода.
        if criterion.status in GROUNDED_STATUSES and not criterion.is_grounded:
            label = STATUS_LABEL.get(criterion.status, criterion.status)
            problems.append(
                f"буллит {index} со статусом «{label}» без единой проверенной "
                "ссылки: evidence обязана содержать реальные путь, строку и основание "
                "из прочитанного кода; если подтверждения нет — ставь статус «planned»"
            )

        # Сторож проверяет все свободные тексты пункта, а не только `comment`:
        # ссылка на несуществующий файл одинаково вредна в любом из них.
        struck = False
        for label, value in (
            ("буллит «проверка»", criterion.proof_text),
            ("буллит «как работает»", criterion.how_text),
        ):
            if not value:
                continue
            violations = check_explanation(value, tree.files_set)
            if violations:
                struck = True
                problems.append(
                    f"{label} буллита {index}: "
                    + "; ".join(v.render() for v in violations)
                )
        if struck:
            for attribute in ("proof", "how", "business", "technical", "why", "comment"):
                if getattr(criterion, attribute):
                    setattr(criterion, attribute, _COMMENT_STRUCK)

        # Оба буллита читает человек без технического контекста, и ссылок
        # на репозиторий в отчёте нет вовсе: имя функции ему нечем открыть.
        for label, value in (("проверка", criterion.proof_text),
                             ("как работает", criterion.how_text)):
            code = contains_code(value)
            if code:
                problems.append(
                    f"буллит «{label}» пункта {index} содержит код («{code}») — "
                    "перепиши обычными словами: ссылки на репозиторий в отчёт "
                    "не выводятся, и читателю такое имя ничего не объясняет"
                )

    if groups and group_misses:
        shown = ", ".join(f"буллит {i} — «{g}»" for i, g in group_misses[:3])
        problems.append(
            f"группы вне объявленных тем ({shown}). Допустимы только: "
            + ", ".join(groups)
        )
    return problems


def _parse_evidence(raw: object, tree: Tree) -> list[EvidenceRef]:
    """Разобрать список evidence-ссылок и проверить каждую `verify_evidence`."""
    evidence: list[EvidenceRef] = []
    if not isinstance(raw, list):
        return evidence
    for raw_ev in raw:
        if not isinstance(raw_ev, dict):
            continue
        path = str(raw_ev.get("path") or "").strip()
        basis = str(raw_ev.get("basis") or "").strip()
        try:
            line = int(raw_ev["line"]) if raw_ev.get("line") is not None else None
        except (TypeError, ValueError):
            line = None
        if not path:
            continue
        note = " ".join(str(raw_ev.get("note") or "").split())[:_MAX_NOTE_CHARS]
        result = verify_evidence(path, line, basis, tree)
        evidence.append(EvidenceRef(
            path=result.path, line=result.line, basis=basis,
            verified=result.ok, reason=result.reason, note=note,
        ))
    return evidence


def _accept_summary(
    args: dict,
    plan_ids: set[str],
    verdicts_by_id: dict[str, ItemVerdict],
    tolerant: bool = False,
) -> tuple[ProjectSummary | None, str | None, bool]:
    """Разобрать `submit_summary` — текст вывода. Решение считает код.

    `conclusion` — ровно 3 буллита, каждый обрезается до 4 слов.

    Смысловой гейт (третий элемент кортежа — `gate_violation`): текст
    `conclusion` проверяется сторожем путей и идентификаторов
    (`report.guard.check_summary_text`) против файлов, подтверждённых
    evidence. В `tolerant` режиме нарушивший пункт заменяется пометкой,
    а не отклоняет весь вывод.

    Прежние гейты («blocked перевешивает процент», «нет движения — не GO»)
    сняты: решение определяется одним порогом готовности и ничем больше.
    Блокирующие буллиты остаются видны в отчёте, но решение не меняют.
    """
    raw_conclusion = args.get("conclusion")
    if not isinstance(raw_conclusion, list) or len(raw_conclusion) != _MAX_CONCLUSION_BULLETS:
        prislano = len(raw_conclusion) if isinstance(raw_conclusion, list) else "не список"
        return None, (f"conclusion: нужно ровно {_MAX_CONCLUSION_BULLETS} буллита, "
                      f"прислано {prislano}"), False
    conclusion = [_trim_words(str(b), _MAX_CONCLUSION_WORDS)
                  for b in raw_conclusion if str(b).strip()]
    if len(conclusion) != _MAX_CONCLUSION_BULLETS:
        return None, "conclusion: все 3 буллита должны быть непустыми", False

    verified_paths = {
        e.path for verdict in verdicts_by_id.values()
        for e in verdict.evidence if e.verified
    }
    checked: list[str] = []
    for index, text in enumerate(conclusion, start=1):
        violations = check_summary_text(text, plan_ids, verified_paths)
        if not violations:
            checked.append(text)
            continue
        if not tolerant:
            return None, (f"conclusion, пункт {index}: "
                          + "; ".join(v.render() for v in violations)), True
        checked.append(_ITEM_STRUCK)

    # Готовность и решение — детерминированный расчёт по принятым статусам.
    # Что модель думает о решении, роли не играет: поля для него в схеме
    # вызова нет.
    readiness = calculate_progress(
        [c for v in verdicts_by_id.values() for c in v.criteria]
    ) or 0
    return ProjectSummary(
        decision=compute_decision(readiness),
        conclusion=checked,
        reason=decision_reason(readiness),
    ), None, False


def _trim_words(text: str, limit: int) -> str:
    return " ".join(text.split()[:limit])


"""Единая точка разбора текстового ввода: два формата, один результат.

Форматов входа два, и различать их надо детерминированно, а не угадывать по
содержимому на ходу:

* **Файл инициативы из колоды** (`agent_md`) — шапка «Клиентский путь:» +
  «Проект:», затем все `##` подряд, затем все буллиты, затем дословный хвост.
* **Ручной клиентский путь** (`journey_text`) — буллиты лежат под каждым `##`.

Различает их структура, а не шапка: «Клиентский путь:» и «Проект:» есть у
обоих форматов. В колоде все `##` идут подряд до первого буллита, поэтому ни
один буллит не встречается раньше последнего заголовка; в ручном пути буллиты
лежат под каждым `##`. Подробности и краевые случаи — в
`agent_md.looks_like_agent_md`.

Цена ошибки распознавания несимметрична, но велика в обе стороны: принять
колоду за ручной путь — затянуть её дословный хвост в буллиты и раздуть
знаменатель готовности (на корпусе из 102 файлов старый парсер делал это во
всех 82 случаях, где не падал совсем); принять ручной путь за колоду — свалить
все его этапы в один.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from pko.progress.agent_md import AgentPlan, looks_like_agent_md, parse_agent_md
from pko.progress.journey_text import JourneyParse, parse_journey_text


@dataclass(frozen=True)
class PlanInput:
    """Разобранный ввод плюс то, что нужно отчёту помимо этапов."""

    parse: JourneyParse
    source_format: str = "journey_text"
    source_digest: str = ""
    stages: list[str] = field(default_factory=list)
    source_text: str = ""
    effect_quotes: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    @property
    def items(self):
        return self.parse.items

    @property
    def context(self) -> dict[str, str]:
        return self.parse.context


def parse_plan_text(raw: str) -> PlanInput:
    if looks_like_agent_md(raw):
        plan: AgentPlan = parse_agent_md(raw)
        return PlanInput(
            parse=plan.to_journey_parse(),
            source_format="agent_md",
            source_digest=plan.source_digest,
            stages=list(plan.stages),
            source_text=plan.source_text,
            effect_quotes=plan.effect_quotes,
            notes=list(plan.notes),
        )
    return PlanInput(parse=parse_journey_text(raw), source_format="journey_text")

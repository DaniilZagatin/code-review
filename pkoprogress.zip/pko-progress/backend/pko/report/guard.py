"""Сторож текста отчёта: проверяет, что текст не вводит идентификаторы и пути,
которых нет в модели. Нарушение не правится — текст отбрасывается.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from pko.extractors.base import CODE_SUFFIXES, DATA_SUFFIXES

ID_PATTERN = re.compile(r"(?<![A-Za-z0-9\-])(?:NEED|CP|AP-CP|AP|BBB|AO|GRD)-[A-Za-z0-9\-]{2,}\b")
_SUFFIXES = "|".join(s.lstrip(".") for s in CODE_SUFFIXES + DATA_SUFFIXES)
PATH_PATTERN = re.compile(rf"\b[\w./-]+\.(?:{_SUFFIXES})\b")
CHECK_ID_PATTERN = re.compile(r"\bCHK-[A-Z]+-\d+\b")


@dataclass(frozen=True)
class GuardViolation:
    code: str
    detail: str

    def render(self) -> str:
        return f"{self.code}: {self.detail}"


def check_text(text: str, allowed_ids: set[str], allowed_paths: set[str] | None = None
               ) -> list[GuardViolation]:
    """Вернуть нарушения. Пустой список — текст можно публиковать."""
    violations: list[GuardViolation] = []
    allowed_paths = allowed_paths or set()

    unknown_ids = sorted(
        {m for m in ID_PATTERN.findall(text) if m not in allowed_ids and not _is_check_id(m)}
    )
    if unknown_ids:
        violations.append(
            GuardViolation(
                "UNKNOWN_ID",
                "в тексте есть идентификаторы, которых нет в модели: " + ", ".join(unknown_ids[:5]),
            )
        )

    unknown_paths = sorted(
        {p for p in PATH_PATTERN.findall(text) if not _path_allowed(p, allowed_paths)}
    )
    if unknown_paths:
        violations.append(
            GuardViolation(
                "UNKNOWN_PATH",
                "в тексте есть пути к файлам, не подтверждённые доказательствами: "
                + ", ".join(unknown_paths[:5]),
            )
        )
    return violations


def _path_allowed(path: str, allowed: set[str]) -> bool:
    """Путь разрешён целиком или как короткое имя разрешённого файла.

    Ссылка вида «router.py:7 — start_task» — нормальный рабочий формат
    комментария: полное имя не умещается в 200 символах, а читатель отчёта
    найдёт файл по короткому имени. Отклоняется только имя файла, которого
    в материалах нет ни под полным, ни под коротким вариантом.
    """
    if path in allowed:
        return True
    suffix = "/" + path
    return any(a == path or a.endswith(suffix) for a in allowed)


def _is_check_id(value: str) -> bool:
    return bool(CHECK_ID_PATTERN.fullmatch(value))


def check_explanation(text: str, tree_files: set[str]) -> list[GuardViolation]:
    """Проверить свободный текст объяснения вердикта."""
    return check_text(text, allowed_ids=set(), allowed_paths=tree_files)


def check_summary_text(
    text: str, plan_ids: set[str], verified_paths: set[str]
) -> list[GuardViolation]:
    """Проверить текст сводного вывода по проекту."""
    return check_text(text, allowed_ids=plan_ids, allowed_paths=verified_paths)

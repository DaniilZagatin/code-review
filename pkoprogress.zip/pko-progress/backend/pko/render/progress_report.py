"""Офлайн-отчёт о прогрессе: клиентский путь из образа результата, сверенный
с материалами проекта.

В том же стиле, что и остальные отчёты PKO (`render/base.py`: `page()`, `esc()`,
общая CSS) — один самодостаточный файл без внешних ресурсов.

Секция «Путь» — исключение из «всё генерирует Python»: её рисует собранный
React-бандл (`frontend-app/`, см. `_load_journey_bundle`). Бандл собирается
один раз (`npm run build`) и не коммитится — читается с диска при каждом вызове.

Цвет и процент этапа считаются здесь по той же формуле, что и в шаблоне
дашборда (`dashboard_template.html`): вес применимых буллитов, делённый на их
число. Формула живёт в `ItemVerdict.percent`, а пороги цвета — в
`percent_color`, и обе стороны берут их отсюда, поэтому офлайн-отчёт и
веб-экран разойтись не могут.
"""

from __future__ import annotations

import json
from pathlib import Path

from pko.errors import PkoError
from pko.progress.schema import ProgressModel
from pko.render.base import page

# frontend-app/dist/index.html — собранный React-бандл секции «Путь».
_JOURNEY_BUNDLE_PATH = Path(__file__).resolve().parents[3] / "frontend-app" / "dist" / "index.html"

# Пороги цвета этапа — те же, что в шаблоне дашборда: от 80% зелёный, от 40%
# жёлтый, ниже красный. Этап без применимых буллитов не красный, а серый: он
# не «провален», он просто не про эту инициативу.
COLOR_LABELS = {
    "green": "Сделано",
    "amber": "Частично",
    "red": "Не начато",
    "purple": "Не относится",
}


def percent_color(percent: int | None) -> str:
    if percent is None:
        return "purple"
    if percent >= 80:
        return "green"
    if percent >= 40:
        return "amber"
    return "red"


_EXTRA_CSS = """
:root {
  --accent: #7c3aed;
  --accent-light: #f3e5fd;
  --border: #e4d6fa;
  --journey-panel: #f3e5fd;
}
"""


def render_progress_report(model: ProgressModel) -> str:
    title = "Отчёт о готовности"
    subtitle = (f"{model.meta.get('project_name') or model.meta.get('repo', '—')} · "
                f"{model.meta.get('client_path_name', '—')}")
    decision = model.summary.decision if model.summary else ""
    badge = f"{model.readiness}% готовности" + (f" · {decision}" if decision else "")

    body = _journey_section(model)
    footer = (
        f"PKO progress · коммит {str(model.meta.get('commit', ''))[:8] or '—'} · "
        f"{model.meta.get('generated_at', '')}"
    )
    html = page(title=title, subtitle=subtitle, badge=badge, body=body, footer=footer)
    return html.replace("</style>", _EXTRA_CSS + "</style>", 1)


def _load_journey_bundle() -> tuple[str, str]:
    """Читает собранный React-бандл и возвращает `(<style>…</style>, <script>…</script>)`."""
    if not _JOURNEY_BUNDLE_PATH.exists():
        raise PkoError(
            "Дашборд-путь не собран.",
            hint=f"выполните: cd frontend-app && npm install && npm run build "
                 f"(ожидается {_JOURNEY_BUNDLE_PATH})",
        )
    html = _JOURNEY_BUNDLE_PATH.read_text(encoding="utf-8")

    style_start = html.index("<style")
    style_end = html.index("</style>", style_start) + len("</style>")
    style_tag = html[style_start:style_end]

    script_start = html.index('<script type="module"')
    script_end = html.index("</script>", script_start) + len("</script>")
    script_tag = html[script_start:script_end]

    return style_tag, script_tag


def _journey_items(model: ProgressModel) -> list[dict[str, object]]:
    """Этапы в контракте CLI-бандла «Пути».

    Бандл ждёт плоский набор полей (`title`/`status`/`label`/`color`/`pct`/
    `explanation`) и не знает про буллиты. Его мы сознательно не переделываем:
    веб-экран и скачиваемый HTML работают на новом контракте, а CLI-отчёт
    получает ту же картину, свёрнутую в одну строку — перечень буллитов этапа
    в порядке образа результата.
    """
    rows: list[dict[str, object]] = []
    for verdict in model.verdicts:
        item = model.items.get(verdict.item_id)
        title = item.title if item else verdict.item_id
        percent = verdict.percent()
        color = percent_color(percent)
        texts = item.criteria if item else []
        rows.append({
            "title": title,
            "status": color,
            "label": COLOR_LABELS[color],
            "color": color,
            "pct": percent if percent is not None else 0,
            "explanation": "; ".join(texts),
        })
    return rows


def _journey_section(model: ProgressModel) -> str:
    """Дашборд-путь: точную геометрию и раскладку рисует React-бандл
    (`frontend-app/`) — здесь только данные и точка монтирования."""
    if not model.verdicts:
        return ""
    style_tag, script_tag = _load_journey_bundle()
    items_json = json.dumps(_journey_items(model), ensure_ascii=False)

    return f"""
  <div id="journey-root"></div>
  {style_tag}
  <script>window.__JOURNEY_ITEMS__ = {items_json};</script>
  {script_tag}
"""

"""Скачиваемый HTML-дашборд готовности проекта — отдельная генерация, отдельно
от HTML-отчёта (`progress_report.py` + React-бандл `frontend-app/`, не трогается).

Идея: один самодостаточный HTML-файл (`dashboard_template.html`), который
повторяет веб-экран результатов (`frontend-web/src/components/dashboard/`) —
формат OnePage: шапка с оценкой и решением, строка шкалы, до четырёх
тематических блоков с раскрытием пункта на «Описание» и «Подтверждение».
Шаблон — статический HTML+CSS+JS без внешних ресурсов; данные подставляются
одним JSON-блоком (маркер `/*__DATA__*/`).

Источник данных — тот же контракт, что уходит на веб-экран:
`render/dashboard_data.py::build_dashboard_data` (в вебе он лежит в
`job.result`). Отсюда правило: **шаблон ничего не вычисляет.** Проценты,
готовность, решение и шкала с весами приходят готовыми. Вторая формула в
разметке неизбежно расходится с первой — так уже было, и веб показывал не тот
отчёт, что скачиваемый HTML.

Безопасность: тексты агента (title/points/description/conclusion)
вставляются в страницу через `textContent` в шаблоне, а в JSON
предварительно заменяются все `<` на `\u003c` — поэтому даже `</script>` или
разметка в ответе агента не могут выйти за пределы `<script>` с данными и не
инъецируют HTML.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_DASHBOARD_TEMPLATE_PATH = Path(__file__).parent / "dashboard_template.html"

# Маркер в шаблоне, который заменяется на JSON-литерал с данными агента.
# Валидный JS-комментарий → файл остаётся открываемым как заглушка (нет данных
# → window.__DATA__ = ; был бы синтаксической ошибкой, поэтому заменяем весь
# маркер вместе с `/* */`).
_DATA_MARKER = "/*__DATA__*/"


def render_dashboard_html(result: dict[str, Any]) -> str:
    """Собрать самодостаточный HTML-дашборд из контракта `build_dashboard_data`.

    `result` — словарь с ключами `meta`, `readiness`, `items`, опционально
    `summary` (тот же вид, что отдаёт `GET /api/analyses/{id}` в статусе READY).
    Никаких путей к файлам/тестов/технических деталей здесь нет — те же поля,
    что рисует веб-экран 3.
    """
    template = _DASHBOARD_TEMPLATE_PATH.read_text(encoding="utf-8")
    data_json = _to_safe_json(result)
    return template.replace(_DATA_MARKER, data_json, 1)


def _to_safe_json(result: dict[str, Any]) -> str:
    """JSON-литерал, безопасный для встраивания в `<script>` HTML-страницы.

    `json.dumps` сам по себе не экранирует `<`/`>` — строка вроде `"</script>"`
    в данных агента досрочно закрыла бы тег `<script>` с данными. Замена `<` на
    `\\u003c` делает литерал безопасным: JS раскрывает последовательность
    обратно в `<`, а в HTML-потоке её нет. `>` экранировать не нужно — без `<>`
    тег не сформировать.
    """
    return json.dumps(result, ensure_ascii=False).replace("<", "\\u003c")

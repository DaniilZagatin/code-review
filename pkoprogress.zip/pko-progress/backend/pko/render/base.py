"""Общие части HTML-отчётов.

Оформление повторяет уже принятый в комплекте вид (`taxonomy_v1_1.html`,
`passports_v1_1.html`): те же цветовые переменные, карточки, таблицы и теги
объектов. Отчёт остаётся одним самодостаточным файлом без внешних ресурсов.

Дополнение к исходному оформлению — бейдж происхождения у каждого поля: читатель
должен видеть, что перед ним, наблюдение в коде или неподтверждённое допущение.
"""

from __future__ import annotations

import html
import re
from typing import Any




CSS = """
:root {
  --bg: #f8f9fb; --surface: #ffffff; --border: #e2e5ea;
  --text: #1e2229; --text-secondary: #5e6879;
  --accent: #2563eb; --accent-light: #eff4ff;
  --green: #059669; --green-light: #ecfdf5;
  --amber: #d97706; --amber-light: #fffbeb;
  --red: #dc2626; --red-light: #fef2f2;
  --purple: #7c3aed; --purple-light: #f5f3ff;
  --cyan: #0891b2; --cyan-light: #ecfeff;
  --pink: #db2777; --pink-light: #fdf2f8;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', Roboto, sans-serif;
  background: var(--bg); color: var(--text); line-height: 1.6; padding: 2rem 1rem;
}
.container { max-width: 1200px; margin: 0 auto; }
.header { text-align: center; padding: 2rem 0 2.5rem; }
.header h1 { font-size: 1.75rem; font-weight: 700; letter-spacing: -0.02em; }
.header .subtitle { color: var(--text-secondary); margin-top: 0.5rem; font-size: 0.95rem; }
.badge {
  display: inline-block; background: var(--accent-light); color: var(--accent);
  font-size: 0.75rem; font-weight: 600; padding: 0.2rem 0.75rem; border-radius: 999px;
  margin-top: 0.5rem; letter-spacing: 0.02em;
}
.badge-warn { background: var(--amber-light); color: var(--amber); }
.badge-danger { background: var(--red-light); color: var(--red); }
.meta-bar {
  display: flex; flex-wrap: wrap; gap: 1rem; justify-content: center;
  padding: 1rem 1.5rem; background: var(--surface); border: 1px solid var(--border);
  border-radius: 12px; margin-bottom: 1.5rem; font-size: 0.85rem;
}
.meta-item { display: flex; align-items: center; gap: 0.4rem; }
.meta-label { color: var(--text-secondary); }
.meta-value { font-weight: 600; }
.section {
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 12px; margin-bottom: 1.5rem; overflow: hidden;
}
.section-header {
  padding: 1rem 1.5rem; display: flex; align-items: center; gap: 0.75rem;
  border-bottom: 1px solid var(--border);
}
.section-header .icon {
  width: 36px; height: 36px; border-radius: 8px; display: flex;
  align-items: center; justify-content: center; font-size: 1rem; flex-shrink: 0;
}
.section-header h2 { font-size: 1.05rem; font-weight: 600; flex: 1; }
.section-header .count {
  font-size: 0.8rem; color: var(--text-secondary); background: var(--bg);
  padding: 0.15rem 0.6rem; border-radius: 999px;
}
.section-body { padding: 1.5rem; }
.tag {
  display: inline-block; font-size: 0.75rem; font-weight: 600;
  padding: 0.15rem 0.5rem; border-radius: 4px; margin-right: 0.25rem;
}
.tag-need { background: var(--accent-light); color: var(--accent); }
.tag-cp { background: var(--green-light); color: var(--green); }
.tag-ap { background: var(--purple-light); color: var(--purple); }
.tag-bbb { background: var(--amber-light); color: var(--amber); }
.tag-ao { background: var(--cyan-light); color: var(--cyan); }
.tag-grd { background: var(--pink-light); color: var(--pink); }
.obj-table { width: 100%; border-collapse: collapse; font-size: 0.88rem; }
.obj-table th {
  text-align: left; padding: 0.6rem 0.75rem; font-weight: 600; font-size: 0.8rem;
  text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-secondary);
  border-bottom: 2px solid var(--border);
}
.obj-table td { padding: 0.6rem 0.75rem; border-bottom: 1px solid var(--border); vertical-align: top; }
.obj-table tr:last-child td { border-bottom: none; }
.obj-table .id-cell { font-weight: 600; white-space: nowrap; font-size: 0.82rem; }
.obj-table .desc-cell { color: var(--text-secondary); }
.origin {
  display: inline-block; font-size: 0.68rem; font-weight: 700; letter-spacing: 0.03em;
  padding: 0.05rem 0.4rem; border-radius: 4px; margin-left: 0.4rem; white-space: nowrap;
}
.origin-accent { background: var(--accent-light); color: var(--accent); }
.origin-green { background: var(--green-light); color: var(--green); }
.origin-amber { background: var(--amber-light); color: var(--amber); }
.origin-red { background: var(--red-light); color: var(--red); }
.origin-purple { background: var(--purple-light); color: var(--purple); }
.evidence { display: block; margin-top: 0.35rem; font-size: 0.78rem; color: var(--text-secondary); }
.evidence code { background: var(--bg); padding: 0.05rem 0.3rem; border-radius: 3px; }
.evidence-row { padding: 0.1rem 0; }
.evidence-where {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 0.72rem;
  color: var(--text-muted, #98a2b3); white-space: nowrap;
}
.evidence-more { font-style: italic; opacity: 0.8; }
/* Картотека: сетка карточек и страница одного паспорта. Повторяет вид
   `passports_v1_1.html` — обзор из коротких карточек, подробности по клику. */
.section-title {
  font-size: 0.78rem; font-weight: 700; text-transform: uppercase;
  letter-spacing: 0.06em; color: var(--text-secondary); margin: 1.75rem 0 0.75rem;
}
.grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
  gap: 0.75rem;
}
.card {
  background: var(--surface); border: 1px solid var(--border); border-radius: 10px;
  padding: 0.9rem 1rem; cursor: pointer; transition: border-color 0.15s, transform 0.15s;
}
.card:hover { border-color: var(--accent); transform: translateY(-1px); }
.card .ctitle { font-weight: 600; font-size: 0.92rem; line-height: 1.35; }
.card .cid {
  display: inline-block; font-size: 0.7rem; font-weight: 700; color: var(--text-secondary);
  margin-top: 0.2rem; font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
}
.card .cdesc { color: var(--text-secondary); font-size: 0.83rem; margin-top: 0.4rem; }
.card .cmeta { font-size: 0.72rem; color: var(--text-secondary); margin-top: 0.5rem; }
.page { display: none; }
.page.active { display: block; }
.page-bar { display: flex; align-items: center; gap: 0.6rem; margin-bottom: 1rem; font-size: 0.85rem; }
.page-bar .back { color: var(--accent); cursor: pointer; text-decoration: none; }
.page-bar .pbc { color: var(--text-secondary); font-family: ui-monospace, Menlo, monospace; }
.ptable { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
.ptable td { padding: 0.6rem 0.8rem; border-bottom: 1px solid var(--border); vertical-align: top; }
.ptable tr:last-child td { border-bottom: none; }
.ptable .pl { width: 34%; color: var(--text-secondary); font-weight: 500; }
.hidden { display: none; }
/* Компактные списки обзора: блок, операция, ограничение — по одной строке. */
.bbb-list, .ao-list, .grd-list { display: flex; flex-direction: column; gap: 0.5rem; }
.bbb-item, .ao-item, .grd-item {
  display: flex; align-items: flex-start; gap: 0.75rem;
  padding: 0.6rem 0.85rem; background: var(--bg); border-radius: 8px; font-size: 0.88rem;
}
.bbb-item .bbb-id, .ao-item .ao-id, .grd-item .grd-id {
  font-weight: 700; font-size: 0.8rem; white-space: nowrap;
}
.bbb-item .bbb-id { color: var(--amber); }
.ao-item .ao-id { color: var(--cyan); }
.grd-item .grd-id { color: var(--pink); }
.bbb-item .bbb-info, .ao-item .ao-info, .grd-item .grd-info { flex: 1; }
.bbb-item .bbb-name, .ao-item .ao-name, .grd-item .grd-name { font-weight: 600; }
.bbb-item .bbb-desc, .ao-item .ao-desc, .grd-item .grd-desc {
  color: var(--text-secondary); font-size: 0.85rem; margin-top: 0.1rem;
}
.side-note { font-size: 0.75rem; color: var(--text-secondary); white-space: nowrap; }
.run-notes {
  margin-top: 1rem; font-size: 0.78rem; color: var(--text-secondary); line-height: 1.5;
}
.gap-list { display: flex; flex-direction: column; gap: 0.5rem; }
.gap-item {
  padding: 0.6rem 0.9rem; background: var(--amber-light); border-radius: 8px;
  font-size: 0.85rem; color: #7c4a03;
}
.authorship {
  margin-top: 0.6rem; font-size: 0.76rem; color: var(--text-secondary);
  border-top: 1px solid var(--border); padding-top: 0.5rem;
}
.footer {
  text-align: center; color: var(--text-secondary); font-size: 0.8rem;
  padding: 2rem 0 1rem; border-top: 1px solid var(--border); margin-top: 0.5rem;
}
@media (max-width: 768px) {
  .obj-table th, .obj-table td { padding: 0.5rem; }
  .meta-bar { flex-direction: column; align-items: center; }
}
"""


# Кто написал обзорный абзац. Пометка ставится в обоих случаях: правило
# «без пометки — значит, посчитано» работает только там, где пометка бывает.
def esc(value: Any) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def page(title: str, subtitle: str, badge: str, body: str, footer: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>{esc(title)}</title>
<style>{CSS}</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>{esc(title)}</h1>
    <div class="subtitle">{esc(subtitle)}</div>
    <div class="badge">{badge}</div>
  </div>
{body}
  <div class="footer">{footer}</div>
</div>
</body>
</html>
"""

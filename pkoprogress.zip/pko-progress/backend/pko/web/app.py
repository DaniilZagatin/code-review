"""Веб API `pko progress`: асинхронный анализ + живой прогресс по SSE.

Локальный инструмент: сервер поднимается на своей машине, git-доступ — через
уже настроенный SSH-agent (см. README). Логика пайплайна не дублируется с
CLI — обе стороны зовут один и тот же `pko.progress.pipeline.run_progress`,
поэтому веб и `pko progress` не могут разойтись в поведении.

UI — отдельный Next.js-проект `frontend-web/` (свой dev/прод-процесс, ходит
сюда через `/api/*`), этот модуль отдаёт только JSON и SSE, HTML не рендерит и
не раздаёт статику. Реальный прогон может занимать от секунд до ~15 минут
только на клонирование репозитория плюс агентная сессия до 60 шагов.
"""

from __future__ import annotations

import json
import queue

import anyio
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.requests import Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse

from pko.errors import PkoError
from pko.render.dashboard_html import render_dashboard_html
from pko.llm.registry import get_spec
from pko.llm.tracing import init_phoenix_tracing
from pko.util.env import load_env
from pko.web import analyses

load_env()
init_phoenix_tracing()

app = FastAPI(title="PKO progress")


@app.exception_handler(PkoError)
def _handle_pko_error(request: Request, exc: PkoError) -> JSONResponse:
    return JSONResponse(status_code=400, content={"message": exc.message, "hint": exc.hint})


_HEARTBEAT_SECONDS = 15


def _get_job_or_404(analysis_id: str) -> analyses.AnalysisJob:
    job = analyses.get_job(analysis_id)
    if job is None:
        raise PkoError("Анализ не найден.", hint=f"неизвестный analysis_id: {analysis_id!r}")
    return job


@app.post("/api/analyses")
async def create_analysis(
    journey_text: str = Form(""),
    repository: str = Form(""),
    branch: str = Form(""),
    thinking: bool = Form(False),
    description: str = Form(""),
    files: list[UploadFile] = File([]),
) -> JSONResponse:
    """`repository` (необязательно) и `files` — два независимых источника
    evidence. Пустой репозиторий — анализ только по загруженным файлам.
    Оба пустые — тоже валидный запрос: агент получает пустой снимок
    материалов и сам решает, что писать в вердикт.

    `journey_text` — клиентский путь текстом: название, этапы (##) и буллиты
    (-). Код разбирает его в план; модель только проверяет готовность пунктов.

    `description` — описание инициативы: из него агент формулирует «Было» и
    «Стало» первым шагом сессии (`submit_brief`). Пусто — шаг пропускается.

    `thinking` — переключатель режима рассуждения модели с формы.
    """
    spec = get_spec("matcher", thinking=thinking)
    if spec is None:
        raise PkoError(
            "Роль matcher не заведена: LLM-эндпоинт не задан и дефолтный GLM отключён.",
            hint="PKO_ASSEMBLER_* по умолчанию не обязательны — агент поднимается "
                 "на внутреннем GLM-5.2 (pko/defaults.py); задайте переменные до "
                 "запуска pko serve только для переопределения.",
        )

    # `files=[UploadFile()]` пустышка — Starlette так отдаёт поле, которое
    # клиент вообще не передал в multipart-форме.
    uploads = [
        (f.filename, await f.read())
        for f in files
        if f.filename
    ]

    job = analyses.create_analysis(
        journey_text=journey_text,
        repository=repository,
        branch=branch,
        uploads=uploads,
        spec=spec,
        description=description,
    )
    return JSONResponse({"analysis_id": job.id, "status": job.status})


@app.get("/api/analyses/{analysis_id}/events")
async def stream_analysis_events(analysis_id: str) -> StreamingResponse:
    job = _get_job_or_404(analysis_id)

    async def generate():
        if job.status != "PROCESSING":
            terminal = {"type": "analysis_ready"} if job.status == "READY" else {"type": "error", **(job.error or {})}
            yield f"data: {json.dumps(terminal, ensure_ascii=False)}\n\n"
            return

        while True:
            try:
                event = await anyio.to_thread.run_sync(lambda: job.events.get(timeout=_HEARTBEAT_SECONDS))
            except queue.Empty:
                yield ": keepalive\n\n"
                continue
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
            if event.get("type") in ("analysis_ready", "error"):
                break

    return StreamingResponse(generate(), media_type="text/event-stream")


@app.get("/api/analyses/{analysis_id}")
async def get_analysis(analysis_id: str) -> JSONResponse:
    job = _get_job_or_404(analysis_id)
    if job.status == "PROCESSING":
        return JSONResponse({"status": "PROCESSING"})
    if job.status == "ERROR":
        return JSONResponse(status_code=400, content={"status": "ERROR", **(job.error or {})})
    return JSONResponse({"status": "READY", **(job.result or {})})


@app.get("/api/analyses/{analysis_id}/dashboard.html")
async def get_analysis_dashboard(analysis_id: str) -> HTMLResponse:
    """Самодостаточный HTML-дашборд готовности проекта для скачивания."""
    job = _get_job_or_404(analysis_id)
    if job.status == "PROCESSING":
        raise PkoError("Анализ ещё не завершён.", hint="дождитесь READY по SSE/GET, затем запросите дашборд")
    if job.status == "ERROR":
        raise PkoError(job.error["message"] if job.error else "Анализ завершился с ошибкой.",
                       hint=(job.error or {}).get("hint", ""))
    return HTMLResponse(render_dashboard_html(job.result or {}))

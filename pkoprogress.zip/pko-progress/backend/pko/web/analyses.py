"""Асинхронные задачи анализа для живого веб-фронтенда (`frontend-web/`).

Локальный инструмент, один процесс — как и весь `pko serve`. Поэтому реестр
задач — обычный `dict` в памяти, выполнение — `threading.Thread`, обмен
событиями прогресса — `queue.Queue`.

Один прогон = один `AnalysisJob`. `run_progress` уже умеет сообщать о
прогрессе через `on_event` — здесь это событие просто складывается в очередь
задачи, откуда его читает SSE-эндпоинт.
"""

from __future__ import annotations

import queue
import shutil
import tempfile
import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from pko.errors import PkoError
from pko.llm.registry import ModelSpec
from pko.progress.local_source import (
    build_empty_workspace,
    build_target_repo_from_uploads,
    merge_with_uploads,
)
from pko.progress.pipeline import run_progress
from pko.progress.target_repo import TargetRepo, load_target, open_repo_source
from pko.render.dashboard_data import build_dashboard_data

Status = Literal["PROCESSING", "READY", "ERROR"]

# Реестр живёт в памяти процесса и раньше рос без потолка: каждый `POST
# /api/analyses` добавлял задачу с очередью событий, и долгая жизнь `pko serve`
# заканчивалась раздутой памятью. При достижении потолка вытесняется самая
# старая завершённая задача; PROCESSING не вытесняются никогда.
MAX_JOBS = 100


@dataclass
class AnalysisJob:
    id: str
    status: Status = "PROCESSING"
    events: "queue.Queue[dict[str, Any]]" = field(default_factory=queue.Queue)
    result: dict[str, Any] | None = None
    error: dict[str, str] | None = None


_JOBS: dict[str, AnalysisJob] = {}


def get_job(job_id: str) -> AnalysisJob | None:
    return _JOBS.get(job_id)


def _prune_jobs() -> None:
    """Освободить место под новую задачу, вытеснив самую старую завершённую."""
    if len(_JOBS) < MAX_JOBS:
        return
    for job_id, job in _JOBS.items():
        if job.status != "PROCESSING":
            _JOBS.pop(job_id, None)
            return


def create_analysis(
    journey_text: str,
    repository: str,
    branch: str,
    uploads: list[tuple[str, bytes]],
    spec: ModelSpec,
    description: str | None = None,
) -> AnalysisJob:
    """Провалидировать вход, создать задачу и сразу запустить её в фоне.

    `repository` — SSH-ссылка или локальный путь (автоопределение, как в CLI);
    пустое поле — анализ только по загруженным файлам (без репозитория).
    `branch` пустая — ветка по умолчанию (master/main), имеет смысл только
    при непустом репозитории.
    `description` — описание инициативы: из него агент формулирует «Было» и
    «Стало» первым шагом (`submit_brief`). None/пусто — шаг пропускается.
    """
    if not journey_text or not journey_text.strip():
        raise PkoError(
            "Не задан клиентский путь.",
            hint="введите название пути, этапы и их пункты в текстовое поле",
        )

    repository = repository.strip() or ""
    branch = (branch.strip() or None) if repository else None

    description = (description or "").strip() or None

    job = AnalysisJob(id="an_" + uuid.uuid4().hex[:12])
    _prune_jobs()
    _JOBS[job.id] = job

    tmp_dir = Path(tempfile.mkdtemp(prefix=f"pko-analysis-{job.id}-"))

    thread = threading.Thread(
        target=_execute,
        args=(job, journey_text, repository, branch, uploads, tmp_dir,
              spec, description),
        daemon=True,
    )
    thread.start()
    return job


def _build_target(
    repository: str, branch: str | None, uploads: list[tuple[str, bytes]], workspace_dir: Path,
    emit,
) -> tuple[TargetRepo, str]:
    """Git, файлы, или оба сразу."""
    target: TargetRepo | None = None
    name = ""
    if repository:
        emit("phase", {"phase": "materials_loading", "label": "Подключаем репозиторий"})
        git_repo, name = open_repo_source(repository, branch=branch)
        target = load_target(git_repo, branch)
    else:
        emit("phase", {"phase": "materials_loading", "label": "Обрабатываем загруженные файлы"})

    if uploads:
        target = (
            merge_with_uploads(target, uploads, workspace_dir) if target is not None
            else build_target_repo_from_uploads(uploads, workspace_dir)
        )
    elif target is None:
        target = build_empty_workspace(workspace_dir)
    emit("phase", {"phase": "materials_ready", "label": "Материалы проекта готовы"})
    return target, name


def _execute(
    job: AnalysisJob,
    journey_text: str,
    repository: str,
    branch: str | None,
    uploads: list[tuple[str, bytes]],
    tmp_dir: Path,
    spec: ModelSpec,
    description: str | None = None,
) -> None:
    def emit(kind: str, data: dict[str, Any]) -> None:
        job.events.put({"type": kind, **data})

    try:
        target, name = _build_target(repository, branch, uploads, tmp_dir / "workspace", emit)
        model = run_progress(
            journey_text, name, target, spec, on_event=emit, description=description,
        )

        job.result = build_dashboard_data(model)
        job.status = "READY"
        job.events.put({"type": "analysis_ready"})
    except PkoError as exc:
        job.error = {"message": exc.message, "hint": exc.hint}
        job.status = "ERROR"
        job.events.put({"type": "error", **job.error})
    except Exception as exc:  # noqa: BLE001
        job.error = {"message": "Внутренняя ошибка анализа.", "hint": str(exc)}
        job.status = "ERROR"
        job.events.put({"type": "error", **job.error})
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

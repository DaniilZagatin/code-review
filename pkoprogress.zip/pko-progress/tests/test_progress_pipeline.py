"""`run_progress` — сквозная сборка ProgressModel, с фокусом на `on_event`.

Проверяет колбэк живого прогресса напрямую через `run_progress`, без CLI/HTTP
обвязки.
"""

import unittest

import pko.llm.client as client_module
from agent_script import (
    AFTER,
    BEFORE,
    BULLETS,
    CLIENT_PATH_NAME,
    CONCLUSION,
    CONTEXT,
    DESCRIPTION,
    JOURNEY_TEXT,
    NOW,
    PROJECT_NAME,
    STAGE_TITLE,
    full_session,
)
from fixture_support import ensure_fixture, scripted_responses
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress.pipeline import run_progress
from pko.progress.target_repo import TargetRepo, load_target

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")


class RunProgressOnEventTest(unittest.TestCase):
    def setUp(self):
        repo = GitRepo(ensure_fixture())
        self.target: TargetRepo = load_target(repo, "master")

        import tempfile
        from pathlib import Path
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

        self._original_cache_dir = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = Path(self.tmp.name) / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._original_cache_dir)

        self._original_request = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original_request)

    def test_on_event_receives_phases_and_claims_in_order(self):
        ChatClient._create = scripted_responses(*full_session(with_brief=True))

        events: list[tuple[str, dict]] = []
        model = run_progress(
            JOURNEY_TEXT, "demo-repo", self.target, SPEC,
            on_event=lambda kind, data: events.append((kind, data)),
            description=DESCRIPTION,
        )

        self.assertEqual([kind for kind, _ in events], [
            "plan_ready", "claim_verified", "summary_ready",
        ])
        self.assertEqual(events[0][1]["item_count"], 1)
        self.assertEqual(events[0][1]["items"][0], {
            "title": STAGE_TITLE, "origin": "user", "criteria": 2,
        })
        # Один буллит done, второй planned -> (1 + 0) / 2 = 50%.
        self.assertEqual(events[1][1], {
            "title": STAGE_TITLE, "applicable": True, "percent": 50, "criteria": 2,
        })
        self.assertEqual(events[2][1]["decision"], "GO")

        # readiness считается кодом: («Да» 100 + «Нет» 0) / 2 = 50%.
        self.assertEqual(model.readiness, 50)
        self.assertEqual(model.summary.decision, "GO")
        self.assertEqual(model.summary.conclusion, CONCLUSION)
        self.assertIsInstance(model.summary.conclusion, list)
        self.assertEqual(model.summary_source, "llm")
        self.assertEqual(model.meta["client_path_name"], CLIENT_PATH_NAME)
        self.assertEqual(model.meta["project_name"], PROJECT_NAME)
        # submit_brief перезаписал before/now/after в meta.
        self.assertEqual(model.meta["before"], BEFORE)
        self.assertEqual(model.meta["now"], NOW)
        self.assertEqual(model.meta["after"], AFTER)
        self.assertEqual(model.criterion_counts()["done"], 1)

    def test_without_on_event_behaves_exactly_as_before(self):
        ChatClient._create = scripted_responses(
            *full_session(stage={"statuses": ["planned", "planned"]},
                          summary={"decision": "NO GO"})
        )
        model = run_progress(JOURNEY_TEXT, "demo-repo", self.target, SPEC)
        # Все planned -> 0%.
        self.assertEqual(model.readiness, 0)
        # Ниже порога — PIVOT. NO GO на текущем шаге не выдаётся.
        self.assertEqual(model.summary.decision, "PIVOT")
        self.assertEqual(model.verdicts[0].percent(), 0)


if __name__ == "__main__":
    unittest.main()

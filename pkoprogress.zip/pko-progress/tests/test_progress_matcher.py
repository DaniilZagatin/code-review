"""Единый агент (`run_agent`): готовый клиентский путь -> оценка этапов по
материалам -> вердикт.

Транспорт подменяется: `ChatClient._create` отдаёт по одному заготовленному
ответу на каждый ход сессии. Путь/строка/якорь проверяются на настоящей
фикстуре `mini_repo`.

Главный инвариант: **тексты пути не пишет модель**. Названия этапов и
буллиты приходят из текстового поля, разбираются кодом в `PlanItem` и
передаются агенту готовыми. Модель только проверяет готовность пунктов.
"""

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from fixture_support import ensure_fixture, make_openai_response, scripted_responses
from pko.errors import PkoError
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress import matcher
from pko.progress.journey_text import parse_journey_text
from pko.progress.matcher import (
    DEFAULT_MAX_STEPS,
    find_unclaimed_paths,
    load_system_prompt,
    run_agent,
)
from pko.progress.schema import CriterionVerdict, EvidenceRef, ItemVerdict, PlanItem

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")

ROUTER_EVIDENCE = [{"path": "backend/src/api/v1/router.py", "line": 7,
                    "basis": "функция start_task ставит задачу в обработку"}]

BULLETS = ["Определены источники обращений", "Подтверждена скорость обработки"]

CONTEXT = {
    "client_path_name": "Постановка задачи в работу",
    "project_name": "Приём обращений",
    "before": "задача пересылается вручную и теряется между сменами",
    "after": "задача попадает исполнителю сразу и видна обеим сторонам",
}

CONCLUSION = [
    "Ценность подтверждена материалами",
    "Измеримость результата не закрыта",
    "Можно идти дальше",
]


def _call(name: str, args: dict, call_id: str | None = None) -> dict:
    return {
        "id": call_id or f"call_{name}",
        "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }


def tool_call(name: str, **args) -> dict:
    return {"content": None, "tool_calls": [_call(name, args)]}


def parallel_tool_calls(*calls: tuple[str, dict]) -> dict:
    return {"content": None, "tool_calls": [
        _call(name, args, call_id=f"call_{i}_{name}") for i, (name, args) in enumerate(calls)
    ]}


def make_plan(*stages: tuple[str, str, list[str]]) -> list[PlanItem]:
    """Собрать план: (id, title, bullets)."""
    items = []
    for i, (item_id, title, bullets) in enumerate(stages, start=1):
        items.append(PlanItem(id=item_id, title=title, criteria=bullets, origin="user"))
    return items


def criterion(applicable: bool = True, status: str = "done",
              evidence: list[dict] | None = None,
              proof: str = "", how: str = "", comment: str = "") -> dict:
    """Оценка одного буллита в том виде, в каком её присылает модель.

    `comment` — поле прежних версий: оно всё ещё читается как «как работает»,
    и тесты совместимости этим пользуются.
    """
    return {"applicable": applicable, "status": status, "evidence": evidence or [],
            "proof": proof, "how": how, "comment": comment}


def stage_args(item_id: str, applicable: bool = True,
               criteria: list[dict] | None = None) -> dict:
    if criteria is None:
        criteria = [criterion(status="done", evidence=ROUTER_EVIDENCE),
                    criterion(status="planned")]
    return {"item_id": item_id, "applicable": applicable, "criteria": criteria}


def rate(item_id: str, applicable: bool = True, criteria: list[dict] | None = None) -> dict:
    return tool_call("submit_stage", **stage_args(item_id, applicable, criteria))


def summary_call(decision: str = "PIVOT",
                 conclusion: list[str] | None = None) -> dict:
    return tool_call(
        "submit_summary", decision=decision,
        conclusion=CONCLUSION if conclusion is None else conclusion,
    )


def finish() -> dict:
    return tool_call("finish")


def brief(before: str = "было так", now: str = "сейчас так", after: str = "стало иначе") -> dict:
    return tool_call("submit_brief", before=before, now=now, after=after)


def review(confirmed: bool = True, notes: str = "") -> dict:
    return tool_call("submit_review", confirmed=confirmed, notes=notes)


def malformed(text: str) -> dict:
    return {"content": text}


class MatcherAgentTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.repo = GitRepo(ensure_fixture())
        cls.sha = cls.repo.resolve("master")
        cls.tree = Tree.at(cls.repo, cls.sha)

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)

    def _run(self, *answers, plan=None, max_steps=DEFAULT_MAX_STEPS, on_verdict=None,
              on_summary=None, description=None):
        if plan is None:
            plan = make_plan(("intake", "Постановка задачи", BULLETS))
        ChatClient._create = scripted_responses(*answers)
        return run_agent(
            plan, CONTEXT, self.tree, SPEC, client=self.client, max_steps=max_steps,
            on_verdict=on_verdict, on_summary=on_summary, description=description,
        )

    def test_no_spec_returns_empty_with_note(self):
        plan = make_plan(("intake", "Постановка задачи", BULLETS))
        result = run_agent(plan, CONTEXT, self.tree, spec=None)
        self.assertFalse(result.usable)
        self.assertIn("не настроен", result.notes[0])

    def test_empty_plan_returns_empty_with_note(self):
        result = run_agent([], CONTEXT, self.tree, SPEC, client=self.client)
        self.assertFalse(result.usable)
        self.assertIn("План пуст", " ".join(result.notes))

    def test_full_session(self):
        plan = make_plan(
            ("intake", "Постановка задачи", BULLETS),
            ("billing", "Оплата подписки", BULLETS),
        )
        result = self._run(
            tool_call("read_file", path="backend/src/api/v1/router.py"),
            rate("intake"),
            rate("billing", applicable=False,
                 criteria=[criterion(applicable=False), criterion(applicable=False)]),
            review(),
            summary_call(),
            finish(),
            plan=plan,
        )
        self.assertEqual(result.source, "llm")
        self.assertEqual(len(result.items), 2)
        by_id = {v.item_id: v for v in result.verdicts}
        # Один буллит «Да» (100), второй «Нет» (0) -> 50%.
        self.assertEqual(by_id["intake"].percent(), 50)
        self.assertTrue(by_id["intake"].criteria[0].evidence[0].verified)
        # Неприменимый этап в картину не входит вовсе.
        self.assertIsNone(by_id["billing"].percent())
        # Решение считает код по порогу: 50% >= 50% -> GO.
        self.assertEqual(result.summary.decision, "GO")
        self.assertEqual(result.context["client_path_name"], CONTEXT["client_path_name"])

    def test_plan_keeps_bullet_texts_verbatim(self):
        plan = make_plan(("intake", "Постановка задачи",
                          ["Первый буллет как в образе", "Второй буллет"]))
        result = self._run(
            rate("intake", criteria=[criterion(status="done", evidence=ROUTER_EVIDENCE),
                                     criterion(status="partial", evidence=ROUTER_EVIDENCE)]),
            finish(),
            plan=plan,
        )
        [item] = result.plan
        self.assertEqual(item.criteria, ["Первый буллет как в образе", "Второй буллет"])

    def test_stage_with_wrong_number_of_ratings_is_rejected(self):
        result = self._run(
            rate("intake", criteria=[criterion()]),
            rate("intake"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(len(result.verdicts[0].criteria), 2)

    def test_unknown_status_for_applicable_criterion_is_rejected(self):
        result = self._run(
            rate("intake", criteria=[criterion(status="почти"), criterion(status="planned")]),
            rate("intake"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(result.verdicts[0].criteria[0].status, "done")

    def test_non_applicable_criterion_drops_status_and_evidence(self):
        result = self._run(
            rate("intake", criteria=[
                criterion(applicable=False, status="done", evidence=ROUTER_EVIDENCE),
                criterion(status="done", evidence=ROUTER_EVIDENCE),
            ]),
            finish(),
        )
        verdict = result.verdicts[0]
        self.assertEqual(verdict.criteria[0].status, "")
        self.assertEqual(verdict.criteria[0].evidence, [])
        # Неприменимый буллит исключён из знаменателя: остаётся один «Да».
        self.assertEqual(verdict.percent(), 100)

    def test_stage_without_applicable_criteria_has_no_percent(self):
        # Все буллиты неприменимы, но этап применим: (0+0)/2 = 0%.
        result = self._run(
            rate("intake", criteria=[criterion(applicable=False), criterion(applicable=False)]),
            finish(),
        )
        # Считать нечего: ни одного применимого буллита.
        self.assertIsNone(result.verdicts[0].percent())

    def test_fabricated_evidence_is_rejected_then_kept_unverified_and_noted(self):
        # Первый заход с выдуманной ссылкой отклоняется гейтом подтверждённости;
        # повтор принимается, но остаётся ungrounded и попадает в notes.
        bad = [criterion(status="done",
                         evidence=[{"path": "нет/такого.py", "line": 1, "basis": "x"}]),
               criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=bad),
            finish(),
        )
        verdict = result.verdicts[0]
        self.assertFalse(verdict.criteria[0].evidence[0].verified)
        self.assertFalse(verdict.criteria[0].is_grounded)
        self.assertIn("без единой подтверждённой ссылки", " ".join(result.notes))

    def test_done_without_evidence_is_rejected_then_fix_accepted(self):
        bad = [criterion(status="done", evidence=[]), criterion(status="planned")]
        fixed = [criterion(status="planned"), criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=fixed),
            finish(),
        )
        self.assertEqual([c.status for c in result.verdicts[0].criteria],
                         ["planned", "planned"])

    def test_evidence_without_line_is_not_verified(self):
        # Путь без строки подтверждает лишь существование файла — гейт такой
        # ссылкой не закрывается (verify_evidence возвращает verified=False).
        no_line = [{"path": "backend/src/api/v1/router.py", "basis": "start_task"}]
        bad = [criterion(status="done", evidence=no_line, proof="Код есть и работает."),
               criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=bad),
            finish(),
        )
        evidence = result.verdicts[0].criteria[0].evidence[0]
        self.assertFalse(evidence.verified)
        self.assertIn("номер строки", evidence.reason)

    def test_text_inventing_path_is_rejected_then_fix_accepted(self):
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                         proof="см. service/deep/worker.py"),
               criterion(status="planned")]
        good = [criterion(status="done", evidence=ROUTER_EVIDENCE, proof="Код есть и работает."),
                criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=good),
            finish(),
        )
        self.assertEqual(result.verdicts[0].criteria[0].proof, "Код есть и работает.")

    def test_text_guard_violation_is_struck_after_second_attempt(self):
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                         proof="см. service/deep/worker.py"),
               criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=bad),
            finish(),
        )
        self.assertEqual(result.verdicts[0].criteria[0].proof, matcher._COMMENT_STRUCK)

    def test_real_path_in_text_is_rejected_too(self):
        """Ссылок в отчёте нет вовсе — значит и в тексте им не место.

        Раньше отклонялся только выдуманный путь: настоящий проходил, потому
        что рядом печатался список ссылок. Списка больше нет, и «router.py:7»
        читателю отчёта открыть нечем.
        """
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                         proof="Подтверждается в backend/src/api/v1/router.py:7."),
               criterion(status="planned")]
        good = [criterion(status="done", evidence=ROUTER_EVIDENCE, proof="Код есть и работает."),
                criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=good),
            finish(),
        )
        self.assertEqual(result.verdicts[0].criteria[0].proof, "Код есть и работает.")

    def test_how_with_function_name_is_rejected(self):
        """«Как работает» читает человек без технического контекста."""
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                         how="Вызывается analyze_excel_model() из графа."),
               criterion(status="planned")]
        good = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                          how="Система открывает модель и считает результат."),
                criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=good),
            finish(),
        )
        self.assertEqual(result.verdicts[0].criteria[0].how,
                         "Система открывает модель и считает результат.")

    def test_go_with_blocked_bullet_is_rejected(self):
        blocked = criterion(status="blocked", evidence=ROUTER_EVIDENCE,
                            proof="Код есть и работает.")
        result = self._run(
            rate("intake", criteria=[blocked, criterion(status="planned")]),
            review(),
            summary_call(decision="GO"),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "PIVOT")
        self.assertNotIn("заменено кодом", " ".join(result.notes))

    def test_submit_brief_updates_context_before_after(self):
        # Агент формулирует AS IS / Now / To Be из описания первым шагом.
        result = self._run(
            brief(before="ручная пересылка задач", now="видна в системе без маршрутизации", after="автоматическая маршрутизация"),
            rate("intake"),
            finish(),
            description="Раньше пересылали вручную, теперь автоматически.",
        )
        self.assertEqual(result.context["before"], "ручная пересылка задач")
        self.assertEqual(result.context["now"], "видна в системе без маршрутизации")
        self.assertEqual(result.context["after"], "автоматическая маршрутизация")

    def test_submit_brief_without_description_is_ignored(self):
        # Без описания submit_brief не нужен, но если вызван — принимается.
        result = self._run(
            brief(),
            rate("intake"),
            finish(),
        )
        self.assertEqual(result.context["before"], "было так")
        self.assertEqual(result.context["now"], "сейчас так")
        self.assertTrue(result.usable)

    def test_submit_brief_empty_fields_rejected(self):
        result = self._run(
            brief(before="", now="", after=""),
            brief(before="было", now="сейчас", after="стало"),
            rate("intake"),
            finish(),
            description="Описание.",
        )
        self.assertEqual(result.context["before"], "было")
        self.assertEqual(result.context["now"], "сейчас")
        self.assertEqual(result.context["after"], "стало")

    def test_decision_ignores_what_the_model_asked_for(self):
        """Решение вычисляет код по порогу: что прислала модель — неважно."""
        result = self._run(
            rate("intake"),            # done + planned → готовность 50%
            review(),
            summary_call(decision="NO GO"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "GO")
        self.assertEqual(result.summary.reason, "50% ≥ 40%")

    def test_below_threshold_gives_pivot(self):
        result = self._run(
            rate("intake", criteria=[criterion(status="planned"), criterion(status="planned")]),
            review(),
            summary_call(decision="GO"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "PIVOT")
        self.assertEqual(result.summary.reason, "0% < 40%")

    def test_blocked_no_longer_overrides_the_threshold(self):
        """Сознательное изменение: на текущем шаге решает только порог.

        Блокирующий буллит остаётся виден в отчёте, но решение не меняет.
        """
        blocked = criterion(status="blocked", evidence=ROUTER_EVIDENCE,
                            proof="Код есть и работает.")
        result = self._run(
            rate("intake", criteria=[blocked, criterion(status="done",
                                                        evidence=ROUTER_EVIDENCE,
                                                        proof="Код есть и работает.")]),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "GO")

    def test_every_status_but_planned_needs_verified_evidence(self):
        """Гейт держит всю шкалу, а не три статуса из шести.

        `limited` весит 90%, `unused` — 70%. Пока их не было в списке
        подтверждаемых, вес приходил в расчёт без единой проверенной строки
        кода: статус без ссылки проезжал молча.
        """
        for status in ("done", "limited", "unused", "partial", "blocked"):
            with self.subTest(status=status):
                bare = [criterion(status=status, proof="Код есть."),
                        criterion(status="planned")]
                good = [criterion(status=status, evidence=ROUTER_EVIDENCE,
                                  proof="Код есть."),
                        criterion(status="planned")]
                result = self._run(
                    rate("intake", criteria=bare),
                    rate("intake", criteria=good),
                    finish(),
                )
                self.assertEqual(result.verdicts[0].criteria[0].status, status)
                self.assertTrue(result.verdicts[0].criteria[0].is_grounded)

    def test_planned_needs_no_evidence(self):
        result = self._run(
            rate("intake", criteria=[criterion(status="planned", proof="Не нашлось."),
                                     criterion(status="planned")]),
            finish(),
        )
        self.assertEqual([c.status for c in result.verdicts[0].criteria],
                         ["planned", "planned"])

    def test_summary_risk_with_invented_path_is_rejected(self):
        bad_conclusion = ["Интеграции нет в service/deep/worker.py", CONCLUSION[1], CONCLUSION[2]]
        result = self._run(
            rate("intake"),
            review(),
            summary_call(conclusion=bad_conclusion),
            summary_call(),
            finish(),
        )
        self.assertEqual(result.summary.conclusion, CONCLUSION)

    def test_summary_conclusion_guard_violation_is_struck_after_second_attempt(self):
        bad_conclusion = ["Интеграции нет в service/deep/worker.py", CONCLUSION[1], CONCLUSION[2]]
        result = self._run(
            rate("intake"),
            review(),
            summary_call(conclusion=bad_conclusion),
            summary_call(conclusion=bad_conclusion),
            finish(),
        )
        self.assertEqual(result.summary.conclusion[0], matcher._ITEM_STRUCK)
        self.assertEqual(result.summary.conclusion[1], CONCLUSION[1])

    def test_planned_criterion_needs_no_evidence(self):
        result = self._run(
            rate("intake", criteria=[criterion(status="planned"), criterion(status="planned")]),
            finish(),
        )
        self.assertNotIn("без единой подтверждённой ссылки", " ".join(result.notes))

    def test_unknown_item_id_is_rejected(self):
        result = self._run(
            rate("no-such-id"),
            rate("intake"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)

    def test_unrated_stage_is_named_in_notes(self):
        plan = make_plan(
            ("intake", "Постановка задачи", BULLETS),
            ("billing", "Оплата подписки", BULLETS),
        )
        result = self._run(
            rate("intake"),
            finish(),
            plan=plan,
        )
        self.assertIn("Оплата подписки", " ".join(result.notes))

    def test_garbage_decision_from_model_does_not_break_anything(self):
        """Поле decision принимается для совместимости и просто игнорируется."""
        result = self._run(
            rate("intake"),
            review(),
            summary_call(decision="МОЖЕТ БЫТЬ"),
            finish(),
        )
        self.assertIn(result.summary.decision, ("GO", "PIVOT"))

    def test_stage_titles_are_kept_verbatim(self):
        plan = make_plan(("api", "Интеграция с бюро", BULLETS))
        result = self._run(
            rate("api"),
            finish(),
            plan=plan,
        )
        self.assertEqual(result.plan[0].title, "Интеграция с бюро")

    def test_empty_plan_is_rejected(self):
        result = self._run(
            tool_call("submit_summary", **{"decision": "GO",
                                           "conclusion": ["a", "b", "c"]}),
            finish(),
            plan=[],
        )
        self.assertFalse(result.usable)

    def test_callbacks_fire_on_accepted_calls(self):
        verdicts: list[tuple[str, int | None]] = []
        summaries: list[str] = []
        self._run(
            rate("intake"),
            review(),
            summary_call(),
            finish(),
            on_verdict=lambda item, v: verdicts.append((item.id, v.percent())),
            on_summary=lambda s: summaries.append(s.decision),
        )
        self.assertEqual(verdicts, [("intake", 50)])
        self.assertEqual(summaries, ["GO"])

    # --- Контр-проверка (submit_review) ---

    def test_submit_summary_rejected_without_review(self):
        # Есть done — submit_summary не принимается без submit_review.
        result = self._run(
            rate("intake"),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertIsNone(result.summary)
        self.assertIn("Контр-проверка не завершена", " ".join(result.notes))

    def test_review_unlocks_summary(self):
        result = self._run(
            rate("intake"),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "GO")

    def test_review_not_confirmed_does_not_unlock(self):
        result = self._run(
            rate("intake"),
            review(confirmed=False),
            review(confirmed=True),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "GO")

    def test_review_required_even_when_all_planned(self):
        # Все planned — review всё равно требуется: агент мог пропустить код.
        result = self._run(
            rate("intake", criteria=[criterion(status="planned"), criterion(status="planned")]),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "PIVOT")
        self.assertNotIn("Контр-проверка не завершена", " ".join(result.notes))

    def test_review_required_even_when_only_blocked(self):
        # blocked без done/partial — review всё равно требуется.
        blocked = criterion(status="blocked", evidence=ROUTER_EVIDENCE,
                            proof="Код есть и работает.")
        result = self._run(
            rate("intake", criteria=[blocked, criterion(status="planned")]),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "PIVOT")
        self.assertNotIn("Контр-проверка не завершена", " ".join(result.notes))

    def test_stage_revision_during_review_replaces_verdict(self):
        # Агент понизил done→planned при контр-проверке через повторный submit_stage.
        done = [criterion(status="done", evidence=ROUTER_EVIDENCE), criterion(status="planned")]
        fixed = [criterion(status="planned"), criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=done),
            rate("intake", criteria=fixed),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual([c.status for c in result.verdicts[0].criteria],
                         ["planned", "planned"])

    def test_stops_after_repeated_identical_tool_call(self):
        result = self._run(
            tool_call("search", pattern="x"),
            tool_call("search", pattern="x"),
            tool_call("search", pattern="x"),
            finish(),
        )
        self.assertFalse(result.usable)
        self.assertIn("одинаковых вызова", " ".join(result.notes))

    def test_stops_at_step_budget(self):
        result = self._run(
            tool_call("list_files"),
            tool_call("search", pattern="a"),
            max_steps=2,
        )
        self.assertFalse(result.usable)
        self.assertIn("бюджет шагов", " ".join(result.notes))

    def test_budget_exhausted_keeps_accepted_verdicts(self):
        result = self._run(
            rate("intake"),
            tool_call("search", pattern="a"),
            tool_call("list_files"),
            max_steps=3,
        )
        self.assertTrue(result.usable)
        self.assertIn("бюджет шагов", " ".join(result.notes))

    def test_tolerates_a_few_malformed_responses(self):
        result = self._run(
            malformed("извините"),
            malformed("и снова"),
            rate("intake"),
            finish(),
        )
        self.assertTrue(result.usable)

    def test_gives_up_after_too_many_malformed_responses(self):
        result = self._run(malformed("x"), malformed("y"), malformed("z"), malformed("w"))
        self.assertFalse(result.usable)
        self.assertIn("не вызвал инструмент", " ".join(result.notes))

    def test_invalid_tool_arguments_json_does_not_crash(self):
        result = self._run(
            rate("intake"),
            {"content": None, "tool_calls": [{
                "id": "bad", "type": "function",
                "function": {"name": "read_file", "arguments": "{not valid json"},
            }]},
            finish(),
        )
        self.assertTrue(result.usable)

    def test_stage_and_finish_in_the_same_turn(self):
        result = self._run(
            parallel_tool_calls(("submit_stage", stage_args("intake")), ("finish", {})),
        )
        self.assertTrue(result.usable)

    def test_stage_without_bullets_accepted(self):
        # Этап без буллитов — criteria пустой список.
        plan = [PlanItem(id="empty", title="Этап без пунктов", criteria=[], origin="user")]
        result = self._run(
            tool_call("submit_stage", item_id="empty", applicable=True, criteria=[]),
            finish(),
            plan=plan,
        )
        self.assertTrue(result.usable)
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(len(result.verdicts[0].criteria), 0)


class SystemPromptTest(unittest.TestCase):
    def test_all_prompt_parts_are_loaded(self):
        prompt, missing = load_system_prompt()
        self.assertEqual(missing, [])
        self.assertGreater(len(prompt), 1000)
        self.assertIn("submit_stage", prompt)
        self.assertIn("submit_review", prompt)

    def test_missing_part_is_reported_not_swallowed(self):
        with tempfile.TemporaryDirectory() as empty:
            with mock.patch.object(matcher, "_PROMPT_DIR", Path(empty)):
                prompt, missing = load_system_prompt()
        self.assertEqual(missing, list(matcher._PROMPT_PARTS))
        self.assertTrue(prompt)


class StagePercentTest(unittest.TestCase):
    """Готовность: (Да×100 + Почти×70 + Почти нет×30) / применимые буллиты."""

    def _verdict(self, *pairs):
        return ItemVerdict(
            item_id="a", applicable=True,
            criteria=[CriterionVerdict(applicable=a, status=s) for a, s in pairs],
        )

    def test_weights(self):
        self.assertEqual(self._verdict((True, "done"), (True, "done")).percent(), 100)
        self.assertEqual(self._verdict((True, "done"), (True, "planned")).percent(), 50)
        self.assertEqual(self._verdict((True, "limited"), (True, "limited")).percent(), 90)
        self.assertEqual(self._verdict((True, "unused"), (True, "unused")).percent(), 70)
        self.assertEqual(self._verdict((True, "partial"), (True, "partial")).percent(), 50)
        self.assertEqual(self._verdict((True, "blocked"), (True, "done")).percent(), 50)
        self.assertEqual(self._verdict((True, "planned"), (True, "blocked")).percent(), 0)

    def test_scale_is_monotonic(self):
        """Порядок ступеней: частично < не используется < с ограничениями < работает."""
        order = ["partial", "unused", "limited", "done"]
        percents = [self._verdict((True, s)).percent() for s in order]
        self.assertEqual(percents, sorted(percents))
        self.assertEqual(percents, [50, 70, 90, 100])

    def test_non_applicable_criterion_is_excluded_from_denominator(self):
        # Неприменимый буллит — не про код (декларация эффекта, потребители).
        # Он не должен тянуть готовность вниз: (100)/1 = 100%.
        self.assertEqual(self._verdict((True, "done"), (False, "")).percent(), 100)

    def test_all_criteria_non_applicable_gives_none(self):
        self.assertIsNone(self._verdict((False, ""), (False, "")).percent())

    def test_stage_without_criteria_returns_none(self):
        # Этап без буллитов: None (не 0, не серый — просто нечего считать).
        self.assertIsNone(self._verdict().percent())

    def test_non_applicable_stage_is_grey(self):
        verdict = self._verdict((True, "done"))
        verdict.applicable = False
        self.assertIsNone(verdict.percent())


class OverallProgressTest(unittest.TestCase):
    """Общий прогресс: сумма весов всех буллитов / их количество × 100."""

    def test_non_applicable_stage_bullets_are_excluded(self):
        from pko.progress.schema import ProgressModel
        # Этап 1 (применимый): done + planned → 100 + 0
        # Этап 2 (неприменимый): оба буллита вне знаменателя
        # Общий: (100 + 0) / 2 = 50%
        model = ProgressModel(
            verdicts=[
                ItemVerdict(item_id="a", applicable=True, criteria=[
                    CriterionVerdict(applicable=True, status="done"),
                    CriterionVerdict(applicable=True, status="planned"),
                ]),
                ItemVerdict(item_id="b", applicable=False, criteria=[
                    CriterionVerdict(applicable=False, status=""),
                    CriterionVerdict(applicable=False, status=""),
                ]),
            ],
        )
        self.assertEqual(model.overall_progress(), 50)

    def test_all_done_gives_100(self):
        from pko.progress.schema import ProgressModel
        model = ProgressModel(
            verdicts=[
                ItemVerdict(item_id="a", applicable=True, criteria=[
                    CriterionVerdict(applicable=True, status="done"),
                    CriterionVerdict(applicable=True, status="done"),
                ]),
            ],
        )
        self.assertEqual(model.overall_progress(), 100)

    def test_no_verdicts_gives_0(self):
        from pko.progress.schema import ProgressModel
        model = ProgressModel(verdicts=[])
        self.assertEqual(model.overall_progress(), 0)


class UnclaimedPathsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        repo = GitRepo(ensure_fixture())
        cls.tree = Tree.at(repo, repo.resolve("master"))
        from pko.extractors.runner import extract_all

        cls.extraction = extract_all(cls.tree)

    def test_paths_without_verified_evidence_are_reported(self):
        verdict = ItemVerdict(item_id="a", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="done", evidence=[
                EvidenceRef(path="backend/src/api/v1/router.py", line=7,
                            basis="start_task", verified=True, reason="ok"),
            ]),
        ])
        groups = find_unclaimed_paths(self.extraction, [verdict])
        claimed = {p for g in groups for p in g.example_paths}
        self.assertNotIn("backend/src/api/v1/router.py", claimed)

    def test_no_verdicts_means_everything_is_unclaimed(self):
        groups = find_unclaimed_paths(self.extraction, [])
        self.assertGreater(sum(g.file_count for g in groups), 0)


if __name__ == "__main__":
    unittest.main()

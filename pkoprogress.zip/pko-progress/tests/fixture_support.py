"""Подготовка тестового репозитория.

Фикстура — настоящий git-репозиторий и потому не хранится в версионном контроле
(`.gitignore`). Раньше её нужно было создать отдельной командой, и на чистом
клоне набор тестов молча пропускался: гонять его в CI было нечем. Теперь любой
тест, которому нужна фикстура, создаёт её сам.
"""

from __future__ import annotations

import subprocess
import unittest
from pathlib import Path
from types import SimpleNamespace

TESTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TESTS_DIR.parent
FIXTURE_REPO = TESTS_DIR / "fixtures" / "mini_repo"
FIXTURE_SCRIPT = TESTS_DIR / "make_fixture.sh"


def ensure_fixture() -> Path:
    """Вернуть путь к фикстуре, создав её при необходимости.

    Пропуск допустим ровно в одном случае — скрипта нет в дереве. Если скрипт есть,
    но не отработал, прогон обязан покраснеть: иначе `unittest` завершится с нулём,
    а 27 сквозных тестов молча не выполнятся — та самая беззвучная потеря проверки,
    ради устранения которой фикстура и стала создаваться сама.
    """
    return _ensure(FIXTURE_REPO, FIXTURE_SCRIPT)


def _ensure(repo: Path, script: Path) -> Path:
    if (repo / ".git").exists():
        return repo
    if not script.exists():
        raise unittest.SkipTest(f"нет скрипта фикстуры: {script}")
    # Git Bash на Windows не принимает ни `D:\a\b.sh` (съедает слеши), ни
    # `D:/a/b.sh`. Запускаем из каталога скрипта по голому имени — тогда
    # трансляция пути не нужна вовсе.
    try:
        proc = subprocess.run(
            ["bash", script.name],
            capture_output=True,
            text=True,
            errors="replace",
            cwd=str(script.parent),
        )
    except OSError as exc:  # нет bash — проверить нечем, это не повод зеленеть
        raise RuntimeError(f"не удалось запустить {script}: {exc}") from exc

    if proc.returncode != 0 or not (repo / ".git").exists():
        raise RuntimeError(
            f"не удалось создать фикстуру ({script}, код {proc.returncode}): "
            + (proc.stderr or proc.stdout).strip()[:500]
        )
    return repo


def make_openai_response(message: dict | str) -> SimpleNamespace:
    """Собрать ответ, имитирующий openai SDK, из dict-сообщения или строки.

    Тесты раньше мокали `ChatClient._request` и возвращали dict
    `{"choices": [{"message": ...}]}`. Теперь клиент на openai SDK и мокается
    через `ChatClient._create` — нужен объект с атрибутами
    `.choices[0].message.content`/`.tool_calls`/`.usage`, как отдаёт SDK.

    Строка (legacy) оборачивается в `{"content": <str>}` — для тестов, где
    ответ был голым текстом (vision-прогон и т.п.)."""
    if isinstance(message, str):
        message = {"content": message}
    raw_tc = message.get("tool_calls")
    tool_calls = None
    if isinstance(raw_tc, list) and raw_tc:
        tool_calls = [
            SimpleNamespace(
                id=str(tc.get("id", "")),
                type="function",
                function=SimpleNamespace(
                    name=str((tc.get("function") or {}).get("name", "")),
                    arguments=str((tc.get("function") or {}).get("arguments", "")),
                ),
            )
            for tc in raw_tc
        ]
    msg = SimpleNamespace(
        content=message.get("content"),
        tool_calls=tool_calls,
        reasoning_content=message.get("reasoning_content") or "",
    )
    finish_reason = "tool_calls" if tool_calls else "stop"
    return SimpleNamespace(
        choices=[SimpleNamespace(message=msg, finish_reason=finish_reason)],
        usage=SimpleNamespace(prompt_tokens=10, completion_tokens=5, total_tokens=15),
    )


def scripted_responses(*answers):
    """Вернуть функцию-мок для `ChatClient._create`.

    Каждый answer — dict-сообщение тестового хода (`{"content": ...,
    "tool_calls": [...]}`) или строка (голый текст). По исчерпании очереди
    отдаёт `finish`-сообщение (пустой content, без tool_calls) — чтобы тест
    не зависал, если агент сделал больше шагов, чем заготовлено."""
    queue = list(answers)

    def _create(self, payload, extra_body=None):
        if queue:
            message = queue.pop(0)
        else:
            message = {"content": None}
        return make_openai_response(message)

    return _create


"""Tests for the current progress-report contract.

Journey stages and business criteria come from ``PlanItem``. ``ItemVerdict``
only assesses applicability and implementation status.
"""

import json
import unittest
from unittest import mock

from pko.errors import PkoError
from pko.progress.schema import CriterionVerdict, ItemVerdict, PlanItem, ProgressModel
from pko.render.progress_report import percent_color, render_progress_report


_FAKE_BUNDLE = ("<style>.fake{}</style>", '<script type="module">/*fake bundle*/</script>')


def _criterion(status: str = "done", *, applicable: bool = True) -> CriterionVerdict:
    return CriterionVerdict(applicable=applicable, status=status)


def _model(verdicts: list[ItemVerdict]) -> ProgressModel:
    items = {
        verdict.item_id: PlanItem(
            id=verdict.item_id,
            title=f"Stage {verdict.item_id}",
            description=f"Description {verdict.item_id}",
            criteria=[f"Business outcome {verdict.item_id}"],
            origin="user",
        )
        for verdict in verdicts
    }
    model = ProgressModel(
        meta={"project_name": "Demo project", "client_path_name": "Demo path"},
        items=items,
        verdicts=verdicts,
        readiness=0,
    )
    model.readiness = model.overall_progress()
    return model


class PercentColorTest(unittest.TestCase):
    def test_thresholds_match_dashboard_palette(self):
        self.assertEqual(percent_color(None), "purple")
        self.assertEqual(percent_color(0), "red")
        self.assertEqual(percent_color(39), "red")
        self.assertEqual(percent_color(40), "amber")
        self.assertEqual(percent_color(79), "amber")
        self.assertEqual(percent_color(80), "green")
        self.assertEqual(percent_color(100), "green")


class JourneySectionTest(unittest.TestCase):
    def setUp(self):
        patcher = mock.patch(
            "pko.render.progress_report._load_journey_bundle",
            return_value=_FAKE_BUNDLE,
        )
        self.addCleanup(patcher.stop)
        patcher.start()

    def test_empty_verdicts_produce_no_section(self):
        html = render_progress_report(ProgressModel())
        self.assertNotIn('<div id="journey-root">', html)

    def test_mount_point_and_bundle_are_embedded(self):
        verdicts = [
            ItemVerdict(item_id="a", applicable=True, criteria=[_criterion()]),
        ]
        html = render_progress_report(_model(verdicts))
        self.assertIn('<div id="journey-root">', html)
        self.assertIn(_FAKE_BUNDLE[0], html)
        self.assertIn(_FAKE_BUNDLE[1], html)

    def test_items_json_uses_plan_text_and_criterion_statuses(self):
        verdicts = [
            ItemVerdict(item_id="done", applicable=True, criteria=[_criterion("done")]),
            ItemVerdict(item_id="partial", applicable=True, criteria=[_criterion("partial")]),
            ItemVerdict(item_id="planned", applicable=True, criteria=[_criterion("planned")]),
            ItemVerdict(item_id="na", applicable=False, criteria=[_criterion(applicable=False)]),
        ]

        html = render_progress_report(_model(verdicts))
        start = html.index("window.__JOURNEY_ITEMS__ = ") + len("window.__JOURNEY_ITEMS__ = ")
        end = html.index(";</script>", start)
        items = json.loads(html[start:end])
        by_title = {item["title"]: item for item in items}

        self.assertEqual(by_title["Stage done"]["pct"], 100)
        self.assertEqual(by_title["Stage done"]["color"], "green")
        # «Не работает, реализовано частично» весит 50.
        self.assertEqual(by_title["Stage partial"]["pct"], 50)
        self.assertEqual(by_title["Stage partial"]["color"], "amber")
        self.assertEqual(by_title["Stage planned"]["pct"], 0)
        self.assertEqual(by_title["Stage planned"]["color"], "red")
        self.assertEqual(by_title["Stage na"]["pct"], 0)
        self.assertEqual(by_title["Stage na"]["color"], "purple")
        self.assertEqual(by_title["Stage partial"]["explanation"], "Business outcome partial")


class JourneyBundleMissingTest(unittest.TestCase):
    def test_missing_bundle_raises_a_clean_pko_error(self):
        verdicts = [
            ItemVerdict(item_id="a", applicable=True, criteria=[_criterion()]),
        ]
        with mock.patch("pko.render.progress_report._JOURNEY_BUNDLE_PATH") as fake_path:
            fake_path.exists.return_value = False
            with self.assertRaises(PkoError) as ctx:
                render_progress_report(_model(verdicts))
            self.assertIn("npm run build", ctx.exception.hint)


if __name__ == "__main__":
    unittest.main()

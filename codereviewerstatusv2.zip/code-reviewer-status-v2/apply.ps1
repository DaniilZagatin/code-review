# Установка правок копированием. Запускать из корня репозитория code-reviewer:
#   powershell -ExecutionPolicy Bypass -File \путь\к\пакету\apply.ps1
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path "backend\pko\progress")) {
    Write-Error "Запускать из корня репозитория code-reviewer (нет backend\pko\progress)"
}

$stamp  = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = ".backup-status-scale-$stamp"
New-Item -ItemType Directory -Force -Path $backup | Out-Null

Push-Location "$here\files"
$files = Get-ChildItem -Recurse -File | ForEach-Object { Resolve-Path -Relative $_.FullName }
Pop-Location

foreach ($rel in $files) {
    $target = Join-Path (Get-Location) $rel
    if (Test-Path $target) {
        $dest = Join-Path $backup $rel
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest) | Out-Null
        Copy-Item $target $dest -Force
    }
}
Write-Host "Резервная копия изменяемых файлов: $backup"

Copy-Item -Recurse -Force "$here\files\*" (Get-Location)
Write-Host "Файлы установлены. Проверка: make test  (ожидается 238 тестов, OK)"

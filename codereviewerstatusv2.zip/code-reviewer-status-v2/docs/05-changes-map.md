# Карта изменений по файлам

Всё, что менялось, и зачем именно там. Патчи — в `patches/`, готовые файлы —
в `files/` (структура повторяет репозиторий).

## Ядро методологии

**`backend/pko/progress/schema.py`** — единственное место, где живёт шкала.

- `CRITERION_STATUSES` — пять ключей в порядке веса;
- `CRITERION_WEIGHT` — 1.0 / 0.9 / 0.7 / 0.5 / 0;
- `CRITERION_LABELS` — подписи для отчёта;
- `CRITERION_STATUS_LINE` — первая строка комментария по статусу;
- `CRITERION_ALIASES` + `normalize_status()` — приведение старых ключей
  (`blocked` → `planned` и т.д.);
- `render_comment()` — сборка четырёх блоков в текст;
- `CriterionVerdict` — поля `how` / `where` / `why`, метод `comment_parts()`,
  поле `applicable` удалено;
- `ItemVerdict` — `applicable` удалён, `percent()` считает всегда.

**`backend/pko/progress/agent_system.md`** — системный промпт агента. Заменён
раздел статусов (новая шкала, алгоритм из четырёх вопросов, границы,
признаки `not_wired`), добавлен раздел «Комментарий к буллиту», из вердикта
убраны правила про `blocked`, из шага 1 — про применимость.

**`backend/pko/progress/matcher.py`** — инструменты агента и гейты кода.

- схема `submit_stage`: три поля комментария вместо `comment`, `status`
  обязателен, `applicable` убран из этапа и из буллита;
- `_GROUNDED_STATUSES` — подтверждения требуют все статусы, кроме `planned`;
- `_GROUNDED_PROOF_STATUSES` — движение для `GO`: `done` / `works_limited` /
  `partial` (без `not_wired`, с объяснением почему);
- `_parse_comment_parts()` — разбор блоков + подхват старого `comment`;
- `_comment_structure_problems()` — гейты: непустые блоки, `where` цитирует
  проверенную evidence, `why` называет альтернативу;
- `_REVIEW_HINTS` — подсказки контр-проверки по каждому промежуточному
  статусу;
- гейт `GO` при `blocked` удалён вместе со статусом.

## Контракт и рендер

**`backend/pko/web/analyses.py`** — в дашборд уходят `status` (всегда) и
`comment_parts`; `applicable` больше не публикуется.

**`backend/pko/progress/pipeline.py`** — событие `claim_verified` без
`applicable`.

**`backend/pko/render/dashboard_template.html`** — скачиваемый HTML:
словарь статусов с весами, алиасы старых ключей, легенда на пять позиций,
рендер комментария четырьмя размеченными блоками, зелёная палитра
промежуточных статусов (токен `--lime`, бирюза для `not_wired`), удалены
стили `na` и `blocked`.

**`frontend-web/src/components/dashboard/Dashboard.tsx`**,
**`dashboard.css`**, **`lib/types.ts`** — то же самое на React: тот же
словарь, те же веса, тот же компонент комментария (`CriterionComment`), те же
цвета. Расхождение веб-экрана и скачиваемого HTML здесь считается багом, а не
вариантом дизайна — поэтому правки зеркальные.

## Тесты

**`tests/test_progress_statuses.py`** — новый файл, 21 тест: состав шкалы,
веса, нормализация старых ключей, обязательность evidence, четыре гейта
структуры комментария, приём промежуточных статусов end-to-end, разведение
веса и вердикта (`not_wired` даёт 90%, но не даёт `GO`), подсказки
контр-проверки.

**`tests/agent_script.py`** — сценарий агента для сквозных тестов: блоки
комментария по каждому статусу, согласованные с evidence.

**`tests/test_progress_matcher.py`** — хелпер `criterion()` заполняет блоки;
сценарии с `blocked` заменены на `not_wired`; тесты «неприменимого» буллита
заменены на «статус обязателен»; арифметика процента под новые веса.

**`tests/test_web_analyses.py`** — проверяется `comment_parts` и то, что
первая строка выведена кодом; снято требование «в дашборде нет путей» —
теперь пути публикуются в блоке `where`, а служебные поля evidence по-прежнему
нет.

**`tests/test_render_dashboard_html.py`** — шаблон знает все пять статусов, его
веса сверяются напрямую с `CRITERION_WEIGHT`, блоки комментария доходят до
страницы.

**`tests/test_render_progress_report.py`**, **`tests/test_progress_pipeline.py`**
— убран `applicable`, CLI-отчёт проверяется на новом весе `not_wired`.

## Что НЕ трогалось

- `frontend-app/` (React-бандл CLI-отчёта) — работает на плоском контракте
  `title/status/label/color/pct` и новых полей не видит;
- `dashboard_templateUPD.html` в корне репозитория — ручной вариант шаблона,
  в код не подключён. Если он используется для показов, перенесите в него
  правки из `patches/backend_pko_render_dashboard_template.html.patch`
  вручную;
- экстракторы, git-слой, LLM-клиент — методология статусов их не касается.

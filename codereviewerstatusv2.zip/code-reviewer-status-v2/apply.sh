#!/usr/bin/env bash
# Установка правок копированием. Запускать из корня репозитория code-reviewer:
#   bash /путь/к/пакету/apply.sh
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -d "backend/pko/progress" ]; then
  echo "Запускать из корня репозитория code-reviewer (нет backend/pko/progress)" >&2
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP=".backup-status-scale-$STAMP"
mkdir -p "$BACKUP"
( cd "$HERE/files" && find . -type f ) | while read -r rel; do
  if [ -f "$rel" ]; then
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp "$rel" "$BACKUP/$rel"
  fi
done
echo "Резервная копия изменяемых файлов: $BACKUP"

cp -r "$HERE/files/." .
echo "Файлы установлены. Проверка: make test  (ожидается 238 тестов, OK)"

"""Шкала степени реализации (пять статусов) и структура комментария буллита.

Проверяется то, что делает КОД, а не модель: веса статусов в проценте,
обязательность подтверждения для статусов, утверждающих наличие кода,
обязательность трёх блоков комментария и их связность с evidence.

Отдельно проверяется расхождение веса и вердикта: `not_wired` («код есть, но
не подключён») весит почти как готовый пункт — работы осталось мало, — но
подтверждённым движением не считается: пользователь не получает ничего.
Поэтому проект, где всё написано и ничего не подключено, набирает высокий
процент и получает `PIVOT`, а не `GO`.
"""

import unittest

from fixture_support import ensure_fixture, scripted_responses
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress.matcher import run_agent
from pko.progress.schema import (
    CRITERION_STATUSES,
    CRITERION_WEIGHT,
    CriterionVerdict,
    ItemVerdict,
    calculate_progress,
    normalize_status,
    render_comment,
)

from test_progress_matcher import (  # noqa: E402  — общие заготовки сценария
    CONTEXT,
    ROUTER_EVIDENCE,
    criterion,
    finish,
    make_plan,
    rate,
    review,
    summary_call,
)

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")
BULLETS = ["Определены источники обращений", "Подтверждена скорость обработки"]


class StatusScaleTest(unittest.TestCase):
    """Шкала и арифметика: пять делений, веса заданы в одном месте."""

    def test_scale_has_five_gradations(self):
        self.assertEqual(
            CRITERION_STATUSES,
            ("done", "not_wired", "works_limited", "partial", "planned"),
        )

    def test_scale_has_no_blocked_and_no_not_applicable(self):
        self.assertNotIn("blocked", CRITERION_STATUSES)
        self.assertNotIn("na", CRITERION_STATUSES)
        # Старые отчёты не падают: «блокер» читается как «не реализовано».
        self.assertEqual(normalize_status("blocked"), "planned")

    def test_weights(self):
        self.assertEqual(CRITERION_WEIGHT, {
            "done": 1.0, "not_wired": 0.9, "works_limited": 0.7,
            "partial": 0.5, "planned": 0.0,
        })

    def test_weights_follow_the_order_of_the_scale(self):
        weights = [CRITERION_WEIGHT[s] for s in CRITERION_STATUSES]
        self.assertEqual(weights, sorted(weights, reverse=True))

    def test_intermediate_statuses_move_the_percent(self):
        # (0.9 + 0.5) / 2 = 70%.
        criteria = [CriterionVerdict(status="not_wired"),
                    CriterionVerdict(status="partial")]
        self.assertEqual(calculate_progress(criteria), 70)

    def test_unwired_code_is_almost_a_finished_bullet(self):
        # Написано всё, осталось подключить — это 90%, а не 0.
        self.assertEqual(calculate_progress([CriterionVerdict(status="not_wired")]), 90)
        self.assertEqual(calculate_progress([CriterionVerdict(status="planned")]), 0)

    def test_old_status_keys_are_normalized_not_dropped(self):
        self.assertEqual(normalize_status("amber"), "partial")
        self.assertEqual(normalize_status("completed"), "done")
        self.assertEqual(normalize_status("not_connected"), "not_wired")
        self.assertEqual(normalize_status("выдумка"), "")

    def test_grounding_is_required_for_every_status_but_planned(self):
        for status in CRITERION_STATUSES:
            verdict = CriterionVerdict(status=status)
            if status == "planned":
                self.assertTrue(verdict.is_grounded, status)
            else:
                self.assertFalse(verdict.is_grounded, status)


class CommentStructureTest(unittest.TestCase):
    """Комментарий — четыре блока, первый пишет код по статусу."""

    def test_status_line_comes_from_the_status_not_from_the_model(self):
        text = render_comment("not_wired", "как", "где", "почему")
        self.assertTrue(text.startswith("Статус: код рабочий, но не подключён"))
        self.assertIn("Как работает: как", text)
        self.assertIn("Где реализовано: где", text)
        self.assertIn("Почему такой статус: почему", text)

    def test_parts_are_published_separately(self):
        verdict = CriterionVerdict(status="done", how="как",
                                   where="router.py:7", why="не works_limited")
        parts = verdict.comment_parts()
        self.assertEqual(parts["how"], "как")
        self.assertEqual(parts["where"], "router.py:7")
        self.assertEqual(parts["status_line"], "код рабочий")

    def test_no_blocks_means_no_parts(self):
        self.assertIsNone(CriterionVerdict(status="done").comment_parts())


class GateTest(unittest.TestCase):
    """Смысловые гейты кода на оценке этапа."""

    @classmethod
    def setUpClass(cls):
        cls.repo = GitRepo(ensure_fixture())
        cls.tree = Tree.at(cls.repo, cls.repo.resolve("master"))

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)

    def _run(self, *answers, plan=None):
        if plan is None:
            plan = make_plan(("intake", "Постановка задачи", BULLETS))
        ChatClient._create = scripted_responses(*answers)
        return run_agent(plan, CONTEXT, self.tree, SPEC, client=self.client)

    def test_not_wired_without_evidence_is_rejected(self):
        # «Код есть, но не подключён» без ссылки на этот код неотличим от
        # «кода нет» — код такую оценку не принимает.
        bad = [criterion(status="not_wired", evidence=[]), criterion(status="planned")]
        fixed = [criterion(status="not_wired", evidence=ROUTER_EVIDENCE),
                 criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=fixed),
            finish(),
        )
        verdict = result.verdicts[0]
        self.assertEqual(verdict.criteria[0].status, "not_wired")
        self.assertTrue(verdict.criteria[0].evidence[0].verified)

    def test_empty_comment_block_is_rejected(self):
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE, how_it_works=""),
               criterion(status="planned")]
        good = [criterion(status="done", evidence=ROUTER_EVIDENCE),
                criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=good),
            finish(),
        )
        self.assertTrue(result.verdicts[0].criteria[0].how)

    def test_where_must_cite_a_verified_file(self):
        # Ссылки в тексте не должны жить отдельно от доказательств: блок
        # «где реализовано» обязан назвать тот же файл, что и evidence.
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                         where="где-то в сервисе"),
               criterion(status="planned")]
        good = [criterion(status="done", evidence=ROUTER_EVIDENCE),
                criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=good),
            finish(),
        )
        self.assertIn("router.py", result.verdicts[0].criteria[0].where)

    def test_why_must_name_the_rejected_status(self):
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                         why_this_status="потому что так решил"),
               criterion(status="planned")]
        good = [criterion(status="done", evidence=ROUTER_EVIDENCE),
                criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=good),
            finish(),
        )
        self.assertIn("works_limited", result.verdicts[0].criteria[0].why)

    def test_intermediate_statuses_are_accepted_end_to_end(self):
        result = self._run(
            rate("intake", criteria=[
                criterion(status="works_limited", evidence=ROUTER_EVIDENCE),
                criterion(status="not_wired", evidence=ROUTER_EVIDENCE),
            ]),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        verdict = result.verdicts[0]
        self.assertEqual([c.status for c in verdict.criteria],
                         ["works_limited", "not_wired"])
        # (0.7 + 0.9) / 2 = 80%.
        self.assertEqual(verdict.percent(), 80)

    def test_go_is_not_published_when_nothing_is_wired(self):
        # Всё написано, но пользователь не доходит ни до чего: процент высокий
        # (90%), а движения, которое можно наблюдать, нет — GO не публикуется.
        result = self._run(
            rate("intake", criteria=[
                criterion(status="not_wired", evidence=ROUTER_EVIDENCE),
                criterion(status="not_wired", evidence=ROUTER_EVIDENCE),
            ]),
            review(),
            summary_call(decision="GO"),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.verdicts[0].percent(), 90)
        self.assertEqual(result.summary.decision, "PIVOT")

    def test_go_is_published_when_something_reaches_the_user(self):
        result = self._run(
            rate("intake", criteria=[
                criterion(status="works_limited", evidence=ROUTER_EVIDENCE),
                criterion(status="not_wired", evidence=ROUTER_EVIDENCE),
            ]),
            review(),
            summary_call(decision="GO"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "GO")


class ReviewBriefTest(unittest.TestCase):
    """Контр-проверка спрашивает про каждый промежуточный статус."""

    def test_hints_cover_every_intermediate_status(self):
        from pko.progress.matcher import _build_review_brief

        plan = make_plan(("intake", "Постановка задачи", ["a", "b", "c", "d"]))
        verdict = ItemVerdict(item_id="intake", criteria=[
            CriterionVerdict(status="planned"),
            CriterionVerdict(status="not_wired"),
            CriterionVerdict(status="partial"),
            CriterionVerdict(status="works_limited"),
        ])
        brief = _build_review_brief(plan, {"intake": verdict}, None)
        self.assertIn("не пропущена ли реализация", brief)
        self.assertIn("точно ли код не подключён", brief)
        self.assertIn("не реализовано ли всё", brief)
        self.assertIn("назови ограничение", brief)


if __name__ == "__main__":  # pragma: no cover
    unittest.main()

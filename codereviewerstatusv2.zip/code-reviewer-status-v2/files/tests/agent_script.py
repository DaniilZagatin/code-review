"""Заготовки вызовов агента для сквозных тестов (CLI, веб, пайплайн).

Сценарий: оценка этапа → вердикт → finish. submit_plan больше нет — план
разбирается кодом из текстового поля, агент только проверяет пункты.
"""

import json

CLIENT_PATH_NAME = "Постановка задачи в работу"
PROJECT_NAME = "Редизайн платёжного сервиса"
BEFORE = "задача пересылается вручную и теряется между сменами"
NOW = "задача видна в системе, но без автоматической маршрутизации"
AFTER = "задача попадает исполнителю сразу и видна обеим сторонам"

DESCRIPTION = (
    "Раньше задачи пересылались вручную и терялись между сменами. Теперь "
    "задача попадает исполнителю сразу и видна обеим сторонам."
)

STAGE_ID = "postanovka-zadach"
STAGE_TITLE = "Постановка задач"
STAGE_DESCRIPTION = "Клиент передаёт задачу в работу и видит её статус без звонка"
BULLETS = ["Определены источники обращений", "Подтверждена скорость обработки"]

CONCLUSION = [
    "Ценность подтверждена материалами",
    "Измеримость результата не закрыта",
    "Можно идти дальше",
]

ROUTER_EVIDENCE = [{"path": "backend/src/api/v1/router.py", "line": 7,
                    "basis": "функция start_task ставит задачу в обработку"}]

CONTEXT = {
    "client_path_name": CLIENT_PATH_NAME,
    "project_name": PROJECT_NAME,
    "before": BEFORE,
    "now": NOW,
    "after": AFTER,
}

JOURNEY_TEXT = "\n".join([
    f"Клиентский путь: {CLIENT_PATH_NAME}",
    f"Проект: {PROJECT_NAME}",
    f"Было: {BEFORE}",
    f"Сейчас: {NOW}",
    f"Стало: {AFTER}",
    "",
    f"## {STAGE_TITLE}",
    f"- {BULLETS[0]}",
    f"- {BULLETS[1]}",
])


def tool_call(call_id: str, name: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": call_id, "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


# Комментарий буллита — три блока вместо свободного текста. Блоки заполнены
# так, чтобы проходить смысловые гейты кода: `where` называет тот же файл, что
# и evidence, `why_this_status` называет отвергнутый статус.
COMMENT_BLOCKS = {
    "done": {
        "how_it_works": "запрос пользователя доходит до обработчика и задача ставится в работу",
        "where": "backend/src/api/v1/router.py:7 — start_task",
        "why_this_status": "не works_limited: ограничений на пути не нашлось",
    },
    "works_limited": {
        "how_it_works": "задача ставится в работу, но подтверждение приходит не по всем каналам",
        "where": "backend/src/api/v1/router.py:7 — start_task",
        "why_this_status": "не done: есть ограничение по каналам подтверждения",
    },
    "partial": {
        "how_it_works": "источники обращений разобраны только для веб-формы, почты нет вовсе",
        "where": "backend/src/api/v1/router.py:7 — start_task",
        "why_this_status": "не works_limited: часть заявленного объёма не написана",
    },
    "not_wired": {
        "how_it_works": "обработчик написан, но маршрут до него не заведён — пользователь не доходит",
        "where": "backend/src/api/v1/router.py:7 — start_task, вызывающих нет",
        "why_this_status": "не planned: код существует; не partial: до пользователя ничего не доходит",
    },
    "planned": {
        "how_it_works": "реализации нет",
        "where": "искал по router, handler, enqueue — не нашёл",
        "why_this_status": "не not_wired: кода нет вовсе",
    },
}


def stage_args(item_id: str = STAGE_ID,
               statuses: list[str] | None = None,
               evidence: list[dict] | None = None) -> dict:
    statuses = statuses or ["done", "planned"]
    criteria = []
    for index, status in enumerate(statuses):
        row: dict = {"status": status}
        row.update(COMMENT_BLOCKS.get(status, COMMENT_BLOCKS["planned"]))
        if status != "planned":
            row["evidence"] = ROUTER_EVIDENCE if evidence is None else evidence
            # Блок «где реализовано» обязан ссылаться на тот же файл, что и
            # evidence, — иначе код отклонит оценку. Тест, который подменяет
            # evidence, получает согласованный с ней текст.
            if evidence:
                first = evidence[0]
                row["where"] = f"{first.get('path')}:{first.get('line')} — {first.get('basis')}"
        criteria.append(row)
    return {"item_id": item_id, "criteria": criteria}


def summary_args(decision: str = "PIVOT") -> dict:
    return {"decision": decision, "conclusion": list(CONCLUSION)}


def brief_args(before: str = BEFORE, now: str = NOW, after: str = AFTER) -> dict:
    return {"before": before, "now": now, "after": after}


def full_session(**kwargs) -> list[dict]:
    """Полный сценарий: brief (из описания) → оценка этапа → контр-проверка → вердикт → finish."""
    calls = []
    if kwargs.get("with_brief"):
        calls.append(tool_call("call_brief", "submit_brief", **brief_args(
            **kwargs.get("brief", {}),
        )))
    calls.append(tool_call("call_stage", "submit_stage", **stage_args(**kwargs.get("stage", {}))))
    calls.append(tool_call("call_review", "submit_review", confirmed=True, notes="проверено"))
    calls.append(tool_call("call_summary", "submit_summary", **summary_args(**kwargs.get("summary", {}))))
    calls.append(tool_call("call_finish", "finish"))
    return calls

"""Скачиваемый HTML-дашборд (`render/dashboard_html.py` + `dashboard_template.html`):
контракт данных и безопасность. Без сети, без LLM, без fastapi — шаблон и
подстановка JSON проверяются как чистый строковый рендер.

Сама вёрстка/интерактив (шевроны, клик, анимация) — vanilla JS в шаблоне,
в статическом HTML их нет; здесь проверяется, что данные агента доходят до
страницы в правильном виде и что тексты агента не могут сломать/инъецировать
разметку.
"""

import json
import unittest

from pathlib import Path

from pko.render import dashboard_html
from pko.render.dashboard_html import render_dashboard_html
from pko.progress.schema import CRITERION_STATUSES, CRITERION_WEIGHT


def _result(items, summary=None, readiness=1.0, title="Тестовый проект"):
    return {
        "meta": {"title": title, "repo": "demo/repo", "commit": "abc1234", "generated_at": "2026-01-01"},
        "readiness": readiness,
        "counts": {"DONE": len(items), "PARTIAL": 0, "NOT_STARTED": 0, "UNCLEAR": 0},
        "items": items,
        **({"summary": summary} if summary is not None else {}),
    }


def _item(title="API постановки задач", status="DONE", pct=100,
          assessment=None, description="Описание этапа", color="green", label="Сделано"):
    if assessment is None:
        assessment = [{"status": "done", "text": "Реализован", "comment": ""}]
    return {"title": title, "status": status, "pct": pct, "assessment": assessment,
            "description": description, "color": color, "label": label}


class DashboardHtmlTest(unittest.TestCase):
    def test_marker_is_replaced_and_data_embedded(self):
        html = render_dashboard_html(_result([_item()]))
        self.assertNotIn("/*__DATA__*/", html)
        self.assertIn("window.__DATA__", html)

    def test_agent_texts_reach_the_page_json(self):
        html = render_dashboard_html(_result([_item(assessment=[{"status": "done", "text": "Эндпоинт реализован и подтверждён", "comment": ""}])]))
        self.assertIn("Эндпоинт реализован и подтверждён", html)
        self.assertIn("Тестовый проект", html)

    def test_readiness_rounds_to_percent_in_template(self):
        # Шаблон считает процент в JS из readiness; в JSON лежит сырое 0.4 —
        # проверяем, что оно дошло без искажения (округление делает JS).
        html = render_dashboard_html(_result([_item(status="PARTIAL", pct=40, color="amber",
                                                     label="Частично")], readiness=0.4))
        data = _extract_data(html)
        self.assertAlmostEqual(data["readiness"], 0.4)
        self.assertEqual(data["items"][0]["pct"], 40)

    def test_summary_is_present_when_provided(self):
        summary = {"conclusion": "Проект готов."}
        html = render_dashboard_html(_result([_item()], summary=summary))
        data = _extract_data(html)
        self.assertEqual(data["summary"]["conclusion"], "Проект готов.")
        self.assertIn("Проект готов.", html)

    def test_summary_is_absent_when_none(self):
        html = render_dashboard_html(_result([_item()]))
        data = _extract_data(html)
        self.assertNotIn("summary", data)

    def test_script_injection_in_agent_text_is_neutralised(self):
        # Текст агента со `</script>` не должен закрывать тег <script> с данными
        # и не должен инъецировать разметку. `<` заменяется на \u003c в JSON.
        poison = "</script><img src=x onerror=alert(1)>"
        clean = render_dashboard_html(_result([_item(assessment=[{"status": "done", "text": "чистый текст", "comment": ""}])]))
        poisoned = render_dashboard_html(_result([_item(assessment=[{"status": "done", "text": poison, "comment": ""}])]))
        # В шаблоне два <script> (данные + код) — инъекция не должна добавить
        # ни одного закрывающего тега сверх базового числа.
        self.assertEqual(poisoned.count("</script>"), clean.count("</script>"))
        # literal `<img` не выжил — `<` заменён на \u003c, тег не формируется.
        # `onerror` как подстрока в данных остаётся, но через textContent она
        # не исполнится — поэтому эту подстроку отдельно не проверяем.
        self.assertNotIn("<img", poisoned)
        # Текст восстанавливается JS-парсером: \u003c/script> → </script>
        self.assertIn("\\u003c/script>", poisoned)

    def test_empty_items_renders_without_error(self):
        html = render_dashboard_html(_result([], readiness=0.0))
        self.assertIn("window.__DATA__", html)
        self.assertEqual(_extract_data(html)["items"], [])


def _extract_data(html: str) -> dict:
    start = html.index("window.__DATA__ = ") + len("window.__DATA__ = ")
    end = html.index(";</script>", start)
    return json.loads(html[start:end])


if __name__ == "__main__":
    unittest.main()


class DashboardStatusScaleTest(unittest.TestCase):
    """Шаблон знает ту же шкалу и те же веса, что и модель.

    Расхождение здесь — это два разных процента у одного отчёта: один в
    JSON модели, другой на экране. Поэтому веса сверяются напрямую с
    `CRITERION_WEIGHT`, а не переписываются в шаблон «на глаз».
    """

    def setUp(self):
        self.template = (Path(dashboard_html.__file__).parent
                         / "dashboard_template.html").read_text(encoding="utf-8")

    def test_template_knows_every_status(self):
        for status in CRITERION_STATUSES:
            self.assertIn(status + ":", self.template, status)

    def test_template_weights_match_the_model(self):
        for status, weight in CRITERION_WEIGHT.items():
            if weight in (0.0, 1.0):
                continue
            # .75 и .25 записаны в шаблоне без ведущего нуля.
            self.assertIn("weight:" + str(weight).lstrip("0"), self.template, status)

    def test_legend_shows_the_intermediate_statuses(self):
        self.assertIn("Работает с ограничением", self.template)
        self.assertIn("Код есть, не подключён", self.template)

    def test_comment_blocks_reach_the_page(self):
        html = render_dashboard_html(_result([_item(assessment=[{
            "status": "not_wired", "text": "Инструмент правки параметров",
            "comment": "Статус: код есть, но не подключён.",
            "comment_parts": {
                "status_line": "код есть, но не подключён",
                "how": "инструмент написан, но маршрутизатор направляет мимо",
                "where": "tools.py:1484 — modify_excel_input_value",
                "why": "не planned: код существует",
            },
        }])]))
        self.assertIn("modify_excel_input_value", html)
        self.assertIn("маршрутизатор направляет мимо", html)
        self.assertIn("Почему такой статус", html)

"use client";

import { useEffect, useState } from "react";
import type { AnalysisResult, AssessmentItem, StageItem } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Download } from "lucide-react";
import "./dashboard.css";

// Веб-экран результатов — тот же дашборд, что и скачиваемый HTML
// (`backend/pko/render/dashboard_template.html`), только на React. Данные,
// расчёты и разметка совпадают намеренно: руководство не должно видеть две
// разные эстетики от одного инструмента. Стили перенесены из шаблона
// скриптом, а логика — этим файлом; расхождение здесь означает баг, а не
// вариант дизайна.
//
// Процент и цвет этапа не приходят с бэкенда: их считает сам экран по
// применимым буллитам, ровно как шаблон. Общая готовность, наоборот, приходит
// готовой — это оценка модели, а не среднее.

const STATUS_COLOR: Record<string, string> = {
  green: "var(--green)",
  amber: "var(--amber)",
  red: "var(--red)",
  purple: "var(--na)",
};

// Шкала степени реализации: шесть делений плюс «не относится». Веса — те же,
// что в backend/pko/progress/schema.py::CRITERION_WEIGHT. Расхождение весов
// означает, что процент на экране и процент в модели считаются по-разному, то
// есть баг, а не вариант оформления.
type CriterionKey = "done" | "not_wired" | "works_limited" | "partial" | "planned";

const CRITERION: Record<CriterionKey, { color: string; label: string; icon: string; weight: number }> = {
  done: { color: "var(--green)", label: "Работает", icon: "✓", weight: 1 },
  not_wired: { color: "var(--tiffany)", label: "Код есть, не подключён", icon: "", weight: 0.9 },
  works_limited: { color: "var(--lime)", label: "Работает с ограничением", icon: "✓", weight: 0.7 },
  partial: { color: "var(--purple)", label: "Реализовано частично", icon: "", weight: 0.5 },
  planned: { color: "var(--text-3)", label: "Не реализовано", icon: "", weight: 0 },
};

// Прежние ключи и цветовые синонимы — чтобы отчёты старых прогонов
// открывались. «Блокирующий фактор» из шкалы убран: читается как «не
// реализовано».
const STATUS_ALIASES: Record<string, CriterionKey> = {
  completed: "done", green: "done",
  partially: "partial", amber: "partial",
  limited: "works_limited", works_with_limits: "works_limited",
  not_connected: "not_wired", unwired: "not_wired", dead_code: "not_wired",
  blocked: "planned", blocker: "planned", red: "planned",
};

function criterionKey(item: AssessmentItem): CriterionKey {
  const raw = String(item.status || "").toLowerCase();
  const key = STATUS_ALIASES[raw] ?? (raw as CriterionKey);
  return key in CRITERION ? key : "planned";
}

// Комментарий буллита — фиксированная структура: статус (его пишет код по
// статусу), суть, ссылки на файлы и функции, обоснование выбора статуса.
const COMMENT_BLOCKS: { key: "status_line" | "how" | "where" | "why"; label: string }[] = [
  { key: "status_line", label: "Статус" },
  { key: "how", label: "Как работает" },
  { key: "where", label: "Где реализовано" },
  { key: "why", label: "Почему такой статус" },
];

// Готовность этапа: сумма весов статусов / всего_буллитов × 100.
// `null` — только если буллитов нет вовсе.
function stagePercent(item: StageItem): number | null {
  const all = (item.assessment || []);
  if (!all.length) return null;
  const score = all.reduce((sum, x) => sum + CRITERION[criterionKey(x)].weight, 0);
  return Math.round((score / all.length) * 100);
}

function stageColor(item: StageItem): string {
  const p = stagePercent(item);
  if (p === null) return "amber";
  return p >= 80 ? "green" : p >= 40 ? "amber" : "red";
}

function formatDate(value?: string): string {
  if (!value) return "";
  const d = new Date(value);
  if (isNaN(d.getTime())) return String(value);
  try {
    return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "short", year: "numeric" });
  } catch {
    return String(value);
  }
}

function downloadName(meta: AnalysisResult["meta"]): string {
  const base = (meta.project_name || meta.client_path_name || meta.repo || "project")
    .replace(/[^A-Za-z0-9А-Яа-я]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "project";
  return `pko-dashboard-${base}.html`;
}

function Gauge({ percent }: { percent: number }) {
  const r = 88;
  const c = 2 * Math.PI * r;
  const [offset, setOffset] = useState(c);
  useEffect(() => {
    const id = requestAnimationFrame(() => setOffset(c * (1 - percent / 100)));
    return () => cancelAnimationFrame(id);
  }, [percent, c]);

  return (
    <div className="gauge-wrap">
      <div className="gauge-halo" />
      <svg className="gauge-svg" viewBox="0 0 220 220">
        <defs>
          <linearGradient id="gaugeGradient" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--primary)" />
            <stop offset="62%" stopColor="var(--primary-2)" />
            <stop offset="100%" stopColor="var(--green)" />
          </linearGradient>
        </defs>
        <circle className="gauge-track" cx="110" cy="110" r={r} />
        <circle
          className="gauge-progress"
          cx="110" cy="110" r={r}
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="gauge-center">
        <div className="gauge-value">{percent}%</div>
        <div className="gauge-caption">готовность</div>
      </div>
    </div>
  );
}

function StatusLegend() {
  const defs: [CriterionKey, string][] = [
    ["done", "Работает"],
    ["not_wired", "Код есть, не подключён"],
    ["works_limited", "Работает с ограничением"],
    ["partial", "Реализовано частично"],
    ["planned", "Не реализовано"],
  ];
  return (
    <div className="status-legend">
      {defs.map(([key, label]) => (
        <span key={key} className="legend-item">
          <i
            className={cn("legend-mark", key)}
            style={{ ["--legend" as string]: CRITERION[key].color }}
          >
            {CRITERION[key].icon}
          </i>
          <span>{label}</span>
        </span>
      ))}
    </div>
  );
}

function StageCard({ item, index }: { item: StageItem; index: number }) {
  const color = stageColor(item);
  const percent = stagePercent(item);
  const criteria = item.assessment || [];

  return (
    <article
      className="stage-card"
      style={{
        ["--status" as string]: STATUS_COLOR[color],
        ["--delay" as string]: `${index * 48}ms`,
      }}
      aria-label={`${item.title}. ${percent === null ? "Буллиты не заданы" : `Готовность ${percent}%`}`}
    >
      <div className="stage-top">
        <span className="stage-index">{String(index + 1).padStart(2, "0")}</span>
        <span className="stage-pct">{percent === null ? "—" : `${percent}%`}</span>
      </div>
      <h3 className="stage-name">{item.title || "Без названия"}</h3>
      <p className="stage-description">{item.description || "Описание этапа не указано."}</p>
      <div className="criteria-list">
        {criteria.length === 0 && <div className="empty">Критерии не заданы</div>}
        {criteria.map((criterion, i) => {
          const key = criterionKey(criterion);
          const state = CRITERION[key];
          return (
            <div
              key={i}
              className={cn("criterion", key)}
              style={{ ["--bullet" as string]: state.color }}
              aria-label={state.label}
            >
              <span className="criterion-state">{state.icon}</span>
              <div className="criterion-body">
                <div className="criterion-text">{criterion.text || "Без описания"}</div>
                <CriterionComment item={criterion} label={state.label} />
              </div>
            </div>
          );
        })}
      </div>
    </article>
  );
}

// Структурный комментарий: четыре размеченных блока. Старый отчёт с одним
// абзацем `comment` рисуется как раньше — одной строкой.
function CriterionComment({ item, label }: { item: AssessmentItem; label: string }) {
  const parts = item.comment_parts;
  if (parts) {
    const rows = COMMENT_BLOCKS
      .map((b) => ({ ...b, value: b.key === "status_line" ? (parts.status_line || label) : parts[b.key] }))
      .filter((b) => !!b.value);
    if (rows.length) {
      return (
        <div className="criterion-comment">
          {rows.map((b) => (
            <div key={b.key} className={cn("criterion-block", b.key === "status_line" ? "status" : b.key)}>
              <span className="criterion-block-label">{b.label}</span>
              <span className="criterion-block-value">{b.value}</span>
            </div>
          ))}
        </div>
      );
    }
  }
  if (!item.comment) return null;
  return <div className="criterion-comment">{item.comment}</div>;
}

function Icon({ paths }: { paths: string[] }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"
         strokeLinecap="round" strokeLinejoin="round">
      {paths.map((d, i) => <path key={i} d={d} />)}
    </svg>
  );
}

const SUN = ["M12 3v2", "M12 19v2", "M3 12h2", "M19 12h2", "m5.64 5.64 1.42-1.42",
             "m16.94 16.94 1.42-1.42", "m5.64 18.36 1.42-1.42", "m16.94 7.06 1.42-1.42",
             "M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z"];
const MOON = ["M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z"];

export function Dashboard({ analysis, analysisId }: { analysis: AnalysisResult; analysisId: string }) {
  const { meta, readiness, items, summary } = analysis;
  const pathName = meta.client_path_name || "Клиентский путь";
  const projectName = meta.project_name || meta.repo || "Название проекта";
  const percent = Math.max(0, Math.min(100, Math.round(readiness)));

  // Решение приходит от модели. Резервный вывод по проценту — на случай, если
  // поле не дошло: шаблон делает ровно так же, и расходиться им нельзя.
  const rawDecision = String(meta.decision || "").toUpperCase().replace("NO-GO", "NO GO");
  const decision = ["GO", "PIVOT", "NO GO"].includes(rawDecision)
    ? rawDecision
    : percent >= 80 ? "GO" : percent >= 40 ? "PIVOT" : "NO GO";
  const decisionClass = decision === "GO" ? "go" : decision === "NO GO" ? "no-go" : "pivot";
  const decisionColor =
    decisionClass === "go" ? "var(--green)" : decisionClass === "no-go" ? "var(--red)" : "var(--amber)";

  const [theme, setTheme] = useState(() => {
    try {
      const saved = localStorage.getItem("readiness-theme");
      if (saved === "light" || saved === "dark") return saved;
    } catch { /* noop */ }
    return "light";
  });

  useEffect(() => {
    try { localStorage.setItem("readiness-theme", theme); } catch { /* noop */ }
  }, [theme]);

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      document.documentElement.style.setProperty("--mx", `${(e.clientX / window.innerWidth * 100).toFixed(1)}%`);
      document.documentElement.style.setProperty("--my", `${(e.clientY / window.innerHeight * 100).toFixed(1)}%`);
    };
    document.addEventListener("pointermove", onMove, { passive: true });
    return () => document.removeEventListener("pointermove", onMove);
  }, []);

  return (
    <div className="dashboard-root" data-theme={theme}>
      <div className="ambient" aria-hidden="true" />
      <div className="noise" aria-hidden="true" />

      <main className="shell">
        <header className="topbar">
          <div className="top-actions">
            <button
              type="button"
              className="icon-btn"
              aria-label="Переключить тему"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            >
              <Icon paths={theme === "dark" ? SUN : MOON} />
            </button>
          </div>
        </header>

        <section className="hero">
          <div className="hero-grid">
            <div className="hero-content">
              <div className="eyebrow">
                <span className="eyebrow-dot" />
                <span>Автономный анализ проекта</span>
              </div>
              <h1>{pathName}</h1>
              <div className="project-name">{projectName}</div>
              <div className="project-story">
                <div className="story-block story-before">
                  <span className="story-label">AS IS</span>
                  <strong className="story-value">{meta.before || "Исходное состояние не указано"}</strong>
                </div>
                <div className="story-block story-now">
                  <span className="story-label">Now</span>
                  <strong className="story-value">{meta.now || "Текущее состояние не указано"}</strong>
                </div>
                <div className="story-block story-after">
                  <span className="story-label">To Be</span>
                  <strong className="story-value">{meta.after || "Целевое состояние не указано"}</strong>
                </div>
              </div>
            </div>

            <div className="hero-side">
              <div className="hero-side-card gauge-card">
                <Gauge percent={percent} />
              </div>
              <div
                className="hero-side-card verdict-card"
                style={{ ["--decision" as string]: decisionColor }}
              >
                <div className="verdict-label">Оценка ИИ по клиентскому пути</div>
                <div className={cn("decision-badge", decisionClass)}>{decision}</div>
                <div className="verdict-guide">
                  GO — развивать · PIVOT — скорректировать · NO GO — остановить
                </div>
                <div className="verdict-copy">
                  {summary?.conclusion && summary.conclusion.length > 0 ? (
                    <ul className="verdict-bullets">
                      {summary.conclusion.map((text, i) => (
                        <li key={i}>{text}</li>
                      ))}
                    </ul>
                  ) : "Общий вывод пока не сформирован."}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="section-head">
            <div>
              <h2 className="section-title">Клиентский путь</h2>
              <p className="section-note">
                Этапы пути и статус ключевых результатов внутри каждого этапа.
              </p>
            </div>
            <StatusLegend />
          </div>
          {items.length === 0 ? (
            <div className="empty">Этапы проекта пока не найдены.</div>
          ) : (
            <div className="journey-viewport">
              <div className="journey" style={{ ["--stage-count" as string]: String(items.length) }}>
                {items.map((item, i) => <StageCard key={i} item={item} index={i} />)}
              </div>
            </div>
          )}
        </section>

        <footer className="footer">
          <span>
            <span className="footer-dot" />
            Автономный анализ проекта
          </span>
          <a
            href={`/api/analyses/${analysisId}/dashboard.html`}
            download={downloadName(meta)}
            className="download-btn"
          >
            <Download className="size-4" aria-hidden="true" />
            Скачать дашборд
          </a>
          <span>{meta.generated_at ? `Обновлено ${formatDate(meta.generated_at)}` : ""}</span>
        </footer>
      </main>
    </div>
  );
}

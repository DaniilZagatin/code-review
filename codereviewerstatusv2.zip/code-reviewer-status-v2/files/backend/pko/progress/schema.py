"""Модель одного прогона: клиентский путь из образа результата и оценка его
этапов по материалам проекта.

Ключевой принцип новой версии — **тексты пути не пишет модель**. Названия
этапов, их описания и буллиты копируются из образа результата дословно и
живут в `PlanItem`; вердикт (`ItemVerdict`) добавляет к ним только две вещи:
относится ли пункт к рассматриваемой инициативе и в каком он состоянии. Текст
и оценка разведены по разным объектам, поэтому переформулировать буллет
физически нечем: в вердикте для текста просто нет поля.

Это заменило прежнюю конструкцию, где модель сама сочиняла и этапы, и
формулировки возможностей. Она давала либо технический язык, либо — после
починки языка — гладкий, но не тот текст: отчёт переставал совпадать с
образом результата, который команда согласовала и по которому себя мерит.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# Состояние буллита — шкала СТЕПЕНИ РЕАЛИЗАЦИИ, а не качества метрик.
# Совпадает со словарём шаблона дашборда: он же задаёт вес в расчёте
# готовности. Пять делений вместо прежних четырёх состояний: между «работает»
# и «не реализовано» лежат три промежуточных, которые раньше схлопывались в
# `partial` и теряли главное различие — сколько работы осталось до результата.
#
#   done          1.00  путь end-to-end работает, наблюдаемых ограничений нет
#   not_wired     0.90  код написан и на вид рабочий, но НЕ ПОДКЛЮЧЁН:
#                       пользователь до него не доходит (не вызывается из точки
#                       входа, за выключенным флагом, только из тестов,
#                       результат не отдаётся наружу). Осталось подключить —
#                       поэтому по объёму работы это почти готовый пункт
#   works_limited 0.70  путь работает целиком, но названо одно ограничение
#                       (часть входных форматов, качество/полнота результата,
#                        нет краевых случаев) — «работает, но плохо»
#   partial       0.50  реализована ЧАСТЬ заявленного объёма: что-то из
#                       требуемого доходит до пользователя, чего-то нет вовсе
#   planned       0.00  подтверждённого кода нет
#
# Порядок в кортеже — по весу: он же порядок легенды в отчёте.
CRITERION_STATUSES = ("done", "not_wired", "works_limited", "partial", "planned")
CRITERION_WEIGHT = {
    "done": 1.0,
    "not_wired": 0.9,
    "works_limited": 0.7,
    "partial": 0.5,
    "planned": 0.0,
}

# Подпись статуса в отчёте и легенде дашборда.
CRITERION_LABELS = {
    "done": "Работает",
    "not_wired": "Код есть, не подключён",
    "works_limited": "Работает с ограничением",
    "partial": "Реализовано частично",
    "planned": "Не реализовано",
}

# Первая строка структурированного комментария — «Статус: код рабочий, почти
# рабочий или нет». Её пишет КОД по выбранному статусу, а не модель: иначе
# заголовок комментария и статус буллита могут разойтись, и читатель получит
# два разных ответа на один вопрос.
CRITERION_STATUS_LINE = {
    "done": "код рабочий",
    "not_wired": "код рабочий, но не подключён — пользователь до него не доходит",
    "works_limited": "код рабочий, но с названным ограничением",
    "partial": "код почти рабочий — реализована часть заявленного",
    "planned": "рабочего кода нет",
}

# Прежние ключи и «цветовые» синонимы, которые могли прийти из старых прогонов
# или от модели, обученной на прежнем словаре. Приводим к текущей шкале, чтобы
# старый JSON открывался, а не падал. `blocked` из шкалы убран: блокирующий
# фактор — это суждение о последствиях, а не степень реализации; старые
# отчёты читаются как «не реализовано».
CRITERION_ALIASES = {
    "completed": "done",
    "green": "done",
    "partially": "partial",
    "amber": "partial",
    "limited": "works_limited",
    "works_with_limits": "works_limited",
    "not_connected": "not_wired",
    "unwired": "not_wired",
    "dead_code": "not_wired",
    "blocked": "planned",
    "blocker": "planned",
    "red": "planned",
}


def normalize_status(raw: str) -> str:
    """Ключ статуса из произвольной строки: сам ключ, синоним или пустая строка."""
    key = str(raw or "").strip().lower()
    key = CRITERION_ALIASES.get(key, key)
    return key if key in CRITERION_STATUSES else ""


def status_line(status: str) -> str:
    """Первая строка комментария по статусу — детерминированно, без модели."""
    return CRITERION_STATUS_LINE.get(status, "статус не выставлен")


def render_comment(status: str, how: str, where: str, why: str) -> str:
    """Собрать комментарий буллита в единой структуре из четырёх блоков.

    Структура фиксирована и одинакова для всех буллитов — читатель отчёта
    находит нужный блок глазами, не вчитываясь:

        Статус: <строка по статусу — пишет код>
        Как работает: <суть механики от входа до результата>
        Где реализовано: <файлы/пакеты/функции — path:line — имя>
        Почему такой статус: <почему этот, а не соседний>

    Пустые блоки не печатаются: строка «Где реализовано: —» хуже, чем её
    отсутствие. Блок «Статус» печатается всегда: он выводится из статуса.
    """
    rows = [f"Статус: {status_line(status)}."]
    if how:
        rows.append(f"Как работает: {how}")
    if where:
        rows.append(f"Где реализовано: {where}")
    if why:
        rows.append(f"Почему такой статус: {why}")
    return "\n".join(rows)


DECISIONS = ("GO", "PIVOT", "NO GO")


def calculate_progress(criteria: list["CriterionVerdict"]) -> int | None:
    """Детерминированный расчёт прогресса по списку буллитов.

    Формула: сумма весов статусов / всего_буллитов × 100.

    done          — 1.0
    not_wired     — 0.9
    works_limited — 0.7
    partial       — 0.5
    planned       — 0

    Все буллиты равнозначны и все входят в знаменатель: у пункта клиентского
    пути нет состояния «не считается». Возвращает None, если список пуст.
    """
    if not criteria:
        return None
    total = len(criteria)
    score = sum(c.weight for c in criteria)
    return round(score / total * 100)


@dataclass(frozen=True)
class PlanItem:
    """Один этап клиентского пути — дословно из текстового ввода.

    `criteria` — буллиты этапа в исходном порядке и исходной редакции. Они
    попадают сюда на фазе разбора текста и дальше не меняются: вердикт
    ссылается на них по позиции, а не пересылает текст заново.
    """

    id: str
    title: str
    description: str = ""
    criteria: list[str] = field(default_factory=list)
    origin: str = "user"

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "criteria": list(self.criteria),
            "origin": self.origin,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "PlanItem":
        return PlanItem(
            id=d["id"],
            title=d["title"],
            description=d.get("description", ""),
            criteria=list(d.get("criteria") or []),
            origin=d.get("origin", "user"),
        )


@dataclass(frozen=True)
class EvidenceRef:
    """Одна ссылка на материалы, подтверждающая состояние буллита.

    `verified=False` не отбрасывается — понижается и остаётся в модели с
    причиной: утверждение без доказательства не публикуется как «материалы
    показывают».
    """

    path: str
    line: int | None
    basis: str
    verified: bool
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path, "line": self.line, "basis": self.basis,
            "verified": self.verified, "reason": self.reason,
        }


@dataclass
class CriterionVerdict:
    """Оценка одного буллита этапа: относится ли он к инициативе и что с ним.

    Текста здесь нет намеренно — он берётся из `PlanItem.criteria` по той же
    позиции. Модель не может ни переписать буллет, ни выбросить его, ни
    добавить новый: длина списка сверяется с планом.

    Состояния «не относится» у буллита нет: каждый пункт клиентского пути
    получает один из пяти статусов. Пункт, до которого инициатива не дошла, —
    это `planned`, а не отдельная серая категория: путь согласован целиком, и
    отчёт по нему должен читаться целиком.

    Комментарий разложен на три поля модели (`how`/`where`/`why`) плюс
    четвёртый блок, который выводит код из статуса. Свободного «напиши
    что-нибудь до 400 символов» больше нет: в прежнем виде модель писала то
    механику без ссылок, то ссылки без механики, и защитить вердикт этим
    текстом было нельзя. `comment` остаётся — но как СОБРАННЫЙ из блоков
    текст, чтобы старые читатели контракта не сломались.
    """

    status: str = ""
    comment: str = ""
    how: str = ""
    where: str = ""
    why: str = ""
    evidence: list[EvidenceRef] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.status and self.status not in CRITERION_STATUSES:
            raise ValueError(f"неизвестный статус буллита: {self.status}")
        if not self.comment and (self.how or self.where or self.why):
            self.comment = render_comment(self.status, self.how, self.where, self.why)

    @property
    def weight(self) -> float:
        return CRITERION_WEIGHT.get(self.status, 0.0)

    @property
    def status_label(self) -> str:
        return CRITERION_LABELS.get(self.status, "")

    def comment_parts(self) -> dict[str, str] | None:
        """Блоки комментария по отдельности — для дашборда, который рисует их
        как размеченные строки, а не как один абзац.

        `None`, если структурированных блоков нет вовсе (буллит неприменим или
        пришёл из старого прогона со свободным `comment`).
        """
        if not (self.how or self.where or self.why):
            return None
        return {
            "status_line": status_line(self.status),
            "how": self.how,
            "where": self.where,
            "why": self.why,
        }

    @property
    def verified_evidence(self) -> list[EvidenceRef]:
        return [e for e in self.evidence if e.verified]

    @property
    def is_grounded(self) -> bool:
        """Есть ли подтверждение у заявленного прогресса.

        Спрашивается со всех статусов, кроме `planned`: любой из них
        утверждает, что код существует (`not_wired` — тоже: «код есть, но не
        подключён» без ссылки на этот код не проверить). «Не реализовано» —
        утверждение об отсутствии, подтверждать в материалах нечего.
        """
        if self.status in ("", "planned"):
            return True
        return bool(self.verified_evidence)

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "status": self.status,
            "comment": self.comment,
            "evidence": [e.to_dict() for e in self.evidence],
        }
        parts = self.comment_parts()
        if parts is not None:
            out["comment_parts"] = parts
        return out


@dataclass
class ItemVerdict:
    """Оценка одного этапа: состояние его буллитов."""

    item_id: str
    criteria: list[CriterionVerdict] = field(default_factory=list)

    def percent(self) -> int | None:
        """Готовность этапа: `calculate_progress` по всем буллитам этапа.

        `None` — только если буллитов нет вовсе. Отдельного состояния
        «этап не относится к инициативе» больше нет: клиентский путь
        оценивается целиком.
        """
        return calculate_progress(self.criteria)

    @property
    def evidence(self) -> list[EvidenceRef]:
        return [e for c in self.criteria for e in c.evidence]

    @property
    def ungrounded_count(self) -> int:
        return sum(1 for c in self.criteria if not c.is_grounded)

    def to_dict(self) -> dict[str, Any]:
        return {
            "item_id": self.item_id,
            "percent": self.percent(),
            "criteria": [c.to_dict() for c in self.criteria],
        }


@dataclass(frozen=True)
class UnclaimedGroup:
    """Группа файлов, не подтвердивших ни одного буллита плана.

    Не вердикт «сделано сверх плана» — только сырой кандидат для него.
    Детерминированная разница множеств, без суждения модели.
    """

    group: str
    example_paths: list[str]
    file_count: int

    def to_dict(self) -> dict[str, Any]:
        return {"group": self.group, "example_paths": self.example_paths,
                "file_count": self.file_count}


@dataclass(frozen=True)
class ProjectSummary:
    """Итог анализа: вердикт и его обоснование.

    `conclusion` — 3 коротких буллита (до 4 слов каждый): что подтверждено,
    что мешает, можно ли идти дальше.
    """

    decision: str = ""
    conclusion: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {"decision": self.decision, "conclusion": list(self.conclusion)}


@dataclass
class ProgressModel:
    """Итоговая модель одного прогона.

    `readiness` — детерминированный расчёт: сумма весов всех буллитов,
    делённая на их число (done = 1, not_wired = 0.9, works_limited = 0.7,
    partial = 0.5, planned = 0). Не оценка модели, а арифметика по статусам.
    """

    meta: dict[str, Any] = field(default_factory=dict)
    items: dict[str, PlanItem] = field(default_factory=dict)
    verdicts: list[ItemVerdict] = field(default_factory=list)
    unclaimed: list[UnclaimedGroup] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    readiness: int = 0
    summary: ProjectSummary | None = None
    summary_source: str = "none"

    def criterion_counts(self) -> dict[str, int]:
        """Сколько буллитов в каждом состоянии — по всему пути."""
        out = {status: 0 for status in CRITERION_STATUSES}
        for verdict in self.verdicts:
            for criterion in verdict.criteria:
                if criterion.status in out:
                    out[criterion.status] += 1
        return out

    def overall_progress(self) -> int:
        """Общий прогресс: сумма весов всех буллитов / их количество × 100.

        done = 1, not_wired = 0.9, works_limited = 0.7, partial = 0.5,
        planned = 0. Все буллиты равнозначны по весу пункта.
        """
        all_criteria = [c for v in self.verdicts for c in v.criteria]
        if not all_criteria:
            return 0
        return calculate_progress(all_criteria) or 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "pko-progress-model/0.2",
            "meta": self.meta,
            "readiness": self.readiness,
            "criterion_counts": self.criterion_counts(),
            "items": {item_id: item.to_dict() for item_id, item in self.items.items()},
            "verdicts": [v.to_dict() for v in self.verdicts],
            "unclaimed": [u.to_dict() for u in self.unclaimed],
            "gaps": self.gaps,
            "summary": self.summary.to_dict() if self.summary else None,
            "summary_source": self.summary_source,
        }

    def to_json(self) -> str:
        import json

        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2, sort_keys=False)

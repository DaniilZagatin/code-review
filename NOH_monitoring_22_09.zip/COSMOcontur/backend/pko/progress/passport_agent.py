"""Паспортный агент: отдельная сессия, обход дерева сверху вниз.

Сессия оценки (`matcher.run_agent`) заканчивается вердиктом. Паспорт
клиентского пути собирает **вторая сессия** — без инструментов репозитория:
по коду она не ходит, а работает на том, что уже собрала первая — карте
возможностей, вердиктах с доказательствами и сжатом следе прочитанного.

Дерево строится **итеративно**, и очередь ведёт код, а не модель:

    journey-1  ← submit_node: поля пути
               ← declare_children: процессы (название + basis) и узлы до
                  развилки — BBB с before_fork (классификатор, права):
                  они выполняются до выбора процесса и в процессы не входят
    process-1  ← submit_node: поля процесса
               ← declare_children: BBB — новые {name, basis} или уже
                  объявленные {ref: "bbb-2"} (общий блок, второй родитель)
    bbb-1      ← submit_node
               ← declare_children: операции
    operation-1 ← submit_node          (лист — детей нет)
    operation-2 ← submit_node
    bbb-2 …    (обход в глубину, пока очередь не пуста)
    link_nodes(from, to, kind, basis, field)   связи поверх дерева
    bind_scenario_step(scenario, step, nodes)  шаги сценариев без узла
    submit_defect(title, kind, nodes, scenarios, where, blocking)  дефекты
    submit_need(name, purpose, source)                потребность клиента
    submit_guardrail(name, invariant, condition, effect, targets, source)
    submit_risks(risks)                               операционные риски
    finish

Каждый узел проверяется гейтом отдельно (`passport_gate`), отклонение стоит
одного шага, а не всего паспорта. У промежуточных узлов дети обязательны:
объявление без единого ребёнка не принимается. Идентификаторы выдаёт код,
реестр и `object-id` строит `normalize_passport` — модель присылает только
названия, основания, поля и связи. В каждом ответе модель получает карту
уже построенного дерева — из истории ей ничего вспоминать не нужно.

Сценарии из ревизии связности привязываются к узлам по шагам
(`scenario_steps` в `submit_node`, `bind_scenario_step` после дерева).
Шаг без узла код не пропускает молча: после дерева он перечисляет такие
шаги, а первый `finish` при них отклоняет.

Что модель не заполняет, потому что код это знает сам: название пути в
«Связанном КП» процесса, название родительского блока в «Связанном BBB»
операции, версию объекта (коммит). Одно имя — из одного места.

Узел, которого в коде нет, модель помечает `planned`: код оставляет ему
бизнес-смысл, владельца и «чего не хватает», остальные поля отбрасывает,
детей не спрашивает (одна карточка вместо поддерева пустых), а если
привязанный пункт ОР оценён как работающий — отклоняет: заявка «в коде
нет» спорит с оценкой. Дефекты — отдельные сущности (`submit_defect`),
а не проза, размазанная по четырём узлам; разрывы стыков и обещания без
реализации код добавляет в реестр дефектов сам.
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from pko.errors import LlmError
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import _NoopSpan, trace_span
from pko.progress.connectivity import match_bullets
from pko.progress.matcher import _strip_cjk, max_tokens_for
from pko.progress.risk_review import CHECKS as RISK_CHECKS, RESULTS as RISK_REVIEW_RESULTS, validate_review
from pko.progress.passport_gate import (
    BEFORE_FORK_TYPES,
    BRANCHING_HINT,
    BRANCHING_KINDS,
    CHILD_TYPE,
    DECISION_BOUNDARIES,
    DEFECT_KIND_HINT,
    DEFECT_KINDS,
    GUARDRAIL_EFFECT_LABEL,
    GUARDRAIL_EFFECTS,
    MAX_GUARDRAILS,
    MAX_NEEDS,
    MAX_RISKS,
    _AUDIENCE_RE,
    MAX_DEFECTS,
    PLANNED_FIELDS,
    RELATION_HINT,
    RELATION_KINDS,
    RELATION_LABEL,
    RISK_CONFIDENCE,
    RISK_CONFIDENCE_LABEL,
    RISK_SCOPES,
    RISK_SCOPE_LABEL,
    TYPE_LABEL,
    PassportCheck,
    check_defect,
    check_guardrail,
    check_need,
    check_node_fields,
    check_relation,
    check_risk,
    check_router_present,
    collapsed_level_message,
    duplicate_name_message,
    journey_name_of,
    node_type,
    norm_name,
    normalize_passport,
    parent_link_problem,
)
from pko.progress.schema import ConnectivityReview, ItemVerdict, PlanItem, ProjectSummary

_PROMPT_PATH = Path(__file__).parent / "passport_system.md"
_RISK_GUIDE_PATH = Path(__file__).parent / "risk_hypothesis_guide.md"

# Бюджет шагов паспортной сессии: узел — шаг, объявление детей — шаг.
# Дерево на 20 узлов со связями и привязкой сценариев — около 35 шагов;
# запас на отклонения гейта. `PKO_PASSPORT_MAX_STEPS`.
DEFAULT_PASSPORT_MAX_STEPS = 64
# Потолок времени паспортной сессии, `PKO_PASSPORT_MAX_SECONDS`; 0 — без предела.
DEFAULT_PASSPORT_SECONDS = 1200
# Сколько раз один узел отклоняется, прежде чем принять его с нарушениями.
MAX_NODE_REJECTIONS = 2
# У процесса меньше двух BBB — замечание: обычно процесс описан одним куском.
MIN_BBB_PER_PROCESS = 2
# Сколько ошибок подряд без вызова инструмента останавливают сессию.
_MAX_MALFORMED = 3
# `finish` при шагах сценариев без узла отклоняется столько раз: модель
# обязана либо привязать шаг, либо сознательно оставить его вне схемы.
MAX_FINISH_REJECTIONS = 1

# Узлы, которые выполняют шаги сценариев: путь и процесс — контейнеры.
SCENARIO_NODE_TYPES = ("bbb", "operation")

# Поля, которые заполняет код по дереву: одно имя — из одного места.
_LINKED_JOURNEY_FIELD = "4.3.2"   # процесс → связанный клиентский путь
_LINKED_BBB_FIELD = "4.5.2"       # операция → связанный BBB
# Статусы пунктов ОР, при которых «в коде нет» спорит с оценкой.
_WORKING_STATUSES = ("done", "limited", "unused")
# Ссылки на узлы в контракте входа: «профиль из bbb-4» — bbb-4 обязан
# входить в процесс, где стоит ссылающийся узел, либо передавать данные.
_NODE_REF_RE = re.compile(r"\b(?:bbb|operation)-\d+\b")
_INPUT_CONTRACT_FIELDS = {"bbb": "4.4.2", "operation": "4.5.5"}
_EMPTY_JOURNEY_NAME = re.compile(
    r"^(?:клиентский\s+)?путь$|как\s+его\s+назвал|название\s+(?:клиентского\s+)?пути|"
    r"назван\w*\s+моделью",
    re.IGNORECASE,
)
# Пути файлов в следе оценки — по ним проверяется «место в коде» у дефекта.
_PATH_RE = re.compile(r"[\w./\\-]+\.[A-Za-z]{1,6}\b")


# Сколько символов сжатого следа оценки уходит в первое сообщение.
_MAX_KNOWLEDGE_CHARS = 30_000
_MAX_PROOF_CHARS = 300


def _env_number(name: str, default: float) -> float:
    raw = (os.environ.get(name) or "").strip()
    try:
        return max(0.0, float(raw)) if raw else default
    except ValueError:
        return default


def passport_enabled() -> bool:
    """`PKO_PASSPORT`: выключить паспортную сессию можно только явно."""
    raw = (os.environ.get("PKO_PASSPORT") or "").strip().lower()
    return raw not in ("0", "false", "no", "off")


# --- схемы инструментов --------------------------------------------------------

_SUBMIT_NODE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_node",
        "description": (
            "Заполнить один узел паспорта — тот, который код назвал в "
            "последнем ответе. Передай его id, название (name), basis — одну "
            "фразу, почему узел существует как объект управления и чем "
            "отличается от соседей, — и fields: по каждому полю раздела "
            "{value, source}. source начинается с уровня: Установлено: / "
            "Выведено: / Гипотеза: / Требует подтверждения владельца: / "
            "Не установлено:. Для journey дополнительно decision_boundary "
            "(END_TO_END_PROCESS | COMPONENT_BBB). Код проверит узел и скажет, что дальше."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "id узла из ответа кода: journey-1, process-2, bbb-3, operation-4"},
                "name": {"type": "string", "description": "Название узла на языке бизнеса"},
                "basis": {"type": "string", "description": "Почему узел существует как объект управления и чем отличается от соседей — одна фраза"},
                "fields": {
                    "type": "object",
                    "description": "Поля раздела: {\"4.X.Y\": {\"value\": \"...\", \"source\": \"Уровень: привязка\"}}. Бизнес-смысл (*.1) — одно ёмкое предложение: зачем нужен узел, что он делает и какой результат даёт клиенту или следующему шагу. Не повторяй название и не пересказывай алгоритм.",
                },
                "bullets": {
                    "type": "array", "items": {"type": "string"},
                    "description": "Пункты образа результата, которые этот узел реализует — дословно из задания. "
                                   "По ним код считает готовность узла и красит его на схеме. Для узлов дерева "
                                   "(process, bbb, operation) обязательно старайся указать; пункт может принадлежать нескольким узлам.",
                },
                "scenario_steps": {
                    "type": "array",
                    "items": {"type": "object", "properties": {
                        "scenario": {"type": "string", "description": "id целевого сценария из задания: scenario-1 …"},
                        "step": {"type": "integer", "description": "номер шага сценария (с нуля), который выполняет этот узел"},
                    }, "required": ["scenario", "step"]},
                    "description": "В каких шагах целевых сценариев участвует узел. По ним код рисует путь сценария "
                                   "поверх схемы и показывает разрывы на стыках. Только для bbb и operation.",
                },
                "scenario": {
                    "type": "string",
                    "description": "Только для process: ровно один id целевого сценария (scenario-N), который и является этим процессом. Один сценарий — один процесс.",
                },
                "decision_boundary": {"type": "string", "description": "Только для journey: END_TO_END_PROCESS или COMPONENT_BBB"},
                "planned": {
                    "type": "boolean",
                    "description": "true — узла в коде нет, он обещан образом результата. Код оставит "
                                   "бизнес-смысл, владельца и «чего не хватает» (версия и изменения), "
                                   "остальные поля отбросит: режимы, fallback, handoff и компенсацию "
                                   "несуществующему коду не назначают.",
                },
            },
            "required": ["id", "name", "basis", "fields"],
        },
    },
}

_DECLARE_CHILDREN_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "declare_children",
        "description": (
            "Объявить дочерние узлы только что заполненного узла: для journey "
            "— процессы, для process — BBB, для bbb — атомарные операции. "
            "Новый ребёнок — {name, basis}; уже объявленный узел того же уровня, "
            "который входит и сюда (общий BBB или общая операция), — {ref: id}: "
            "у него появится второй родитель, заполнять его повторно не нужно. "
            "У journey дети с before_fork: true — BBB до развилки (определение "
            "сценария обращения, проверка прав): они выполняются до выбора процесса, "
            "в процессы не входят и связываются с ними triggers. "
            "Поля каждого нового ребёнка ты заполнишь, когда код его назовёт. "
            "Дети обязательны: journey без процессов, процесс без BBB и BBB без "
            "операций не принимаются. Дроби по бизнес-действиям: ориентир 3–6 BBB "
            "на процесс, 1–3 операции на BBB."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "parent": {"type": "string", "description": "id узла-родителя из ответа кода"},
                "branching": {
                    "type": "string", "enum": list(BRANCHING_KINDS),
                    "description": "Как дети складываются в результат родителя: "
                                   + "; ".join(f"{k} — {BRANCHING_HINT[k]}" for k in BRANCHING_KINDS),
                },
                "children": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "basis": {"type": "string", "description": "Почему это отдельный объект и чем отличается от соседей"},
                            "ref": {"type": "string", "description": "id уже объявленного узла того же уровня, который входит и в этот родитель"},
                            "before_fork": {"type": "boolean", "description": "Только у детей journey: BBB до развилки — выполняется до выбора процесса и выбирает или разрешает его"},
                        },
                    },
                },
            },
            "required": ["parent", "children"],
        },
    },
}

_LINK_NODES_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "link_nodes",
        "description": (
            "Объявить связь между двумя узлами поверх дерева. Виды: "
            + "; ".join(f"{k} — {RELATION_HINT[k]}" for k in RELATION_KINDS)
            + ". basis — одна фраза, какой факт кода или образа результата "
            "показывает связь. Дерево (родитель → ребёнок) связью не дублируй."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "from": {"type": "string", "description": "id узла-источника"},
                "to": {"type": "string", "description": "id узла-приёмника"},
                "kind": {"type": "string", "enum": list(RELATION_KINDS)},
                "basis": {"type": "string"},
                "field": {"type": "string", "description": "Для feeds: конкретное имя поля состояния, которое источник записывает, а приёмник читает (например portfolio_items), а не «состояние графа»"},
            },
            "required": ["from", "to", "kind", "basis"],
        },
    },
}

_BIND_SCENARIO_STEP_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "bind_scenario_step",
        "description": (
            "Привязать шаг целевого сценария к узлам, которые его выполняют "
            "(bbb или operation). Нужен для шагов, которые не были указаны в "
            "scenario_steps при заполнении узлов: код перечисляет их после дерева."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "scenario": {"type": "string", "description": "id сценария: scenario-1 …"},
                "step": {"type": "integer", "description": "номер шага с нуля"},
                "nodes": {"type": "array", "items": {"type": "string"}, "description": "id узлов bbb/operation"},
            },
            "required": ["scenario", "step", "nodes"],
        },
    },
}

_SUBMIT_DEFECT_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_defect",
        "description": (
            "Зафиксировать один дефект как отдельный объект — вместо пересказа в полях "
            "нескольких узлов. Виды: "
            + "; ".join(f"{k} — {DEFECT_KIND_HINT[k]}" for k in DEFECT_KINDS)
            + ". Один дефект — один вызов, даже если он объясняет несколько узлов и сценариев. "
            "Разрывы стыков из ревизии связности и обещания образа результата без реализации "
            "код добавляет в реестр сам — их повторять не нужно."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Что не так и чем грозит клиенту — словами, без кода"},
                "kind": {"type": "string", "enum": list(DEFECT_KINDS)},
                "nodes": {"type": "array", "items": {"type": "string"}, "description": "Затронутые узлы"},
                "scenarios": {"type": "array", "items": {"type": "string"}, "description": "Сценарии из задания, которые дефект блокирует или искажает"},
                "where": {"type": "string", "description": "Место в коде: путь и строка из материалов оценки"},
                "blocking": {"type": "boolean", "description": "true — сценарий с этим дефектом до результата не доходит (деньги списаны, продукт не открыт)"},
            },
            "required": ["title", "kind"],
        },
    },
}

_SUBMIT_NEED_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_need",
        "description": (
            "Сформулировать потребность клиента — задачу человека, существующую до продукта, "
            "которую закрывает клиентский путь. Аудитория («все клиенты приложения») потребностью "
            "не является. Кодом потребность не устанавливается: source — «Выведено: …» из образа "
            "результата или «Требует подтверждения владельца: …». Обычно одна-две на путь."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Короткое предметное название потребности"},
                "purpose": {"type": "string", "description": "Какую задачу решает человек и какой результат для него ценен — одно-два предложения"},
                "source": {"type": "string", "description": "Уровень и привязка: из какого текста образа результата следует"},
            },
            "required": ["name", "purpose", "source"],
        },
    },
}

_SUBMIT_GUARDRAIL_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_guardrail",
        "description": (
            "Сформулировать ограничение исполнения: защищаемый инвариант + условие срабатывания + "
            "ограничивающий эффект. Эффекты: "
            + ", ".join(f"{e} — {GUARDRAIL_EFFECT_LABEL[e]}" for e in GUARDRAIL_EFFECTS)
            + ". targets — узлы, которые ограничение защищает (процесс, BBB, операция, путь). "
            "Константа или лимит без места применения ограничение не доказывают; обязательная "
            "защита из образа результата может быть «Требует подтверждения владельца», если реализации нет."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "invariant": {"type": "string", "description": "Что защищаем — какое состояние не должно нарушаться"},
                "condition": {"type": "string", "description": "Когда срабатывает"},
                "effect": {"type": "string", "enum": list(GUARDRAIL_EFFECTS)},
                "targets": {"type": "array", "items": {"type": "string"}, "description": "id защищаемых узлов"},
                "source": {"type": "string", "description": "Уровень и привязка: где в коде или образе результата задано"},
            },
            "required": ["name", "invariant", "condition", "effect", "targets", "source"],
        },
    },
}

_SUBMIT_RISKS_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_risks",
        "description": (
            "Завершить отдельный анализ операционных рисков после дерева и guardrails. "
            "Передай весь дедуплицированный набор одним массивом (пустой массив допустим, "
            "если после локальной и сквозной проверки риски не обоснованы). Каждый риск — "
            "причина → негативное событие → бизнес-последствие; это не дефект, не отсутствие "
            "контроля само по себе и не новый уровень дерева. Риск не меняет статус узла."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "risks": {
                    "type": "array",
                    "maxItems": MAX_RISKS,
                    "items": {
                        "type": "object",
                        "properties": {
                            "title": {"type": "string", "description": "Краткое название негативного события, без слов «возможный риск»"},
                            "problem": {"type": "string", "description": "Для карточки руководителя: одно короткое понятное предложение, которое объединяет условие возникновения, негативное событие и конкретное бизнес-последствие. Без имён функций, вводных слов и повтора названия. Пример: «Если при нулевых остатках расчёт продолжится по обычному правилу, клиенту могут предложить портфель с неверными долями продуктов»"},
                            "scope": {"type": "string", "enum": list(RISK_SCOPES), "description": "local — внутри одного узла; cross_node — на стыке двух и более"},
                            "cause": {"type": "string", "description": "Отказ, ошибка, состояние данных, нарушение порядка, внешнее событие или недостаточный контроль"},
                            "negative_event": {"type": "string", "description": "Одно понятное руководителю предложение: что может пойти не так для клиента или операции; не повторяй причины и последствия"},
                            "consequences": {"type": "array", "items": {"type": "string"}, "description": "Влияние на клиента, банк, обязательство, деньги, данные, срок или бизнес-результат"},
                            "primary_node": {"type": "string", "description": "Основной id узла возникновения"},
                            "linked_nodes": {"type": "array", "items": {"type": "string"}, "description": "Все затронутые узлы, включая основной"},
                            "existing_controls": {
                                "type": "array",
                                "items": {"type": "object", "properties": {
                                    "description": {"type": "string"},
                                    "basis": {"type": "string", "description": "Где контроль обнаружен и какую часть цепочки покрывает"},
                                }, "required": ["description", "basis"]},
                            },
                            "control_gap": {"type": "string", "description": "Конкретный пробел после problem: на каком понятном читателю этапе, перед каким действием и какая проверка/ветка/контроль не покрывает описанное условие. Не пиши внутренние ID вроде operation-28: они допустимы только в primary_node/linked_nodes. Если отсутствие не доказано, прямо напиши «не подтверждено», но назови конкретное правило. Не повторяй событие и последствия"},
                            "guardrails": {"type": "array", "items": {"type": "string"}, "description": "id связанных ограничений исполнения: guardrail-N"},
                            "evidence": {
                                "type": "array",
                                "items": {"type": "object", "properties": {
                                    "where": {"type": "string", "description": "Путь/контракт/тест/иной артефакт из материалов оценки"},
                                    "basis": {"type": "string", "description": "Наблюдаемый факт и его роль в выводе"},
                                }, "required": ["where", "basis"]},
                            },
                            "confidence": {"type": "string", "enum": list(RISK_CONFIDENCE)},
                            "confidence_note": {"type": "string", "description": "Почему сила основания соответствует уровню"},
                            "confirmation_needed": {"type": "string", "description": "Для requires_confirmation: что именно проверить"},
                        },
                        "required": ["title", "problem", "scope", "cause", "negative_event", "consequences",
                                     "primary_node", "linked_nodes", "existing_controls", "control_gap",
                                     "guardrails", "evidence", "confidence", "confidence_note"],
                    },
                },
            },
            "required": ["risks"],
        },
    },
}

# The checklist is stored for audit, never rendered as a wall of green controls.
_risk_parameters = _SUBMIT_RISKS_SCHEMA["function"]["parameters"]
_risk_parameters["required"].append("review")
_risk_parameters["properties"]["review"] = {
    "type": "array", "description": "Внутренний чек-лист каждого процесса, включая его шаги и стыки",
    "items": {"type": "object", "required": ["node", "checks"], "properties": {
        "node": {"type": "string", "description": "process-N"},
        "checks": {"type": "array", "items": {"type": "object",
            "required": ["check", "result", "note", "evidence", "risk_titles"], "properties": {
                "check": {"type": "string", "enum": list(RISK_CHECKS), "description": str(RISK_CHECKS)},
                "result": {"type": "string", "enum": list(RISK_REVIEW_RESULTS)},
                "note": {"type": "string", "description": "Проверенные шаги, покрытие контроля и предел вывода; unknown — каких сведений нет"},
                "evidence": _risk_parameters["properties"]["risks"]["items"]["properties"]["evidence"],
                "risk_titles": {"type": "array", "items": {"type": "string"}},
            }}},
    }},
}
for _key, _description in {
    "trigger": "Конкретное условие возникновения события",
    "mechanism": "Как причина приводит к событию несмотря на найденные контроли; не выводи отсутствие защиты из молчания материалов",
    "recommendation": "Адресное действие для закрытия именно этого пробела",
    "closure_criterion": "Проверяемый результат теста/наблюдения, достаточный для закрытия пробела",
}.items():
    _item = _risk_parameters["properties"]["risks"]["items"]
    _item["properties"][_key] = {"type": "string", "description": _description}
    _item["required"].append(_key)

_FINISH_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "finish",
        "description": "Завершить паспорт: дерево построено, связи объявлены, шаги сценариев привязаны.",
        "parameters": {"type": "object", "properties": {}},
    },
}


# --- состояние сессии ------------------------------------------------------------

@dataclass
class _Node:
    id: str
    name: str
    basis: str
    # Первый родитель — место узла в дереве; остальные — общие включения.
    parents: list[str] = field(default_factory=list)
    # Как дети складываются в результат: из BRANCHING_KINDS, пусто — не задано.
    branching: str = ""
    # BBB до развилки: под клиентским путём, к процессам ведёт triggers.
    before_fork: bool = False
    # В коде нет: поля урезаны, статус на схеме — «не реализован».
    planned: bool = False
    filled: bool = False
    data: dict[str, Any] = field(default_factory=dict)
    children: list[str] = field(default_factory=list)

    @property
    def parent(self) -> str | None:
        return self.parents[0] if self.parents else None


@dataclass
class _PassportSession:
    nodes: dict[str, _Node] = field(default_factory=dict)
    counters: dict[str, int] = field(default_factory=dict)
    # Очередь заполнения — стек обхода в глубину.
    queue: list[str] = field(default_factory=list)
    # Узел, поля которого ждёт код, и узел, дети которого ждут объявления.
    current: str | None = None
    awaiting_children_of: str | None = None
    tree_done: bool = False
    attempts: dict[str, int] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    remarks: list[str] = field(default_factory=list)
    finished: bool = False
    decision_boundary: str = ""
    # Название инициативы — антипример для имени клиентского пути. Путь
    # должен описывать переход клиента к результату, а не продукт/проект.
    initiative_name: str = ""
    span: Any = field(default_factory=lambda: _NoopSpan())
    on_node: Callable[[str, str], None] | None = None
    # Пункты ОР (дословно) и целевые сценарии — для привязки узлов: по ним
    # код считает готовность узла и рисует путь сценария на схеме.
    plan_bullets: list[str] = field(default_factory=list)
    # Статус каждого пункта ОР после рецензента — сверка с «в коде нет».
    bullet_status: dict[str, str] = field(default_factory=dict)
    scenarios: dict[str, list[str]] = field(default_factory=dict)
    scenario_titles: dict[str, str] = field(default_factory=dict)
    # Связи поверх дерева: {from, to, kind, basis, field}.
    relations: list[dict[str, str]] = field(default_factory=list)
    # Дефекты — отдельные сущности.
    defects: list[dict[str, Any]] = field(default_factory=list)
    # Потребности клиента и ограничения исполнения — уровни графа.
    needs: list[dict[str, Any]] = field(default_factory=list)
    guardrails: list[dict[str, Any]] = field(default_factory=list)
    # Риски передаются одним финальным пакетом: так модель сначала видит всё
    # дерево, связи, контроли и может дедуплицировать локальные/сквозные записи.
    risks: list[dict[str, Any]] = field(default_factory=list)
    risk_reviewed: bool = False
    risk_review: list[dict[str, Any]] = field(default_factory=list)
    # Пути файлов из материалов оценки — «место в коде» дефекта сверяется с ними.
    known_paths: set[str] = field(default_factory=set)

    def new_id(self, ntype: str) -> str:
        self.counters[ntype] = self.counters.get(ntype, 0) + 1
        return f"{ntype}-{self.counters[ntype]}"

    def tree_ids(self) -> list[str]:
        return list(self.nodes)

    def of_type(self, ntype: str) -> list[_Node]:
        return [n for n in self.nodes.values() if node_type(n.id) == ntype]

    def relation_keys(self) -> set[tuple[str, str, str]]:
        return {(r["from"], r["to"], r["kind"]) for r in self.relations}

    def relation_context(self) -> dict[str, dict[str, Any]]:
        """Родители и признак «до развилки» — для контекстных проверок связи."""
        return {nid: {"parents": list(n.parents), "before_fork": n.before_fork}
                for nid, n in self.nodes.items()}

    def processes_of(self, nid: str) -> set[str]:
        """Процессы, в которые узел входит (через любого из родителей)."""
        out: set[str] = set()
        frontier = [nid]
        seen: set[str] = set()
        while frontier:
            current = frontier.pop()
            if current in seen or current not in self.nodes:
                continue
            seen.add(current)
            if node_type(current) == "process":
                out.add(current)
                continue
            frontier.extend(self.nodes[current].parents)
        return out

    def bound_steps(self) -> set[tuple[str, int]]:
        out: set[tuple[str, int]] = set()
        for node in self.nodes.values():
            for entry in node.data.get("scenario_steps") or []:
                out.add((str(entry.get("scenario")), int(entry.get("step"))))
        return out

    def unbound_steps(self) -> list[tuple[str, int, str]]:
        """Шаги целевых сценариев, у которых нет ни одного узла."""
        bound = self.bound_steps()
        return [
            (sid, index, text)
            for sid, steps in self.scenarios.items()
            for index, text in enumerate(steps)
            if (sid, index) not in bound
        ]


# --- обработчики ----------------------------------------------------------------

def _handle_submit_node(state: _PassportSession, args: dict) -> str:
    nid = str(args.get("id") or "").strip()
    ntype = node_type(nid)
    expected = _expected_submit(state)
    if not ntype or nid not in expected:
        return (f"submit_node отклонён: сейчас ожидается {_expected_text(state)}, "
                f"а пришёл «{nid or '?'}».")
    name = _clean(args.get("name"))
    basis = _clean(args.get("basis"))
    fields = args.get("fields")
    if isinstance(fields, str):
        try:
            fields = json.loads(fields)
        except ValueError:
            fields = None
    if not isinstance(fields, dict):
        fields = {}
    fields = _clean_fields(fields)
    node = state.nodes.get(nid)
    if node is not None and not name:
        name = node.name
    if node is not None and not basis:
        basis = node.basis
    # Клиентский путь формулирует агент: переход клиента из исходного
    # состояния к ценному результату. Аудитория путём не является.
    if ntype == "journey" and name and _AUDIENCE_RE.search(name) and len(name.split()) <= 5:
        return (f"{nid} отклонён:\n- «{name}» — аудитория, а не клиентский путь. Назови путь как "
                "переход клиента к результату: что человек получает в конце.")
    if (ntype == "journey" and name and state.initiative_name
            and norm_name(name) == norm_name(state.initiative_name)):
        return (
            f"{nid} отклонён:\n- «{name}» повторяет название инициативы. Название "
            "клиентского пути должно выражать общий результат для клиента и "
            "охватывать все процессы, например «Размещение сбережений»"
        )
    if ntype == "journey" and name and _EMPTY_JOURNEY_NAME.search(name):
        return (
            f"{nid} отклонён:\n- «{name}» не раскрывает суть пути. Назови действие "
            "клиента и конечный результат, без служебных слов о пути или модели"
        )

    payload: dict[str, Any] = {"name": name, "basis": basis, "fields": fields}
    planned = bool(args.get("planned")) and ntype != "journey"
    if planned:
        payload["planned"] = True
    if node is not None and node.before_fork:
        payload["before_fork"] = True
    if node is not None and node.branching:
        payload["branching"] = node.branching
    _fill_linked_fields(state, nid, ntype, fields)
    check = PassportCheck()
    if not name:
        check.errors.append(f"{nid}: нет названия (name)")
    if not basis:
        check.errors.append(f"{nid}: нет basis — одной фразы, почему узел существует как объект управления")
    if not fields:
        check.errors.append(f"{nid}: fields пуст — заполни поля раздела, по каждому value и source")
    _check_name_unique(check, state, nid, name)
    if ntype == "process" and state.scenarios:
        scenario_id = str(args.get("scenario") or "").strip()
        if not scenario_id and node is not None and node.filled:
            scenario_id = str(node.data.get("scenario") or "").strip()
        claimed = {
            str(other.data.get("scenario") or "").strip()
            for other in state.of_type("process")
            if other.id != nid and other.filled
        }
        unclaimed = [sid for sid in state.scenarios if sid not in claimed]
        if not scenario_id and len(unclaimed) == 1:
            scenario_id = unclaimed[0]
        if scenario_id not in state.scenarios:
            check.errors.append(
                f"{nid}: process — это один целевой сценарий; укажи scenario из списка: "
                + ", ".join(state.scenarios)
            )
        elif scenario_id in claimed:
            check.errors.append(
                f"{nid}: сценарий {scenario_id} уже представлен другим процессом; "
                "один сценарий нельзя дублировать двумя процессами"
            )
        else:
            payload["scenario"] = scenario_id
    check_node_fields(check, nid, payload)
    if planned:
        payload["fields"] = {fid: f for fid, f in fields.items() if fid in PLANNED_FIELDS.get(ntype, set())}

    if ntype != "journey":
        _attach_links(state, check, nid, ntype, args, payload)
        if planned:
            _check_planned_against_verdicts(state, check, nid, payload.get("bullets") or [])

    if ntype == "journey":
        boundary = str(args.get("decision_boundary") or "").strip()
        if boundary not in DECISION_BOUNDARIES:
            check.errors.append(
                "journey: decision_boundary должен быть END_TO_END_PROCESS "
                "(путь покрывает триггер входа и результат после) или COMPONENT_BBB "
                "(диалог внутри агента от классификации до сообщения)"
            )
        else:
            payload["decision_boundary"] = boundary

    if check.errors:
        state.attempts[nid] = state.attempts.get(nid, 0) + 1
        state.span.add_event("node_rejected", node=nid, attempts=state.attempts[nid])
        if state.attempts[nid] <= MAX_NODE_REJECTIONS:
            listed = "\n".join(f"- {e}" for e in check.errors[:10])
            return f"{nid} отклонён:\n{listed}\nИсправь и вызови submit_node({nid}) снова."
        state.notes.append(
            f"{nid} принят с нарушениями после {MAX_NODE_REJECTIONS} отклонений: "
            + "; ".join(check.errors[:6])
        )

    if node is None:
        node = _Node(id=nid, name=name, basis=basis)
        state.nodes[nid] = node
    node.name, node.basis = name, basis
    node.planned = planned
    # Повторная отправка после дерева (исправление по замечанию) не теряет
    # привязок сценариев, сделанных bind_scenario_step.
    if node.filled and not payload.get("scenario_steps"):
        payload["scenario_steps"] = list(node.data.get("scenario_steps") or [])
    node.data = payload
    node.filled = True
    if ntype == "journey":
        state.decision_boundary = payload.get("decision_boundary", state.decision_boundary)
    state.remarks.extend(check.remarks)
    state.span.add_event("node_accepted", node=nid, remarks=len(check.remarks))
    if state.on_node is not None:
        state.on_node(nid, name)

    reply = [f"{nid} «{name}» принят."]
    if check.remarks:
        reply.append("Замечания (исправь при желании повторным submit_node, иначе продолжай):")
        reply.extend(f"- {r}" for r in check.remarks[:6])

    if state.tree_done:
        # Правка уже принятого узла после дерева: очередь не трогаем.
        reply.append(_after_tree_text(state))
        return "\n".join(reply)

    if planned and ntype in CHILD_TYPE:
        # Обещание без реализации — одна карточка и строка в реестре дефектов,
        # а не поддерево пустых карточек: детей у планируемого узла код не ждёт.
        reply.append("Узел планируемый: детей у него не заводим — обещание уйдёт в реестр дефектов как дефект полноты.")
        state.current = None
        reply.append(_advance(state))
        return "\n".join(reply)
    if ntype in CHILD_TYPE:
        state.current = None
        state.awaiting_children_of = nid
        child_label = TYPE_LABEL[CHILD_TYPE[ntype]]
        reply.append(
            f"Теперь объяви детей: declare_children(parent=\"{nid}\", children=[{{name, basis}} | {{ref}}, …]) "
            f"— {child_label.lower()} ({_children_hint(ntype)}). Дети обязательны."
        )
        return "\n".join(reply)

    state.current = None
    reply.append(_advance(state))
    return "\n".join(reply)


def _fill_linked_fields(state: _PassportSession, nid: str, ntype: str, fields: dict[str, Any]) -> None:
    """Связанный КП у процесса и связанный BBB у операции заполняет код:
    имя берётся из дерева, а не переписывается моделью в каждой карточке."""
    node = state.nodes.get(nid)
    parent = state.nodes.get(node.parent) if node is not None and node.parent else None
    if ntype == "process":
        root = next(iter(state.of_type("journey")), None)
        if root is not None:
            fields[_LINKED_JOURNEY_FIELD] = {
                "value": f"Клиентский путь «{root.name}».",
                "source": "Выведено: название пути сформулировано по исходному и целевому состоянию инициативы, узел journey-1",
            }
    elif ntype == "operation" and parent is not None:
        others = [state.nodes[p].name for p in node.parents[1:] if p in state.nodes]
        value = f"BBB «{parent.name}»" + (" (также в " + ", ".join(f"«{n}»" for n in others) + ")" if others else "") + "."
        fields[_LINKED_BBB_FIELD] = {
            "value": value,
            "source": f"Установлено: место операции в дереве паспорта — родитель {parent.id}",
        }


def _check_planned_against_verdicts(state: _PassportSession, check: PassportCheck,
                                    nid: str, bullets: list[str]) -> None:
    """«В коде нет» спорит с оценкой, если привязанный пункт ОР работает."""
    working = [b for b in bullets if state.bullet_status.get(b) in _WORKING_STATUSES]
    if working:
        check.errors.append(
            f"{nid}: узел объявлен планируемым, но его пункт ОР оценён как работающий: "
            + "; ".join(f"«{b[:60]}»" for b in working[:3])
            + ". Либо узел реализован (убери planned), либо пункт привязан не к тому узлу"
        )


def _attach_links(state: _PassportSession, check: PassportCheck, nid: str, ntype: str,
                  args: dict, payload: dict[str, Any]) -> None:
    """Привязка узла к пунктам ОР и шагам сценариев — модель предлагает,
    код сопоставляет. Несопоставленное отбрасывается с замечанием, а не
    с отклонением: карточка узла ценна и без раскраски."""
    raw_bullets = args.get("bullets")
    bullets = match_bullets(raw_bullets, state.plan_bullets) if state.plan_bullets else []
    if isinstance(raw_bullets, list) and raw_bullets and not bullets:
        check.remarks.append(
            f"{nid}: ни один из названных пунктов ОР не сопоставлен — цитируй пункты "
            "дословно из задания"
        )
    elif ntype in SCENARIO_NODE_TYPES and not bullets and state.plan_bullets:
        check.remarks.append(
            f"{nid}: не привязан к пунктам ОР (bullets) — без этого готовность узла на "
            "схеме не считается"
        )
    payload["bullets"] = bullets

    steps_out: list[dict[str, Any]] = []
    raw_steps = args.get("scenario_steps")
    if isinstance(raw_steps, list):
        if ntype not in SCENARIO_NODE_TYPES and raw_steps:
            check.remarks.append(
                f"{nid}: шаги сценариев выполняют BBB и операции, а не {TYPE_LABEL[ntype].lower()} — "
                "привязка отброшена, укажи её у детей"
            )
        else:
            for item in raw_steps:
                if not isinstance(item, dict):
                    continue
                sid = str(item.get("scenario") or "").strip()
                try:
                    step = int(item.get("step"))
                except (TypeError, ValueError):
                    check.remarks.append(f"{nid}: у scenario_steps step должен быть числом")
                    continue
                problem = _scenario_step_problem(state, sid, step)
                if problem:
                    check.remarks.append(f"{nid}: {problem}")
                    continue
                entry = {"scenario": sid, "step": step}
                if entry not in steps_out:
                    steps_out.append(entry)
    payload["scenario_steps"] = steps_out


def _scenario_step_problem(state: _PassportSession, sid: str, step: int) -> str:
    steps = state.scenarios.get(sid)
    if steps is None:
        if not state.scenarios:
            return "целевых сценариев в задании нет"
        return f"сценария {sid!r} нет — есть: " + ", ".join(state.scenarios)
    if not (0 <= step < len(steps)):
        return f"у {sid} шаги 0–{len(steps) - 1}, прислан {step}"
    return ""


def _handle_declare_children(state: _PassportSession, args: dict) -> str:
    parent_id = str(args.get("parent") or "").strip()
    if state.awaiting_children_of is None or parent_id != state.awaiting_children_of:
        return (f"declare_children отклонён: сейчас ожидается {_expected_text(state)}"
                + (f", а не объявление детей у «{parent_id}»" if parent_id else ""))
    parent = state.nodes[parent_id]
    ptype = node_type(parent_id)
    ctype = CHILD_TYPE[ptype]
    branching = str(args.get("branching") or "").strip()
    raw = args.get("children")
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            raw = None
    items = [c for c in (raw or []) if isinstance(c, dict)]
    new_children = [c for c in items if not str(c.get("ref") or "").strip() and str(c.get("name") or "").strip()]
    refs = [str(c.get("ref") or "").strip() for c in items if str(c.get("ref") or "").strip()]
    # Узлы до развилки объявляются у пути вместе с процессами и в дереве
    # стоят перед ними: они выполняются раньше любого процесса.
    gate_children = [c for c in new_children if ptype == "journey" and bool(c.get("before_fork"))]
    new_children = [c for c in gate_children] + [c for c in new_children if c not in gate_children]

    check = PassportCheck()
    if branching and branching not in BRANCHING_KINDS:
        check.errors.append(
            f"{parent_id}: тип ветвления «{branching}» не из списка: "
            + ", ".join(f"{k} ({BRANCHING_HINT[k]})" for k in BRANCHING_KINDS)
        )
    if not new_children and not refs:
        check.errors.append(
            f"{parent_id}: у {TYPE_LABEL[ptype].lower()} должен быть хотя бы один "
            f"{TYPE_LABEL[ctype].lower()} — {_children_hint(ptype)}"
        )
    if ptype == "journey" and new_children and len(gate_children) == len(new_children) and not refs:
        check.errors.append(
            f"{parent_id}: объявлены только узлы до развилки — у клиентского пути должен "
            "быть хотя бы один процесс"
        )
    if ptype != "journey" and any(bool(c.get("before_fork")) for c in new_children):
        check.errors.append(
            f"{parent_id}: before_fork допустим только у детей клиентского пути — "
            "узел до развилки стоит перед процессами, а не внутри"
        )
    seen: set[str] = set()
    for child in new_children:
        cname = _clean(child.get("name"))
        cbasis = _clean(child.get("basis"))
        key = norm_name(cname)
        child_type = "bbb" if child in gate_children else ctype
        if not cbasis:
            check.errors.append(f"«{cname}»: нет basis")
        if key in seen:
            check.errors.append(f"«{cname}» объявлен дважды")
        seen.add(key)
        if key == norm_name(parent.name):
            check.errors.append(duplicate_name_message(f"{child_type}-?", parent_id, cname))
        else:
            _check_name_unique(check, state, f"{child_type}-?", cname)
    # Ссылка на уже объявленный узел — общий ребёнок: второй родитель того же
    # уровня, а не новый узел. Существование и тип проверяет гейт.
    shared: list[str] = []
    for ref in refs:
        if ref in shared:
            check.errors.append(f"{ref} указан дважды")
            continue
        problem = parent_link_problem(ref, parent_id, set(state.nodes)) if ref in state.nodes else f"{ref}: узла нет"
        if not problem and state.nodes[ref].before_fork:
            problem = (f"{ref}: узел до развилки выполняется до выбора процесса и в процессы "
                       "не входит; если процесс им запускается — link_nodes(kind=triggers)")
        if problem:
            check.errors.append(f"ref {problem}")
            continue
        if parent_id in state.nodes[ref].parents:
            check.errors.append(f"{ref} уже ребёнок {parent_id}")
            continue
        shared.append(ref)
    total = len(new_children) + len(shared)
    if (ptype == "process" and len(new_children) == 1 and not shared
            and norm_name(new_children[0].get("basis")) == norm_name(parent.basis)):
        check.errors.append(collapsed_level_message(parent_id, f"{ctype}-?"))
    if (ptype == "bbb" and len(new_children) == 1 and not shared
            and norm_name(new_children[0].get("basis")) == norm_name(parent.basis)):
        check.errors.append(
            f"{parent_id} и operation-?: единственная операция повторяет основание BBB. "
            "Операция должна называть конкретный вызов, вход, выход и собственную точку "
            "отказа; если отдельной точки отказа нет, не создавай формальный уровень"
        )

    if check.errors:
        key = f"children:{parent_id}"
        state.attempts[key] = state.attempts.get(key, 0) + 1
        state.span.add_event("children_rejected", node=parent_id, attempts=state.attempts[key])
        if state.attempts[key] <= MAX_NODE_REJECTIONS or not total:
            listed = "\n".join(f"- {e}" for e in check.errors[:10])
            return (f"дети {parent_id} отклонены:\n{listed}\n"
                    f"Исправь и вызови declare_children(parent=\"{parent_id}\") снова.")
        state.notes.append(
            f"дети {parent_id} приняты с нарушениями: " + "; ".join(check.errors[:6])
        )

    if ptype == "process" and total < MIN_BBB_PER_PROCESS:
        state.remarks.append(
            f"{parent_id}: один BBB на процесс — проверь по признакам дробления "
            "(разные входы/результаты, внешние системы, расчёт vs генерация, "
            "режим полномочий); обычно процесс описан одним куском"
        )

    if branching in BRANCHING_KINDS:
        parent.branching = branching
        parent.data["branching"] = branching
    elif ptype != "journey" and len(new_children) + len(shared) > 1:
        state.remarks.append(
            f"{parent_id}: у узла несколько веток, а тип ветвления не назван — укажи branching "
            "(mandatory_parallel / alternative / optional / sequence): для обязательных "
            "параллельных веток результат родителя требует всех"
        )
    ids: list[str] = []
    for child in new_children:
        is_gate = child in gate_children
        cid = state.new_id("bbb" if is_gate else ctype)
        state.nodes[cid] = _Node(
            id=cid, name=_clean(child.get("name")),
            basis=_clean(child.get("basis")), parents=[parent_id],
            before_fork=is_gate,
        )
        parent.children.append(cid)
        ids.append(cid)
    for ref in shared:
        state.nodes[ref].parents.append(parent_id)
        parent.children.append(ref)
    # Обход в глубину: первый новый ребёнок заполняется следующим, остальные ждут.
    state.queue[0:0] = ids
    state.awaiting_children_of = None
    state.span.add_event("children_declared", node=parent_id, count=total)

    parts = [f"{cid} «{state.nodes[cid].name}»" + (" (до развилки)" if state.nodes[cid].before_fork else "")
             for cid in ids]
    parts += [f"{ref} «{state.nodes[ref].name}» (общий, уже заполнен)" for ref in shared]
    reply = [f"{parent_id}: объявлено {total} — " + ", ".join(parts) + "."]
    if ptype == "process" and total < MIN_BBB_PER_PROCESS:
        reply.append("Замечание: " + state.remarks[-1])
    elif not branching and ptype != "journey" and total > 1:
        reply.append("Замечание: " + state.remarks[-1])
    reply.append(_advance(state))
    return "\n".join(reply)


def _handle_link_nodes(state: _PassportSession, args: dict) -> str:
    if state.awaiting_children_of or state.current:
        return (f"link_nodes отклонён: сначала {_expected_text(state)}; связи объявляй "
                "между уже объявленными узлами, лучше после дерева.")
    rel = {
        "from": str(args.get("from") or "").strip(),
        "to": str(args.get("to") or "").strip(),
        "kind": str(args.get("kind") or "").strip(),
        "basis": _clean(args.get("basis")),
        "field": _clean(args.get("field")),
    }
    check = PassportCheck()
    check_relation(check, rel, set(state.nodes), state.relation_keys(), state.relation_context())
    if rel["kind"] == "includes" and rel["to"] in state.nodes and rel["from"] in state.nodes[rel["to"]].parents:
        check.errors.append(f"связь {rel['from']} → {rel['to']}: {rel['from']} уже родитель {rel['to']} — дерево связью не дублируй")
    if check.errors:
        state.span.add_event("relation_rejected", count=len(check.errors))
        return "связь отклонена:\n" + "\n".join(f"- {e}" for e in check.errors[:6])
    state.relations.append(rel)
    if rel["kind"] == "includes":
        state.nodes[rel["to"]].parents.append(rel["from"])
        state.nodes[rel["from"]].children.append(rel["to"])
    state.remarks.extend(check.remarks)
    state.span.add_event("relation_accepted", kind=rel["kind"])
    reply = [f"связь принята: {rel['from']} {RELATION_LABEL[rel['kind']]} {rel['to']}."]
    reply.extend(f"Замечание: {r}" for r in check.remarks[:3])
    if state.tree_done:
        reply.append(_after_tree_text(state))
    else:
        reply.append(_advance(state))
    return "\n".join(reply)


def _handle_bind_scenario_step(state: _PassportSession, args: dict) -> str:
    if state.awaiting_children_of or state.current:
        return f"bind_scenario_step отклонён: сначала {_expected_text(state)}."
    sid = str(args.get("scenario") or "").strip()
    try:
        step = int(args.get("step"))
    except (TypeError, ValueError):
        return "bind_scenario_step отклонён: step должен быть числом."
    problem = _scenario_step_problem(state, sid, step)
    if problem:
        return f"bind_scenario_step отклонён: {problem}."
    raw = args.get("nodes")
    if isinstance(raw, str):
        raw = [raw]
    ids = [str(x).strip() for x in (raw or []) if str(x).strip()]
    errors: list[str] = []
    accepted: list[str] = []
    for nid in ids:
        node = state.nodes.get(nid)
        if node is None:
            errors.append(f"узла {nid} нет")
        elif node_type(nid) not in SCENARIO_NODE_TYPES:
            errors.append(f"{nid}: шаги сценариев выполняют BBB и операции, а не {TYPE_LABEL[node_type(nid)].lower()}")
        else:
            accepted.append(nid)
    if not accepted:
        return "bind_scenario_step отклонён:\n" + "\n".join(f"- {e}" for e in (errors or ["nodes пуст"]))
    for nid in accepted:
        node = state.nodes[nid]
        steps = list(node.data.get("scenario_steps") or [])
        entry = {"scenario": sid, "step": step}
        if entry not in steps:
            steps.append(entry)
        node.data["scenario_steps"] = steps
    reply = [f"{sid} шаг {step} «{state.scenarios[sid][step]}» — привязан к " + ", ".join(accepted) + "."]
    if errors:
        reply.append("Отброшено: " + "; ".join(errors))
    reply.append(_after_tree_text(state) if state.tree_done else _advance(state))
    return "\n".join(reply)


def _handle_submit_defect(state: _PassportSession, args: dict) -> str:
    if state.awaiting_children_of or state.current:
        return f"submit_defect отклонён: сначала {_expected_text(state)}; дефекты — после дерева."
    if len(state.defects) >= MAX_DEFECTS:
        return f"submit_defect отклонён: реестр дефектов полон ({MAX_DEFECTS})."
    defect = {
        "title": _clean(args.get("title")),
        "kind": str(args.get("kind") or "").strip(),
        "nodes": [str(x).strip() for x in (args.get("nodes") or []) if str(x).strip()] if isinstance(args.get("nodes"), list) else [],
        "scenarios": [str(x).strip() for x in (args.get("scenarios") or []) if str(x).strip()] if isinstance(args.get("scenarios"), list) else [],
        "where": _clean(args.get("where")),
        "blocking": bool(args.get("blocking")),
    }
    check = PassportCheck()
    check_defect(check, defect, set(state.nodes), set(state.scenarios), state.known_paths or None)
    if any(norm_name(d["title"]) == norm_name(defect["title"]) for d in state.defects):
        check.errors.append(f"дефект «{defect['title'][:30]}» уже заведён — один дефект, одна строка")
    if check.errors:
        state.span.add_event("defect_rejected", count=len(check.errors))
        return "дефект отклонён:\n" + "\n".join(f"- {e}" for e in check.errors[:6])
    state.defects.append(defect)
    state.remarks.extend(check.remarks)
    state.span.add_event("defect_accepted", kind=defect["kind"])
    reply = [f"дефект принят ({len(state.defects)}): {defect['title'][:80]}."]
    reply.extend(f"Замечание: {r}" for r in check.remarks[:2])
    reply.append(_after_tree_text(state) if state.tree_done else _advance(state))
    return "\n".join(reply)


def _handle_submit_need(state: _PassportSession, args: dict) -> str:
    if state.awaiting_children_of or state.current:
        return f"submit_need отклонён: сначала {_expected_text(state)}."
    if len(state.needs) >= MAX_NEEDS:
        return f"submit_need отклонён: потребностей уже {MAX_NEEDS}."
    need = {"name": _clean(args.get("name")), "purpose": _clean(args.get("purpose")), "source": _clean(args.get("source"))}
    check = PassportCheck()
    check_need(check, need)
    if any(norm_name(n["name"]) == norm_name(need["name"]) for n in state.needs):
        check.errors.append(f"потребность «{need['name'][:30]}» уже сформулирована")
    if check.errors:
        return "потребность отклонена:\n" + "\n".join(f"- {e}" for e in check.errors[:6])
    state.needs.append(need)
    state.span.add_event("need_accepted")
    return f"потребность принята ({len(state.needs)}): {need['name']}.\n" + (_after_tree_text(state) if state.tree_done else _advance(state))


def _handle_submit_guardrail(state: _PassportSession, args: dict) -> str:
    if state.awaiting_children_of or state.current:
        return f"submit_guardrail отклонён: сначала {_expected_text(state)}."
    if len(state.guardrails) >= MAX_GUARDRAILS:
        return f"submit_guardrail отклонён: ограничений уже {MAX_GUARDRAILS}."
    raw_targets = args.get("targets")
    guardrail = {
        "id": f"guardrail-{len(state.guardrails) + 1}",
        "name": _clean(args.get("name")), "invariant": _clean(args.get("invariant")),
        "condition": _clean(args.get("condition")), "effect": str(args.get("effect") or "").strip().upper(),
        "targets": [str(x).strip() for x in raw_targets if str(x).strip()] if isinstance(raw_targets, list) else [str(raw_targets or "").strip()],
        "source": _clean(args.get("source")),
    }
    check = PassportCheck()
    check_guardrail(check, guardrail, set(state.nodes))
    if any(norm_name(g["name"]) == norm_name(guardrail["name"]) for g in state.guardrails):
        check.errors.append(f"ограничение «{guardrail['name'][:30]}» уже сформулировано")
    if check.errors:
        return "ограничение отклонено:\n" + "\n".join(f"- {e}" for e in check.errors[:6])
    state.guardrails.append(guardrail)
    state.span.add_event("guardrail_accepted", effect=guardrail["effect"])
    return f"ограничение {guardrail['id']} принято ({len(state.guardrails)}): {guardrail['name']}.\n" + (_after_tree_text(state) if state.tree_done else _advance(state))


def _handle_submit_risks(state: _PassportSession, args: dict) -> str:
    if state.awaiting_children_of or state.current or not state.tree_done:
        return f"submit_risks отклонён: сначала {_expected_text(state)}; риски финализируются после дерева."
    raw = args.get("risks")
    if not isinstance(raw, list):
        return "submit_risks отклонён: risks должен быть массивом; передай [] после выполненного анализа, если обоснованных рисков нет."
    if len(raw) > MAX_RISKS:
        return f"submit_risks отклонён: рисков больше лимита {MAX_RISKS}; дедуплицируй одинаковые события и последствия."

    candidates: list[dict[str, Any]] = []
    errors: list[str] = []
    remarks: list[str] = []
    seen: dict[str, int] = {}
    seen_titles: set[str] = set()
    known_guardrails = {str(g.get("id") or "") for g in state.guardrails}
    for index, item in enumerate(raw, 1):
        if not isinstance(item, dict):
            errors.append(f"риск {index}: ожидается объект")
            continue
        controls = []
        for control in item.get("existing_controls") or []:
            if isinstance(control, dict):
                controls.append({"description": _clean(control.get("description")),
                                 "basis": _clean(control.get("basis"))})
            else:
                controls.append(control)
        evidence = []
        for ev in item.get("evidence") or []:
            if isinstance(ev, dict):
                evidence.append({"where": _clean(ev.get("where")), "basis": _clean(ev.get("basis"))})
            else:
                evidence.append(ev)
        risk = {
            "title": _clean(item.get("title")),
            "problem": _clean(item.get("problem")),
            "scope": str(item.get("scope") or "").strip(),
            "cause": _clean(item.get("cause")),
            "negative_event": _clean(item.get("negative_event")),
            "consequences": [_clean(x) for x in item.get("consequences") or [] if _clean(x)]
                            if isinstance(item.get("consequences"), list) else [],
            "primary_node": str(item.get("primary_node") or "").strip(),
            "linked_nodes": [str(x).strip() for x in item.get("linked_nodes") or [] if str(x).strip()]
                            if isinstance(item.get("linked_nodes"), list) else [],
            "existing_controls": controls,
            "control_gap": _clean(item.get("control_gap")),
            "guardrails": [str(x).strip() for x in item.get("guardrails") or [] if str(x).strip()]
                          if isinstance(item.get("guardrails"), list) else [],
            "evidence": evidence,
            "confidence": str(item.get("confidence") or "").strip(),
            "confidence_note": _clean(item.get("confidence_note")),
            "confirmation_needed": _clean(item.get("confirmation_needed")),
        }
        check = PassportCheck()
        for key in ("trigger", "mechanism", "recommendation", "closure_criterion"):
            risk[key] = _clean(item.get(key))
            if len(risk[key]) < 20:
                check.errors.append(f"{key}: нужно конкретное объяснение, не короче 20 символов")
        check_risk(check, risk, set(state.nodes), known_guardrails, state.known_paths, strict=True)
        signature = norm_name(risk["negative_event"]) + "|" + risk["primary_node"]
        if signature and signature in seen:
            check.errors.append(
                f"дублирует риск {seen[signature]} — объедини причины, последствия, узлы и основания без потери"
            )
        if norm_name(risk["title"]) in seen_titles:
            check.errors.append("название риска повторяется — объедини дубликаты или уточни разные события")
        if check.errors:
            errors.extend(f"риск {index}: {message}" for message in check.errors[:8])
        else:
            seen[signature] = index
            seen_titles.add(norm_name(risk["title"]))
            candidates.append(risk)
            remarks.extend(check.remarks)
    review = args.get("review")
    errors.extend(validate_review(review, {n.id for n in state.of_type("process")}, candidates, state.known_paths))
    if errors:
        state.span.add_event("risks_rejected", count=len(errors))
        return "submit_risks отклонён:\n" + "\n".join(f"- {e}" for e in errors[:16])

    state.risks = candidates
    state.risk_review = review
    state.risk_reviewed = True
    state.remarks.extend(remarks)
    state.span.add_event("risks_accepted", count=len(candidates))
    reply = [f"анализ операционных рисков принят: {len(candidates)}."]
    reply.extend(f"Замечание: {r}" for r in remarks[:3])
    reply.append(_after_tree_text(state))
    return "\n".join(reply)


def _handle_finish(state: _PassportSession, args: dict) -> str:
    missing = _unfinished(state)
    if missing:
        return "finish отклонён: " + "; ".join(missing) + ". " + _expected_text(state)
    if not state.risk_reviewed:
        return (
            "finish отклонён: операционные риски не проанализированы. После локальной проверки "
            "BBB/операций и сквозной проверки стыков вызови submit_risks(risks=[…]); если "
            "полных причинных цепочек нет — submit_risks(risks=[])."
        )
    scenario_issues = _process_scenario_issues(state)
    if scenario_issues:
        state.attempts["process_scenarios"] = state.attempts.get("process_scenarios", 0) + 1
        if state.attempts["process_scenarios"] <= MAX_FINISH_REJECTIONS:
            return (
                "finish отклонён: process должен совпадать с целевым сценарием один к одному — "
                + "; ".join(scenario_issues)
                + ". Исправь process повторным submit_node(id, scenario=\"scenario-N\")."
            )
        state.remarks.append("несовпадение процессов и сценариев: " + "; ".join(scenario_issues))
    unbound = state.unbound_steps()
    if unbound:
        state.attempts["finish"] = state.attempts.get("finish", 0) + 1
        if state.attempts["finish"] <= MAX_FINISH_REJECTIONS:
            return ("finish отклонён: шаги сценариев без узла — "
                    + _unbound_text(unbound)
                    + ". Привяжи их bind_scenario_step(scenario, step, nodes) к BBB или операции, "
                    "которые их выполняют; если шаг лежит вне схемы паспорта — вызови finish ещё раз, "
                    "и он останется в замечаниях.")
        state.remarks.append("шаги сценариев без узла на схеме: " + _unbound_text(unbound))
    state.finished = True
    return "паспорт завершён"


def _unbound_text(unbound: list[tuple[str, int, str]]) -> str:
    return "; ".join(f"{sid} шаг {index} «{text[:60]}»" for sid, index, text in unbound[:8]) + (
        f" … и ещё {len(unbound) - 8}" if len(unbound) > 8 else "")


def _process_scenario_issues(state: _PassportSession) -> list[str]:
    """Один process — один сценарий, и каждый сценарий представлен один раз."""
    if not state.scenarios:
        return []
    by_scenario: dict[str, list[str]] = {sid: [] for sid in state.scenarios}
    unmapped: list[str] = []
    for node in state.of_type("process"):
        sid = str(node.data.get("scenario") or "").strip()
        if sid in by_scenario:
            by_scenario[sid].append(node.id)
        else:
            unmapped.append(node.id)
    issues: list[str] = []
    if unmapped:
        issues.append("без scenario: " + ", ".join(unmapped))
    missing = [sid for sid, nodes in by_scenario.items() if not nodes]
    if missing:
        issues.append("без process: " + ", ".join(missing))
    duplicate = [f"{sid} → {', '.join(nodes)}" for sid, nodes in by_scenario.items() if len(nodes) > 1]
    if duplicate:
        issues.append("дубли: " + "; ".join(duplicate))
    return issues


def _clean(value: Any) -> str:
    """Текст от модели в паспорт — через ту же чистку иероглифов, что и у
    трёх других проходов: GLM-5.2 вставляет CJK-символы в русский текст."""
    return _strip_cjk(str(value or "")).strip()


def _clean_fields(fields: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for fid, cell in fields.items():
        if isinstance(cell, dict):
            out[fid] = {**cell, "value": _clean(cell.get("value")),
                        "source": _clean(cell.get("source"))}
        else:
            out[fid] = cell
    return out


_HANDLERS: dict[str, Callable[[_PassportSession, dict], str]] = {
    "submit_node": _handle_submit_node,
    "declare_children": _handle_declare_children,
    "link_nodes": _handle_link_nodes,
    "bind_scenario_step": _handle_bind_scenario_step,
    "submit_defect": _handle_submit_defect,
    "submit_need": _handle_submit_need,
    "submit_guardrail": _handle_submit_guardrail,
    "submit_risks": _handle_submit_risks,
    "finish": _handle_finish,
}
_TOOL_NAMES = ", ".join(_HANDLERS)


def _unfinished(state: _PassportSession) -> list[str]:
    out: list[str] = []
    if state.awaiting_children_of:
        out.append(f"не объявлены дети {state.awaiting_children_of}")
    if state.current:
        out.append(f"не заполнен {state.current}")
    if state.queue:
        out.append(f"в очереди {len(state.queue)} узлов: " + ", ".join(state.queue[:5]))
    return out


def _advance(state: _PassportSession) -> str:
    """Следующий шаг протокола: очередной узел дерева или переход к связям."""
    if state.queue:
        nid = state.queue.pop(0)
        state.current = nid
        node = state.nodes[nid]
        parent = state.nodes[node.parent] if node.parent else None
        lines = [_tree_map(state), f"Заполни {nid} «{node.name}» ({TYPE_LABEL[node_type(nid)]}) — basis: {node.basis}."]
        if parent is not None:
            lines.append(f"Родитель {parent.id} «{parent.name}»: {_node_digest(parent)}")
        siblings = [state.nodes[c] for c in (parent.children if parent else []) if c != nid]
        if siblings:
            lines.append("Соседи: " + "; ".join(f"{s.id} «{s.name}»" for s in siblings))
        if node_type(nid) == "process" and state.scenarios:
            available = [
                f"{sid} «{state.scenario_titles.get(sid, sid)}»"
                for sid in state.scenarios
                if not any(
                    other.id != nid and other.data.get("scenario") == sid
                    for other in state.of_type("process")
                )
            ]
            lines.append(
                "Process равен одному целевому сценарию. Передай scenario; доступны: "
                + ", ".join(available)
            )
        lines.append(f"Вызови submit_node(id=\"{nid}\") с полями раздела.")
        return "\n".join(lines)
    if not state.tree_done:
        state.tree_done = True
        return "\n".join([_tree_map(state), "Дерево построено.", _after_tree_text(state)])
    return _after_tree_text(state)


def _after_tree_text(state: _PassportSession) -> str:
    """Что делать после дерева: связи, привязка шагов сценариев, finish."""
    lines = [
        "Дальше: связи поверх дерева — link_nodes(from, to, kind, basis), виды: "
        + ", ".join(f"{k} ({RELATION_LABEL[k]})" for k in RELATION_KINDS)
        + "; общий BBB или операция, входящие в несколько процессов/блоков — kind=includes."
    ]
    unbound = state.unbound_steps()
    if unbound:
        lines.append(
            "Шаги сценариев без узла: " + _unbound_text(unbound)
            + ". Привяжи bind_scenario_step(scenario, step, nodes=[bbb-N | operation-N])."
        )
    elif state.scenarios:
        lines.append("Все шаги целевых сценариев привязаны к узлам.")
    scenario_issues = _process_scenario_issues(state)
    if scenario_issues:
        lines.append(
            "Процессы должны совпадать со сценариями один к одному: "
            + "; ".join(scenario_issues)
            + ". Исправь process повторным submit_node(id, scenario=\"scenario-N\")."
        )
    gaps = _input_contract_gaps(state)
    if gaps:
        lines.append("Контракт входа ссылается на узел вне процесса: " + "; ".join(gaps[:6])
                     + ". Если узел выполняется внутри процесса — link_nodes(kind=includes) от процесса; "
                     "если только передаёт данные — kind=feeds.")
    lines.append(
        "Дефекты — submit_defect(title, kind, nodes, scenarios, where, blocking): один дефект — один вызов "
        "(отключённый расчёт, нет компенсации при частичном исполнении, повторное нажатие, две реализации, "
        "деградация на запасном пути). Разрывы стыков и обещания без реализации код добавит сам."
        + (f" Заведено дефектов: {len(state.defects)}." if state.defects else "")
    )
    lines.append(
        "Потребность клиента — submit_need(name, purpose, source); ограничения исполнения — "
        "submit_guardrail(name, invariant, condition, effect, targets, source)."
        + (f" Потребностей: {len(state.needs)}, ограничений: {len(state.guardrails)}." if state.needs or state.guardrails else " Пока ни одной.")
    )
    lines.append(
        "Операционные риски финализируй одним submit_risks(risks=[…], review=[…]) после guardrails: "
        "по каждому процессу обязателен чек-лист input/decision/execution/persistence/dependencies/detection/recovery, "
        "даже при пустом наборе рисков. Сначала "
        "локально проверь BBB и операции, затем стыки всей цепочки; каждый риск — причина → "
        "негативное событие → бизнес-последствие. Риск не равен дефекту или отсутствию контроля и "
        "не меняет статус узла. "
        + (f"Анализ принят, рисков: {len(state.risks)}." if state.risk_reviewed else "Анализ ещё не отправлен.")
    )
    if not state.risk_reviewed:
        lines.append(_risk_exposure_digest(state))
        try:
            lines.append(_RISK_GUIDE_PATH.read_text(encoding="utf-8").strip())
        except OSError:
            state.notes.append("Памятка гипотез операционного риска не найдена: risk_hypothesis_guide.md")
    lines.append("Исправить принятый узел можно повторным submit_node(id). Когда всё — finish.")
    return "\n".join(lines)


_RISK_FOCUS_FIELDS = {
    "process": ("4.3.4", "4.3.6", "4.3.7"),
    "bbb": ("4.4.2", "4.4.4", "4.4.5"),
    "operation": ("4.5.4", "4.5.5", "4.5.6"),
}


def _risk_exposure_digest(state: _PassportSession, limit: int = 7000) -> str:
    """Напомнить модели принятые узлы и факты об экспозиции после сборки дерева.

    Это навигация по заполненному паспорту, не источник доказательств сам по
    себе: в evidence всё равно требуется исходный прочитанный материал.
    """
    lines = [
        "Опорные факты для поиска рисков (утверждения узлов, не доказательства риска; "
        "сверяй каждую гипотезу с исходным прочитанным источником):"
    ]
    used = len(lines[0])
    omitted = 0
    for node in state.nodes.values():
        ntype = node_type(node.id)
        if ntype == "journey":
            continue
        fields = node.data.get("fields") or {}
        parts = [f"{node.id} «{node.name[:90]}»"]
        if node.planned:
            parts.append("планируется; не считай отсутствие реализации действующим отказом")
        if ntype == "process":
            parts.append(f"сценарий {node.data.get('scenario') or 'не привязан'}")
        else:
            parts.append("родители: " + ", ".join(node.parents))
        first_source = ""
        for fid in _RISK_FOCUS_FIELDS.get(ntype, ()):
            field_data = fields.get(fid) or {}
            value = str(field_data.get("value") or "").strip()
            if value:
                parts.append(f"{fid}: {value[:110]}")
                source = str(field_data.get("source") or "").strip()
                if source and not first_source:
                    first_source = source[:140]
        if first_source:
            parts.append("источник поля: " + first_source)
        if node.data.get("scenario_steps"):
            parts.append("шаги: " + str(node.data["scenario_steps"])[:90])
        line = "; ".join(parts)
        if used + len(line) + 1 > limit:
            omitted += 1
            continue
        lines.append(line)
        used += len(line) + 1
    if omitted:
        lines.append(f"Ещё {omitted} узлов не вошли в краткую сводку; используй карту дерева выше.")
    if state.relations:
        relations = "; ".join(
            f"{r['from']} {r['kind']} {r['to']}" for r in state.relations
        )
        lines.append("Принятые связи: " + relations[:1200])
    return "\n".join(lines)


def _input_contract_gaps(state: _PassportSession) -> list[str]:
    """Узел X упомянут в контракте входа узла Y, но не входит ни в один
    процесс Y и не связан с ним: реестр расходится с карточкой."""
    fed: set[tuple[str, str]] = {(r["from"], r["to"]) for r in state.relations if r["kind"] in ("feeds", "precedes", "triggers", "depends_on")}
    out: list[str] = []
    for nid, node in state.nodes.items():
        if not node.filled:
            continue
        fid = _INPUT_CONTRACT_FIELDS.get(node_type(nid))
        if not fid:
            continue
        cell = (node.data.get("fields") or {}).get(fid) or {}
        text = " ".join(str(cell.get(k) or "") for k in ("value", "source"))
        y_processes = state.processes_of(nid)
        for ref in dict.fromkeys(_NODE_REF_RE.findall(text)):
            other = state.nodes.get(ref)
            if other is None or ref == nid or other.before_fork:
                continue
            if (ref, nid) in fed or (nid, ref) in fed:
                continue
            if state.processes_of(ref) & y_processes:
                continue
            out.append(f"{ref} упомянут в контракте входа {nid}, но не входит в "
                       + ", ".join(sorted(y_processes)) if y_processes else f"{ref} упомянут в контракте входа {nid}")
    return out


def _expected_submit(state: _PassportSession) -> set[str]:
    if state.awaiting_children_of:
        return set()
    if state.current:
        return {state.current}
    if not state.tree_done:
        return set()
    # После дерева — повторная отправка уже принятого узла (исправление по замечанию).
    return {n.id for n in state.nodes.values() if n.filled}


def _expected_text(state: _PassportSession) -> str:
    if state.awaiting_children_of:
        return f"declare_children(parent=\"{state.awaiting_children_of}\")"
    if state.current:
        return f"submit_node(id=\"{state.current}\")"
    if state.tree_done:
        return "link_nodes, bind_scenario_step, submit_risks, повторный submit_node принятого узла или finish"
    return "ничего: дерево не начато"


def _check_name_unique(check: PassportCheck, state: _PassportSession, nid: str, name: str) -> None:
    key = norm_name(name)
    if not key:
        return
    for other in state.nodes.values():
        if other.id != nid and norm_name(other.name) == key:
            check.errors.append(duplicate_name_message(nid, other.id, name))
            return


def _children_hint(ptype: str) -> str:
    return {
        "journey": "по одному на сценарий с собственными условиями запуска и завершением; "
                   "узел, который выбирает или разрешает процесс (определение сценария, проверка прав), "
                   "— BBB с before_fork: true, перед процессами",
        "process": "одно бизнес-действие с одним ответом «что получили»; 3–6 на процесс, "
                   "включая определение сценария, получение данных, подбор, предложение, "
                   "объяснение, подтверждение, исполнение; общий с другим процессом блок — {ref: id}",
        "bbb": "шаг с наблюдаемым снаружи результатом, который может отказать отдельно; "
               "1–3 на BBB, обычно по способам исполнения; общая с другим блоком операция — {ref: id}",
    }[ptype]


def _node_digest(node: _Node, limit: int = 220) -> str:
    fields = node.data.get("fields") or {}
    parts = []
    for fid in sorted(fields):
        value = str((fields.get(fid) or {}).get("value") or "").strip()
        if value:
            parts.append(f"{fid}: {value[:limit]}")
        if len(parts) >= 3:
            break
    return " · ".join(parts) or "поля не заполнены"


def _tree_map(state: _PassportSession) -> str:
    """Карта построенного: id · название — basis, с отступами по уровням.
    Общий узел показан под каждым родителем, но раскрыт только под первым."""
    lines = ["Построено:"]

    def visit(nid: str, depth: int, via: str | None) -> None:
        node = state.nodes[nid]
        mark = "✓" if node.filled else "…"
        shared = via is not None and node.parent != via
        extra = ""
        if len(node.parents) > 1:
            extra = " (также в " + ", ".join(p for p in node.parents if p != via) + ")"
        if node.before_fork:
            extra += " (до развилки)"
        if node.planned:
            extra += " (планируется)"
        lines.append(f"{'  ' * depth}{mark} {nid} «{node.name}» — {node.basis[:100]}{extra}")
        if shared:
            return
        for cid in node.children:
            visit(cid, depth + 1, nid)

    for root in state.of_type("journey"):
        visit(root.id, 0, None)
    business = [f"{r['from']} {RELATION_LABEL[r['kind']]} {r['to']}"
                for r in state.relations if r["kind"] != "includes"]
    if business:
        lines.append("Связи: " + "; ".join(business))
    return "\n".join(lines)


# --- сборка результата --------------------------------------------------------------

def _build_passport_data(state: _PassportSession, scope: str, date: str, commit: str = "") -> dict[str, Any]:
    def rebuild(nid: str) -> dict[str, Any]:
        node = state.nodes[nid]
        out: dict[str, Any] = {"id": nid, "type": node_type(nid)}
        if node.children or node_type(nid) != "operation":
            # Под второстепенным родителем общий узел в дереве не повторяется:
            # его место — под первым; остальные связи живут в `parents`.
            out["children"] = [rebuild(c) for c in node.children if state.nodes[c].parent == nid]
        return out

    # Версия объекта — состояние кода, по которому выставлены статусы: один
    # текст на все узлы, без «Не установлена» рядом с «Не установлено по…».
    version = f"коммит {commit[:8]}" if commit else "Не установлено: источник без git-истории (архив)"
    nodes: dict[str, Any] = {}
    for nid, node in state.nodes.items():
        entry: dict[str, Any] = {"name": node.name, "basis": node.basis, "fields": {},
                                 "parents": list(node.parents), "before_fork": node.before_fork,
                                 "planned": node.planned, "object-version": version}
        if node.filled:
            entry.update({k: v for k, v in node.data.items() if k not in ("name", "basis")})
        else:
            entry["object-version"] = "Не заполнено: сессия прервана до этого узла"
        nodes[nid] = entry
    data = {
        "analysis-scope": scope,
        "decision-boundary": state.decision_boundary,
        "analysis-date": date,
        "tree": [rebuild(n.id) for n in state.of_type("journey")],
        "nodes": nodes,
        "relations": [dict(r) for r in state.relations],
        "defects": [dict(d) for d in state.defects],
        "needs": [dict(n) for n in state.needs],
        "guardrails": [dict(g) for g in state.guardrails],
        "risks": [dict(r) for r in state.risks],
        "risk_review": {"complete": state.risk_reviewed, "processes": state.risk_review},
    }
    return normalize_passport(data)


@dataclass
class PassportAgentResult:
    passport_data: dict[str, Any] | None = None
    notes: list[str] = field(default_factory=list)
    steps: int = 0


# --- вход: сжатые знания сессии оценки -------------------------------------------------

def render_evaluation_digest(
    plan_items: list[PlanItem],
    verdicts: list[ItemVerdict],
    summary: ProjectSummary | None,
    knowledge: list[str],
) -> str:
    """Что узнала сессия оценки — единственный источник фактов для паспорта."""
    by_id = {v.item_id: v for v in verdicts}
    lines: list[str] = []
    if summary is not None:
        lines.append(f"Верхнеуровневая оценка: {summary.match} — {summary.match_note}")
    lines.append("Оценка этапов образа результата (статус · проверка · как работает · ссылки):")
    for item in plan_items:
        lines.append(f"## {item.title}")
        verdict = by_id.get(item.id)
        for idx, text in enumerate(item.criteria):
            crit = verdict.criteria[idx] if verdict and idx < len(verdict.criteria) else None
            if crit is None:
                lines.append(f"- {text} — не оценено")
                continue
            lines.append(f"- {text} — {crit.status}")
            if crit.proof:
                lines.append(f"  проверка: {crit.proof[:_MAX_PROOF_CHARS]}")
            if crit.how:
                lines.append(f"  как работает: {crit.how[:_MAX_PROOF_CHARS]}")
            for ev in crit.evidence:
                if getattr(ev, "verified", False):
                    lines.append(f"  · {ev.path}:{ev.line} — {ev.basis}" + (f" — {ev.note}" if getattr(ev, 'note', '') else ""))
    if knowledge:
        lines.append("")
        lines.append("Что сессия оценки читала в коде (сжатый след):")
        total = 0
        for entry in knowledge:
            total += len(entry) + 1
            if total > _MAX_KNOWLEDGE_CHARS:
                lines.append("… (след обрезан)")
                break
            lines.append(entry)
    return "\n".join(lines)


def render_scenarios_digest(connectivity: ConnectivityReview | None) -> str:
    """Целевые сценарии ревизии — для привязки узлов (`scenario_steps`)."""
    if connectivity is None or not connectivity.scenarios:
        return ""
    lines = ["Целевые сценарии (для scenario_steps: id сценария и номер шага с нуля; "
             "каждый шаг обязан получить узел bbb/operation, иначе finish попросит привязать):"]
    for scenario in connectivity.scenarios:
        status = scenario.status
        lines.append(f"{scenario.id} «{scenario.title}» — {status}"
                     + (", критический" if scenario.critical else ""))
        for index, step in enumerate(scenario.steps):
            handoff = scenario.handoff_at(index)
            mark = ""
            if handoff is not None and index < scenario.transitions:
                mark = f" → стык после шага: {handoff.result}"
            lines.append(f"  {index}: {step}{mark}")
    return "\n".join(lines)


def run_passport_agent(
    plan_items: list[PlanItem],
    context: dict[str, str],
    verdicts: list[ItemVerdict],
    summary: ProjectSummary | None,
    spec: ModelSpec | None,
    client: ChatClient | None = None,
    capability_digest: str = "",
    knowledge: list[str] | None = None,
    source_text: str | None = None,
    repo_name: str = "",
    commit: str = "",
    max_steps: int | None = None,
    on_node: Callable[[str, str], None] | None = None,
    connectivity: ConnectivityReview | None = None,
) -> PassportAgentResult:
    """Собрать паспорт клиентского пути отдельной сессией по знаниям оценки.

    `connectivity` — целевые сценарии ревизии: узлы привязываются к их шагам,
    и схема паспорта показывает путь сценария и разрывы на стыках.
    """
    if spec is None:
        return PassportAgentResult(notes=["Паспорт: matcher не настроен"])
    if max_steps is None:
        max_steps = int(_env_number("PKO_PASSPORT_MAX_STEPS", DEFAULT_PASSPORT_MAX_STEPS))

    # Название пути — строго из образа результата; имя проекта и репозитория
    # только когда в тексте инициативы названия нет.
    journey_name = journey_name_of(context, repo_name)
    state = _PassportSession(
        on_node=on_node,
        initiative_name=(context.get("project_name") or "").strip(),
        plan_bullets=[str(text) for item in plan_items for text in item.criteria],
        bullet_status=_bullet_statuses(plan_items, verdicts),
        scenarios={s.id: list(s.steps) for s in (connectivity.scenarios if connectivity else [])},
        scenario_titles={s.id: s.title for s in (connectivity.scenarios if connectivity else [])},
    )
    root = state.new_id("journey")
    state.nodes[root] = _Node(id=root, name=journey_name, basis="путь задан образом результата инициативы")
    state.queue.append(root)
    state.known_paths = _known_paths(verdicts, knowledge or [])

    brief = [
        f"Рабочая подсказка для клиентского пути: {journey_name}. Название инициативы: "
        f"{context.get('project_name') or '—'}. Не повторяй название инициативы: "
        "сформулируй общий результат для клиента, охватывающий все процессы; "
        "не называй отдельный продукт, канал, способ подбора или шаг.",
        f"Было: {context.get('before') or '—'}. Стало: {context.get('after') or '—'}.",
    ]
    if source_text and source_text.strip():
        brief.append("Дословный текст инициативы:\n" + source_text.strip()[:4000])
    if capability_digest:
        brief.append(capability_digest)
    brief.append(render_evaluation_digest(plan_items, verdicts, summary, knowledge or []))
    scenarios_digest = render_scenarios_digest(connectivity)
    if scenarios_digest:
        brief.append(scenarios_digest)
    brief.append("")
    brief.append(_advance(state))
    user_brief = "\n\n".join(brief)

    try:
        system_prompt = _PROMPT_PATH.read_text(encoding="utf-8")
    except OSError:
        system_prompt = "Ты заполняешь паспорт клиентского пути по знаниям сессии оценки."
        state.notes.append("Промпт паспортного агента не найден: passport_system.md")

    chat_client = client if client is not None else ChatClient(spec=spec)
    thinking_on = bool(
        spec.extra_body
        and spec.extra_body.get("chat_template_kwargs", {}).get("enable_thinking") is True
    )
    # Потолок ответа — тот же выбор, что у трёх других проходов: в режиме
    # рассуждения в него входит `reasoning_content`, и тесный бюджет даёт
    # пустой `content`.
    max_tokens = max_tokens_for(thinking_on)
    schemas = [_SUBMIT_NODE_SCHEMA, _DECLARE_CHILDREN_SCHEMA, _LINK_NODES_SCHEMA,
               _BIND_SCENARIO_STEP_SCHEMA, _SUBMIT_DEFECT_SCHEMA, _SUBMIT_NEED_SCHEMA,
               _SUBMIT_GUARDRAIL_SCHEMA, _SUBMIT_RISKS_SCHEMA, _FINISH_SCHEMA]
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_brief},
    ]
    budget_seconds = _env_number("PKO_PASSPORT_MAX_SECONDS", DEFAULT_PASSPORT_SECONDS)
    deadline = time.monotonic() + budget_seconds if budget_seconds else 0.0
    malformed = 0
    steps_done = 0

    with trace_span("passport_session") as session_handle:
        state.span = session_handle
        session_handle.set_attribute("max_steps", max_steps)
        for step in range(1, max(1, max_steps) + 1):
            steps_done = step
            if deadline and time.monotonic() > deadline:
                state.notes.append(f"паспорт: время сессии исчерпано ({int(budget_seconds)} с) на шаге {step}")
                break
            with trace_span("passport.step", step=step) as step_span:
                try:
                    result = chat_client.chat(messages, tools=schemas, max_tokens=max_tokens)
                except LlmError as exc:
                    step_span.set_attribute("error", exc.message)
                    state.notes.append(f"паспорт: агент недоступен на шаге {step}: {exc.message} {exc.hint}".strip())
                    break
            if not result.tool_calls:
                malformed += 1
                if malformed >= _MAX_MALFORMED:
                    state.notes.append(f"паспорт: агент не вызвал инструмент {malformed} раз подряд — остановлено")
                    break
                messages.append({"role": "assistant", "content": result.text})
                messages.append({"role": "user", "content": "Нужно вызвать инструмент: " + _expected_text(state)})
                continue
            malformed = 0
            messages.append({
                "role": "assistant", "content": result.text or None,
                "tool_calls": result.tool_calls,
                "reasoning_content": result.reasoning_content or None,
            })
            for call in result.tool_calls:
                messages.append(_answer_call(state, call))
            _compact_history(messages)
            if state.finished:
                break
        else:
            state.notes.append(f"паспорт: бюджет шагов исчерпан ({max_steps})")
        session_handle.set_attribute("steps_done", steps_done)
        session_handle.set_attribute("nodes", len(state.nodes))
        session_handle.set_attribute("relations", len(state.relations))
        session_handle.set_attribute("defects", len(state.defects))
        session_handle.set_attribute("risks", len(state.risks))
        session_handle.set_attribute("risks_reviewed", state.risk_reviewed)
        session_handle.set_attribute("finished", state.finished)

    if not state.finished:
        missing = _unfinished(state)
        if missing:
            state.notes.append("паспорт не завершён: " + "; ".join(missing))
        elif not state.risk_reviewed:
            state.notes.append("паспорт не завершён: анализ операционных рисков не отправлен (submit_risks)")
        else:
            state.notes.append("паспорт не завершён: finish не принят до остановки сессии")
        unbound = state.unbound_steps()
        if unbound and state.scenarios:
            state.remarks.append("шаги сценариев без узла на схеме: " + _unbound_text(unbound))
    unfilled = [n.id for n in state.nodes.values() if not n.filled]
    if unfilled:
        state.notes.append("паспорт: узлы объявлены, но не заполнены: " + ", ".join(unfilled[:8]))
    check = PassportCheck()
    check_router_present(check, {nid: n.data for nid, n in state.nodes.items() if n.filled})
    if state.finished and not state.needs:
        check.remarks.append("потребность клиента не сформулирована (submit_need) — на графе ряд потребностей пуст")
    state.remarks.extend(check.remarks)
    if state.remarks:
        state.notes.append("Замечания к паспорту: " + "; ".join(dict.fromkeys(state.remarks)))

    if state.plan_bullets:
        linked = {b for n in state.nodes.values() if n.filled for b in (n.data.get("bullets") or [])}
        unlinked = [b for b in state.plan_bullets if b not in linked]
        if unlinked:
            state.notes.append(
                f"паспорт: пунктов ОР без узла на схеме — {len(unlinked)} из {len(state.plan_bullets)}: "
                + "; ".join(f"«{b[:60]}»" for b in unlinked[:4])
            )
    filled_any = any(n.filled for n in state.nodes.values())
    scope = f"{repo_name} · коммит {commit[:8] if commit else '—'} · {context.get('project_name') or journey_name}"
    data = _build_passport_data(state, scope, time.strftime("%Y-%m-%d"), commit) if filled_any else None
    return PassportAgentResult(passport_data=data, notes=state.notes, steps=steps_done)


def _known_paths(verdicts: list[ItemVerdict], knowledge: list[str]) -> set[str]:
    """Пути, которые встречались в материалах оценки: ссылки вердиктов и
    след прочитанного. «Место в коде» у дефекта сверяется с ними."""
    out: set[str] = set()
    for verdict in verdicts:
        for crit in verdict.criteria:
            for ev in crit.evidence:
                if getattr(ev, "path", ""):
                    out.add(str(ev.path))
    for entry in knowledge:
        for match in _PATH_RE.findall(str(entry)):
            out.add(match)
    return out


def _bullet_statuses(plan_items: list[PlanItem], verdicts: list[ItemVerdict]) -> dict[str, str]:
    by_id = {v.item_id: v for v in verdicts}
    out: dict[str, str] = {}
    for item in plan_items:
        verdict = by_id.get(item.id)
        if verdict is None:
            continue
        for idx, text in enumerate(item.criteria):
            if idx < len(verdict.criteria) and verdict.criteria[idx].applicable:
                out[str(text)] = str(verdict.criteria[idx].status)
    return out


def _answer_call(state: _PassportSession, call: dict) -> dict[str, Any]:
    function = call.get("function") or {}
    name = str(function.get("name") or "")
    call_id = str(call.get("id") or "")
    try:
        args = json.loads(function.get("arguments") or "{}")
    except json.JSONDecodeError as exc:
        return {"role": "tool", "tool_call_id": call_id,
                "content": f"аргументы инструмента не являются валидным JSON: {exc}"}
    handler = _HANDLERS.get(name)
    if handler is None:
        content = f"инструмента «{name}» нет. Доступны: {_TOOL_NAMES}. " + _expected_text(state)
    else:
        content = handler(state, args if isinstance(args, dict) else {})
    return {"role": "tool", "tool_call_id": call_id, "content": content}


# Ответы после узлов несут карту дерева, а после дерева — памятку рисков.
# В истории нужны только последние ответы; старые ужимаются до первой строки.
_KEEP_RECENT_TOOL_REPLIES = 2


def _compact_history(messages: list[dict[str, Any]]) -> None:
    tool_idx = [i for i, m in enumerate(messages) if m.get("role") == "tool"]
    for i in tool_idx[:-_KEEP_RECENT_TOOL_REPLIES]:
        content = str(messages[i].get("content") or "")
        if ("\nПостроено:" in content or content.startswith("Построено:")
                or "\nОпорные факты для поиска рисков (" in content):
            messages[i]["content"] = content.split("\n", 1)[0]

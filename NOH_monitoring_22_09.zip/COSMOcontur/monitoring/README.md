# Мониторинг `pko progress` (CLI)

Локальный стек: Grafana + Loki + Alloy + Prometheus + экспортёр PKO. CLI
пишет один JSONL-файл на запуск в `%USERPROFILE%\.pko\monitoring`. Контейнеры
читают эти файлы; запуск `pko progress` не зависит от доступности Grafana.

## Запуск на компьютере с Podman

Нужны работающий Podman и compose provider (`podman-compose` или
`docker-compose` — `podman compose version` должен выполняться). Из корня
проекта на Windows в PowerShell:

```powershell
.\monitoring\start.ps1
pko progress --journey-file .\initiative.md --repo-path .\target-repo --out .\pko-progress-out
```

На Linux:

```bash
bash monitoring/start.sh
pko progress --journey-file initiative.md --repo-path target-repo --out pko-progress-out
```

Откройте <http://localhost:3000/d/pko-cli-monitoring>. В локальной конфигурации
логин `admin`, пароль `admin`; перед запуском можно задать
`$env:PKO_GRAFANA_PASSWORD = '...'`. Адрес слушает только `127.0.0.1`.

CLI сразу печатает `run_id`. Впишите его в поле **«Фильтр по run_id»** вверху
дашборда: нижняя панель покажет события именно этого прогона. Дашборд
обновляется каждые 5 секунд. Метрики показывают общую картину без уникальных
`run_id` в Prometheus labels.

Если ПКO запускается из другого каталога, настройка не меняется: путь
журнала по умолчанию привязан к домашнему каталогу, а не к текущей папке.
Для другого места задайте **одинаковый** `PKO_MONITOR_DIR` перед запуском
`start.ps1` и `pko progress`.

Остановить стек, сохранив историю:

```powershell
.\monitoring\stop.ps1
```

На Linux: `bash monitoring/stop.sh`.

## Что записывается

- Начало и конец прогона, длительность и итог (`success`, `error`, `interrupted`).
- Начало/конец каждого из четырёх проходов и каждого шага, их время и
  завершённость сессии.
- Время вызова модели, успех/ошибка, использование кеша и токены, если
  endpoint их сообщил.
- Счётчики отклонений паспортного гейта, наличие паспортных данных и ошибка
  рендера паспорта.

В журнал не пишутся промпты, ответы модели, код проекта, ключи и текст
исключений. Phoenix по-прежнему можно включать отдельно для подробных трейсов.

`pko_stale_runs` означает, что CLI не завершился и в течение 30 минут не было
событий. Это отдельный сигнал: один вызов LLM может занимать несколько минут.
Пустой список рисков не считается ошибкой. Loki и Prometheus хранят данные
14 дней; исходные JSONL остаются в каталоге журнала, пока их не удалит
пользователь.

Если панели пустые, проверьте `podman compose -f monitoring/compose.yaml ps`,
затем наличие `run_*.jsonl` в каталоге и статус контейнеров `alloy` и
`exporter`. Прямой тест экспортёра внутри сети compose:

```powershell
podman compose -f monitoring/compose.yaml exec exporter python -c "import urllib.request; print(urllib.request.urlopen('http://localhost:9108/metrics').read().decode()[:1000])"
```

"""CLI journal and persistent exporter: live state, final duration, no duplicate replay."""

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

from pko.monitor_exporter import EventMetrics, STALE_AFTER_SECONDS
from pko.monitoring import monitored_cli_run, observe_span, record_llm_call


class MonitoringTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.previous = os.environ.get("PKO_MONITOR_DIR")
        os.environ["PKO_MONITOR_DIR"] = self.tmp.name
        self.addCleanup(self._restore_env)

    def _restore_env(self):
        if self.previous is None:
            os.environ.pop("PKO_MONITOR_DIR", None)
        else:
            os.environ["PKO_MONITOR_DIR"] = self.previous

    def test_live_steps_and_persistent_metrics(self):
        metrics = EventMetrics(Path(self.tmp.name))
        with monitored_cli_run() as journal:
            with observe_span("agent_session", {}) as span:
                with observe_span("agent.step", {"step": 1}):
                    record_llm_call(duration_seconds=2.5, result="success",
                                    usage={"prompt_tokens": 120, "completion_tokens": 30})
                span.set_attribute("steps_done", 1)
                span.set_attribute("finished", True)
            with observe_span("passport_session", {}) as span:
                span.add_event("risks_rejected", {"count": 2, "secret": "must-not-log"})
                span.set_attribute("steps_done", 0)
                span.set_attribute("finished", False)
            live = metrics.render()
            self.assertIn("pko_active_runs 1", live)
            self.assertIn('pko_steps_total{pass="matcher"} 1', live)
            self.assertIn('pko_llm_tokens_total{pass="matcher",type="prompt"} 120', live)

        final = metrics.render()
        self.assertIn("pko_active_runs 0", final)
        self.assertIn('pko_runs_total{result="success"} 1', final)
        self.assertIn('pko_pass_results_total{pass="passport",result="incomplete"} 1', final)
        self.assertIn('pko_gate_rejections_total{pass="passport",kind="risks_rejected"} 1', final)
        self.assertIn("pko_run_duration_seconds_count 1", final)
        self.assertEqual(final, metrics.render())  # repeated scrape does not double count

        records = [json.loads(line) for line in journal.path.read_text(encoding="utf-8").splitlines()]
        self.assertEqual(records[0]["run_id"], journal.run_id)
        self.assertEqual(records[-1]["event"], "run_finished")
        self.assertTrue(all("secret" not in event for event in records))

        restarted = EventMetrics(Path(self.tmp.name))
        self.assertIn('pko_runs_total{result="success"} 1', restarted.render())

    def test_error_and_stale_run(self):
        with self.assertRaises(ValueError):
            with monitored_cli_run():
                raise ValueError("private error detail")
        metrics = EventMetrics(Path(self.tmp.name))
        self.assertIn('pko_runs_total{result="error"} 1', metrics.render())
        self.assertNotIn("private error detail", "".join(
            path.read_text(encoding="utf-8") for path in Path(self.tmp.name).glob("*.jsonl")))

        metrics.ingest({"event": "run_started", "run_id": "run_orphan", "at": 100.0})
        text = metrics.render(now=100.0 + STALE_AFTER_SECONDS + 1)
        self.assertIn("pko_stale_runs 1", text)


if __name__ == "__main__":
    unittest.main()

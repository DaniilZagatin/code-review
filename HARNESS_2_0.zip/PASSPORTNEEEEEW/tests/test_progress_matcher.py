"""Единый агент (`run_agent`): готовый клиентский путь -> оценка этапов по
материалам -> вердикт.

Транспорт подменяется: `ChatClient._create` отдаёт по одному заготовленному
ответу на каждый ход сессии. Путь/строка/якорь проверяются на настоящей
фикстуре `mini_repo`.

Главный инвариант: **тексты пути не пишет модель**. Названия этапов и
буллиты приходят из текстового поля, разбираются кодом в `PlanItem` и
передаются агенту готовыми. Модель только проверяет готовность пунктов.
"""

import json
import tempfile
import os
import time
import unittest
from types import SimpleNamespace
from pathlib import Path
from unittest import mock

from fixture_support import ensure_fixture, make_openai_response, scripted_responses
from pko.errors import PkoError
from pko.extractors.base import Tree
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.extractors.base import Fact
from pko.progress import matcher
from pko.progress.journey_text import parse_journey_text
from pko.progress.matcher import (
    DEFAULT_MAX_STEPS,
    find_unclaimed_paths,
    load_system_prompt,
    run_agent,
)
from pko.progress.schema import CriterionVerdict, EvidenceRef, ItemVerdict, PlanItem

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")

ROUTER_EVIDENCE = [{"path": "backend/src/api/v1/router.py", "line": 7,
                    "basis": "функция start_task ставит задачу в обработку"}]

BULLETS = ["Определены источники обращений", "Подтверждена скорость обработки"]

CONTEXT = {
    "client_path_name": "Постановка задачи в работу",
    "project_name": "Приём обращений",
    "before": "задача пересылается вручную и теряется между сменами",
    "after": "задача попадает исполнителю сразу и видна обеим сторонам",
}

CONCLUSION = [
    "Ценность подтверждена материалами",
    "Измеримость результата не закрыта",
    "Можно идти дальше",
]

# Верхнеуровневая оценка целого: её модель присылает сама, в отличие от
# готовности и решения — те считает код.
MATCH = "mostly"
MATCH_NOTE = (
    "Заявки система принимает и распределяет сама, "
    "а измеримость результата пока ничем не закрыта."
)


def _call(name: str, args: dict, call_id: str | None = None) -> dict:
    return {
        "id": call_id or f"call_{name}",
        "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }


def tool_call(name: str, **args) -> dict:
    return {"content": None, "tool_calls": [_call(name, args)]}


def parallel_tool_calls(*calls: tuple[str, dict]) -> dict:
    return {"content": None, "tool_calls": [
        _call(name, args, call_id=f"call_{i}_{name}") for i, (name, args) in enumerate(calls)
    ]}


def make_plan(*stages: tuple[str, str, list[str]]) -> list[PlanItem]:
    """Собрать план: (id, title, bullets)."""
    items = []
    for i, (item_id, title, bullets) in enumerate(stages, start=1):
        items.append(PlanItem(id=item_id, title=title, criteria=bullets, origin="user"))
    return items


NA_REASON = "Пункт про следующие этапы, а не про текущий код."
# Развёрнутая «Проверка» для не-зелёных статусов: гейт требует показать, что
# похожее нашлось и чего именно из буллита не нашлось.
LONG_PROOF = (
    "Похожее в коде есть: приём обращения работает и доходит до регистрации. "
    "Дальнейшей обработки не нашлось — маршрутизации по исполнителям в коде нет."
)
# «Как работает» гейт требует непустым у любого оценённого буллита.
HOW = "Система принимает обращение и регистрирует его в общем списке задач."


def criterion(applicable: bool = True, status: str = "done",
              evidence: list[dict] | None = None,
              proof: str = "", how: str = "", comment: str = "",
              na_reason: str | None = None) -> dict:
    """Оценка одного буллита в том виде, в каком её присылает модель.

    `comment` — поле прежних версий: оно всё ещё читается как «как работает»,
    и тесты совместимости этим пользуются. `na_reason` подставляется сам:
    исключить пункт из расчёта без объяснения гейт не даёт.
    """
    # Не зелёный статус требует развёрнутой «Проверки» — подставляем её сама,
    # чтобы каждый тест не переписывал текст ради прохождения гейта.
    if applicable and status and status != "done" and not proof and not comment:
        proof = LONG_PROOF
    # «Как работает» гейт тоже требует непустым: в живом прогоне четыре пункта
    # пришли с пустым полем, и читатель видел претензию без объяснения.
    if applicable and status and not how and not comment:
        how = HOW
    row = {"applicable": applicable, "status": status, "evidence": evidence or [],
           "proof": proof, "how": how, "comment": comment}
    if not applicable:
        row["na_reason"] = NA_REASON if na_reason is None else na_reason
    return row


def stage_args(item_id: str, applicable: bool = True,
               criteria: list[dict] | None = None) -> dict:
    if criteria is None:
        criteria = [criterion(status="done", evidence=ROUTER_EVIDENCE),
                    criterion(status="planned")]
    return {"item_id": item_id, "applicable": applicable, "criteria": criteria}


def rate(item_id: str, applicable: bool = True, criteria: list[dict] | None = None) -> dict:
    return tool_call("submit_stage", **stage_args(item_id, applicable, criteria))


def summary_call(decision: str = "PIVOT",
                 conclusion: list[str] | None = None,
                 match: str = MATCH,
                 match_note: str = MATCH_NOTE) -> dict:
    return tool_call(
        "submit_summary",
        conclusion=CONCLUSION if conclusion is None else conclusion,
        match=match, match_note=match_note,
    )


def finish() -> dict:
    return tool_call("finish")


def brief(before: str = "было так", now: str = "сейчас так", after: str = "стало иначе") -> dict:
    return tool_call("submit_brief", before=before, now=now, after=after)


def review(confirmed: bool = True, notes: str = "") -> dict:
    return tool_call("submit_review", confirmed=confirmed, notes=notes)


def malformed(text: str) -> dict:
    return {"content": text}


class MatcherAgentTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.repo = GitRepo(ensure_fixture())
        cls.sha = cls.repo.resolve("master")
        cls.tree = Tree.at(cls.repo, cls.sha)

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)

    def _run(self, *answers, plan=None, max_steps=DEFAULT_MAX_STEPS, on_verdict=None,
              on_summary=None, description=None):
        if plan is None:
            plan = make_plan(("intake", "Постановка задачи", BULLETS))
        ChatClient._create = scripted_responses(*answers)
        return run_agent(
            plan, CONTEXT, self.tree, SPEC, client=self.client, max_steps=max_steps,
            on_verdict=on_verdict, on_summary=on_summary, description=description,
        )

    def test_no_spec_returns_empty_with_note(self):
        plan = make_plan(("intake", "Постановка задачи", BULLETS))
        result = run_agent(plan, CONTEXT, self.tree, spec=None)
        self.assertFalse(result.usable)
        self.assertIn("не настроен", result.notes[0])

    def test_empty_plan_returns_empty_with_note(self):
        result = run_agent([], CONTEXT, self.tree, SPEC, client=self.client)
        self.assertFalse(result.usable)
        self.assertIn("План пуст", " ".join(result.notes))

    def test_full_session(self):
        plan = make_plan(
            ("intake", "Постановка задачи", BULLETS),
            ("billing", "Оплата подписки", BULLETS),
        )
        result = self._run(
            tool_call("read_file", path="backend/src/api/v1/router.py"),
            rate("intake"),
            rate("billing", applicable=False,
                 criteria=[criterion(applicable=False), criterion(applicable=False)]),
            review(),
            summary_call(),
            finish(),
            plan=plan,
        )
        self.assertEqual(result.source, "llm")
        self.assertEqual(len(result.items), 2)
        by_id = {v.item_id: v for v in result.verdicts}
        # Один буллит «Да» (100), второй «Нет» (0) -> 50%.
        self.assertEqual(by_id["intake"].percent(), 50)
        self.assertTrue(by_id["intake"].criteria[0].evidence[0].verified)
        # Неприменимый этап в картину не входит вовсе.
        self.assertIsNone(by_id["billing"].percent())
        # Решение считает код по порогу: 50% >= 50% -> GO.
        self.assertEqual(result.summary.decision, "GO")
        self.assertEqual(result.context["client_path_name"], CONTEXT["client_path_name"])

    def test_plan_keeps_bullet_texts_verbatim(self):
        plan = make_plan(("intake", "Постановка задачи",
                          ["Первый буллет как в образе", "Второй буллет"]))
        result = self._run(
            rate("intake", criteria=[criterion(status="done", evidence=ROUTER_EVIDENCE),
                                     criterion(status="partial", evidence=ROUTER_EVIDENCE)]),
            finish(),
            plan=plan,
        )
        [item] = result.plan
        self.assertEqual(item.criteria, ["Первый буллет как в образе", "Второй буллет"])

    def test_stage_with_wrong_number_of_ratings_is_rejected(self):
        result = self._run(
            rate("intake", criteria=[criterion()]),
            rate("intake"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(len(result.verdicts[0].criteria), 2)

    def test_unknown_status_for_applicable_criterion_is_rejected(self):
        result = self._run(
            rate("intake", criteria=[criterion(status="почти"), criterion(status="planned")]),
            rate("intake"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(result.verdicts[0].criteria[0].status, "done")

    def test_non_applicable_criterion_drops_status_and_evidence(self):
        result = self._run(
            rate("intake", criteria=[
                criterion(applicable=False, status="done", evidence=ROUTER_EVIDENCE),
                criterion(status="done", evidence=ROUTER_EVIDENCE),
            ]),
            finish(),
        )
        verdict = result.verdicts[0]
        self.assertEqual(verdict.criteria[0].status, "")
        self.assertEqual(verdict.criteria[0].evidence, [])
        # Неприменимый буллит исключён из знаменателя: остаётся один «Да».
        self.assertEqual(verdict.percent(), 100)

    def test_stage_without_applicable_criteria_has_no_percent(self):
        # Все буллиты неприменимы, но этап применим: (0+0)/2 = 0%.
        result = self._run(
            rate("intake", criteria=[criterion(applicable=False), criterion(applicable=False)]),
            finish(),
        )
        # Считать нечего: ни одного применимого буллита.
        self.assertIsNone(result.verdicts[0].percent())

    def test_fabricated_evidence_is_rejected_then_kept_unverified_and_noted(self):
        # Первый заход с выдуманной ссылкой отклоняется гейтом подтверждённости;
        # повтор принимается, но остаётся ungrounded и попадает в notes.
        bad = [criterion(status="done",
                         evidence=[{"path": "нет/такого.py", "line": 1, "basis": "x"}]),
               criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=bad),
            finish(),
        )
        verdict = result.verdicts[0]
        self.assertFalse(verdict.criteria[0].evidence[0].verified)
        self.assertFalse(verdict.criteria[0].is_grounded)
        self.assertIn("без единой подтверждённой ссылки", " ".join(result.notes))

    def test_done_without_evidence_is_rejected_then_fix_accepted(self):
        bad = [criterion(status="done", evidence=[]), criterion(status="planned")]
        fixed = [criterion(status="planned"), criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=fixed),
            finish(),
        )
        self.assertEqual([c.status for c in result.verdicts[0].criteria],
                         ["planned", "planned"])

    def test_evidence_without_line_is_not_verified(self):
        # Путь без строки подтверждает лишь существование файла — гейт такой
        # ссылкой не закрывается (verify_evidence возвращает verified=False).
        no_line = [{"path": "backend/src/api/v1/router.py", "basis": "start_task"}]
        bad = [criterion(status="done", evidence=no_line, proof="Код есть и работает."),
               criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=bad),
            finish(),
        )
        evidence = result.verdicts[0].criteria[0].evidence[0]
        self.assertFalse(evidence.verified)
        self.assertIn("номер строки", evidence.reason)

    def test_text_inventing_path_is_rejected_then_fix_accepted(self):
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                         proof="см. service/deep/worker.py"),
               criterion(status="planned")]
        good = [criterion(status="done", evidence=ROUTER_EVIDENCE, proof="Код есть и работает."),
                criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=good),
            finish(),
        )
        self.assertEqual(result.verdicts[0].criteria[0].proof, "Код есть и работает.")

    def test_text_guard_violation_is_struck_after_second_attempt(self):
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                         proof="см. service/deep/worker.py"),
               criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=bad),
            finish(),
        )
        self.assertEqual(result.verdicts[0].criteria[0].proof, matcher._COMMENT_STRUCK)

    def test_real_path_in_text_is_rejected_too(self):
        """Ссылок в отчёте нет вовсе — значит и в тексте им не место.

        Раньше отклонялся только выдуманный путь: настоящий проходил, потому
        что рядом печатался список ссылок. Списка больше нет, и «router.py:7»
        читателю отчёта открыть нечем.
        """
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                         proof="Подтверждается в backend/src/api/v1/router.py:7."),
               criterion(status="planned")]
        good = [criterion(status="done", evidence=ROUTER_EVIDENCE, proof="Код есть и работает."),
                criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=good),
            finish(),
        )
        self.assertEqual(result.verdicts[0].criteria[0].proof, "Код есть и работает.")

    def test_how_with_function_name_is_rejected(self):
        """«Как работает» читает человек без технического контекста."""
        bad = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                         how="Вызывается analyze_excel_model() из графа."),
               criterion(status="planned")]
        good = [criterion(status="done", evidence=ROUTER_EVIDENCE,
                          how="Система открывает модель и считает результат."),
                criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=good),
            finish(),
        )
        self.assertEqual(result.verdicts[0].criteria[0].how,
                         "Система открывает модель и считает результат.")

    def test_go_with_blocked_bullet_is_rejected(self):
        blocked = criterion(status="blocked", evidence=ROUTER_EVIDENCE,
                            proof=LONG_PROOF)
        result = self._run(
            rate("intake", criteria=[blocked, criterion(status="planned")]),
            review(),
            summary_call(decision="GO"),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "PIVOT")
        self.assertNotIn("заменено кодом", " ".join(result.notes))

    def test_submit_brief_updates_context_before_after(self):
        # Агент формулирует AS IS / Now / To Be из описания первым шагом.
        result = self._run(
            brief(before="ручная пересылка задач", now="видна в системе без маршрутизации", after="автоматическая маршрутизация"),
            rate("intake"),
            finish(),
            description="Раньше пересылали вручную, теперь автоматически.",
        )
        self.assertEqual(result.context["before"], "ручная пересылка задач")
        self.assertEqual(result.context["now"], "видна в системе без маршрутизации")
        self.assertEqual(result.context["after"], "автоматическая маршрутизация")

    def test_submit_brief_without_description_is_ignored(self):
        # Без описания submit_brief не нужен, но если вызван — принимается.
        result = self._run(
            brief(),
            rate("intake"),
            finish(),
        )
        self.assertEqual(result.context["before"], "было так")
        self.assertEqual(result.context["now"], "сейчас так")
        self.assertTrue(result.usable)

    def test_submit_brief_empty_fields_rejected(self):
        result = self._run(
            brief(before="", now="", after=""),
            brief(before="было", now="сейчас", after="стало"),
            rate("intake"),
            finish(),
            description="Описание.",
        )
        self.assertEqual(result.context["before"], "было")
        self.assertEqual(result.context["now"], "сейчас")
        self.assertEqual(result.context["after"], "стало")

    def test_decision_ignores_what_the_model_asked_for(self):
        """Решение вычисляет код по порогу: что прислала модель — неважно."""
        result = self._run(
            rate("intake"),            # done + planned → готовность 50%
            review(),
            summary_call(decision="NO GO"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "GO")
        self.assertEqual(result.summary.reason, "50% ≥ 40%")

    def test_below_threshold_gives_pivot(self):
        result = self._run(
            rate("intake", criteria=[criterion(status="planned"), criterion(status="planned")]),
            review(),
            summary_call(decision="GO"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "PIVOT")
        self.assertEqual(result.summary.reason, "0% < 40%")

    def test_blocked_no_longer_overrides_the_threshold(self):
        """Сознательное изменение: на текущем шаге решает только порог.

        Блокирующий буллит остаётся виден в отчёте, но решение не меняет.
        """
        blocked = criterion(status="blocked", evidence=ROUTER_EVIDENCE,
                            proof=LONG_PROOF)
        result = self._run(
            rate("intake", criteria=[blocked, criterion(status="done",
                                                        evidence=ROUTER_EVIDENCE,
                                                        proof="Код есть и работает.")]),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "GO")

    def test_every_status_but_planned_needs_verified_evidence(self):
        """Гейт держит всю шкалу, а не три статуса из шести.

        `limited` весит 90%, `unused` — 70%. Пока их не было в списке
        подтверждаемых, вес приходил в расчёт без единой проверенной строки
        кода: статус без ссылки проезжал молча.
        """
        for status in ("done", "limited", "unused", "partial", "blocked"):
            with self.subTest(status=status):
                bare = [criterion(status=status, proof=LONG_PROOF),
                        criterion(status="planned")]
                good = [criterion(status=status, evidence=ROUTER_EVIDENCE,
                                  proof=LONG_PROOF),
                        criterion(status="planned")]
                result = self._run(
                    rate("intake", criteria=bare),
                    rate("intake", criteria=good),
                    finish(),
                )
                self.assertEqual(result.verdicts[0].criteria[0].status, status)
                self.assertTrue(result.verdicts[0].criteria[0].is_grounded)

    def test_planned_needs_no_evidence(self):
        result = self._run(
            rate("intake", criteria=[criterion(status="planned", proof=LONG_PROOF),
                                     criterion(status="planned")]),
            finish(),
        )
        self.assertEqual([c.status for c in result.verdicts[0].criteria],
                         ["planned", "planned"])

    def test_confirmed_evidence_is_offered_to_the_lowered_bullets(self):
        """Одна функция нередко закрывает несколько буллитов сразу.

        На живом прогоне «сценарный анализ» получил «работает» по функции
        перебора диапазонов, а соседний пункт про анализ чувствительности —
        «в коде не нашлось»: одна реализация, противоположные выводы. Модель
        не видела, чем подтверждены соседи.
        """
        verdicts = {
            "a": ItemVerdict(item_id="a", applicable=True, criteria=[
                CriterionVerdict(
                    applicable=True, status="done",
                    evidence=[EvidenceRef("tools.py", 624, "analyze_excel_model",
                                          True, "ok", note="перебирает диапазоны")],
                ),
                CriterionVerdict(applicable=True, status="planned"),
            ]),
        }
        rows = matcher._confirmed_evidence(verdicts)
        self.assertEqual(len(rows), 1)
        self.assertIn("tools.py:624", rows[0])
        self.assertIn("перебирает диапазоны", rows[0])

    def test_confirmed_evidence_skips_rejected_links(self):
        verdicts = {
            "a": ItemVerdict(item_id="a", applicable=True, criteria=[
                CriterionVerdict(
                    applicable=True, status="done",
                    evidence=[EvidenceRef("a.py", 1, "run", False, "нет якоря")],
                ),
            ]),
        }
        self.assertEqual(matcher._confirmed_evidence(verdicts), [])

    def test_budget_follows_the_model_window(self):
        """Окно Kimi-K3 — 178к токенов, GLM — 128к: бюджеты обязаны отличаться.

        Плоский потолок в символах либо душил большую модель лишним
        перечитыванием, либо не спасал маленькую от отказа.
        """
        kimi = matcher._history_budget(178_000, 8192, 1.8, 11_474)
        glm = matcher._history_budget(128_000, 8192, 1.8, 11_474)
        self.assertGreater(kimi, glm)
        # Отправляемое должно уложиться в окно с запасом на ответ.
        self.assertLess((kimi + 11_474) / 1.8 + 8192, 178_000)

    def test_budget_grows_after_calibration(self):
        """Настоящая плотность выше осторожной — значит места больше."""
        careful = matcher._history_budget(178_000, 8192, 1.8, 11_474)
        measured = matcher._history_budget(178_000, 8192, 2.6, 11_474)
        self.assertGreater(measured, careful)

    def test_unknown_window_falls_back_to_a_safe_default(self):
        self.assertEqual(matcher._history_budget(0, 8192, 2.6, 11_474),
                         matcher._HISTORY_BUDGET_CHARS)

    def test_env_override_wins_over_everything(self):
        """Эндпоинт может быть настроен на окно меньше заявленного моделью."""
        import os as _os
        self.addCleanup(_os.environ.pop, "PKO_HISTORY_BUDGET", None)
        _os.environ["PKO_HISTORY_BUDGET"] = "30000"
        self.assertEqual(matcher._history_budget(178_000, 8192, 2.6, 11_474), 30_000)

    def test_density_is_measured_from_the_model_own_usage(self):
        self.assertAlmostEqual(matcher._measure_density(300_000, 120_000), 2.5)
        # Мусорные значения не должны раздувать бюджет.
        self.assertIsNone(matcher._measure_density(300_000, 10))
        self.assertIsNone(matcher._measure_density(300_000, 0))
        self.assertIsNone(matcher._measure_density(0, 100))

    def test_budget_never_collapses_to_nothing(self):
        """Даже при странных настройках агенту нужно место на работу."""
        self.assertGreaterEqual(
            matcher._history_budget(20_000, 16_384, 1.0, 50_000), 20_000)

    def test_history_is_trimmed_before_the_endpoint_refuses(self):
        """История растёт с каждым шагом и рано или поздно перерастает окно.

        На большом репозитории эндпоинт отказывал на тридцатом шаге, и прогон
        терялся целиком — без единой оценки. Теперь старые выводы инструментов
        ужимаются заранее.
        """
        messages = [
            {"role": "system", "content": "S" * 100},
            {"role": "user", "content": "U" * 100},
        ]
        for _ in range(10):
            messages.append({"role": "assistant", "content": None, "tool_calls": []})
            messages.append({"role": "tool", "tool_call_id": "x", "content": "L" * 5000})

        cut = matcher._trim_history(messages, budget=12000)
        self.assertGreater(cut, 0)
        total = sum(matcher._message_size(m) for m in messages)
        self.assertLessEqual(total, 12000)
        # Системный промпт и план остаются целыми: без них сессия бессмысленна.
        self.assertEqual(messages[0]["content"], "S" * 100)
        self.assertEqual(messages[1]["content"], "U" * 100)
        # Сообщения не выброшены — иначе диалог развалится: каждому вызову
        # нужен парный ответ.
        self.assertEqual(len(messages), 22)

    def test_history_within_budget_is_untouched(self):
        messages = [
            {"role": "system", "content": "S"},
            {"role": "user", "content": "U"},
            {"role": "tool", "tool_call_id": "x", "content": "коротко"},
        ]
        self.assertEqual(matcher._trim_history(messages, budget=10_000), 0)
        self.assertEqual(messages[2]["content"], "коротко")

    def test_newest_output_survives_trimming(self):
        """Ужимаются самые старые — свежий вывод агенту ещё нужен."""
        messages = [
            {"role": "system", "content": "S"},
            {"role": "user", "content": "U"},
            {"role": "tool", "tool_call_id": "a", "content": "A" * 5000},
            {"role": "tool", "tool_call_id": "b", "content": "B" * 5000},
        ]
        matcher._trim_history(messages, budget=6000)
        self.assertEqual(messages[3]["content"], "B" * 5000)
        self.assertIn("убран из истории", messages[2]["content"])

    def test_reasoning_counts_towards_the_history_size(self):
        """Рассуждение уходит эндпоинту вместе с историей и занимает окно.

        В режиме рассуждения это основной объём шага; не считать его значит
        мерить плотность по половине отправленного и раздавать бюджет,
        которого нет.
        """
        plain = {"role": "assistant", "content": "ответ", "tool_calls": []}
        with_reasoning = dict(plain, reasoning_content="думаю " * 1000)
        self.assertGreater(matcher._message_size(with_reasoning),
                           matcher._message_size(plain) + 5000)

    def test_single_tool_result_is_capped(self):
        capped = matcher._cap_tool_result("x" * 50_000)
        self.assertLess(len(capped), 50_000)
        self.assertIn("обрезан", capped)
        self.assertEqual(matcher._cap_tool_result("коротко"), "коротко")

    def test_capability_digest_lists_what_the_system_can_do(self):
        """Агент начинает с умений системы, а не с поиска слов из буллита.

        Буллит написан языком бизнеса, код — своим: «анализ чувствительности»
        в коде называется перебором диапазонов. Поиск по слову из буллита не
        находит ничего, поэтому карта возможностей идёт первым сообщением.
        """
        facts = [
            Fact(kind="TOOL", key="analyze_excel_model", value="сценарный расчёт",
                 path="tools.py", line=624),
            Fact(kind="ROUTE", key="POST /invoke", value="", path="router.py", line=120),
            Fact(kind="SQL_COLUMN", key="client_id", value="", path="schema.sql", line=3),
        ]
        digest = matcher._capability_digest(SimpleNamespace(facts=facts))
        self.assertIn("analyze_excel_model", digest)
        self.assertIn("tools.py:624", digest)
        self.assertIn("POST /invoke", digest)
        # Имена колонок — про устройство, а не про умения: в карту не идут.
        self.assertNotIn("client_id", digest)

    def test_capability_digest_covers_sql_and_java(self):
        """Целевой стек инициатив — SQL-процедуры и Java-сервисы.

        Пока в карту попадали только питоновские виды фактов, на таком
        репозитории она оставалась почти пустой: процедуры и методы — то, что
        система умеет, — агент не видел и снова искал слова из буллита.
        """
        facts = [
            Fact(kind="SQL_PROC", key="calc_client_score", value="procedure",
                 path="db/proc.sql", line=2),
            Fact(kind="JAVA_METHOD", key="loadRows", value="", path="Svc.java", line=8),
            Fact(kind="JAVA_JOB", key="recalcDaily", value="", path="Svc.java", line=6),
            Fact(kind="SQL_TABLE", key="scores", value="", path="db/proc.sql", line=9),
        ]
        digest = matcher._capability_digest(SimpleNamespace(facts=facts))
        self.assertIn("calc_client_score", digest)
        self.assertIn("loadRows", digest)
        self.assertIn("recalcDaily", digest)
        # Таблица — устройство, а не умение: в карту не идёт.
        self.assertNotIn("scores", digest)

    def test_capability_digest_is_empty_without_extraction(self):
        self.assertEqual(matcher._capability_digest(None), "")

    def test_capability_digest_is_capped(self):
        facts = [
            Fact(kind="TOOL", key=f"tool_{i}", value="", path="t.py", line=i)
            for i in range(200)
        ]
        digest = matcher._capability_digest(SimpleNamespace(facts=facts), limit=5)
        self.assertEqual(digest.count("- TOOL"), 5)

    def test_non_applicable_without_reason_is_rejected(self):
        """Исключение из расчёта — единственный рычаг без доказательств.

        Статус требует проверенной ссылки, а «пункт не про нас» не требовал
        ничего: буллит молча уходил из знаменателя и поднимал процент. Теперь
        хотя бы объяснение обязательно, и оно видно в отчёте.
        """
        bad = [criterion(applicable=False, na_reason=""), criterion(status="planned")]
        good = [criterion(applicable=False), criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=bad),
            rate("intake", criteria=good),
            finish(),
        )
        self.assertEqual(result.verdicts[0].criteria[0].na_reason, NA_REASON)

    def test_non_applicable_reason_reaches_the_report(self):
        result = self._run(
            rate("intake", criteria=[criterion(applicable=False),
                                     criterion(status="planned")]),
            finish(),
        )
        self.assertEqual(result.verdicts[0].criteria[0].to_dict()["na_reason"],
                         NA_REASON)

    def test_summary_risk_with_invented_path_is_rejected(self):
        bad_conclusion = ["Интеграции нет в service/deep/worker.py", CONCLUSION[1], CONCLUSION[2]]
        result = self._run(
            rate("intake"),
            review(),
            summary_call(conclusion=bad_conclusion),
            summary_call(),
            finish(),
        )
        self.assertEqual(result.summary.conclusion, CONCLUSION)

    def test_session_stops_when_time_is_up(self):
        """Шагов может хватать, а времени — нет: восемьдесят шагов по три
        минуты это четыре часа, и всё это время поток держит память, место в
        очереди и открытый SSE у человека, который давно ушёл."""
        saved = os.environ.get("PKO_MAX_SESSION_SECONDS")
        os.environ["PKO_MAX_SESSION_SECONDS"] = "0.001"
        self.addCleanup(
            lambda: os.environ.__setitem__("PKO_MAX_SESSION_SECONDS", saved)
            if saved is not None
            else os.environ.pop("PKO_MAX_SESSION_SECONDS", None))
        time.sleep(0.01)
        result = self._run(rate("intake"), review(), summary_call(), finish())
        self.assertIn("время сессии исчерпано", " ".join(result.notes))

    def test_empty_how_is_rejected(self):
        """В живом прогоне четыре пункта пришли с пустым «Как работает»:
        читатель видел претензию без объяснения, что система делает вместо."""
        result = self._run(
            rate("intake", criteria=[criterion(status="planned", proof=LONG_PROOF, how=" "),
                                     criterion(how=HOW)]),
            rate("intake"), review(), summary_call(), finish(),
        )
        self.assertTrue(all(c.how_text for v in result.verdicts for c in v.criteria))

    def test_json_debris_in_match_note_is_rejected(self):
        """Модель однажды уложила в поле весь объект вызова строкой, и в отчёт
        уехало «…не реализованы", "»."""
        debris = ('Система подбирает вклады и оформляет портфель.", '
                  '"conclusion": ["Подбор работает", "Анализ трат не сделан"')
        result = self._run(
            rate("intake"), review(),
            summary_call(match_note=debris),
            summary_call(),
            finish(),
        )
        self.assertEqual(result.summary.match_note, MATCH_NOTE)

    def test_match_reaches_the_summary(self):
        result = self._run(rate("intake"), review(), summary_call(), finish())
        self.assertEqual(result.summary.match, MATCH)
        self.assertEqual(result.summary.match_note, MATCH_NOTE)

    def test_unknown_match_is_rejected(self):
        """Оценка вне шкалы — это не оценка: код требует её переслать."""
        result = self._run(
            rate("intake"), review(),
            summary_call(match="почти соответствует"),
            summary_call(),
            finish(),
        )
        self.assertEqual(result.summary.match, MATCH)

    def test_match_without_explanation_is_rejected(self):
        """Оценка целого без фразы «почему» ничем не отличается от догадки."""
        result = self._run(
            rate("intake"), review(),
            summary_call(match_note="   "),
            summary_call(),
            finish(),
        )
        self.assertEqual(result.summary.match_note, MATCH_NOTE)

    def test_code_in_match_note_is_rejected(self):
        """Верхнеуровневую оценку читают первой — путей в ней быть не должно."""
        result = self._run(
            rate("intake"), review(),
            summary_call(match_note="Всё делает service/deep/worker.py по расписанию."),
            summary_call(),
            finish(),
        )
        self.assertEqual(result.summary.match_note, MATCH_NOTE)

    def test_summary_conclusion_guard_violation_is_struck_after_second_attempt(self):
        bad_conclusion = ["Интеграции нет в service/deep/worker.py", CONCLUSION[1], CONCLUSION[2]]
        result = self._run(
            rate("intake"),
            review(),
            summary_call(conclusion=bad_conclusion),
            summary_call(conclusion=bad_conclusion),
            finish(),
        )
        self.assertEqual(result.summary.conclusion[0], matcher._ITEM_STRUCK)
        self.assertEqual(result.summary.conclusion[1], CONCLUSION[1])

    def test_planned_criterion_needs_no_evidence(self):
        result = self._run(
            rate("intake", criteria=[criterion(status="planned"), criterion(status="planned")]),
            finish(),
        )
        self.assertNotIn("без единой подтверждённой ссылки", " ".join(result.notes))

    def test_unknown_item_id_is_rejected(self):
        result = self._run(
            rate("no-such-id"),
            rate("intake"),
            finish(),
        )
        self.assertEqual(len(result.verdicts), 1)

    def test_unrated_stage_is_named_in_notes(self):
        plan = make_plan(
            ("intake", "Постановка задачи", BULLETS),
            ("billing", "Оплата подписки", BULLETS),
        )
        result = self._run(
            rate("intake"),
            finish(),
            plan=plan,
        )
        self.assertIn("Оплата подписки", " ".join(result.notes))

    def test_garbage_decision_from_model_does_not_break_anything(self):
        """Поле decision принимается для совместимости и просто игнорируется."""
        result = self._run(
            rate("intake"),
            review(),
            summary_call(decision="МОЖЕТ БЫТЬ"),
            finish(),
        )
        self.assertIn(result.summary.decision, ("GO", "PIVOT"))

    def test_stage_titles_are_kept_verbatim(self):
        plan = make_plan(("api", "Интеграция с бюро", BULLETS))
        result = self._run(
            rate("api"),
            finish(),
            plan=plan,
        )
        self.assertEqual(result.plan[0].title, "Интеграция с бюро")

    def test_empty_plan_is_rejected(self):
        result = self._run(
            tool_call("submit_summary", **{"decision": "GO",
                                           "conclusion": ["a", "b", "c"]}),
            finish(),
            plan=[],
        )
        self.assertFalse(result.usable)

    def test_callbacks_fire_on_accepted_calls(self):
        verdicts: list[tuple[str, int | None]] = []
        summaries: list[str] = []
        self._run(
            rate("intake"),
            review(),
            summary_call(),
            finish(),
            on_verdict=lambda item, v: verdicts.append((item.id, v.percent())),
            on_summary=lambda s: summaries.append(s.decision),
        )
        self.assertEqual(verdicts, [("intake", 50)])
        self.assertEqual(summaries, ["GO"])

    # --- Контр-проверка (submit_review) ---

    def test_submit_summary_rejected_without_review(self):
        # Есть done — submit_summary не принимается без submit_review.
        result = self._run(
            rate("intake"),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertIsNone(result.summary)
        self.assertIn("Контр-проверка не завершена", " ".join(result.notes))

    def test_review_unlocks_summary(self):
        result = self._run(
            rate("intake"),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "GO")

    def test_review_not_confirmed_does_not_unlock(self):
        result = self._run(
            rate("intake"),
            review(confirmed=False),
            review(confirmed=True),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "GO")

    def test_review_required_even_when_all_planned(self):
        # Все planned — review всё равно требуется: агент мог пропустить код.
        result = self._run(
            rate("intake", criteria=[criterion(status="planned"), criterion(status="planned")]),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "PIVOT")
        self.assertNotIn("Контр-проверка не завершена", " ".join(result.notes))

    def test_review_required_even_when_only_blocked(self):
        # blocked без done/partial — review всё равно требуется.
        blocked = criterion(status="blocked", evidence=ROUTER_EVIDENCE,
                            proof=LONG_PROOF)
        result = self._run(
            rate("intake", criteria=[blocked, criterion(status="planned")]),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual(result.summary.decision, "PIVOT")
        self.assertNotIn("Контр-проверка не завершена", " ".join(result.notes))

    def test_stage_revision_during_review_replaces_verdict(self):
        # Агент понизил done→planned при контр-проверке через повторный submit_stage.
        done = [criterion(status="done", evidence=ROUTER_EVIDENCE), criterion(status="planned")]
        fixed = [criterion(status="planned"), criterion(status="planned")]
        result = self._run(
            rate("intake", criteria=done),
            rate("intake", criteria=fixed),
            review(),
            summary_call(decision="PIVOT"),
            finish(),
        )
        self.assertEqual([c.status for c in result.verdicts[0].criteria],
                         ["planned", "planned"])

    def test_stops_after_repeated_identical_tool_call(self):
        result = self._run(
            tool_call("search", pattern="x"),
            tool_call("search", pattern="x"),
            tool_call("search", pattern="x"),
            finish(),
        )
        self.assertFalse(result.usable)
        self.assertIn("одинаковых вызова", " ".join(result.notes))

    def test_stops_at_step_budget(self):
        result = self._run(
            tool_call("list_files"),
            tool_call("search", pattern="a"),
            max_steps=2,
        )
        self.assertFalse(result.usable)
        self.assertIn("бюджет шагов", " ".join(result.notes))

    def test_budget_exhausted_keeps_accepted_verdicts(self):
        result = self._run(
            rate("intake"),
            tool_call("search", pattern="a"),
            tool_call("list_files"),
            max_steps=3,
        )
        self.assertTrue(result.usable)
        self.assertIn("бюджет шагов", " ".join(result.notes))

    def test_tolerates_a_few_malformed_responses(self):
        result = self._run(
            malformed("извините"),
            malformed("и снова"),
            rate("intake"),
            finish(),
        )
        self.assertTrue(result.usable)

    def test_gives_up_after_too_many_malformed_responses(self):
        result = self._run(malformed("x"), malformed("y"), malformed("z"), malformed("w"))
        self.assertFalse(result.usable)
        self.assertIn("не вызвал инструмент", " ".join(result.notes))

    def test_invalid_tool_arguments_json_does_not_crash(self):
        result = self._run(
            rate("intake"),
            {"content": None, "tool_calls": [{
                "id": "bad", "type": "function",
                "function": {"name": "read_file", "arguments": "{not valid json"},
            }]},
            finish(),
        )
        self.assertTrue(result.usable)

    def test_stage_and_finish_in_the_same_turn(self):
        result = self._run(
            parallel_tool_calls(("submit_stage", stage_args("intake")), ("finish", {})),
        )
        self.assertTrue(result.usable)

    def test_grey_stage_cannot_carry_rated_bullets(self):
        """Неприменимый этап серый целиком: статусы его пунктов нигде не считаются.

        Раньше такой вызов принимался: этап показывался как «не относится»
        (percent None), а его буллиты со статусами уезжали в общую готовность.
        """
        result = self._run(
            rate("intake", applicable=False),   # done + planned внутри серого этапа
            rate("intake", applicable=False,
                 criteria=[criterion(applicable=False), criterion(applicable=False)]),
            finish(),
        )
        [verdict] = result.verdicts
        self.assertFalse(verdict.applicable)
        self.assertIsNone(verdict.percent())
        self.assertEqual([c.applicable for c in verdict.criteria], [False, False])

    def test_decision_follows_the_final_statuses(self):
        """Переоценка этапа после вердикта не должна оставлять старое решение.

        `submit_summary` считает решение в момент вызова; если модель потом
        понизила статусы, процент отчёта менялся, а бейдж — нет.
        """
        lowered = [criterion(status="planned"), criterion(status="planned")]
        result = self._run(
            rate("intake"),                      # done + planned → 50% → GO
            review(),
            summary_call(),
            rate("intake", criteria=lowered),    # 0% → PIVOT
            finish(),
        )
        self.assertEqual(result.summary.decision, "PIVOT")
        self.assertTrue(result.summary.reason.startswith("0%"), result.summary.reason)

    def test_stage_without_bullets_accepted(self):
        # Этап без буллитов — criteria пустой список.
        plan = [PlanItem(id="empty", title="Этап без пунктов", criteria=[], origin="user")]
        result = self._run(
            tool_call("submit_stage", item_id="empty", applicable=True, criteria=[]),
            finish(),
            plan=plan,
        )
        self.assertTrue(result.usable)
        self.assertEqual(len(result.verdicts), 1)
        self.assertEqual(len(result.verdicts[0].criteria), 0)


class SystemPromptTest(unittest.TestCase):
    def test_all_prompt_parts_are_loaded(self):
        prompt, missing = load_system_prompt()
        self.assertEqual(missing, [])
        self.assertGreater(len(prompt), 1000)
        self.assertIn("submit_stage", prompt)
        self.assertIn("submit_review", prompt)

    def test_missing_part_is_reported_not_swallowed(self):
        with tempfile.TemporaryDirectory() as empty:
            with mock.patch.object(matcher, "_PROMPT_DIR", Path(empty)):
                prompt, missing = load_system_prompt()
        self.assertEqual(missing, list(matcher._PROMPT_PARTS))
        self.assertTrue(prompt)


class StagePercentTest(unittest.TestCase):
    """Готовность: (Да×100 + Почти×70 + Почти нет×30) / применимые буллиты."""

    def _verdict(self, *pairs):
        return ItemVerdict(
            item_id="a", applicable=True,
            criteria=[CriterionVerdict(applicable=a, status=s) for a, s in pairs],
        )

    def test_weights(self):
        self.assertEqual(self._verdict((True, "done"), (True, "done")).percent(), 100)
        self.assertEqual(self._verdict((True, "done"), (True, "planned")).percent(), 50)
        self.assertEqual(self._verdict((True, "limited"), (True, "limited")).percent(), 75)
        self.assertEqual(self._verdict((True, "unused"), (True, "unused")).percent(), 50)
        self.assertEqual(self._verdict((True, "partial"), (True, "partial")).percent(), 25)
        self.assertEqual(self._verdict((True, "blocked"), (True, "done")).percent(), 50)
        self.assertEqual(self._verdict((True, "planned"), (True, "blocked")).percent(), 0)

    def test_scale_is_monotonic(self):
        """Порядок ступеней: частично < не используется < с ограничениями < работает."""
        order = ["partial", "unused", "limited", "done"]
        percents = [self._verdict((True, s)).percent() for s in order]
        self.assertEqual(percents, sorted(percents))
        # Ровные четверти: шаг вниз по шкале стоит 25 пунктов.
        self.assertEqual(percents, [25, 50, 75, 100])

    def test_non_applicable_criterion_is_excluded_from_denominator(self):
        # Неприменимый буллит — не про код (декларация эффекта, потребители).
        # Он не должен тянуть готовность вниз: (100)/1 = 100%.
        self.assertEqual(self._verdict((True, "done"), (False, "")).percent(), 100)

    def test_all_criteria_non_applicable_gives_none(self):
        self.assertIsNone(self._verdict((False, ""), (False, "")).percent())

    def test_stage_without_criteria_returns_none(self):
        # Этап без буллитов: None (не 0, не серый — просто нечего считать).
        self.assertIsNone(self._verdict().percent())

    def test_non_applicable_stage_is_grey(self):
        verdict = self._verdict((True, "done"))
        verdict.applicable = False
        self.assertIsNone(verdict.percent())


class OverallProgressTest(unittest.TestCase):
    """Общий прогресс: сумма весов всех буллитов / их количество × 100."""

    def test_non_applicable_stage_bullets_are_excluded(self):
        from pko.progress.schema import ProgressModel
        # Этап 1 (применимый): done + planned → 100 + 0
        # Этап 2 (неприменимый): оба буллита вне знаменателя
        # Общий: (100 + 0) / 2 = 50%
        model = ProgressModel(
            verdicts=[
                ItemVerdict(item_id="a", applicable=True, criteria=[
                    CriterionVerdict(applicable=True, status="done"),
                    CriterionVerdict(applicable=True, status="planned"),
                ]),
                ItemVerdict(item_id="b", applicable=False, criteria=[
                    CriterionVerdict(applicable=False, status=""),
                    CriterionVerdict(applicable=False, status=""),
                ]),
            ],
        )
        self.assertEqual(model.overall_progress(), 50)

    def test_rated_bullets_inside_a_grey_stage_do_not_count(self):
        """Флаг этапа сильнее флагов буллитов: серый этап — вне расчёта целиком.

        Проценты этапов (`percent()`) и общая готовность обязаны считаться по
        одному списку буллитов, иначе серый этап показывался бы «не
        относится», а его пункты тянули бы общее число.
        """
        from pko.progress.schema import ProgressModel
        model = ProgressModel(
            verdicts=[
                ItemVerdict(item_id="a", applicable=True, criteria=[
                    CriterionVerdict(applicable=True, status="done"),
                    CriterionVerdict(applicable=True, status="planned"),
                ]),
                ItemVerdict(item_id="b", applicable=False, criteria=[
                    CriterionVerdict(applicable=True, status="done"),
                    CriterionVerdict(applicable=True, status="done"),
                ]),
            ],
        )
        self.assertEqual(model.overall_progress(), 50)
        self.assertEqual(model.closed_share(), 50)
        self.assertEqual(model.criterion_counts()["done"], 1)
        self.assertEqual(model.not_applicable_count(), 2)

    def test_all_done_gives_100(self):
        from pko.progress.schema import ProgressModel
        model = ProgressModel(
            verdicts=[
                ItemVerdict(item_id="a", applicable=True, criteria=[
                    CriterionVerdict(applicable=True, status="done"),
                    CriterionVerdict(applicable=True, status="done"),
                ]),
            ],
        )
        self.assertEqual(model.overall_progress(), 100)

    def test_no_verdicts_gives_0(self):
        from pko.progress.schema import ProgressModel
        model = ProgressModel(verdicts=[])
        self.assertEqual(model.overall_progress(), 0)


class UnclaimedPathsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        repo = GitRepo(ensure_fixture())
        cls.tree = Tree.at(repo, repo.resolve("master"))
        from pko.extractors.runner import extract_all

        cls.extraction = extract_all(cls.tree)

    def test_paths_without_verified_evidence_are_reported(self):
        verdict = ItemVerdict(item_id="a", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="done", evidence=[
                EvidenceRef(path="backend/src/api/v1/router.py", line=7,
                            basis="start_task", verified=True, reason="ok"),
            ]),
        ])
        groups = find_unclaimed_paths(self.extraction, [verdict])
        claimed = {p for g in groups for p in g.example_paths}
        self.assertNotIn("backend/src/api/v1/router.py", claimed)

    def test_no_verdicts_means_everything_is_unclaimed(self):
        groups = find_unclaimed_paths(self.extraction, [])
        self.assertGreater(sum(g.file_count for g in groups), 0)


if __name__ == "__main__":
    unittest.main()

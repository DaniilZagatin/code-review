"""Regression tests for the typed model -> harness boundary."""

import json
import os
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from pko.llm.harness import (
    ToolCallBudget,
    bundle_fingerprint,
    deny_tool_calls,
    dispatch_tool_calls,
    harden_tool_schemas,
    normalize_tool_call_dicts,
    parse_tool_call,
    tool_message,
    trace_model_result,
)
from pko.llm.client import ChatClient
from pko.llm.client import ChatResult
from pko.llm.runtime import (
    AgentLoopConfig,
    AgentLoopHooks,
    StopReason,
    run_agent_loop,
)


def _schemas():
    return harden_tool_schemas([{
        "type": "function",
        "function": {
            "name": "inspect",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "limit": {"type": "integer"},
                    "rows": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {"kind": {"type": "string", "enum": ["a", "b"]}},
                            "required": ["kind"],
                        },
                    },
                    # Deliberately open: keys are runtime field IDs.
                    "fields": {"type": "object"},
                },
                "required": ["path"],
            },
        },
    }])


def _call(name="inspect", call_id="call_1", **arguments):
    return {
        "id": call_id,
        "type": "function",
        "function": {"name": name, "arguments": json.dumps(arguments)},
    }


class ToolSchemaBoundaryTest(unittest.TestCase):
    def test_declared_objects_are_closed_but_open_maps_stay_open(self):
        parameters = _schemas()[0]["function"]["parameters"]
        self.assertFalse(parameters["additionalProperties"])
        self.assertFalse(parameters["properties"]["rows"]["items"]["additionalProperties"])
        self.assertNotIn("additionalProperties", parameters["properties"]["fields"])

    def test_valid_call_is_parsed(self):
        parsed, error = parse_tool_call(
            _call(path="app.py", limit=10, rows=[{"kind": "a"}], fields={"4.1": "x"}),
            _schemas(),
        )
        self.assertEqual(error, "")
        self.assertEqual(parsed.name, "inspect")
        self.assertEqual(parsed.arguments["limit"], 10)

    def test_unknown_argument_is_rejected_before_handler(self):
        parsed, error = parse_tool_call(_call(path="app.py", surprise=True), _schemas())
        self.assertIsNone(parsed)
        self.assertIn("неизвестные поля", error)

    def test_missing_required_and_wrong_nested_enum_are_rejected(self):
        parsed, error = parse_tool_call(_call(limit=1), _schemas())
        self.assertIsNone(parsed)
        self.assertIn("обязательное поле", error)

        parsed, error = parse_tool_call(_call(path="app.py", rows=[{"kind": "z"}]), _schemas())
        self.assertIsNone(parsed)
        self.assertIn("допустимый список", error)

    def test_non_object_arguments_are_rejected(self):
        call = _call(path="app.py")
        call["function"]["arguments"] = "[]"
        parsed, error = parse_tool_call(call, _schemas())
        self.assertIsNone(parsed)
        self.assertIn("JSON-объект", error)

    def test_missing_and_duplicate_ids_are_normalized(self):
        calls = normalize_tool_call_dicts([
            {"function": {"name": "a", "arguments": "{}"}},
            {"id": "same", "function": {"name": "b", "arguments": "{}"}},
            {"id": "same", "function": {"name": "c", "arguments": "{}"}},
        ])
        self.assertEqual([c["id"] for c in calls], ["call_1", "same", "same_2"])


class PromptTrustBoundaryTest(unittest.TestCase):
    def test_every_agent_prompt_marks_repository_content_as_data(self):
        prompt_dir = Path(__file__).resolve().parents[1] / "backend" / "pko" / "progress"
        for name in (
            "agent_system.md", "critic_system.md", "coherence_system.md", "passport_system.md",
        ):
            text = (prompt_dir / name).read_text(encoding="utf-8")
            self.assertIn("Граница доверия", text, msg=name)
            self.assertIn("данные", text, msg=name)
            self.assertIn("не инструкции", text, msg=name)


class CacheTelemetryTest(unittest.TestCase):
    def test_bundle_hash_is_stable_across_dict_order(self):
        self.assertEqual(bundle_fingerprint({"b": 2, "a": 1}),
                         bundle_fingerprint({"a": 1, "b": 2}))

    def test_provider_cached_tokens_are_preserved(self):
        response = SimpleNamespace(usage=SimpleNamespace(
            prompt_tokens=100,
            completion_tokens=20,
            total_tokens=120,
            prompt_tokens_details=SimpleNamespace(cached_tokens=80),
        ))
        usage = ChatClient._usage_of(object.__new__(ChatClient), response)
        self.assertEqual(usage["cached_tokens"], 80)

    def test_common_trace_records_cache_and_token_fields(self):
        class Span:
            def __init__(self):
                self.values = {}

            def set_attribute(self, key, value):
                self.values[key] = value

        span = Span()
        result = SimpleNamespace(
            from_cache=False, text="ok", reasoning_content="why",
            tool_calls=[_call(name="inspect", path="a.py")],
            usage={"prompt_tokens": 100, "completion_tokens": 20,
                   "total_tokens": 120, "cached_tokens": 80},
        )
        trace_model_result(span, result)
        self.assertEqual(span.values["cached_tokens"], 80)
        self.assertEqual(span.values["tool_call_count"], 1)


class ToolBudgetTest(unittest.TestCase):
    def test_explicit_denial_pairs_every_call(self):
        calls = [_call(call_id="a", path="a.py"), _call(call_id="b", path="b.py")]
        messages = deny_tool_calls(calls, "denied")
        self.assertEqual([m["tool_call_id"] for m in messages], ["a", "b"])
        self.assertTrue(all(m["content"] == "denied" for m in messages))

    def test_every_call_gets_a_result_when_turn_limit_is_exceeded(self):
        calls = [_call(call_id=f"c{i}", path=f"{i}.py") for i in range(4)]
        budget = ToolCallBudget(max_total=10, max_per_turn=2)
        report = dispatch_tool_calls(
            calls,
            answer=lambda call: tool_message(call, "ok"),
            budget=budget,
        )
        self.assertEqual(len(report.messages), len(calls))
        self.assertEqual(report.admitted, 2)
        self.assertEqual(report.denied, 2)
        self.assertTrue(all(m["tool_call_id"] == calls[i]["id"] for i, m in enumerate(report.messages)))

    def test_calls_after_finish_are_denied_without_dispatch(self):
        finished = False
        handled = []

        def answer(call):
            nonlocal finished
            handled.append(call["id"])
            finished = True
            return tool_message(call, "finished")

        calls = [_call(call_id="finish", path="a"), _call(call_id="late", path="b")]
        report = dispatch_tool_calls(
            calls,
            answer=answer,
            budget=ToolCallBudget(max_total=10, max_per_turn=10),
            is_finished=lambda: finished,
        )
        self.assertEqual(handled, ["finish"])
        self.assertEqual(report.denied_after_finish, 1)
        self.assertIn("session_finished", report.messages[1]["content"])

    def test_total_budget_override_is_host_owned(self):
        with mock.patch.dict(os.environ, {"PKO_MAX_TOOL_CALLS": "3"}):
            budget = ToolCallBudget.for_steps(100)
        self.assertEqual(budget.max_total, 3)


class _ScriptedChat:
    def __init__(self, *results):
        self.results = list(results)
        self.requests = []

    def chat(self, messages, **kwargs):
        self.requests.append([dict(message) for message in messages])
        return self.results.pop(0)


def _chat_result(*calls, text="", usage=None, reasoning="", from_cache=False):
    return ChatResult(
        text=text,
        usage=usage or {},
        from_cache=from_cache,
        tool_calls=list(calls),
        reasoning_content=reasoning,
    )


class AgentRuntimeTest(unittest.TestCase):
    def _config(self, **overrides):
        values = {
            "role": "test",
            "session_span": "test_session",
            "step_span": "test.step",
            "max_steps": 5,
            "max_tokens": 100,
            "malformed_limit": 2,
            "repeat_limit": 3,
        }
        values.update(overrides)
        return AgentLoopConfig(**values)

    def test_finish_produces_typed_stats_and_operational_events(self):
        finished = False

        def answer(call):
            nonlocal finished
            finished = True
            return tool_message(call, "done")

        client = _ScriptedChat(_chat_result(_call(call_id="finish", path="x"),
                                             usage={"prompt_tokens": 10,
                                                    "completion_tokens": 4,
                                                    "cached_tokens": 6},
                                             reasoning="private",
                                             from_cache=True))
        run = run_agent_loop(
            chat_client=client,
            system_prompt="system",
            user_prompt="task",
            tools=_schemas(),
            config=self._config(),
            hooks=AgentLoopHooks(
                answer_call=answer,
                is_finished=lambda: finished,
                nudge="use a tool",
            ),
        )
        self.assertEqual(run.stats.stop_reason, StopReason.FINISHED)
        self.assertTrue(run.stats.completed)
        self.assertEqual(run.stats.tool_calls, 1)
        self.assertEqual(run.stats.cached_tokens, 6)
        self.assertEqual(run.stats.cache_hits, 1)
        self.assertIn("session_completed", [event.kind for event in run.events])
        # Hidden reasoning is measured, never stored in the event stream.
        self.assertNotIn("private", json.dumps(
            [event.model_dump() for event in run.events], ensure_ascii=False,
        ))

    def test_malformed_limit_has_machine_readable_stop_reason(self):
        client = _ScriptedChat(
            _chat_result(text="plain answer"),
            _chat_result(text="plain answer again"),
        )
        run = run_agent_loop(
            chat_client=client,
            system_prompt="system",
            user_prompt="task",
            tools=_schemas(),
            config=self._config(),
            hooks=AgentLoopHooks(
                answer_call=lambda call: tool_message(call, "ok"),
                is_finished=lambda: False,
                nudge="use a tool",
            ),
        )
        self.assertEqual(run.stats.stop_reason, StopReason.MALFORMED_OUTPUT)
        self.assertEqual(run.stats.malformed_responses, 2)
        self.assertEqual(client.requests[1][-1]["content"], "use a tool")

    def test_repeated_batch_is_denied_and_paired(self):
        call = _call(call_id="same", path="a.py")
        client = _ScriptedChat(_chat_result(call), _chat_result(call), _chat_result(call))
        run = run_agent_loop(
            chat_client=client,
            system_prompt="system",
            user_prompt="task",
            tools=_schemas(),
            config=self._config(),
            hooks=AgentLoopHooks(
                answer_call=lambda item: tool_message(item, "ok"),
                is_finished=lambda: False,
                nudge="use a tool",
            ),
        )
        self.assertEqual(run.stats.stop_reason, StopReason.REPEATED_TOOL_CALLS)
        self.assertEqual(run.messages[-1]["tool_call_id"], "same")
        self.assertIn("repeated_call", run.messages[-1]["content"])
        self.assertEqual(run.stats.tool_calls, 2)

    def test_domain_compactor_is_recorded_as_typed_event(self):
        finished = False

        def answer(call):
            nonlocal finished
            finished = True
            return tool_message(call, "x" * 100)

        client = _ScriptedChat(_chat_result(_call(path="a.py")))
        run = run_agent_loop(
            chat_client=client,
            system_prompt="system",
            user_prompt="task",
            tools=_schemas(),
            config=self._config(),
            hooks=AgentLoopHooks(
                answer_call=answer,
                is_finished=lambda: finished,
                nudge="use a tool",
                compact=lambda messages, budget: 1,
            ),
        )
        self.assertEqual(run.stats.trimmed_messages, 1)
        self.assertIn("context_compaction", [event.kind for event in run.events])


if __name__ == "__main__":
    unittest.main()

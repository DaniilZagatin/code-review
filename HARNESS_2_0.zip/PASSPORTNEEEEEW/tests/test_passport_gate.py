"""Гейт паспорта клиентского пути: модель предлагает, код проверяет.

* структурные нарушения (BBB без операций, дубли уровней, связи в
  несуществующие узлы или не из списка, «Установлено» на намерении)
  отклоняются с объяснением;
* у узла может быть несколько родителей: общий BBB объявляется ссылкой
  `{ref}` или связью `includes`, в дереве стоит под первым, в реестре
  перечислены все;
* нормализация строит нумерацию, ID объектов, связи и реестр из дерева;
* сессия агента ведёт очередь, принимает связи и привязку шагов сценариев,
  а `finish` при шагах без узла отклоняет один раз;
* рендерер переключает бейдж, вырезает потребности и ограничения из
  шаблона и кладёт всех родителей в реестр.
"""

from __future__ import annotations

import json
import unittest

from fixture_support import scripted_responses
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress.passport_agent import render_evaluation_digest, run_passport_agent
from pko.progress.passport_gate import (
    RELATION_KINDS,
    check_passport,
    normalize_passport,
)
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import (
    ConnectivityReview,
    CriterionVerdict,
    EvidenceRef,
    Handoff,
    HandoffCheck,
    ItemVerdict,
    PlanItem,
    ProgressModel,
    Scenario,
)
from pko.render.client_journey_passport import (
    STATUS_BADGE_AGENT,
    STATUS_BADGE_FALLBACK,
    STATUS_BADGE_TEMPLATE,
    flatten_passport_data,
    passport_registry_rows,
    passport_tree_spec,
    render_client_journey_passport,
)
from pko.render.passport_map import build_passport_map, passport_map_nodes


SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")


def _f(value: str, source: str) -> dict:
    return {"value": value, "source": source}


EST = "Установлено: portfolio_creator.py, collect_portfolio — собирает продукты по долям"
OWNER = "Требует подтверждения владельца: владелец продукта вкладов, назначение вне кода"


def _valid() -> dict:
    """Паспорт, проходящий гейт: то, каким его ждёт код.

    Два процесса делят BBB «Определение сценария обращения» (bbb-1): в
    дереве он под process-1, у process-2 числится через `parents`. Между
    блоками — связи `triggers` и `precedes`.
    """
    return {
        "analysis-scope": "repo · abc1234 · проект",
        "decision-boundary": "COMPONENT_BBB",
        "analysis-date": "2026-09-15",
        "tree": [
            {"id": "journey-1", "type": "journey", "children": [
                {"id": "process-1", "type": "process", "children": [
                    {"id": "bbb-1", "type": "bbb", "children": [
                        {"id": "operation-1", "type": "operation"},
                    ]},
                    {"id": "bbb-2", "type": "bbb", "children": [
                        {"id": "operation-2", "type": "operation"},
                    ]},
                ]},
                {"id": "process-2", "type": "process", "children": [
                    {"id": "bbb-3", "type": "bbb", "children": [
                        {"id": "operation-3", "type": "operation"},
                    ]},
                ]},
            ]},
        ],
        "nodes": {
            "journey-1": {"name": "Размещение сбережений в диалоге", "basis": "путь задан образом результата",
                          "fields": {"4.2.3": _f("Предложение: владелец продукта", OWNER)}},
            "process-1": {"name": "Портфельное предложение", "basis": "сценарий с собственной точкой входа",
                          "fields": {
                              "4.3.3": _f("Предложение: владелец продукта", OWNER),
                              "4.3.6": _f("Сборка портфеля — AUTO; оформление — CONFIRM, ждёт кнопки.",
                                          "Выведено: opener.py ждёт нажатия кнопки перед открытием"),
                              "4.3.8": _f("Не установлено: передачи человеку нет, клиент остаётся с ботом.",
                                          "Не установлено"),
                          }},
            "process-2": {"name": "Ответы на вопросы о продуктах", "basis": "сценарий без оформления, со своим завершением",
                          "fields": {
                              "4.3.3": _f("Предложение: владелец продукта", OWNER),
                              "4.3.6": _f("Определение сценария — AUTO; ответ — AUTO.",
                                          "Выведено: подтверждения перед ответом в коде нет"),
                          }},
            "bbb-1": {"name": "Определение сценария обращения", "basis": "выбирает процесс по реплике",
                      "parents": ["process-1", "process-2"],
                      "fields": {"4.4.1": _f("Относит реплику к сценарию.", EST)}},
            "bbb-2": {"name": "Сборка портфеля", "basis": "переиспользуемое действие с контрактом",
                      "fields": {"4.4.1": _f("Собирает набор продуктов.", EST)}},
            "bbb-3": {"name": "Ответ по справочнику продуктов", "basis": "генерация текста по данным",
                      "fields": {"4.4.1": _f("Отвечает на вопрос о продукте.", EST)}},
            "operation-1": {"name": "Классификация реплики", "basis": "результат виден снаружи блока",
                            "fields": {"4.5.1": _f("Определяет категорию.", EST)}},
            "operation-2": {"name": "Расчёт долей портфеля", "basis": "отдельный расчёт с собственным отказом",
                            "fields": {"4.5.6": _f("Повтор безопасен: расчёт без внешнего эффекта.", EST)}},
            "operation-3": {"name": "Текст ответа клиенту", "basis": "сообщение — внешний результат",
                            "fields": {"4.5.1": _f("Формирует текст ответа.", EST)}},
        },
        "relations": [
            {"from": "bbb-1", "to": "process-1", "kind": "triggers",
             "basis": "по категории PICKER граф вызывает подбор"},
            {"from": "bbb-1", "to": "process-2", "kind": "triggers",
             "basis": "по категории FAQ граф вызывает ответы"},
            {"from": "operation-2", "to": "bbb-2", "kind": "feeds",
             "basis": "доли возвращаются в сборку портфеля"},
        ],
    }


class CheckPassportTest(unittest.TestCase):

    def test_valid_passport_passes(self):
        check = check_passport(_valid())
        self.assertEqual(check.errors, [], check.errors)

    def test_bbb_without_operation_rejected(self):
        data = _valid()
        data["tree"][0]["children"][0]["children"][1]["children"] = []
        errors = check_passport(data).errors
        self.assertTrue(any("bbb-2: BBB без атомарных операций" in e for e in errors), errors)

    def test_child_duplicating_parent_rejected(self):
        data = _valid()
        data["nodes"]["operation-2"]["name"] = "Сборка портфеля"
        errors = check_passport(data).errors
        self.assertTrue(any("названы одинаково" in e for e in errors), errors)

    def test_single_bbb_with_parent_basis_rejected(self):
        data = _valid()
        data["tree"][0]["children"][0]["children"] = [data["tree"][0]["children"][0]["children"][1]]
        del data["nodes"]["bbb-1"], data["nodes"]["operation-1"]
        data["relations"] = []
        data["nodes"]["bbb-2"]["basis"] = data["nodes"]["process-1"]["basis"]
        errors = check_passport(data).errors
        self.assertTrue(any("средний уровень пустой" in e for e in errors), errors)

    def test_shared_node_counts_as_child_of_every_parent(self):
        # У process-2 в tree только bbb-3; без второго родителя у bbb-1 он бы
        # прошёл и так, но пустой процесс, чьи BBB — только общие, тоже полный.
        data = _valid()
        data["tree"][0]["children"][1]["children"] = []
        del data["nodes"]["bbb-3"], data["nodes"]["operation-3"]
        errors = check_passport(data).errors
        self.assertFalse(any("process-2: процесс без BBB" in e for e in errors), errors)

    def test_parents_must_match_tree_and_type(self):
        data = _valid()
        data["nodes"]["bbb-1"]["parents"] = ["process-2", "process-1"]
        errors = check_passport(data).errors
        self.assertTrue(any("первый в parents должен быть родителем из tree" in e for e in errors), errors)
        data = _valid()
        data["nodes"]["bbb-1"]["parents"] = ["process-1", "bbb-2"]
        errors = check_passport(data).errors
        self.assertTrue(any("родитель должен быть типа process" in e for e in errors), errors)
        data = _valid()
        data["nodes"]["bbb-1"]["parents"] = ["process-1", "process-9"]
        errors = check_passport(data).errors
        self.assertTrue(any("process-9 не существует" in e for e in errors), errors)

    def test_relation_kind_outside_list_rejected(self):
        data = _valid()
        data["relations"][0]["kind"] = "связано как-то"
        errors = check_passport(data).errors
        self.assertTrue(any("вид «связано как-то» не из списка" in e for e in errors), errors)
        self.assertIn("includes", RELATION_KINDS)

    def test_relation_to_unknown_or_self_rejected(self):
        data = _valid()
        data["relations"].append({"from": "bbb-2", "to": "bbb-9", "kind": "precedes", "basis": "вызов после сборки"})
        data["relations"].append({"from": "bbb-2", "to": "bbb-2", "kind": "precedes", "basis": "вызов после сборки"})
        errors = check_passport(data).errors
        self.assertTrue(any("узла bbb-9 нет" in e for e in errors), errors)
        self.assertTrue(any("с самим собой" in e for e in errors), errors)

    def test_relation_without_basis_or_duplicate_rejected(self):
        data = _valid()
        data["relations"][0]["basis"] = "да"
        data["relations"].append(dict(data["relations"][1]))
        errors = check_passport(data).errors
        self.assertTrue(any("нет basis" in e for e in errors), errors)
        self.assertTrue(any("уже объявлена" in e for e in errors), errors)

    def test_relation_with_journey_rejected(self):
        data = _valid()
        data["relations"].append({"from": "journey-1", "to": "bbb-2", "kind": "precedes", "basis": "путь начинается со сборки"})
        errors = check_passport(data).errors
        self.assertTrue(any("клиентским путём" in e for e in errors), errors)

    def test_includes_requires_parent_level(self):
        data = _valid()
        data["relations"].append({"from": "bbb-2", "to": "operation-3", "kind": "includes", "basis": "текст ответа нужен и в сборке"})
        self.assertEqual(check_passport(data).errors, [])
        data["relations"].append({"from": "process-2", "to": "operation-2", "kind": "includes", "basis": "расчёт нужен и в ответах"})
        errors = check_passport(data).errors
        self.assertTrue(any("includes — второй родитель" in e for e in errors), errors)

    def test_bare_level_without_detail_rejected(self):
        data = _valid()
        data["nodes"]["bbb-2"]["fields"]["4.4.1"]["source"] = "Выведено"
        errors = check_passport(data).errors
        self.assertTrue(any("«Выведено» без привязки" in e for e in errors), errors)

    def test_source_without_level_rejected(self):
        data = _valid()
        data["nodes"]["bbb-2"]["fields"]["4.4.1"]["source"] = "portfolio_creator.py"
        errors = check_passport(data).errors
        self.assertTrue(any("должно начинаться с уровня" in e for e in errors), errors)

    def test_owner_established_rejected(self):
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.3"]["source"] = "Установлено: CODEOWNERS, команда депозитов"
        errors = check_passport(data).errors
        self.assertTrue(any("process-1 4.3.3" in e for e in errors), errors)

    def test_process_without_execution_mode_rejected(self):
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.6"]["value"] = "Сборка портфеля, оформление."
        errors = check_passport(data).errors
        self.assertTrue(any("режим исполнения" in e for e in errors), errors)

    def test_bad_decision_boundary_rejected(self):
        data = _valid()
        data["decision-boundary"] = "ВЕСЬ ПУТЬ"
        self.assertTrue(any("decision-boundary" in e for e in check_passport(data).errors))

    def test_handoff_as_scenario_transition_is_remark(self):
        data = _valid()
        data["nodes"]["process-1"]["fields"]["4.3.8"]["value"] = "Переход к оформлению по кнопке."
        check = check_passport(data)
        self.assertEqual(check.errors, [])
        self.assertTrue(any("4.3.8" in r for r in check.remarks), check.remarks)

    def test_status_rollback_is_not_compensation_remark(self):
        data = _valid()
        data["nodes"]["operation-2"]["name"] = "Перевод средств"
        data["nodes"]["operation-2"]["fields"]["4.5.4"] = _f("Средства переведены на источник.", EST)
        data["nodes"]["operation-2"]["fields"]["4.5.6"]["value"] = "При ошибке статус откатывается."
        remarks = check_passport(data).remarks
        self.assertTrue(any("откат статуса — не компенсация" in r for r in remarks), remarks)

    def test_router_mentioned_without_node_is_remark(self):
        data = _valid()
        data["nodes"]["bbb-1"]["name"] = "Подбор вклада"
        data["nodes"]["bbb-1"]["basis"] = "переиспользуемое действие"
        data["nodes"]["process-1"]["fields"]["4.3.4"] = _f(
            "Запрос на портфель.", "Установлено: prompts/scenario.py классификатор категорий")
        remarks = check_passport(data).remarks
        self.assertTrue(any("классификатор" in r for r in remarks), remarks)
        # Узел с ролью маршрутизатора есть — замечания нет.
        self.assertFalse(any("классификатор" in r for r in check_passport(_valid()).remarks))

    def test_legacy_need_and_guardrail_nodes_rejected(self):
        data = _valid()
        data["nodes"]["need-1"] = {"name": "Разместить деньги", "basis": "существует до продукта", "fields": {}}
        errors = check_passport(data).errors
        # Тип не опознан: в дерево не входит, в nodes лишний.
        self.assertTrue(errors, errors)

    def test_empty_or_wrong_type_rejected(self):
        self.assertTrue(check_passport(None).errors)
        self.assertTrue(check_passport({"nodes": {}}).errors)
        self.assertTrue(check_passport({"nodes": {"journey-1": {"name": "x"}}}).errors)


class NormalizePassportTest(unittest.TestCase):

    def test_registry_lists_all_parents_and_relations_kept(self):
        norm = normalize_passport(_valid())
        rows = {row["id"]: row for row in norm["registry"]}
        self.assertEqual(rows["journey-1"]["parent"], "—")
        self.assertEqual(rows["process-1"]["parent"], "journey-1")
        self.assertEqual(rows["bbb-1"]["parent"], "process-1, process-2")
        self.assertEqual(rows["operation-2"]["parent"], "bbb-2")
        self.assertEqual(rows["bbb-2"]["basis"], "переиспользуемое действие с контрактом")
        self.assertEqual(norm["nodes"]["bbb-1"]["parents"], ["process-1", "process-2"])
        self.assertEqual(norm["nodes"]["bbb-2"]["parents"], ["process-1"])
        self.assertEqual([r["kind"] for r in norm["relations"]], ["triggers", "triggers", "feeds"])
        self.assertEqual(norm["relations"][0]["kind_label"], "запускает")
        self.assertNotIn("need-1", rows)

    def test_includes_relation_adds_parent(self):
        data = _valid()
        data["nodes"]["bbb-1"].pop("parents")
        data["relations"].append({"from": "process-2", "to": "bbb-1", "kind": "includes",
                                  "basis": "определение сценария общее для процессов"})
        norm = normalize_passport(data)
        self.assertEqual(norm["nodes"]["bbb-1"]["parents"], ["process-1", "process-2"])
        rows = {row["id"]: row for row in norm["registry"]}
        self.assertEqual(rows["bbb-1"]["parent"], "process-1, process-2")

    def test_agent_registry_ignored(self):
        data = _valid()
        data["registry"] = [{"id": "bbb-1", "type": "X", "name": "Y", "parent": "—", "basis": "чужое"}]
        rows = {row["id"]: row for row in normalize_passport(data)["registry"]}
        self.assertEqual(rows["bbb-1"]["parent"], "process-1, process-2")
        self.assertEqual(rows["bbb-1"]["basis"], "выбирает процесс по реплике")
        self.assertEqual(len(rows), 9)

    def test_renumbering_and_object_ids(self):
        data = _valid()
        # Агент нумерует с дыр: bbb-7 — код пересчитывает вместе со связями.
        data["tree"][0]["children"][0]["children"][1]["id"] = "bbb-7"
        data["nodes"]["bbb-7"] = data["nodes"].pop("bbb-2")
        data["relations"][2]["to"] = "bbb-7"
        norm = normalize_passport(data)
        self.assertIn("bbb-2", norm["nodes"])
        self.assertNotIn("bbb-7", norm["nodes"])
        self.assertEqual(norm["relations"][2]["to"], "bbb-2")
        self.assertEqual(norm["nodes"]["bbb-2"]["object-id"], "bbb.sborka-portfelya")
        self.assertEqual(norm["tree"][0]["children"][0]["children"][1]["id"], "bbb-2")

    def test_unknown_relation_dropped_silently_in_normalize(self):
        data = _valid()
        data["relations"].append({"from": "bbb-2", "to": "bbb-9", "kind": "precedes", "basis": "мимо"})
        norm = normalize_passport(data)
        self.assertEqual(len(norm["relations"]), 3)


def _node_call(node_id: str, name: str, basis: str, fields: dict, **extra) -> dict:
    args = {"id": node_id, "name": name, "basis": basis, "fields": fields, **extra}
    return {"content": None, "tool_calls": [{
        "id": f"call_{node_id}", "type": "function",
        "function": {"name": "submit_node", "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


def _children_call(parent: str, *children) -> dict:
    items = [{"ref": c} if isinstance(c, str) else {"name": c[0], "basis": c[1]} for c in children]
    args = {"parent": parent, "children": items}
    return {"content": None, "tool_calls": [{
        "id": f"call_children_{parent}", "type": "function",
        "function": {"name": "declare_children", "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


def _tool_call(name: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": f"call_{name}_{abs(hash(json.dumps(args, sort_keys=True))) % 10_000}", "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


def _link_call(src: str, dst: str, kind: str, basis: str = "вызов после успешного шага в graph.py") -> dict:
    return _tool_call("link_nodes", **{"from": src, "to": dst, "kind": kind, "basis": basis})


def _finish_call() -> dict:
    return _tool_call("finish")


PROCESS_FIELDS = {
    "4.3.3": _f("Предложение: владелец продукта", OWNER),
    "4.3.6": _f("Определение сценария — AUTO; сборка — AUTO.", "Выведено: подтверждения перед действием нет"),
    "4.3.8": _f("Не установлено: передачи человеку нет.", "Не установлено"),
}
BBB_FIELDS = {"4.4.1": _f("Делает одно действие.", EST)}
OP_FIELDS = {"4.5.1": _f("Шаг с наблюдаемым результатом.", EST)}


def _happy_script() -> list[dict]:
    """Полный обход: journey → process → 2 BBB × 1 операция → связь → finish."""
    return [
        _node_call("journey-1", "Размещение сбережений", "путь из образа результата",
                   {"4.2.3": _f("Предложение: владелец продукта", OWNER)},
                   decision_boundary="COMPONENT_BBB"),
        _children_call("journey-1", ("Портфельное предложение", "сценарий со своим входом")),
        _node_call("process-1", "Портфельное предложение", "сценарий со своим входом", PROCESS_FIELDS),
        _children_call("process-1",
                       ("Определение сценария обращения", "выбирает процесс по реплике"),
                       ("Сборка портфеля", "собирает набор продуктов")),
        _node_call("bbb-1", "Определение сценария обращения", "выбирает процесс по реплике", BBB_FIELDS),
        _children_call("bbb-1", ("Классификация реплики", "результат виден снаружи")),
        _node_call("operation-1", "Классификация реплики", "результат виден снаружи", OP_FIELDS),
        _node_call("bbb-2", "Сборка портфеля", "собирает набор продуктов", BBB_FIELDS),
        _children_call("bbb-2", ("Расчёт долей портфеля", "отдельный расчёт")),
        _node_call("operation-2", "Расчёт долей портфеля", "отдельный расчёт", OP_FIELDS),
        _link_call("bbb-1", "bbb-2", "triggers"),
        _finish_call(),
    ]


def _shared_script() -> list[dict]:
    """Два процесса, общий BBB через {ref}: journey → process-1 (bbb-1, bbb-2)
    → process-2 (ref bbb-1, bbb-3) → связи → finish."""
    return [
        _node_call("journey-1", "Размещение сбережений", "путь из образа результата",
                   {"4.2.3": _f("Предложение: владелец продукта", OWNER)},
                   decision_boundary="COMPONENT_BBB"),
        _children_call("journey-1", ("Портфельное предложение", "сценарий со своим входом"),
                       ("Ответы на вопросы", "сценарий без оформления")),
        _node_call("process-1", "Портфельное предложение", "сценарий со своим входом", PROCESS_FIELDS),
        _children_call("process-1",
                       ("Определение сценария обращения", "выбирает процесс по реплике"),
                       ("Сборка портфеля", "собирает набор продуктов")),
        _node_call("bbb-1", "Определение сценария обращения", "выбирает процесс по реплике", BBB_FIELDS),
        _children_call("bbb-1", ("Классификация реплики", "результат виден снаружи")),
        _node_call("operation-1", "Классификация реплики", "результат виден снаружи", OP_FIELDS),
        _node_call("bbb-2", "Сборка портфеля", "собирает набор продуктов", BBB_FIELDS),
        _children_call("bbb-2", ("Расчёт долей портфеля", "отдельный расчёт")),
        _node_call("operation-2", "Расчёт долей портфеля", "отдельный расчёт", OP_FIELDS),
        _node_call("process-2", "Ответы на вопросы", "сценарий без оформления", PROCESS_FIELDS),
        _children_call("process-2", "bbb-1", ("Ответ по справочнику", "генерация текста по данным")),
        _node_call("bbb-3", "Ответ по справочнику", "генерация текста по данным", BBB_FIELDS),
        _children_call("bbb-3", ("Текст ответа клиенту", "сообщение — внешний результат")),
        _node_call("operation-3", "Текст ответа клиенту", "сообщение — внешний результат", OP_FIELDS),
        _link_call("bbb-1", "process-1", "triggers", "категория PICKER запускает подбор"),
        _link_call("bbb-1", "process-2", "triggers", "категория FAQ запускает ответы"),
        _finish_call(),
    ]


def _scenario(steps: list[str], results: list[str] | None = None) -> Scenario:
    handoffs = []
    for index in range(len(steps) - 1):
        result = (results or ["ok"] * (len(steps) - 1))[index]
        handoffs.append(Handoff(step=index, kind="call", checks=[
            HandoffCheck(check=c, result=result, note="", evidence=[])
            for c in ("reachability", "contract", "data_continuity")
        ]))
    return Scenario(id="scenario-1", title="Подбор портфеля", entry="вход", outcome="итог",
                    steps=steps, critical=True, bullets=["Подобран продукт."], handoffs=handoffs)


class PassportAgentTest(unittest.TestCase):
    """Отдельная сессия: обход сверху вниз, очередь ведёт код."""

    def setUp(self):
        self._original = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._original)
        self.client = ChatClient(spec=SPEC, use_cache=False)
        self.plan = [PlanItem(id="s1", title="Подбор", criteria=["Подобран продукт."], origin="user")]
        self.verdicts = [ItemVerdict(item_id="s1", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="done", proof="Код есть.", how="Подбирает.",
                             evidence=[EvidenceRef(path="app.py", line=3, basis="select",
                                                   verified=True, reason="ок", note="подбирает вклад")]),
        ])]

    def _run(self, *answers, **kwargs):
        ChatClient._create = scripted_responses(*answers)
        return run_passport_agent(
            self.plan, {"client_path_name": "Размещение сбережений", "project_name": "Демо"},
            self.verdicts, None, SPEC, client=self.client,
            knowledge=["[read_file app.py:1-40 — def select()]"], repo_name="demo", commit="abc1234",
            **kwargs,
        )

    def test_full_walk_builds_tree_registry_and_ids(self):
        result = self._run(*_happy_script())
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertFalse(any("не завершён" in n for n in result.notes), result.notes)
        self.assertEqual(data["decision-boundary"], "COMPONENT_BBB")
        rows = {r["id"]: r for r in data["registry"]}
        self.assertEqual(set(rows), {"journey-1", "process-1", "bbb-1", "bbb-2",
                                     "operation-1", "operation-2"})
        self.assertEqual(rows["operation-2"]["parent"], "bbb-2")
        self.assertEqual(data["nodes"]["bbb-2"]["object-id"], "bbb.sborka-portfelya")
        self.assertEqual(data["tree"][0]["children"][0]["children"][1]["children"][0]["id"], "operation-2")
        self.assertEqual(data["relations"], [{
            "from": "bbb-1", "to": "bbb-2", "kind": "triggers", "kind_label": "запускает",
            "basis": "вызов после успешного шага в graph.py",
        }])

    def test_shared_node_via_ref_gets_two_parents_once_in_tree(self):
        result = self._run(*_shared_script())
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertFalse(any("не завершён" in n or "с нарушениями" in n for n in result.notes), result.notes)
        self.assertEqual(data["nodes"]["bbb-1"]["parents"], ["process-1", "process-2"])
        rows = {r["id"]: r for r in data["registry"]}
        self.assertEqual(rows["bbb-1"]["parent"], "process-1, process-2")
        # В дереве общий узел стоит под первым родителем, под вторым — нет.
        procs = data["tree"][0]["children"]
        self.assertEqual([c["id"] for c in procs[0]["children"]], ["bbb-1", "bbb-2"])
        self.assertEqual([c["id"] for c in procs[1]["children"]], ["bbb-3"])
        self.assertEqual(len(data["nodes"]), 9)
        self.assertEqual([r["kind"] for r in data["relations"]], ["triggers", "triggers"])

    def test_ref_to_unknown_or_wrong_level_rejected(self):
        script = _shared_script()
        # Сначала ref на несуществующий узел и на операцию — отклонение, затем верный вызов.
        script.insert(11, _children_call("process-2", "bbb-9", ("Ответ по справочнику", "генерация текста")))
        script.insert(12, _children_call("process-2", "operation-1", ("Ответ по справочнику", "генерация текста")))
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertEqual(result.passport_data["nodes"]["bbb-1"]["parents"], ["process-1", "process-2"])
        self.assertFalse(any("с нарушениями" in n for n in result.notes), result.notes)

    def test_includes_link_adds_parent_after_tree(self):
        script = _happy_script()
        script.insert(-1, _link_call("process-1", "bbb-1", "includes", "уже родитель — должно отклониться"))
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        # Дублирование дерева связью отклонено: связей осталась одна.
        self.assertEqual(len(result.passport_data["relations"]), 1)

    def test_bad_relation_rejected_without_losing_step(self):
        script = _happy_script()
        script.insert(-1, _link_call("bbb-1", "bbb-7", "precedes"))
        script.insert(-1, _link_call("bbb-1", "bbb-2", "как-то связаны"))
        script.insert(-1, _link_call("bbb-1", "bbb-2", "triggers"))  # дубль
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertEqual(len(result.passport_data["relations"]), 1)
        self.assertFalse(any("не завершён" in n for n in result.notes), result.notes)

    def test_children_required_for_intermediate_nodes(self):
        script = _happy_script()
        script.insert(5, _children_call("bbb-1"))  # пустое объявление детей у BBB
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertIn("operation-1", result.passport_data["nodes"])
        self.assertEqual(result.passport_data["nodes"]["bbb-1"]["name"], "Определение сценария обращения")

    def test_wrong_node_id_rejected_and_queue_kept(self):
        script = _happy_script()
        # Модель пытается заполнить bbb-2 раньше очереди — код не принимает.
        script.insert(4, _node_call("bbb-2", "Сборка портфеля", "собирает", BBB_FIELDS))
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertEqual(result.passport_data["nodes"]["bbb-1"]["name"], "Определение сценария обращения")
        self.assertEqual(len(result.passport_data["registry"]), 6)

    def test_bad_node_rejected_then_fixed(self):
        script = _happy_script()
        bad = _node_call("bbb-2", "Портфельное предложение", "как процесс", BBB_FIELDS)
        script.insert(7, bad)
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertEqual(result.passport_data["nodes"]["bbb-2"]["name"], "Сборка портфеля")
        self.assertFalse(any("с нарушениями" in n for n in result.notes), result.notes)

    def test_interrupted_session_keeps_declared_nodes(self):
        result = self._run(*_happy_script()[:6])
        data = result.passport_data
        self.assertIsNotNone(data)
        self.assertIn("bbb-2", data["nodes"])
        self.assertIn("Не заполнено", data["nodes"]["bbb-2"].get("object-version", ""))
        self.assertTrue(any("не завершён" in n for n in result.notes), result.notes)
        self.assertTrue(any("не заполнены" in n for n in result.notes), result.notes)

    def test_single_bbb_process_gets_remark(self):
        script = [
            _node_call("journey-1", "Размещение сбережений", "путь из образа результата",
                       {"4.2.3": _f("Предложение: владелец продукта", OWNER)},
                       decision_boundary="COMPONENT_BBB"),
            _children_call("journey-1", ("Портфельное предложение", "сценарий со своим входом")),
            _node_call("process-1", "Портфельное предложение", "сценарий со своим входом", PROCESS_FIELDS),
            _children_call("process-1", ("Сборка портфеля", "собирает набор продуктов")),
            _node_call("bbb-1", "Сборка портфеля", "собирает набор продуктов", BBB_FIELDS),
            _children_call("bbb-1", ("Расчёт долей портфеля", "отдельный расчёт")),
            _node_call("operation-1", "Расчёт долей портфеля", "отдельный расчёт", OP_FIELDS),
            _finish_call(),
        ]
        result = self._run(*script)
        self.assertIsNotNone(result.passport_data)
        self.assertTrue(any("один BBB на процесс" in n for n in result.notes), result.notes)

    def test_finish_rejected_once_for_unbound_scenario_steps(self):
        review = ConnectivityReview(scenarios=[_scenario(["Реплика классифицируется", "Собирается портфель", "Показан оффер"])])
        script = _happy_script()
        # bbb-1 берёт шаг 0; шаги 1 и 2 без узла. Первый finish отклоняется,
        # модель привязывает шаг 1 и завершает — шаг 2 остаётся в замечаниях.
        script[4] = _node_call("bbb-1", "Определение сценария обращения", "выбирает процесс по реплике",
                               BBB_FIELDS, scenario_steps=[{"scenario": "scenario-1", "step": 0}])
        script.insert(-1, _finish_call())
        script.insert(-1, _tool_call("bind_scenario_step", scenario="scenario-1", step=1, nodes=["bbb-2", "operation-2"]))
        result = self._run(*script, connectivity=review)
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertFalse(any("не завершён" in n for n in result.notes), result.notes)
        self.assertEqual(data["nodes"]["bbb-2"]["scenario_steps"], [{"scenario": "scenario-1", "step": 1}])
        self.assertEqual(data["nodes"]["operation-2"]["scenario_steps"], [{"scenario": "scenario-1", "step": 1}])
        self.assertTrue(any("шаг 2 «Показан оффер»" in n for n in result.notes), result.notes)

    def test_bind_scenario_step_rejects_containers_and_unknown_steps(self):
        review = ConnectivityReview(scenarios=[_scenario(["Реплика классифицируется", "Собирается портфель"])])
        script = _happy_script()
        script.insert(-1, _tool_call("bind_scenario_step", scenario="scenario-1", step=0, nodes=["process-1"]))
        script.insert(-1, _tool_call("bind_scenario_step", scenario="scenario-1", step=5, nodes=["bbb-1"]))
        script.insert(-1, _tool_call("bind_scenario_step", scenario="scenario-1", step=0, nodes=["bbb-1"]))
        script.insert(-1, _tool_call("bind_scenario_step", scenario="scenario-1", step=1, nodes=["bbb-2"]))
        result = self._run(*script, connectivity=review)
        data = result.passport_data
        self.assertIsNotNone(data, result.notes)
        self.assertFalse(any("шаги сценариев без узла" in n for n in result.notes), result.notes)
        self.assertEqual(data["nodes"]["bbb-1"]["scenario_steps"], [{"scenario": "scenario-1", "step": 0}])
        self.assertEqual(data["nodes"]["process-1"].get("scenario_steps", []), [])

    def test_no_spec_returns_note(self):
        result = run_passport_agent(self.plan, {}, self.verdicts, None, None)
        self.assertIsNone(result.passport_data)
        self.assertTrue(result.notes)

    def test_digest_contains_evidence_and_knowledge(self):
        text = render_evaluation_digest(self.plan, self.verdicts, None, ["[read_file app.py:1-40 — def select()]"])
        self.assertIn("app.py:3 — select — подбирает вклад", text)
        self.assertIn("[read_file app.py", text)
        self.assertIn("Подобран продукт. — done", text)


class PassportMapTest(unittest.TestCase):
    """Схема: общий узел под первым родителем, связи в контракте, пропуски
    шагов сценария на пути."""

    def _model(self, data: dict, scenario: Scenario | None = None) -> ProgressModel:
        plan = PlanItem(id="s1", title="Подбор", criteria=["Подобран продукт.", "Показан оффер."], origin="user")
        verdicts = [ItemVerdict(item_id="s1", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="done", proof="", how=""),
            CriterionVerdict(applicable=True, status="planned", proof="", how=""),
        ])]
        model = ProgressModel(meta={}, items={"s1": plan}, verdicts=verdicts)
        model.passport_data = data
        if scenario is not None:
            model.connectivity = ConnectivityReview(scenarios=[scenario])
        return model

    def test_nodes_carry_all_parents_and_relations(self):
        norm = normalize_passport(_valid())
        nodes = {n["id"]: n for n in passport_map_nodes(norm)}
        self.assertEqual(nodes["bbb-1"]["parents"], ["process-1", "process-2"])
        self.assertEqual(nodes["bbb-1"]["parent"], "process-1")
        self.assertIsNone(nodes["journey-1"]["parent"])
        schema = build_passport_map(self._model(norm))
        self.assertEqual([r["kind"] for r in schema["relations"]], ["triggers", "triggers", "feeds"])
        by_id = {n["id"]: n for n in schema["nodes"]}
        self.assertEqual(len(by_id["bbb-1"]["relations"]), 2)
        self.assertEqual(schema["summary"]["shared_nodes"], 1)
        self.assertEqual(schema["summary"]["relations_total"], 3)

    def test_shared_node_bullets_count_for_every_parent(self):
        data = _valid()
        data["nodes"]["bbb-1"]["bullets"] = ["Подобран продукт."]
        norm = normalize_passport(data)
        by_id = {n["id"]: n for n in build_passport_map(self._model(norm))["nodes"]}
        # Оба процесса получают состояние через общий блок.
        self.assertEqual(by_id["process-1"]["implementation_status"], "implemented")
        self.assertEqual(by_id["process-2"]["implementation_status"], "implemented")
        self.assertEqual(by_id["process-2"]["assessment_source"], "derived")

    def test_unmapped_scenario_steps_are_explicit(self):
        data = _valid()
        data["nodes"]["bbb-1"]["scenario_steps"] = [{"scenario": "scenario-1", "step": 0}]
        data["nodes"]["bbb-2"]["scenario_steps"] = [{"scenario": "scenario-1", "step": 2}]
        scenario = _scenario(["Классификация", "Профиль клиента", "Сборка портфеля"], ["ok", "broken"])
        schema = build_passport_map(self._model(normalize_passport(data), scenario))
        [path] = schema["paths"]
        self.assertEqual(path["steps_mapped"], 2)
        self.assertEqual(path["steps_total"], 3)
        self.assertEqual(path["unmapped_steps"], [{"step": 1, "text": "Профиль клиента"}])
        self.assertTrue(any("Профиль клиента" in p for p in path["problems"]), path["problems"])
        [edge] = path["edges"]
        self.assertEqual((edge["from"], edge["to"], edge["result"], edge["skipped"]), ("bbb-1", "bbb-2", "broken", [1]))
        self.assertEqual(schema["summary"]["scenario_steps_mapped"], 2)
        self.assertEqual(schema["summary"]["scenario_steps_total"], 3)

    def test_scenario_without_any_node_is_a_path_problem(self):
        scenario = _scenario(["Классификация", "Сборка портфеля"])
        schema = build_passport_map(self._model(normalize_passport(_valid()), scenario))
        [path] = schema["paths"]
        self.assertEqual(path["steps_mapped"], 0)
        self.assertEqual(path["problems"], ["ни один шаг сценария не привязан к узлу схемы"])


_JOURNEY = """\
Клиентский путь: Размещение сбережений
Проект: Демо-проект
## Подбор
- Подобран продукт.
"""


class RenderWithGateTest(unittest.TestCase):

    def _render(self, data):
        model = ProgressModel(meta={}, items={}, verdicts=[])
        model.passport_data = data
        plan = parse_plan_text(_JOURNEY)
        return render_client_journey_passport(
            model, plan, "demo/repo", Extraction(facts=[]),
            commit="abc1234", branch="main",
            llm_values=flatten_passport_data(data) if data else None,
            registry_rows=passport_registry_rows(data) if data else None,
            tree_spec=passport_tree_spec(data) if data else None,
        )

    def test_badge_switches_by_source(self):
        html = self._render(normalize_passport(_valid()))
        self.assertIn(STATUS_BADGE_AGENT, html)
        self.assertNotIn(STATUS_BADGE_TEMPLATE, html)
        html = self._render(None)
        self.assertIn(STATUS_BADGE_FALLBACK, html)

    def test_all_parents_in_registry_and_shared_node_rendered_once(self):
        html = self._render(normalize_passport(_valid()))
        self.assertIn('<td data-col="Родитель">process-1, process-2</td>', html)
        self.assertEqual(html.count('id="bbb-1"'), 1)
        self.assertIn("Ответ по справочнику продуктов", html)
        self.assertIn("bbb.sborka-portfelya", html)
        self.assertIn('"kind_label":"запускает"', html)

    def test_needs_and_guardrails_removed_from_output(self):
        for data in (normalize_passport(_valid()), None):
            html = self._render(data)
            self.assertNotIn('id="related-needs"', html)
            self.assertNotIn('id="related-guardrails"', html)
            self.assertNotIn('id="need-1"', html)
            self.assertNotIn('id="guardrail-1"', html)
            self.assertNotIn('id="tpl-need"', html)
            self.assertNotIn('id="tpl-guardrail"', html)
            # Дерево и остальные заготовки на месте.
            self.assertIn('id="tpl-operation"', html)
            self.assertIn('id="journey-1"', html)

    def test_initiative_basis_in_header(self):
        html = self._render(normalize_passport(_valid()))
        self.assertIn("Образ результата инициативы", html)
        self.assertIn("Размещение сбережений; Подбор; пунктов образа результата: 1", html)

    def test_map_has_no_separate_verdict_and_explains_muted_nodes(self):
        html = self._render(normalize_passport(_valid()))
        self.assertNotIn("Вердикт схемы", html)
        self.assertIn("приглушено — узел вне выбранных сценариев", html)
        self.assertIn("второй родитель", html)
        self.assertIn("связь (вид — по клику на узел)", html)
        self.assertIn("обходного пути нет", html)


if __name__ == "__main__":
    unittest.main()

"""Гейт паспорта клиентского пути: модель предлагает узлы, код проверяет.

Паспорт заполняет агент (`passport_agent`), и без проверки он получается
реверс-инжинирингом кода: BBB остаются без операций, уровни схлопываются,
реестр расходится с деревом, связи ведут в несуществующие узлы, а
«Установлено» стоит там, где источник — строка промпта. Здесь то, что
можно проверить кодом.

Дерево путь → процесс → BBB → операция — **каркас**, а не единственная
форма связи. У узла может быть несколько родителей (общий BBB
«Определение сценария обращения» входит в несколько процессов), а между
узлами внутри процесса действуют связи из закрытого списка
`RELATION_KINDS`: предшествует, запускает, передаёт данные, зависит от,
запасной путь, подтверждает. Первый родитель — место узла в дереве и в
нумерации; остальные и связи — рёбра поверх дерева.

Три функции:

* `check_passport` — проверка готового JSON целиком; поузловые части
  (`check_node_fields`, `check_relation`) зовёт паспортный агент на
  каждом шаге: `errors` — узел отклоняется, `remarks` — принимается,
  замечания идут агенту и в служебные заметки прогона.
* `normalize_passport` — то, чего у модели не спрашивают: сквозная
  нумерация узлов, идентификаторы объектов по единой схеме, реестр,
  выведенный из дерева и связей. Модель присылает дерево, поля и связи,
  реестр строит код — расходиться им негде.
* `journey_name_of` — единственный источник названия пути.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from pko.progress.schema import contains_code
from pko.progress.text_input import slug

NODE_TYPES = ("journey", "process", "bbb", "operation")
TREE_TYPES = NODE_TYPES
CHILD_TYPE = {"journey": "process", "process": "bbb", "bbb": "operation"}
PARENT_TYPE = {"process": "journey", "bbb": "process", "operation": "bbb"}

TYPE_LABEL = {
    "journey": "Клиентский путь",
    "process": "Автономный процесс",
    "bbb": "BBB",
    "operation": "Атомарная операция",
}

DECISION_BOUNDARIES = ("END_TO_END_PROCESS", "COMPONENT_BBB")

# Связи между узлами поверх дерева. Список закрытый: свободная
# формулировка вида превращает схему в мешок стрелок, по которому нельзя
# ни посчитать, ни сравнить два паспорта. `includes` — структурная связь
# «второй родитель»: узел входит ещё в один процесс или BBB.
RELATION_KINDS = (
    "includes",
    "precedes",
    "triggers",
    "feeds",
    "depends_on",
    "fallback",
    "confirms",
)
RELATION_LABEL = {
    "includes": "включает",
    "precedes": "предшествует",
    "triggers": "запускает",
    "feeds": "передаёт данные",
    "depends_on": "зависит от",
    "fallback": "запасной путь для",
    "confirms": "подтверждает",
}
RELATION_HINT = {
    "includes": "узел входит ещё в один процесс или BBB (второй родитель); from — родитель, to — общий узел",
    "precedes": "from выполняется раньше to внутри одного процесса",
    "triggers": "результат from запускает to — событие, переход, вызов другого процесса",
    "feeds": "выход from — вход to (передача данных)",
    "depends_on": "from не может выполниться без результата to (предусловие)",
    "fallback": "from выполняется, когда to отказал или недоступен",
    "confirms": "from — подтверждение клиента или человека, без которого to не выполняется",
}
# Основание связи — одна фраза, но не пустая и не «так устроен код».
MIN_RELATION_BASIS_CHARS = 12

# Уровни обоснования. Каждое «Основание» начинается с одного из них.
SOURCE_LEVELS = (
    "Установлено",
    "Выведено",
    "Гипотеза",
    "Требует подтверждения владельца",
    "Не установлено",
)
# После уровня обязана идти привязка: голое «Выведено» — пустое поле,
# оформленное как заполненное. «Не установлено» без пояснения допускается.
MIN_SOURCE_DETAIL_CHARS = 12

# Поля бизнес-намерения: код их не устанавливает. Владелец подтверждается
# вне кода — «Установлено» здесь означает, что CODEOWNERS выдан за решение
# бизнеса.
INTENT_FIELDS = {
    "4.2.3", "4.3.3", "4.4.3", "4.5.3",  # владельцы
}

# Режимы исполнения BBB (§ 4.3.6) — поле без режима не заполнено.
EXECUTION_MODES = ("HUMAN_ONLY", "ASSIST", "CONFIRM", "AUTO")

# Handoff — передача человеку. Переход между сценариями агента им не является.
_HUMAN_WORDS = re.compile(
    r"человек|оператор|сотрудник|специалист|менеджер|консультант|"
    r"не установлено|неприменимо|нет передачи|передач\w* нет",
    re.IGNORECASE,
)
# Маршрутизатор упоминается в основаниях — значит, он определяет, какой
# процесс запустится, и обязан быть узлом.
_ROUTER_WORDS = re.compile(
    r"классификатор|классификац|маршрутизатор|маршрутизац|роутер|"
    r"\brouter\b|classif|scenario\.py|intent",
    re.IGNORECASE,
)
_ROUTER_NODE_WORDS = re.compile(
    r"классификац|маршрутизац|определение сценария|распознавание (?:запроса|намерения|сценария)",
    re.IGNORECASE,
)
# Компенсация — обратное действие на внешний эффект. Откат статуса в своей
# базе им не является.
_STATUS_WORDS = re.compile(r"статус", re.IGNORECASE)
_COMPENSATION_WORDS = re.compile(
    r"компенсац|возврат|возвращ|отмен|обратн|компенсации нет|не компенсир",
    re.IGNORECASE,
)
_MONEY_WORDS = re.compile(
    r"перевод|платёж|платеж|списан|зачислен|средств|деньг|открыти[ея] (?:продукта|вклада|счёта|счета)",
    re.IGNORECASE,
)


@dataclass
class PassportCheck:
    errors: list[str] = field(default_factory=list)
    remarks: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors


# --- разбор структуры ---------------------------------------------------------

def node_type(node_id: str) -> str:
    for prefix in NODE_TYPES:
        if str(node_id).startswith(prefix + "-"):
            return prefix
    return ""


def _walk(tree: Any) -> list[tuple[str, str | None, int]]:
    """Список (id, parent_id, глубина) в порядке обхода дерева."""
    out: list[tuple[str, str | None, int]] = []

    def visit(node: Any, parent: str | None, depth: int) -> None:
        if not isinstance(node, dict):
            return
        nid = str(node.get("id") or "")
        if nid:
            out.append((nid, parent, depth))
        for child in node.get("children") or []:
            visit(child, nid or parent, depth + 1)

    if isinstance(tree, list):
        for root in tree:
            visit(root, None, 0)
    return out


def _fields(node: dict) -> dict[str, dict]:
    fields = node.get("fields")
    if not isinstance(fields, dict):
        return {}
    return {str(k): v for k, v in fields.items() if isinstance(v, dict)}


def _text(field_obj: dict | None, key: str) -> str:
    if not isinstance(field_obj, dict):
        return ""
    value = field_obj.get(key)
    return value.strip() if isinstance(value, str) else ""


def _links(node: dict, key: str) -> list[str]:
    """Список ссылок на узлы: `parents` у узла дерева."""
    raw = node.get(key)
    if isinstance(raw, str):
        raw = [part.strip() for part in re.split(r"[,;·]", raw)]
    if not isinstance(raw, list):
        return []
    out: list[str] = []
    for x in raw:
        text = str(x).strip()
        if text and text != "—" and text not in out:
            out.append(text)
    return out


def _relations(data: dict) -> list[dict]:
    raw = data.get("relations")
    if not isinstance(raw, list):
        return []
    return [r for r in raw if isinstance(r, dict)]


def _norm_name(name: Any) -> str:
    return re.sub(r"[^\wа-яё]+", " ", str(name or "").lower()).strip()


# --- проверка ------------------------------------------------------------------

def check_passport(data: Any) -> PassportCheck:
    """Проверить паспорт от агента. Пустой `errors` — можно принимать."""
    check = PassportCheck()
    if not isinstance(data, dict) or not data:
        check.errors.append("паспорт должен быть непустым JSON-объектом")
        return check

    nodes = data.get("nodes")
    if not isinstance(nodes, dict) or not nodes:
        check.errors.append("nodes пуст: узлы паспорта не переданы")
        return check
    nodes = {str(k): v for k, v in nodes.items() if isinstance(v, dict)}

    boundary = str(data.get("decision-boundary") or "").strip()
    if boundary and boundary not in DECISION_BOUNDARIES:
        check.errors.append(
            "decision-boundary должен быть одним из: " + ", ".join(DECISION_BOUNDARIES)
        )

    walk = _walk(data.get("tree"))
    _check_tree(check, walk, nodes)
    _check_names(check, nodes, walk)
    _check_parents(check, nodes, walk)
    _check_relations(check, data, nodes)
    _check_fields(check, nodes)
    _check_router(check, nodes)
    return check


def _check_tree(check: PassportCheck, walk: list, nodes: dict) -> None:
    if not walk:
        check.errors.append("tree пуст: нужен хотя бы один узел journey с процессами")
        return
    known = {nid for nid, _, _ in walk}
    children: dict[str, list[str]] = {}
    for nid, parent, _ in walk:
        if parent is not None:
            children.setdefault(parent, []).append(nid)
    # Общий узел (несколько родителей) в дереве стоит под первым, а у
    # остальных родителей числится в `parents`: детей им это тоже даёт.
    for nid, node in nodes.items():
        for parent in _links(node, "parents")[1:]:
            children.setdefault(parent, []).append(nid)

    for nid, parent, _ in walk:
        ntype = node_type(nid)
        if ntype not in TREE_TYPES:
            check.errors.append(
                f"{nid}: в tree допустимы только journey/process/bbb/operation"
            )
            continue
        if nid not in nodes:
            check.errors.append(f"{nid}: есть в tree, но нет в nodes")
        expected_parent = PARENT_TYPE.get(ntype)
        parent_type = node_type(parent) if parent else None
        if parent_type != expected_parent:
            check.errors.append(
                f"{nid}: родитель должен быть типа {expected_parent or 'нет (корень)'}, "
                f"а стоит {parent or 'корень'}"
            )
        if ntype == "bbb" and not children.get(nid):
            check.errors.append(
                f"{nid}: BBB без атомарных операций. Уровень BBB промежуточный: "
                "заведи хотя бы одну операцию — шаг, который отдаёт результат "
                "блока наружу (расчёт, сообщение клиенту, перевод, открытие продукта, "
                "запись). Кандидаты обычно уже перечислены в «Способах исполнения» "
                "этого же блока"
            )
        if ntype == "process" and not children.get(nid):
            check.errors.append(f"{nid}: процесс без BBB")
        if ntype == "journey" and not children.get(nid):
            check.errors.append(f"{nid}: клиентский путь без процессов")

    for nid, node in nodes.items():
        if node_type(nid) not in TREE_TYPES:
            check.errors.append(
                f"{nid}: тип узла не опознан. В паспорте только journey/process/bbb/operation; "
                "потребности клиента и ограничения исполнения отдельными узлами не заводятся"
            )
        elif nid not in known:
            check.errors.append(f"{nid}: есть в nodes, но не входит в tree")


def _check_names(check: PassportCheck, nodes: dict, walk: list) -> None:
    """Узел не дублирует родителя и не совпадает по названию с другим узлом."""
    names: dict[str, str] = {}
    for nid, node in nodes.items():
        name = _norm_name(node.get("name"))
        if not name:
            check.errors.append(f"{nid}: нет названия (name)")
            continue
        if name in names:
            check.errors.append(duplicate_name_message(nid, names[name], str(node.get("name"))))
        names.setdefault(name, nid)

    by_id = {nid: parent for nid, parent, _ in walk}
    children: dict[str, list[str]] = {}
    for nid, parent in by_id.items():
        if parent:
            children.setdefault(parent, []).append(nid)
    for parent, kids in children.items():
        if len(kids) != 1 or node_type(parent) != "process":
            continue
        kid = kids[0]
        p_basis = _norm_name(nodes.get(parent, {}).get("basis"))
        k_basis = _norm_name(nodes.get(kid, {}).get("basis"))
        if p_basis and p_basis == k_basis:
            check.errors.append(collapsed_level_message(parent, kid))


def _check_parents(check: PassportCheck, nodes: dict, walk: list) -> None:
    """`parents` согласован с деревом: первый родитель — тот, что в tree,
    остальные — существующие узлы уровнем выше."""
    tree_parent = {nid: parent for nid, parent, _ in walk}
    for nid, node in nodes.items():
        parents = _links(node, "parents")
        if not parents:
            continue
        expected = tree_parent.get(nid)
        if expected and parents[0] != expected:
            check.errors.append(
                f"{nid}: первый в parents должен быть родителем из tree ({expected}), "
                f"а стоит {parents[0]}"
            )
        for parent in parents:
            problem = parent_link_problem(nid, parent, set(nodes))
            if problem:
                check.errors.append(problem)


def parent_link_problem(nid: str, parent: str, known: set[str]) -> str:
    """Почему `parent` не может быть родителем `nid` (пусто — может)."""
    if parent not in known:
        return f"{nid}: родитель {parent} не существует"
    expected = PARENT_TYPE.get(node_type(nid))
    if node_type(parent) != expected:
        return (f"{nid}: родитель должен быть типа {expected or 'нет (корень)'}, "
                f"а {parent} — {node_type(parent) or '?'}")
    return ""


def duplicate_name_message(nid: str, other: str, name: str) -> str:
    return (
        f"{nid} и {other} названы одинаково («{name}»): "
        "это один объект, записанный на двух уровнях. Оставь один узел "
        "или назови ребёнка по его собственному действию"
    )


def collapsed_level_message(parent: str, kid: str) -> str:
    return (
        f"{parent} и {kid}: у процесса один BBB с тем же основанием "
        "существования — средний уровень пустой. Разбей процесс на "
        "блоки с разными действиями или объясни в basis, чем блок отличается"
    )


def norm_name(name: Any) -> str:
    return _norm_name(name)


def _check_relations(check: PassportCheck, data: dict, nodes: dict) -> None:
    seen: set[tuple[str, str, str]] = set()
    for rel in _relations(data):
        check_relation(check, rel, set(nodes), seen)


def check_relation(check: PassportCheck, rel: dict, known: set[str],
                   seen: set[tuple[str, str, str]] | None = None) -> None:
    """Одна связь: узлы существуют, вид из списка, основание есть,
    `includes` идёт от узла уровнем выше, дубли не принимаются."""
    src = str(rel.get("from") or "").strip()
    dst = str(rel.get("to") or "").strip()
    kind = str(rel.get("kind") or "").strip()
    basis = str(rel.get("basis") or "").strip()
    label = f"связь {src or '?'} → {dst or '?'}"
    if kind not in RELATION_KINDS:
        check.errors.append(
            f"{label}: вид «{kind}» не из списка. Допустимы: "
            + ", ".join(f"{k} ({RELATION_LABEL[k]})" for k in RELATION_KINDS)
        )
    for nid in (src, dst):
        if nid not in known:
            check.errors.append(f"{label}: узла {nid or '?'} нет")
        elif node_type(nid) == "journey":
            check.errors.append(f"{label}: связи между клиентским путём и узлами не заводятся — путь и так содержит всё дерево")
    if src and src == dst:
        check.errors.append(f"{label}: связь узла с самим собой")
    if kind == "includes" and src in known and dst in known:
        problem = parent_link_problem(dst, src, known)
        if problem:
            check.errors.append(f"{label}: includes — второй родитель; {problem}")
    if len(basis) < MIN_RELATION_BASIS_CHARS:
        check.errors.append(
            f"{label}: нет basis — одной фразы, откуда связь следует (какой факт кода или "
            "образа результата её показывает)"
        )
    key = (src, dst, kind)
    if seen is not None:
        if key in seen:
            check.errors.append(f"{label} ({kind}) уже объявлена")
        seen.add(key)


def _check_fields(check: PassportCheck, nodes: dict) -> None:
    for nid, node in nodes.items():
        check_node_fields(check, nid, node)


def check_node_fields(check: PassportCheck, nid: str, node: dict) -> None:
    """Поля одного узла: уровни оснований, ⚑-поля, режим, handoff, компенсация."""
    ntype = node_type(nid)
    fields = _fields(node)
    for fid, fobj in fields.items():
        value = _text(fobj, "value")
        source = _text(fobj, "source")
        if not value and not source:
            continue
        level = _source_level(source)
        if level is None:
            check.errors.append(
                f"{nid} {fid}: основание должно начинаться с уровня "
                "(Установлено: / Выведено: / Гипотеза: / Требует подтверждения "
                f"владельца: / Не установлено:), а не «{source[:40]}»"
            )
            continue
        detail = source[len(level):].lstrip(" :·—-")
        if level != "Не установлено" and len(detail) < MIN_SOURCE_DETAIL_CHARS:
            check.errors.append(
                f"{nid} {fid}: «{level}» без привязки. После уровня — что "
                "именно и где найдено (файл, функция, факт) или чем можно проверить"
            )
        if fid in INTENT_FIELDS and level == "Установлено":
            check.errors.append(
                f"{nid} {fid}: бизнес-намерение (владелец) кодом не "
                "устанавливается. Уровень — «Требует подтверждения владельца:» "
                "или «Гипотеза:», предложение — в значении"
            )
    if ntype == "process":
        modes = _text(fields.get("4.3.6"), "value")
        if modes and not any(m in modes.upper() for m in EXECUTION_MODES):
            check.errors.append(
                f"{nid} 4.3.6: не назван режим исполнения. Для каждого BBB "
                "укажи максимум из HUMAN_ONLY / ASSIST / CONFIRM / AUTO по факту "
                "кода: ждёт ли он подтверждения человека перед действием"
            )
        handoff = _text(fields.get("4.3.8"), "value")
        if handoff and not _HUMAN_WORDS.search(handoff):
            check.remarks.append(
                f"{nid} 4.3.8: handoff — передача управления человеку (оператору, "
                "специалисту), а не переход между сценариями агента. Если "
                "передачи человеку в коде нет — так и напиши: «Не установлено: "
                "передачи человеку нет, клиент остаётся с ботом»"
            )
    if ntype == "operation":
        comp = _text(fields.get("4.5.6"), "value")
        effect = _text(fields.get("4.5.4"), "value") + " " + _text(fields.get("4.5.1"), "value")
        if (comp and _STATUS_WORDS.search(comp) and not _COMPENSATION_WORDS.search(comp)
                and _MONEY_WORDS.search(effect)):
            check.remarks.append(
                f"{nid} 4.5.6: откат статуса — не компенсация. Операция двигает "
                "деньги или открывает продукт: скажи прямо, есть ли обратное "
                "действие на внешний эффект, и что происходит с уже выполненной "
                "частью при ошибке следующего шага"
            )


def check_router_present(check: PassportCheck, nodes: dict) -> None:
    """Классификатор упоминается в основаниях — он обязан быть узлом."""
    _check_router(check, nodes)


def _check_router(check: PassportCheck, nodes: dict) -> None:
    """Классификатор упоминается в основаниях — он обязан быть узлом."""
    mentioned = False
    for node in nodes.values():
        for fobj in _fields(node).values():
            if _ROUTER_WORDS.search(_text(fobj, "source")):
                mentioned = True
                break
        if mentioned:
            break
    if not mentioned:
        return
    for nid, node in nodes.items():
        if node_type(nid) not in ("process", "bbb"):
            continue
        haystack = " ".join([str(node.get("name") or ""), str(node.get("basis") or "")])
        if _ROUTER_NODE_WORDS.search(haystack):
            return
    check.remarks.append(
        "классификатор или маршрутизатор сценария упоминается в основаниях, но "
        "узла для него нет. Он решает, какой процесс запустится, — самый "
        "рискованный компонент решения. Заведи BBB «Определение сценария "
        "обращения» и свяжи его с процессами, которые он запускает (triggers)"
    )


def _source_level(source: str) -> str | None:
    for level in SOURCE_LEVELS:
        if source.startswith(level):
            return level
    return None


# --- нормализация --------------------------------------------------------------

def normalize_passport(data: dict) -> dict:
    """Сквозная нумерация, единая схема ID объектов, реестр из дерева и связей.

    Модель присылает `tree`, `nodes` (с `parents` у общих узлов) и
    `relations`. Всё остальное строит код:

    * узлы нумеруются по порядку обхода дерева: journey-1, process-1…,
      bbb-1…, operation-1… — заготовки шаблона всегда заняты, «дыр» нет;
    * `object-id` = `<тип>.<слаг названия>`: единая схема, по которой
      паспорта разных инициатив можно сшить;
    * `parents` у каждого узла дерева: первый — родитель из tree, дальше
      остальные из присланного списка; в реестре столбец «Родитель» —
      все через запятую;
    * `relations` переименовываются вместе с узлами, вид получает подпись;
    * `registry` выводится из дерева и связей.
    """
    nodes_in = {str(k): v for k, v in (data.get("nodes") or {}).items() if isinstance(v, dict)}
    walk = _walk(data.get("tree"))

    counters: dict[str, int] = {}
    rename: dict[str, str] = {}

    def assign(old: str) -> str:
        if old in rename:
            return rename[old]
        ntype = node_type(old)
        counters[ntype] = counters.get(ntype, 0) + 1
        rename[old] = f"{ntype}-{counters[ntype]}"
        return rename[old]

    for nid, _, _ in walk:
        assign(nid)

    def rebuild(node: Any) -> dict | None:
        if not isinstance(node, dict) or not node.get("id"):
            return None
        new = {"id": rename[str(node["id"])], "type": node_type(str(node["id"]))}
        kids = [rebuild(c) for c in node.get("children") or []]
        kids = [k for k in kids if k]
        if kids or new["type"] != "operation":
            new["children"] = kids
        return new

    tree = [t for t in (rebuild(r) for r in data.get("tree") or []) if t]

    tree_parent = {nid: parent for nid, parent, _ in walk}
    agent_basis = {
        str(row.get("id")): str(row.get("basis") or "")
        for row in data.get("registry") or [] if isinstance(row, dict)
    }
    nodes_out: dict[str, dict] = {}
    for old, node in nodes_in.items():
        if old not in rename:
            continue  # узел дерева, которого нет в tree — проверка его уже отклонила
        new_id = rename[old]
        ntype = node_type(new_id)
        out = dict(node)
        out["object-id"] = f"{ntype}.{slug(str(node.get('name') or new_id))}"
        out["basis"] = str(node.get("basis") or agent_basis.get(old) or "")
        parents: list[str] = []
        primary = tree_parent.get(old)
        if primary and primary in rename:
            parents.append(rename[primary])
        for extra in _links(node, "parents"):
            renamed = rename.get(extra)
            if renamed and renamed not in parents and renamed != new_id:
                parents.append(renamed)
        out["parents"] = parents
        nodes_out[new_id] = out

    relations: list[dict] = []
    seen: set[tuple[str, str, str]] = set()
    for rel in _relations(data):
        src, dst = rename.get(str(rel.get("from") or "")), rename.get(str(rel.get("to") or ""))
        kind = str(rel.get("kind") or "")
        if not src or not dst or kind not in RELATION_KINDS or (src, dst, kind) in seen:
            continue
        seen.add((src, dst, kind))
        relations.append({
            "from": src, "to": dst, "kind": kind,
            "kind_label": RELATION_LABEL[kind],
            "basis": str(rel.get("basis") or ""),
        })
        # `includes` — структурная связь: второй родитель попадает в `parents`
        # узла, чтобы реестр и схема видели его без разбора relations.
        if kind == "includes" and dst in nodes_out and src not in nodes_out[dst]["parents"]:
            nodes_out[dst]["parents"].append(src)

    order = [rename[nid] for nid, _, _ in walk]
    registry = []
    for nid in order:
        node = nodes_out.get(nid, {})
        ntype = node_type(nid)
        registry.append({
            "id": nid,
            "type": TYPE_LABEL[ntype],
            "name": str(node.get("name") or ""),
            "parent": ", ".join(node.get("parents") or []) or "—",
            "basis": str(node.get("basis") or ""),
        })

    out = {k: v for k, v in data.items() if k not in ("tree", "nodes", "registry", "relations")}
    out["tree"] = tree
    out["nodes"] = nodes_out
    out["relations"] = relations
    out["registry"] = registry
    return out


def journey_name_of(ctx: dict[str, str], repo_name: str = "") -> str:
    """Название клиентского пути — из образа результата (`client_path_name`).

    Один источник для заголовка паспорта, корня дерева и брифа паспортного
    агента: иначе путь назывался то именем проекта, то именем репозитория.
    """
    return ctx.get("client_path_name") or ctx.get("project_name") or repo_name or "—"

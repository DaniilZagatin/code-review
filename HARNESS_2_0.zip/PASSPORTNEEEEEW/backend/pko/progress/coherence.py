"""Ревизия связности: складываются ли сделанные пункты в работающую систему.

Первый агент отвечает на вопрос «сделан ли этот пункт», рецензент
(`progress.critic`) — «правда ли он сделан». Ни тот, ни другой не отвечают на
третий: **соединены ли сделанные пункты между собой.**

Разница не теоретическая. Код можно написать по каждому буллиту образа
результата и не соединить: узел графа никто не вызывает, результат никуда не
уходит, «оркестратор» переключает три режима вместо управления агентами,
данные клиента принимаются и не используются, в каталоге лежит один продукт
из трёх обещанных. Постатейно такая система набирает высокий процент, а
замысла инициативы не выполняет — и читатель отчёта этого не видит, потому
что каждый отдельный пункт закрыт честно.

Ревизор смотрит на целое и делает три вещи:

1. **Прослеживает сквозной путь** (`submit_flow`): что запускает систему,
   какие шаги проходит, что получает пользователь. Не может назвать точку
   входа и довести цепочку до результата — это и есть главный ответ.
2. **Называет изъяны** (`submit_flaw`): вид из закрытого списка
   (`schema.FLAW_KINDS`), вес, заголовок, объяснение человеческим языком и
   подтверждённая ссылка. По одному вызову на изъян.
3. **Выносит уровень связности** (`submit_integrity`): `coherent` /
   `fragmented` / `disconnected` плюс фраза.
4. **Измеряет сквозную связность** (`progress.connectivity`): выводит
   целевые сценарии из образа результата (`submit_scenarios`) и прослеживает
   стыки каждого (`submit_trace`). Статусы сценариев и процент считает код.

Ограничения — те же, что у первых двух агентов:

* **Ни одного числа он не меняет.** Готовность, решение и статусы буллитов
  остаются как есть: изъян связности — это не статус пункта, и пересчитывать
  им проценты значит завести вторую шкалу поверх первой. Ревизия идёт
  отдельным блоком карточки.
* **Изъян без проверенной ссылки не принимается.** Отсутствие связи
  доказывается местом, где связь должна была быть, и оно проверяется
  `verify.verify_evidence`.
* **Тексты проходят те же сторожа**: без кода в тексте для читателя
  (`schema.contains_code`), без ссылок на несуществующие файлы
  (`report.guard.check_explanation`).
* **Пункты образа результата ревизор не переписывает.** В `bullets` он
  называет затронутые пункты, а в карточку идёт дословный текст из плана:
  несопоставленное отбрасывается.
* **Уровень не спорит со списком изъянов** — `schema.integrity_level_problem`
  проверяет это детерминированно, а не на глаз.

Выключается `PKO_COHERENCE=false`; бюджеты — `PKO_COHERENCE_STEPS`,
`PKO_COHERENCE_SECONDS`.
"""

from __future__ import annotations

import os
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from pko.extractors.base import Tree
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.harness import (
    harden_tool_schemas,
    parse_tool_call,
    tool_message,
)
from pko.llm.registry import ModelSpec
from pko.llm.runtime import (
    AgentLoopConfig,
    AgentLoopHooks,
    AgentRunStats,
    StopReason,
    run_agent_loop,
)
from pko.progress.agent_tools import TOOL_SCHEMAS as REPO_TOOL_SCHEMAS, ToolBox
from pko.progress.connectivity import (
    CONNECTIVITY_TOOL_SCHEMAS,
    ConnectivityState,
    brief_lines as connectivity_brief_lines,
    finish_problem as connectivity_finish_problem,
    handle_scenarios,
    handle_trace,
)
from pko.progress.matcher import (
    max_tokens_for,
    AgentResult,
    _cap_tool_result,
    _capability_digest,
    _clip,
    _parse_evidence,
)
from pko.progress.schema import (
    FLAW_KINDS,
    FLAW_SEVERITIES,
    INTEGRITY_LEVELS,
    PURPOSE_VERDICTS,
    STATUS_LABEL,
    ConnectivityReview,
    FlowTrace,
    IntegrityReview,
    ItemVerdict,
    PlanItem,
    SystemFlaw,
    SystemPurpose,
    contains_code,
    integrity_level_problem,
    purpose_verdict_problem,
)
from pko.report.guard import check_explanation

_PROMPT_PATH = Path(__file__).parent / "coherence_system.md"

# Ревизору нужно пройти сквозной путь и проверить стыки: это больше чтения,
# чем у рецензента (тот работает по готовому списку мест), но меньше, чем у
# первого агента — искать реализацию заново он не обязан.
DEFAULT_COHERENCE_STEPS = 40
DEFAULT_COHERENCE_SECONDS = 900
_MALFORMED_LIMIT = 3
_REPEAT_LIMIT = 3

# Сколько изъянов доезжает до карточки. Блок на два десятка пунктов читатель
# не прочтёт, а ревизор при желании найдёт бесконечно много: потолок заставляет
# называть главное. Лишние отклоняются с объяснением, а не режутся молча.
_MAX_FLAWS = 12
_MIN_DETAIL_CHARS = 120
_MAX_DETAIL_CHARS = 600
# Суммарная логика проекта: короче двухсот символов это не описание системы, а
# ярлык; длиннее семисот читатель карточки не прочтёт.
_MIN_DOES_CHARS = 200
_MAX_DOES_CHARS = 700
_MAX_TITLE_CHARS = 80
_MIN_NOTE_CHARS = 60
_MAX_NOTE_CHARS = 400
_MAX_FLOW_STEP_CHARS = 160
_MIN_FLOW_STEPS = 2
_MAX_FLOW_STEPS = 7
# Сколько пунктов образа результата показываем ревизору. Больше — в бюджет
# истории, и первым делом выпадет то, ради чего он позван.
_MAX_BRIEF_BULLETS = 60
# Сколько файлов показываем в карте подтверждений.
_MAX_MAP_ROWS = 24

_FALLBACK_PROMPT = (
    "Ты — ревизор связности. Проследи сквозной путь системы по коду "
    "(submit_flow), назови изъяны связности (submit_flaw) и вынеси уровень "
    "(submit_integrity). Закончи вызовом finish."
)

_NUDGE = (
    "Нужно вызвать инструмент: read_file / search / who_calls / show_facts для "
    "проверки, submit_scenarios для целевых сценариев, submit_trace по стыкам "
    "каждого, submit_flow для сквозного пути, submit_flaw для изъяна, "
    "submit_integrity для уровня связности, finish в конце."
)

_SUBMIT_SYSTEM_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_system",
        "description": (
            "ПЕРВЫЙ вызов ревизии. Прочитай код и скажи своими словами, что эта "
            "система делает на самом деле — не по названию инициативы и не по "
            "списку пунктов, а по устройству кода. Это суммарная логика всего "
            "проекта: ради чего он написан и как работает как целое."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "does": {
                    "type": "string",
                    "description": (
                        "Что система делает на самом деле: 200–700 символов, две-четыре "
                        "фразы. Кому и какую задачу решает, из чего берёт данные, что "
                        "выдаёт на выходе, чем является по сути — помощник человека, "
                        "автономный агент, расчётный сервис, витрина данных. "
                        "Человеческим языком, без имён функций, путей и декораторов."
                    ),
                },
                "not_does": {
                    "type": "string",
                    "description": (
                        "Чего система НЕ делает из того, что обещает инициатива: "
                        "120–500 символов. Не перечисление незакрытых пунктов, а "
                        "главное расхождение между замыслом и тем, чем система "
                        "оказалась. Если расхождений нет — так и напиши одной фразой "
                        "и поставь verdict=same_purpose."
                    ),
                },
                "verdict": {
                    "type": "string", "enum": list(PURPOSE_VERDICTS),
                    "description": (
                        "same_purpose — система решает ту задачу, ради которой инициатива "
                        "затевалась, пусть и не целиком. "
                        "narrower — решает узкую часть задачи: например, обещан автономный "
                        "агент, а сделан подсказчик для сотрудника. "
                        "different — код решает другую задачу; требует изъяна scope_mismatch."
                    ),
                },
                "evidence": {
                    "type": "array",
                    "description": "Места, по которым ты это понял: точка входа, ядро обработки, "
                                   "выход результата. Минимум одна проверенная ссылка.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string"},
                            "line": {"type": "integer"},
                            "basis": {"type": "string", "description": "имя функции/класса/маршрута рядом со строкой"},
                            "note": {"type": "string", "description": "что здесь происходит, одной фразой"},
                        },
                    },
                },
            },
            "required": ["does", "not_does", "verdict", "evidence"],
        },
    },
}

_SUBMIT_FLOW_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_flow",
        "description": (
            "Сквозной путь системы, прослеженный по коду: что её запускает, "
            "какие шаги она проходит и что в итоге получает пользователь. "
            "Вызови ОДИН раз, до submit_integrity. Если путь рвётся — всё "
            "равно вызови, с complete=false и указанием места обрыва: "
            "ненайденный сквозной путь и есть главный ответ ревизии."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "entry": {
                    "type": "string",
                    "description": "Что запускает работу: запрос пользователя, сообщение из очереди, "
                                   "событие внешней системы, расписание. Человеческим языком, без имён "
                                   "функций и путей.",
                },
                "steps": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "2–7 шагов по порядку, каждый одной фразой: что происходит с данными "
                                   "от входа к результату. Без имён функций, файлов и декораторов.",
                },
                "outcome": {
                    "type": "string",
                    "description": "Что получает пользователь или система-потребитель на выходе.",
                },
                "complete": {
                    "type": "boolean",
                    "description": "true — путь проходит от входа до результата целиком; false — рвётся.",
                },
                "break_point": {
                    "type": "string",
                    "description": "ОБЯЗАТЕЛЬНО при complete=false: на каком шаге и почему рвётся путь. "
                                   "Человеческим языком.",
                },
                "evidence": {
                    "type": "array",
                    "description": "Ссылки, по которым прослежен путь: минимум точка входа. Проверяются кодом.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string"},
                            "line": {"type": "integer"},
                            "basis": {"type": "string", "description": "имя функции/класса/маршрута рядом со строкой"},
                            "note": {"type": "string", "description": "что здесь происходит, одной фразой"},
                        },
                    },
                },
            },
            "required": ["entry", "steps", "outcome", "complete", "evidence"],
        },
    },
}

_SUBMIT_FLAW_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_flaw",
        "description": (
            "Один изъян связности. По вызову на изъян, до submit_integrity. "
            "Изъян — это НЕ «пункт не сделан» (это уже посчитано статусами), а "
            "«сделанное не соединено»: цепочка рвётся, результат никуда не "
            "уходит, данные принимаются и не используются, оркестратор ничем "
            "не управляет, каталог пуст. Каждый изъян требует подтверждённой "
            "ссылки на место, где связь должна была быть."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "kind": {
                    "type": "string", "enum": list(FLAW_KINDS),
                    "description": (
                        "broken_chain — сквозной путь рвётся между шагами. "
                        "no_orchestration — «оркестратор» ничем не управляет: нет ветвления, "
                        "нет вызова отдельных навыков. "
                        "state_lost — состояние между шагами не передаётся, каждый шаг начинает с нуля. "
                        "one_way_integration — из системы читают, а обещанного действия (записи, "
                        "создания задачи, отправки) нет. "
                        "result_not_delivered — результат считается, но до названного в инициативе "
                        "потребителя не доходит. "
                        "data_not_used — данные принимаются или собираются, но в расчёт и в промпт не идут. "
                        "stub_on_seam — на стыке частей заглушка: пустой метод, заготовленный ответ, мок. "
                        "catalog_empty — инфраструктура на несколько сущностей есть, наполнена одна. "
                        "manual_trigger — обещана автономность, а запуск только ручной: нет триггера, "
                        "расписания, подписки на событие. "
                        "duplicate_logic — одно и то же сделано дважды и по-разному, ветки расходятся. "
                        "scope_mismatch — код решает соседнюю задачу, а не заявленную. "
                        "no_feedback_loop — система действует, но результат действия не проверяет."
                    ),
                },
                "severity": {
                    "type": "string", "enum": list(FLAW_SEVERITIES),
                    "description": (
                        "blocker — пока это так, замысел инициативы не выполняется. "
                        "major — заметная часть замысла не работает. "
                        "minor — изъян реальный, но сквозной путь проходит."
                    ),
                },
                "title": {
                    "type": "string",
                    "description": "Заголовок изъяна: до 80 символов, назывной фразой, без кода. "
                                   "«Профиль клиента собирается, но в подбор продуктов не попадает».",
                },
                "detail": {
                    "type": "string",
                    "description": (
                        "Что именно не соединено и чем это грозит замыслу — 120–600 символов, "
                        "человеческим языком, для читателя без технического контекста. Два "
                        "утверждения: (1) что есть и работает, (2) где обрыв. ЗАПРЕЩЕНЫ имена "
                        "функций, классов, файлов, пути, декораторы и snake_case."
                    ),
                },
                "bullets": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Пункты образа результата, которых изъян касается — дословно из "
                                   "списка выше. Несопоставленные будут отброшены.",
                },
                "evidence": {
                    "type": "array",
                    "description": "Минимум одна ссылка на место обрыва: где связь должна была быть "
                                   "и её нет, где лежит заглушка, где результат теряется.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string"},
                            "line": {"type": "integer"},
                            "basis": {"type": "string", "description": "имя функции/класса/таблицы рядом со строкой"},
                            "note": {"type": "string", "description": "что здесь происходит, одной фразой"},
                        },
                    },
                },
            },
            "required": ["kind", "severity", "title", "detail", "evidence"],
        },
    },
}

_SUBMIT_INTEGRITY_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_integrity",
        "description": (
            "Уровень связности решения — ОДИН раз, после submit_flow и всех "
            "submit_flaw, перед finish. Уровень обязан согласовываться со "
            "списком изъянов: «связное» при блокере или существенном изъяне не "
            "принимается, «не собрано» без блокера — тоже."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "level": {
                    "type": "string", "enum": list(INTEGRITY_LEVELS),
                    "description": (
                        "coherent — сквозной путь проходит целиком, части соединены; "
                        "fragmented — части работают, но соединены не все, путь рвётся; "
                        "disconnected — единого решения нет, набор частей без сквозного пути."
                    ),
                },
                "note": {
                    "type": "string",
                    "description": "60–400 символов: что система представляет собой как целое и чего "
                                   "ей не хватает, чтобы замысел инициативы выполнялся. Человеческим "
                                   "языком, без имён функций и путей.",
                },
            },
            "required": ["level", "note"],
        },
    },
}

_FINISH_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "finish",
        "description": "Вызови, когда прослежен путь, названы изъяны и вынесен уровень связности.",
        "parameters": {"type": "object", "properties": {}},
    },
}

_COHERENCE_TOOL_SCHEMAS: list[dict[str, Any]] = harden_tool_schemas(
    REPO_TOOL_SCHEMAS
    + [_SUBMIT_SYSTEM_SCHEMA]
    + CONNECTIVITY_TOOL_SCHEMAS
    + [_SUBMIT_FLOW_SCHEMA, _SUBMIT_FLAW_SCHEMA, _SUBMIT_INTEGRITY_SCHEMA, _FINISH_SCHEMA]
)


def coherence_enabled() -> bool:
    """`PKO_COHERENCE`: выключить ревизию можно только явно."""
    raw = (os.environ.get("PKO_COHERENCE") or "").strip().lower()
    return raw not in ("0", "false", "no", "off")


def _env_int(name: str, default: int) -> int:
    raw = (os.environ.get(name) or "").strip()
    try:
        return max(0, int(raw)) if raw else default
    except ValueError:
        return default


def load_coherence_prompt() -> tuple[str, bool]:
    """Системный промпт ревизора и признак, что файл найден."""
    try:
        return _PROMPT_PATH.read_text(encoding="utf-8"), True
    except OSError:
        return _FALLBACK_PROMPT, False


@dataclass
class CoherenceOutcome:
    """Итог ревизии: разбор для карточки и заметки для того, кто прогон
    запускал."""

    review: IntegrityReview | None = None
    connectivity: ConnectivityReview | None = None
    notes: list[str] = field(default_factory=list)
    runtime_stats: dict[str, Any] = field(default_factory=dict)


def _plan_bullets(plan: list[PlanItem], verdicts: list[ItemVerdict]) -> list[tuple[str, str]]:
    """Пары «текст буллита → итоговый статус» по применимым этапам.

    Статусы уже прошли рецензента: ревизор должен видеть картину такой, какой
    её увидит читатель отчёта, а не такой, какой она была до понижений.
    """
    by_id = {item.id: item for item in plan}
    rows: list[tuple[str, str]] = []
    for verdict in verdicts:
        item = by_id.get(verdict.item_id)
        if item is None or not verdict.applicable:
            continue
        for text, criterion in zip(item.criteria, verdict.criteria):
            if not criterion.applicable:
                continue
            rows.append((str(text), criterion.status))
    return rows


def evidence_map(verdicts: list[ItemVerdict]) -> list[tuple[str, int]]:
    """Где лежат подтверждения: файл → сколько буллитов он закрывает.

    Детерминированный счёт, а не суждение. Он отвечает на вопрос, который
    модели задавать бессмысленно: разбросана ли реализация по несвязанным
    кускам или собрана в одном месте. Один файл на двенадцать буллитов — это
    один модуль, который делает всё; двенадцать файлов по одному — повод
    проверить, соединены ли они между собой.
    """
    counter: Counter[str] = Counter()
    for verdict in verdicts:
        if not verdict.applicable:
            continue
        for criterion in verdict.criteria:
            if not criterion.applicable:
                continue
            for path in {e.path for e in criterion.verified_evidence if e.path}:
                counter[path] += 1
    return counter.most_common()


def build_coherence_brief(
    plan: list[PlanItem],
    verdicts: list[ItemVerdict],
    context: dict[str, str] | None = None,
    match: str = "",
    match_note: str = "",
    extraction: Extraction | None = None,
) -> str:
    """Задание ревизору: образ результата с итоговыми статусами, карта
    подтверждений, карта возможностей репозитория."""
    context = context or {}
    bullets = _plan_bullets(plan, verdicts)
    lines = [
        "Постатейный разбор закончен. Твоя работа — проверить, складываются ли "
        "закрытые пункты в работающую систему: пройти сквозной путь по коду, "
        "назвать изъяны связности и вынести уровень.",
        "",
    ]
    name = context.get("project_name") or context.get("client_path_name")
    if name:
        lines.append(f"Инициатива: {name}")
    for key, label in (("before", "Было"), ("now", "Сейчас"), ("after", "Стало")):
        if context.get(key):
            lines.append(f"{label}: {context[key]}")
    if match_note:
        lines.append(f"Оценка целого от первого агента: {match_note}")
    lines.append("")

    lines.append("Образ результата и статусы после проверки:")
    for index, (text, status) in enumerate(bullets[:_MAX_BRIEF_BULLETS], start=1):
        label = STATUS_LABEL.get(status, status)
        lines.append(f"{index}. [{label}] {text}")
    if len(bullets) > _MAX_BRIEF_BULLETS:
        lines.append(f"…и ещё {len(bullets) - _MAX_BRIEF_BULLETS} пунктов")
    lines.append("")

    rows = evidence_map(verdicts)
    if rows:
        lines.append(
            "Где лежат подтверждения (файл — сколько пунктов он закрывает). "
            "Это подсказка, где искать стыки: соседние по файлу пункты обязаны "
            "быть соединены, разнесённые — повод проверить, вызывают ли они "
            "друг друга."
        )
        for path, count in rows[:_MAX_MAP_ROWS]:
            lines.append(f"- {path} — пунктов: {count}")
        if len(rows) > _MAX_MAP_ROWS:
            lines.append(f"- …и ещё файлов: {len(rows) - _MAX_MAP_ROWS}")
        lines.append("")

    inventory = _capability_digest(extraction)
    if inventory:
        lines.append(inventory)
        lines.append("")

    lines.extend(connectivity_brief_lines())
    lines.append("")
    lines.append(
        "Начни с точки входа: найди, что запускает систему, пройди цепочку до "
        "результата и пойми, чем этот код является как целое. Затем проверь "
        "стыки по чек-листу из инструкции. Порядок вызовов: submit_system → "
        "submit_scenarios → submit_trace по каждому сценарию → submit_flow → "
        "submit_flaw по каждому изъяну → submit_integrity → finish."
    )
    return "\n".join(lines)


@dataclass
class _Session:
    plan_bullets: list[str]
    tree: Tree
    tools: ToolBox
    purpose: SystemPurpose | None = None
    flow: FlowTrace | None = None
    flaws: list[SystemFlaw] = field(default_factory=list)
    level: str = ""
    note: str = ""
    rejected: int = 0
    notes: list[str] = field(default_factory=list)
    finished: bool = False
    runtime_stats: dict[str, Any] = field(default_factory=dict)
    # Целевые сценарии и стыки — счётная часть ревизии (`connectivity`).
    connectivity: ConnectivityState | None = None


def _clean(value: object, limit: int) -> str:
    return _clip(" ".join(str(value or "").split()), limit)


def _text_problem(label: str, value: str, tree: Tree) -> str:
    """Общие сторожа текста для читателя: код внутри и несуществующие пути."""
    code = contains_code(value)
    if code:
        return (f"{label} содержит код («{code}») — перепиши обычными словами: "
                "путь и строку положи в evidence, читателю отчёта имя функции "
                "ничего не объясняет")
    violations = check_explanation(value, tree.files_set)
    if violations:
        return f"{label}: " + "; ".join(v.render() for v in violations)
    return ""


def _match_bullets(raw: object, plan_bullets: list[str]) -> list[str]:
    """Сопоставить названные пункты с планом. Тексты в карточку идут из плана,
    а не из ответа модели: пересказанный буллит — это уже не буллит."""
    if not isinstance(raw, list):
        return []
    normalized = {re.sub(r"\W+", "", text).lower(): text for text in plan_bullets}
    out: list[str] = []
    for entry in raw:
        key = re.sub(r"\W+", "", str(entry or "")).lower()
        if not key:
            continue
        hit = normalized.get(key)
        if hit is None:
            # Модель почти всегда цитирует пункт не дословно: ищем вхождение в
            # обе стороны, но берём всё равно текст плана.
            for norm_key, text in normalized.items():
                if key and (key in norm_key or norm_key in key):
                    hit = text
                    break
        if hit is not None and hit not in out:
            out.append(hit)
    return out


def _handle_system(state: _Session, args: dict) -> str:
    """`submit_system` — что система делает на самом деле, по коду."""
    does = _clean(args.get("does"), _MAX_DOES_CHARS)
    not_does = _clean(args.get("not_does"), _MAX_DETAIL_CHARS)
    if len(does) < _MIN_DOES_CHARS:
        state.rejected += 1
        return (f"описание отклонено: «что делает» слишком короткое ({len(does)} симв., "
                f"нужно от {_MIN_DOES_CHARS}). Две-четыре фразы: кому и какую задачу "
                "решает, откуда данные, что на выходе, чем является по сути")
    if len(not_does) < _MIN_DETAIL_CHARS:
        state.rejected += 1
        return (f"описание отклонено: «чего не делает» слишком короткое "
                f"({len(not_does)} симв., нужно от {_MIN_DETAIL_CHARS}). Назови главное "
                "расхождение между замыслом и тем, чем система оказалась; если "
                "расхождений нет — скажи это прямо")
    for label, value in (("«что делает»", does), ("«чего не делает»", not_does)):
        problem = _text_problem(label, value, state.tree)
        if problem:
            state.rejected += 1
            return f"описание отклонено: {problem}"
    verdict = str(args.get("verdict") or "").strip().lower()
    # Про `scope_mismatch` проверяем позже, на submit_integrity: изъяны ещё не
    # названы, и требовать их сейчас значило бы ломать порядок работы.
    if verdict not in PURPOSE_VERDICTS:
        state.rejected += 1
        return (f"описание отклонено: вердикт {verdict!r} неизвестен. Допустимы: "
                + ", ".join(PURPOSE_VERDICTS))
    evidence = [e for e in _parse_evidence(args.get("evidence"), state.tree) if e.verified]
    if not evidence:
        state.rejected += 1
        return ("описание отклонено: нужна хотя бы одна проверенная ссылка — "
                "место, по которому ты понял, что система делает")
    state.purpose = SystemPurpose(does=does, not_does=not_does, verdict=verdict,
                                  evidence=evidence)
    return ("описание принято. Теперь выведи целевые сценарии из образа результата "
            "(submit_scenarios), проследи стыки каждого (submit_trace), затем "
            "submit_flow.")


def _handle_flow(state: _Session, args: dict) -> str:
    """`submit_flow` — сквозной путь системы."""
    entry = _clean(args.get("entry"), _MAX_FLOW_STEP_CHARS)
    outcome = _clean(args.get("outcome"), _MAX_FLOW_STEP_CHARS)
    raw_steps = args.get("steps")
    if not entry or not outcome:
        state.rejected += 1
        return "путь отклонён: entry и outcome обязательны и непусты"
    if not isinstance(raw_steps, list):
        state.rejected += 1
        return "путь отклонён: steps должен быть списком шагов"
    steps = [_clean(step, _MAX_FLOW_STEP_CHARS) for step in raw_steps]
    steps = [step for step in steps if step]
    if not (_MIN_FLOW_STEPS <= len(steps) <= _MAX_FLOW_STEPS):
        state.rejected += 1
        return (f"путь отклонён: шагов должно быть от {_MIN_FLOW_STEPS} до "
                f"{_MAX_FLOW_STEPS}, прислано {len(steps)}")
    complete = bool(args.get("complete"))
    break_point = _clean(args.get("break_point"), _MAX_DETAIL_CHARS)
    if not complete and not break_point:
        state.rejected += 1
        return ("путь отклонён: при complete=false обязателен break_point — "
                "на каком шаге и почему цепочка рвётся")
    for label, value in (("entry", entry), ("outcome", outcome),
                         ("break_point", break_point)):
        if not value:
            continue
        problem = _text_problem(f"поле {label}", value, state.tree)
        if problem:
            state.rejected += 1
            return f"путь отклонён: {problem}"
    for index, step in enumerate(steps, start=1):
        problem = _text_problem(f"шаг {index}", step, state.tree)
        if problem:
            state.rejected += 1
            return f"путь отклонён: {problem}"

    evidence = [e for e in _parse_evidence(args.get("evidence"), state.tree) if e.verified]
    if not evidence:
        state.rejected += 1
        return ("путь отклонён: нужна хотя бы одна проверенная ссылка — "
                "как минимум точка входа, откуда ты начал цепочку")

    state.flow = FlowTrace(
        entry=entry, steps=steps, outcome=outcome, complete=complete,
        break_point="" if complete else break_point, evidence=evidence,
    )
    return ("путь принят. Теперь пройди стыки по чек-листу и назови изъяны "
            "через submit_flaw — по вызову на изъян.")


def _handle_flaw(state: _Session, args: dict) -> str:
    """`submit_flaw` — один изъян связности."""
    if len(state.flaws) >= _MAX_FLAWS:
        state.rejected += 1
        return (f"изъян отклонён: их уже {_MAX_FLAWS} — столько читатель не "
                "прочтёт. Если этот важнее одного из названных, дальше "
                "переходи к submit_integrity: в карточке останутся самые "
                "тяжёлые")
    kind = str(args.get("kind") or "").strip().lower()
    if kind not in FLAW_KINDS:
        state.rejected += 1
        return (f"изъян отклонён: вид {kind!r} не из списка. Допустимы: "
                + ", ".join(FLAW_KINDS))
    severity = str(args.get("severity") or "").strip().lower()
    if severity not in FLAW_SEVERITIES:
        state.rejected += 1
        return (f"изъян отклонён: вес {severity!r} неизвестен. Допустимы: "
                + ", ".join(FLAW_SEVERITIES))
    title = _clean(args.get("title"), _MAX_TITLE_CHARS)
    if not title:
        state.rejected += 1
        return "изъян отклонён: нужен заголовок — назывной фразой, до 80 символов"
    detail = _clean(args.get("detail"), _MAX_DETAIL_CHARS)
    if len(detail) < _MIN_DETAIL_CHARS:
        state.rejected += 1
        return (f"изъян отклонён: объяснение слишком короткое ({len(detail)} симв., "
                f"нужно от {_MIN_DETAIL_CHARS}). Скажи, что есть и работает, и "
                "где именно обрыв")
    for label, value in (("заголовок", title), ("объяснение", detail)):
        problem = _text_problem(label, value, state.tree)
        if problem:
            state.rejected += 1
            return f"изъян отклонён: {problem}"

    evidence = [e for e in _parse_evidence(args.get("evidence"), state.tree) if e.verified]
    if not evidence:
        state.rejected += 1
        return ("изъян отклонён: нужна хотя бы одна проверенная ссылка на место "
                "обрыва — где связь должна была быть, где лежит заглушка, где "
                "теряется результат. Отсутствие связи доказывается местом, а не "
                "утверждением")

    for existing in state.flaws:
        if existing.kind == kind and existing.title.lower() == title.lower():
            state.rejected += 1
            return "изъян отклонён: такой уже назван — этот вид с тем же заголовком есть в списке"

    flaw = SystemFlaw(
        kind=kind, severity=severity, title=title, detail=detail,
        bullets=_match_bullets(args.get("bullets"), state.plan_bullets),
        evidence=evidence,
    )
    state.flaws.append(flaw)
    return (f"изъян принят ({len(state.flaws)} из {_MAX_FLAWS}). Следующий "
            "изъян или submit_integrity, когда всё названо.")


def _handle_integrity(state: _Session, args: dict) -> str:
    """`submit_integrity` — уровень связности."""
    if state.purpose is None:
        state.rejected += 1
        return ("уровень отклонён: сначала submit_system — пока не сказано, что "
                "система делает на самом деле, судить о её связности не о чем")
    if state.flow is None:
        state.rejected += 1
        return ("уровень отклонён: сначала submit_flow — уровень связности без "
                "прослеженного сквозного пути ничем не обоснован")
    level = str(args.get("level") or "").strip().lower()
    problem = integrity_level_problem(level, state.flaws)
    if problem:
        state.rejected += 1
        return f"уровень отклонён: {problem}"
    # «Решает другую задачу» без разбора, что именно она решает вместо, — это
    # ярлык. Требуем изъян вида scope_mismatch, где это сказано.
    problem = purpose_verdict_problem(state.purpose.verdict, state.flaws)
    if problem:
        state.rejected += 1
        return f"уровень отклонён: {problem}"
    note = _clean(args.get("note"), _MAX_NOTE_CHARS)
    if len(note) < _MIN_NOTE_CHARS:
        state.rejected += 1
        return (f"уровень отклонён: пояснение слишком короткое ({len(note)} симв., "
                f"нужно от {_MIN_NOTE_CHARS})")
    text_problem = _text_problem("пояснение", note, state.tree)
    if text_problem:
        state.rejected += 1
        return f"уровень отклонён: {text_problem}"
    state.level = level
    state.note = note
    return "уровень связности принят. Вызови finish."


def _handle_finish(state: _Session, args: dict) -> str:
    if state.purpose is None:
        state.rejected += 1
        return ("finish отклонён: не сказано, что система делает на самом деле. "
                "Вызови submit_system — это главный ответ ревизии")
    if state.flow is None:
        state.rejected += 1
        return ("finish отклонён: сквозной путь не прослежен. Вызови submit_flow — "
                "даже если путь рвётся, это и есть результат ревизии")
    if not state.level:
        state.rejected += 1
        return "finish отклонён: уровень связности не вынесен — вызови submit_integrity"
    if state.connectivity is not None:
        problem = connectivity_finish_problem(state.connectivity)
        if problem:
            state.rejected += 1
            return f"finish отклонён: {problem}"
    state.finished = True
    return "ревизия связности завершена"


def _handle_scenarios(state: _Session, args: dict) -> str:
    if state.connectivity is None:
        state.rejected += 1
        return "инструмента submit_scenarios нет: измерение связности выключено"
    return handle_scenarios(state.connectivity, args)


def _handle_trace(state: _Session, args: dict) -> str:
    if state.connectivity is None:
        state.rejected += 1
        return "инструмента submit_trace нет: измерение связности выключено"
    return handle_trace(state.connectivity, args)


_HANDLERS: dict[str, Callable[[_Session, dict], str]] = {
    "submit_system": _handle_system,
    "submit_scenarios": _handle_scenarios,
    "submit_trace": _handle_trace,
    "submit_flow": _handle_flow,
    "submit_flaw": _handle_flaw,
    "submit_integrity": _handle_integrity,
    "finish": _handle_finish,
}

_FOREIGN_TOOLS = (
    "submit_stage", "submit_review", "submit_summary", "submit_groups",
    "submit_brief", "submit_challenge",
)


def _answer_call(state: _Session, call: dict) -> dict[str, Any]:
    parsed, error = parse_tool_call(call, _COHERENCE_TOOL_SCHEMAS)
    if parsed is None:
        return tool_message(call, error)
    name = parsed.name
    args = parsed.arguments
    handler = _HANDLERS.get(name)
    if handler:
        content = handler(state, args)
    elif name in _FOREIGN_TOOLS:
        content = (f"инструмента {name!r} у ревизора нет: статусы пунктов уже "
                   "выставлены и менять их не твоя работа. Твои инструменты — "
                   "submit_flow, submit_flaw, submit_integrity, finish")
    else:
        content = _cap_tool_result(state.tools.call(name, args).content)
    return tool_message(call, content)


def run_coherence(
    result: AgentResult,
    tree: Tree,
    spec: ModelSpec | None,
    client: ChatClient | None = None,
    extraction: Extraction | None = None,
    on_event: Callable[[str, dict[str, Any]], None] | None = None,
    max_steps: int | None = None,
    source_digest: str = "",
) -> CoherenceOutcome:
    """Прогнать ревизора связности по результату первых двух агентов.

    `source_digest` — отпечаток образа результата: состав целевых сценариев
    привязывается к нему, чтобы сравнивать связность между прогонами только
    при одинаковом ОР.

    Ничего в `result` не меняет: возвращает разбор для карточки и заметки.
    Готовность, решение и статусы буллитов остаются как были — связность это
    отдельный вопрос, и пересчитывать ею проценты значит завести вторую шкалу
    поверх первой.
    """
    if not coherence_enabled():
        return CoherenceOutcome(notes=[
            "Ревизия связности выключена (PKO_COHERENCE=false): собранность "
            "решения не проверялась"
        ])
    if spec is None or not result.usable:
        return CoherenceOutcome()
    bullets = _plan_bullets(result.plan, result.verdicts)
    if not bullets:
        return CoherenceOutcome(notes=[
            "Ревизия связности: применимых пунктов нет, проверять связность нечего"
        ])
    steps = (max_steps if max_steps is not None
             else _env_int("PKO_COHERENCE_STEPS", DEFAULT_COHERENCE_STEPS))
    if steps <= 0:
        return CoherenceOutcome(notes=["Ревизия связности выключена (PKO_COHERENCE_STEPS=0)"])

    if on_event is not None:
        on_event("phase", {"phase": "coherence",
                           "label": "Ревизия связности: собирается ли решение целиком"})

    chat_client = client if client is not None else ChatClient(spec=spec)
    thinking_on = bool(
        spec.extra_body
        and spec.extra_body.get("chat_template_kwargs", {}).get("enable_thinking") is True
    )
    max_tokens = max_tokens_for(thinking_on)
    brief = build_coherence_brief(
        result.plan, result.verdicts, context=result.context,
        match=result.summary.match if result.summary else "",
        match_note=result.summary.match_note if result.summary else "",
        extraction=extraction,
    )
    state = _run_session(
        brief, [text for text, _ in bullets], tree, chat_client, steps, max_tokens,
        window_tokens=getattr(spec, "context_window", 0) or 0, extraction=extraction,
        source_digest=source_digest,
    )

    notes = list(state.notes)
    connectivity: ConnectivityReview | None = None
    if state.connectivity is not None:
        connectivity = state.connectivity.review()
        if connectivity is None:
            notes.append(
                "Сквозная связность не измерена: целевые сценарии не объявлены "
                "(submit_scenarios не вызван)"
            )
        else:
            counts = connectivity.counts()
            done, total = connectivity.handoff_coverage()
            untraced = state.connectivity.untraced
            notes.append(
                f"Сквозная связность: собрано {counts['assembled']} из "
                f"{len(connectivity.scenarios)} сценариев ({connectivity.percent()}%), "
                f"разрывов — {counts['broken']}, недостаточно данных — {counts['unknown']}; "
                f"стыков проверено {done} из {total}"
                + (f"; понижено до unknown за отсутствие ссылок — {state.connectivity.downgraded}"
                   if state.connectivity.downgraded else "")
                + (f"; не прослежены: {', '.join(untraced)}" if untraced else "")
            )
            for scenario in connectivity.blocked():
                notes.append(
                    f"Критический сценарий «{scenario.title}» разорван — "
                    f"результат «{scenario.outcome}» заблокирован"
                )
    review: IntegrityReview | None = None
    if state.level and state.flow is not None:
        review = IntegrityReview(
            level=state.level, note=state.note, purpose=state.purpose,
            flow=state.flow, flaws=list(state.flaws), checked=len(bullets),
        )
        counts = review.severity_counts()
        notes.append(
            "Ревизия связности: "
            + ", ".join(f"{label} — {counts[key]}" for key, label in (
                ("blocker", "блокирующих изъянов"),
                ("major", "существенных"),
                ("minor", "замечаний"),
            ))
            + (f", отклонённых вызовов — {state.rejected}" if state.rejected else "")
        )
    else:
        # Называем первое недостающее звено, а не последнее: не сказано, что
        # система делает, — значит дело в этом, даже если формально не вынесен
        # и уровень.
        if state.purpose is None:
            missing = "не сказано, что система делает на самом деле"
        elif state.flow is None:
            missing = "сквозной путь не прослежен"
        else:
            missing = "уровень связности не вынесен"
        notes.append(
            f"Ревизия связности не доведена до конца: {missing} — "
            "блок связности в карточку не попадёт"
        )
    return CoherenceOutcome(
        review=review,
        connectivity=connectivity,
        notes=notes,
        runtime_stats=state.runtime_stats,
    )


def _run_session(
    brief: str,
    plan_bullets: list[str],
    tree: Tree,
    chat_client: ChatClient,
    max_steps: int,
    max_tokens: int,
    window_tokens: int = 0,
    extraction: Extraction | None = None,
    source_digest: str = "",
) -> _Session:
    """Сессия ревизора связности на общем bounded runtime."""
    state = _Session(
        plan_bullets=list(plan_bullets), tree=tree,
        tools=ToolBox(tree, extraction=extraction),
        connectivity=ConnectivityState(
            plan_bullets=list(plan_bullets), tree=tree, source_digest=source_digest,
        ),
    )
    system_prompt, found = load_coherence_prompt()
    if not found:
        state.notes.append(
            "Ревизия связности: системный промпт не найден, использована краткая заготовка"
        )
    budget_seconds = float(_env_int("PKO_COHERENCE_SECONDS", DEFAULT_COHERENCE_SECONDS))
    run = run_agent_loop(
        chat_client=chat_client,
        system_prompt=system_prompt,
        user_prompt=brief,
        tools=_COHERENCE_TOOL_SCHEMAS,
        config=AgentLoopConfig(
            role="coherence",
            session_span="coherence_session",
            step_span="coherence.step",
            max_steps=max(1, max_steps),
            max_seconds=budget_seconds,
            max_tokens=max_tokens,
            window_tokens=max(0, window_tokens),
            malformed_limit=_MALFORMED_LIMIT,
            repeat_limit=_REPEAT_LIMIT,
        ),
        hooks=AgentLoopHooks(
            answer_call=lambda call: _answer_call(state, call),
            is_finished=lambda: state.finished,
            nudge=_NUDGE,
            final_trace_attributes=lambda: {
                "flaws": len(state.flaws),
                "scenarios": len(state.connectivity.order) if state.connectivity else 0,
                "level": state.level,
            },
        ),
    )
    _append_coherence_stop_note(state.notes, run.stats, budget_seconds, max_steps)
    state.runtime_stats = run.stats.model_dump(mode="json")
    return state


def _append_coherence_stop_note(
    notes: list[str], stats: AgentRunStats, budget_seconds: float, max_steps: int,
) -> None:
    if stats.stop_reason == StopReason.TIME_LIMIT:
        notes.append(
            f"Ревизия связности: время исчерпано ({int(budget_seconds)} с) "
            f"на шаге {stats.steps_done}"
        )
    elif stats.stop_reason == StopReason.MODEL_ERROR:
        notes.append(
            f"Ревизия связности: ревизор недоступен на шаге {stats.steps_done}: "
            f"{stats.error_message}"
        )
    elif stats.stop_reason == StopReason.MALFORMED_OUTPUT:
        notes.append(
            f"Ревизия связности: ревизор не вызвал инструмент "
            f"{stats.malformed_responses} раз подряд — остановлено"
        )
    elif stats.stop_reason == StopReason.REPEATED_TOOL_CALLS:
        notes.append(
            f"Ревизия связности: остановлено — {_REPEAT_LIMIT} одинаковых вызова подряд"
        )
    elif stats.stop_reason == StopReason.TOOL_BUDGET:
        notes.append(
            f"Ревизия связности: бюджет инструментов исчерпан "
            f"({stats.tool_calls}); сессия остановлена"
        )
    elif stats.stop_reason == StopReason.STEP_LIMIT:
        notes.append(f"Ревизия связности: бюджет шагов исчерпан ({max_steps})")

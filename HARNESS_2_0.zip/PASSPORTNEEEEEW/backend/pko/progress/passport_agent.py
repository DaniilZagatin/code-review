"""Паспортный агент: отдельная сессия, обход дерева сверху вниз.

Сессия оценки (`matcher.run_agent`) заканчивается вердиктом. Паспорт
клиентского пути собирает **вторая сессия** — без инструментов репозитория:
по коду она не ходит, а работает на том, что уже собрала первая — карте
возможностей, вердиктах с доказательствами и сжатом следе прочитанного.

Дерево строится **итеративно**, и очередь ведёт код, а не модель:

    journey-1  ← submit_node: поля пути
               ← declare_children: процессы (название + basis)
    process-1  ← submit_node: поля процесса
               ← declare_children: BBB — новые {name, basis} или уже
                  объявленные {ref: "bbb-2"} (общий блок, второй родитель)
    bbb-1      ← submit_node
               ← declare_children: операции
    operation-1 ← submit_node          (лист — детей нет)
    operation-2 ← submit_node
    bbb-2 …    (обход в глубину, пока очередь не пуста)
    link_nodes(from, to, kind, basis)   связи поверх дерева
    bind_scenario_step(scenario, step, nodes)  шаги сценариев без узла
    finish

Каждый узел проверяется гейтом отдельно (`passport_gate`), отклонение стоит
одного шага, а не всего паспорта. У промежуточных узлов дети обязательны:
объявление без единого ребёнка не принимается. Идентификаторы выдаёт код,
реестр и `object-id` строит `normalize_passport` — модель присылает только
названия, основания, поля и связи. В каждом ответе модель получает карту
уже построенного дерева — из истории ей ничего вспоминать не нужно.

Сценарии из ревизии связности привязываются к узлам по шагам
(`scenario_steps` в `submit_node`, `bind_scenario_step` после дерева).
Шаг без узла код не пропускает молча: после дерева он перечисляет такие
шаги, а первый `finish` при них отклоняет.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.harness import (
    harden_tool_schemas,
    parse_tool_call,
    tool_message,
)
from pko.llm.registry import ModelSpec
from pko.llm.runtime import (
    AgentLoopConfig,
    AgentLoopHooks,
    AgentRunStats,
    StopReason,
    run_agent_loop,
)
from pko.llm.tracing import _NoopSpan
from pko.progress.connectivity import match_bullets
from pko.progress.matcher import _strip_cjk, max_tokens_for
from pko.progress.passport_gate import (
    CHILD_TYPE,
    DECISION_BOUNDARIES,
    RELATION_HINT,
    RELATION_KINDS,
    RELATION_LABEL,
    TYPE_LABEL,
    PassportCheck,
    check_node_fields,
    check_relation,
    check_router_present,
    collapsed_level_message,
    duplicate_name_message,
    journey_name_of,
    node_type,
    norm_name,
    normalize_passport,
    parent_link_problem,
)
from pko.progress.schema import ConnectivityReview, ItemVerdict, PlanItem, ProjectSummary

_PROMPT_PATH = Path(__file__).parent / "passport_system.md"

# Бюджет шагов паспортной сессии: узел — шаг, объявление детей — шаг.
# Дерево на 20 узлов со связями и привязкой сценариев — около 35 шагов;
# запас на отклонения гейта. `PKO_PASSPORT_MAX_STEPS`.
DEFAULT_PASSPORT_MAX_STEPS = 60
# Потолок времени паспортной сессии, `PKO_PASSPORT_MAX_SECONDS`; 0 — без предела.
DEFAULT_PASSPORT_SECONDS = 1200
# Сколько раз один узел отклоняется, прежде чем принять его с нарушениями.
MAX_NODE_REJECTIONS = 2
# У процесса меньше двух BBB — замечание: обычно процесс описан одним куском.
MIN_BBB_PER_PROCESS = 2
# Сколько ошибок подряд без вызова инструмента останавливают сессию.
_MAX_MALFORMED = 3
# `finish` при шагах сценариев без узла отклоняется столько раз: модель
# обязана либо привязать шаг, либо сознательно оставить его вне схемы.
MAX_FINISH_REJECTIONS = 1

# Узлы, которые выполняют шаги сценариев: путь и процесс — контейнеры.
SCENARIO_NODE_TYPES = ("bbb", "operation")


# Сколько символов сжатого следа оценки уходит в первое сообщение.
_MAX_KNOWLEDGE_CHARS = 30_000
_MAX_PROOF_CHARS = 300


def _env_number(name: str, default: float) -> float:
    raw = (os.environ.get(name) or "").strip()
    try:
        return max(0.0, float(raw)) if raw else default
    except ValueError:
        return default


def passport_enabled() -> bool:
    """`PKO_PASSPORT`: выключить паспортную сессию можно только явно."""
    raw = (os.environ.get("PKO_PASSPORT") or "").strip().lower()
    return raw not in ("0", "false", "no", "off")


# --- схемы инструментов --------------------------------------------------------

_SUBMIT_NODE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_node",
        "description": (
            "Заполнить один узел паспорта — тот, который код назвал в "
            "последнем ответе. Передай его id, название (name), basis — одну "
            "фразу, почему узел существует как объект управления и чем "
            "отличается от соседей, — и fields: по каждому полю раздела "
            "{value, source}. source начинается с уровня: Установлено: / "
            "Выведено: / Гипотеза: / Требует подтверждения владельца: / "
            "Не установлено:. Для journey дополнительно decision_boundary "
            "(END_TO_END_PROCESS | COMPONENT_BBB). Код проверит узел и скажет, что дальше."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "id узла из ответа кода: journey-1, process-2, bbb-3, operation-4"},
                "name": {"type": "string", "description": "Название узла на языке бизнеса"},
                "basis": {"type": "string", "description": "Почему узел существует как объект управления и чем отличается от соседей — одна фраза"},
                "fields": {
                    "type": "object",
                    "description": "Поля раздела: {\"4.X.Y\": {\"value\": \"...\", \"source\": \"Уровень: привязка\"}}",
                },
                "bullets": {
                    "type": "array", "items": {"type": "string"},
                    "description": "Пункты образа результата, которые этот узел реализует — дословно из задания. "
                                   "По ним код считает готовность узла и красит его на схеме. Для узлов дерева "
                                   "(process, bbb, operation) обязательно старайся указать; пункт может принадлежать нескольким узлам.",
                },
                "scenario_steps": {
                    "type": "array",
                    "items": {"type": "object", "properties": {
                        "scenario": {"type": "string", "description": "id целевого сценария из задания: scenario-1 …"},
                        "step": {"type": "integer", "description": "номер шага сценария (с нуля), который выполняет этот узел"},
                    }, "required": ["scenario", "step"]},
                    "description": "В каких шагах целевых сценариев участвует узел. По ним код рисует путь сценария "
                                   "поверх схемы и показывает разрывы на стыках. Только для bbb и operation.",
                },
                "decision_boundary": {"type": "string", "description": "Только для journey: END_TO_END_PROCESS или COMPONENT_BBB"},
            },
            "required": ["id", "name", "basis", "fields"],
        },
    },
}

_DECLARE_CHILDREN_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "declare_children",
        "description": (
            "Объявить дочерние узлы только что заполненного узла: для journey "
            "— процессы, для process — BBB, для bbb — атомарные операции. "
            "Новый ребёнок — {name, basis}; уже объявленный узел того же уровня, "
            "который входит и сюда (общий BBB или общая операция), — {ref: id}: "
            "у него появится второй родитель, заполнять его повторно не нужно. "
            "Поля каждого нового ребёнка ты заполнишь, когда код его назовёт. "
            "Дети обязательны: journey без процессов, процесс без BBB и BBB без "
            "операций не принимаются. Дроби по бизнес-действиям: ориентир 3–6 BBB "
            "на процесс, 1–3 операции на BBB."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "parent": {"type": "string", "description": "id узла-родителя из ответа кода"},
                "children": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "basis": {"type": "string", "description": "Почему это отдельный объект и чем отличается от соседей"},
                            "ref": {"type": "string", "description": "id уже объявленного узла того же уровня, который входит и в этот родитель"},
                        },
                    },
                },
            },
            "required": ["parent", "children"],
        },
    },
}

_LINK_NODES_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "link_nodes",
        "description": (
            "Объявить связь между двумя узлами поверх дерева. Виды: "
            + "; ".join(f"{k} — {RELATION_HINT[k]}" for k in RELATION_KINDS)
            + ". basis — одна фраза, какой факт кода или образа результата "
            "показывает связь. Дерево (родитель → ребёнок) связью не дублируй."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "from": {"type": "string", "description": "id узла-источника"},
                "to": {"type": "string", "description": "id узла-приёмника"},
                "kind": {"type": "string", "enum": list(RELATION_KINDS)},
                "basis": {"type": "string"},
            },
            "required": ["from", "to", "kind", "basis"],
        },
    },
}

_BIND_SCENARIO_STEP_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "bind_scenario_step",
        "description": (
            "Привязать шаг целевого сценария к узлам, которые его выполняют "
            "(bbb или operation). Нужен для шагов, которые не были указаны в "
            "scenario_steps при заполнении узлов: код перечисляет их после дерева."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "scenario": {"type": "string", "description": "id сценария: scenario-1 …"},
                "step": {"type": "integer", "description": "номер шага с нуля"},
                "nodes": {"type": "array", "items": {"type": "string"}, "description": "id узлов bbb/operation"},
            },
            "required": ["scenario", "step", "nodes"],
        },
    },
}

_FINISH_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "finish",
        "description": "Завершить паспорт: дерево построено, связи объявлены, шаги сценариев привязаны.",
        "parameters": {"type": "object", "properties": {}},
    },
}

_PASSPORT_TOOL_SCHEMAS: list[dict[str, Any]] = harden_tool_schemas([
    _SUBMIT_NODE_SCHEMA,
    _DECLARE_CHILDREN_SCHEMA,
    _LINK_NODES_SCHEMA,
    _BIND_SCENARIO_STEP_SCHEMA,
    _FINISH_SCHEMA,
])


# --- состояние сессии ------------------------------------------------------------

@dataclass
class _Node:
    id: str
    name: str
    basis: str
    # Первый родитель — место узла в дереве; остальные — общие включения.
    parents: list[str] = field(default_factory=list)
    filled: bool = False
    data: dict[str, Any] = field(default_factory=dict)
    children: list[str] = field(default_factory=list)

    @property
    def parent(self) -> str | None:
        return self.parents[0] if self.parents else None


@dataclass
class _PassportSession:
    nodes: dict[str, _Node] = field(default_factory=dict)
    counters: dict[str, int] = field(default_factory=dict)
    # Очередь заполнения — стек обхода в глубину.
    queue: list[str] = field(default_factory=list)
    # Узел, поля которого ждёт код, и узел, дети которого ждут объявления.
    current: str | None = None
    awaiting_children_of: str | None = None
    tree_done: bool = False
    attempts: dict[str, int] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    remarks: list[str] = field(default_factory=list)
    finished: bool = False
    decision_boundary: str = ""
    span: Any = field(default_factory=lambda: _NoopSpan())
    on_node: Callable[[str, str], None] | None = None
    # Пункты ОР (дословно) и целевые сценарии — для привязки узлов: по ним
    # код считает готовность узла и рисует путь сценария на схеме.
    plan_bullets: list[str] = field(default_factory=list)
    scenarios: dict[str, list[str]] = field(default_factory=dict)
    # Связи поверх дерева: {from, to, kind, basis}.
    relations: list[dict[str, str]] = field(default_factory=list)

    def new_id(self, ntype: str) -> str:
        self.counters[ntype] = self.counters.get(ntype, 0) + 1
        return f"{ntype}-{self.counters[ntype]}"

    def tree_ids(self) -> list[str]:
        return list(self.nodes)

    def of_type(self, ntype: str) -> list[_Node]:
        return [n for n in self.nodes.values() if node_type(n.id) == ntype]

    def relation_keys(self) -> set[tuple[str, str, str]]:
        return {(r["from"], r["to"], r["kind"]) for r in self.relations}

    def bound_steps(self) -> set[tuple[str, int]]:
        out: set[tuple[str, int]] = set()
        for node in self.nodes.values():
            for entry in node.data.get("scenario_steps") or []:
                out.add((str(entry.get("scenario")), int(entry.get("step"))))
        return out

    def unbound_steps(self) -> list[tuple[str, int, str]]:
        """Шаги целевых сценариев, у которых нет ни одного узла."""
        bound = self.bound_steps()
        return [
            (sid, index, text)
            for sid, steps in self.scenarios.items()
            for index, text in enumerate(steps)
            if (sid, index) not in bound
        ]


# --- обработчики ----------------------------------------------------------------

def _handle_submit_node(state: _PassportSession, args: dict) -> str:
    nid = str(args.get("id") or "").strip()
    ntype = node_type(nid)
    expected = _expected_submit(state)
    if not ntype or nid not in expected:
        return (f"submit_node отклонён: сейчас ожидается {_expected_text(state)}, "
                f"а пришёл «{nid or '?'}».")
    name = _clean(args.get("name"))
    basis = _clean(args.get("basis"))
    fields = args.get("fields")
    if isinstance(fields, str):
        try:
            fields = json.loads(fields)
        except ValueError:
            fields = None
    if not isinstance(fields, dict):
        fields = {}
    fields = _clean_fields(fields)
    node = state.nodes.get(nid)
    if node is not None and not name:
        name = node.name
    if node is not None and not basis:
        basis = node.basis
    # Корень дерева назван образом результата инициативы, и модель его не
    # переименовывает: иначе путь в паспорте расходился с путём в отчёте.
    if ntype == "journey" and node is not None and node.name:
        name = node.name

    payload: dict[str, Any] = {"name": name, "basis": basis, "fields": fields}
    check = PassportCheck()
    if not name:
        check.errors.append(f"{nid}: нет названия (name)")
    if not basis:
        check.errors.append(f"{nid}: нет basis — одной фразы, почему узел существует как объект управления")
    if not fields:
        check.errors.append(f"{nid}: fields пуст — заполни поля раздела, по каждому value и source")
    _check_name_unique(check, state, nid, name)
    check_node_fields(check, nid, payload)

    if ntype != "journey":
        _attach_links(state, check, nid, ntype, args, payload)

    if ntype == "journey":
        boundary = str(args.get("decision_boundary") or "").strip()
        if boundary not in DECISION_BOUNDARIES:
            check.errors.append(
                "journey: decision_boundary должен быть END_TO_END_PROCESS "
                "(путь покрывает триггер входа и результат после) или COMPONENT_BBB "
                "(диалог внутри агента от классификации до сообщения)"
            )
        else:
            payload["decision_boundary"] = boundary

    if check.errors:
        state.attempts[nid] = state.attempts.get(nid, 0) + 1
        state.span.add_event("node_rejected", node=nid, attempts=state.attempts[nid])
        if state.attempts[nid] <= MAX_NODE_REJECTIONS:
            listed = "\n".join(f"- {e}" for e in check.errors[:10])
            return f"{nid} отклонён:\n{listed}\nИсправь и вызови submit_node({nid}) снова."
        state.notes.append(
            f"{nid} принят с нарушениями после {MAX_NODE_REJECTIONS} отклонений: "
            + "; ".join(check.errors[:6])
        )

    if node is None:
        node = _Node(id=nid, name=name, basis=basis)
        state.nodes[nid] = node
    node.name, node.basis = name, basis
    # Повторная отправка после дерева (исправление по замечанию) не теряет
    # привязок сценариев, сделанных bind_scenario_step.
    if node.filled and not payload.get("scenario_steps"):
        payload["scenario_steps"] = list(node.data.get("scenario_steps") or [])
    node.data = payload
    node.filled = True
    if ntype == "journey":
        state.decision_boundary = payload.get("decision_boundary", state.decision_boundary)
    state.remarks.extend(check.remarks)
    state.span.add_event("node_accepted", node=nid, remarks=len(check.remarks))
    if state.on_node is not None:
        state.on_node(nid, name)

    reply = [f"{nid} «{name}» принят."]
    if check.remarks:
        reply.append("Замечания (исправь при желании повторным submit_node, иначе продолжай):")
        reply.extend(f"- {r}" for r in check.remarks[:6])

    if state.tree_done:
        # Правка уже принятого узла после дерева: очередь не трогаем.
        reply.append(_after_tree_text(state))
        return "\n".join(reply)

    if ntype in CHILD_TYPE:
        state.current = None
        state.awaiting_children_of = nid
        child_label = TYPE_LABEL[CHILD_TYPE[ntype]]
        reply.append(
            f"Теперь объяви детей: declare_children(parent=\"{nid}\", children=[{{name, basis}} | {{ref}}, …]) "
            f"— {child_label.lower()} ({_children_hint(ntype)}). Дети обязательны."
        )
        return "\n".join(reply)

    state.current = None
    reply.append(_advance(state))
    return "\n".join(reply)


def _attach_links(state: _PassportSession, check: PassportCheck, nid: str, ntype: str,
                  args: dict, payload: dict[str, Any]) -> None:
    """Привязка узла к пунктам ОР и шагам сценариев — модель предлагает,
    код сопоставляет. Несопоставленное отбрасывается с замечанием, а не
    с отклонением: карточка узла ценна и без раскраски."""
    raw_bullets = args.get("bullets")
    bullets = match_bullets(raw_bullets, state.plan_bullets) if state.plan_bullets else []
    if isinstance(raw_bullets, list) and raw_bullets and not bullets:
        check.remarks.append(
            f"{nid}: ни один из названных пунктов ОР не сопоставлен — цитируй пункты "
            "дословно из задания"
        )
    elif ntype in SCENARIO_NODE_TYPES and not bullets and state.plan_bullets:
        check.remarks.append(
            f"{nid}: не привязан к пунктам ОР (bullets) — без этого готовность узла на "
            "схеме не считается"
        )
    payload["bullets"] = bullets

    steps_out: list[dict[str, Any]] = []
    raw_steps = args.get("scenario_steps")
    if isinstance(raw_steps, list):
        if ntype not in SCENARIO_NODE_TYPES and raw_steps:
            check.remarks.append(
                f"{nid}: шаги сценариев выполняют BBB и операции, а не {TYPE_LABEL[ntype].lower()} — "
                "привязка отброшена, укажи её у детей"
            )
        else:
            for item in raw_steps:
                if not isinstance(item, dict):
                    continue
                sid = str(item.get("scenario") or "").strip()
                try:
                    step = int(item.get("step"))
                except (TypeError, ValueError):
                    check.remarks.append(f"{nid}: у scenario_steps step должен быть числом")
                    continue
                problem = _scenario_step_problem(state, sid, step)
                if problem:
                    check.remarks.append(f"{nid}: {problem}")
                    continue
                entry = {"scenario": sid, "step": step}
                if entry not in steps_out:
                    steps_out.append(entry)
    payload["scenario_steps"] = steps_out


def _scenario_step_problem(state: _PassportSession, sid: str, step: int) -> str:
    steps = state.scenarios.get(sid)
    if steps is None:
        if not state.scenarios:
            return "целевых сценариев в задании нет"
        return f"сценария {sid!r} нет — есть: " + ", ".join(state.scenarios)
    if not (0 <= step < len(steps)):
        return f"у {sid} шаги 0–{len(steps) - 1}, прислан {step}"
    return ""


def _handle_declare_children(state: _PassportSession, args: dict) -> str:
    parent_id = str(args.get("parent") or "").strip()
    if state.awaiting_children_of is None or parent_id != state.awaiting_children_of:
        return (f"declare_children отклонён: сейчас ожидается {_expected_text(state)}"
                + (f", а не объявление детей у «{parent_id}»" if parent_id else ""))
    parent = state.nodes[parent_id]
    ptype = node_type(parent_id)
    ctype = CHILD_TYPE[ptype]
    raw = args.get("children")
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            raw = None
    items = [c for c in (raw or []) if isinstance(c, dict)]
    new_children = [c for c in items if not str(c.get("ref") or "").strip() and str(c.get("name") or "").strip()]
    refs = [str(c.get("ref") or "").strip() for c in items if str(c.get("ref") or "").strip()]

    check = PassportCheck()
    if not new_children and not refs:
        check.errors.append(
            f"{parent_id}: у {TYPE_LABEL[ptype].lower()} должен быть хотя бы один "
            f"{TYPE_LABEL[ctype].lower()} — {_children_hint(ptype)}"
        )
    seen: set[str] = set()
    for child in new_children:
        cname = _clean(child.get("name"))
        cbasis = _clean(child.get("basis"))
        key = norm_name(cname)
        if not cbasis:
            check.errors.append(f"«{cname}»: нет basis")
        if key in seen:
            check.errors.append(f"«{cname}» объявлен дважды")
        seen.add(key)
        if key == norm_name(parent.name):
            check.errors.append(duplicate_name_message(f"{ctype}-?", parent_id, cname))
        else:
            _check_name_unique(check, state, f"{ctype}-?", cname)
    # Ссылка на уже объявленный узел — общий ребёнок: второй родитель того же
    # уровня, а не новый узел. Существование и тип проверяет гейт.
    shared: list[str] = []
    for ref in refs:
        if ref in shared:
            check.errors.append(f"{ref} указан дважды")
            continue
        problem = parent_link_problem(ref, parent_id, set(state.nodes)) if ref in state.nodes else f"{ref}: узла нет"
        if problem:
            check.errors.append(f"ref {problem}")
            continue
        if parent_id in state.nodes[ref].parents:
            check.errors.append(f"{ref} уже ребёнок {parent_id}")
            continue
        shared.append(ref)
    total = len(new_children) + len(shared)
    if (ptype == "process" and len(new_children) == 1 and not shared
            and norm_name(new_children[0].get("basis")) == norm_name(parent.basis)):
        check.errors.append(collapsed_level_message(parent_id, f"{ctype}-?"))

    if check.errors:
        key = f"children:{parent_id}"
        state.attempts[key] = state.attempts.get(key, 0) + 1
        state.span.add_event("children_rejected", node=parent_id, attempts=state.attempts[key])
        if state.attempts[key] <= MAX_NODE_REJECTIONS or not total:
            listed = "\n".join(f"- {e}" for e in check.errors[:10])
            return (f"дети {parent_id} отклонены:\n{listed}\n"
                    f"Исправь и вызови declare_children(parent=\"{parent_id}\") снова.")
        state.notes.append(
            f"дети {parent_id} приняты с нарушениями: " + "; ".join(check.errors[:6])
        )

    if ptype == "process" and total < MIN_BBB_PER_PROCESS:
        state.remarks.append(
            f"{parent_id}: один BBB на процесс — проверь по признакам дробления "
            "(разные входы/результаты, внешние системы, расчёт vs генерация, "
            "режим полномочий); обычно процесс описан одним куском"
        )

    ids: list[str] = []
    for child in new_children:
        cid = state.new_id(ctype)
        state.nodes[cid] = _Node(
            id=cid, name=_clean(child.get("name")),
            basis=_clean(child.get("basis")), parents=[parent_id],
        )
        parent.children.append(cid)
        ids.append(cid)
    for ref in shared:
        state.nodes[ref].parents.append(parent_id)
        parent.children.append(ref)
    # Обход в глубину: первый новый ребёнок заполняется следующим, остальные ждут.
    state.queue[0:0] = ids
    state.awaiting_children_of = None
    state.span.add_event("children_declared", node=parent_id, count=total)

    parts = [f"{cid} «{state.nodes[cid].name}»" for cid in ids]
    parts += [f"{ref} «{state.nodes[ref].name}» (общий, уже заполнен)" for ref in shared]
    reply = [f"{parent_id}: объявлено {total} — " + ", ".join(parts) + "."]
    if ptype == "process" and total < MIN_BBB_PER_PROCESS:
        reply.append("Замечание: " + state.remarks[-1])
    reply.append(_advance(state))
    return "\n".join(reply)


def _handle_link_nodes(state: _PassportSession, args: dict) -> str:
    if state.awaiting_children_of or state.current:
        return (f"link_nodes отклонён: сначала {_expected_text(state)}; связи объявляй "
                "между уже объявленными узлами, лучше после дерева.")
    rel = {
        "from": str(args.get("from") or "").strip(),
        "to": str(args.get("to") or "").strip(),
        "kind": str(args.get("kind") or "").strip(),
        "basis": _clean(args.get("basis")),
    }
    check = PassportCheck()
    check_relation(check, rel, set(state.nodes), state.relation_keys())
    if rel["kind"] == "includes" and rel["to"] in state.nodes and rel["from"] in state.nodes[rel["to"]].parents:
        check.errors.append(f"связь {rel['from']} → {rel['to']}: {rel['from']} уже родитель {rel['to']} — дерево связью не дублируй")
    if check.errors:
        state.span.add_event("relation_rejected", count=len(check.errors))
        return "связь отклонена:\n" + "\n".join(f"- {e}" for e in check.errors[:6])
    state.relations.append(rel)
    if rel["kind"] == "includes":
        state.nodes[rel["to"]].parents.append(rel["from"])
        state.nodes[rel["from"]].children.append(rel["to"])
    state.span.add_event("relation_accepted", kind=rel["kind"])
    reply = [f"связь принята: {rel['from']} {RELATION_LABEL[rel['kind']]} {rel['to']}."]
    if state.tree_done:
        reply.append(_after_tree_text(state))
    else:
        reply.append(_advance(state))
    return "\n".join(reply)


def _handle_bind_scenario_step(state: _PassportSession, args: dict) -> str:
    if state.awaiting_children_of or state.current:
        return f"bind_scenario_step отклонён: сначала {_expected_text(state)}."
    sid = str(args.get("scenario") or "").strip()
    try:
        step = int(args.get("step"))
    except (TypeError, ValueError):
        return "bind_scenario_step отклонён: step должен быть числом."
    problem = _scenario_step_problem(state, sid, step)
    if problem:
        return f"bind_scenario_step отклонён: {problem}."
    raw = args.get("nodes")
    if isinstance(raw, str):
        raw = [raw]
    ids = [str(x).strip() for x in (raw or []) if str(x).strip()]
    errors: list[str] = []
    accepted: list[str] = []
    for nid in ids:
        node = state.nodes.get(nid)
        if node is None:
            errors.append(f"узла {nid} нет")
        elif node_type(nid) not in SCENARIO_NODE_TYPES:
            errors.append(f"{nid}: шаги сценариев выполняют BBB и операции, а не {TYPE_LABEL[node_type(nid)].lower()}")
        else:
            accepted.append(nid)
    if not accepted:
        return "bind_scenario_step отклонён:\n" + "\n".join(f"- {e}" for e in (errors or ["nodes пуст"]))
    for nid in accepted:
        node = state.nodes[nid]
        steps = list(node.data.get("scenario_steps") or [])
        entry = {"scenario": sid, "step": step}
        if entry not in steps:
            steps.append(entry)
        node.data["scenario_steps"] = steps
    reply = [f"{sid} шаг {step} «{state.scenarios[sid][step]}» — привязан к " + ", ".join(accepted) + "."]
    if errors:
        reply.append("Отброшено: " + "; ".join(errors))
    reply.append(_after_tree_text(state) if state.tree_done else _advance(state))
    return "\n".join(reply)


def _handle_finish(state: _PassportSession, args: dict) -> str:
    missing = _unfinished(state)
    if missing:
        return "finish отклонён: " + "; ".join(missing) + ". " + _expected_text(state)
    unbound = state.unbound_steps()
    if unbound:
        state.attempts["finish"] = state.attempts.get("finish", 0) + 1
        if state.attempts["finish"] <= MAX_FINISH_REJECTIONS:
            return ("finish отклонён: шаги сценариев без узла — "
                    + _unbound_text(unbound)
                    + ". Привяжи их bind_scenario_step(scenario, step, nodes) к BBB или операции, "
                    "которые их выполняют; если шаг лежит вне схемы паспорта — вызови finish ещё раз, "
                    "и он останется в замечаниях.")
        state.remarks.append("шаги сценариев без узла на схеме: " + _unbound_text(unbound))
    state.finished = True
    return "паспорт завершён"


def _unbound_text(unbound: list[tuple[str, int, str]]) -> str:
    return "; ".join(f"{sid} шаг {index} «{text[:60]}»" for sid, index, text in unbound[:8]) + (
        f" … и ещё {len(unbound) - 8}" if len(unbound) > 8 else "")


def _clean(value: Any) -> str:
    """Текст от модели в паспорт — через ту же чистку иероглифов, что и у
    трёх других проходов: GLM-5.2 вставляет CJK-символы в русский текст."""
    return _strip_cjk(str(value or "")).strip()


def _clean_fields(fields: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for fid, cell in fields.items():
        if isinstance(cell, dict):
            out[fid] = {**cell, "value": _clean(cell.get("value")),
                        "source": _clean(cell.get("source"))}
        else:
            out[fid] = cell
    return out


_HANDLERS: dict[str, Callable[[_PassportSession, dict], str]] = {
    "submit_node": _handle_submit_node,
    "declare_children": _handle_declare_children,
    "link_nodes": _handle_link_nodes,
    "bind_scenario_step": _handle_bind_scenario_step,
    "finish": _handle_finish,
}
_TOOL_NAMES = ", ".join(_HANDLERS)


def _unfinished(state: _PassportSession) -> list[str]:
    out: list[str] = []
    if state.awaiting_children_of:
        out.append(f"не объявлены дети {state.awaiting_children_of}")
    if state.current:
        out.append(f"не заполнен {state.current}")
    if state.queue:
        out.append(f"в очереди {len(state.queue)} узлов: " + ", ".join(state.queue[:5]))
    return out


def _advance(state: _PassportSession) -> str:
    """Следующий шаг протокола: очередной узел дерева или переход к связям."""
    if state.queue:
        nid = state.queue.pop(0)
        state.current = nid
        node = state.nodes[nid]
        parent = state.nodes[node.parent] if node.parent else None
        lines = [_tree_map(state), f"Заполни {nid} «{node.name}» ({TYPE_LABEL[node_type(nid)]}) — basis: {node.basis}."]
        if parent is not None:
            lines.append(f"Родитель {parent.id} «{parent.name}»: {_node_digest(parent)}")
        siblings = [state.nodes[c] for c in (parent.children if parent else []) if c != nid]
        if siblings:
            lines.append("Соседи: " + "; ".join(f"{s.id} «{s.name}»" for s in siblings))
        lines.append(f"Вызови submit_node(id=\"{nid}\") с полями раздела.")
        return "\n".join(lines)
    if not state.tree_done:
        state.tree_done = True
        return "\n".join([_tree_map(state), "Дерево построено.", _after_tree_text(state)])
    return _after_tree_text(state)


def _after_tree_text(state: _PassportSession) -> str:
    """Что делать после дерева: связи, привязка шагов сценариев, finish."""
    lines = [
        "Дальше: связи поверх дерева — link_nodes(from, to, kind, basis), виды: "
        + ", ".join(f"{k} ({RELATION_LABEL[k]})" for k in RELATION_KINDS)
        + "; общий BBB или операция, входящие в несколько процессов/блоков — kind=includes."
    ]
    unbound = state.unbound_steps()
    if unbound:
        lines.append(
            "Шаги сценариев без узла: " + _unbound_text(unbound)
            + ". Привяжи bind_scenario_step(scenario, step, nodes=[bbb-N | operation-N])."
        )
    elif state.scenarios:
        lines.append("Все шаги целевых сценариев привязаны к узлам.")
    lines.append("Исправить принятый узел можно повторным submit_node(id). Когда всё — finish.")
    return "\n".join(lines)


def _expected_submit(state: _PassportSession) -> set[str]:
    if state.awaiting_children_of:
        return set()
    if state.current:
        return {state.current}
    if not state.tree_done:
        return set()
    # После дерева — повторная отправка уже принятого узла (исправление по замечанию).
    return {n.id for n in state.nodes.values() if n.filled}


def _expected_text(state: _PassportSession) -> str:
    if state.awaiting_children_of:
        return f"declare_children(parent=\"{state.awaiting_children_of}\")"
    if state.current:
        return f"submit_node(id=\"{state.current}\")"
    if state.tree_done:
        return "link_nodes, bind_scenario_step, повторный submit_node принятого узла или finish"
    return "ничего: дерево не начато"


def _check_name_unique(check: PassportCheck, state: _PassportSession, nid: str, name: str) -> None:
    key = norm_name(name)
    if not key:
        return
    for other in state.nodes.values():
        if other.id != nid and norm_name(other.name) == key:
            check.errors.append(duplicate_name_message(nid, other.id, name))
            return


def _children_hint(ptype: str) -> str:
    return {
        "journey": "по одному на сценарий с собственными условиями запуска и завершением",
        "process": "одно бизнес-действие с одним ответом «что получили»; 3–6 на процесс, "
                   "включая определение сценария, получение данных, подбор, предложение, "
                   "объяснение, подтверждение, исполнение; общий с другим процессом блок — {ref: id}",
        "bbb": "шаг с наблюдаемым снаружи результатом, который может отказать отдельно; "
               "1–3 на BBB, обычно по способам исполнения; общая с другим блоком операция — {ref: id}",
    }[ptype]


def _node_digest(node: _Node, limit: int = 220) -> str:
    fields = node.data.get("fields") or {}
    parts = []
    for fid in sorted(fields):
        value = str((fields.get(fid) or {}).get("value") or "").strip()
        if value:
            parts.append(f"{fid}: {value[:limit]}")
        if len(parts) >= 3:
            break
    return " · ".join(parts) or "поля не заполнены"


def _tree_map(state: _PassportSession) -> str:
    """Карта построенного: id · название — basis, с отступами по уровням.
    Общий узел показан под каждым родителем, но раскрыт только под первым."""
    lines = ["Построено:"]

    def visit(nid: str, depth: int, via: str | None) -> None:
        node = state.nodes[nid]
        mark = "✓" if node.filled else "…"
        shared = via is not None and node.parent != via
        extra = ""
        if len(node.parents) > 1:
            extra = " (также в " + ", ".join(p for p in node.parents if p != via) + ")"
        lines.append(f"{'  ' * depth}{mark} {nid} «{node.name}» — {node.basis[:100]}{extra}")
        if shared:
            return
        for cid in node.children:
            visit(cid, depth + 1, nid)

    for root in state.of_type("journey"):
        visit(root.id, 0, None)
    business = [f"{r['from']} {RELATION_LABEL[r['kind']]} {r['to']}"
                for r in state.relations if r["kind"] != "includes"]
    if business:
        lines.append("Связи: " + "; ".join(business))
    return "\n".join(lines)


# --- сборка результата --------------------------------------------------------------

def _build_passport_data(state: _PassportSession, scope: str, date: str) -> dict[str, Any]:
    def rebuild(nid: str) -> dict[str, Any]:
        node = state.nodes[nid]
        out: dict[str, Any] = {"id": nid, "type": node_type(nid)}
        if node.children or node_type(nid) != "operation":
            # Под второстепенным родителем общий узел в дереве не повторяется:
            # его место — под первым; остальные связи живут в `parents`.
            out["children"] = [rebuild(c) for c in node.children if state.nodes[c].parent == nid]
        return out

    nodes: dict[str, Any] = {}
    for nid, node in state.nodes.items():
        entry: dict[str, Any] = {"name": node.name, "basis": node.basis, "fields": {},
                                 "parents": list(node.parents)}
        if node.filled:
            entry.update({k: v for k, v in node.data.items() if k not in ("name", "basis")})
        else:
            entry["object-version"] = "Не заполнено: сессия прервана до этого узла"
        nodes[nid] = entry
    data = {
        "analysis-scope": scope,
        "decision-boundary": state.decision_boundary,
        "analysis-date": date,
        "tree": [rebuild(n.id) for n in state.of_type("journey")],
        "nodes": nodes,
        "relations": [dict(r) for r in state.relations],
    }
    return normalize_passport(data)


@dataclass
class PassportAgentResult:
    passport_data: dict[str, Any] | None = None
    notes: list[str] = field(default_factory=list)
    steps: int = 0
    runtime_stats: dict[str, Any] = field(default_factory=dict)


# --- вход: сжатые знания сессии оценки -------------------------------------------------

def render_evaluation_digest(
    plan_items: list[PlanItem],
    verdicts: list[ItemVerdict],
    summary: ProjectSummary | None,
    knowledge: list[str],
) -> str:
    """Что узнала сессия оценки — единственный источник фактов для паспорта."""
    by_id = {v.item_id: v for v in verdicts}
    lines: list[str] = []
    if summary is not None:
        lines.append(f"Верхнеуровневая оценка: {summary.match} — {summary.match_note}")
    lines.append("Оценка этапов образа результата (статус · проверка · как работает · ссылки):")
    for item in plan_items:
        lines.append(f"## {item.title}")
        verdict = by_id.get(item.id)
        for idx, text in enumerate(item.criteria):
            crit = verdict.criteria[idx] if verdict and idx < len(verdict.criteria) else None
            if crit is None:
                lines.append(f"- {text} — не оценено")
                continue
            lines.append(f"- {text} — {crit.status}")
            if crit.proof:
                lines.append(f"  проверка: {crit.proof[:_MAX_PROOF_CHARS]}")
            if crit.how:
                lines.append(f"  как работает: {crit.how[:_MAX_PROOF_CHARS]}")
            for ev in crit.evidence:
                if getattr(ev, "verified", False):
                    lines.append(f"  · {ev.path}:{ev.line} — {ev.basis}" + (f" — {ev.note}" if getattr(ev, 'note', '') else ""))
    if knowledge:
        lines.append("")
        lines.append("Что сессия оценки читала в коде (сжатый след):")
        total = 0
        for entry in knowledge:
            total += len(entry) + 1
            if total > _MAX_KNOWLEDGE_CHARS:
                lines.append("… (след обрезан)")
                break
            lines.append(entry)
    return "\n".join(lines)


def render_scenarios_digest(connectivity: ConnectivityReview | None) -> str:
    """Целевые сценарии ревизии — для привязки узлов (`scenario_steps`)."""
    if connectivity is None or not connectivity.scenarios:
        return ""
    lines = ["Целевые сценарии (для scenario_steps: id сценария и номер шага с нуля; "
             "каждый шаг обязан получить узел bbb/operation, иначе finish попросит привязать):"]
    for scenario in connectivity.scenarios:
        status = scenario.status
        lines.append(f"{scenario.id} «{scenario.title}» — {status}"
                     + (", критический" if scenario.critical else ""))
        for index, step in enumerate(scenario.steps):
            handoff = scenario.handoff_at(index)
            mark = ""
            if handoff is not None and index < scenario.transitions:
                mark = f" → стык после шага: {handoff.result}"
            lines.append(f"  {index}: {step}{mark}")
    return "\n".join(lines)


def run_passport_agent(
    plan_items: list[PlanItem],
    context: dict[str, str],
    verdicts: list[ItemVerdict],
    summary: ProjectSummary | None,
    spec: ModelSpec | None,
    client: ChatClient | None = None,
    capability_digest: str = "",
    knowledge: list[str] | None = None,
    source_text: str | None = None,
    repo_name: str = "",
    commit: str = "",
    max_steps: int | None = None,
    on_node: Callable[[str, str], None] | None = None,
    connectivity: ConnectivityReview | None = None,
) -> PassportAgentResult:
    """Собрать паспорт клиентского пути отдельной сессией по знаниям оценки.

    `connectivity` — целевые сценарии ревизии: узлы привязываются к их шагам,
    и схема паспорта показывает путь сценария и разрывы на стыках.
    """
    if spec is None:
        return PassportAgentResult(notes=["Паспорт: matcher не настроен"])
    if max_steps is None:
        max_steps = int(_env_number("PKO_PASSPORT_MAX_STEPS", DEFAULT_PASSPORT_MAX_STEPS))

    # Название пути — строго из образа результата; имя проекта и репозитория
    # только когда в тексте инициативы названия нет.
    journey_name = journey_name_of(context, repo_name)
    state = _PassportSession(
        on_node=on_node,
        plan_bullets=[str(text) for item in plan_items for text in item.criteria],
        scenarios={s.id: list(s.steps) for s in (connectivity.scenarios if connectivity else [])},
    )
    root = state.new_id("journey")
    state.nodes[root] = _Node(id=root, name=journey_name, basis="путь задан образом результата инициативы")
    state.queue.append(root)

    brief = [
        f"Клиентский путь: {journey_name}. Проект: {context.get('project_name') or '—'}.",
        f"Было: {context.get('before') or '—'}. Стало: {context.get('after') or '—'}.",
    ]
    if source_text and source_text.strip():
        brief.append("Дословный текст инициативы:\n" + source_text.strip()[:4000])
    if capability_digest:
        brief.append(capability_digest)
    brief.append(render_evaluation_digest(plan_items, verdicts, summary, knowledge or []))
    scenarios_digest = render_scenarios_digest(connectivity)
    if scenarios_digest:
        brief.append(scenarios_digest)
    brief.append("")
    brief.append(_advance(state))
    user_brief = "\n\n".join(brief)

    try:
        system_prompt = _PROMPT_PATH.read_text(encoding="utf-8")
    except OSError:
        system_prompt = "Ты заполняешь паспорт клиентского пути по знаниям сессии оценки."
        state.notes.append("Промпт паспортного агента не найден: passport_system.md")

    chat_client = client if client is not None else ChatClient(spec=spec)
    thinking_on = bool(
        spec.extra_body
        and spec.extra_body.get("chat_template_kwargs", {}).get("enable_thinking") is True
    )
    # Потолок ответа — тот же выбор, что у трёх других проходов: в режиме
    # рассуждения в него входит `reasoning_content`, и тесный бюджет даёт
    # пустой `content`.
    max_tokens = max_tokens_for(thinking_on)
    schemas = _PASSPORT_TOOL_SCHEMAS
    budget_seconds = _env_number("PKO_PASSPORT_MAX_SECONDS", DEFAULT_PASSPORT_SECONDS)
    run = run_agent_loop(
        chat_client=chat_client,
        system_prompt=system_prompt,
        user_prompt=user_brief,
        tools=schemas,
        config=AgentLoopConfig(
            role="passport",
            session_span="passport_session",
            step_span="passport.step",
            max_steps=max(1, max_steps),
            max_seconds=budget_seconds,
            max_tokens=max_tokens,
            window_tokens=max(0, getattr(spec, "context_window", 0) or 0),
            malformed_limit=_MAX_MALFORMED,
            repeat_limit=3,
        ),
        hooks=AgentLoopHooks(
            answer_call=lambda call: _answer_call(state, call),
            is_finished=lambda: state.finished,
            nudge=lambda: "Нужно вызвать инструмент: " + _expected_text(state),
            compact=lambda messages, _budget: _compact_history(messages),
            on_session_start=lambda span: setattr(state, "span", span),
            final_trace_attributes=lambda: {
                "nodes": len(state.nodes),
                "relations": len(state.relations),
            },
        ),
    )
    steps_done = run.stats.steps_done
    _append_passport_stop_note(state.notes, run.stats, budget_seconds, max_steps)

    if not state.finished:
        missing = _unfinished(state)
        if missing:
            state.notes.append("паспорт не завершён: " + "; ".join(missing))
        unbound = state.unbound_steps()
        if unbound and state.scenarios:
            state.remarks.append("шаги сценариев без узла на схеме: " + _unbound_text(unbound))
    unfilled = [n.id for n in state.nodes.values() if not n.filled]
    if unfilled:
        state.notes.append("паспорт: узлы объявлены, но не заполнены: " + ", ".join(unfilled[:8]))
    check = PassportCheck()
    check_router_present(check, {nid: n.data for nid, n in state.nodes.items() if n.filled})
    state.remarks.extend(check.remarks)
    if state.remarks:
        state.notes.append("Замечания к паспорту: " + "; ".join(dict.fromkeys(state.remarks)))

    if state.plan_bullets:
        linked = {b for n in state.nodes.values() if n.filled for b in (n.data.get("bullets") or [])}
        unlinked = [b for b in state.plan_bullets if b not in linked]
        if unlinked:
            state.notes.append(
                f"паспорт: пунктов ОР без узла на схеме — {len(unlinked)} из {len(state.plan_bullets)}: "
                + "; ".join(f"«{b[:60]}»" for b in unlinked[:4])
            )
    filled_any = any(n.filled for n in state.nodes.values())
    scope = f"{repo_name} · коммит {commit[:8] if commit else '—'} · {context.get('project_name') or journey_name}"
    data = _build_passport_data(state, scope, time.strftime("%Y-%m-%d")) if filled_any else None
    return PassportAgentResult(
        passport_data=data,
        notes=state.notes,
        steps=steps_done,
        runtime_stats=run.stats.model_dump(mode="json"),
    )


def _append_passport_stop_note(
    notes: list[str], stats: AgentRunStats, budget_seconds: float, max_steps: int,
) -> None:
    if stats.stop_reason == StopReason.TIME_LIMIT:
        notes.append(
            f"паспорт: время сессии исчерпано ({int(budget_seconds)} с) "
            f"на шаге {stats.steps_done}"
        )
    elif stats.stop_reason == StopReason.MODEL_ERROR:
        notes.append(
            f"паспорт: агент недоступен на шаге {stats.steps_done}: {stats.error_message}"
        )
    elif stats.stop_reason == StopReason.MALFORMED_OUTPUT:
        notes.append(
            f"паспорт: агент не вызвал инструмент {stats.malformed_responses} "
            "раз подряд — остановлено"
        )
    elif stats.stop_reason == StopReason.REPEATED_TOOL_CALLS:
        notes.append("паспорт: остановлено — 3 одинаковых вызова подряд")
    elif stats.stop_reason == StopReason.TOOL_BUDGET:
        notes.append(
            f"паспорт: бюджет инструментов исчерпан ({stats.tool_calls}); "
            "сессия остановлена"
        )
    elif stats.stop_reason == StopReason.STEP_LIMIT:
        notes.append(f"паспорт: бюджет шагов исчерпан ({max_steps})")


def _answer_call(state: _PassportSession, call: dict) -> dict[str, Any]:
    parsed, error = parse_tool_call(call, _PASSPORT_TOOL_SCHEMAS)
    if parsed is None:
        return tool_message(call, error)
    name = parsed.name
    args = parsed.arguments
    handler = _HANDLERS.get(name)
    if handler is None:
        content = f"инструмента «{name}» нет. Доступны: {_TOOL_NAMES}. " + _expected_text(state)
    else:
        content = handler(state, args)
    return tool_message(call, content)


# Ответ кода на каждый принятый узел несёт карту дерева целиком; в истории
# она нужна только последняя. Старые ответы ужимаются до первой строки —
# факт принятия остаётся, карта не копится.
_KEEP_RECENT_TOOL_REPLIES = 2


def _compact_history(messages: list[dict[str, Any]]) -> int:
    compacted = 0
    tool_idx = [i for i, m in enumerate(messages) if m.get("role") == "tool"]
    for i in tool_idx[:-_KEEP_RECENT_TOOL_REPLIES]:
        content = str(messages[i].get("content") or "")
        if "\nПостроено:" in content or content.startswith("Построено:"):
            shortened = content.split("\n", 1)[0]
            if shortened != content:
                messages[i]["content"] = shortened
                compacted += 1
    return compacted

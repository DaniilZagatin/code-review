"""Typed guardrails shared by the PKO agent loops.

The domain handlers deliberately remain ordinary Python: they contain the
business gates and are already well covered by tests.  This module hardens the
boundary in front of them instead:

* tool-call envelopes are validated with Pydantic;
* arguments are checked locally against the advertised JSON schema;
* object schemas reject unknown fields by default;
* model turns cannot bypass the step budget by emitting an unbounded batch of
  tool calls;
* every proposed call still receives exactly one tool result, including calls
  denied by the budget or after an accepted ``finish``.

It is intentionally smaller than a PydanticAI migration.  PKO has custom
OpenAI-compatible endpoints and mature deterministic gates; replacing the
whole loop would add provider coupling without improving those gates.
"""

from __future__ import annotations

import copy
import hashlib
import json
import os
from collections.abc import Callable
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError


class _FunctionEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    name: str = Field(min_length=1, max_length=128)
    arguments: str = "{}"


class _ToolCallEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    id: str = Field(min_length=1, max_length=256)
    type: Literal["function"] = "function"
    function: _FunctionEnvelope


class ParsedToolCall(BaseModel):
    """Validated model proposal passed to a domain handler."""

    model_config = ConfigDict(extra="forbid", strict=True)

    call_id: str
    name: str
    arguments: dict[str, Any]


class ToolCallBudget(BaseModel):
    """Host-owned tool-call budget, separate from the model-turn budget."""

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    max_total: int = Field(ge=1)
    max_per_turn: int = Field(ge=1)
    used: int = Field(default=0, ge=0)
    denied: int = Field(default=0, ge=0)

    @classmethod
    def for_steps(cls, max_steps: int) -> "ToolCallBudget":
        """Build a bounded budget with optional deployment overrides."""

        default_total = max(16, max(1, max_steps) * 4)
        return cls(
            max_total=_positive_env("PKO_MAX_TOOL_CALLS", default_total),
            max_per_turn=_positive_env("PKO_MAX_TOOL_CALLS_PER_TURN", 8),
        )

    def admit(self, turn_index: int) -> tuple[bool, str]:
        if turn_index >= self.max_per_turn:
            self.denied += 1
            return False, "per_turn"
        if self.used >= self.max_total:
            self.denied += 1
            return False, "total"
        self.used += 1
        return True, ""


class DispatchReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    messages: list[dict[str, Any]] = Field(default_factory=list)
    admitted: int = 0
    denied: int = 0
    denied_after_finish: int = 0
    total_exhausted: bool = False


def harden_tool_schemas(schemas: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return a copy whose declared object shapes reject unknown properties.

    Open-ended maps (for example passport field IDs) intentionally have no
    ``properties`` member and remain open.  Objects with a declared shape get
    ``additionalProperties: false`` recursively.
    """

    hardened = copy.deepcopy(schemas)
    for tool in hardened:
        function = tool.get("function") or {}
        _close_declared_objects(function.get("parameters"))
    return hardened


def normalize_tool_call_dicts(raw_calls: list[Any]) -> list[dict[str, Any]]:
    """Normalize cached/SDK calls and supply stable, unique missing IDs."""

    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw in enumerate(raw_calls, start=1):
        row = raw if isinstance(raw, dict) else {}
        function = row.get("function") if isinstance(row.get("function"), dict) else {}
        call_id = str(row.get("id") or f"call_{index}")
        base = call_id
        suffix = 2
        while call_id in seen:
            call_id = f"{base}_{suffix}"
            suffix += 1
        seen.add(call_id)
        normalized.append({
            "id": call_id,
            "type": "function",
            "function": {
                "name": str(function.get("name") or ""),
                "arguments": str(function.get("arguments") or "{}"),
            },
        })
    return normalized


def parse_tool_call(
    call: dict[str, Any], schemas: list[dict[str, Any]],
) -> tuple[ParsedToolCall | None, str]:
    """Validate one call envelope and its arguments before dispatch."""

    try:
        envelope = _ToolCallEnvelope.model_validate(call)
    except ValidationError as exc:
        return None, "вызов инструмента отклонён: некорректный конверт — " + _pydantic_error(exc)

    try:
        arguments = json.loads(envelope.function.arguments or "{}")
    except json.JSONDecodeError as exc:
        return None, f"аргументы инструмента не являются валидным JSON: {exc}"
    if not isinstance(arguments, dict):
        return None, "аргументы инструмента отклонены: корнем должен быть JSON-объект"

    schema = _schema_by_name(schemas).get(envelope.function.name)
    if schema is not None:
        problem = _validate_value(arguments, schema, path="arguments")
        if problem:
            return None, "аргументы инструмента отклонены схемой: " + problem

    return ParsedToolCall(
        call_id=envelope.id,
        name=envelope.function.name,
        arguments=arguments,
    ), ""


def tool_message(call: dict[str, Any], content: str) -> dict[str, Any]:
    """Build the mandatory result paired with a model tool call."""

    return {
        "role": "tool",
        "tool_call_id": str(call.get("id") or "missing_tool_call_id"),
        "content": content,
    }


def dispatch_tool_calls(
    calls: list[dict[str, Any]],
    *,
    answer: Callable[[dict[str, Any]], dict[str, Any]],
    budget: ToolCallBudget,
    is_finished: Callable[[], bool] | None = None,
) -> DispatchReport:
    """Dispatch a model batch while preserving one-result-per-call.

    Calls are serialized because protocol tools mutate session state.  Once a
    ``finish`` handler accepts completion, later calls from the same model
    message are denied instead of mutating an already-finished session.
    """

    report = DispatchReport()
    for index, call in enumerate(calls):
        if is_finished is not None and is_finished():
            report.denied += 1
            report.denied_after_finish += 1
            report.messages.append(tool_message(
                call,
                "вызов отклонён [session_finished]: сессия уже завершена; "
                "после принятого finish состояние не меняется",
            ))
            continue

        allowed, reason = budget.admit(index)
        if not allowed:
            report.denied += 1
            if reason == "total":
                report.total_exhausted = True
                detail = f"общий лимит {budget.max_total} вызовов исчерпан"
            else:
                detail = f"за один ход разрешено не больше {budget.max_per_turn} вызовов"
            report.messages.append(tool_message(
                call,
                f"вызов отклонён [tool_budget_exceeded]: {detail}",
            ))
            continue

        report.admitted += 1
        report.messages.append(answer(call))
    return report


def deny_tool_calls(calls: list[dict[str, Any]], reason: str) -> list[dict[str, Any]]:
    """Pair every unexecuted proposal with an explicit denial result."""

    return [tool_message(call, reason) for call in calls]


def bundle_fingerprint(value: Any) -> str:
    """Stable short hash for prompt/tool-bundle fragmentation telemetry."""

    if isinstance(value, str):
        raw = value
    else:
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def trace_model_result(span: Any, result: Any) -> None:
    """Record the same cost/cache/result shape for every agent role."""

    span.set_attribute("from_cache", bool(getattr(result, "from_cache", False)))
    span.set_attribute("text_chars", len(getattr(result, "text", "") or ""))
    span.set_attribute(
        "reasoning_chars", len(getattr(result, "reasoning_content", "") or ""),
    )
    calls = getattr(result, "tool_calls", None) or []
    names = ",".join(str((call.get("function") or {}).get("name") or "") for call in calls)
    span.set_attribute("tool_calls", names)
    span.set_attribute("tool_call_count", len(calls))
    usage = getattr(result, "usage", None) or {}
    if usage:
        span.set_attribute("prompt_tokens", usage.get("prompt_tokens", 0))
        span.set_attribute("completion_tokens", usage.get("completion_tokens", 0))
        span.set_attribute("total_tokens", usage.get("total_tokens", 0))
        span.set_attribute("cached_tokens", usage.get("cached_tokens", 0))


def _positive_env(name: str, default: int) -> int:
    raw = (os.environ.get(name) or "").strip()
    try:
        value = int(raw) if raw else default
    except ValueError:
        value = default
    return max(1, value)


def _close_declared_objects(node: Any) -> None:
    if not isinstance(node, dict):
        return
    if node.get("type") == "object" and isinstance(node.get("properties"), dict):
        node.setdefault("additionalProperties", False)
        for child in node["properties"].values():
            _close_declared_objects(child)
    if node.get("type") == "array":
        _close_declared_objects(node.get("items"))


def _schema_by_name(schemas: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for tool in schemas:
        function = tool.get("function") or {}
        name = str(function.get("name") or "")
        parameters = function.get("parameters")
        if name and isinstance(parameters, dict):
            out[name] = parameters
    return out


def _validate_value(value: Any, schema: dict[str, Any], path: str) -> str:
    expected = schema.get("type")
    if expected == "object":
        if not isinstance(value, dict):
            return f"{path}: ожидался object, получен {_json_type(value)}"
        properties = schema.get("properties") or {}
        for required in schema.get("required") or []:
            if required not in value:
                return f"{path}.{required}: обязательное поле отсутствует"
        if schema.get("additionalProperties") is False:
            unknown = sorted(set(value) - set(properties))
            if unknown:
                return f"{path}: неизвестные поля: {', '.join(unknown)}"
        for key, child in properties.items():
            if key in value and isinstance(child, dict):
                problem = _validate_value(value[key], child, f"{path}.{key}")
                if problem:
                    return problem
    elif expected == "array":
        if not isinstance(value, list):
            return f"{path}: ожидался array, получен {_json_type(value)}"
        if "minItems" in schema and len(value) < int(schema["minItems"]):
            return f"{path}: элементов {len(value)}, минимум {schema['minItems']}"
        if "maxItems" in schema and len(value) > int(schema["maxItems"]):
            return f"{path}: элементов {len(value)}, максимум {schema['maxItems']}"
        child = schema.get("items")
        if isinstance(child, dict):
            for index, item in enumerate(value):
                problem = _validate_value(item, child, f"{path}[{index}]")
                if problem:
                    return problem
    elif expected == "string" and not isinstance(value, str):
        return f"{path}: ожидался string, получен {_json_type(value)}"
    elif expected == "integer" and (not isinstance(value, int) or isinstance(value, bool)):
        return f"{path}: ожидался integer, получен {_json_type(value)}"
    elif expected == "number" and (
        not isinstance(value, (int, float)) or isinstance(value, bool)
    ):
        return f"{path}: ожидался number, получен {_json_type(value)}"
    elif expected == "boolean" and not isinstance(value, bool):
        return f"{path}: ожидался boolean, получен {_json_type(value)}"

    allowed = schema.get("enum")
    if isinstance(allowed, list) and value not in allowed:
        return f"{path}: значение {value!r} не входит в допустимый список"
    return ""


def _json_type(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    if isinstance(value, str):
        return "string"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    return type(value).__name__


def _pydantic_error(exc: ValidationError) -> str:
    first = exc.errors(include_url=False)[0]
    location = ".".join(str(part) for part in first.get("loc") or [])
    message = str(first.get("msg") or "ошибка валидации")
    return f"{location}: {message}" if location else message

"""Provider-neutral context accounting and deterministic compaction.

The progress agents used to import these helpers from ``progress.matcher``.
That made the matcher an accidental runtime dependency of every other role.
Keeping context policy next to the LLM runtime makes the dependency direction
explicit: domain agents depend on the harness, never on another domain agent.
"""

from __future__ import annotations

import json
import os
from typing import Any


DEFAULT_HISTORY_BUDGET_CHARS = 80_000
DEFAULT_CHARS_PER_TOKEN = 1.8
WINDOW_SAFETY_TOKENS = 8_000
WINDOW_FILL = 0.85
TRIMMED_TOOL_RESULT = (
    "(вывод инструмента убран из истории: она переросла бюджет контекста. "
    "Если эти данные ещё нужны — запроси их снова.)"
)


def history_budget(
    window_tokens: int = 0,
    reserve_tokens: int = 0,
    chars_per_token: float = DEFAULT_CHARS_PER_TOKEN,
    overhead_chars: int = 0,
) -> int:
    """Return the safe character budget for the message history.

    ``PKO_HISTORY_BUDGET`` remains an operator-owned hard override.  The
    default formula reserves response tokens and a safety margin, then keeps
    the request below 85% of the advertised model window.
    """

    raw = os.environ.get("PKO_HISTORY_BUDGET", "").strip()
    if raw.isdigit() and int(raw) > 0:
        return int(raw)
    if window_tokens <= 0:
        return DEFAULT_HISTORY_BUDGET_CHARS

    usable = int(window_tokens * WINDOW_FILL) - reserve_tokens - WINDOW_SAFETY_TOKENS
    budget = int(usable * max(chars_per_token, 0.5)) - overhead_chars
    return max(budget, 20_000)


def measure_token_density(history_chars: int, prompt_tokens: int) -> float | None:
    """Estimate characters per token from provider usage telemetry."""

    if prompt_tokens <= 0 or history_chars <= 0:
        return None
    density = history_chars / prompt_tokens
    if not 1.0 <= density <= 6.0:
        return None
    return density


def message_size(message: dict[str, Any]) -> int:
    """Approximate all message content that consumes the model window."""

    size = len(str(message.get("content") or ""))
    size += len(str(message.get("reasoning_content") or ""))
    for call in message.get("tool_calls") or []:
        function = call.get("function") or {}
        size += len(str(function.get("name") or ""))
        size += len(str(function.get("arguments") or ""))
    return size


def trim_tool_history(
    messages: list[dict[str, Any]],
    budget: int,
    *,
    replacement: str = TRIMMED_TOOL_RESULT,
) -> int:
    """Compact old tool payloads without breaking call/result pairing."""

    total = sum(message_size(message) for message in messages)
    if total <= budget:
        return 0

    trimmed = 0
    for message in messages[2:]:
        if total <= budget:
            break
        if message.get("role") != "tool":
            continue
        content = str(message.get("content") or "")
        if len(content) <= len(replacement):
            continue
        total -= len(content) - len(replacement)
        message["content"] = replacement
        trimmed += 1
    return trimmed


def tool_call_signature(calls: list[dict[str, Any]]) -> tuple[tuple[str, str], ...]:
    """Build a deterministic signature used by the repeated-call guard."""

    signature: list[tuple[str, str]] = []
    for call in calls:
        function = call.get("function") or {}
        name = str(function.get("name") or "")
        raw_arguments = str(function.get("arguments") or "{}")
        try:
            parsed = json.loads(raw_arguments)
            arguments = json.dumps(
                parsed, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
            )
        except (json.JSONDecodeError, TypeError, ValueError):
            arguments = raw_arguments
        signature.append((name, arguments))
    return tuple(sorted(signature))

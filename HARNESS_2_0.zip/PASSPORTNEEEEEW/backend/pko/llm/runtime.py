"""Shared, typed runtime for PKO's single-agent tool loops.

Domain modules own their state machines and validation rules.  This module
owns the control plane around them: model turns, tool dispatch, budgets,
context compaction, stopping, and operational trace events.

No hidden reasoning text is persisted in events.  The runtime records only
counts, tool names, budget decisions, and stop reasons.
"""

from __future__ import annotations

import json
import time
from collections.abc import Callable
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from pko.errors import LlmError
from pko.llm.client import ChatClient, ChatResult
from pko.llm.context import (
    DEFAULT_CHARS_PER_TOKEN,
    history_budget,
    measure_token_density,
    message_size,
    tool_call_signature,
    trim_tool_history,
)
from pko.llm.harness import (
    ToolCallBudget,
    bundle_fingerprint,
    deny_tool_calls,
    dispatch_tool_calls,
    trace_model_result,
)
from pko.llm.tracing import trace_span


class StopReason(StrEnum):
    """Machine-readable reason why an agent loop returned control."""

    FINISHED = "finished"
    STEP_LIMIT = "step_limit"
    TIME_LIMIT = "time_limit"
    TOOL_BUDGET = "tool_budget"
    MALFORMED_OUTPUT = "malformed_output"
    REPEATED_TOOL_CALLS = "repeated_tool_calls"
    MODEL_ERROR = "model_error"


class AgentLoopConfig(BaseModel):
    """Host-owned limits and stable identifiers for one agent role."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    role: str = Field(min_length=1, max_length=64)
    session_span: str = Field(min_length=1, max_length=128)
    step_span: str = Field(min_length=1, max_length=128)
    max_steps: int = Field(ge=1)
    max_seconds: float = Field(default=0.0, ge=0.0)
    max_tokens: int = Field(ge=1)
    window_tokens: int = Field(default=0, ge=0)
    malformed_limit: int = Field(default=3, ge=1)
    repeat_limit: int = Field(default=3, ge=0)
    manage_context: bool = True


class AgentEvent(BaseModel):
    """Bounded operational event suitable for replay and trace grading."""

    model_config = ConfigDict(extra="forbid")

    kind: str = Field(min_length=1, max_length=64)
    step: int = Field(default=0, ge=0)
    details: dict[str, Any] = Field(default_factory=dict)


class AgentRunStats(BaseModel):
    """Typed outcome of the control loop, independent of domain output."""

    model_config = ConfigDict(extra="forbid")

    role: str
    stop_reason: StopReason
    completed: bool = False
    steps_done: int = Field(default=0, ge=0)
    model_calls: int = Field(default=0, ge=0)
    tool_calls: int = Field(default=0, ge=0)
    tool_calls_denied: int = Field(default=0, ge=0)
    malformed_responses: int = Field(default=0, ge=0)
    trimmed_messages: int = Field(default=0, ge=0)
    prompt_tokens: int = Field(default=0, ge=0)
    completion_tokens: int = Field(default=0, ge=0)
    cached_tokens: int = Field(default=0, ge=0)
    cache_hits: int = Field(default=0, ge=0)
    elapsed_seconds: float = Field(default=0.0, ge=0.0)
    error_message: str = ""


class AgentLoopResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    messages: list[dict[str, Any]]
    stats: AgentRunStats
    events: list[AgentEvent]


@dataclass(frozen=True)
class AgentLoopHooks:
    """Domain callbacks used by the provider-neutral loop."""

    answer_call: Callable[[dict[str, Any]], dict[str, Any]]
    is_finished: Callable[[], bool]
    nudge: str | Callable[[], str]
    after_turn: Callable[[list[dict[str, Any]], int, ChatResult], None] | None = None
    compact: Callable[[list[dict[str, Any]], int], int] | None = None
    on_session_start: Callable[[Any], None] | None = None
    final_trace_attributes: Callable[[], dict[str, Any]] | None = None


def run_agent_loop(
    *,
    chat_client: ChatClient,
    system_prompt: str,
    user_prompt: str,
    tools: list[dict[str, Any]],
    config: AgentLoopConfig,
    hooks: AgentLoopHooks,
    tool_budget: ToolCallBudget | None = None,
) -> AgentLoopResult:
    """Run one bounded tool-calling session and return a typed outcome."""

    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]
    budget = tool_budget or ToolCallBudget.for_steps(config.max_steps)
    overhead_chars = len(json.dumps(
        tools, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
    ))
    density = DEFAULT_CHARS_PER_TOKEN
    deadline = time.monotonic() + config.max_seconds if config.max_seconds else 0.0
    started = time.monotonic()
    malformed = 0
    recent_calls: list[tuple[tuple[str, str], ...]] = []
    events: list[AgentEvent] = []
    stats = AgentRunStats(role=config.role, stop_reason=StopReason.STEP_LIMIT)

    with trace_span(config.session_span) as session_span:
        session_span.set_attribute("agent_role", config.role)
        session_span.set_attribute("system_prompt_hash", bundle_fingerprint(system_prompt))
        session_span.set_attribute("tool_bundle_hash", bundle_fingerprint(tools))
        session_span.set_attribute("max_steps", config.max_steps)
        session_span.set_attribute("max_seconds", config.max_seconds)
        if hooks.on_session_start is not None:
            hooks.on_session_start(session_span)

        def emit(kind: str, step: int = 0, **details: Any) -> None:
            event = AgentEvent(kind=kind, step=step, details=details)
            events.append(event)
            session_span.add_event(kind, step=step, **details)

        emit("session_started", max_steps=config.max_steps)

        for step in range(1, config.max_steps + 1):
            stats.steps_done = step
            if deadline and time.monotonic() > deadline:
                stats.stop_reason = StopReason.TIME_LIMIT
                emit("budget_exhausted", step, budget="time")
                break

            sent_chars = sum(message_size(message) for message in messages) + overhead_chars
            with trace_span(config.step_span, step=step) as step_span:
                try:
                    result = chat_client.chat(
                        messages, tools=tools, max_tokens=config.max_tokens,
                    )
                except LlmError as exc:
                    step_span.set_attribute("error", exc.message)
                    stats.stop_reason = StopReason.MODEL_ERROR
                    stats.error_message = f"{exc.message} {exc.hint}".strip()
                    emit("model_error", step, message=stats.error_message)
                    break
                trace_model_result(step_span, result)

            stats.model_calls += 1
            if result.from_cache:
                stats.cache_hits += 1
            _accumulate_usage(stats, result.usage)
            call_names = [
                str((call.get("function") or {}).get("name") or "")
                for call in (result.tool_calls or [])
            ]
            emit(
                "model_turn", step,
                tool_count=len(call_names),
                tool_names=",".join(call_names),
                text_chars=len(result.text or ""),
                reasoning_chars=len(result.reasoning_content or ""),
                from_cache=result.from_cache,
            )

            if not result.tool_calls:
                malformed += 1
                stats.malformed_responses = malformed
                emit("malformed_model_output", step, consecutive=malformed)
                if malformed >= config.malformed_limit:
                    stats.stop_reason = StopReason.MALFORMED_OUTPUT
                    break
                messages.append({"role": "assistant", "content": result.text})
                nudge = hooks.nudge() if callable(hooks.nudge) else hooks.nudge
                messages.append({"role": "user", "content": nudge})
                continue
            malformed = 0

            messages.append({
                "role": "assistant",
                "content": result.text or None,
                "tool_calls": result.tool_calls,
                "reasoning_content": result.reasoning_content or None,
            })

            signature = tool_call_signature(result.tool_calls)
            recent_calls.append(signature)
            repeated = (
                config.repeat_limit > 0
                and len(recent_calls) >= config.repeat_limit
                and len(set(recent_calls[-config.repeat_limit:])) == 1
            )
            if repeated:
                messages.extend(deny_tool_calls(
                    result.tool_calls,
                    "вызов отклонён [repeated_call]: тот же набор вызовов повторён "
                    f"{config.repeat_limit} раза подряд; сессия остановлена",
                ))
                stats.stop_reason = StopReason.REPEATED_TOOL_CALLS
                emit("repeated_tool_calls", step, consecutive=config.repeat_limit)
                break

            dispatched = dispatch_tool_calls(
                result.tool_calls,
                answer=hooks.answer_call,
                budget=budget,
                is_finished=hooks.is_finished,
            )
            messages.extend(dispatched.messages)
            emit(
                "tool_batch", step,
                proposed=len(result.tool_calls),
                admitted=dispatched.admitted,
                denied=dispatched.denied,
                denied_after_finish=dispatched.denied_after_finish,
            )
            if dispatched.total_exhausted:
                stats.stop_reason = StopReason.TOOL_BUDGET
                emit("budget_exhausted", step, budget="tool_calls")
                break

            measured = measure_token_density(
                sent_chars, int((result.usage or {}).get("prompt_tokens") or 0),
            )
            if measured is not None:
                density = measured

            if config.manage_context:
                context_budget = history_budget(
                    window_tokens=config.window_tokens,
                    reserve_tokens=config.max_tokens,
                    chars_per_token=density,
                    overhead_chars=overhead_chars,
                )
                compact = hooks.compact or trim_tool_history
                cut = max(0, int(compact(messages, context_budget) or 0))
                if cut:
                    stats.trimmed_messages += cut
                    emit("context_compaction", step, messages_trimmed=cut)

            if hooks.after_turn is not None:
                hooks.after_turn(messages, step, result)

            if hooks.is_finished():
                stats.completed = True
                stats.stop_reason = StopReason.FINISHED
                emit("session_completed", step)
                break
        else:
            stats.stop_reason = StopReason.STEP_LIMIT
            emit("budget_exhausted", config.max_steps, budget="model_turns")

        stats.tool_calls = budget.used
        stats.tool_calls_denied = budget.denied
        stats.elapsed_seconds = max(0.0, time.monotonic() - started)
        session_span.set_attribute("steps_done", stats.steps_done)
        session_span.set_attribute("finished", stats.completed)
        session_span.set_attribute("stop_reason", stats.stop_reason.value)
        session_span.set_attribute("tool_calls", stats.tool_calls)
        session_span.set_attribute("tool_calls_denied", stats.tool_calls_denied)
        session_span.set_attribute("trimmed_messages", stats.trimmed_messages)
        session_span.set_attribute("elapsed_seconds", stats.elapsed_seconds)
        if hooks.final_trace_attributes is not None:
            for key, value in hooks.final_trace_attributes().items():
                session_span.set_attribute(key, value)

    return AgentLoopResult(messages=messages, stats=stats, events=events)


def _accumulate_usage(stats: AgentRunStats, usage: dict[str, Any] | None) -> None:
    if not usage:
        return
    stats.prompt_tokens += max(0, int(usage.get("prompt_tokens") or 0))
    stats.completion_tokens += max(0, int(usage.get("completion_tokens") or 0))
    stats.cached_tokens += max(0, int(usage.get("cached_tokens") or 0))

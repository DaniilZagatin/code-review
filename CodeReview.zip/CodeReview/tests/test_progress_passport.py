"""Паспорт клиентского пути: инструмент `submit_passport` в сессии агента,
проход данных до `ProgressModel` и рендер HTML по шаблону ДПСС v3.

Паспорт — отдельный артефакт рядом с дашбордом. Он ничего не оценивает:
статусы, готовность и решение остаются прежними, заполнил его агент или
нет. Если агент до `submit_passport` не дошёл, паспорт собирается
детерминированно из модели и экстракции, а в `gaps` остаётся заметка.
"""

import tempfile
import unittest
from pathlib import Path

import pko.llm.client as client_module
from agent_script import (
    JOURNEY_TEXT,
    PASSPORT,
    PASSPORT_BBB2_NAME,
    PASSPORT_JOURNEY_NAME,
    full_session,
    passport_args,
    stage_args,
    summary_args,
    tool_call,
)
from fixture_support import ensure_fixture, make_openai_response, scripted_responses
from pko.git.repo import GitRepo
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.progress import matcher
from pko.progress.matcher import run_agent
from pko.progress.pipeline import run_progress
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import PlanItem
from pko.progress.target_repo import load_target
from pko.render import client_journey_passport as passport_render
from pko.render.client_journey_passport import (
    flatten_passport_data,
    passport_registry_rows,
    passport_tree_spec,
    render_client_journey_passport,
    render_passport_from_model,
)

SPEC = ModelSpec(role="matcher", base_url="https://stub.local/v1", model="stub-model", api_key="x")
BULLETS = ["Определены источники обращений", "Подтверждена скорость обработки"]
CONTEXT = {
    "client_path_name": "Постановка задачи в работу",
    "project_name": "Приём обращений",
    "before": "задача пересылается вручную",
    "after": "задача попадает исполнителю сразу",
}


def _plan() -> list[PlanItem]:
    return [PlanItem(id="intake", title="Постановка задачи", criteria=BULLETS, origin="user")]


def _recording_responses(*answers):
    """Как `scripted_responses`, но запоминает имена инструментов в каждом
    запросе: по ним видно, в какой фазе схема паспорта уходит модели."""
    queue = list(answers)
    seen: list[list[str]] = []

    def _create(self, payload, extra_body=None):
        seen.append([t["function"]["name"] for t in payload.get("tools") or []])
        message = queue.pop(0) if queue else {"content": None}
        return make_openai_response(message)

    return _create, seen


class SubmitPassportToolTest(unittest.TestCase):
    """Инструмент в сессии первого агента."""

    @classmethod
    def setUpClass(cls):
        cls.target = load_target(GitRepo(ensure_fixture()), "master")

    def setUp(self):
        self.addCleanup(setattr, ChatClient, "_create", ChatClient._create)
        self.client = ChatClient(spec=SPEC, use_cache=False)

    def _run(self, *answers):
        ChatClient._create = scripted_responses(*answers)
        return run_agent(_plan(), CONTEXT, self.target.tree, SPEC, client=self.client)

    def test_passport_after_summary_is_kept_as_is(self):
        result = self._run(
            tool_call("c1", "submit_stage", **stage_args(item_id="intake")),
            tool_call("c2", "submit_review", confirmed=True),
            tool_call("c3", "submit_summary", **summary_args()),
            tool_call("c4", "submit_passport", **passport_args()),
            tool_call("c5", "finish"),
        )
        self.assertTrue(result.usable)
        self.assertEqual(result.passport_data, PASSPORT)
        # Паспорт не трогает оценку: статусы и вердикт те же, что без него.
        self.assertEqual(result.verdicts[0].percent(), 50)
        self.assertIsNotNone(result.summary)
        self.assertFalse(any("Паспорт не заполнен" in n for n in result.notes))

    def test_passport_before_summary_is_rejected(self):
        result = self._run(
            tool_call("c1", "submit_stage", **stage_args(item_id="intake")),
            tool_call("c2", "submit_passport", **passport_args()),
            tool_call("c3", "submit_review", confirmed=True),
            tool_call("c4", "submit_summary", **summary_args()),
            tool_call("c5", "finish"),
        )
        self.assertIsNone(result.passport_data)
        self.assertTrue(any("Паспорт не заполнен" in n for n in result.notes))

    def test_empty_passport_is_rejected(self):
        result = self._run(
            tool_call("c1", "submit_stage", **stage_args(item_id="intake")),
            tool_call("c2", "submit_review", confirmed=True),
            tool_call("c3", "submit_summary", **summary_args()),
            tool_call("c4", "submit_passport", passport={}),
            tool_call("c5", "finish"),
        )
        self.assertIsNone(result.passport_data)

    def test_without_passport_session_ends_with_a_note(self):
        result = self._run(
            tool_call("c1", "submit_stage", **stage_args(item_id="intake")),
            tool_call("c2", "submit_review", confirmed=True),
            tool_call("c3", "submit_summary", **summary_args()),
            tool_call("c4", "finish"),
        )
        self.assertTrue(result.usable)
        self.assertIsNone(result.passport_data)
        self.assertTrue(any("submit_passport не вызван" in n for n in result.notes))

    def test_passport_schema_appears_only_after_summary(self):
        create, seen = _recording_responses(
            tool_call("c1", "submit_stage", **stage_args(item_id="intake")),
            tool_call("c2", "submit_review", confirmed=True),
            tool_call("c3", "submit_summary", **summary_args()),
            tool_call("c4", "submit_passport", **passport_args()),
            tool_call("c5", "finish"),
        )
        ChatClient._create = create
        run_agent(_plan(), CONTEXT, self.target.tree, SPEC, client=self.client)
        # Три первых запроса — до принятого вердикта, паспорта в наборе нет;
        # четвёртый и пятый — после, он появляется.
        self.assertEqual(len(seen), 5)
        for tools in seen[:3]:
            self.assertNotIn("submit_passport", tools)
        for tools in seen[3:]:
            self.assertIn("submit_passport", tools)
        self.assertIn("finish", seen[0])

    def test_summary_reply_points_to_passport(self):
        state = matcher._Session(plan_items=_plan(), tree=self.target.tree, tools=None)
        state.summary = object()  # type: ignore[assignment]
        reply = matcher._handle_passport(state, passport_args())
        self.assertIn("паспорт принят", reply)
        self.assertEqual(state.passport_data, PASSPORT)


class PassportInModelTest(unittest.TestCase):
    """Проход данных через пайплайн: рецензент и ревизор паспорт не теряют."""

    def setUp(self):
        self.target = load_target(GitRepo(ensure_fixture()), "master")
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", client_module.DEFAULT_CACHE_DIR)
        client_module.DEFAULT_CACHE_DIR = Path(self.tmp.name) / "llm-cache"
        self.addCleanup(setattr, ChatClient, "_create", ChatClient._create)

    def test_passport_data_reaches_model_and_json(self):
        ChatClient._create = scripted_responses(*full_session(with_passport=True))
        model = run_progress(JOURNEY_TEXT, "demo-repo", self.target, SPEC)
        self.assertEqual(model.passport_data, PASSPORT)
        self.assertEqual(model.to_dict()["passport_data"], PASSPORT)
        self.assertEqual(model.readiness, 50)
        self.assertEqual(model.summary.decision, "GO")

    def test_without_passport_model_keeps_none_and_a_gap(self):
        ChatClient._create = scripted_responses(*full_session())
        model = run_progress(JOURNEY_TEXT, "demo-repo", self.target, SPEC)
        self.assertIsNone(model.passport_data)
        self.assertIsNone(model.to_dict()["passport_data"])
        self.assertTrue(any("submit_passport не вызван" in g for g in model.gaps))


class PassportRenderTest(unittest.TestCase):
    """Рендер HTML: значения агента поверх детерминированных, новые узлы —
    из <template>-заготовок, реестр — из строк агента."""

    @classmethod
    def setUpClass(cls):
        cls.target = load_target(GitRepo(ensure_fixture()), "master")
        cls.tmp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.tmp.cleanup)
        cls.addClassCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", client_module.DEFAULT_CACHE_DIR)
        client_module.DEFAULT_CACHE_DIR = Path(cls.tmp.name) / "llm-cache"
        cls.addClassCleanup(setattr, ChatClient, "_create", ChatClient._create)
        ChatClient._create = scripted_responses(*full_session())
        cls.model = run_progress(JOURNEY_TEXT, "demo-repo", cls.target, SPEC)

    def test_template_ships_inside_the_package(self):
        self.assertTrue(passport_render._TEMPLATE_PATH.is_file())
        self.assertEqual(passport_render._TEMPLATE_PATH.parent.name, "render")

    def test_template_is_selfcontained(self):
        """Шаблон пришёл экспортом из компонентного фреймворка: биндинги
        `{{ … }}`, `onClick`, `support.js`, шрифты из `assets/`. Без рантайма
        кнопки не работали, а в кнопке было видно сырое `{{ allLabel }}`.
        Файл уходит письмом и обязан работать сам по себе."""
        html = passport_render._TEMPLATE_PATH.read_text(encoding="utf-8")
        for residue in ("{{", "onClick", "support.js", "<x-dc>", "<helmet>",
                        "@font-face", "text/x-dc", "DCLogic"):
            self.assertNotIn(residue, html, residue)
        self.assertIn('id="toggle-all"', html)
        self.assertIn('id="gray-range"', html)
        # Заголовок и шторка есть у каждого узла: 6 образцов + 6 заготовок.
        self.assertEqual(html.count('class="node-head"'), 12)
        self.assertEqual(html.count('class="node-fold"'), 12)

    def test_header_plate_says_who_filled_the_passport(self):
        plain = render_passport_from_model(
            self.model, JOURNEY_TEXT, "demo-repo", self.target.extraction,
            commit=self.target.sha, branch=self.target.branch,
        )
        self.assertIn("БЕЗ АГЕНТА", plain)
        # Текст плашки заменён; в data-placeholder заглушка остаётся законно.
        self.assertNotIn(">ЗАГОТОВКА · ПОЛЯ НЕ ЗАПОЛНЕНЫ</div>", plain)
        from dataclasses import replace
        by_agent = render_passport_from_model(
            replace(self.model, passport_data=PASSPORT), JOURNEY_TEXT, "demo-repo",
            self.target.extraction, commit=self.target.sha, branch=self.target.branch,
        )
        self.assertIn("ЗАПОЛНЕНО ПО КОДУ · АГЕНТ", by_agent)

    def test_deterministic_fallback_fills_context(self):
        html = render_passport_from_model(
            self.model, JOURNEY_TEXT, "demo-repo", self.target.extraction,
            commit=self.target.sha, branch=self.target.branch,
        )
        self.assertIn("<!DOCTYPE html>", html)
        self.assertIn("demo-repo", html)
        # Название пути и «было» из текста инициативы.
        self.assertIn(CONTEXT["client_path_name"], html)
        self.assertIn("задача пересылается вручную", html)
        # Образцы шаблона на месте, заготовки не тронуты.
        self.assertIn('id="journey-1"', html)
        self.assertIn('<template id="tpl-bbb">', html)
        self.assertNotIn('id="bbb-2"', html)

    def test_agent_values_override_and_extra_nodes_are_cloned(self):
        plan_input = parse_plan_text(JOURNEY_TEXT)
        html = render_client_journey_passport(
            self.model, plan_input, "demo-repo", self.target.extraction,
            commit="abc", branch="master",
            llm_values=flatten_passport_data(PASSPORT),
            registry_rows=passport_registry_rows(PASSPORT),
            tree_spec=passport_tree_spec(PASSPORT),
        )
        self.assertIn(PASSPORT["analysis-scope"], html)
        self.assertIn("Клиент передаёт задачу и видит её статус без звонка.", html)
        self.assertIn("Установлено: маршрут постановки задачи в коде", html)
        # bbb-2 в шаблоне не было — клонирован из заготовки и заполнен.
        self.assertIn('id="bbb-2"', html)
        self.assertIn(PASSPORT_BBB2_NAME, html)
        self.assertIn("Сообщает исполнителю о новой задаче.", html)
        # Реестр — строки агента, а не шесть образцов.
        self.assertIn('<td data-col="HTML-id">bbb-2</td>', html)
        self.assertNotIn('<td data-col="HTML-id">need-1</td>', html)
        # Заготовки остаются: ручное дополнение паспорта по инструкции v3.
        self.assertIn('id="bbb-N"', html)

    def test_agent_values_are_escaped(self):
        data = {**PASSPORT, "analysis-scope": "<script>alert(1)</script>"}
        plan_input = parse_plan_text(JOURNEY_TEXT)
        html = render_client_journey_passport(
            self.model, plan_input, "demo-repo", self.target.extraction,
            commit="abc", branch="master",
            llm_values=flatten_passport_data(data),
        )
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", html)

    def test_flatten_ignores_garbage(self):
        self.assertEqual(flatten_passport_data(None), {})
        self.assertEqual(flatten_passport_data({"nodes": "no"}), {
            "analysis-scope": "", "decision-boundary": "", "analysis-date": "",
        })
        flat = flatten_passport_data({"nodes": {"bbb-7": {"name": "X", "fields": {"4.4.1": {"value": "v"}}},
                                                "unknown-1": {"name": "skip"}}})
        self.assertEqual(flat["bbb-7:name"], "X")
        self.assertEqual(flat["bbb-7:4.4.1:value"], "v")
        self.assertNotIn("unknown-1:name", flat)
        self.assertEqual(passport_registry_rows({"registry": "no"}), [])
        self.assertEqual(passport_tree_spec({"tree": [{"id": "journey-1"}]}), [{"id": "journey-1"}])

    def test_render_from_model_uses_agent_data_when_present(self):
        from dataclasses import replace
        model = replace(self.model, passport_data=PASSPORT)
        html = render_passport_from_model(
            model, JOURNEY_TEXT, "demo-repo", self.target.extraction,
            commit=self.target.sha, branch=self.target.branch,
        )
        self.assertIn(PASSPORT_JOURNEY_NAME, html)
        self.assertIn('id="bbb-2"', html)


if __name__ == "__main__":
    unittest.main()

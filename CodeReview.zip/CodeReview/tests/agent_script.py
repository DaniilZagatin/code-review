"""Заготовки вызовов агента для сквозных тестов (CLI, веб, пайплайн).

Сценарий: оценка этапа → вердикт → finish. submit_plan больше нет — план
разбирается кодом из текстового поля, агент только проверяет пункты.
"""

import json

CLIENT_PATH_NAME = "Постановка задачи в работу"
PROJECT_NAME = "Редизайн платёжного сервиса"
BEFORE = "задача пересылается вручную и теряется между сменами"
NOW = "задача видна в системе, но без автоматической маршрутизации"
AFTER = "задача попадает исполнителю сразу и видна обеим сторонам"

DESCRIPTION = (
    "Раньше задачи пересылались вручную и терялись между сменами. Теперь "
    "задача попадает исполнителю сразу и видна обеим сторонам."
)

STAGE_ID = "postanovka-zadach"
STAGE_TITLE = "Постановка задач"
STAGE_DESCRIPTION = "Клиент передаёт задачу в работу и видит её статус без звонка"
BULLETS = ["Определены источники обращений", "Подтверждена скорость обработки"]

CONCLUSION = [
    "Ценность подтверждена материалами",
    "Измеримость результата не закрыта",
    "Можно идти дальше",
]

ROUTER_EVIDENCE = [{"path": "backend/src/api/v1/router.py", "line": 7,
                    "basis": "функция start_task ставит задачу в обработку"}]

CONTEXT = {
    "client_path_name": CLIENT_PATH_NAME,
    "project_name": PROJECT_NAME,
    "before": BEFORE,
    "now": NOW,
    "after": AFTER,
}

JOURNEY_TEXT = "\n".join([
    f"Клиентский путь: {CLIENT_PATH_NAME}",
    f"Проект: {PROJECT_NAME}",
    f"Было: {BEFORE}",
    f"Сейчас: {NOW}",
    f"Стало: {AFTER}",
    "",
    f"## {STAGE_TITLE}",
    f"- {BULLETS[0]}",
    f"- {BULLETS[1]}",
])


def tool_call(call_id: str, name: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": call_id, "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


# Раскрытие пункта — два буллита человеческим языком. Ссылок на репозиторий
# в тексте нет намеренно: их отклоняет гейт, потому что в отчёт они не идут.
# Для не-зелёных статусов «Проверка» обязана быть развёрнутой: что похожее
# нашлось и чего именно из буллита не нашлось. Короче 120 символов гейт такую
# оценку не принимает — заглушки написаны так же, как их писал бы агент.
PROOF = {
    "done": "Код есть и работает: путь от заявки до обработки проходит целиком.",
    "limited": (
        "Приём заявок и передача исполнителю работают. Ограничение в том, что "
        "обрабатываются не все типы обращений: часть уходит в общую очередь и "
        "дальше её ведут вручную."
    ),
    "unused": (
        "Код передачи заявки исполнителю написан и рабочий, обходится без "
        "ручных шагов. В текущем сценарии до него не доходит очередь: вызова "
        "из рабочего пути нет."
    ),
    "partial": (
        "Регистрация заявки в системе есть и работает. Дальнейшей передачи "
        "исполнителю не нашлось: после регистрации заявка остаётся в списке, "
        "и сквозной путь не отрабатывает."
    ),
    "planned": (
        "Похожего в коде нашлась только регистрация обращения без дальнейшей "
        "обработки. Ни маршрутизации по исполнителям, ни уведомления сторон "
        "не нашлось: этого в коде нет."
    ),
    "blocked": (
        "Код приёма заявки есть и работает, но результат дальше не уходит: "
        "следующий шаг пути ждёт его и без него не начинается."
    ),
}
HOW = {
    "done": "Заявка попадает исполнителю сразу, обе стороны видят её статус.",
    "limited": "Заявка доходит до исполнителя, кроме отдельных случаев.",
    "unused": "Функция готова, но её никто не вызывает.",
    "partial": "Заявка регистрируется, дальше её ведут руками.",
    "planned": "Пока делается вручную.",
    "blocked": "Дальше по пути ничего не происходит.",
}


def stage_args(item_id: str = STAGE_ID, applicable: bool = True,
               statuses: list[str] | None = None,
               evidence: list[dict] | None = None) -> dict:
    statuses = statuses or ["done", "planned"]
    criteria = []
    for status in statuses:
        row: dict = {
            "applicable": True, "status": status,
            "proof": PROOF.get(status, ""), "how": HOW.get(status, ""),
        }
        if status != "planned":
            row["evidence"] = ROUTER_EVIDENCE if evidence is None else evidence
        criteria.append(row)
    return {"item_id": item_id, "applicable": applicable, "criteria": criteria}


# Верхнеуровневая оценка целого: её модель присылает сама, в отличие от
# готовности и решения — те считает код.
MATCH = "mostly"
MATCH_NOTE = (
    "Система принимает файл модели и считает по нему сценарии, "
    "а готовых форм под материалы сделки в ней пока нет."
)


def summary_args(
    decision: str = "PIVOT",
    match: str = MATCH,
    match_note: str = MATCH_NOTE,
) -> dict:
    # `decision` модель больше не присылает — решение считает код. Параметр
    # оставлен, чтобы сценарии тестов не переписывать под каждый вызов.
    return {
        "conclusion": list(CONCLUSION),
        "match": match,
        "match_note": match_note,
    }


def brief_args(before: str = BEFORE, now: str = NOW, after: str = AFTER) -> dict:
    return {"before": before, "now": now, "after": after}


def critic_session(*challenges: dict) -> list[dict]:
    """Сессия рецензента (`progress.critic`): понижения и `finish`.

    Идёт после `finish` первого агента из той же очереди ответов. Без
    понижений — один `finish`: рецензент прошёл список и претензий не нашёл.
    """
    calls = [
        tool_call(f"call_challenge_{i}", "submit_challenge", **challenge)
        for i, challenge in enumerate(challenges, start=1)
    ]
    calls.append(tool_call("call_critic_finish", "finish"))
    return calls


# Ревизия связности (`progress.coherence`): сквозной путь, изъяны, уровень.
# Заглушки написаны так же, как их писал бы ревизор: тексты без кода, изъян с
# проверенной ссылкой, уровень согласован со списком изъянов.
FLOW = {
    "entry": "Запрос на постановку задачи приходит от клиента",
    "steps": [
        "Система регистрирует заявку",
        "Заявка уходит исполнителю",
    ],
    "outcome": "Исполнитель видит задачу, клиент видит статус",
    "complete": True,
    "evidence": ROUTER_EVIDENCE,
}
INTEGRITY_NOTE = (
    "Система принимает заявку и доводит её до исполнителя: сквозной путь "
    "проходит целиком, части соединены между собой."
)


def flow_args(**over) -> dict:
    args = {**FLOW, "evidence": list(ROUTER_EVIDENCE)}
    args.update(over)
    return args


SYSTEM_DOES = (
    "Система принимает заявку от клиента, регистрирует её и передаёт "
    "исполнителю: на вход приходит обращение, на выходе исполнитель видит "
    "задачу, а клиент — её статус. По сути это сервис маршрутизации обращений "
    "между клиентом и исполнителем, работающий без участия диспетчера."
)
SYSTEM_NOT_DOES = (
    "Расхождений с замыслом не нашлось: обещанная передача заявки исполнителю "
    "и видимость статуса обеими сторонами в коде есть и работают."
)


def system_args(**over) -> dict:
    args = {"does": SYSTEM_DOES, "not_does": SYSTEM_NOT_DOES,
            "verdict": "same_purpose", "evidence": list(ROUTER_EVIDENCE)}
    args.update(over)
    return args


def coherence_session(*flaws: dict, flow: dict | None = None,
                      system: dict | None = None,
                      level: str = "coherent", note: str = INTEGRITY_NOTE) -> list[dict]:
    """Сессия ревизора связности: что делает система → путь → изъяны →
    уровень → finish.

    Идёт последней в очереди ответов, после сессии рецензента.
    """
    calls = [tool_call("call_system", "submit_system", **(system or system_args()))]
    calls.append(tool_call("call_flow", "submit_flow", **(flow or flow_args())))
    calls.extend(
        tool_call(f"call_flaw_{i}", "submit_flaw", **flaw)
        for i, flaw in enumerate(flaws, start=1)
    )
    calls.append(tool_call("call_integrity", "submit_integrity", level=level, note=note))
    calls.append(tool_call("call_coherence_finish", "finish"))
    return calls


# Паспорт клиентского пути (`submit_passport`): дерево с двумя BBB — второго
# в шаблоне нет, рендерер обязан клонировать его из <template>-заготовки.
PASSPORT_JOURNEY_NAME = "Постановка задачи в работу"
PASSPORT_BBB2_NAME = "Уведомление исполнителя"
PASSPORT = {
    "analysis-scope": "demo-repo · коммит abcdef12 · Приём обращений",
    "decision-boundary": "END_TO_END_PROCESS",
    "analysis-date": "2026-09-15",
    "tree": [
        {"id": "journey-1", "type": "journey", "children": [
            {"id": "process-1", "type": "process", "children": [
                {"id": "bbb-1", "type": "bbb", "children": [
                    {"id": "operation-1", "type": "operation"},
                ]},
                {"id": "bbb-2", "type": "bbb", "children": []},
            ]},
        ]},
    ],
    "nodes": {
        "journey-1": {
            "name": PASSPORT_JOURNEY_NAME, "object-id": "CJ-1", "object-version": "1.0",
            "fields": {"4.2.1": {
                "value": "Клиент передаёт задачу и видит её статус без звонка.",
                "source": "Установлено: маршрут постановки задачи в коде",
            }},
        },
        "process-1": {
            "name": "Маршрутизация обращений", "object-id": "", "object-version": "",
            "fields": {"4.3.1": {
                "value": "Принимает обращение и передаёт исполнителю.",
                "source": "Установлено: обработчик маршрута",
            }},
        },
        "bbb-1": {
            "name": "Регистрация заявки", "object-id": "", "object-version": "",
            "fields": {"4.4.1": {"value": "Создаёт запись о заявке.", "source": "Установлено: функция start_task"}},
        },
        "bbb-2": {
            "name": PASSPORT_BBB2_NAME, "object-id": "", "object-version": "",
            "fields": {"4.4.1": {"value": "Сообщает исполнителю о новой задаче.", "source": "Выведено: вызов из обработчика"}},
        },
    },
    "registry": [
        {"id": "journey-1", "type": "Клиентский путь", "name": PASSPORT_JOURNEY_NAME, "parent": "—", "basis": "образ результата"},
        {"id": "process-1", "type": "Автономный процесс", "name": "Маршрутизация обращений", "parent": "journey-1", "basis": "обработчик маршрута"},
        {"id": "bbb-1", "type": "BBB", "name": "Регистрация заявки", "parent": "process-1", "basis": "функция start_task"},
        {"id": "bbb-2", "type": "BBB", "name": PASSPORT_BBB2_NAME, "parent": "process-1", "basis": "вызов из обработчика"},
    ],
}


def passport_args(**over) -> dict:
    passport = {**PASSPORT, **over}
    return {"passport": passport}


def full_session(**kwargs) -> list[dict]:
    """Полный сценарий: brief (из описания) → оценка этапа → контр-проверка →
    вердикт → паспорт (если `with_passport`) → finish → сессия рецензента
    (`critic`) → ревизия связности (`coherence`). Оба последних прохода по
    умолчанию без претензий."""
    calls = []
    if kwargs.get("with_brief"):
        calls.append(tool_call("call_brief", "submit_brief", **brief_args(
            **kwargs.get("brief", {}),
        )))
    calls.append(tool_call("call_stage", "submit_stage", **stage_args(**kwargs.get("stage", {}))))
    calls.append(tool_call("call_review", "submit_review", confirmed=True, notes="проверено"))
    calls.append(tool_call("call_summary", "submit_summary", **summary_args(**kwargs.get("summary", {}))))
    if kwargs.get("with_passport"):
        calls.append(tool_call("call_passport", "submit_passport", **passport_args()))
    calls.append(tool_call("call_finish", "finish"))
    calls.extend(critic_session(*kwargs.get("critic", ())))
    calls.extend(coherence_session(**kwargs.get("coherence", {})))
    return calls

"use client";

import { useEffect, useMemo, useState } from "react";
import type { AnalysisEvent } from "@/lib/types";

// Сменяющиеся сообщения для фазы обхода пунктов (под текущим пунктом).
const ITEM_MESSAGES = [
  "Ищем реализацию в материалах проекта…",
  "Читаем найденные файлы…",
  "Сверяемся с описанием этапа…",
  "Оцениваем готовность…",
];

const STAGE_ORDER: (StageKey | "done")[] = [
  "materials", "plan", "agent", "summary", "review", "done",
];
const MIN_STAGE_DWELL_MS = 650;

// Этапы пайплайна с весами для полосы прогресса. Сумма весов = 100.
// `review` — два прохода после вердикта: рецензент перечитывает код по
// ссылкам первого агента, ревизор проверяет связность решения. Оба идут
// минутами, и без своего этапа полоса стояла бы на «Формируем выводы».
const STAGES = [
  { key: "materials", weight: 12 },
  { key: "plan", weight: 12 },
  { key: "agent", weight: 44 },
  { key: "summary", weight: 14 },
  { key: "review", weight: 18 },
] as const;

type StageKey = (typeof STAGES)[number]["key"];

function currentStage(events: AnalysisEvent[]): StageKey | "done" {
  if (events.some((e) => e.type === "analysis_ready")) return "done";
  // Фазы строгой проверки и ревизии приходят уже после вердикта, поэтому
  // проверяются раньше `summary_ready`.
  if (events.some((e) => e.type === "phase" && (e.phase === "critic" || e.phase === "coherence"))) {
    return "review";
  }
  if (events.some((e) => e.type === "summary_ready")) return "summary";
  if (events.some((e) => e.type === "claim_verified")) return "agent";
  if (events.some((e) => e.type === "plan_ready")) return "plan";
  return "materials";
}

export function AnalysisProgress({
  events,
  onComplete,
}: {
  events: AnalysisEvent[];
  onComplete?: () => void;
}) {
  const rawStage = currentStage(events);

  const STAGE_LABELS: Record<StageKey | "done", string> = {
    materials: "Чтение материалов проекта",
    plan: "Разбор клиентского пути",
    agent: "Проверка пунктов по материалам",
    summary: "Формирование выводов",
    review: "Строгая проверка и связность",
    done: "Готово",
  };

  function stageLabel(key: StageKey | "done"): string {
    return STAGE_LABELS[key] ?? "Анализируем";
  }

  const [stage, setStage] = useState<StageKey | "done">(rawStage);
  useEffect(() => {
    if (rawStage === stage) return;
    const fromIdx = STAGE_ORDER.indexOf(stage);
    const toIdx = STAGE_ORDER.indexOf(rawStage);
    const goingForward = toIdx > fromIdx;
    const delay = goingForward ? MIN_STAGE_DWELL_MS : 0;
    const nextStage = goingForward ? STAGE_ORDER[fromIdx + 1] : rawStage;
    const t = setTimeout(() => {
      setStage(nextStage);
    }, delay);
    return () => clearTimeout(t);
  }, [rawStage, stage]);

  useEffect(() => {
    if (stage !== "done" || !onComplete) return;
    const t = setTimeout(onComplete, 900);
    return () => clearTimeout(t);
  }, [stage, onComplete]);

  const completedWeight = STAGES
    .filter((s) => STAGES.indexOf(s) < STAGES.findIndex((s2) => s2.key === stage))
    .reduce((sum, s) => sum + s.weight, 0);
  const currentWeight = stage === "done" ? 0 : (STAGES.find((s) => s.key === stage)?.weight ?? 0);
  const pct = stage === "done" ? 100 : completedWeight + Math.round(currentWeight / 2);

  const stageIndex = stage === "done" ? STAGES.length : STAGES.findIndex((s) => s.key === stage);

  // Прогонов одновременно идёт ограниченное число: пока свой не начался,
  // человек должен понимать, что он в очереди, а не что всё зависло.
  const queued = useMemo(
    () =>
      events.some((e) => e.type === "phase" && e.phase === "queued") &&
      !events.some((e) => e.type === "phase" && e.phase !== "queued"),
    [events],
  );

  const messages = useMemo<string[]>(() => {
    if (stage === "materials" && queued) return ["Ждём очереди — сейчас идут другие прогоны…"];
    if (stage === "materials") return ["Подключаем материалы проекта…", "Обрабатываем файлы…"];
    if (stage === "plan") return ["Разбираем текст клиентского пути…", "Извлекаем этапы и пункты…"];
    if (stage === "agent") return ITEM_MESSAGES;
    if (stage === "summary") return ["Обобщаем результаты по всем этапам…", "Формируем общий вывод…"];
    if (stage === "review") {
      return [
        "Перечитываем код по ссылкам оценок…",
        "Проверяем, собирается ли решение целиком…",
        "Ищем разрывы между частями…",
      ];
    }
    if (stage === "done") return ["Анализ завершён"];
    return [];
  }, [stage, queued]);

  const [msgIndex, setMsgIndex] = useState(0);
  useEffect(() => {
    if (messages.length <= 1) return;
    const t = setInterval(() => {
      setMsgIndex((prev) => (prev + 1) % messages.length);
    }, 2500);
    return () => clearInterval(t);
  }, [messages]);
  const currentMsg = messages[Math.min(msgIndex, messages.length - 1)] ?? "";

  return (
    <div className="rounded-xl border border-border bg-card p-8 flex flex-col gap-6">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          {stage !== "done" && (
            <span
              className="size-5 rounded-full border-2 border-primary border-t-transparent animate-spin shrink-0"
              aria-hidden
            />
          )}
          <div>
            <h1 className="text-lg font-semibold">
              {stage === "done" ? "Анализ завершён" : "Анализируем проект"}
            </h1>
            <p
              key={stage}
              className="text-muted-foreground text-sm mt-0.5 transition-stage-label"
            >
              {stageLabel(stage)}
            </p>
          </div>
        </div>
        {currentMsg && (
          <p
            key={currentMsg}
            className="text-muted-foreground text-sm text-right transition-stage-label shrink-0 max-w-[45%]"
          >
            {currentMsg}
          </p>
        )}
      </div>

      <div>
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-1.5">
          <span>Прогресс</span>
          <span className="tabular-nums">{pct}%</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full rounded-full bg-primary transition-all duration-500"
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>

      <ol className="flex flex-col gap-2 text-sm">
        {STAGES.map((s, i) => {
          const isDone = i < stageIndex || stage === "done";
          const isCurrent = i === stageIndex && stage !== "done";
          return (
            <li
              key={s.key}
              className={
                "transition-colors duration-500 " +
                (isDone ? "text-foreground" :
                 isCurrent ? "text-primary font-medium" :
                 "text-muted-foreground")
              }
            >
              <span
                key={isDone ? "done" : isCurrent ? "current" : "pending"}
                className="transition-stage-marker"
              >
                {isDone ? "✓" : isCurrent ? "●" : "○"}
              </span>{" "}
              {stageLabel(s.key)}
            </li>
          );
        })}
      </ol>
    </div>
  );
}

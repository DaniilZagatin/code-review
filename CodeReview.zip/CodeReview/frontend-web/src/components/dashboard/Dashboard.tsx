"use client";

import { Fragment, useCallback, useEffect, useState } from "react";
import type {
  AnalysisResult,
  AssessmentItem,
  Dispute,
  DisputeVerdict,
  CodeLink,
  FlawSeverity,
  IntegrityReview,
  ScaleRow,
  StageItem,
} from "@/lib/types";
import { cn } from "@/lib/utils";
import { Download } from "lucide-react";
import "./dashboard.css";

// Веб-экран результатов — тот же отчёт, что и скачиваемый HTML
// (`backend/pko/render/dashboard_template.html`), только на React. Разметка и
// эстетика совпадают намеренно: руководство не должно видеть две разные
// картинки от одного инструмента.
//
// Здесь НИЧЕГО не вычисляется. Проценты, готовность, решение и шкала с весами
// приходят готовыми из данных. Раньше этот файл считал процент этапа сам
// (`done=1, partial=0.5`, неприменимые в знаменателе) и выводил решение по
// порогам 80/40 — обе формулы разошлись с бэкендом и давали другой отчёт.

type StatusKey = "done" | "limited" | "unused" | "partial" | "planned" | "blocked" | "na";

// Подписи дублируют бэкенд только для aria-label и запасного варианта:
// на экран идёт `status_label` из данных.
const STATUS_LABEL: Record<StatusKey, string> = {
  done: "работает",
  limited: "работает с ограничениями",
  unused: "код реализован, но не используется",
  partial: "не работает, реализовано частично",
  planned: "не реализовано",
  blocked: "блокирует",
  na: "не оценивается",
};

function statusKey(item: AssessmentItem): StatusKey {
  if (item.applicable !== true) return "na";
  const raw = String(item.status || "").toLowerCase();
  if (raw === "scaffold") return "partial";  // статус прежних прогонов
  if (["done", "limited", "unused", "partial", "blocked"].includes(raw)) {
    return raw as StatusKey;
  }
  return "planned";
}

function Mark({ status, big }: { status: StatusKey; big?: boolean }) {
  return <span className={cn("mark", status, big && "lg")} title={STATUS_LABEL[status]} />;
}

// Сплошной текст длиннее двух фраз читается плохо — режем на пункты.
function splitSentences(text: string): string[] {
  return String(text || "")
    .split(/(?<=[.!?;])\s+(?=[А-ЯA-Z«(])/)
    .map((s) => s.trim())
    .filter(Boolean);
}

// Даже одна фраза оформляется пунктом списка: кружок слева показывает, где
// начинается отдельное утверждение, и раскрытие читается одинаково везде.
function Comment({ text }: { text: string }) {
  const parts = splitSentences(text);
  const items = parts.length ? parts : [text];
  return (
    <ul className="detail-list">
      {items.map((part, i) => <li key={i}>{part}</li>)}
    </ul>
  );
}

// Шторка со ссылками на код: закрыта по умолчанию, открывается отдельно от
// самого пункта. Отчёт читается без неё, а тому, кто хочет проверить, ссылки
// под рукой. Приходят только подтверждённые — неподтверждённая ссылка ничего
// не доказывает, а рядом со статусом читается как доказательство.
function Links({ items }: { items: CodeLink[] }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="links">
      <button
        type="button"
        className="links-toggle"
        aria-expanded={open}
        onClick={(e) => {
          // Клик по шторке не должен схлопывать сам пункт.
          e.stopPropagation();
          setOpen((v) => !v);
        }}
      >
        <span className="links-caret">{open ? "▾" : "▸"}</span>
        Ссылки на код ({items.length})
      </button>
      {open && (
        <div className="links-body">
          {items.map((item, i) => (
            <div key={i} className="link-item">
              <div className="link-where">
                <span className="link-path">
                  {item.path}{item.line ? `:${item.line}` : ""}
                </span>
                {item.basis && (
                  <>
                    {"\u00a0\u00a0"}
                    <span className="link-symbol">{item.basis}</span>
                  </>
                )}
              </div>
              {item.note && <div className="link-note">{item.note}</div>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Ответ команды на оценку. Показывается только там, где галка не зелёная:
// с «работает» спорить незачем, а всё остальное — претензия к чужой работе,
// и у команды должно быть право ответить. Комментарий обязателен для всего,
// кроме простого «принять»: возражение без объяснения нечем обработать.
// Цвет ответа — из палитры статусов, а не отдельный: согласие зелёное,
// оговорка янтарная, отказ красный. Классы держат его в CSS, чтобы вся гамма
// отчёта правилась в одном месте.
const VERDICTS: { key: DisputeVerdict; label: string; cls: string }[] = [
  { key: "accept", label: "Принять", cls: "v-accept" },
  { key: "accept_with_note", label: "Принять с оговоркой", cls: "v-note" },
  { key: "reject", label: "Отклонить", cls: "v-reject" },
];

// Галочка, восклицательный знак в круге, крест. Рисуются штрихом на
// currentColor: цвет задаёт кнопка, иконка его наследует.
const ICON_PATHS: Record<DisputeVerdict, string[]> = {
  accept: ["M20 6 9 17l-5-5"],
  accept_with_note: ["M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z", "M12 7.6v5.6", "M12 16.6v.2"],
  reject: ["M6.5 6.5l11 11", "M17.5 6.5l-11 11"],
};

function VerdictIcon({ verdict }: { verdict: DisputeVerdict }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {ICON_PATHS[verdict].map((d) => (
        <path key={d} d={d} />
      ))}
    </svg>
  );
}

function DisputeBox({
  analysisId,
  bulletIndex,
  saved,
  onSaved,
}: {
  analysisId: string;
  bulletIndex: number;
  saved?: Dispute;
  onSaved: (dispute: Dispute) => void;
}) {
  const [chosen, setChosen] = useState<DisputeVerdict | null>(null);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const send = async (verdict: DisputeVerdict, text: string) => {
    setBusy(true);
    setError("");
    try {
      const body = new FormData();
      body.append("bullet_index", String(bulletIndex));
      body.append("verdict", verdict);
      body.append("comment", text);
      const resp = await fetch(`/api/analyses/${analysisId}/disputes`, {
        method: "POST",
        body,
      });
      const data = await resp.json();
      if (!resp.ok) {
        setError(data?.message || "Не удалось сохранить ответ.");
        return;
      }
      onSaved(data as Dispute);
      setChosen(null);
      setComment("");
    } catch {
      setError("Сервер не ответил. Попробуйте ещё раз.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="dispute" onClick={(e) => e.stopPropagation()}>
      <div className="dispute-head">
        <span className="dispute-label">Ответ команды</span>
        {saved && (
          <span
            className={cn(
              "dispute-saved",
              VERDICTS.find((item) => item.key === saved.verdict)?.cls,
            )}
          >
            {saved.verdict_label}
            {saved.comment ? `: ${saved.comment}` : ""}
          </span>
        )}
      </div>
      <div className="dispute-buttons">
        {VERDICTS.map((item) => (
          <button
            key={item.key}
            type="button"
            className={cn(
              "dispute-btn",
              item.cls,
              // Пока ответ выбирают, подсвечен выбор, а не то, что сохранено:
              // две залитые кнопки рядом означали бы два ответа на один пункт.
              (chosen ? chosen === item.key : saved?.verdict === item.key) && "active",
            )}
            disabled={busy}
            onClick={() => {
              if (item.key === "accept") {
                void send("accept", "");
                return;
              }
              setChosen(chosen === item.key ? null : item.key);
            }}
          >
            <VerdictIcon verdict={item.key} />
            <span>{item.label}</span>
          </button>
        ))}
      </div>
      {chosen && (
        <div className="dispute-form">
          <textarea
            className="dispute-input"
            placeholder="Что именно не так с оценкой? Если пункт сделан — где именно."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={3}
          />
          <button
            type="button"
            className="dispute-send"
            disabled={busy || !comment.trim()}
            onClick={() => void send(chosen, comment)}
          >
            Отправить
          </button>
        </div>
      )}
      {error && <div className="dispute-error">{error}</div>}
    </div>
  );
}

// Один буллит разбора: подпись слева, содержимое справа.
// Связность решения — блок, отвечающий не за «сделан ли пункт», а за
// «складываются ли сделанные пункты в работающую систему». Постатейный разбор
// на это ответить не может: код пишут по каждому буллиту и не соединяют, и
// тогда высокий процент не значит ничего. Стоит до блоков с пунктами.
//
// Подписи уровня и веса изъяна приходят из данных: вторая таблица подписей
// здесь разошлась бы с бэкендом, как когда-то разошёлся расчёт процента.
// Сводка изъянов одной строкой: «1 блокер · 2 существенных». Вес, которого
// нет, не печатается — ноль читался бы как «проверяли и не нашли».
const FLAW_WORDS: [FlawSeverity, string, string, string][] = [
  ["blocker", "блокер", "блокера", "блокеров"],
  ["major", "существенный", "существенных", "существенных"],
  ["minor", "замечание", "замечания", "замечаний"],
];

function flawSummary(counts?: Record<FlawSeverity, number>): string {
  return FLAW_WORDS.map(([key, one, few, many]) => {
    const n = Number(counts?.[key]) || 0;
    if (!n) return "";
    const last = n % 10;
    const tens = n % 100;
    const word =
      last === 1 && tens !== 11 ? one
      : last >= 2 && last <= 4 && (tens < 12 || tens > 14) ? few
      : many;
    return `${n} ${word}`;
  }).filter(Boolean).join(" · ");
}

function Integrity({ review }: { review: IntegrityReview }) {
  const flow = review.flow;
  const flaws = review.flaws || [];
  // Свёрнут по умолчанию: отчёт обязан помещаться на один экран. В строке
  // заголовка остаётся всё, ради чего блок читают.
  const [open, setOpen] = useState(false);
  const summary = flawSummary(review.counts);
  return (
    <div className="integrity">
      <button
        type="button"
        className="integrity-toggle"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        <div className="integrity-head">
          <div className="integrity-title">
            <span className="integrity-caret">{open ? "▾" : "▸"}</span>
            Связность решения
          </div>
          <div className="integrity-marks">
            {summary && <span className="integrity-count">{summary}</span>}
            {review.purpose?.verdict_label && (
              <span className={cn("purpose-verdict", review.purpose.verdict)}>
                {review.purpose.verdict_label}
              </span>
            )}
            <span className={cn("integrity-level", review.level)}>{review.level_label}</span>
          </div>
        </div>
      </button>
      <div className="integrity-body" hidden={!open}>
      {review.note && <div className="integrity-note">{review.note}</div>}
      {review.level_hint && <div className="integrity-hint">{review.level_hint}</div>}

      {/* Что система делает на самом деле — независимый ответ о целом, данный
          по устройству кода, а не по списку пунктов. Стоит первым: читатель
          должен сначала понять, чем система оказалась. */}
      {review.purpose?.does && (
        <div className="purpose">
          {/* Вердикт о назначении стоит в свёрнутой шапке блока — второй раз
              его печатать незачем. */}
          <div className="flow-label">Что система делает на самом деле</div>
          <div className="purpose-does">{review.purpose.does}</div>
          {review.purpose.not_does && (
            <div className="purpose-not">
              <b>Чего не делает: </b>
              {review.purpose.not_does}
            </div>
          )}
          {review.purpose.links && review.purpose.links.length > 0 && (
            <Links items={review.purpose.links} />
          )}
        </div>
      )}

      {flow?.entry && (
        <div className="flow">
          <div className="flow-label">Сквозной путь</div>
          <div className="flow-chain">
            {/* Стрелки и шаги — соседи в одном flex-контейнере, как в
                шаблоне скачиваемого файла: обёртка вокруг пары сбила бы
                переносы длинной цепочки. */}
            {[flow.entry, ...(flow.steps || [])].map((part, index) => (
              <Fragment key={index}>
                {index > 0 && <span className="flow-arrow">{"→"}</span>}
                <span className={cn("flow-step", index === 0 && "edge")}>{part}</span>
              </Fragment>
            ))}
            <span className="flow-arrow">{"→"}</span>
            {/* Результат при оборванном пути не достигается — пунктир
                показывает это раньше, чем читатель дойдёт до объяснения. */}
            <span className={cn("flow-step", "edge", !flow.complete && "broken")}>
              {flow.outcome}
            </span>
          </div>
          {!flow.complete && flow.break_point && (
            <div className="flow-break">Путь рвётся: {flow.break_point}</div>
          )}
          {flow.links && flow.links.length > 0 && <Links items={flow.links} />}
        </div>
      )}

      {flaws.length > 0 && (
        <div className="flaws">
          {flaws.map((flaw, index) => (
            <div key={index} className="flaw">
              <div className="flaw-head">
                <span className={cn("flaw-sev", flaw.severity)}>{flaw.severity_label}</span>
                <span className="flaw-title">{flaw.title}</span>
                {flaw.kind_label && <span className="flaw-kind">{flaw.kind_label}</span>}
              </div>
              {flaw.detail && <div className="flaw-detail">{flaw.detail}</div>}
              {flaw.bullets && flaw.bullets.length > 0 && (
                <div className="flaw-bullets">
                  <b>Затронутые пункты: </b>
                  {flaw.bullets.join(" · ")}
                </div>
              )}
              {flaw.links && flaw.links.length > 0 && <Links items={flaw.links} />}
            </div>
          ))}
        </div>
      )}
      </div>
    </div>
  );
}

function Part({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="part">
      <div className="part-label">{label}</div>
      <div className="part-body">{children}</div>
    </div>
  );
}

function Row({
  item,
  index,
  analysisId,
  dispute,
  onDisputeSaved,
}: {
  item: AssessmentItem;
  index: number;
  analysisId: string;
  dispute?: Dispute;
  onDisputeSaved: (dispute: Dispute) => void;
}) {
  const [open, setOpen] = useState(false);
  const status = statusKey(item);
  // Раскрытие — два буллита человеческим языком, ссылки ниже в шторке.
  const proof = item.proof || item.technical || item.why || "";
  const how = item.how || item.business || item.comment || "";
  const links = item.links || [];
  // Неприменимый пункт выходит из знаменателя готовности — значит причина
  // обязана быть на виду, иначе процент растёт молча.
  const naReason = item.applicable === true ? "" : item.na_reason || "";
  const hasDetail = naReason
    ? true
    : Boolean(proof) || Boolean(how) || links.length > 0;

  return (
    <div
      className={cn("row", status, open && "open")}
      style={hasDetail ? undefined : { cursor: "default" }}
      role={hasDetail ? "button" : undefined}
      tabIndex={hasDetail ? 0 : undefined}
      aria-expanded={hasDetail ? open : undefined}
      aria-label={STATUS_LABEL[status]}
      onClick={() => hasDetail && setOpen((v) => !v)}
      onKeyDown={(e) => {
        if (!hasDetail) return;
        // Клавиши внутри раскрытия — поле комментария, кнопки ответа,
        // шторка ссылок — всплывают сюда, но пункту не адресованы: пробел в
        // текстовом поле сворачивал пункт вместе с недописанным
        // комментарием, а сам пробел при этом не печатался.
        if (e.target !== e.currentTarget) return;
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          setOpen((v) => !v);
        }
      }}
    >
      <div>
        <div className="row-text">{item.text || "Без описания"}</div>
        {hasDetail && (
          // Разбор открывается по клику: список остаётся читаемым, а
          // объяснение никуда не спрятано. Структура пункта одинакова
          // везде: статус — проверка — как работает — ссылки на код.
          <div className="detail">
            {naReason && (
              <Part label="Не оценивается">
                <Comment text={naReason} />
              </Part>
            )}
            {!naReason && proof && (
              <Part label="Проверка">
                <div className="part-head">
                  <span className="part-status">
                    {item.status_label || STATUS_LABEL[status]}
                  </span>
                </div>
                <Comment text={proof} />
              </Part>
            )}
            {!naReason && how && (
              <Part label="Как работает">
                <Comment text={how} />
              </Part>
            )}
            {!naReason && links.length > 0 && <Links items={links} />}
            {/* Спорить с зелёной галкой незачем — форма только там, где
                оценка не «Работает». */}
            {item.applicable === true && status !== "done" && (
              <DisputeBox
                analysisId={analysisId}
                bulletIndex={index}
                saved={dispute}
                onSaved={onDisputeSaved}
              />
            )}
          </div>
        )}
      </div>
      <div className="row-mark">
        <Mark status={status} big />
      </div>
    </div>
  );
}

function chipFor(numbered: NumberedRow[]): { text: string; cls: string } {
  const rows = numbered.map((n) => n.row);
  const usable = rows.filter((r) => r.applicable === true);
  if (!usable.length) return { text: "не оценивается", cls: "" };
  const done = usable.filter((r) => r.status === "done").length;
  // «В работе» — всё между «работает» и «не реализовано».
  const work = usable.filter((r) =>
    ["limited", "unused", "partial", "scaffold"].includes(String(r.status)),
  ).length;
  if (done === usable.length) return { text: `${done} из ${done}`, cls: "all-done" };
  if (done === 0 && work === 0) return { text: "не реализовано", cls: "" };
  if (done === 0) return { text: `${work} в работе`, cls: "in-work" };
  return { text: `${done} из ${usable.length}`, cls: "" };
}

// Сквозной номер пункта считается до группировки и в том же порядке, что на
// бэкенде (`items` → `assessment`): по нему сохраняется ответ команды, и
// разойтись нумерации нельзя — ответ уедет к чужому пункту.
type NumberedRow = { row: AssessmentItem; index: number };

function groupRows(items: StageItem[]): { name: string; rows: NumberedRow[] }[] {
  const order: string[] = [];
  const byName = new Map<string, NumberedRow[]>();
  let index = 0;
  for (const item of items) {
    for (const row of item.assessment || []) {
      const name = (row.group || "").trim() || "Функционал";
      if (!byName.has(name)) {
        byName.set(name, []);
        order.push(name);
      }
      byName.get(name)!.push({ row, index });
      index += 1;
    }
  }
  return order.map((name) => ({ name, rows: byName.get(name)! }));
}

function Ring({ percent }: { percent: number }) {
  const r = 36;
  const c = 2 * Math.PI * r;
  return (
    <div className="ring">
      <svg viewBox="0 0 84 84">
        <circle className="ring-track" cx="42" cy="42" r={r} />
        <circle
          className="ring-value"
          cx="42" cy="42" r={r}
          strokeDasharray={c}
          strokeDashoffset={c * (1 - percent / 100)}
        />
      </svg>
      <div className="ring-num">{percent}%</div>
    </div>
  );
}

// Шкала — одна строка-легенда: расшифровки убраны, они дублировали сами
// названия статусов и мешали отчёту помещаться на один экран.
//
// Вес показывается только прототипный: цветной кружок у пункта означает
// именно его, и второй вес рядом читателя путал. Промышленная готовность
// стоит отдельным числом в шапке.
function weightPair(row: ScaleRow): string {
  if (row.weight === null || row.weight === undefined) return "";
  return `${row.weight}%`;
}

function Scale({ rows }: { rows: ScaleRow[] }) {
  return (
    <div className="scale">
      {/* Подписи у легенды нет намеренно: любой заголовок делал строку шире
          экрана. Цвет пункта относится к готовности прототипа — она стоит
          прямо над легендой отдельным числом. */}
      {rows.map((row) => (
        <span key={row.status} className="scale-item">
          <Mark status={row.status as StatusKey} />
          <span>{row.short || row.label}</span>
          <span className="scale-weight">{weightPair(row)}</span>
        </span>
      ))}
    </div>
  );
}

function downloadName(meta: AnalysisResult["meta"]): string {
  const base = (meta.project_name || meta.client_path_name || meta.repo || "project")
    .replace(/[^A-Za-z0-9А-Яа-я]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "project";
  return `pko-dashboard-${base}.html`;
}

function passportDownloadName(meta: AnalysisResult["meta"]): string {
  return downloadName(meta).replace(/^pko-dashboard-/, "pko-passport-");
}

export function Dashboard({
  analysis,
  analysisId,
}: {
  analysis: AnalysisResult;
  analysisId: string;
}) {
  const { meta, readiness, items } = analysis;
  const percent = Math.max(0, Math.min(100, Math.round(readiness)));
  const scale = meta.scale || [];
  const groups = groupRows(items);
  // Замечания отчёта (`gaps`) на экран не выводятся — так же, как и в
  // скачиваемом HTML: отчёт уходит команде и руководству, а замечания —
  // рабочий след для того, кто прогон запускал. Они остаются в JSON ответа
  // `GET /api/analyses/{id}` и в progress_model.json.

  // Уже сохранённые ответы: страницу открывают несколько человек и не по
  // одному разу, и свой ответ команда должна видеть, а не отправлять заново.
  const [disputes, setDisputes] = useState<Record<number, Dispute>>({});
  const rememberDispute = useCallback((dispute: Dispute) => {
    setDisputes((current) => ({ ...current, [dispute.bullet_index]: dispute }));
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/analyses/${analysisId}/disputes`)
      .then((resp) => (resp.ok ? resp.json() : { items: [] }))
      .then((data) => {
        if (cancelled) return;
        const next: Record<number, Dispute> = {};
        for (const item of (data.items || []) as Dispute[]) {
          // Список идёт свежими сверху: первый ответ по пункту и есть текущий.
          if (next[item.bullet_index] === undefined) next[item.bullet_index] = item;
        }
        setDisputes(next);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [analysisId]);

  // Решение приходит из данных. Фолбэка по проценту здесь нет и быть не должно:
  // вторая формула вердикта — регресс, а не подстраховка.
  const decision = String(meta.decision || "").toUpperCase().replace("NO-GO", "NO GO");
  const decisionClass =
    decision === "GO" ? "go" : decision === "PIVOT" ? "pivot" : decision === "NO GO" ? "no-go" : "";

  return (
    <div className="dashboard-root">
      <main className="shell">
        <section className="sheet">
          <div className="tags">
            <span className="tag dark">Программа AI-эффективность</span>
            <span className="tag plain">Готовность функционала</span>
          </div>

          <div className="head">
            <div>
              <h1>{meta.project_name || "Анализ готовности функционала"}</h1>
              {meta.client_path_name && (
                <p className="subtitle">Клиентский путь: {meta.client_path_name}</p>
              )}
            </div>
            <div className="score">
              <Ring percent={percent} />
              <div className="score-text">
                <div className="score-title">ИИ-оценка кода</div>
                <div className="score-verdict">
                  {decisionClass ? (
                    // Строки расчёта («71% ≥ 40%») рядом с бейджем нет:
                    // готовность стоит числом ниже и говорит то же самое.
                    <span className={cn("badge", decisionClass)}>{decision}</span>
                  ) : (
                    <span className="badge none">Решение не сформировано</span>
                  )}
                </div>
                {/* Оценивается прототип — по нему и решение. Второе число,
                    промышленная готовность, из отчёта убрано: рядом с первым
                    его читали как «до прома осталось 29%». Расчёт остался и
                    лежит в progress_model.json. */}
                <div className="score-pair">
                  <span className="score-metric">
                    <span className="score-metric-label">Прототип</span>
                    <span className="score-metric-value">{percent}%</span>
                  </span>
                </div>
                {/* Верхнеуровневая оценка: делает ли система то, ради чего
                    затевалась. Постатейный разбор считает буллиты и легко
                    скатывается в придирки к формулировкам — этот ответ про
                    целое. */}
                {meta.match_label && (
                  <div className={cn("match", meta.match && `match-${meta.match}`)}>
                    <span className="match-label">{meta.match_label}</span>
                    {meta.match_note && (
                      <span className="match-note">{meta.match_note}</span>
                    )}
                  </div>
                )}

              </div>
            </div>
          </div>

          {scale.length > 0 && <Scale rows={scale} />}

          {analysis.integrity?.level && <Integrity review={analysis.integrity} />}

          {groups.length === 0 ? (
            <div className="empty">Буллиты образа результата не найдены.</div>
          ) : (
            <div className="groups">
              {groups.map((group, index) => {
                const chip = chipFor(group.rows);
                return (
                  <div key={group.name} className="group">
                    <div className="group-head">
                      <div className="group-name">
                        <span className="group-num">{String(index + 1).padStart(2, "0")}</span>
                        <span className="group-title">{group.name}</span>
                      </div>
                      <span className={cn("chip", chip.cls)}>{chip.text}</span>
                    </div>
                    {group.rows.map(({ row, index }) => (
                      <Row
                        key={index}
                        item={row}
                        index={index}
                        analysisId={analysisId}
                        dispute={disputes[index]}
                        onDisputeSaved={rememberDispute}
                      />
                    ))}
                  </div>
                );
              })}
            </div>
          )}

          <div className="foot">
            {meta.repo && <span>Репозиторий <b>{meta.repo}</b></span>}
            {meta.branch && <span>Ветка <b>{meta.branch}</b></span>}
            {meta.commit && <span>Коммит <b>{meta.commit.slice(0, 8)}</b></span>}
            {/* Слепок образа результата убран: читателю отчёта хеш ничего не
                говорит, он остаётся в progress_model.json. Время убрано —
                для отчёта о готовности достаточно даты. */}
            {meta.generated_at && (
              <span>Отчёт от <b>{meta.generated_at.split(" ")[0]}</b></span>
            )}
            <a
              href={`/api/analyses/${analysisId}/dashboard.html`}
              download={downloadName(meta)}
              className="download-btn"
            >
              <Download className="size-4" aria-hidden="true" />
              Скачать отчёт
            </a>
            <a
              href={`/api/analyses/${analysisId}/passport.html`}
              download={passportDownloadName(meta)}
              className="download-btn"
            >
              <Download className="size-4" aria-hidden="true" />
              Скачать паспорт
            </a>
          </div>
        </section>
      </main>
    </div>
  );
}

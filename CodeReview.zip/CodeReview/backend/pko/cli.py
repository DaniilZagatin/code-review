"""CLI: pko parse / pko progress / pko serve.

Три команды и ничего больше. `parse` не ходит ни в сеть, ни в LLM — он нужен,
чтобы до запуска анализа увидеть, как разобран файл инициативы: сколько
буллитов, что попало в дословный хвост, есть ли замечания разбора.
"""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path

from pko import __version__
from pko.errors import PkoError
from pko.initiatives import all_initiatives, find as find_initiative
from pko.llm.registry import get_spec
from pko.output.publisher import write_outputs
from pko.progress.local_source import build_target_repo_from_uploads
from pko.progress.matcher import DEFAULT_MAX_STEPS
from pko.progress.pipeline import run_progress
from pko.progress.plan_input import parse_plan_text
from pko.progress.target_repo import (
    GitRepo,
    load_target,
    open_repo_source,
    repo_name as repo_name_of,
)
from pko.render.client_journey_passport import render_passport_from_model
from pko.render.dashboard_data import build_dashboard_data
from pko.render.dashboard_html import render_dashboard_html
from pko.render.progress_report import render_progress_report
from pko.util.env import load_env


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pko",
        description="Проверка готовности пунктов клиентского пути по коду репозитория.",
    )
    parser.add_argument("--version", action="version", version=f"pko {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    parse_cmd = sub.add_parser("parse", help="Разобрать файл инициативы, ничего не запуская")
    _add_journey_args(parse_cmd)
    parse_cmd.add_argument("--json", action="store_true", help="Вывести JSON")
    parse_cmd.set_defaults(handler=_cmd_parse)

    progress = sub.add_parser("progress", help="Оценить готовность по коду")
    _add_journey_args(progress)
    source = progress.add_argument_group("источник кода (ровно один)")
    source.add_argument("--url", default="", help="SSH-адрес Bitbucket")
    source.add_argument("--repo-path", default="", help="Локальный клон репозитория")
    source.add_argument("--zip", dest="zip_path", default="", help="ZIP-архив с кодом")
    progress.add_argument("--branch", default="", help="Ветка (для git-источника)")
    progress.add_argument("--out", default="pko-progress-out", help="Каталог отчётов")
    progress.add_argument("--max-steps", type=int, default=DEFAULT_MAX_STEPS)
    progress.add_argument("--thinking", action="store_true", default=True, help="Включить thinking у модели (по умолчанию)")
    progress.add_argument("--no-thinking", dest="thinking", action="store_false", help="Отключить thinking у модели")
    progress.add_argument("--no-fetch", action="store_true", help="Не обновлять зеркало")
    progress.add_argument(
        "--junit", default="",
        help="JUnit-отчёт о прогоне тестов (xml): проходящий тест — сильнейшее "
             "доказательство «работает», какое бывает в статике",
    )
    progress.add_argument("--quiet", action="store_true", help="Не печатать ход работы")
    progress.set_defaults(handler=_cmd_progress)

    catalog = sub.add_parser(
        "initiatives", help="Показать инициативы из вшитого каталога")
    catalog.add_argument("--search", default="", help="Фильтр по названию")
    catalog.set_defaults(handler=_cmd_initiatives)

    answers = sub.add_parser(
        "answers", help="Собрать ответы из вернувшихся HTML-отчётов")
    answers.add_argument("paths", nargs="+", help="Файлы или папки с отчётами")
    answers.add_argument(
        "--db", default="",
        help="Файл базы; по умолчанию ~/.pko/feedback.db или Postgres из PKO_DB_URL")
    answers.add_argument("--json", action="store_true", help="Вывести собранное в JSON")
    answers.set_defaults(handler=_cmd_answers)

    serve = sub.add_parser("serve", help="Запустить веб-интерфейс")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    serve.set_defaults(handler=_cmd_serve)

    return parser


def _add_journey_args(target: argparse.ArgumentParser) -> None:
    group = target.add_mutually_exclusive_group(required=True)
    group.add_argument("--journey-file", default="", help="Файл инициативы (.md)")
    group.add_argument("--journey-text", default="", help="Текст клиентского пути")
    group.add_argument(
        "--initiative", default="",
        help="Инициатива из вшитого каталога: идентификатор или часть названия "
             "(список — pko initiatives)",
    )


def _read_journey(args: argparse.Namespace) -> str:
    # Каталог отдаёт тот же текст формата колоды, что лежал бы в файле:
    # дальше по пайплайну разбор один на все источники.
    if getattr(args, "initiative", ""):
        return find_initiative(args.initiative).to_text()
    if args.journey_text:
        return args.journey_text
    path = Path(args.journey_file)
    if not path.is_file():
        raise PkoError(
            f"Файл инициативы не найден: {path}",
            hint="укажите путь к .md с образом результата",
        )
    return path.read_text(encoding="utf-8")


def _cmd_parse(args: argparse.Namespace) -> int:
    plan = parse_plan_text(_read_journey(args))
    if args.json:
        payload = {
            "source_format": plan.source_format,
            "source_digest": plan.source_digest,
            "stages": plan.stages,
            "context": plan.context,
            "items": [
                {"id": item.id, "title": item.title, "criteria": list(item.criteria)}
                for item in plan.items
            ],
            "effect_quotes": plan.effect_quotes,
            "notes": plan.notes,
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    print(f"Формат:          {plan.source_format}")
    print(f"Клиентский путь: {plan.context.get('client_path_name', '')}")
    print(f"Инициатива:      {plan.context.get('project_name', '')}")
    if plan.stages:
        print(f"Этапы пути ({len(plan.stages)}):")
        for number, stage in enumerate(plan.stages, start=1):
            print(f"  {number}. {stage}")
    total = sum(len(item.criteria) for item in plan.items)
    print(f"Буллитов:        {total}")
    for item in plan.items:
        if len(plan.items) > 1:
            print(f"  [{item.title}]")
        for number, text in enumerate(item.criteria, start=1):
            print(f"  {number:2}. {text}")
    if plan.effect_quotes:
        print("Эффект по документу (цитаты, не расчёт):")
        for quote in plan.effect_quotes:
            print(f"  · {quote}")
    for note in plan.notes:
        print(f"! {note}")
    return 0


def _cmd_initiatives(args: argparse.Namespace) -> int:
    """Список инициатив каталога — чтобы не искать нужный файл руками."""
    query = (args.search or "").strip().lower()
    items = [
        item for item in all_initiatives()
        if not query or query in item.project.lower() or query in item.id.lower()
    ]
    if not items:
        print("Ничего не найдено." if query else
              "Каталог пуст: соберите его через scripts/build_initiatives.py")
        return 0
    source = ""
    for item in items:
        if item.source != source:
            source = item.source
            print(f"\n[{source}]")
        print(f"  {item.id}")
        print(f"    {item.title}  ({len(item.bullets)} буллитов)")
    print(f"\nВсего: {len(items)}")
    return 0


def _open_target(args: argparse.Namespace, workspace: Path):
    given = [bool(args.url), bool(args.repo_path), bool(args.zip_path)]
    if sum(given) == 0:
        raise PkoError(
            "Не указан источник кода.",
            hint="передайте --url (Bitbucket по SSH), --repo-path или --zip",
        )
    if sum(given) > 1:
        raise PkoError(
            "Указано несколько источников кода сразу.",
            hint="выберите один: --url, --repo-path или --zip",
        )
    # Отчёт о тестах проверяется до выбора источника: флаг относится к любому
    # из них, и молча терять его на ZIP-архиве нельзя.
    junit = getattr(args, "junit", "") or None
    if junit and not Path(junit).is_file():
        raise PkoError(f"Отчёт о тестах не найден: {junit}",
                       hint="укажите путь к JUnit-XML или уберите --junit")
    if args.zip_path:
        archive = Path(args.zip_path)
        if not archive.is_file():
            raise PkoError(f"Архив не найден: {archive}", hint="проверьте путь к ZIP")
        target = build_target_repo_from_uploads([archive], workspace, junit_path=junit)
        return target, archive.stem
    if args.repo_path:
        path = Path(args.repo_path)
        repo = GitRepo(path)
        return load_target(repo, args.branch or None, junit_path=junit), repo_name_of(path)
    repo, name = open_repo_source(
        args.url, branch=args.branch or None, no_fetch=args.no_fetch
    )
    return load_target(repo, args.branch or None, junit_path=junit), name


def _cmd_progress(args: argparse.Namespace) -> int:
    journey_text = _read_journey(args)
    spec = get_spec("matcher", thinking=True if args.thinking else None)
    if spec is None:
        raise PkoError(
            "Роль matcher не настроена: не задан LLM-эндпоинт.",
            hint="заполните PKO_ASSEMBLER_BASE_URL в .env (см. .env.example)",
        )

    def emit(name: str, payload: dict) -> None:
        if args.quiet:
            return
        if name == "plan_ready":
            print(f"План: этапов {payload.get('item_count')}")
        elif name == "claim_verified":
            percent = payload.get("percent")
            print(f"  {payload.get('title')}: "
                  + ("не относится" if percent is None else f"{percent}%"))
        elif name == "summary_ready":
            print(f"Решение: {payload.get('decision')}")

    with tempfile.TemporaryDirectory(prefix="pko-cli-") as tmp:
        target, name = _open_target(args, Path(tmp))
        model = run_progress(
            journey_text, name, target, spec,
            max_steps=args.max_steps, on_event=emit,
        )

        outputs: dict[str, tuple[str, str]] = {
            "progress-model": ("progress_model.json", model.to_json()),
            "progress-report": ("progress_report.html", render_progress_report(model)),
            "dashboard": ("dashboard.html", render_dashboard_html(build_dashboard_data(model))),
        }
        # Паспорт клиентского пути — четвёртый артефакт, аддитивный к трём
        # основным: его ошибка не должна оставить прогон без дашборда и
        # отчёта. Нужны экстракция и ветка — поэтому собирается внутри
        # временного каталога, пока `target` жив.
        notes: list[str] = []
        try:
            outputs["client-journey-passport"] = (
                "client_journey_passport.html",
                render_passport_from_model(
                    model, journey_text, name, target.extraction,
                    commit=target.sha, branch=target.branch,
                    model_name=getattr(spec, "model", ""),
                ),
            )
            notes.append(
                "паспорт: поля заполнены агентом (submit_passport)"
                if model.passport_data else
                "паспорт: агент не заполнил, заполнение детерминированное"
            )
        except Exception as exc:  # noqa: BLE001 — паспорт не должен ронять прогон
            notes.append(f"паспорт не сформирован: {exc}")

    written = write_outputs(Path(args.out), outputs)

    decision = model.summary.decision if model.summary else "не сформировано"
    reason = model.summary.reason if model.summary else ""
    print()
    print(f"Готовность: {model.readiness}%  ·  закрыто полностью: {model.closed_share()}%")
    print(f"Решение:    {decision} {reason}".rstrip())
    if model.gaps:
        print(f"Замечаний:  {len(model.gaps)}")
        for gap in model.gaps[:5]:
            print(f"  ! {gap}")
    for note in notes:
        print(f"  ! {note}")
    for item in written:
        print(f"Записано:   {item.path}")
    return 0


def _cmd_answers(args: argparse.Namespace) -> int:
    """Свести ответы из вернувшихся отчётов в общую базу.

    Отчёты уходят письмом и возвращаются письмом же — с ответами внутри
    файла. Шестьдесят инициатив это шестьдесят писем, и разбирать их поштучно
    никто не станет.
    """
    from pko.web.collect import collect
    from pko.web.feedback import FeedbackStore, default_store

    store = FeedbackStore(path=Path(args.db)) if args.db else default_store()
    try:
        result = collect([Path(p) for p in args.paths], store)
        rows = [d.to_dict() for d in store.list()]
    finally:
        store.close()

    if args.json:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0

    print(f"Файлов с ответами: {result.files_with_answers}")
    print(f"Собрано ответов:   {result.saved}")
    print(f"База:              {store.describe()}")
    if result.files_without_answers:
        print(f"Без ответов ({len(result.files_without_answers)}): "
              + ", ".join(result.files_without_answers[:5]))
    for line in result.unreadable:
        print("  ! не прочитан:", line)
    for line in result.skipped:
        print("  ! не принят:", line)

    by_verdict: dict[str, int] = {}
    for row in rows:
        by_verdict[row["verdict_label"]] = by_verdict.get(row["verdict_label"], 0) + 1
    if by_verdict:
        print("\nВсего в базе:")
        for label, count in sorted(by_verdict.items(), key=lambda kv: -kv[1]):
            print(f"  {label}: {count}")
    return 0


def _cmd_serve(args: argparse.Namespace) -> int:
    try:
        import uvicorn
    except ImportError as exc:
        raise PkoError(
            "Пакет uvicorn не установлен.",
            hint="выполните: pip install -e .",
        ) from exc
    uvicorn.run("pko.web.app:app", host=args.host, port=args.port)
    return 0


def main(argv: list[str] | None = None) -> int:
    load_env()
    args = _build_parser().parse_args(argv)
    try:
        return args.handler(args)
    except PkoError as exc:
        print(f"Ошибка: {exc.render()}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nПрервано.", file=sys.stderr)
        return 130


def run() -> None:
    raise SystemExit(main())


if __name__ == "__main__":
    run()

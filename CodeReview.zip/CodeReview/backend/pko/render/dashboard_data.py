"""Контракт дашборда: `ProgressModel` → JSON, который читают оба отчёта.

Один и тот же словарь уходит в три места:

* `web/analyses.py` — в `job.result`, откуда его забирает React-экран
  (`frontend-web/src/components/dashboard/Dashboard.tsx`);
* `render/dashboard_html.py` — в самодостаточный HTML (`window.__DATA__`);
* `cli.py` — в файл `dashboard.html` рядом с отчётом.

Раньше функция жила в `web/analyses.py` и CLI импортировал её оттуда как
приватную: командная строка зависела от веб-слоя ради формата отчёта. Формат —
дело рендера, поэтому он тут.

Главное правило места: **считает только этот модуль и `progress/schema.py`.**
Проценты, готовность, решение и шкала с весами приходят к шаблону и к React
готовыми. Вторая формула в разметке неизбежно расходится с первой — так уже
было: веб-экран считал процент сам и показывал не тот отчёт, что скачиваемый
HTML.
"""

from __future__ import annotations

from typing import Any

from pko.progress.schema import (
    MATCH_LABEL,
    READY_THRESHOLD,
    STATUS_LABEL,
    ProgressModel,
    limit_groups,
    scale_rows,
)


def build_dashboard_data(model: ProgressModel) -> dict[str, Any]:
    """Собрать контракт дашборда — не полный `ProgressModel.to_dict()`.

    Читатель дашборда — первое лицо, не разработчик: пути к материалам и
    `unclaimed` сюда осознанно не попадают.

    Ссылки на код доезжают, но **только подтверждённые** и в отдельную
    шторку: отчёт читается без них, а тому, кто захочет проверить, они под
    рукой. Неподтверждённая ссылка не показывается вовсе — она ничего не
    доказывает, а рядом со статусом выглядит доказательством. В модели
    (`progress_model.json`) остаются обе: там нужен полный след проверки.

    Пробелы (`gaps`) доезжают: там сказано, где отчёт сам себе не доверяет.
    """
    # Группы сводятся к MAX_GROUPS до отдачи на экран: одного указания в
    # промпте мало — на живом прогоне модель выдала 11 групп на 12 буллитов.
    # Неприменимые пункты тоже попадают в группировку: они видны в отчёте, и
    # без своей группы уезжали в отдельный блок «Функционал» — пятый при
    # лимите в четыре.
    group_map = limit_groups([
        criterion.group
        for verdict in model.verdicts
        for criterion in verdict.criteria
    ])
    merged_groups = sorted({old for old, new in group_map.items() if old != new})

    items = []
    for verdict in model.verdicts:
        item = model.items.get(verdict.item_id)
        if item is None:
            continue
        assessment = [
            _assessment_row(text, criterion, group_map)
            for text, criterion in zip(item.criteria, verdict.criteria)
        ]
        stage: dict[str, Any] = {
            "title": item.title,
            "description": item.description,
            "percent": verdict.percent(),
            "assessment": assessment,
        }
        if verdict.applicable:
            stage["applicable"] = True
        items.append(stage)

    result: dict[str, Any] = {
        "meta": _meta(model),
        # Две готовности из одних и тех же статусов: прототип (главное число,
        # по нему решение) и промышленное решение (строгие веса).
        "readiness": model.readiness,
        "readiness_prod": model.readiness_prod,
        "items": items,
        "gaps": list(model.gaps) + _match_conflict(model) + _integrity_conflict(model) + ([
            "Тематических групп было больше четырёх — мелкие сведены в «Прочее»: "
            + ", ".join(merged_groups[:6])
        ] if merged_groups else []),
    }
    if model.summary is not None:
        summary = model.summary.to_dict()
        # Решение показывается рядом с оценкой кода (`meta.decision`), в
        # блоке вывода оно было бы вторым бейджем о том же самом.
        summary.pop("decision", None)
        result["summary"] = summary
    # Связность — единственный блок отчёта, который отвечает не за «сделан ли
    # пункт», а за «собрано ли целое». В отличие от `gaps` это не рабочий след
    # прогона, а предметное суждение о системе с подтверждёнными ссылками:
    # оно уходит команде и руководству наравне со статусами.
    if model.integrity is not None:
        result["integrity"] = model.integrity.to_dict()
    return result


def _integrity_conflict(model: ProgressModel) -> list[str]:
    """Спор связности с процентом — в замечания прогона.

    Высокий процент при несобранном решении — это ровно тот случай, ради
    которого ревизия и заведена: пункты закрыты, а система не работает как
    целое. Читателю карточки это видно по блоку связности, а тому, кто прогон
    запускал, нужно в явном виде.
    """
    review = model.integrity
    if review is None or not review.level:
        return []
    blockers = review.severity_counts().get("blocker", 0)
    if review.level == "disconnected" and model.readiness >= READY_THRESHOLD:
        return [
            f"Ревизия связности: решение не собрано при готовности {model.readiness}% — "
            "пункты закрыты по отдельности, но сквозного пути нет. Процент считается "
            "по буллитам и связность не учитывает."
        ]
    if blockers and model.summary is not None and model.summary.decision == "GO":
        return [
            f"Ревизия связности: решение GO при изъянах, блокирующих замысел ({blockers}) — "
            "проверьте блок связности перед тем, как опираться на решение."
        ]
    return []


def _match_conflict(model: ProgressModel) -> list[str]:
    """Расхождение верхнеуровневой оценки с расчётом — в замечания.

    Оценку целого даёт модель, проценты считает код. Разойтись они могут
    законно (буллиты формальные, а суть сделана — и наоборот), но резкое
    расхождение читатель должен видеть, а не гадать, какому числу верить.
    """
    summary = model.summary
    if summary is None or not summary.match:
        return []
    if summary.match == "mismatch" and model.readiness >= READY_THRESHOLD:
        return [
            f"Верхнеуровневая оценка «{MATCH_LABEL['mismatch'].lower()}» "
            f"расходится с расчётом по буллитам ({model.readiness}%): "
            "проверьте, тот ли код анализировался."
        ]
    if summary.match in ("matches", "mostly") and model.readiness < READY_THRESHOLD:
        # На девяти живых прогонах модель поставила «в основном соответствует»
        # девять раз из девяти — включая прогоны на 25% и 31%, где в её же
        # пояснении сказано, что главного в коде нет. Средняя оценка стала
        # значением по умолчанию, и расхождение с расчётом надо показывать.
        label = MATCH_LABEL.get(summary.match, summary.match).lower()
        return [
            f"Верхнеуровневая оценка «{label}» расходится с расчётом по буллитам "
            f"({model.readiness}%, порог {READY_THRESHOLD}%): большая часть пунктов "
            "не подтверждена кодом."
        ]
    return []


def _assessment_row(text: str, criterion, group_map: dict[str, str]) -> dict[str, Any]:
    """Одна строка отчёта: текст буллита из плана + оценка из вердикта."""
    row: dict[str, Any] = {
        "text": text,
        "group": group_map.get(criterion.group, criterion.group),
    }
    if not criterion.applicable:
        # Неприменимый пункт показывается серым и в расчёт не входит: статуса
        # у него нет, и додумывать его шаблону нечем. Но причина исключения
        # обязана быть видна — иначе пункт молча пропадает из знаменателя.
        if criterion.na_reason:
            row["na_reason"] = criterion.na_reason
        return row
    row["applicable"] = True
    row["status"] = criterion.status
    row["status_label"] = STATUS_LABEL.get(criterion.status, criterion.status)
    # Раскрытие пункта — два буллита: «Проверка» и «Как работает».
    row["proof"] = criterion.proof_text
    row["how"] = criterion.how_text
    # Ссылки — в шторку, и только подтверждённые: отклонённая ссылка ничего
    # не доказывает, а на экране читается как доказательство.
    links = [
        {"path": e.path, "line": e.line, "basis": e.basis, "note": e.note}
        for e in criterion.evidence if e.verified
    ]
    if links:
        row["links"] = links
    return row


def _meta(model: ProgressModel) -> dict[str, Any]:
    """Шапка отчёта: контекст пути плюс всё посчитанное бэкендом."""
    meta = dict(model.meta)
    # Шкала печатается в отчёте с весами: читатель должен уметь пересчитать
    # процент сам, не заглядывая в документацию.
    meta["scale"] = scale_rows()
    meta["closed_share"] = model.closed_share()
    meta["counts"] = model.criterion_counts()
    meta["not_applicable"] = model.not_applicable_count()
    if model.summary is not None:
        meta["decision"] = model.summary.decision
        # Верхнеуровневая оценка целого: постатейный разбор считает буллиты,
        # а это ответ на вопрос, делает ли система то, ради чего затевалась.
        meta["match"] = model.summary.match
        meta["match_label"] = MATCH_LABEL.get(model.summary.match, "")
        meta["match_note"] = model.summary.match_note
    # Строка расчёта («71% ≥ 40%») в шапку не идёт: два числа готовности
    # рядом с бейджем говорят то же самое и читаются лучше. В модели
    # (`summary.reason`) и в выводе CLI она остаётся — там это след, а не
    # элемент отчёта.
    return meta

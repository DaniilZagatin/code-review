"""Веб API `pko progress`: асинхронный анализ + живой прогресс по SSE.

Локальный инструмент: сервер поднимается на своей машине, git-доступ — через
уже настроенный SSH-agent (см. README). Логика пайплайна не дублируется с
CLI — обе стороны зовут один и тот же `pko.progress.pipeline.run_progress`,
поэтому веб и `pko progress` не могут разойтись в поведении.

UI — отдельный Next.js-проект `frontend-web/` (свой dev/прод-процесс, ходит
сюда через `/api/*`), этот модуль отдаёт только JSON и SSE, HTML не рендерит и
не раздаёт статику. Реальный прогон может занимать от секунд до ~15 минут
только на клонирование репозитория плюс агентная сессия до 60 шагов.
"""

from __future__ import annotations

import json
import queue
import time

import anyio
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.requests import Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse

from pko.errors import PkoError
from pko.initiatives import all_initiatives, find as find_initiative
from pko.progress.local_source import MAX_WORKSPACE_BYTES
from pko.render.dashboard_html import render_dashboard_html
from pko.llm.registry import get_spec
from pko.llm.tracing import init_phoenix_tracing
from pko.util.env import load_env
from pko.web import analyses, feedback

load_env()
init_phoenix_tracing()

app = FastAPI(title="PKO progress")


@app.exception_handler(PkoError)
def _handle_pko_error(request: Request, exc: PkoError) -> JSONResponse:
    # Переполненная очередь — не ошибка запроса, а просьба зайти позже:
    # у неё свой код, чтобы клиент и прокси отличали её от невалидной формы.
    status = 429 if isinstance(exc, analyses.QueueFullError) else 400
    return JSONResponse(status_code=status, content={"message": exc.message, "hint": exc.hint})


@app.get("/health")
@app.get("/api/health")
async def health() -> JSONResponse:
    """Живость процесса и то, куда он пишет ответы команд.

    В базу здесь намеренно не ходим. Проба на готовность с проверкой Postgres
    уронила бы весь интерфейс из-за недоступной базы, хотя анализ к ней не
    обращается вовсе — база нужна только ответам команд.

    Зато видно, какое хранилище выбрано по окружению: на стенде в контейнере
    `sqlite` означает потерянный `DATABASE_URL` и ответы, которые исчезнут
    вместе с подом.
    """
    body: dict[str, str] = {"status": "ok"}
    try:
        current = feedback.store()
        body["storage"] = current.kind()
        body["storage_target"] = current.describe()
    except PkoError as exc:
        # Кривой DSN рестартом не лечится, поэтому это не повод отдавать 500
        # и уводить под в перезапуск: говорим прямо, что настроено не так.
        body["status"] = "degraded"
        body["storage"] = ""
        body["error"] = exc.render()
    return JSONResponse(body)


# Синхронный обработчик (`def`): обращение к базе блокирующее, см. ниже.
@app.get("/api/health/db")
def health_db() -> JSONResponse:
    """Живая проверка базы ответов — для диагностики «не сохраняется».

    `/health` в базу намеренно не ходит, поэтому «storage: postgres» там
    значит лишь, что DSN задан. Здесь соединение, таблица и права
    проверяются по-настоящему, а причина отказа возвращается текстом:
    таймаут соединения, нет таблицы, нет прав, кривой DSN.
    """
    try:
        current = feedback.store()
        target = current.ping()
    except PkoError as exc:
        return JSONResponse(
            status_code=503,
            content={"status": "error", "message": exc.message, "hint": exc.hint},
        )
    return JSONResponse({"status": "ok", "storage": current.kind(), "storage_target": target})


_HEARTBEAT_SECONDS = 15
# Как часто поток SSE заглядывает в очередь событий задачи. Раньше каждое
# соединение занимало поток из пула anyio блокирующим `queue.get(timeout)`:
# сорок открытых вкладок прогресса — и пул исчерпан, а в нём же исполняются
# синхронные обработчики ответов команд. Опрос из цикла событий потоков не
# держит вовсе, а задержка события в четверть секунды на экране незаметна.
_POLL_SECONDS = 0.25

# Потолок на весь запрос загрузки. Тот же порядок, что и бюджет распакованного
# workspace: больше этого всё равно не пройдёт дальше, и отклонить дешевле
# сразу, чем после чтения в память.
MAX_UPLOAD_BYTES = MAX_WORKSPACE_BYTES
# Порция чтения одного файла из формы: предел проверяется после каждой.
_UPLOAD_CHUNK_BYTES = 1 << 20


def _get_job_or_404(analysis_id: str) -> analyses.AnalysisJob:
    job = analyses.get_job(analysis_id)
    if job is None:
        raise PkoError("Анализ не найден.", hint=f"неизвестный analysis_id: {analysis_id!r}")
    return job


@app.post("/api/analyses")
async def create_analysis(
    journey_text: str = Form(""),
    initiative_id: str = Form(""),
    repository: str = Form(""),
    branch: str = Form(""),
    thinking: bool = Form(False),
    description: str = Form(""),
    files: list[UploadFile] = File([]),
) -> JSONResponse:
    """`repository` (необязательно) и `files` — два независимых источника
    evidence. Пустой репозиторий — анализ только по загруженным файлам.
    Оба пустые — тоже валидный запрос: агент получает пустой снимок
    материалов и сам решает, что писать в вердикт.

    `journey_text` — клиентский путь текстом: название, этапы (##) и буллиты
    (-). Код разбирает его в план; модель только проверяет готовность пунктов.

    `description` — описание инициативы: из него агент формулирует «Было» и
    «Стало» первым шагом сессии (`submit_brief`). Пусто — шаг пропускается.

    `thinking` — переключатель режима рассуждения модели с формы.
    """
    # Инициатива из каталога — то же самое, что вставленный руками текст:
    # шестьдесят с лишним образов результата вшиты в пакет, и копировать их
    # в форму каждый раз незачем.
    if initiative_id.strip() and not journey_text.strip():
        journey_text = find_initiative(initiative_id).to_text()

    spec = get_spec("matcher", thinking=thinking)
    if spec is None:
        raise PkoError(
            "Роль matcher не заведена: LLM-эндпоинт не задан и дефолтный GLM отключён.",
            hint="PKO_ASSEMBLER_* по умолчанию не обязательны — агент поднимается "
                 "на внутреннем GLM-5.2 (pko/defaults.py); задайте переменные до "
                 "запуска pko serve только для переопределения.",
        )

    # `files=[UploadFile()]` пустышка — Starlette так отдаёт поле, которое
    # клиент вообще не передал в multipart-форме.
    #
    # Общий размер считаем прямо здесь. Тело запроса Starlette держит на диске,
    # а `read()` поднимает файл в память целиком: без этого предела полгигабайта
    # из формы становились полугигабайтом резидентной памяти ещё до того, как
    # начнётся распаковка со своим бюджетом.
    uploads: list[tuple[str, bytes]] = []
    total = 0
    for item in files:
        if not item.filename:
            continue
        # Читаем кусками и считаем по ходу: один файл на гигабайт при
        # `read()` целиком оказывался в памяти раньше, чем срабатывала
        # проверка, — предел защищал только от суммы маленьких файлов.
        buffer = bytearray()
        while True:
            chunk = await item.read(_UPLOAD_CHUNK_BYTES)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_UPLOAD_BYTES:
                raise PkoError(
                    "Загруженные файлы слишком большие в сумме.",
                    hint=f"ограничение — {MAX_UPLOAD_BYTES // 1_000_000} МБ на один запрос",
                )
            buffer.extend(chunk)
        uploads.append((item.filename, bytes(buffer)))

    job = analyses.create_analysis(
        journey_text=journey_text,
        repository=repository,
        branch=branch,
        uploads=uploads,
        spec=spec,
        description=description,
    )
    return JSONResponse({"analysis_id": job.id, "status": job.status})


@app.get("/api/initiatives")
async def list_initiatives(search: str = "") -> JSONResponse:
    """Каталог образов результата для выбора в форме."""
    query = (search or "").strip().lower()
    items = [
        item.to_dict() for item in all_initiatives()
        if not query or query in item.project.lower() or query in item.id.lower()
    ]
    return JSONResponse({"items": items, "total": len(items)})


@app.get("/api/analyses/{analysis_id}/events")
async def stream_analysis_events(analysis_id: str) -> StreamingResponse:
    job = _get_job_or_404(analysis_id)

    async def generate():
        if job.status != "PROCESSING":
            terminal = {"type": "analysis_ready"} if job.status == "READY" else {"type": "error", **(job.error or {})}
            yield f"data: {json.dumps(terminal, ensure_ascii=False)}\n\n"
            return

        last_beat = time.monotonic()
        while True:
            try:
                event = job.events.get_nowait()
            except queue.Empty:
                now = time.monotonic()
                if now - last_beat >= _HEARTBEAT_SECONDS:
                    last_beat = now
                    yield ": keepalive\n\n"
                await anyio.sleep(min(_POLL_SECONDS, _HEARTBEAT_SECONDS))
                continue
            last_beat = time.monotonic()
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
            if event.get("type") in ("analysis_ready", "error"):
                break

    return StreamingResponse(generate(), media_type="text/event-stream")


@app.get("/api/analyses/{analysis_id}")
async def get_analysis(analysis_id: str) -> JSONResponse:
    job = _get_job_or_404(analysis_id)
    if job.status == "PROCESSING":
        return JSONResponse({"status": "PROCESSING"})
    if job.status == "ERROR":
        return JSONResponse(status_code=400, content={"status": "ERROR", **(job.error or {})})
    return JSONResponse({"status": "READY", **(job.result or {})})


# Дальше три обработчика намеренно синхронные (`def`, не `async def`).
# Внутри — запись и чтение внешней базы, а это блокирующий вызов: в
# `async def` он выполняется прямо в цикле событий и на время сетевой паузы
# останавливает весь сервер, включая SSE-прогресс чужих прогонов. С файловой
# базой это были микросекунды и вопрос не стоял; с Postgres на стенде пауза
# измеряется секундами, а при недоступной базе — таймаутом соединения.
# Синхронный обработчик FastAPI уводит в пул потоков сам.
@app.post("/api/analyses/{analysis_id}/disputes")
def create_dispute(
    analysis_id: str,
    bullet_index: int = Form(...),
    verdict: str = Form(...),
    comment: str = Form(""),
    author: str = Form(""),
) -> JSONResponse:
    """Ответ команды на оценку одного буллита.

    Отчёт — утверждение о чужой работе, и у команды должно быть право с ним
    не согласиться. Три ответа: принять, принять с оговоркой, отклонить;
    последние два без комментария не принимаются — возражение без объяснения
    нечем обработать.

    Контекст (инициатива, текст буллита, статус агента) берётся из готового
    анализа, а не из формы: клиент не должен иметь возможности приписать
    возражение к чужому пункту.
    """
    job = _get_job_or_404(analysis_id)
    if job.status != "READY" or not job.result:
        raise PkoError(
            "Анализ ещё не готов — оспаривать нечего.",
            hint="дождитесь завершения анализа",
        )

    rows = [
        row
        for item in (job.result.get("items") or [])
        for row in (item.get("assessment") or [])
    ]
    if not 0 <= bullet_index < len(rows):
        raise PkoError(
            f"Пункт {bullet_index} не найден в этом анализе.",
            hint=f"в отчёте {len(rows)} пунктов, нумерация с нуля",
        )
    row = rows[bullet_index]
    meta = job.result.get("meta") or {}

    saved = feedback.store().save(feedback.Dispute(
        analysis_id=analysis_id,
        bullet_index=bullet_index,
        verdict=verdict,
        comment=comment,
        author=author,
        project_name=str(meta.get("project_name") or ""),
        client_path=str(meta.get("client_path_name") or ""),
        bullet_text=str(row.get("text") or ""),
        agent_status=str(row.get("status") or ""),
    ))
    return JSONResponse(saved.to_dict())


@app.get("/api/analyses/{analysis_id}/disputes")
def list_analysis_disputes(analysis_id: str) -> JSONResponse:
    """Возражения по одному анализу — чтобы экран показал уже сохранённое."""
    items = [d.to_dict() for d in feedback.store().list(analysis_id=analysis_id)]
    return JSONResponse({"items": items, "total": len(items)})


@app.get("/api/disputes")
def list_all_disputes(limit: int = 1000) -> JSONResponse:
    """Все возражения по всем анализам — то самое «в одном месте».

    Ради этого механика и заводилась: шестьдесят инициатив, и разбирать их
    ответы, открывая шестьдесят файлов, никто не станет.
    """
    items = [d.to_dict() for d in feedback.store().list(limit=limit)]
    return JSONResponse({"items": items, "total": len(items)})


@app.get("/api/analyses/{analysis_id}/dashboard.html")
async def get_analysis_dashboard(analysis_id: str) -> HTMLResponse:
    """Самодостаточный HTML-дашборд готовности проекта для скачивания."""
    job = _get_job_or_404(analysis_id)
    if job.status == "PROCESSING":
        raise PkoError("Анализ ещё не завершён.", hint="дождитесь READY по SSE/GET, затем запросите дашборд")
    if job.status == "ERROR":
        raise PkoError(job.error["message"] if job.error else "Анализ завершился с ошибкой.",
                       hint=(job.error or {}).get("hint", ""))
    return HTMLResponse(render_dashboard_html(job.result or {}))


@app.get("/api/analyses/{analysis_id}/passport.html")
async def get_analysis_passport(analysis_id: str) -> HTMLResponse:
    """Паспорт клиентского пути (шаблон ДПСС v3) для скачивания.

    Заполнен агентом в той же сессии (`submit_passport`) или, если агент до
    него не дошёл, детерминированно из модели и экстракции.
    """
    job = _get_job_or_404(analysis_id)
    if job.status == "PROCESSING":
        raise PkoError("Анализ ещё не завершён.", hint="дождитесь READY по SSE/GET, затем запросите паспорт")
    if job.status == "ERROR":
        raise PkoError(job.error["message"] if job.error else "Анализ завершился с ошибкой.",
                       hint=(job.error or {}).get("hint", ""))
    if job.passport_html is None:
        raise PkoError("Паспорт для этого анализа не сформирован.", hint=job.passport_note or "")
    return HTMLResponse(job.passport_html)

# Раскатка PKO progress на OpenShift

Что здесь лежит:

| Файл | Что делает |
|---|---|
| `../Dockerfile` | образ бэкенда (`uvicorn pko.web.app:app`) — в корне |
| `../frontend-web/Dockerfile` | образ фронтенда (Next.js standalone) |
| `../Jenkinsfile` | сборка обоих образов и деплой с откатом — в корне |
| `Chart.yaml`, `values.yaml`, `templates/` | чарт: один Deployment, один Service, один Route |

## Что получается в кластере

```
        Route (TLS passthrough, 8443)
                    │
              Service :8443
                    │
        ┌───────────▼────────────────────────────┐
        │                 1 pod                  │
        │  nginx :8443                           │
        │    ├── /api/  → localhost:8000 backend │
        │    └── /      → localhost:3000 front   │
        └───────────┬──────────────┬─────────────┘
                    │              │
              Postgres          LLM endpoint
             (внешний)          (внешний)
```

TLS терминирует сам pod: у Router'а нет валидного сертификата на целевой
hostname, поэтому Route идёт в режиме passthrough, а сертификат берётся из
Secret'а `syngx-certs`. Так же сделано у соседнего проекта в этом namespace.

**Реплика одна, и это не оплошность.** Реестр анализов и очередь задач живут
в памяти процесса (`web/analyses.py`): вторая реплика отвечала бы «анализ не
найден» на каждый второй запрос. Ответы команд от этого не страдают — они в
Postgres и видны всем.

## Хранилище: почему Postgres

Ответы команд («принять», «принять с оговоркой», «отклонить» плюс
комментарий) — единственное, что приложение обязано сохранить надолго.
Отчёты пересчитываются, кеш модели восстанавливается, а комментарий команды
написан человеком один раз.

В контейнере файловая база лежала бы на эфемерном диске и исчезала бы вместе
с подом при каждом деплое. Поэтому на стенде хранилище — внешний Postgres
(`PKO_DB_URL`), а файл остаётся только для запуска на своей машине.

Молчаливого отката с Postgres на файл нет: если DSN задан, а подключиться не
вышло, приложение говорит об этом. Тихо записать ответы в контейнерный файл и
потерять их через час — худший из возможных исходов.

Таблицу и схему приложение создаёт само при первом обращении. Если прав на
DDL у прикладного пользователя нет — заведите их заранее, приложение это
переживёт:

```sql
CREATE SCHEMA IF NOT EXISTS pko_progress;

CREATE TABLE IF NOT EXISTS pko_progress.disputes (
    id              BIGSERIAL PRIMARY KEY,
    created_at      TEXT    NOT NULL,
    analysis_id     TEXT    NOT NULL,
    project_name    TEXT    NOT NULL DEFAULT '',
    client_path     TEXT    NOT NULL DEFAULT '',
    bullet_index    INTEGER NOT NULL,
    bullet_text     TEXT    NOT NULL DEFAULT '',
    agent_status    TEXT    NOT NULL DEFAULT '',
    verdict         TEXT    NOT NULL,
    comment         TEXT    NOT NULL DEFAULT '',
    author          TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS disputes_analysis ON pko_progress.disputes(analysis_id);
CREATE INDEX IF NOT EXISTS disputes_verdict  ON pko_progress.disputes(verdict);

GRANT USAGE ON SCHEMA pko_progress TO <пользователь>;
GRANT SELECT, INSERT ON pko_progress.disputes TO <пользователь>;
GRANT USAGE ON SEQUENCE pko_progress.disputes_id_seq TO <пользователь>;
```

Разобрать ответы потом можно одним запросом:

```sql
SELECT created_at, project_name, bullet_text, verdict, comment
  FROM pko_progress.disputes
 ORDER BY id DESC;
```

То же самое отдаёт `GET /api/disputes` — всё сразу, без обхода анализов.

## Что нужно завести до первого деплоя

Три Secret'а в namespace. Чарт их **не создаёт**: секреты не должны лежать в
git даже в шаблонном виде.

```bash
# 1. Строка подключения к Postgres
oc create secret generic pg-dsn -n ci02589505-ai-agents \
  --from-literal=DATABASE_URL_SYNC='postgresql://пользователь:пароль@хост:5432/база'

# 2. Эндпоинт и ключ модели (все три ключа необязательные: без них берутся
#    значения из pko/defaults.py)
oc create secret generic models-secrets -n ci02589505-ai-agents \
  --from-literal=PKO_ASSEMBLER_BASE_URL='https://<эндпоинт>/v1' \
  --from-literal=PKO_ASSEMBLER_MODEL='GLM-5.2' \
  --from-literal=PKO_ASSEMBLER_API_KEY='...'

# 3. Сертификат для nginx (обычно уже есть в namespace)
oc create secret generic syngx-certs -n ci02589505-ai-agents \
  --from-file=chain.pem=./chain.pem \
  --from-file=server_key.key=./server_key.key
```

Драйвер ставится в образ отдельным файлом `requirements-postgres.txt`: на
ноутбуке он не нужен, а колесо `psycopg-binary` собрано не под каждую
версию Python. Код принимает и `psycopg2-binary` — что найдётся в индексе.

DSN принимается и в форме SQLAlchemy (`postgresql+psycopg://...`) — суффикс
драйвера снимается на входе.

## Деплой

Обычный путь — Jenkins: он собирает оба образа под тегом `<BUILD_ID>-snapshot`
и раскатывает чарт, а при неудачных health checks откатывает на предыдущую
ревизию.

Руками:

```bash
helm lint helm --values helm/values.yaml
helm template pko-progress helm --values helm/values.yaml | less

helm upgrade --install pko-progress helm \
  --namespace ci02589505-ai-agents \
  --set images.backend.tag=<тег> \
  --set images.frontend.tag=<тег> \
  --atomic --wait --timeout 5m
```

## Проверка после раскатки

```bash
oc get pods -n ci02589505-ai-agents            # 1 pod, 3/3 Ready
oc logs deploy/pko-progress -c backend --tail=50
curl -k https://<host>/api/health
```

`/api/health` отвечает, куда пишутся ответы команд:

```json
{"status": "ok", "storage": "postgres",
 "storage_target": "Postgres postgresql://pko:***@db:5432/analytics, схема pko_progress"}
```

**`"storage": "sqlite"` в контейнере — это авария**, а не мелочь: значит DSN
не доехал, ответы команд пишутся в файл внутри пода и исчезнут при первом же
деплое. Проверьте Secret `pg-dsn` и имя ключа в `backend.dbSecretKey`.

Дальше — обычный сценарий: открыть Route, загрузить ZIP или указать
репозиторий, дождаться отчёта, у не-зелёного пункта нажать «Отклонить» с
комментарием и убедиться, что строка появилась в базе.

## Что менять под другой стенд (ПСИ, ПРОМ)

| Параметр | Где |
|---|---|
| namespace | `values.yaml: namespace` и `Jenkinsfile: NAMESPACE` |
| hostname | `values.yaml: route.host` |
| адрес кластера | `Jenkinsfile: KUBERNETES_SERVICE_HOST` |
| путь образов | `values.yaml: images.*.repository` и `Jenkinsfile: destImagePath` |
| схема в базе | `values.yaml: backend.dbSchema` |
| ключ DSN в Secret'е | `values.yaml: backend.dbSecretKey` |
| имена Secret'ов | `values.yaml: secrets.*`, `nginx.certsSecret` |
| лимиты ресурсов | `values.yaml: backend.resources` и соседние |
| параллельность прогонов | `values.yaml: backend.maxParallel` |
| длина очереди прогонов | `values.yaml: backend.maxQueue` |
| потолок времени сессии | `values.yaml: backend.sessionSeconds` |
| образ nginx | `values.yaml: images.nginx` — путь до зеркала docker.io |

## Известные ограничения

- **Реплика одна.** См. выше: реестр анализов в памяти процесса.
- **Одновременных прогонов — два** (`backend.maxParallel`). Больше упирается
  не в процессор, а в память: каждый прогон держит распакованный workspace и
  историю диалога агента. Остальные запросы не отклоняются, а ждут очереди —
  человек видит это на экране прогресса.
- **Сессия агента ограничена получасом** (`backend.sessionSeconds`). По
  исчерпании отчёт выпускается по тому, что успели оценить, с пометкой в
  замечаниях. Ноль снимает предел.
- **Загрузка — до 200 МБ на запрос** и столько же на распакованные материалы;
  nginx отсекает всё, что тяжелее 256 МБ.
- **Анализы хранятся в памяти, последние сто.** Ссылка на отчёт старше сотни
  прогонов ответит «анализ не найден». Ответы команд это не затрагивает —
  они в Postgres.
- **Кеш модели и зеркала репозиториев — на `emptyDir`.** После рестарта пода
  первый прогон снова платит вызовами модели. Данных это не теряет.
- **Клонирование по SSH** требует ключа в контейнере; на стенде рабочий путь —
  загрузка ZIP-архивов через форму. Несколько архивов сразу поддерживаются
  (каждый распаковывается в свой каталог).
- **CLI-отчёт (`pko progress` внутри контейнера) не соберётся**: ему нужен
  собранный `frontend-app/dist/index.html`, которого в образе бэкенда нет.
  Веб-отчёт самодостаточен и от этого файла не зависит.
- **Аутентификации нет.** Кто открыл ссылку — тот и запускает прогоны и
  читает чужие ответы. Для внутреннего стенда это решение, а не недосмотр,
  но решение осознанное: если контур требует иного, нужен внешний слой
  (OAuth-proxy на Route или auth в nginx).
- **Тесты в пайплайне не гоняются.** Гейт локальный: `python
  tests/run_tests.py` перед пушем — прогон герметичный, сети и базы не
  требует.

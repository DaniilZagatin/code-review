"""Единый паспорт клиентского пути — рендер HTML-шаблона v3.

Шаблон: ``passport-dpss-v3.html``. Использует ``data-fill``
атрибуты (не Mustache): каждый заполняемый элемент имеет
``data-fill="value|source|name|object-id|object-version|..."`` и
``data-placeholder``. Рендерер находит эти элементы и подставляет текст,
сохраняя CSS, структуру, классы и ``<template>``-доноры.

Иерархия объектов в шаблоне:
  journey (КП) → process (процесс) → bbb (бизнес-блок) → operation (операция)

Карточки потребности клиента (§ 4.1) и ограничения исполнения (§ 4.6),
которые есть в шаблоне, паспорт не выпускает: их контейнеры и заготовки
рендерер вырезает (`_strip_removed_sections`), сам шаблон не меняется.
Раздел «Основание паспорта» (область анализа, граница решения, дата,
образ результата) вырезается так же: заказчику он не нужен, репозиторий
и коммит остаются строкой в шапке.
Поверх дерева паспорт несёт связи: у узла может быть несколько родителей
(общий BBB в нескольких процессах), а между узлами — связи из
`passport_gate.RELATION_KINDS`; в реестре столбец «Родитель» перечисляет
всех родителей через запятую, связи идут в схему и карточку узла.

Два источника значений полей:
  1. **Паспортный агент** (``progress.passport_agent``, отдельная сессия
     после оценки, рецензента и ревизора) — модель заполняет смысловые поля
     по знаниям сессии оценки. Значения приходят как ``passport_data``
     (``ProgressModel.passport_data``) и преобразуются в ``llm_values``
     (плоский dict, ключи совпадают со схемой ``_fill_template``).
  2. **Детерминированное заполнение** (``_build_fill_values``) — fallback
     из ProgressModel + Extraction, если паспортная сессия не приняла ни
     одного узла.

Принцип тот же: код заполняет, не выдумывает. Агент предлагает содержания
полей, код подставляет их в HTML — модель не видит разметку и не может
её сломать.
"""

from __future__ import annotations

import html as _html
import re
import time
from pathlib import Path
from typing import Any

from pko.errors import PkoError
from pko.extractors.runner import Extraction
from pko.progress.passport_gate import PLANNED_FIELDS, audience_of, journey_name_of
from pko.render.passport_map import build_passport_map, nodes_json
from pko.progress.plan_input import PlanInput
from pko.progress.schema import ProgressModel

_TEMPLATE_PATH = Path(__file__).resolve().parents[3] / "passport-dpss-v3.html"

_EMPTY = "Не установлено по доступным артефактам"
_NEEDS_OWNER = "Требуется подтверждение владельца"


def render_client_journey_passport(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str = "",
    llm_values: dict[str, str] | None = None,
    registry_rows: list[dict[str, str]] | None = None,
    tree_spec: list[dict[str, Any]] | None = None,
) -> str:
    """Собрать заполненный HTML-паспорт из модели и экстракции.

    ``llm_values`` — плоский dict значений полей от агента (ключи вида
    ``{node}:{field}:value``, ``{node}:name``, ``analysis-scope`` и т.д.).
    Если передан, значения LLM перекрывают детерминированные (только непустые).

    ``registry_rows`` — строки реестра узлов от агента. Если не передан,
    реестр строится детерминированно из известных узлов.

    ``tree_spec`` — спецификация дерева узлов от агента (произвольное число
    узлов каждого типа). Если передана, рендерер клонирует
    ``<template>``-заготовки и перестраивает дерево.
    """
    template = _strip_removed_sections(_TEMPLATE_PATH.read_text(encoding="utf-8"))
    values = _build_fill_values(model, plan_input, repo_name, extraction, commit, branch, model_name)
    filled_by_agent = bool(llm_values)
    if llm_values:
        for key, val in llm_values.items():
            if val:
                values[key] = val
    if tree_spec:
        template = _insert_extra_nodes(template, tree_spec, registry_rows)
    if registry_rows is None:
        registry_rows = _build_registry(values)
    schema = build_passport_map(model)
    # Статус узла в реестре — тот же, что на схеме: считает код по пунктам ОР.
    status_by_id = {n["id"]: n.get("implementation_label", "") for n in schema.get("nodes", [])}
    template = _fill_registry(template, registry_rows, status_by_id)
    template = _fill_template(template, values)
    # Библиотека заготовок нужна только клонированию узлов; в выпуске её нет:
    # заготовка с унаследованным id и названием читается как пустой узел.
    template = _strip_templates(template)
    _assert_no_placeholders(template)
    template = _set_status_badge(template, filled_by_agent)
    template = _set_title(template, _journey_title(model, plan_input, repo_name))
    summary = schema.get("summary") or {}
    schema["meta"] = {
        "scope": values.get("analysis-scope", ""),
        "audience": audience_of(plan_input.context),
        "boundary": values.get("decision-boundary", ""),
        "date": values.get("analysis-date", ""),
        "analysis": _analysis_scope_lines(extraction, commit, summary),
        "planned_fields": {k: sorted(v) for k, v in PLANNED_FIELDS.items()},
        # Потребность и ограничения исполнения — уровни графа, их формулирует
        # паспортный агент (submit_need / submit_guardrail).
        "needs": list((model.passport_data or {}).get("needs") or []),
        "guardrails": list((model.passport_data or {}).get("guardrails") or []),
    }
    template = _finalize_html(template, schema)
    return template


def _journey_title(model: ProgressModel, plan_input: PlanInput, repo_name: str) -> str:
    """Название пути — как его сформулировал агент; без агента — из образа результата."""
    nodes = (model.passport_data or {}).get("nodes") or {}
    root = nodes.get("journey-1") if isinstance(nodes, dict) else None
    name = str((root or {}).get("name") or "").strip() if isinstance(root, dict) else ""
    return name or journey_name_of(plan_input.context, repo_name)


_TEMPLATE_BLOCK_RE = re.compile(r'<template id="tpl-\w+">.*?</template>\s*', re.DOTALL)
_PLACEHOLDER_ID_RE = re.compile(r'id="(?:journey|process|bbb|operation)-N"')


def _strip_templates(template: str) -> str:
    """Убрать библиотеку заготовок. Сначала — комментарии: в них шаблон
    упоминает «<template id="tpl-journey">» текстом, и регулярка по тегам
    иначе съедает дерево до первого настоящего `</template>`."""
    return _TEMPLATE_BLOCK_RE.sub("", _COMMENT_RE.sub("", template))


def _assert_no_placeholders(template: str) -> None:
    """Ни один видимый узел не несёт `-N` в id — иначе в паспорт уехала заготовка."""
    stripped = _COMMENT_RE.sub("", template)
    if _PLACEHOLDER_ID_RE.search(stripped):
        raise PkoError(
            "в паспорт попала заготовка узла с id «-N»",
            "проверьте вставку узлов: заготовки клонируются только с реальным номером",
        )


def _analysis_scope_lines(extraction: Extraction, commit: str, summary: dict[str, Any]) -> list[str]:
    """Область анализа для шапки: что загружено и чего среди материалов нет.
    Явное «не проверялось» лучше молчания."""
    paths = {str(f.path) for f in getattr(extraction, "facts", []) or [] if getattr(f, "path", "")}
    lines = [f"файлов с фактами: {len(paths)}" if paths else "фактов из кода не извлечено"]
    if not commit:
        lines.append("git-история отсутствует: источник — архив или отдельные файлы, версия кода не привязана")
    total, unchecked = summary.get("handoffs_total") or 0, summary.get("wiring_unchecked") or 0
    if total and unchecked:
        lines.append(f"подключение в конфигурации сборки не проверено на {unchecked} из {total} передач")
    elif not total:
        lines.append("передачи между шагами не прослежены: целевых сценариев нет")
    return lines


_TITLE_RE = re.compile(r"(<h1\b[^>]*>)(.*?)(</h1>)", re.DOTALL)


def _set_title(html: str, name: str) -> str:
    """Заголовок страницы — «Паспорт инициативы «Название»».

    Название — из образа результата; в `<title>` оно же, чтобы вкладка и
    файл в письме опознавались без открытия.
    """
    title = f"Паспорт инициативы «{_html.escape(name)}»"
    html = _TITLE_RE.sub(lambda m: m.group(1) + title + m.group(3), html, count=1)
    return html.replace(
        "<title>Единый паспорт клиентского пути · ДПСС</title>",
        f"<title>{title}</title>", 1,
    )


def render_passport_from_model(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str = "",
) -> str:
    """Паспорт по итоговой модели прогона — общая точка для CLI и веба.

    Если паспортная сессия приняла хотя бы один узел (`model.passport_data`),
    дерево, реестр и поля берутся из него; иначе рендерер заполняет паспорт
    детерминированно из модели и экстракции и ставит бейдж «агент паспорт
    не заполнил».
    """
    data = model.passport_data
    return render_client_journey_passport(
        model, plan_input, repo_name, extraction,
        commit=commit, branch=branch, model_name=model_name,
        llm_values=flatten_passport_data(data) if data else None,
        registry_rows=passport_registry_rows(data) if data else None,
        tree_spec=passport_tree_spec(data) if data else None,
    )


# Бейдж в шапке. Шаблон приходит с «ЗАГОТОВКА · ПОЛЯ НЕ ЗАПОЛНЕНЫ», и
# заполненный паспорт уходил читателю с этой подписью. Статус переключает
# код: он один знает, кто заполнял поля.
STATUS_BADGE_TEMPLATE = "ЗАГОТОВКА · ПОЛЯ НЕ ЗАПОЛНЕНЫ"
STATUS_BADGE_AGENT = "ЗАПОЛНЕНО ПО КОДУ · БИЗНЕС-НАМЕРЕНИЕ ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ ВЛАДЕЛЬЦА"
STATUS_BADGE_FALLBACK = "ЗАПОЛНЕНО ДЕТЕРМИНИРОВАННО · АГЕНТ ПАСПОРТ НЕ ЗАПОЛНИЛ"


def _set_status_badge(html: str, filled_by_agent: bool) -> str:
    badge = STATUS_BADGE_AGENT if filled_by_agent else STATUS_BADGE_FALLBACK
    return html.replace(STATUS_BADGE_TEMPLATE, badge, 1)


# --- разделы шаблона, которых в паспорте нет -----------------------------------

# Контейнеры и заготовки потребности клиента и ограничения исполнения. Шаблон
# остаётся прежним (это стандарт заказчика), а из выпускаемого файла эти
# разделы вырезаются вместе с образцами need-1 и guardrail-1 внутри.
_REMOVED_CONTAINERS = ("related-needs", "related-guardrails")
_REMOVED_TEMPLATES = ("tpl-need", "tpl-guardrail")
# Разделы шаблона, которые вырезаются целиком по заголовку.
_REMOVED_SECTION_TITLES = ("Основание паспорта",)


def _strip_removed_sections(template: str) -> str:
    for container_id in _REMOVED_CONTAINERS:
        template = _remove_div_by_id(template, container_id)
    for tpl_id in _REMOVED_TEMPLATES:
        template = re.sub(
            rf'<template id="{tpl_id}">.*?</template>\s*', '', template, count=1, flags=re.DOTALL,
        )
    for title in _REMOVED_SECTION_TITLES:
        template = re.sub(
            rf'<section\b[^>]*>\s*<h2\b[^>]*>{re.escape(title)}</h2>.*?</section>\s*',
            '', template, count=1, flags=re.DOTALL,
        )
    return template


def _remove_div_by_id(template: str, element_id: str) -> str:
    """Убрать `<div id="…">…</div>` целиком, с учётом вложенных div."""
    m = re.search(rf'<div\b[^>]*id="{re.escape(element_id)}"[^>]*>', template)
    if not m:
        return template
    end = _closing_div_end(template, m.end())
    if end is None:
        return template
    return template[:m.start()] + template[end:]


def _closing_div_end(template: str, pos: int) -> int | None:
    """Позиция сразу после закрывающего `</div>` контейнера, открытого до `pos`."""
    depth = 1
    while depth > 0 and pos < len(template):
        open_m = re.search(r"<div\b", template[pos:])
        close_m = re.search(r"</div>", template[pos:])
        if close_m is None:
            return None
        if open_m and open_m.start() < close_m.start():
            depth += 1
            pos += open_m.end()
        else:
            depth -= 1
            pos += close_m.end()
            if depth == 0:
                return pos
    return None


# --- динамические узлы из ответа агента ---------------------------------------
#
# Агент может вернуть дерево с произвольным числом узлов каждого типа.
# Шаблон v3 содержит образцы (journey-1, process-1, bbb-1, ...) и
# <template>-заготовки для клонирования. Рендерер:
#   1. Находит узлы, которых ещё нет в HTML (по id).
#   2. Клонирует <template> нужного типа, заменяет -N на реальный номер.
#   3. Вставляет клон в data-children контейнер родителя.

_TEMPLATE_RE = re.compile(
    r'<template id="tpl-(\w+)">(.*?)</template>', re.DOTALL,
)

# HTML-комментарии: в шаблоне v3 внутри комментариев встречаются тексты
# вида «<template id="tpl-journey">» — они не теги, а подсказки агенту.
# Без удаления комментариев regex выше ловит их и ест половину файла.
_COMMENT_RE = re.compile(r'<!--.*?-->', re.DOTALL)


def _strip_comments(html: str) -> str:
    """Убрать HTML-комментарии, чтобы regex по тегам не матчил текст в них."""
    return _COMMENT_RE.sub("", html)


def _extract_templates(template: str) -> dict[str, str]:
    """Извлечь HTML-заготовки узлов из <template> элементов."""
    clean = _strip_comments(template)
    out: dict[str, str] = {}
    for m in _TEMPLATE_RE.finditer(clean):
        out[m.group(1)] = m.group(2)
    return out


def _clone_node(template_html: str, node_id: str) -> str:
    """Клонировать заготовку узла, заменив ``N`` в id на реальный номер."""
    number = node_id.rsplit("-", 1)[-1]
    return template_html.replace("-N", f"-{number}")


def _existing_node_ids(template: str) -> set[str]:
    """Найти id всех узлов, уже присутствующих в HTML (вне <template>)."""
    clean = _strip_comments(template)
    stripped = _TEMPLATE_RE.sub("", clean)
    return set(re.findall(
        r'id="((?:journey|process|bbb|operation)-\d+)"',
        stripped,
    ))


def _insert_extra_nodes(
    template: str,
    tree_spec: list[dict[str, Any]],
    registry_rows: list[dict[str, str]] | None,
) -> str:
    """Добавить недостающие узлы в HTML, клонируя <template>-заготовки.

    Работает с шаблоном v3, где нет ``id="tree"`` контейнера: узлы лежат
    напрямую в ``<section>``, а дочерние — в ``data-children`` контейнерах
    внутри родительского узла.
    """
    templates = _extract_templates(template)
    if not templates:
        return template

    existing = _existing_node_ids(template)

    # Собираем все id узлов из tree_spec и registry.
    all_nodes = _collect_all_node_ids(tree_spec, registry_rows)

    # Узлы, которые нужно добавить.
    missing = [nid for nid in all_nodes if nid not in existing]
    if not missing:
        return template

    # Для каждого недостающего узла: клонируем template и вставляем
    # в data-children контейнер родителя.
    for node_id in missing:
        node_type = _node_type(node_id)
        tpl = templates.get(node_type)
        if not tpl:
            continue
        clone = _clone_node(tpl, node_id)

        # Ищем родителя по registry. В столбце «Родитель» могут стоять
        # несколько узлов через запятую: карточка общего узла лежит под
        # первым, остальные родители — связи на схеме.
        parent_id = None
        for row in (registry_rows or []):
            if row.get("id") == node_id:
                parent_id = _first_parent(row.get("parent", ""))
                break

        if parent_id and parent_id != "—":
            # Вставляем в data-children="[type]" контейнер внутри родителя.
            template = _insert_into_parent(template, parent_id, node_type, clone)
        else:
            # Journey без родителя — вставляем после последнего journey.
            template = _insert_after_last_node(template, node_type, clone)

    return template


def _insert_into_parent(
    template: str, parent_id: str, child_type: str, clone_html: str,
) -> str:
    """Вставить клон узла в data-children контейнер внутри родительского узла.

    Ищем ``<div ... data-children="child_type" ...>...</div>`` внутри HTML
    родительского узла (по id) и вставляем клон перед закрывающим ``</div>``.
    """
    # Находим позицию родительского узла по id.
    parent_re = re.compile(rf'id="{re.escape(parent_id)}"')
    parent_m = parent_re.search(template)
    if not parent_m:
        return template

    # После родительского id ищем data-children="child_type" контейнер.
    search_start = parent_m.end()
    container_re = re.compile(
        rf'(<div\b[^>]*data-children="{child_type}"[^>]*>)',
    )
    if child_type == "bbb" and _node_type(parent_id) == "journey":
        # Узел до развилки живёт под клиентским путём, а у пути в шаблоне
        # только контейнер процессов: свой контейнер BBB добавляется перед
        # ним. Искать первый попавшийся data-children="bbb" нельзя — он
        # окажется внутри первого процесса.
        process_m = re.compile(r'<div\b[^>]*data-children="process"[^>]*>').search(template, search_start)
        if not process_m:
            return template
        holder_re = re.compile(r'(<div\b[^>]*data-children="bbb" data-before-fork="true"[^>]*>)')
        container_m = holder_re.search(template, search_start, process_m.start())
        if not container_m:
            holder = ('<div class="children" data-children="bbb" data-before-fork="true" '
                      'style="margin:24px 0 0 12px;padding-left:24px;border-left:1px dashed var(--g3)"></div>\n')
            template = template[:process_m.start()] + holder + template[process_m.start():]
            container_m = holder_re.search(template, search_start)
    else:
        container_m = container_re.search(template, search_start)
    if not container_m:
        return template

    # От начала контейнера ищем его закрывающий </div> (с учётом вложенности).
    pos = container_m.end()
    depth = 1
    while depth > 0 and pos < len(template):
        open_m = re.search(r"<div\b", template[pos:])
        close_m = re.search(r"</div>", template[pos:])
        if close_m is None:
            break
        if open_m and open_m.start() < close_m.start():
            depth += 1
            pos += open_m.end()
        else:
            depth -= 1
            if depth == 0:
                # Это закрывающий тег контейнера — вставляем перед ним.
                insert_pos = pos + close_m.start()
                return (
                    template[:insert_pos]
                    + "\n" + clone_html + "\n"
                    + template[insert_pos:]
                )
            pos += close_m.end()

    return template


def _first_parent(raw: str) -> str:
    """Первый родитель из столбца «Родитель» реестра («process-1, process-2»)."""
    parts = [p.strip() for p in str(raw or "").replace(";", ",").replace("·", ",").split(",")]
    return next((p for p in parts if p), "")


def _insert_after_last_node(
    template: str, node_type: str, clone_html: str,
) -> str:
    """Вставить клон после последнего узла того же типа (fallback)."""
    # Ищем все id="type-N" вне <template>.
    stripped = _TEMPLATE_RE.sub("", template)
    matches = list(re.finditer(
        rf'id="({node_type}-\d+)"', stripped,
    ))
    if not matches:
        return template
    # Вставляем после конца последнего узла — после следующего </div>
    # на том же уровне. Простой подход: вставляем перед началом следующего
    # блока (следующий узел или конец section).
    last_pos = matches[-1].end()
    # Ищем следующий </div> на нужной глубине — грубо, ищем
    # "<!--#NODE:" или "<div id=\"related-" после последнего узла.
    after = re.search(
        r'(<!--#NODE:|</section)',
        template[last_pos:],
    )
    if after:
        insert_pos = last_pos + after.start()
        return (
            template[:insert_pos]
            + "\n" + clone_html + "\n"
            + template[insert_pos:]
        )
    return template


def _collect_all_node_ids(
    tree_spec: list[dict[str, Any]] | None,
    registry_rows: list[dict[str, str]] | None,
) -> list[str]:
    """Собрать все id узлов из tree_spec и/или registry, в порядке появления."""
    seen: list[str] = []
    seen_set: set[str] = set()

    def visit(node: dict[str, Any]) -> None:
        nid = node.get("id", "")
        if nid and nid not in seen_set:
            seen.append(nid)
            seen_set.add(nid)
        for child in (node.get("children") or []):
            if isinstance(child, dict):
                visit(child)

    if tree_spec:
        for node in tree_spec:
            if isinstance(node, dict):
                visit(node)

    if registry_rows:
        for row in registry_rows:
            nid = row.get("id", "")
            if nid and nid not in seen_set:
                seen.append(nid)
                seen_set.add(nid)

    return seen

    return html


# --- данные ------------------------------------------------------------------

def _build_fill_values(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str,
) -> dict[str, str]:
    """Сопоставить поля шаблона с данными модели.

    Ключи — составные: `{node_id}:{fill_type}` или `{node_id}:{field_id}:{fill_type}`.
    `fill_type` — value | source | name | object-id | object-version.
    """
    ctx = plan_input.context
    # Название клиентского пути — строго из образа результата инициативы.
    # Имя проекта и репозитория — только запасные варианты, когда в тексте
    # пути названия нет вовсе.
    journey_name = journey_name_of(ctx, repo_name)
    project_name = ctx.get("project_name") or journey_name
    generated = time.strftime("%Y-%m-%d %H:%M")
    v: dict[str, str] = {}

    # --- мета (в шапку: раздела «Основание паспорта» в выпуске нет) ---
    v["analysis-scope"] = f"{repo_name} · коммит {commit[:8] if commit else '—'} · {project_name}"
    v["decision-boundary"] = "END_TO_END_PROCESS"
    v["analysis-date"] = generated

    # --- journey-1 (Клиентский путь) ---
    v["journey-1:name"] = journey_name
    v["journey-1:object-id"] = _EMPTY
    v["journey-1:object-version"] = _EMPTY
    v["journey-1:4.2.1:value"] = ctx.get("before") or _EMPTY
    v["journey-1:4.2.1:source"] = "образ результата инициативы"
    v["journey-1:4.2.2:value"] = ctx.get("client_path_name") or _EMPTY
    v["journey-1:4.2.2:source"] = "образ результата инициативы"
    v["journey-1:4.2.3:value"] = _NEEDS_OWNER
    v["journey-1:4.2.3:source"] = _EMPTY
    v["journey-1:4.2.4:value"] = (
        f"До: {ctx.get('before', _EMPTY)}. После: {ctx.get('after', _EMPTY)}."
    )
    v["journey-1:4.2.4:source"] = "образ результата инициативы"
    v["journey-1:4.2.5:value"] = _summary_outcomes(model)
    v["journey-1:4.2.5:source"] = "оценка агента по коду репозитория"
    v["journey-1:4.2.6:value"] = _stages_text(plan_input)
    v["journey-1:4.2.6:source"] = "образ результата инициативы"
    v["journey-1:4.2.7:value"] = _interaction_moments(model)
    v["journey-1:4.2.7:source"] = "оценка агента по коду репозитория"
    v["journey-1:4.2.8:value"] = _EMPTY
    v["journey-1:4.2.8:source"] = _EMPTY

    # --- process-1 (Автономный процесс) ---
    v["process-1:name"] = project_name
    v["process-1:object-id"] = _EMPTY
    v["process-1:object-version"] = _EMPTY
    v["process-1:4.3.1:value"] = f"Собирает и исполняет решение для клиентского пути «{journey_name}»."
    v["process-1:4.3.1:source"] = "образ результата инициативы"
    v["process-1:4.3.2:value"] = f"Клиентский путь: {journey_name}"
    v["process-1:4.3.2:source"] = "образ результата инициативы"
    v["process-1:4.3.3:value"] = _NEEDS_OWNER
    v["process-1:4.3.3:source"] = _EMPTY
    v["process-1:4.3.4:value"] = _entry_conditions(extraction)
    v["process-1:4.3.4:source"] = _extraction_source(extraction, "ROUTE")
    v["process-1:4.3.5:value"] = _routing_logic(model, plan_input)
    v["process-1:4.3.5:source"] = _extraction_source(extraction, "GRAPH_NODE")
    v["process-1:4.3.6:value"] = _bbbs_and_modes(extraction)
    v["process-1:4.3.6:source"] = _extraction_source(extraction, "TOOL")
    v["process-1:4.3.7:value"] = _fallback(model, extraction)
    v["process-1:4.3.7:source"] = "оценка агента по коду репозитория"
    v["process-1:4.3.8:value"] = _EMPTY
    v["process-1:4.3.8:source"] = _EMPTY
    v["process-1:4.3.9:value"] = f"Коммит: {commit or '—'}"
    v["process-1:4.3.9:source"] = "git-коммит"

    # --- bbb-1 (первый бизнес-блок) ---
    _fill_bbb(v, "bbb-1", extraction, model, 0)
    # --- bbb-2 ---
    _fill_bbb(v, "bbb-2", extraction, model, 1)
    # --- bbb-3 ---
    _fill_bbb(v, "bbb-3", extraction, model, 2)

    # --- operation-1, operation-2 ---
    _fill_operation(v, "operation-1", extraction, 0)
    _fill_operation(v, "operation-2", extraction, 1)

    return v


def _fill_bbb(v: dict, node_id: str, extraction: Extraction, model: ProgressModel, index: int) -> None:
    tools = extraction.by_kind("TOOL") + extraction.by_kind("GRAPH_NODE")
    fact = tools[index] if index < len(tools) else None
    if fact:
        v[f"{node_id}:name"] = fact.key
        v[f"{node_id}:object-id"] = _EMPTY
        v[f"{node_id}:object-version"] = _EMPTY
        v[f"{node_id}:4.4.1:value"] = str(fact.value or _EMPTY)[:200] if isinstance(fact.value, (str, dict)) else _EMPTY
        v[f"{node_id}:4.4.1:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.2:value"] = _EMPTY
        v[f"{node_id}:4.4.2:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.3:value"] = _NEEDS_OWNER
        v[f"{node_id}:4.4.3:source"] = _EMPTY
        v[f"{node_id}:4.4.4:value"] = _EMPTY
        v[f"{node_id}:4.4.4:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.5:value"] = _EMPTY
        v[f"{node_id}:4.4.5:source"] = _EMPTY
        v[f"{node_id}:4.4.6:value"] = _EMPTY
        v[f"{node_id}:4.4.6:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.7:value"] = _EMPTY
        v[f"{node_id}:4.4.7:source"] = _EMPTY
    else:
        for fill in ("name", "object-id", "object-version"):
            v[f"{node_id}:{fill}"] = _EMPTY
        for field in ("4.4.1", "4.4.2", "4.4.3", "4.4.4", "4.4.5", "4.4.6", "4.4.7"):
            v[f"{node_id}:{field}:value"] = _EMPTY
            v[f"{node_id}:{field}:source"] = _EMPTY


def _fill_operation(v: dict, node_id: str, extraction: Extraction, index: int) -> None:
    funcs = [f for f in extraction.by_kind("FUNCTION") if f.value and isinstance(f.value, dict) and f.value.get("doc")]
    fact = funcs[index] if index < len(funcs) else None
    if fact:
        doc = str(fact.value.get("doc") or _EMPTY)[:200]
        v[f"{node_id}:name"] = fact.key
        v[f"{node_id}:object-id"] = _EMPTY
        v[f"{node_id}:object-version"] = _EMPTY
        v[f"{node_id}:4.5.1:value"] = doc
        v[f"{node_id}:4.5.1:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.2:value"] = _EMPTY
        v[f"{node_id}:4.5.2:source"] = _EMPTY
        v[f"{node_id}:4.5.3:value"] = _NEEDS_OWNER
        v[f"{node_id}:4.5.3:source"] = _EMPTY
        v[f"{node_id}:4.5.4:value"] = _EMPTY
        v[f"{node_id}:4.5.4:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.5:value"] = _EMPTY
        v[f"{node_id}:4.5.5:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.6:value"] = _EMPTY
        v[f"{node_id}:4.5.6:source"] = _EMPTY
    else:
        for fill in ("name", "object-id", "object-version"):
            v[f"{node_id}:{fill}"] = _EMPTY
        for field in ("4.5.1", "4.5.2", "4.5.3", "4.5.4", "4.5.5", "4.5.6"):
            v[f"{node_id}:{field}:value"] = _EMPTY
            v[f"{node_id}:{field}:source"] = _EMPTY


# --- вспомогательные ---------------------------------------------------------

def _summary_outcomes(model: ProgressModel) -> str:
    if not model.verdicts:
        return _EMPTY
    done = sum(1 for v in model.verdicts for c in v.criteria if c.applicable and c.status == "done")
    total = sum(1 for v in model.verdicts for c in v.criteria if c.applicable)
    if done == total:
        return f"Все {total} пунктов реализованы — путь завершается успешно."
    if done > 0:
        return f"Из {total} пунктов полностью работают {done} — результат достигается частично."
    return f"Из {total} пунктов ни один не работает полностью — результат не подтверждён."


def _stages_text(plan_input: PlanInput) -> str:
    if not plan_input.stages:
        return _EMPTY
    return "; ".join(f"{i}. {s}" for i, s in enumerate(plan_input.stages, 1))


def _interaction_moments(model: ProgressModel) -> str:
    moments: list[str] = []
    for v in model.verdicts:
        for c in v.criteria:
            if c.applicable and c.how_text:
                moments.append(c.how_text[:120])
    if not moments:
        return _EMPTY
    return "; ".join(moments[:5])


def _entry_conditions(extraction: Extraction) -> str:
    routes = extraction.by_kind("ROUTE")
    if not routes:
        return _EMPTY
    return "Точка входа: " + ", ".join(f.key for f in routes[:3])


def _routing_logic(model: ProgressModel, plan_input: PlanInput) -> str:
    parts: list[str] = []
    if plan_input.stages:
        parts.append("Этапы: " + " → ".join(plan_input.stages))
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        done = sum(1 for c in v.criteria if c.applicable and c.status == "done")
        total = sum(1 for c in v.criteria if c.applicable)
        parts.append(f"{item.title}: {done}/{total}")
    return "; ".join(parts[:5]) or _EMPTY


def _bbbs_and_modes(extraction: Extraction) -> str:
    tools = extraction.by_kind("TOOL")
    if not tools:
        return _EMPTY
    return ", ".join(f.key for f in tools[:5])


def _fallback(model: ProgressModel, extraction: Extraction) -> str:
    for v in model.verdicts:
        for c in v.criteria:
            if c.applicable and c.status in ("partial", "blocked"):
                return "Обнаружены нереализованные пункты — требуется ручная проверка"
    return _EMPTY


def _extraction_source(extraction: Extraction, kind: str) -> str:
    facts = extraction.by_kind(kind)
    if not facts:
        return _EMPTY
    f = facts[0]
    return f"{f.path}:{f.line}" if f.line else f.path


# --- реестр узлов ------------------------------------------------------------

_NODE_META = [
    ("journey-1", "Клиентский путь", "—"),
    ("process-1", "Автономный процесс", "journey-1"),
    ("bbb-1", "BBB", "process-1"),
    ("operation-1", "Атомарная операция", "bbb-1"),
]


def _build_registry(values: dict[str, str]) -> list[dict[str, str]]:
    """Построить реестр узлов из заполненных значений (fallback без LLM)."""
    rows: list[dict[str, str]] = []
    for node_id, type_label, parent in _NODE_META:
        name = values.get(f"{node_id}:name", "")
        rows.append({
            "id": node_id,
            "type": type_label,
            "name": name,
            "parent": parent,
            "basis": "обнаружен в коде репозитория",
        })
    return rows


_REGISTRY_TBODY_RE = re.compile(
    r"(<table[^>]*class=\"registry\"[^>]*>.*?<tbody>)(.*?)(</tbody>)",
    re.DOTALL,
)


_REGISTRY_STATUS_TH = (
    '<th style="width:14%;text-align:left;padding:0 16px 10px;font-size:17px;font-weight:700;'
    'color:#000;vertical-align:bottom;border-bottom:1px solid #000">Статус</th>'
)


def _fill_registry(template: str, rows: list[dict[str, str]],
                   status_by_id: dict[str, str] | None = None) -> str:
    """Заполнить таблицу реестра узлов строками.

    Заменяет содержимое ``<tbody>`` шаблона на строки из ``rows``.
    Сохраняет структуру ``<td data-col="...">`` для CSS. Столбец «Статус»
    (реализован / с ограничениями / частично / не реализован / недостаточно
    данных) добавляется кодом: в шаблоне его нет, а без него планируемый
    процесс стоит в одном ряду с работающими и отличим только по прозе.
    """
    if not rows:
        return template
    status_by_id = status_by_id or {}

    def replace_tbody(m: re.Match) -> str:
        open_tag = m.group(1)
        close_tag = m.group(3)

        col_names = ["HTML-id", "Тип", "Название", "Родитель", "Статус", "Основание"]
        col_keys = ["id", "type", "name", "parent", "status", "basis"]

        new_rows: list[str] = []
        for row in rows:
            row = {**row, "status": status_by_id.get(str(row.get("id", "")), "") or "—"}
            cells = []
            for col_name, col_key in zip(col_names, col_keys):
                val = _html.escape(str(row.get(col_key, "")), quote=False)
                cells.append(f'<td data-col="{col_name}">{val}</td>')
            new_rows.append("<tr>" + "".join(cells) + "</tr>")

        return open_tag + "\n" + "\n".join(new_rows) + "\n" + close_tag

    template = _REGISTRY_TBODY_RE.sub(replace_tbody, template, count=1)
    # Заголовок столбца — перед «Основание существования узла».
    return re.sub(
        r'(<th\b[^>]*>Основание существования узла</th>)',
        _REGISTRY_STATUS_TH + r'\1', template, count=1,
    )


# --- HTML-рендерер -----------------------------------------------------------
#
# Шаблон v3 использует <div class="node [type]" id="[type]-N"> вместо <details>.
# Линейный проход: отслеживаем текущий узел (по id на div.node) и поле
# (data-field), пропускаем HTML-комментарии.
#
# fill types:
#   name, object-id, object-version → ключ {node}:{fill} (без поля)
#   value, source                   → ключ {node}:{field}:{fill}
#   analysis-scope, decision-boundary, analysis-date → ключ {fill} (вне узлов)

# Узел: id="(journey|process|bbb|operation)-N" на любом теге.
# Поле: data-field="X.Y.Z". Заполнение: data-fill="value|source|name|...".

_TOKEN_RE = re.compile(
    r'(<!--.*?-->)'                                                  # 1: comment (skip)
    r'|(id="((?:journey|process|bbb|operation)-\d+)")'                # 2,3: node id
    r'|(data-field="([^"]+)")'                                       # 4,5: data-field
    r'|(data-fill="([^"]+)"[^>]*>)([^<]*)(</(?:div|span)>)',        # 6,7,8,9: data-fill element
    re.DOTALL,
)

_NODE_FILLS = {"name", "object-id", "object-version"}
_FIELD_FILLS = {"value", "source"}
_NODE_ID_RE = re.compile(
    r"^(?:journey|process|bbb|operation)-\d+$"
)


def _fill_template(template: str, values: dict[str, str]) -> str:
    """Заполнить data-fill элементы значениями из dict.

    Линейный проход: отслеживаем текущий узел (по id) и поле (data-field),
    пропускаем комментарии. Каждый data-fill заполняется по ключу
    {node}:{field}:{fill} или {node}:{fill} или {fill}.

    Работает с шаблоном v3, где узлы — ``<div class="node" id="X">``, а не
    ``<details>``: нет стека open/close, текущий узел обновляется при
    обнаружении нового id узла.
    """
    parts: list[str] = []
    last_end = 0
    current_node: str | None = None
    current_field: str | None = None

    for m in _TOKEN_RE.finditer(template):
        parts.append(template[last_end:m.start()])
        last_end = m.end()

        if m.group(1) is not None:
            # HTML-комментарий — пропускаем как есть
            parts.append(m.group(0))
        elif m.group(3) is not None:
            # id="journey-1" / id="process-2" и т.д. — вход в узел.
            # В v3 узлы не вкладываются через details, а идут последовательно:
            # новый id узла означает, что предыдущий закончился.
            current_node = m.group(3)
            current_field = None
            parts.append(m.group(0))
        elif m.group(5) is not None:
            # data-field="X.Y.Z"
            current_field = m.group(5)
            parts.append(m.group(0))
        elif m.group(7) is not None:
            # data-fill="..." element
            fill_type = m.group(7)
            open_tag = m.group(6)
            content = m.group(8)
            close_tag = m.group(9)
            key = _make_key(current_node, current_field, fill_type)
            val = values.get(key, "") if key else ""
            if val:
                safe = _html.escape(val, quote=False)
                parts.append(open_tag + safe + close_tag)
            else:
                parts.append(m.group(0))

    parts.append(template[last_end:])
    return "".join(parts)


def _make_key(node: str | None, field: str | None, fill: str) -> str | None:
    """Собрать ключ для values dict по контексту узла и поля."""
    if fill in _NODE_FILLS:
        return f"{node}:{fill}" if node else None
    if fill in _FIELD_FILLS:
        return f"{node}:{field}:{fill}" if node and field else None
    return fill


# --- разбор passport_data от агента ------------------------------------------
#
# Агент-матчер вызывает инструмент `submit_passport` с JSON-объектом,
# содержащим значения полей паспорта. Эти функции преобразуют его в плоский
# dict для `_fill_template` и в строки реестра.

_FIELD_MAP = {
    "journey": ["4.2.1", "4.2.2", "4.2.3", "4.2.4", "4.2.5", "4.2.6", "4.2.7", "4.2.8"],
    "process": ["4.3.1", "4.3.2", "4.3.3", "4.3.4", "4.3.5", "4.3.6", "4.3.7", "4.3.8", "4.3.9"],
    "bbb": ["4.4.1", "4.4.2", "4.4.3", "4.4.4", "4.4.5", "4.4.6", "4.4.7"],
    "operation": ["4.5.1", "4.5.2", "4.5.3", "4.5.4", "4.5.5", "4.5.6"],
}

_SAMPLE_NODES = {
    "journey-1": "journey",
    "process-1": "process",
    "bbb-1": "bbb",
    "operation-1": "operation",
}

_NODE_TYPE_PREFIXES = ("journey", "process", "bbb", "operation")


def _node_type(node_id: str) -> str:
    """Тип узла по id: journey-1 → journey, bbb-3 → bbb."""
    for prefix in _NODE_TYPE_PREFIXES:
        if node_id.startswith(prefix + "-"):
            return prefix
    return ""


def flatten_passport_data(data: dict[str, Any] | None) -> dict[str, str]:
    """Преобразовать JSON-ответ агента (``submit_passport``) в плоский dict.

    Ключи совпадают со схемой ``_fill_template``:
    - ``analysis-scope``, ``decision-boundary``, ``analysis-date``
    - ``{node}:name``, ``{node}:object-id``, ``{node}:object-version``
    - ``{node}:{field}:value``, ``{node}:{field}:source``

    Обрабатывает произвольное число узлов — агент может вернуть
    journey-1, journey-2, bbb-1, bbb-2, bbb-3 и т.д.
    """
    if not data or not isinstance(data, dict):
        return {}

    v: dict[str, str] = {}
    v["analysis-scope"] = str(data.get("analysis-scope", ""))
    v["decision-boundary"] = str(data.get("decision-boundary", ""))
    v["analysis-date"] = str(data.get("analysis-date", ""))

    nodes = data.get("nodes", {})
    if not isinstance(nodes, dict):
        return v

    for node_id, node in nodes.items():
        if not isinstance(node, dict):
            continue
        node_type = _node_type(str(node_id))
        if not node_type:
            continue
        v[f"{node_id}:name"] = str(node.get("name", ""))
        v[f"{node_id}:object-id"] = str(node.get("object-id", ""))
        v[f"{node_id}:object-version"] = str(node.get("object-version", ""))
        fields = node.get("fields", {})
        if not isinstance(fields, dict):
            continue
        for field_id in _FIELD_MAP.get(node_type, []):
            field = fields.get(field_id, {})
            if not isinstance(field, dict):
                continue
            v[f"{node_id}:{field_id}:value"] = str(field.get("value", ""))
            v[f"{node_id}:{field_id}:source"] = str(field.get("source", ""))

    return v


def passport_tree_spec(data: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Извлечь спецификацию дерева узлов из ответа агента.

    Возвращает список корневых узлов (journey), каждый может содержать
    ``children`` (process → bbb → operation). Используется ``rebuild_tree``
    для клонирования ``<template>``-заготовок.
    """
    if not data or not isinstance(data, dict):
        return []
    tree = data.get("tree")
    if isinstance(tree, list):
        return tree
    # Если tree нет, строим из nodes по известным образцам.
    nodes = data.get("nodes", {})
    if not isinstance(nodes, dict):
        return []
    tree_spec = []
    for node_id, node in nodes.items():
        if not isinstance(node, dict):
            continue
        node_type = _node_type(str(node_id))
        if node_type == "journey":
            tree_spec.append({"id": str(node_id), "type": "journey", "children": []})
    # Упрощённая сборка: процессы под первый journey, BBB под первый процесс.
    journeys = [n for n in tree_spec if n["type"] == "journey"]
    if not journeys:
        return []
    journey = journeys[0]
    processes = []
    for node_id, node in nodes.items():
        if _node_type(str(node_id)) == "process":
            processes.append({"id": str(node_id), "type": "process", "children": []})
    journey["children"] = processes
    for proc in processes:
        bbbs = []
        for node_id, node in nodes.items():
            if _node_type(str(node_id)) == "bbb":
                bbbs.append({"id": str(node_id), "type": "bbb", "children": []})
        proc["children"] = bbbs
        for bbb in bbbs:
            ops = []
            for node_id, node in nodes.items():
                if _node_type(str(node_id)) == "operation":
                    ops.append({"id": str(node_id), "type": "operation"})
            bbb["children"] = ops
        break  # только под первый BBB
    return tree_spec


def passport_registry_rows(data: dict[str, Any] | None) -> list[dict[str, str]]:
    """Строки реестра узлов из ответа агента."""
    if not data or not isinstance(data, dict):
        return []
    rows = data.get("registry", [])
    if not isinstance(rows, list):
        return []
    out: list[dict[str, str]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        out.append({
            "id": str(row.get("id", "")),
            "type": str(row.get("type", "")),
            "name": str(row.get("name", "")),
            "parent": str(row.get("parent", "")),
            "basis": str(row.get("basis", "")),
        })
    return out


# --- финализация HTML: убираем зависимость от DCLogic/support.js -------------
#
# Шаблон v3 — это DCLogic-компонент: Mustache-плейсхолдеры `{{ ... }}`,
# `style-hover` (нестандартный атрибут), внешний `support.js` и класс
# `Component extends DCLogic`. Без движка всё ломается: кнопки не работают,
# узлы не раскрываются, анимация не применяется.
#
# `_finalize_html` делает шаблон самодостаточным:
#   1. Убирает `<script src="./support.js">` и DCLogic-скрипт.
#   2. Заменяет Mustache-плейсхолдеры на статические значения.
#   3. Убирает `data-anim` / `data-uneditable` / `style-hover`.
#   4. Конвертирует `style-hover` в CSS `:hover`.
#   5. Добавляет свой `<script>` для сворачивания/разворачивания узлов.

_MUSTACHE_RE = re.compile(r"\{\{[^}]+\}\}")

# Статические значения для Mustache-плейсхолдеров. Узлы раскрыты по умолчанию
# (кроме operation и guardrail — их много, и они длинные).
_MUSTACHE_VALUES: dict[str, str] = {
    "allLabel": "Свернуть все",
    "panelRows": "0fr",
    "iconOpacity": ".65",
    "grayVal": "1",
    "grayPct": "100%",
    "oJourney": "1fr", "rJourney": "180deg",
    "oProcess": "1fr", "rProcess": "180deg",
    "oBbb": "1fr", "rBbb": "180deg",
    "oOperation": "0fr", "rOperation": "0deg",
    "oGuardrail": "0fr", "rGuardrail": "0deg",
}
# Callback-плейсхолдеры (onClick/onInput) — заменяем на пустые вызовы.
_MUSTACE_CALLBACKS = {
    "tJourney", "tProcess", "tBbb", "tOperation", "tGuardrail",
    "toggleAll", "onGray", "hidePanel", "showPanel",
}

# Раскладка отчёта — граф объектов стандарта рядами по уровням: потребность →
# клиентский путь → автономный процесс (он же сценарий) → BBB → атомарная
# операция → ограничение исполнения. Связи — плавные кривые между рядами;
# BBB и операция могут стоять в нескольких процессах и блоках, и каждая
# такая связь рисуется отдельно. Клик по объекту подсвечивает весь его
# сценарий (объекты, привязанные к тем же целевым сценариям, их родителей,
# потребность и ограничения), остальное приглушается; «Открыть описание»
# под объектом показывает карточку из шаблона в выезжающей панели.
# Карточки узлов из шаблона остаются в DOM скрытым хранилищем — JS
# клонирует их в панель. Статусы, разрывы и дефекты берутся из схемы,
# которую посчитал код.
_INLINE_CSS = """<style data-passport-fix>
[data-uneditable]{display:none!important}
#pko-store,.pko-hidden{display:none!important}
html,body{height:100%;overflow:hidden}
.pko-page{max-width:none!important;padding:0!important;margin:0!important;height:100vh;display:flex;flex-direction:column;background:#F6F8FC;color:#233247;font-size:13px}
.pko-head{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:14px 24px;border-bottom:1px solid #DCE3EC;background:#fff;flex:none;z-index:10}
.pko-head .eyebrow{font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:#748195;font-weight:700;margin-bottom:5px}
.pko-head h1{font-size:21px;font-weight:750;line-height:1.2;letter-spacing:-.02em;margin:0;color:#233247;max-width:760px}
.pko-head .pko-badge{font-size:10.5px;font-weight:700;color:#748195;letter-spacing:.03em;margin-top:5px}
.pko-metrics{display:flex;gap:28px;flex:none}
.pko-metric span{display:block;color:#748195;font-size:10px;margin-bottom:4px}
.pko-metric strong{font-size:22px;letter-spacing:-.03em;color:#233247}
.pko-metric strong.danger{color:#BA4560}
.pko-context{display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:58px;padding:9px 24px;background:#FBFCFF;border-bottom:1px solid #DCE3EC;flex:none}
.pko-context strong{font-size:12.5px}
.pko-context p{font-size:11px;color:#748195;margin:3px 0 0;line-height:1.5;max-width:940px}
.pko-context .tool{border:1px solid #DCE3EC;border-radius:6px;background:#fff;color:#68788D;padding:7px 10px;font-size:11px;cursor:pointer;font-family:inherit;white-space:nowrap}
.pko-context .tool:disabled{opacity:.5;cursor:default}
.pko-legend{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:10.5px;color:#748195;margin-top:6px}
.pko-legend i{display:inline-block;width:8px;height:8px;border-radius:2px;margin-right:4px;vertical-align:0}
.pko-legend b{display:inline-block;width:16px;height:0;border-top:2px solid #BAC6D6;vertical-align:3px;margin-right:4px}
.pko-legend .pin{display:inline-block;width:12px;height:12px;border-radius:50%;background:#BA4560;color:#fff;font-size:9px;font-weight:800;line-height:12px;text-align:center;margin-right:4px}
.pko-legend .toggle{border:1px solid #DCE3EC;border-radius:6px;background:#fff;color:#68788D;padding:2px 8px;font-size:10.5px;cursor:pointer;font-family:inherit;margin-left:2px}
.pko-legend .toggle:hover{border-color:#8B78D8}.pko-legend .toggle[aria-pressed=true]{background:#F1EDFB;border-color:#D2C7EB;color:#6246AD}
.pko-links .rel.hidden{display:none}
/* === Полотно === */
.pko-body{position:relative;flex:1;min-height:0;display:flex}
.pko-viewport{position:relative;flex:1;min-width:0;overflow:hidden;background:radial-gradient(#DCE3EC .8px,transparent .8px) 0 0/20px 20px;touch-action:none;cursor:grab;user-select:none}
.pko-viewport.dragging{cursor:grabbing}
.pko-canvas{position:absolute;top:0;left:0;transform-origin:0 0;isolation:isolate}
.pko-links{position:absolute;top:0;left:0;overflow:visible;pointer-events:none;z-index:0}
.pko-links .link{fill:none;stroke:#C3CDDB;stroke-width:1.4;transition:opacity .45s ease,stroke .3s ease,stroke-width .3s ease}
.pko-links .link.guards{stroke:#C29B78;stroke-dasharray:4 4}
.pko-links .link.addresses{stroke:#C9B48C}
.pko-links .link.rel{stroke-width:1.5;stroke-dasharray:5 4;opacity:.75}
.pko-links .link.rel.precedes{stroke:#64748B}.pko-links .link.rel.feeds{stroke:#2563EB}.pko-links .link.rel.triggers{stroke:#C2410C;stroke-dasharray:none}.pko-links .link.rel.depends_on{stroke:#7C3AED}.pko-links .link.rel.fallback{stroke:#B45309}.pko-links .link.rel.confirms{stroke:#15803D}
.pko-links .link.dim{opacity:.07}
.pko-links .link.selected{stroke:#8060C2;stroke-width:2.2;opacity:1}
.pko-links .link.rel.selected{stroke-width:2.4}
.pko-object{position:absolute;width:224px;min-height:88px;padding:9px 12px;background:#fff;border:1px solid #CFD8E5;border-top:3px solid var(--color,#A7B7C7);border-radius:8px;text-align:left;box-shadow:0 3px 10px #20304A08;color:#233247;cursor:pointer;font-family:inherit;z-index:1;transition:opacity .45s ease,border-color .3s ease,box-shadow .3s ease,background-color .3s ease}
.pko-object:hover{border-color:#7255CA;box-shadow:0 0 0 2px #DFD4F6}
.pko-object .kind{display:block;font-size:9px;letter-spacing:.05em;text-transform:uppercase;font-weight:750;color:var(--color)}
.pko-object strong{display:block;font-size:15px;line-height:1.27;margin:5px 0;overflow-wrap:anywhere;font-weight:650}
.pko-object small{display:block;font-size:10px;line-height:1.35;color:#8090A5}
.pko-object .st{display:inline-block;margin-top:5px;padding:2px 6px;border-radius:4px;font-size:9.5px;font-weight:700;background:#EEF1F6;color:#617187}
.pko-object .st.implemented{background:#E1F3EE;color:#17695C}.pko-object .st.limited{background:#FFF3CC;color:#765400}.pko-object .st.partial{background:#FFF0E2;color:#8B430C}.pko-object .st.not_implemented{background:#FAE7EC;color:#A13551}.pko-object .st.unknown{background:#EEF1F6;color:#617187}
.pko-object .st.assembled{background:#E1F3EE;color:#17695C}.pko-object .st.broken{background:#FAE7EC;color:#A13551}
.pko-object .tag{display:inline-block;margin:5px 4px 0 0;padding:1px 5px;border-radius:4px;font-size:9px;font-weight:700;letter-spacing:.03em;text-transform:uppercase;background:#F0ECFF;color:#5C45B8}
.pko-object .tag.planned{background:#FCE5EB;color:#9C1833}.pko-object .tag.shared{background:#EEF1FB;color:#3E4C9A}.pko-object .tag.branch{background:#FFF7E6;color:#8B5A00}
.pko-object.dim{opacity:.15;box-shadow:none}.pko-object.dim:hover{opacity:.75}
.pko-object.related{border-color:#B5A2D5;box-shadow:0 2px 9px #7354B414}
.pko-object.selected{border:1px solid #7255CA;border-top:3px solid #7255CA;box-shadow:0 0 0 3px #7255CA40;background:#F6F0FF}
.pko-object.inspected{outline:3px solid #E1BA67}
.pko-object[data-planned=true]{border-style:dashed}
.pko-row-title{position:absolute;font-size:10px;line-height:1.4;width:125px;color:#728096;font-weight:600;pointer-events:none}
.pko-row-title .count{display:block;font-size:20px;color:#9AA4B5;font-weight:400;margin-top:4px}
.pko-pin{position:absolute;z-index:3;border:2px solid #fff;background:#BA4560;color:#fff;border-radius:50%;width:23px;height:23px;line-height:17px;padding:0;font-size:14px;font-weight:800;box-shadow:0 1px 6px #BA456040;cursor:pointer;font-family:inherit}
.pko-pin{transition:opacity .45s ease}.pko-pin.dim{opacity:.12}.pko-pin:hover{box-shadow:0 0 0 3px #BA456030}
.pko-action{position:absolute;z-index:4;width:224px;height:27px;padding:3px 8px;font-size:12.5px;color:#6246AD;border:1px solid #B6A0DA;border-radius:6px;background:#F6F1FF;text-align:center;white-space:nowrap;box-shadow:0 2px 6px #7255CA15;cursor:pointer;font-family:inherit}
.pko-zoom{position:absolute;right:14px;top:12px;display:flex;gap:3px;align-items:center;background:#fff;border:1px solid #DCE3EC;padding:4px;border-radius:9px;z-index:2}
.pko-zoom button{border:0;background:#fff;width:32px;height:32px;color:#56687F;border-radius:5px;cursor:pointer;font-family:inherit;font-size:16px}
.pko-zoom button:hover{background:#F0ECF9}
.pko-zoom .fit{width:auto;font-size:11px;padding:0 10px}
.pko-zoom .lvl{min-width:42px;text-align:center;font-size:10px;color:#748195}
.pko-hint{position:absolute;left:14px;bottom:12px;color:#8B96A6;font-size:10px;background:#FFFFFFED;padding:6px 8px;border:1px solid #E6EAF0;border-radius:6px;pointer-events:none}
.pko-empty{position:absolute;left:50%;top:42%;transform:translate(-50%,-50%);max-width:460px;text-align:center;line-height:1.7;color:#748195}
/* === Панель описания === */
.pko-drawer{position:absolute;right:12px;top:10px;bottom:12px;width:440px;z-index:5;background:#fff;border:1px solid #D9DCEA;border-radius:12px;box-shadow:0 10px 55px #23324724;display:none;flex-direction:column;overflow:hidden}
.pko-drawer.open{display:flex}
.pko-drawer-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 18px;border-bottom:1px solid #DCE3EC;font-size:12px;font-weight:700;flex:none}
.pko-drawer-close{border:1px solid #DCE3EC;border-radius:6px;background:#fff;color:#68788D;padding:2px 9px;font-size:18px;cursor:pointer;font-family:inherit}
.pko-drawer-body{flex:1;min-height:0;overflow:auto;padding:16px 18px 28px}
.pko-drawer-body .node{border:1px solid #D8E0E6;border-radius:12px;background:#fff}
.pko-drawer-body .node .pko-collapsible{grid-template-rows:1fr!important}
.pko-drawer-body .node .children{display:none!important}
.pko-drawer-body .node>div:first-child{cursor:default}
.pko-drawer-body .field{grid-template-columns:minmax(0,1fr)!important;gap:6px 0!important}
.pko-drawer-body .identity{grid-template-columns:minmax(0,1fr)!important}
.pko-drawer-body .node-body,.pko-drawer-body .field,.pko-drawer-body .field *{overflow-wrap:anywhere;min-width:0}
.pko-links-list{display:flex;gap:8px;flex-wrap:wrap;padding:0 24px 20px;font-size:13px;color:#5A6D7C}
.pko-links-list a{color:#7C5CE6;text-decoration:none;border-bottom:1px dotted #7C5CE6;cursor:pointer}
.pko-node-assessment{margin:0 0 14px;padding:12px 14px;border:1px solid #D8E0E6;border-radius:10px;background:#F8FAFC;font-size:13px;line-height:1.5}
.pko-node-assessment .state{display:inline-block;font-weight:700;margin-bottom:5px}.pko-node-assessment ul{margin:6px 0 0;padding-left:18px}
.pko-node-flags{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 10px}
.pko-node-flags span{font-size:10px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;border-radius:5px;padding:3px 7px;background:#F0ECFF;color:#5C45B8}
.pko-node-flags span.planned{background:#FCE5EB;color:#9C1833}
.pko-node-planned-note{margin:0 0 12px;font-size:12px;color:#6D7D8A}
.pko-node-relations,.pko-node-defects,.pko-node-scenarios{margin:0 24px 20px;padding:12px 14px;border:1px solid #D8E0E6;border-radius:10px;background:#F8FAFC;font-size:13px;line-height:1.5}
.pko-node-defects{border-color:#F5C2CC;background:#FFF7F8}
.pko-node-relations .lbl,.pko-node-defects .lbl,.pko-node-scenarios .lbl{font-size:11px;font-weight:800;color:#526373;letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px}
.pko-node-defects .lbl{color:#9C1833}
.pko-node-relations ul,.pko-node-defects ul,.pko-node-scenarios ul{margin:0;padding-left:18px}.pko-node-relations li{margin-bottom:6px}
.pko-node-relations .basis{font-size:12px;color:#6D7D8A}
.pko-node-relations .kind{display:inline-block;font-size:10px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;border-radius:4px;padding:1px 6px;margin-right:4px;border:1px solid #CBD5DE;color:#334155;background:#fff}
.pko-node-scenarios .st{display:inline-block;padding:1px 6px;border-radius:4px;font-size:10px;font-weight:700;background:#EEF1F6;color:#617187;margin-left:6px}
.pko-node-scenarios .st.assembled{background:#E1F3EE;color:#17695C}.pko-node-scenarios .st.broken{background:#FAE7EC;color:#A13551}
.pko-simple{font-size:13px;line-height:1.6}
.pko-simple .type{font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:#7255CA;font-weight:700}
.pko-simple h2{font-size:19px;line-height:1.3;margin:8px 0 12px;color:#233247}
.pko-simple .src{margin-top:12px;padding:10px 12px;background:#F6F3FC;border-radius:7px;font-size:11.5px;color:#75678C}
@media(prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
"""

_INLINE_JS = """<script data-passport-fix>
(function(){
  'use strict';
  var SCHEMA=__PKO_SCHEMA__; var meta=SCHEMA.meta||{};
  var TYPE_ORDER=['need','journey','process','bbb','operation','guardrail'];
  var TYPE_NAME={need:'Потребности',journey:'Клиентский путь',process:'Автономные процессы',bbb:'BBB',operation:'Атомарные операции',guardrail:'Ограничения исполнения'};
  var TYPE_LABEL={need:'Потребность клиента',journey:'Клиентский путь',process:'Автономный процесс',bbb:'BBB',operation:'Атомарная операция',guardrail:'Ограничение исполнения'};
  var COLORS={need:'#AA8337',journey:'#9473BD',process:'#7255CA',bbb:'#3E8B94',operation:'#638A9B',guardrail:'#B3835E'};
  var SCEN_LABEL={assembled:'Собран по коду',broken:'Есть разрыв',unknown:'Не подтверждён'};
  var HIER={addresses:'закрывается путём',contains:'включает процесс',uses:'использует BBB',implements:'исполняется операцией',guards:'ограничивает'};

  // --- 1. Данные: карточки шаблона (DOM) + схема (код) ---
  var store=document.createElement('div'); store.id='pko-store';
  var els={};
  Array.prototype.forEach.call(document.querySelectorAll('.node[id]'),function(el){els[el.id]=el;});
  var byId={}, objects=[];
  function addObject(o){if(byId[o.id]) return; byId[o.id]=o; objects.push(o);}
  (SCHEMA.nodes||[]).forEach(function(n){
    addObject({id:n.id,type:n.type,name:n.name||n.id,parents:(n.parents||[]).slice(),children:[],data:n,
      steps:n.steps||[],scen:{},status:n.implementation_status||'',statusLabel:n.implementation_label||''});
  });
  objects.forEach(function(o){o.parents=o.parents.filter(function(p){return byId[p]}); o.parents.forEach(function(p){byId[p].children.push(o.id)});});
  var journey=objects.filter(function(o){return o.type==='journey'})[0]||null;
  (meta.needs||[]).forEach(function(nd){addObject({id:nd.id,type:'need',name:nd.name,text:nd.purpose||nd.text||'',source:nd.source,parents:[],children:[],targets:nd.targets||[],data:{},steps:[],scen:{}});});
  (meta.guardrails||[]).forEach(function(g){addObject({id:g.id,type:'guardrail',name:g.name,text:g.invariant||g.text||'',condition:g.condition||'',effect:g.effect_label||g.effect||'',source:g.source,parents:[],children:[],targets:g.targets||[],data:{},steps:[],scen:{}});});
  // Иерархические рёбра: один ко многим — BBB в нескольких процессах, операция в нескольких BBB.
  var edges=[];
  objects.forEach(function(o){
    if(o.type==='need') o.targets.forEach(function(t){if(byId[t]) edges.push({id:'e'+edges.length,source:o.id,target:t,type:'addresses'})});
    else if(o.type==='guardrail') o.targets.forEach(function(t){if(byId[t]) edges.push({id:'e'+edges.length,source:o.id,target:t,type:'guards'})});
    else o.parents.forEach(function(p){var pt=byId[p].type; var kind=pt==='journey'?'contains':pt==='process'?'uses':'implements'; edges.push({id:'e'+edges.length,source:p,target:o.id,type:kind});});
  });
  var relations=(SCHEMA.relations||[]).filter(function(r){return r.kind!=='includes'&&byId[r.from]&&byId[r.to]});
  var paths=SCHEMA.paths||[]; var scenById={}; paths.forEach(function(p){scenById[p.id]=p});
  var defects=SCHEMA.defects||[]; var defectById={}; defects.forEach(function(d){defectById[d.id]=d});
  // Принадлежность сценариям: узел — по шагам; предки — по потомкам.
  objects.forEach(function(o){o.steps.forEach(function(s){o.scen[s.scenario]=true})});
  function ancestors(id,out){out=out||{}; (byId[id]?byId[id].parents:[]).forEach(function(p){if(!out[p]){out[p]=true; ancestors(p,out);}}); return out;}
  function descendants(id,out){out=out||{}; (byId[id]?byId[id].children:[]).forEach(function(c){if(!out[c]){out[c]=true; descendants(c,out);}}); return out;}
  objects.forEach(function(o){ if(!Object.keys(o.scen).length) return; Object.keys(ancestors(o.id)).forEach(function(a){Object.keys(o.scen).forEach(function(s){byId[a].scen[s]=true})}); });
  objects.forEach(function(o){ if(o.type==='need'||o.type==='guardrail'){ o.targets.forEach(function(t){Object.keys((byId[t]||{scen:{}}).scen).forEach(function(s){o.scen[s]=true})}); } });
  // Разрывы: узел с разорванным стыком после него.
  var breaks={}; (SCHEMA.handoffs||[]).forEach(function(h){ if(h.result!=='broken') return; (h.from_nodes||[]).forEach(function(id){(breaks[id]=breaks[id]||[]).push(h)}); });
  var brokenCount=(SCHEMA.handoffs||[]).filter(function(h){return h.result==='broken'}).length;

  // --- 2. Страница ---
  var header=document.querySelector('header'); var page=header?header.parentElement:document.body; page.classList.add('pko-page');
  var h1=header?header.querySelector('h1'):null; var badgeEl=header?header.querySelector('div>div:last-child'):null;
  Array.prototype.slice.call(page.children).forEach(function(el){store.appendChild(el)});
  function el(tag,cls,text){var n=document.createElement(tag); if(cls) n.className=cls; if(text!=null) n.textContent=text; return n;}
  function add(parent,tag,cls,text){var n=el(tag,cls,text); parent.appendChild(n); return n;}
  function plural(n,one,few,many){return n%10===1&&n%100!==11?one:n%10>=2&&n%10<=4&&(n%100<12||n%100>14)?few:many;}
  var head=el('div','pko-head'); var hl=add(head,'div'); add(hl,'div','eyebrow','Паспорт клиентского пути'); add(hl,'h1',null,h1?h1.textContent.trim():'Паспорт');
  var legend=add(hl,'div','pko-legend');
  TYPE_ORDER.forEach(function(t){var s=add(legend,'span'); var i=add(s,'i'); i.style.background=COLORS[t]; s.appendChild(document.createTextNode(TYPE_LABEL[t]));});
  var lk=add(legend,'span'); add(lk,'b'); lk.appendChild(document.createTextNode('входит в'));
  var lr=add(legend,'span'); var lb=add(lr,'b'); lb.style.borderTopStyle='dashed'; lb.style.borderTopColor='#2563EB'; lr.appendChild(document.createTextNode('связь между объектами (вид — в карточке)'));
  var lp=add(legend,'span'); add(lp,'span','pin','!'); lp.appendChild(document.createTextNode('разрыв процесса'));
  var relToggle=add(legend,'button','toggle','скрыть связи'); relToggle.type='button'; relToggle.title='Показать или скрыть неиерархические связи между объектами'; relToggle.setAttribute('aria-pressed','false');
  var relsHidden=false;
  relToggle.addEventListener('click',function(){relsHidden=!relsHidden; relToggle.textContent=relsHidden?'показать связи':'скрыть связи'; relToggle.setAttribute('aria-pressed',String(relsHidden)); relEls.forEach(function(x){x.el.classList.toggle('hidden',relsHidden)});});
  var metrics=add(head,'div','pko-metrics');
  function metric(label,value,danger){var m=add(metrics,'div','pko-metric'); add(m,'span',null,label); add(m,'strong',danger?'danger':null,String(value));}
  metric('Процессов',objects.filter(function(o){return o.type==='process'}).length,false);
  metric('Разрывов',brokenCount,brokenCount>0);
  var context=el('div','pko-context'); var ctxText=add(context,'div'); var ctxTitle=add(ctxText,'strong'); var ctxP=add(ctxText,'p');
  var ctxActions=add(context,'div'); var resetBtn=add(ctxActions,'button','tool','Сбросить выбор'); resetBtn.type='button'; resetBtn.disabled=true;
  var body=el('div','pko-body'); var viewport=add(body,'div','pko-viewport'); viewport.tabIndex=0;
  var canvas=add(viewport,'div','pko-canvas');
  var zoomBox=add(viewport,'div','pko-zoom'); zoomBox.innerHTML='<button type="button" data-z="in" title="Приблизить">+</button><button type="button" data-z="out" title="Отдалить">−</button><span class="lvl">100%</span><button type="button" data-z="fit" class="fit">Показать весь граф</button>';
  add(viewport,'div','pko-hint','Клик — собрать процесс объекта · повторный клик или Esc — сбросить · колесо — масштаб · перетаскивание — сдвиг');
  var drawer=add(body,'aside','pko-drawer'); var dh=add(drawer,'div','pko-drawer-head'); var dTitle=add(dh,'span',null,'Описание объекта'); var dClose=add(dh,'button','pko-drawer-close','×'); dClose.type='button'; var dBody=add(drawer,'div','pko-drawer-body');
  page.appendChild(head); page.appendChild(context); page.appendChild(body); page.appendChild(store);

  // --- 3. Раскладка рядами по уровням; при выборе — перестроение ---
  // Карточки создаются один раз; положение задаёт layout(scope): без выбора
  // ряды центрированы, потомки под родителями; при выборе объекты его
  // сценария съезжают влево и выстраиваются под своими родителями, остальные
  // уезжают вправо за разрыв. Перестроение анимируется, рёбра пересчитываются
  // на каждом кадре — линии остаются гладкими кривыми без подписей.
  var positions={}, buttons={}, pins=[], svg=null, sceneW=1, sceneH=1, actionBtn=null;
  var edgeEls=[], relEls=[], rowsData=[], anim=null;
  var CARD=224, GAP=22, LABEL=142, OUTER=22, ROWGAP=40, SPLIT=110;
  function bary(o,prevPos){ var refs=o.type==='need'||o.type==='guardrail'?o.targets:o.parents; var xs=refs.map(function(p){return prevPos[p]}).filter(function(v){return v!=null}); return xs.length?xs.reduce(function(a,b){return a+b},0)/xs.length:null; }
  function orderRow(list,prevPos){
    var key={}; list.forEach(function(o,i){ var b=bary(o,prevPos); key[o.id]=b==null?1e9+i:b; });
    return list.slice().sort(function(a,b){return key[a.id]-key[b.id]||a.id.localeCompare(b.id,undefined,{numeric:true})});
  }
  function computeLayout(scopeIds){
    var target={}; var prevPos={}; var full=LABEL+OUTER;
    rowsData.forEach(function(row){
      var list=row.nodes;
      if(!scopeIds){
        var ordered=orderRow(list,prevPos); var start=full+(sceneW-LABEL-OUTER*2-(ordered.length*(CARD+GAP)-GAP))/2;
        ordered.forEach(function(o,i){target[o.id]=start+i*(CARD+GAP)});
      } else {
        var inn=orderRow(list.filter(function(o){return scopeIds[o.id]}),prevPos), out=orderRow(list.filter(function(o){return !scopeIds[o.id]}),prevPos);
        inn.forEach(function(o,i){target[o.id]=full+i*(CARD+GAP)});
        var x0=full+(inn.length?inn.length*(CARD+GAP)-GAP+SPLIT:0);
        out.forEach(function(o,i){target[o.id]=x0+i*(CARD+GAP)});
      }
      var rowPos={}; list.forEach(function(o){rowPos[o.id]=target[o.id]}); prevPos=rowPos;
    });
    return target;
  }
  function statusChip(o){
    var st=null;
    if(o.type==='process'){ var ss=Object.keys(o.scen).map(function(s){return scenById[s]}).filter(Boolean); if(ss.length){var broken=ss.filter(function(s){return s.status==='broken'}).length; var ok=ss.filter(function(s){return s.status==='assembled'}).length; var state=broken?'broken':ok===ss.length?'assembled':'unknown'; st=el('span','st '+state,SCEN_LABEL[state]+(broken>1?' · разрывов '+broken:'')); } }
    if(!st&&o.status){ st=el('span','st '+o.status,o.statusLabel||o.status); }
    return st;
  }
  function svgEl(tag,attrs){var n=document.createElementNS('http://www.w3.org/2000/svg',tag); Object.keys(attrs||{}).forEach(function(k){n.setAttribute(k,attrs[k])}); return n;}
  function render(){
    canvas.innerHTML=''; positions={}; buttons={}; pins=[]; edgeEls=[]; relEls=[]; rowsData=[];
    svg=document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('class','pko-links'); canvas.appendChild(svg);
    var defs=svgEl('defs'); svg.appendChild(defs);
    ['precedes','feeds','triggers','depends_on','fallback','confirms'].forEach(function(k){var m=svgEl('marker',{id:'pko-m-'+k,viewBox:'0 0 12 12',refX:'11',refY:'6',markerWidth:'9',markerHeight:'9',markerUnits:'userSpaceOnUse',orient:'auto'}); var p=svgEl('path',{d:'M1,2 L11,6 L1,10 L3.5,6 z','stroke-linejoin':'round'}); p.setAttribute('fill',{precedes:'#64748B',feeds:'#2563EB',triggers:'#C2410C',depends_on:'#7C3AED',fallback:'#B45309',confirms:'#15803D'}[k]); m.appendChild(p); defs.appendChild(m);});
    var y=18;
    TYPE_ORDER.forEach(function(t){ var list=objects.filter(function(o){return o.type===t}); if(list.length) rowsData.push({type:t,nodes:list}); });
    sceneW=Math.max.apply(null,[1].concat(rowsData.map(function(r){return r.nodes.length})))*(CARD+GAP)-GAP+LABEL+OUTER*2+SPLIT;
    rowsData.forEach(function(row){
      var lab=add(canvas,'div','pko-row-title',TYPE_NAME[row.type]); lab.style.left=OUTER+'px'; lab.style.top=(y+12)+'px'; add(lab,'span','count',String(row.nodes.length));
      var maxH=0;
      row.nodes.forEach(function(o){
        var b=add(canvas,'button','pko-object'); b.type='button'; b.dataset.id=o.id; b.dataset.type=o.type; b.style.setProperty('--color',COLORS[o.type]); b.style.top=y+'px'; b.style.left='0px';
        add(b,'span','kind',TYPE_LABEL[o.type]); add(b,'strong',null,o.name);
        // На карточке — только статус; все прочие метки живут в описании объекта.
        var d=o.data||{}; if(d.planned) b.dataset.planned='true';
        var chip=statusChip(o); if(chip) b.appendChild(chip);
        b.title=o.name; b.addEventListener('click',function(e){if(!moved||e.detail===0) selectObject(o.id);});
        buttons[o.id]=b; positions[o.id]={x:0,y:y,w:CARD,h:b.offsetHeight}; maxH=Math.max(maxH,b.offsetHeight);
      });
      y+=maxH+ROWGAP;
    });
    sceneH=y+20; canvas.style.width=sceneW+'px'; canvas.style.height=sceneH+'px'; svg.setAttribute('width',sceneW); svg.setAttribute('height',sceneH);
    edges.forEach(function(e){ var p=svgEl('path',{'class':'link '+e.type}); p.dataset.edge=e.id; var t=svgEl('title'); t.textContent=HIER[e.type]||e.type; p.appendChild(t); svg.appendChild(p); edgeEls.push({e:e,el:p}); });
    relations.forEach(function(r,i){ var p=svgEl('path',{'class':'link rel '+r.kind+(relsHidden?' hidden':''),'marker-end':'url(#pko-m-'+r.kind+')'}); p.dataset.rel=String(i); var t=svgEl('title'); t.textContent=(r.kind_label||r.kind)+': «'+byId[r.from].name+'» → «'+byId[r.to].name+'»'; p.appendChild(t); svg.appendChild(p); relEls.push({r:r,i:i,el:p}); });
    if(!objects.length){var msg=add(canvas,'div','pko-empty','Объекты паспорта не собраны.'); msg.style.width='450px'; sceneW=600; sceneH=400;}
    Object.keys(breaks).forEach(function(id){ if(!positions[id]) return; var b=add(canvas,'button','pko-pin','!'); b.type='button'; var titles=breaks[id].map(function(h){return h.scenario_title}); b.title='Разрыв: '+titles.filter(function(v,i,a){return a.indexOf(v)===i}).join(', '); b.addEventListener('click',function(e){e.stopPropagation(); if(moved&&e.detail!==0) return; showBreaks(id);}); pins.push({id:id,button:b}); });
    var t0=computeLayout(null); Object.keys(t0).forEach(function(id){positions[id].x=t0[id]}); place(); selection(); requestAnimationFrame(fit);
  }
  function edgePath(e){
    var a=positions[e.source], b=positions[e.target]; if(!a||!b) return '';
    var x1=a.x+a.w/2, y1=a.y+a.h, x2=b.x+b.w/2, y2=b.y;
    if(e.type==='guards'){ var top=a.y<b.y?a:b, bottom=a.y<b.y?b:a; var lane=Math.max(top.x+top.w,bottom.x+bottom.w)+14; return 'M'+(top.x+top.w)+','+(top.y+top.h/2)+' C'+lane+','+(top.y+top.h/2)+' '+lane+','+(bottom.y+bottom.h/2)+' '+(bottom.x+bottom.w)+','+(bottom.y+bottom.h/2); }
    var mid=(y1+y2)/2; return 'M'+x1+','+y1+' C'+x1+','+mid+' '+x2+','+mid+' '+x2+','+y2;
  }
  function relPath(r,i){
    var a=positions[r.from], b=positions[r.to]; if(!a||!b) return '';
    if(Math.abs(a.y-b.y)<8){ var ltr=a.x<b.x; var x1=a.x+a.w*(ltr?.7:.3), x2=b.x+b.w*(ltr?.3:.7), yy=a.y, h=26+(i%3)*6; return 'M'+x1+','+yy+' C'+x1+','+(yy-h)+' '+x2+','+(yy-h)+' '+x2+','+yy; }
    var down=b.y>a.y; var sx=a.x+a.w/2, sy=down?a.y+a.h:a.y, tx2=b.x+b.w/2, ty2=down?b.y:b.y+b.h; var mid=(sy+ty2)/2; return 'M'+sx+','+sy+' C'+sx+','+mid+' '+tx2+','+mid+' '+tx2+','+ty2;
  }
  function place(){
    Object.keys(buttons).forEach(function(id){buttons[id].style.left=positions[id].x+'px'});
    edgeEls.forEach(function(x){x.el.setAttribute('d',edgePath(x.e))}); relEls.forEach(function(x){x.el.setAttribute('d',relPath(x.r,x.i))});
    pins.forEach(function(p){var pos=positions[p.id]; p.button.style.left=(pos.x-9)+'px'; p.button.style.top=(pos.y-8)+'px';});
    if(actionBtn&&focus&&positions[focus]){actionBtn.style.left=positions[focus].x+'px'; actionBtn.style.top=(positions[focus].y+positions[focus].h+6)+'px';}
  }
  function layout(scopeIds){
    var target=computeLayout(scopeIds); var from={}; Object.keys(positions).forEach(function(id){from[id]=positions[id].x});
    if(anim) cancelAnimationFrame(anim);
    var t0=performance.now(), dur=window.matchMedia('(prefers-reduced-motion: reduce)').matches?0:700;
    function frame(now){
      var k=dur?Math.min(1,(now-t0)/dur):1; var e=ease(k);
      Object.keys(target).forEach(function(id){positions[id].x=from[id]+(target[id]-from[id])*e});
      place(); if(k<1) anim=requestAnimationFrame(frame); else anim=null;
    }
    anim=requestAnimationFrame(frame);
    if(scopeIds) fitTo(scopeIds,target); else fit(true);
  }
  // Камера наводится на собранную группу: по её габаритам, не крупнее 100%.
  function fitTo(scopeIds,target){
    var minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
    Object.keys(scopeIds).forEach(function(id){var p=positions[id]; if(!p) return; var x=target?target[id]:p.x; minX=Math.min(minX,x); maxX=Math.max(maxX,x+p.w); minY=Math.min(minY,p.y); maxY=Math.max(maxY,p.y+p.h);});
    if(!isFinite(minX)) return;
    var pad=60, w=maxX-minX+pad*2, h=maxY-minY+pad*2;
    var next=Math.max(.2,Math.min(1,(viewport.clientWidth-460)/w,(viewport.clientHeight-40)/h));
    animateCamera(next,(viewport.clientWidth-460-w*next)/2-(minX-pad)*next,Math.max(12,(viewport.clientHeight-h*next)/2-(minY-pad)*next));
  }
  // Плавность: ease-in-out (квинтика) — без рывка в начале и в конце.
  function ease(k){return k<.5?16*k*k*k*k*k:1-Math.pow(-2*k+2,5)/2;}
  var camAnim=null;
  function animateCamera(ns,ntx,nty){
    if(camAnim) cancelAnimationFrame(camAnim);
    var s0=scale,x0=tx,y0=ty,t0=performance.now(),dur=window.matchMedia('(prefers-reduced-motion: reduce)').matches?0:600;
    function frame(now){var k=dur?Math.min(1,(now-t0)/dur):1; var e=ease(k); scale=s0+(ns-s0)*e; tx=x0+(ntx-x0)*e; ty=y0+(nty-y0)*e; apply(); if(k<1) camAnim=requestAnimationFrame(frame); else camAnim=null;}
    camAnim=requestAnimationFrame(frame);
  }

  // --- 4. Выбор: весь сценарий объекта ---
  var focus=null, moved=false;
  // Процесс = сценарий: область выбора — процессы, в которые объект входит,
  // и всё их содержимое; у пути — все процессы, у BBB до развилки — те,
  // которые он запускает.
  function processesOf(id){
    var out={}; var o=byId[id]; if(!o) return out;
    if(o.type==='process'){out[id]=true; return out;}
    if(o.type==='journey'){objects.forEach(function(x){if(x.type==='process') out[x.id]=true}); return out;}
    if(o.type==='need'||o.type==='guardrail'){o.targets.forEach(function(t){Object.keys(processesOf(t)).forEach(function(k){out[k]=true})}); return out;}
    Object.keys(ancestors(id)).forEach(function(a){if(byId[a].type==='process') out[a]=true});
    if(o.data&&o.data.before_fork) relations.forEach(function(r){if(r.from===id&&r.kind==='triggers'&&byId[r.to]&&byId[r.to].type==='process') out[r.to]=true});
    return out;
  }
  function scope(id){
    var o=byId[id]; var ids={}; ids[id]=true; var procs=processesOf(id);
    Object.keys(procs).forEach(function(p){ ids[p]=true; Object.keys(descendants(p)).forEach(function(c){ids[c]=true}); Object.keys(ancestors(p)).forEach(function(a){ids[a]=true}); });
    Object.keys(ancestors(id)).forEach(function(a){ids[a]=true});
    if(o.type==='need'||o.type==='guardrail') o.targets.forEach(function(t){ids[t]=true; Object.keys(ancestors(t)).forEach(function(a){ids[a]=true});});
    if(o.type==='journey'||!Object.keys(procs).length) Object.keys(descendants(id)).forEach(function(c){ids[c]=true});
    objects.forEach(function(x){ if((x.type==='need'||x.type==='guardrail')&&x.targets.some(function(t){return ids[t]})) ids[x.id]=true; });
    var edgeSet={}; edges.forEach(function(e){ if(ids[e.source]&&ids[e.target]) edgeSet[e.id]=true; });
    var relSet={}; relations.forEach(function(r,i){ if(ids[r.from]&&ids[r.to]) relSet[i]=true; });
    return {ids:ids,edges:edgeSet,rels:relSet,procs:procs};
  }
  function selection(){
    var sc=focus?scope(focus):null;
    Object.keys(buttons).forEach(function(id){var b=buttons[id]; b.classList.toggle('dim',!!sc&&!sc.ids[id]); b.classList.toggle('related',!!sc&&!!sc.ids[id]&&id!==focus); b.classList.toggle('selected',focus===id);});
    edgeEls.forEach(function(x){ var active=sc&&sc.edges[x.e.id]; x.el.classList.toggle('dim',!!sc&&!active); x.el.classList.toggle('selected',!!sc&&!!active); });
    relEls.forEach(function(x){ var active=sc&&sc.rels[x.i]; x.el.classList.toggle('dim',!!sc&&!active); x.el.classList.toggle('selected',!!sc&&!!active); });
    pins.forEach(function(p){p.button.classList.toggle('dim',!!sc&&!sc.ids[p.id])});
    resetBtn.disabled=!focus;
    if(actionBtn){actionBtn.remove(); actionBtn=null;}
    if(!focus){ ctxTitle.textContent=objects.length?'Выберите любой объект на графе':'Объектная модель не собрана'; ctxP.textContent='Ряды — уровни стандарта: потребность, клиентский путь, автономный процесс, BBB, атомарная операция, ограничение исполнения. Линии — вхождение объекта в родителя; общие BBB и операции связаны с каждым родителем. Клик по объекту собирает его процесс слева, остальное уходит вправо.'; layout(null); return; }
    var o=byId[focus]; var n=Object.keys(sc.procs).length;
    ctxTitle.textContent=o.name; ctxP.textContent=TYPE_LABEL[o.type]+(o.type!=='process'&&n?' · '+n+' '+plural(n,'процесс','процесса','процессов'):'')+' · объекты процесса собраны слева'+(breaks[focus]?' · есть разрыв после этого объекта':'');
    actionBtn=add(canvas,'button','pko-action','Открыть описание →'); actionBtn.type='button'; actionBtn.addEventListener('click',function(e){e.stopPropagation(); if(moved&&e.detail!==0) return; showObject(focus);});
    layout(sc.ids);
  }
  function selectObject(id){ if(!byId[id]) return; if(focus===id){reset(); return;} focus=id; closeDrawer(); selection(); history.replaceState(null,'',location.pathname+location.search+'#'+encodeURIComponent(id)); }
  function reset(){ focus=null; closeDrawer(); selection(); history.replaceState(null,'',location.pathname+location.search); }

  // --- 5. Описание объекта ---
  function link(id){var a=el('a',null,byId[id]?byId[id].name:id); a.addEventListener('click',function(){selectObject(id); showObject(id);}); return a;}
  function openDrawer(title){dTitle.textContent=title; dBody.innerHTML=''; drawer.classList.add('open'); Object.keys(buttons).forEach(function(k){buttons[k].classList.remove('inspected')});}
  function closeDrawer(){drawer.classList.remove('open'); Object.keys(buttons).forEach(function(k){buttons[k].classList.remove('inspected')});}
  function showObject(id){
    var o=byId[id]; if(!o) return; openDrawer('Описание объекта'); if(buttons[id]) buttons[id].classList.add('inspected');
    if(o.type==='need'||o.type==='guardrail'){
      var box=add(dBody,'div','pko-simple'); add(box,'div','type',TYPE_LABEL[o.type]); add(box,'h2',null,o.name);
      if(o.type==='guardrail'){ add(box,'p',null,'Что защищаем: '+(o.text||'—')); add(box,'p',null,'Когда срабатывает: '+(o.condition||'—')); add(box,'p',null,'Эффект: '+(o.effect||'—')); }
      else add(box,'p',null,o.text||'');
      if(o.source) add(box,'div','src','Основание · '+o.source);
      var tl=add(box,'p',null,(o.type==='need'?'Закрывается: ':'Ограничивает: ')); o.targets.forEach(function(t,i){if(i) tl.appendChild(document.createTextNode(', ')); tl.appendChild(link(t));});
      return;
    }
    var src=els[id]; if(!src){add(dBody,'p',null,o.name); return;}
    var clone=src.cloneNode(true); clone.removeAttribute('id'); clone.classList.remove('collapsed'); clone.removeAttribute('data-anim');
    var chead=clone.firstElementChild; if(chead){chead.removeAttribute('onClick'); chead.removeAttribute('onclick'); var arrow=chead.querySelector('svg'); if(arrow&&arrow.parentElement) arrow.parentElement.style.display='none';}
    var grid=chead?chead.nextElementSibling:null; if(grid){grid.classList.add('pko-collapsible'); grid.style.gridTemplateRows='1fr';}
    Array.prototype.forEach.call(clone.querySelectorAll('.children'),function(c){c.parentNode.removeChild(c)});
    var d=o.data||{};
    if(d.planned){ var allowed=(meta.planned_fields||{})[o.type]||[]; Array.prototype.forEach.call(clone.querySelectorAll('[data-field]'),function(f){ if(allowed.indexOf(f.getAttribute('data-field'))<0) f.parentNode.removeChild(f); }); }
    var assessment=el('div','pko-node-assessment'); var flags=el('div','pko-node-flags');
    if(d.before_fork) add(flags,'span',null,'до развилки · выполняется до выбора процесса');
    if(o.parents.length>1) add(flags,'span',null,'общий узел · родителей: '+o.parents.length);
    if(d.planned) add(flags,'span','planned','в коде нет · планируется');
    if(d.branching&&d.branching!=='sequence') add(flags,'span',null,d.branching_label||d.branching);
    if(flags.childNodes.length) assessment.appendChild(flags);
    add(assessment,'div','state',d.implementation_label||'Недостаточно данных');
    if(d.readiness!=null) add(assessment,'div',null,'Полнота узла: '+d.readiness+'%');
    if(Array.isArray(d.problems)&&d.problems.length){var ul=add(assessment,'ul'); d.problems.forEach(function(p){add(ul,'li',null,p)});}
    if(d.planned) add(assessment,'div','pko-node-planned-note','Поля режимов исполнения, fallback, handoff, контрактов и компенсации у планируемого узла не заполняются: они описывали бы поведение кода, которого нет.');
    clone.insertBefore(assessment,clone.firstChild);
    var links=el('div','pko-links-list');
    function list(label,ids){ if(!ids.length) return; links.appendChild(document.createTextNode(label)); ids.forEach(function(c,i){if(i) links.appendChild(document.createTextNode(', ')); links.appendChild(link(c));}); }
    list(o.parents.length>1?'Родители ('+o.parents.length+'): ':'Родитель: ',o.parents); list(' · Дети: ',o.children); clone.appendChild(links);
    if(o.type==='bbb'||o.type==='operation'){ var ps=Object.keys(processesOf(o.id)); if(ps.length){ var sbox=el('div','pko-node-scenarios'); add(sbox,'div','lbl','Процессы'); var sul=add(sbox,'ul'); ps.forEach(function(pid){var li=add(sul,'li'); li.appendChild(link(pid)); var chip=statusChip(byId[pid]); if(chip) li.appendChild(chip);}); clone.appendChild(sbox); } }
    var rels=relations.filter(function(r){return r.from===id||r.to===id});
    if(rels.length){ var rbox=el('div','pko-node-relations'); add(rbox,'div','lbl','Связи'); var rul=add(rbox,'ul'); rels.forEach(function(r){var li=add(rul,'li'); add(li,'span','kind '+r.kind,r.kind_label||r.kind); if(r.from===id){li.appendChild(document.createTextNode('→ ')); li.appendChild(link(r.to));} else {li.appendChild(link(r.from)); li.appendChild(document.createTextNode(' → этот объект'));} if(r.field) add(li,'div','basis','поле состояния: '+r.field); if(r.basis) add(li,'div','basis',r.basis);}); clone.appendChild(rbox); }
    var dfs=(d.defects||[]).map(function(x){return defectById[x]}).filter(Boolean);
    if(dfs.length){ var dbox=el('div','pko-node-defects'); add(dbox,'div','lbl','Дефекты'); var dul=add(dbox,'ul'); dfs.forEach(function(df){var li=add(dul,'li',null,df.title+(df.blocking?' — блокирует':'')+(df.where?' · '+df.where:''));}); clone.appendChild(dbox); }
    dBody.appendChild(clone); dBody.scrollTop=0;
  }
  function showBreaks(id){
    openDrawer('Разрыв процесса'); var box=add(dBody,'div','pko-simple'); add(box,'div','type','После объекта'); add(box,'h2',null,byId[id].name);
    (breaks[id]||[]).forEach(function(h){
      var p=add(box,'p'); add(p,'strong',null,h.scenario_title+(h.critical?' · критический процесс':'')); p.appendChild(document.createElement('br'));
      p.appendChild(document.createTextNode('Переход «'+h.from_step+'» → «'+h.to_step+'»'));
      var ul=add(box,'ul'); (h.checks||[]).forEach(function(c){ if(c.result==='broken'){ add(ul,'li',null,c.check_label+': '+c.result_label+(c.note?' — '+c.note:'')+((c.links||[]).length?' · '+c.links.map(function(l){return l.path+(l.line?':'+l.line:'')}).join(', '):'')); } });
    });
    var dfs=defects.filter(function(df){return df.nodes.indexOf(id)>=0}); if(dfs.length){ add(box,'div','type','Дефекты'); var dul=add(box,'ul'); dfs.forEach(function(df){add(dul,'li',null,df.title+(df.blocking?' — блокирует':''))}); }
    var b=add(box,'button','tool','Открыть описание объекта'); b.type='button'; b.style.marginTop='12px'; b.addEventListener('click',function(){showObject(id)});
  }

  // --- 6. Масштаб и панорама ---
  var scale=1,tx=0,ty=0,drag=null;
  function apply(){canvas.style.transform='translate('+tx+'px,'+ty+'px) scale('+scale+')'; zoomBox.querySelector('.lvl').textContent=Math.round(scale*100)+'%';}
  function fit(smooth){ if(!viewport.clientWidth) return; var ns=Math.max(.2,Math.min(1,(viewport.clientWidth-24)/sceneW,(viewport.clientHeight-60)/sceneH)); var ntx=(viewport.clientWidth-sceneW*ns)/2, nty=Math.max(12,(viewport.clientHeight-48-sceneH*ns)/2); if(smooth===true){animateCamera(ns,ntx,nty); return;} scale=ns; tx=ntx; ty=nty; apply(); }
  function zoom(f,x,y){var next=Math.max(.15,Math.min(2.6,scale*f)); tx=x-(x-tx)*next/scale; ty=y-(y-ty)*next/scale; scale=next; apply();}
  viewport.addEventListener('wheel',function(e){e.preventDefault(); var r=viewport.getBoundingClientRect(); zoom(Math.exp(-e.deltaY*.0015),e.clientX-r.left,e.clientY-r.top);},{passive:false});
  viewport.addEventListener('pointerdown',function(e){ if(e.button!==0||e.target.closest('.pko-zoom')) return; drag={x:e.clientX,y:e.clientY,tx:tx,ty:ty}; moved=false; });
  window.addEventListener('pointermove',function(e){ if(!drag) return; var dx=e.clientX-drag.x, dy=e.clientY-drag.y; if(Math.abs(dx)+Math.abs(dy)>5) moved=true; if(moved){viewport.classList.add('dragging'); tx=drag.tx+dx; ty=drag.ty+dy; apply();} });
  window.addEventListener('pointerup',function(){ drag=null; viewport.classList.remove('dragging'); setTimeout(function(){moved=false},0); });
  window.addEventListener('pointercancel',function(){drag=null; moved=false; viewport.classList.remove('dragging');});
  viewport.addEventListener('click',function(e){ if(!moved&&!e.target.closest('button')&&focus) reset(); });
  zoomBox.addEventListener('click',function(e){var b=e.target.closest('button'); if(!b) return; if(b.dataset.z==='fit') fit(); else zoom(b.dataset.z==='in'?1.2:1/1.2,viewport.clientWidth/2,viewport.clientHeight/2);});
  window.addEventListener('resize',fit);
  resetBtn.addEventListener('click',reset); dClose.addEventListener('click',closeDrawer);
  document.addEventListener('keydown',function(e){ if(e.key==='Escape'){ if(drawer.classList.contains('open')) closeDrawer(); else reset(); } });
  render();
  var initial=decodeURIComponent(location.hash.slice(1)); if(byId[initial]){focus=initial; selection();}
})();
</script>
"""


def _finalize_html(html: str, schema: dict[str, Any] | None = None) -> str:
    """Сделать HTML самодостаточным: убрать DCLogic, заменить Mustache, добавить JS.

    Шаблон v3 рассчитан на внешний движок DCLogic (`support.js`). В
    статичном файле паспорта этого движка нет — функция убирает зависимость
    и добавляет собственный минималистичный JS.
    """
    # 1. Убираем внешний скрипт support.js и DCLogic-блок.
    html = re.sub(r'<script\s+src="./support\.js">\s*</script>', '', html)
    html = re.sub(
        r'<script type="text/x-dc"[^>]*>.*?</script>',
        '', html, flags=re.DOTALL,
    )

    # 2. Заменяем Mustache-плейсхолдеры.
    def replace_mustache(m: re.Match) -> str:
        key = m.group(0).strip("{} ").strip()
        if key in _MUSTACE_CALLBACKS:
            return ""  # onClick="{{ tJourney }}" → onClick=""
        return _MUSTACHE_VALUES.get(key, "")

    html = _MUSTACHE_RE.sub(replace_mustache, html)

    # 3. Убираем data-anim (анимация не нужна в статике).
    html = re.sub(r'\s+data-anim\b', '', html)

    # 4. Убираем style-hover (нестандартный атрибут) — hover в CSS.
    html = re.sub(r'\s+style-hover="[^"]*"', '', html)

    # 6. Убираем упоминания параграфов стандарта из видимых элементов.
    #    «§ 4.2.1», «§ 4.2 · 8 полей», «(§ 3.2.1)», «§§ 3.2, 4.0–4.6» и т.д.
    #    В заголовках полей: «<span ...>§ 4.2.1</span>» → убираем span целиком.
    html = re.sub(
        r'<span[^>]*>§+\s*[\d.,–-]*</span>',
        '', html,
    )
    # Footer с упоминанием стандарта целиком.
    html = re.sub(
        r'Источник:\s*Стандарт автономного процесса[^<]*',
        '', html,
    )
    # В тексте заголовков узлов: «§ 4.2 · 8 полей» → «8 полей»
    html = re.sub(r'§+\s*[\d.]+\s*·\s*', '', html)
    # Одиночные «§ 4.5», «§§ 3.2», «§ 4.0» в видимом тексте.
    html = re.sub(r'§+\s*[\d.,–-]+', '', html)

    # 7. Добавляем CSS и JS перед </body>.
    script = _INLINE_JS.replace("__PKO_SCHEMA__", nodes_json(schema or {"nodes": [], "paths": [], "relations": []}), 1)
    inject = _INLINE_CSS + "\n" + script
    html = html.replace("</body>", inject + "\n</body>", 1)

    return html

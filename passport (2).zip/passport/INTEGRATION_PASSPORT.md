# Инструкция: интеграция заполнения паспорта клиентского пути в агента

## Что это

Интеграция позволяет агенту-матчеру (который анализирует код и оценивает
готовность инициативы) заполнять **паспорт клиентского пути** — HTML-файл по
шаблону `passport-dpss-v3.html` — в той же сессии, без отдельного LLM-вызова.

Агент анализирует код инструментами (`list_files`, `read_file`, `search`,
`who_calls`, `show_facts`), оценивает этапы (`submit_stage`), выносит вердикт
(`submit_summary`) и завершает сессию (`finish`). Паспорт собирает вторая
сессия — паспортный агент — по знаниям первой, без повторного чтения кода.

## Изменённые файлы

| Файл | Что изменилось |
|---|---|
| `backend/pko/progress/matcher.py` | Копит `knowledge` — сводки выводов репозиторных инструментов — и отдаёт через `AgentResult.knowledge` |
| `backend/pko/progress/passport_agent.py` | Паспортная сессия: `submit_node` / `declare_children` / `finish`, очередь DFS, поузловой гейт, сборка `passport_data` |
| `backend/pko/progress/passport_gate.py` | Проверки узлов и `normalize_passport` (нумерация, `object-id`, реестр) |
| `backend/pko/progress/passport_system.md` | Промпт паспортного агента |
| `backend/pko/progress/pipeline.py` | `passport_data` передаётся из `AgentResult` в `ProgressModel` |
| `backend/pko/progress/schema.py` | Поле `passport_data` в `ProgressModel`; сериализация в `to_dict()`/`to_json()` |
| `backend/pko/progress/agent_system.md` | Паспорт из сессии оценки убран; агенту сказано, что его ссылки и `note` — вход паспортного агента |
| `backend/pko/render/client_journey_passport.py` | Переключён на шаблон `passport-dpss-v3.html`; рендерер переписан под `<div>`-структуру v3 (вместо `<details>`); добавлены: `_insert_extra_nodes` (клонирование `<template>`-заготовок для новых узлов), `flatten_passport_data`, `passport_registry_rows`, `passport_tree_spec`, `_fill_registry`, `_strip_comments` |
| `backend/pko/cli.py` | В `_cmd_progress` паспорт берёт `passport_data` из модели (не отдельный LLM-вызов); передаёт `tree_spec` в рендерер |
| `passport-dpss-v3.html` | Новый шаблон паспорта v3 (режим «только код», `<template>`-библиотека, `data-fill`/`data-field`/`data-children`) |
| `instrukciya-zapolneniya-pasporta-v3.md` | Инструкция по заполнению v3 — уровни обоснования, правила реконструкции из кода |

## Как встроить в новый проект

### 1. Скопировать файлы

```
passport-dpss-v3.html              → корень проекта
instrukciya-zapolneniya-pasporta-v3.md → корень проекта
backend/pko/render/client_journey_passport.py → рендерер
backend/pko/progress/matcher.py    → агент (если уже есть — смерджить)
backend/pko/progress/pipeline.py   → пайплайн
backend/pko/progress/schema.py     → модель данных
backend/pko/progress/agent_system.md → системный промпт
backend/pko/cli.py                 → CLI
```

### 2. Проверить путь к шаблону

В `client_journey_passport.py`:

```python
_TEMPLATE_PATH = Path(__file__).resolve().parents[3] / "passport-dpss-v3.html"
```

`parents[3]` — это корень проекта (3 уровня вверх от `backend/pko/render/`).
Если структура другая — поправить путь.

### 3. Добавить инструмент в сессию агента

В `matcher.py`:

В сессии оценки паспортных инструментов нет. `matcher._answer_call`
копит `state.knowledge` — сводки выводов репозиторных инструментов; они
уходят наружу через `AgentResult.knowledge`. Паспорт собирает
`passport_agent.run_passport_agent` (схемы `submit_node`,
`declare_children`, `finish`), который вызывает `pipeline._run_progress`
сразу после `run_agent`.

### 4. Провести passport_data через цепочку

```
run_agent → AgentResult.knowledge
  → run_passport_agent(...) → PassportAgentResult.passport_data
    → ProgressModel.passport_data (pipeline.py)
      → render_client_journey_passport(model.passport_data)
```

### 5. Рендеринг в CLI

```python
from pko.render.client_journey_passport import (
    flatten_passport_data,
    passport_registry_rows,
    passport_tree_spec,
)
llm_vals = flatten_passport_data(model.passport_data)  # если есть
reg_rows = passport_registry_rows(model.passport_data)
tree_spec = passport_tree_spec(model.passport_data)
cj_html = render_client_journey_passport(
    model, plan_input, name, target.extraction,
    commit=target.sha, branch=target.branch,
    llm_values=llm_vals, registry_rows=reg_rows, tree_spec=tree_spec,
)
```

## Как это работает

### Две сессии

```
Сессия оценки (matcher.run_agent)
  submit_stage → submit_review → submit_summary → finish
  + AgentResult.knowledge — сжатый след прочитанного (_summarize_tool_result)
        ↓
Паспортная сессия (passport_agent.run_passport_agent) — по коду не ходит
  submit_node(journey-1) → declare_children(journey-1)
  → submit_node(process-1) → declare_children(process-1)
  → submit_node(bbb-1) → declare_children(bbb-1) → submit_node(operation-1) …
  → submit_node(need-1, journeys=[…]) → submit_node(guardrail-1, scope=[…]) → finish
        ↓
normalize_passport → ProgressModel.passport_data → render_client_journey_passport
```

Вход паспортного агента — карта возможностей, вердикты с подтверждёнными
ссылками и след прочитанного; инструментов репозитория у него нет.
Очередь узлов ведёт код (обход в глубину), id выдаёт код, в каждом ответе —
карта построенного. Дети промежуточных узлов обязательны и объявляются
следующим шагом после заполнения родителя. Гейт поузловой
(`passport_gate.check_node_fields` / `check_need_node` / `check_guardrail_node`),
отклонение стоит одного шага. Пайплайн шлёт события `passport_started`,
`passport_node`, `passport_ready`.

### Формат узла (`submit_node`)

```json
{"id": "bbb-2", "name": "Сборка портфеля", "basis": "собирает набор продуктов по долям",
 "fields": {"4.4.1": {"value": "...", "source": "Установлено: ..."}}}
```

Для `journey` дополнительно `decision_boundary`, для `need` — `journeys`,
для `guardrail` — `scope`. Дети (`declare_children`) — только `name` и `basis`.

### Рендерер: три прохода

1. **`_insert_extra_nodes`** — клонирует `<template>`-заготовки для узлов,
   которых нет в шаблоне; потребности и ограничения — в свои контейнеры.
2. **`_fill_registry`** — таблица реестра из `registry`, построенного кодом.
3. **`_fill_template`** — линейный проход по HTML, подстановка `data-fill`.

### Fallback

Если паспортная сессия не дошла до `finish`, паспорт собирается из того,
что принято; незаполненные узлы помечены «сессия прервана». Если не принят
ни один узел — паспорт формируется детерминированно из `ProgressModel` +
`Extraction` с бейджем «агент паспорт не заполнил».

## Запуск

### DeepSeek (mTLS)

```bash
export PKO_MATCHER_BASE_URL="https://ingressgateway-ai-hub-ci11758197-models-ift.apps.bbwo1z5h.k8s.delta.sbrf.ru/deepseek-v4-flash/v1"
export PKO_MATCHER_MODEL="deepseek-ai/DeepSeek-V4-Flash"
export PKO_MATCHER_CLIENT_CERT="certs/deepsearch-gp-sberca-client.crt"
export PKO_MATCHER_CLIENT_KEY="certs/deepsearch-gp-sberca-client.key"
export PKO_THINKING=true
export PKO_MAX_SESSION_SECONDS=3600
export PKO_CONTEXT_WINDOW=128000

pko progress \
  --initiative agent-kontr-offera \
  --zip projects/.../credit_counter_offer.zip \
  --zip projects/.../depo_counter_offer.zip \
  --out results \
  --thinking \
  --max-steps 80
```

### GLM-5.2 (HTTP, без сертов)

```bash
# .env: PKO_THINKING=true, эндпоинт из defaults.py
pko progress \
  --initiative agent-kontr-offera \
  --zip projects/.../code.zip \
  --out results \
  --thinking \
  --max-steps 80
```

### Результат

В `results/`:

- `<slug>_client_journey_passport.html` — паспорт (шаблон v3, заполнен агентом)
- `<slug>_dashboard.html` — дашборд готовности
- `<slug>_progress_report.html` — отчёт
- `<slug>_progress_model.json` — модель (включая `passport_data`)

## Параметры запуска

| Параметр | Значение | Зачем |
|---|---|---|
| `--max-steps 80` | 80 шагов | Агенту нужно ~40 шагов на анализ + ~10 на паспорт |
| `--thinking` | включить reasoning | DeepSeek/GLM с thinking — глубже анализ, но медленнее |
| `PKO_MAX_SESSION_SECONDS=3600` | 1 час | Thinking-режим: ~1-2 мин на шаг |
| `PKO_CONTEXT_WINDOW=128000` | окно модели | Бюджет истории агента |

## Ограничения

- Паспортный агент может не дойти до `finish` при нехватке шагов или таймауте —
  тогда в паспорт идёт всё принятое, незаполненные узлы помечены «сессия
  прервана»; без единого принятого узла — детерминированные заглушки.
- Кеш LLM инвалидируется при изменении `agent_system.md` — повторный прогон
  того же коммита после правки промпта снова вызывает модель.
- Сертификаты `certs/*.key` не коммитить (в `.gitignore`).

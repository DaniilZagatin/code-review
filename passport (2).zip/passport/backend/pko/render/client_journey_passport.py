"""Единый паспорт клиентского пути — рендер HTML-шаблона v3.

Шаблон: ``passport-dpss-v3.html``. Использует ``data-fill``
атрибуты (не Mustache): каждый заполняемый элемент имеет
``data-fill="value|source|name|object-id|object-version|..."`` и
``data-placeholder``. Рендерер находит эти элементы и подставляет текст,
сохраняя CSS, структуру, классы и ``<template>``-доноры.

Иерархия объектов в шаблоне:
  journey (КП) → process (процесс) → bbb (бизнес-блок) → operation (операция)
  need — связанная карточка потребности клиента
  guardrail — связанная карточка ограничения исполнения

Два источника значений полей:
  1. **Агент-матчер** (инструмент ``submit_passport`` в сессии) — модель
     заполняет смысловые поля паспорта по результатам своего же анализа
     кода. Значения приходят как ``passport_data`` (dict из tool-call)
     и преобразуются в ``llm_values`` (плоский dict, ключи совпадают со
     схемой ``_fill_template``).
  2. **Детерминированное заполнение** (``_build_fill_values``) — fallback
     из ProgressModel + Extraction, если агент не вызвал ``submit_passport``
     или вернул пустоту.

Принцип тот же: код заполняет, не выдумывает. Агент предлагает содержания
полей, код подставляет их в HTML — модель не видит разметку и не может
её сломать.
"""

from __future__ import annotations

import html as _html
import re
import time
from pathlib import Path
from typing import Any

from pko.extractors.runner import Extraction
from pko.progress.plan_input import PlanInput
from pko.progress.schema import ProgressModel

_TEMPLATE_PATH = Path(__file__).resolve().parents[3] / "passport-dpss-v3.html"

_EMPTY = "Не установлено по доступным артефактам"
_NEEDS_OWNER = "Требуется подтверждение владельца"


def render_client_journey_passport(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str = "",
    llm_values: dict[str, str] | None = None,
    registry_rows: list[dict[str, str]] | None = None,
    tree_spec: list[dict[str, Any]] | None = None,
) -> str:
    """Собрать заполненный HTML-паспорт из модели и экстракции.

    ``llm_values`` — плоский dict значений полей от агента (ключи вида
    ``{node}:{field}:value``, ``{node}:name``, ``analysis-scope`` и т.д.).
    Если передан, значения LLM перекрывают детерминированные (только непустые).

    ``registry_rows`` — строки реестра узлов от агента. Если не передан,
    реестр строится детерминированно из известных узлов.

    ``tree_spec`` — спецификация дерева узлов от агента (произвольное число
    узлов каждого типа). Если передана, рендерер клонирует
    ``<template>``-заготовки и перестраивает дерево.
    """
    template = _TEMPLATE_PATH.read_text(encoding="utf-8")
    values = _build_fill_values(model, plan_input, repo_name, extraction, commit, branch, model_name)
    filled_by_agent = bool(llm_values)
    if llm_values:
        for key, val in llm_values.items():
            if val:
                values[key] = val
    if tree_spec:
        template = _insert_extra_nodes(template, tree_spec, registry_rows)
    if registry_rows is None:
        registry_rows = _build_registry(values)
    template = _fill_registry(template, registry_rows)
    template = _fill_template(template, values)
    template = _set_status_badge(template, filled_by_agent)
    template = _finalize_html(template)
    return template


# Бейдж в шапке. Шаблон приходит с «ЗАГОТОВКА · ПОЛЯ НЕ ЗАПОЛНЕНЫ», и
# заполненный паспорт уходил читателю с этой подписью. Статус переключает
# код: он один знает, кто заполнял поля.
STATUS_BADGE_TEMPLATE = "ЗАГОТОВКА · ПОЛЯ НЕ ЗАПОЛНЕНЫ"
STATUS_BADGE_AGENT = "ЗАПОЛНЕНО ПО КОДУ · БИЗНЕС-НАМЕРЕНИЕ ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ ВЛАДЕЛЬЦА"
STATUS_BADGE_FALLBACK = "ЗАПОЛНЕНО ДЕТЕРМИНИРОВАННО · АГЕНТ ПАСПОРТ НЕ ЗАПОЛНИЛ"


def _set_status_badge(html: str, filled_by_agent: bool) -> str:
    badge = STATUS_BADGE_AGENT if filled_by_agent else STATUS_BADGE_FALLBACK
    return html.replace(STATUS_BADGE_TEMPLATE, badge, 1)


# --- динамические узлы из ответа агента ---------------------------------------
#
# Агент может вернуть дерево с произвольным числом узлов каждого типа.
# Шаблон v3 содержит образцы (journey-1, process-1, bbb-1, ...) и
# <template>-заготовки для клонирования. Рендерер:
#   1. Находит узлы, которых ещё нет в HTML (по id).
#   2. Клонирует <template> нужного типа, заменяет -N на реальный номер.
#   3. Вставляет клон в data-children контейнер родителя.

_TEMPLATE_RE = re.compile(
    r'<template id="tpl-(\w+)">(.*?)</template>', re.DOTALL,
)

# HTML-комментарии: в шаблоне v3 внутри комментариев встречаются тексты
# вида «<template id="tpl-journey">» — они не теги, а подсказки агенту.
# Без удаления комментариев regex выше ловит их и ест половину файла.
_COMMENT_RE = re.compile(r'<!--.*?-->', re.DOTALL)


def _strip_comments(html: str) -> str:
    """Убрать HTML-комментарии, чтобы regex по тегам не матчил текст в них."""
    return _COMMENT_RE.sub("", html)


def _extract_templates(template: str) -> dict[str, str]:
    """Извлечь HTML-заготовки узлов из <template> элементов."""
    clean = _strip_comments(template)
    out: dict[str, str] = {}
    for m in _TEMPLATE_RE.finditer(clean):
        out[m.group(1)] = m.group(2)
    return out


def _clone_node(template_html: str, node_id: str) -> str:
    """Клонировать заготовку узла, заменив ``N`` в id на реальный номер."""
    number = node_id.rsplit("-", 1)[-1]
    return template_html.replace("-N", f"-{number}")


def _existing_node_ids(template: str) -> set[str]:
    """Найти id всех узлов, уже присутствующих в HTML (вне <template>)."""
    clean = _strip_comments(template)
    stripped = _TEMPLATE_RE.sub("", clean)
    return set(re.findall(
        r'id="((?:journey|process|bbb|operation|need|guardrail)-\d+)"',
        stripped,
    ))


def _insert_extra_nodes(
    template: str,
    tree_spec: list[dict[str, Any]],
    registry_rows: list[dict[str, str]] | None,
) -> str:
    """Добавить недостающие узлы в HTML, клонируя <template>-заготовки.

    Работает с шаблоном v3, где нет ``id="tree"`` контейнера: узлы лежат
    напрямую в ``<section>``, а дочерние — в ``data-children`` контейнерах
    внутри родительского узла.
    """
    templates = _extract_templates(template)
    if not templates:
        return template

    existing = _existing_node_ids(template)

    # Собираем все id узлов из tree_spec и registry.
    all_nodes = _collect_all_node_ids(tree_spec, registry_rows)

    # Узлы, которые нужно добавить.
    missing = [nid for nid in all_nodes if nid not in existing]
    if not missing:
        return template

    # Строим карту parent → children по registry.
    parent_map: dict[str, list[str]] = {}
    for row in (registry_rows or []):
        parent = row.get("parent", "")
        child_id = row.get("id", "")
        if parent and parent != "—" and child_id:
            parent_map.setdefault(parent, []).append(child_id)

    # Для каждого недостающего узла: клонируем template и вставляем
    # в data-children контейнер родителя.
    for node_id in missing:
        node_type = _node_type(node_id)
        tpl = templates.get(node_type)
        if not tpl:
            continue
        clone = _clone_node(tpl, node_id)

        # Ищем родителя по registry.
        parent_id = None
        for row in (registry_rows or []):
            if row.get("id") == node_id:
                parent_id = row.get("parent", "")
                break

        if node_type in ("need", "guardrail"):
            # Потребности и ограничения живут в своих контейнерах независимо
            # от «родителя»: в реестре у них стоят связанные пути и область
            # действия (journey-1 / bbb-3, operation-2), а не узел-контейнер.
            container_id = "related-needs" if node_type == "need" else "related-guardrails"
            template = _insert_into_container(template, container_id, clone)
        elif parent_id and parent_id != "—":
            # Вставляем в data-children="[type]" контейнер внутри родителя.
            template = _insert_into_parent(template, parent_id, node_type, clone)
        else:
            # Journey без родителя — вставляем после последнего journey.
            template = _insert_after_last_node(template, node_type, clone)

    return template


def _insert_into_parent(
    template: str, parent_id: str, child_type: str, clone_html: str,
) -> str:
    """Вставить клон узла в data-children контейнер внутри родительского узла.

    Ищем ``<div ... data-children="child_type" ...>...</div>`` внутри HTML
    родительского узла (по id) и вставляем клон перед закрывающим ``</div>``.
    """
    # Находим позицию родительского узла по id.
    parent_re = re.compile(rf'id="{re.escape(parent_id)}"')
    parent_m = parent_re.search(template)
    if not parent_m:
        return template

    # После родительского id ищем data-children="child_type" контейнер.
    search_start = parent_m.end()
    container_re = re.compile(
        rf'(<div\b[^>]*data-children="{child_type}"[^>]*>)',
    )
    container_m = container_re.search(template, search_start)
    if not container_m:
        return template

    # От начала контейнера ищем его закрывающий </div> (с учётом вложенности).
    pos = container_m.end()
    depth = 1
    while depth > 0 and pos < len(template):
        open_m = re.search(r"<div\b", template[pos:])
        close_m = re.search(r"</div>", template[pos:])
        if close_m is None:
            break
        if open_m and open_m.start() < close_m.start():
            depth += 1
            pos += open_m.end()
        else:
            depth -= 1
            if depth == 0:
                # Это закрывающий тег контейнера — вставляем перед ним.
                insert_pos = pos + close_m.start()
                return (
                    template[:insert_pos]
                    + "\n" + clone_html + "\n"
                    + template[insert_pos:]
                )
            pos += close_m.end()

    return template


def _insert_into_container(
    template: str, container_id: str, clone_html: str,
) -> str:
    """Вставить клон в related-needs или related-guardrails контейнер."""
    container_re = re.compile(rf'<div\b[^>]*id="{container_id}"[^>]*>')
    m = container_re.search(template)
    if not m:
        return template

    pos = m.end()
    depth = 1
    while depth > 0 and pos < len(template):
        open_m = re.search(r"<div\b", template[pos:])
        close_m = re.search(r"</div>", template[pos:])
        if close_m is None:
            break
        if open_m and open_m.start() < close_m.start():
            depth += 1
            pos += open_m.end()
        else:
            depth -= 1
            if depth == 0:
                insert_pos = pos + close_m.start()
                return (
                    template[:insert_pos]
                    + "\n" + clone_html + "\n"
                    + template[insert_pos:]
                )
            pos += close_m.end()

    return template


def _insert_after_last_node(
    template: str, node_type: str, clone_html: str,
) -> str:
    """Вставить клон после последнего узла того же типа (fallback)."""
    # Ищем все id="type-N" вне <template>.
    stripped = _TEMPLATE_RE.sub("", template)
    matches = list(re.finditer(
        rf'id="({node_type}-\d+)"', stripped,
    ))
    if not matches:
        return template
    # Вставляем после конца последнего узла — после следующего </div>
    # на том же уровне. Простой подход: вставляем перед началом следующего
    # блока (related-needs или конец section).
    last_pos = matches[-1].end()
    # Ищем следующий </div> на нужной глубине — грубо, ищем
    # "<!--#NODE:" или "<div id=\"related-" после последнего узла.
    after = re.search(
        r'(<!--#NODE:|<div\b[^>]*id="related-|</section)',
        template[last_pos:],
    )
    if after:
        insert_pos = last_pos + after.start()
        return (
            template[:insert_pos]
            + "\n" + clone_html + "\n"
            + template[insert_pos:]
        )
    return template


def _collect_all_node_ids(
    tree_spec: list[dict[str, Any]] | None,
    registry_rows: list[dict[str, str]] | None,
) -> list[str]:
    """Собрать все id узлов из tree_spec и/или registry, в порядке появления."""
    seen: list[str] = []
    seen_set: set[str] = set()

    def visit(node: dict[str, Any]) -> None:
        nid = node.get("id", "")
        if nid and nid not in seen_set:
            seen.append(nid)
            seen_set.add(nid)
        for child in (node.get("children") or []):
            if isinstance(child, dict):
                visit(child)

    if tree_spec:
        for node in tree_spec:
            if isinstance(node, dict):
                visit(node)

    if registry_rows:
        for row in registry_rows:
            nid = row.get("id", "")
            if nid and nid not in seen_set:
                seen.append(nid)
                seen_set.add(nid)

    return seen

    return html


# --- данные ------------------------------------------------------------------

def _build_fill_values(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str,
) -> dict[str, str]:
    """Сопоставить поля шаблона с данными модели.

    Ключи — составные: `{node_id}:{fill_type}` или `{node_id}:{field_id}:{fill_type}`.
    `fill_type` — value | source | name | object-id | object-version.
    """
    ctx = plan_input.context
    journey_name = ctx.get("project_name") or ctx.get("client_path_name") or repo_name or "—"
    project_name = journey_name
    generated = time.strftime("%Y-%m-%d %H:%M")
    v: dict[str, str] = {}

    # --- мета ---
    v["analysis-scope"] = f"{repo_name} · коммит {commit[:8] if commit else '—'} · {project_name}"
    v["decision-boundary"] = "END_TO_END_PROCESS"
    v["analysis-date"] = generated
    # Образ результата — единственный источник бизнес-рамки паспорта. Без
    # него «Гипотеза: из описания инициативы» ссылается в пустоту.
    v["initiative-basis"] = _initiative_basis(plan_input)

    # --- journey-1 (Клиентский путь) ---
    v["journey-1:name"] = journey_name
    v["journey-1:object-id"] = _EMPTY
    v["journey-1:object-version"] = _EMPTY
    v["journey-1:4.2.1:value"] = ctx.get("before") or _EMPTY
    v["journey-1:4.2.1:source"] = "образ результата инициативы"
    v["journey-1:4.2.2:value"] = ctx.get("client_path_name") or _EMPTY
    v["journey-1:4.2.2:source"] = "образ результата инициативы"
    v["journey-1:4.2.3:value"] = _NEEDS_OWNER
    v["journey-1:4.2.3:source"] = _EMPTY
    v["journey-1:4.2.4:value"] = (
        f"До: {ctx.get('before', _EMPTY)}. После: {ctx.get('after', _EMPTY)}."
    )
    v["journey-1:4.2.4:source"] = "образ результата инициативы"
    v["journey-1:4.2.5:value"] = _summary_outcomes(model)
    v["journey-1:4.2.5:source"] = "оценка агента по коду репозитория"
    v["journey-1:4.2.6:value"] = _stages_text(plan_input)
    v["journey-1:4.2.6:source"] = "образ результата инициативы"
    v["journey-1:4.2.7:value"] = _interaction_moments(model)
    v["journey-1:4.2.7:source"] = "оценка агента по коду репозитория"
    v["journey-1:4.2.8:value"] = _EMPTY
    v["journey-1:4.2.8:source"] = _EMPTY

    # --- process-1 (Автономный процесс) ---
    v["process-1:name"] = project_name
    v["process-1:object-id"] = _EMPTY
    v["process-1:object-version"] = _EMPTY
    v["process-1:4.3.1:value"] = f"Собирает и исполняет решение для клиентского пути «{journey_name}»."
    v["process-1:4.3.1:source"] = "образ результата инициативы"
    v["process-1:4.3.2:value"] = f"Клиентский путь: {journey_name}"
    v["process-1:4.3.2:source"] = "образ результата инициативы"
    v["process-1:4.3.3:value"] = _NEEDS_OWNER
    v["process-1:4.3.3:source"] = _EMPTY
    v["process-1:4.3.4:value"] = _entry_conditions(extraction)
    v["process-1:4.3.4:source"] = _extraction_source(extraction, "ROUTE")
    v["process-1:4.3.5:value"] = _routing_logic(model, plan_input)
    v["process-1:4.3.5:source"] = _extraction_source(extraction, "GRAPH_NODE")
    v["process-1:4.3.6:value"] = _bbbs_and_modes(extraction)
    v["process-1:4.3.6:source"] = _extraction_source(extraction, "TOOL")
    v["process-1:4.3.7:value"] = _fallback(model, extraction)
    v["process-1:4.3.7:source"] = "оценка агента по коду репозитория"
    v["process-1:4.3.8:value"] = _EMPTY
    v["process-1:4.3.8:source"] = _EMPTY
    v["process-1:4.3.9:value"] = f"Коммит: {commit or '—'}"
    v["process-1:4.3.9:source"] = "git-коммит"

    # --- bbb-1 (первый бизнес-блок) ---
    _fill_bbb(v, "bbb-1", extraction, model, 0)
    # --- bbb-2 ---
    _fill_bbb(v, "bbb-2", extraction, model, 1)
    # --- bbb-3 ---
    _fill_bbb(v, "bbb-3", extraction, model, 2)

    # --- operation-1, operation-2 ---
    _fill_operation(v, "operation-1", extraction, 0)
    _fill_operation(v, "operation-2", extraction, 1)

    # --- guardrail-1 ---
    _fill_guardrail(v, "guardrail-1", extraction)

    # --- need-1 (Потребность клиента) ---
    _fill_need(v, "need-1", plan_input)

    return v


def _fill_bbb(v: dict, node_id: str, extraction: Extraction, model: ProgressModel, index: int) -> None:
    tools = extraction.by_kind("TOOL") + extraction.by_kind("GRAPH_NODE")
    fact = tools[index] if index < len(tools) else None
    if fact:
        v[f"{node_id}:name"] = fact.key
        v[f"{node_id}:object-id"] = _EMPTY
        v[f"{node_id}:object-version"] = _EMPTY
        v[f"{node_id}:4.4.1:value"] = str(fact.value or _EMPTY)[:200] if isinstance(fact.value, (str, dict)) else _EMPTY
        v[f"{node_id}:4.4.1:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.2:value"] = _EMPTY
        v[f"{node_id}:4.4.2:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.3:value"] = _NEEDS_OWNER
        v[f"{node_id}:4.4.3:source"] = _EMPTY
        v[f"{node_id}:4.4.4:value"] = _EMPTY
        v[f"{node_id}:4.4.4:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.5:value"] = _EMPTY
        v[f"{node_id}:4.4.5:source"] = _EMPTY
        v[f"{node_id}:4.4.6:value"] = _EMPTY
        v[f"{node_id}:4.4.6:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.4.7:value"] = _EMPTY
        v[f"{node_id}:4.4.7:source"] = _EMPTY
    else:
        for fill in ("name", "object-id", "object-version"):
            v[f"{node_id}:{fill}"] = _EMPTY
        for field in ("4.4.1", "4.4.2", "4.4.3", "4.4.4", "4.4.5", "4.4.6", "4.4.7"):
            v[f"{node_id}:{field}:value"] = _EMPTY
            v[f"{node_id}:{field}:source"] = _EMPTY


def _fill_operation(v: dict, node_id: str, extraction: Extraction, index: int) -> None:
    funcs = [f for f in extraction.by_kind("FUNCTION") if f.value and isinstance(f.value, dict) and f.value.get("doc")]
    fact = funcs[index] if index < len(funcs) else None
    if fact:
        doc = str(fact.value.get("doc") or _EMPTY)[:200]
        v[f"{node_id}:name"] = fact.key
        v[f"{node_id}:object-id"] = _EMPTY
        v[f"{node_id}:object-version"] = _EMPTY
        v[f"{node_id}:4.5.1:value"] = doc
        v[f"{node_id}:4.5.1:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.2:value"] = _EMPTY
        v[f"{node_id}:4.5.2:source"] = _EMPTY
        v[f"{node_id}:4.5.3:value"] = _NEEDS_OWNER
        v[f"{node_id}:4.5.3:source"] = _EMPTY
        v[f"{node_id}:4.5.4:value"] = _EMPTY
        v[f"{node_id}:4.5.4:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.5:value"] = _EMPTY
        v[f"{node_id}:4.5.5:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
        v[f"{node_id}:4.5.6:value"] = _EMPTY
        v[f"{node_id}:4.5.6:source"] = _EMPTY
    else:
        for fill in ("name", "object-id", "object-version"):
            v[f"{node_id}:{fill}"] = _EMPTY
        for field in ("4.5.1", "4.5.2", "4.5.3", "4.5.4", "4.5.5", "4.5.6"):
            v[f"{node_id}:{field}:value"] = _EMPTY
            v[f"{node_id}:{field}:source"] = _EMPTY


def _fill_guardrail(v: dict, node_id: str, extraction: Extraction) -> None:
    limits = extraction.by_kind("LIMIT")
    fact = limits[0] if limits else None
    if fact:
        v[f"{node_id}:name"] = fact.key
        v[f"{node_id}:object-id"] = _EMPTY
        v[f"{node_id}:object-version"] = _EMPTY
        v[f"{node_id}:4.6.1:value"] = str(fact.value or _EMPTY)[:200]
        v[f"{node_id}:4.6.1:source"] = f"{fact.path}:{fact.line}" if fact.line else fact.path
    else:
        v[f"{node_id}:name"] = "Ограничения клиентского опыта"
        v[f"{node_id}:object-id"] = _EMPTY
        v[f"{node_id}:object-version"] = _EMPTY
        v[f"{node_id}:4.6.1:value"] = "Клиент всегда может отказаться от предложения"
        v[f"{node_id}:4.6.1:source"] = _EMPTY
    for field in ("4.6.2", "4.6.3", "4.6.4", "4.6.5", "4.6.6",
                  "4.6.7", "4.6.8", "4.6.9", "4.6.10", "4.6.11", "4.6.12"):
        v[f"{node_id}:{field}:value"] = _EMPTY
        v[f"{node_id}:{field}:source"] = _EMPTY


def _fill_need(v: dict, node_id: str, plan_input: PlanInput) -> None:
    """Заполнить карточку потребности клиента (§ 4.1, 7 полей)."""
    ctx = plan_input.context
    journey_name = ctx.get("project_name") or ctx.get("client_path_name") or "—"
    v[f"{node_id}:name"] = journey_name
    v[f"{node_id}:object-id"] = _EMPTY
    v[f"{node_id}:object-version"] = _EMPTY
    v[f"{node_id}:4.1.1:value"] = (
        f"Предложение по результатам анализа: потребность, закрываемая "
        f"клиентским путём «{journey_name}»."
    )
    v[f"{node_id}:4.1.1:source"] = "образ результата инициативы"
    v[f"{node_id}:4.1.2:value"] = ctx.get("before") or _EMPTY
    v[f"{node_id}:4.1.2:source"] = "образ результата инициативы"
    v[f"{node_id}:4.1.3:value"] = _NEEDS_OWNER
    v[f"{node_id}:4.1.3:source"] = _EMPTY
    v[f"{node_id}:4.1.4:value"] = _EMPTY
    v[f"{node_id}:4.1.4:source"] = _EMPTY
    v[f"{node_id}:4.1.5:value"] = ctx.get("after") or _EMPTY
    v[f"{node_id}:4.1.5:source"] = "образ результата инициативы"
    v[f"{node_id}:4.1.6:value"] = f"Клиентский путь: {journey_name}"
    v[f"{node_id}:4.1.6:source"] = "образ результата инициативы"
    v[f"{node_id}:4.1.7:value"] = _EMPTY
    v[f"{node_id}:4.1.7:source"] = _EMPTY


# --- вспомогательные ---------------------------------------------------------

def _summary_outcomes(model: ProgressModel) -> str:
    if not model.verdicts:
        return _EMPTY
    done = sum(1 for v in model.verdicts for c in v.criteria if c.applicable and c.status == "done")
    total = sum(1 for v in model.verdicts for c in v.criteria if c.applicable)
    if done == total:
        return f"Все {total} пунктов реализованы — путь завершается успешно."
    if done > 0:
        return f"Из {total} пунктов полностью работают {done} — результат достигается частично."
    return f"Из {total} пунктов ни один не работает полностью — результат не подтверждён."


def _initiative_basis(plan_input: PlanInput) -> str:
    """Образ результата инициативы для шапки: название, этапы и число пунктов."""
    ctx = plan_input.context
    name = ctx.get("client_path_name") or ctx.get("project_name") or ""
    items = list(getattr(plan_input, "items", []) or [])
    bullets = sum(len(getattr(item, "criteria", []) or []) for item in items)
    stages = " · ".join(item.title for item in items if getattr(item, "title", ""))
    parts = [p for p in (name, stages, f"пунктов образа результата: {bullets}" if bullets else "") if p]
    return "; ".join(parts) if parts else _EMPTY


def _stages_text(plan_input: PlanInput) -> str:
    if not plan_input.stages:
        return _EMPTY
    return "; ".join(f"{i}. {s}" for i, s in enumerate(plan_input.stages, 1))


def _interaction_moments(model: ProgressModel) -> str:
    moments: list[str] = []
    for v in model.verdicts:
        for c in v.criteria:
            if c.applicable and c.how_text:
                moments.append(c.how_text[:120])
    if not moments:
        return _EMPTY
    return "; ".join(moments[:5])


def _entry_conditions(extraction: Extraction) -> str:
    routes = extraction.by_kind("ROUTE")
    if not routes:
        return _EMPTY
    return "Точка входа: " + ", ".join(f.key for f in routes[:3])


def _routing_logic(model: ProgressModel, plan_input: PlanInput) -> str:
    parts: list[str] = []
    if plan_input.stages:
        parts.append("Этапы: " + " → ".join(plan_input.stages))
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        done = sum(1 for c in v.criteria if c.applicable and c.status == "done")
        total = sum(1 for c in v.criteria if c.applicable)
        parts.append(f"{item.title}: {done}/{total}")
    return "; ".join(parts[:5]) or _EMPTY


def _bbbs_and_modes(extraction: Extraction) -> str:
    tools = extraction.by_kind("TOOL")
    if not tools:
        return _EMPTY
    return ", ".join(f.key for f in tools[:5])


def _fallback(model: ProgressModel, extraction: Extraction) -> str:
    for v in model.verdicts:
        for c in v.criteria:
            if c.applicable and c.status in ("partial", "blocked"):
                return "Обнаружены нереализованные пункты — требуется ручная проверка"
    return _EMPTY


def _extraction_source(extraction: Extraction, kind: str) -> str:
    facts = extraction.by_kind(kind)
    if not facts:
        return _EMPTY
    f = facts[0]
    return f"{f.path}:{f.line}" if f.line else f.path


# --- реестр узлов ------------------------------------------------------------

_NODE_META = [
    ("journey-1", "Клиентский путь", "—"),
    ("process-1", "Автономный процесс", "journey-1"),
    ("bbb-1", "BBB", "process-1"),
    ("operation-1", "Атомарная операция", "bbb-1"),
    ("need-1", "Потребность клиента", "—"),
    ("guardrail-1", "Ограничение исполнения", "—"),
]


def _build_registry(values: dict[str, str]) -> list[dict[str, str]]:
    """Построить реестр узлов из заполненных значений (fallback без LLM)."""
    rows: list[dict[str, str]] = []
    for node_id, type_label, parent in _NODE_META:
        name = values.get(f"{node_id}:name", "")
        rows.append({
            "id": node_id,
            "type": type_label,
            "name": name,
            "parent": parent,
            "basis": "обнаружен в коде репозитория",
        })
    return rows


_REGISTRY_TBODY_RE = re.compile(
    r"(<table[^>]*class=\"registry\"[^>]*>.*?<tbody>)(.*?)(</tbody>)",
    re.DOTALL,
)


def _fill_registry(template: str, rows: list[dict[str, str]]) -> str:
    """Заполнить таблицу реестра узлов строками.

    Заменяет содержимое ``<tbody>`` шаблона на строки из ``rows``.
    Сохраняет структуру ``<td data-col="...">`` для CSS.
    """
    if not rows:
        return template

    def replace_tbody(m: re.Match) -> str:
        open_tag = m.group(1)
        old_body = m.group(2)
        close_tag = m.group(3)

        # Заголовки колонок из первой строки-образца шаблона.
        col_names = ["HTML-id", "Тип", "Название", "Родитель", "Основание"]
        col_keys = ["id", "type", "name", "parent", "basis"]

        new_rows: list[str] = []
        for row in rows:
            cells = []
            for col_name, col_key in zip(col_names, col_keys):
                val = _html.escape(str(row.get(col_key, "")), quote=False)
                cells.append(f'<td data-col="{col_name}">{val}</td>')
            new_rows.append("<tr>" + "".join(cells) + "</tr>")

        return open_tag + "\n" + "\n".join(new_rows) + "\n" + close_tag

    return _REGISTRY_TBODY_RE.sub(replace_tbody, template, count=1)


# --- HTML-рендерер -----------------------------------------------------------
#
# Шаблон v3 использует <div class="node [type]" id="[type]-N"> вместо <details>.
# Линейный проход: отслеживаем текущий узел (по id на div.node) и поле
# (data-field), пропускаем HTML-комментарии.
#
# fill types:
#   name, object-id, object-version → ключ {node}:{fill} (без поля)
#   value, source                   → ключ {node}:{field}:{fill}
#   analysis-scope, decision-boundary, analysis-date → ключ {fill} (вне узлов)

# Узел: id="(journey|process|bbb|operation|need|guardrail)-N" на любом теге.
# Поле: data-field="X.Y.Z". Заполнение: data-fill="value|source|name|...".

_TOKEN_RE = re.compile(
    r'(<!--.*?-->)'                                                  # 1: comment (skip)
    r'|(id="((?:journey|process|bbb|operation|need|guardrail)-\d+)")' # 2,3: node id
    r'|(data-field="([^"]+)")'                                       # 4,5: data-field
    r'|(data-fill="([^"]+)"[^>]*>)([^<]*)(</(?:div|span)>)',        # 6,7,8,9: data-fill element
    re.DOTALL,
)

_NODE_FILLS = {"name", "object-id", "object-version"}
_FIELD_FILLS = {"value", "source"}
_NODE_ID_RE = re.compile(
    r"^(?:journey|process|bbb|operation|need|guardrail)-\d+$"
)


def _fill_template(template: str, values: dict[str, str]) -> str:
    """Заполнить data-fill элементы значениями из dict.

    Линейный проход: отслеживаем текущий узел (по id) и поле (data-field),
    пропускаем комментарии. Каждый data-fill заполняется по ключу
    {node}:{field}:{fill} или {node}:{fill} или {fill}.

    Работает с шаблоном v3, где узлы — ``<div class="node" id="X">``, а не
    ``<details>``: нет стека open/close, текущий узел обновляется при
    обнаружении нового id узла.
    """
    parts: list[str] = []
    last_end = 0
    current_node: str | None = None
    current_field: str | None = None

    for m in _TOKEN_RE.finditer(template):
        parts.append(template[last_end:m.start()])
        last_end = m.end()

        if m.group(1) is not None:
            # HTML-комментарий — пропускаем как есть
            parts.append(m.group(0))
        elif m.group(3) is not None:
            # id="journey-1" / id="process-2" и т.д. — вход в узел.
            # В v3 узлы не вкладываются через details, а идут последовательно:
            # новый id узла означает, что предыдущий закончился.
            current_node = m.group(3)
            current_field = None
            parts.append(m.group(0))
        elif m.group(5) is not None:
            # data-field="X.Y.Z"
            current_field = m.group(5)
            parts.append(m.group(0))
        elif m.group(7) is not None:
            # data-fill="..." element
            fill_type = m.group(7)
            open_tag = m.group(6)
            content = m.group(8)
            close_tag = m.group(9)
            key = _make_key(current_node, current_field, fill_type)
            val = values.get(key, "") if key else ""
            if val:
                safe = _html.escape(val, quote=False)
                parts.append(open_tag + safe + close_tag)
            else:
                parts.append(m.group(0))

    parts.append(template[last_end:])
    return "".join(parts)


def _make_key(node: str | None, field: str | None, fill: str) -> str | None:
    """Собрать ключ для values dict по контексту узла и поля."""
    if fill in _NODE_FILLS:
        return f"{node}:{fill}" if node else None
    if fill in _FIELD_FILLS:
        return f"{node}:{field}:{fill}" if node and field else None
    return fill


# --- разбор passport_data от агента ------------------------------------------
#
# Агент-матчер вызывает инструмент `submit_passport` с JSON-объектом,
# содержащим значения полей паспорта. Эти функции преобразуют его в плоский
# dict для `_fill_template` и в строки реестра.

_FIELD_MAP = {
    "journey": ["4.2.1", "4.2.2", "4.2.3", "4.2.4", "4.2.5", "4.2.6", "4.2.7", "4.2.8"],
    "process": ["4.3.1", "4.3.2", "4.3.3", "4.3.4", "4.3.5", "4.3.6", "4.3.7", "4.3.8", "4.3.9"],
    "bbb": ["4.4.1", "4.4.2", "4.4.3", "4.4.4", "4.4.5", "4.4.6", "4.4.7"],
    "operation": ["4.5.1", "4.5.2", "4.5.3", "4.5.4", "4.5.5", "4.5.6"],
    "need": ["4.1.1", "4.1.2", "4.1.3", "4.1.4", "4.1.5", "4.1.6", "4.1.7"],
    "guardrail": ["4.6.1", "4.6.2", "4.6.3", "4.6.4", "4.6.5", "4.6.6",
                  "4.6.7", "4.6.8", "4.6.9", "4.6.10", "4.6.11", "4.6.12"],
}

_SAMPLE_NODES = {
    "journey-1": "journey",
    "process-1": "process",
    "bbb-1": "bbb",
    "operation-1": "operation",
    "need-1": "need",
    "guardrail-1": "guardrail",
}

_NODE_TYPE_PREFIXES = ("journey", "process", "bbb", "operation", "need", "guardrail")


def _node_type(node_id: str) -> str:
    """Тип узла по id: journey-1 → journey, bbb-3 → bbb."""
    for prefix in _NODE_TYPE_PREFIXES:
        if node_id.startswith(prefix + "-"):
            return prefix
    return ""


def flatten_passport_data(data: dict[str, Any] | None) -> dict[str, str]:
    """Преобразовать JSON-ответ агента (``submit_passport``) в плоский dict.

    Ключи совпадают со схемой ``_fill_template``:
    - ``analysis-scope``, ``decision-boundary``, ``analysis-date``
    - ``{node}:name``, ``{node}:object-id``, ``{node}:object-version``
    - ``{node}:{field}:value``, ``{node}:{field}:source``

    Обрабатывает произвольное число узлов — агент может вернуть
    journey-1, journey-2, bbb-1, bbb-2, bbb-3 и т.д.
    """
    if not data or not isinstance(data, dict):
        return {}

    v: dict[str, str] = {}
    v["analysis-scope"] = str(data.get("analysis-scope", ""))
    v["decision-boundary"] = str(data.get("decision-boundary", ""))
    v["analysis-date"] = str(data.get("analysis-date", ""))

    nodes = data.get("nodes", {})
    if not isinstance(nodes, dict):
        return v

    for node_id, node in nodes.items():
        if not isinstance(node, dict):
            continue
        node_type = _node_type(str(node_id))
        if not node_type:
            continue
        v[f"{node_id}:name"] = str(node.get("name", ""))
        v[f"{node_id}:object-id"] = str(node.get("object-id", ""))
        v[f"{node_id}:object-version"] = str(node.get("object-version", ""))
        fields = node.get("fields", {})
        if not isinstance(fields, dict):
            continue
        for field_id in _FIELD_MAP.get(node_type, []):
            field = fields.get(field_id, {})
            if not isinstance(field, dict):
                continue
            v[f"{node_id}:{field_id}:value"] = str(field.get("value", ""))
            v[f"{node_id}:{field_id}:source"] = str(field.get("source", ""))

    return v


def passport_tree_spec(data: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Извлечь спецификацию дерева узлов из ответа агента.

    Возвращает список корневых узлов (journey), каждый может содержать
    ``children`` (process → bbb → operation). Используется ``rebuild_tree``
    для клонирования ``<template>``-заготовок.
    """
    if not data or not isinstance(data, dict):
        return []
    tree = data.get("tree")
    if isinstance(tree, list):
        return tree
    # Если tree нет, строим из nodes по известным образцам.
    nodes = data.get("nodes", {})
    if not isinstance(nodes, dict):
        return []
    tree_spec = []
    for node_id, node in nodes.items():
        if not isinstance(node, dict):
            continue
        node_type = _node_type(str(node_id))
        if node_type == "journey":
            tree_spec.append({"id": str(node_id), "type": "journey", "children": []})
    # Упрощённая сборка: процессы под первый journey, BBB под первый процесс.
    journeys = [n for n in tree_spec if n["type"] == "journey"]
    if not journeys:
        return []
    journey = journeys[0]
    processes = []
    for node_id, node in nodes.items():
        if _node_type(str(node_id)) == "process":
            processes.append({"id": str(node_id), "type": "process", "children": []})
    journey["children"] = processes
    for proc in processes:
        bbbs = []
        for node_id, node in nodes.items():
            if _node_type(str(node_id)) == "bbb":
                bbbs.append({"id": str(node_id), "type": "bbb", "children": []})
        proc["children"] = bbbs
        for bbb in bbbs:
            ops = []
            for node_id, node in nodes.items():
                if _node_type(str(node_id)) == "operation":
                    ops.append({"id": str(node_id), "type": "operation"})
            bbb["children"] = ops
        break  # только под первый BBB
    return tree_spec


def passport_registry_rows(data: dict[str, Any] | None) -> list[dict[str, str]]:
    """Строки реестра узлов из ответа агента."""
    if not data or not isinstance(data, dict):
        return []
    rows = data.get("registry", [])
    if not isinstance(rows, list):
        return []
    out: list[dict[str, str]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        out.append({
            "id": str(row.get("id", "")),
            "type": str(row.get("type", "")),
            "name": str(row.get("name", "")),
            "parent": str(row.get("parent", "")),
            "basis": str(row.get("basis", "")),
        })
    return out


# --- финализация HTML: убираем зависимость от DCLogic/support.js -------------
#
# Шаблон v3 — это DCLogic-компонент: Mustache-плейсхолдеры `{{ ... }}`,
# `style-hover` (нестандартный атрибут), внешний `support.js` и класс
# `Component extends DCLogic`. Без движка всё ломается: кнопки не работают,
# узлы не раскрываются, анимация не применяется.
#
# `_finalize_html` делает шаблон самодостаточным:
#   1. Убирает `<script src="./support.js">` и DCLogic-скрипт.
#   2. Заменяет Mustache-плейсхолдеры на статические значения.
#   3. Убирает `data-anim` / `data-uneditable` / `style-hover`.
#   4. Конвертирует `style-hover` в CSS `:hover`.
#   5. Добавляет свой `<script>` для сворачивания/разворачивания узлов.

_MUSTACHE_RE = re.compile(r"\{\{[^}]+\}\}")

# Статические значения для Mustache-плейсхолдеров. Узлы раскрыты по умолчанию
# (кроме operation и guardrail — их много, и они длинные).
_MUSTACHE_VALUES: dict[str, str] = {
    "allLabel": "Свернуть все",
    "panelRows": "0fr",
    "iconOpacity": ".65",
    "grayVal": "1",
    "grayPct": "100%",
    "oJourney": "1fr", "rJourney": "180deg",
    "oProcess": "1fr", "rProcess": "180deg",
    "oBbb": "1fr", "rBbb": "180deg",
    "oOperation": "0fr", "rOperation": "0deg",
    "oGuardrail": "0fr", "rGuardrail": "0deg",
}
# Callback-плейсхолдеры (onClick/onInput) — заменяем на пустые вызовы.
_MUSTACE_CALLBACKS = {
    "tJourney", "tProcess", "tBbb", "tOperation", "tGuardrail",
    "toggleAll", "onGray", "hidePanel", "showPanel",
}

# Базовый CSS для работы без DCLogic: `:hover` вместо `style-hover`,
# сворачивание через класс `.collapsed`.
# Раскладка отчёта: карта дерева → паспорт выбранного узла → реестр.
# Карточки узлов из шаблона остаются в DOM скрытым хранилищем — JS строит
# карту по их вложенности, а карточку выбранного узла клонирует из них.
# Область ограничений и пути потребностей берутся из столбца «Родитель»
# реестра, который построил код.
_INLINE_CSS = """<style data-passport-fix>
/* style-hover → :hover */
.registry tr:hover{background:var(--hov)}
.record:hover{background:var(--hov)}
[data-uneditable]{display:none!important}
/* Исходные карточки узлов — источник данных, на экран не идут. */
#pko-store{display:none}
/* === Карта дерева === */
.pko-map-wrap{overflow-x:auto;padding:8px 0 16px}
.pko-tree,.pko-tree ul{display:flex;justify-content:center;list-style:none;margin:0;padding:22px 0 0;position:relative}
.pko-tree{padding-top:0}
.pko-tree li{display:flex;flex-direction:column;align-items:center;padding:22px 6px 0;position:relative}
.pko-tree>li{padding-top:0}
.pko-tree li::before,.pko-tree li::after{content:'';position:absolute;top:0;right:50%;width:50%;height:22px;border-top:1.5px solid var(--g3)}
.pko-tree li::after{right:auto;left:50%;border-left:1.5px solid var(--g3)}
.pko-tree>li::before,.pko-tree>li::after{display:none}
.pko-tree li:only-child::before,.pko-tree li:only-child::after{border-top:0}
.pko-tree li:only-child::after{border-left:1.5px solid var(--g3)}
.pko-tree li:first-child::before,.pko-tree li:last-child::after{border:0}
.pko-tree li:last-child::before{border-right:1.5px solid var(--g3);border-radius:0 8px 0 0}
.pko-tree li:first-child::after{border-radius:8px 0 0 0}
.pko-tree ul::before{content:'';position:absolute;top:0;left:50%;width:0;height:22px;border-left:1.5px solid var(--g3)}
.pko-box{display:flex;flex-direction:column;gap:4px;min-width:150px;max-width:220px;padding:10px 12px;border:1.5px solid var(--g3);border-radius:12px;background:#fff;cursor:pointer;text-align:left;font-family:inherit;transition:box-shadow .15s ease,border-color .15s ease,transform .15s ease}
.pko-box:hover{border-color:#C17DF7;box-shadow:0 12px 30px -18px rgba(193,125,247,.6);transform:translateY(-2px)}
.pko-box.active{border-color:#C17DF7;background:var(--tp);box-shadow:0 0 0 3px var(--bl)}
.pko-box.scoped{border-style:dashed;border-color:#C17DF7}
.pko-box .t{font-size:11px;font-weight:700;letter-spacing:.06em;color:#fff;background:#C17DF7;border-radius:6px;padding:2px 7px;align-self:flex-start}
.pko-box[data-type=process] .t{background:#7C5CE6}
.pko-box[data-type=bbb] .t{background:#3D8BFD}
.pko-box[data-type=operation] .t{background:#2CB6B0}
.pko-box[data-type=need] .t{background:#E0A100}
.pko-box[data-type=guardrail] .t{background:#E2556F}
.pko-box .n{font-size:13px;font-weight:600;color:#000;line-height:1.25;overflow-wrap:anywhere}
.pko-box .i{font-size:11px;color:var(--g2)}
.pko-lane{display:flex;gap:12px;flex-wrap:wrap;align-items:flex-start;padding:10px 0}
.pko-lane-title{font-size:12px;font-weight:600;color:var(--g2);letter-spacing:.04em;text-transform:uppercase;margin:14px 0 4px}
/* === Карточка выбранного узла === */
#pko-detail{min-height:120px}
#pko-detail .pko-empty{border:1.5px dashed var(--g4);border-radius:16px;padding:28px;color:var(--g2);font-size:17px;text-align:center}
#pko-detail .node{border:1px solid var(--g3);border-radius:16px;background:#fff}
#pko-detail .node .pko-collapsible{grid-template-rows:1fr!important}
#pko-detail .node .children{display:none!important}
#pko-detail .node>div:first-child{cursor:default}
.pko-links{display:flex;gap:8px;flex-wrap:wrap;padding:0 24px 20px;font-size:14px;color:var(--g1)}
.pko-links a{color:#7C5CE6;text-decoration:none;border-bottom:1px dotted #7C5CE6;cursor:pointer}
.pko-links a:hover{border-bottom-style:solid}
/* === Реестр === */
.registry tbody tr{cursor:pointer}
.registry tbody tr.active td{background:var(--tp)}
@media(max-width:768px){.pko-box{min-width:120px;max-width:170px}}
</style>
"""

_INLINE_JS = """<script data-passport-fix>
(function(){
  var TYPE_LABEL={journey:'КП',process:'Процесс',bbb:'BBB',operation:'Операция',need:'Потребность',guardrail:'Ограничение'};
  var TREE_TYPES={journey:1,process:1,bbb:1,operation:1};

  // --- 1. Данные: узлы из DOM (карточки шаблона) + родители из реестра ---
  var store=document.createElement('div'); store.id='pko-store';
  var nodeEls=Array.prototype.slice.call(document.querySelectorAll('.node[id]'));
  var byId={}, order=[];
  nodeEls.forEach(function(el){
    var type=el.getAttribute('data-type')||(el.id.split('-')[0]);
    var nameEl=el.querySelector('[data-fill="name"]');
    var parentEl=el.parentElement?el.parentElement.closest('.node[id]'):null;
    byId[el.id]={id:el.id,type:type,name:(nameEl?nameEl.textContent:el.id).trim(),el:el,
                 parent:parentEl?parentEl.id:null,children:[],scope:[]};
    order.push(el.id);
  });
  order.forEach(function(id){var n=byId[id]; if(n.parent&&byId[n.parent]) byId[n.parent].children.push(id);});
  var registry=document.querySelector('table.registry');
  var rowsById={};
  if(registry){
    Array.prototype.forEach.call(registry.querySelectorAll('tbody tr'),function(tr){
      var idCell=tr.querySelector('[data-col="HTML-id"]'); if(!idCell) return;
      var id=idCell.textContent.trim(); rowsById[id]=tr;
      var parentCell=tr.querySelector('[data-col="Родитель"]');
      if(byId[id]&&(byId[id].type==='guardrail'||byId[id].type==='need')&&parentCell){
        byId[id].scope=parentCell.textContent.split(/[,;·]/).map(function(s){return s.trim()}).filter(function(s){return byId[s]});
      }
    });
  }

  // --- 2. Карта дерева ---
  function box(n){
    var b=document.createElement('button'); b.type='button'; b.className='pko-box'; b.dataset.id=n.id; b.dataset.type=n.type;
    b.innerHTML='<span class="t"></span><span class="n"></span><span class="i"></span>';
    b.querySelector('.t').textContent=TYPE_LABEL[n.type]||n.type;
    b.querySelector('.n').textContent=n.name||'[без названия]';
    var info=n.id;
    if(n.type==='guardrail'&&n.scope.length) info+=' · область: '+n.scope.join(', ');
    if(n.type==='need'&&n.scope.length) info+=' · путь: '+n.scope.join(', ');
    b.querySelector('.i').textContent=info;
    b.addEventListener('click',function(){select(n.id)});
    return b;
  }
  function li(n){
    var item=document.createElement('li'); item.appendChild(box(n));
    if(n.children.length){var ul=document.createElement('ul'); n.children.forEach(function(c){ul.appendChild(li(byId[c]))}); item.appendChild(ul);}
    return item;
  }
  var mapSection=document.createElement('section'); mapSection.id='pko-map'; mapSection.style.marginBottom='56px';
  mapSection.innerHTML='<h2 style="font-size:15px;font-weight:600;color:var(--g2);letter-spacing:.02em;margin-bottom:8px">Карта дерева</h2>'+
    '<p style="font-size:17px;color:var(--g1);max-width:70ch;margin-bottom:8px">Клиентский путь → автономный процесс → BBB → атомарная операция. Потребности сверху, ограничения снизу: у каждого указана область. Клик по узлу открывает его паспорт ниже.</p>';
  var needs=order.filter(function(id){return byId[id].type==='need'});
  var guards=order.filter(function(id){return byId[id].type==='guardrail'});
  var roots=order.filter(function(id){return byId[id].type==='journey'&&!byId[id].parent});
  function lane(title,ids){
    if(!ids.length) return;
    var t=document.createElement('div'); t.className='pko-lane-title'; t.textContent=title; mapSection.appendChild(t);
    var l=document.createElement('div'); l.className='pko-lane'; ids.forEach(function(id){l.appendChild(box(byId[id]))}); mapSection.appendChild(l);
  }
  lane('Потребности клиента',needs);
  var wrap=document.createElement('div'); wrap.className='pko-map-wrap';
  var tree=document.createElement('ul'); tree.className='pko-tree';
  roots.forEach(function(id){tree.appendChild(li(byId[id]))});
  wrap.appendChild(tree); mapSection.appendChild(wrap);
  lane('Ограничения исполнения',guards);

  // --- 3. Карточка выбранного узла ---
  var detailSection=document.createElement('section'); detailSection.style.marginBottom='56px';
  detailSection.innerHTML='<h2 style="font-size:15px;font-weight:600;color:var(--g2);letter-spacing:.02em;margin-bottom:8px">Паспорт узла</h2>'+
    '<div id="pko-detail"><div class="pko-empty">Выберите узел на карте дерева или в реестре</div></div>';
  var detail=detailSection.querySelector('#pko-detail');
  var current=null;
  function link(id,label){var a=document.createElement('a'); a.textContent=label||(id+' «'+byId[id].name+'»'); a.addEventListener('click',function(){select(id)}); return a;}
  function select(id){
    var n=byId[id]; if(!n) return; current=id;
    var clone=n.el.cloneNode(true);
    clone.removeAttribute('id'); clone.classList.remove('collapsed'); clone.removeAttribute('data-anim');
    var head=clone.firstElementChild; if(head){head.removeAttribute('onClick'); head.removeAttribute('onclick'); var arrow=head.querySelector('svg'); if(arrow&&arrow.parentElement) arrow.parentElement.style.display='none';}
    var grid=head?head.nextElementSibling:null; if(grid){grid.classList.add('pko-collapsible'); grid.style.gridTemplateRows='1fr';}
    Array.prototype.forEach.call(clone.querySelectorAll('.children'),function(c){c.parentNode.removeChild(c)});
    var links=document.createElement('div'); links.className='pko-links';
    if(n.parent){links.appendChild(document.createTextNode('Родитель: ')); links.appendChild(link(n.parent));}
    if(n.children.length){links.appendChild(document.createTextNode(' · Дети: ')); n.children.forEach(function(c,i){if(i) links.appendChild(document.createTextNode(', ')); links.appendChild(link(c));});}
    if(n.scope.length){links.appendChild(document.createTextNode(n.type==='need'?' · Закрывает путь: ':' · Действует на: ')); n.scope.forEach(function(c,i){if(i) links.appendChild(document.createTextNode(', ')); links.appendChild(link(c));});}
    var related=guards.filter(function(g){return byId[g].scope.indexOf(id)>=0});
    if(related.length){links.appendChild(document.createTextNode(' · Ограничения: ')); related.forEach(function(c,i){if(i) links.appendChild(document.createTextNode(', ')); links.appendChild(link(c));});}
    clone.appendChild(links);
    detail.innerHTML=''; detail.appendChild(clone);
    Array.prototype.forEach.call(document.querySelectorAll('.pko-box'),function(b){
      b.classList.toggle('active',b.dataset.id===id);
      b.classList.toggle('scoped',n.type==='guardrail'&&n.scope.indexOf(b.dataset.id)>=0);
    });
    Object.keys(rowsById).forEach(function(k){rowsById[k].classList.toggle('active',k===id)});
    if(location.hash!=='#'+id) history.replaceState(null,'','#'+id);
  }
  Object.keys(rowsById).forEach(function(id){rowsById[id].addEventListener('click',function(){select(id); detailSection.scrollIntoView({behavior:'smooth',block:'start'});});});

  // --- 4. Перестановка разделов: карта → узел → реестр; исходное дерево в хранилище ---
  var treeSection=nodeEls.length?nodeEls[0].closest('section'):null;
  var registrySection=registry?registry.closest('section'):null;
  var anchor=registrySection||treeSection;
  if(anchor&&anchor.parentNode){
    anchor.parentNode.insertBefore(mapSection,anchor);
    anchor.parentNode.insertBefore(detailSection,anchor);
    if(registrySection){anchor.parentNode.insertBefore(registrySection,detailSection.nextSibling);}
  }
  if(treeSection){treeSection.parentNode.insertBefore(store,treeSection); store.appendChild(treeSection);}
  var oldBtn=document.querySelector('[data-toggle-all]'); if(oldBtn) oldBtn.style.display='none';

  var initial=location.hash&&byId[location.hash.slice(1)]?location.hash.slice(1):(roots[0]||order[0]);
  if(initial) select(initial);
  window.addEventListener('hashchange',function(){var id=location.hash.slice(1); if(byId[id]&&id!==current) select(id);});
})();
</script>
"""


def _finalize_html(html: str) -> str:
    """Сделать HTML самодостаточным: убрать DCLogic, заменить Mustache, добавить JS.

    Шаблон v3 рассчитан на внешний движок DCLogic (`support.js`). В
    статичном файле паспорта этого движка нет — функция убирает зависимость
    и добавляет собственный минималистичный JS.
    """
    # 1. Убираем внешний скрипт support.js и DCLogic-блок.
    html = re.sub(r'<script\s+src="./support\.js">\s*</script>', '', html)
    html = re.sub(
        r'<script type="text/x-dc"[^>]*>.*?</script>',
        '', html, flags=re.DOTALL,
    )

    # 2. Заменяем Mustache-плейсхолдеры.
    def replace_mustache(m: re.Match) -> str:
        key = m.group(0).strip("{} ").strip()
        if key in _MUSTACE_CALLBACKS:
            return ""  # onClick="{{ tJourney }}" → onClick=""
        return _MUSTACHE_VALUES.get(key, "")

    html = _MUSTACHE_RE.sub(replace_mustache, html)

    # 3. Убираем data-anim (анимация не нужна в статике).
    html = re.sub(r'\s+data-anim\b', '', html)

    # 4. Убираем style-hover (нестандартный атрибут) — hover в CSS.
    html = re.sub(r'\s+style-hover="[^"]*"', '', html)

    # 5. Кнопке "Свернуть/Развернуть все" добавляем data-toggle-all.
    html = html.replace(
        'onClick="" style="border:0;border-radius:8px;background:#000',
        'data-toggle-all="" style="border:0;border-radius:8px;background:#000',
        1,
    )

    # 6. Убираем упоминания параграфов стандарта из видимых элементов.
    #    «§ 4.2.1», «§ 4.2 · 8 полей», «(§ 3.2.1)», «§§ 3.2, 4.0–4.6» и т.д.
    #    В заголовках полей: «<span ...>§ 4.2.1</span>» → убираем span целиком.
    html = re.sub(
        r'<span[^>]*>§+\s*[\d.,–-]*</span>',
        '', html,
    )
    # Footer с упоминанием стандарта целиком.
    html = re.sub(
        r'Источник:\s*Стандарт автономного процесса[^<]*',
        '', html,
    )
    # В тексте заголовков узлов: «§ 4.2 · 8 полей» → «8 полей»
    html = re.sub(r'§+\s*[\d.]+\s*·\s*', '', html)
    # Одиночные «§ 4.5», «§§ 3.2», «§ 4.0» в видимом тексте.
    html = re.sub(r'§+\s*[\d.,–-]+', '', html)

    # 7. Добавляем CSS и JS перед </body>.
    inject = _INLINE_CSS + "\n" + _INLINE_JS
    html = html.replace("</body>", inject + "\n</body>", 1)

    return html

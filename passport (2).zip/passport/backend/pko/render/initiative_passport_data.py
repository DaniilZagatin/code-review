"""Контракт паспорта инициативы (initiative-1.0.0): ProgressModel + Extraction → dict.

Переводит факты кода и оценки агента на язык клиента по правилам
`initiative_FILL_SPEC.md`. В отличие от паспорта системы v3 (сырьё для
витрины сравнения), паспорт инициативы — самодостаточное описание одной
инициативы, которое читается без репозитория.

Четыре признака (FILL_SPEC §8):
  заявлено           — из образа результата / business_intent.yaml
  наблюдается        — переведено из кода
  требует подтверждения — агент вывел сам то, что должен был заявить владелец
  не заполнено       — нет ни источника, ни возможности вывести

Без процентов, без технических терминов, без оценок. Состояние — словами:
работает · работает с оговорками · частично · не реализовано.
"""

from __future__ import annotations

import time
from typing import Any

from pko.extractors.runner import Extraction
from pko.progress.plan_input import PlanInput
from pko.progress.schema import ProgressModel, STATUS_LABEL

PASSPORT_VERSION = "initiative-1.0.0"

_DECLARED = "заявлено"
_OBSERVED = "наблюдается"
_NEEDS_CONFIRM = "требует подтверждения"
_EMPTY = "не заполнено"

_STATUS_WORDS = {
    "done": "работает",
    "limited": "работает с оговорками",
    "unused": "работает с оговорками",
    "partial": "частично",
    "planned": "не реализовано",
    "blocked": "не реализовано",
}


def build_initiative_passport_data(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    tree,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str = "",
) -> dict[str, Any]:
    """Собрать словарь всех переменных паспорта инициативы.

    Источники: `declared` (plan_input), `observed` (extraction),
    `assessed` (model verdicts). Чего нет — `не заполнено`, но не пусто.
    """
    ctx = plan_input.context
    initiative_name = ctx.get("project_name") or repo_name or "—"
    journey_name = ctx.get("client_path_name") or "—"
    generated_at = time.strftime("%Y-%m-%d %H:%M")

    stages_data = _stages(model, plan_input)
    promises = _promises(model, plan_input)
    active_stage_titles = [
        s["title"] for s in stages_data
        if s["active"] in ("полностью", "частично")
    ]

    data: dict[str, Any] = {
        # --- шапка ---
        "initiative_name": initiative_name,
        "generated_at": generated_at,
        "journey_name": journey_name,
        "one_liner": ctx.get("before") or _NEEDS_CONFIRM,
        "client_situation": ctx.get("client_path_name") or _NEEDS_CONFIRM,
        "stage_list": ", ".join(plan_input.stages) if plan_input.stages else _EMPTY,
        "active_stages": ", ".join(active_stage_titles) if active_stage_titles else _EMPTY,
        "execution_type": _execution_type(extraction),
        "business_owner": _NEEDS_CONFIRM,
        "lifecycle_stage": _NEEDS_CONFIRM,
        "b": _NEEDS_CONFIRM,

        # --- 1. Клиент и потребность ---
        "client_situation_long": ctx.get("before") or _NEEDS_CONFIRM,
        "need": _promise_summary(model) or _NEEDS_CONFIRM,
        "recognition_signals": _observed_or_empty(extraction, "ROUTE"),
        "who_initiates": _execution_type(extraction),
        "when_not_to_act": _NEEDS_CONFIRM,

        # --- 2. Результат ---
        "initial_state": ctx.get("before") or _NEEDS_CONFIRM,
        "target_state": ctx.get("after") or _NEEDS_CONFIRM,
        "client_success_signal": _NEEDS_CONFIRM,
        "outcome_achieved": _outcome(model, "done", "limited"),
        "outcome_handled": _outcome(model, "partial"),
        "outcome_unknown": _outcome(model, "planned", "blocked"),

        # --- 3. Этапы ---
        "stages": stages_data,

        # --- 4. Обещания ---
        "promises": promises,

        # --- 5. Входы/выходы ---
        "input": _entry_points(extraction),
        "receives_from": _external_deps(extraction),
        "output": _exit_points(extraction),
        "hands_over": _NEEDS_CONFIRM,
        "external_dependencies": _external_deps(extraction),

        # --- 6. Общие блоки ---
        "shared_blocks": _shared_blocks(extraction),

        # --- 7. Ценность ---
        "value": _value_rows(model, plan_input),
        "how_measure_achievement": _test_narrative(extraction, "achievement"),
        "how_measure_handled": _test_narrative(extraction, "handled"),
        "how_measure_relevance": _NEEDS_CONFIRM,
        "how_measure_economics": _EMPTY,

        # --- 8. Границы и защита ---
        "commitments": _commitments(extraction),
        "does_not_do": _NEEDS_CONFIRM,
        "human_required": _human_required(extraction),

        # --- 9. Не так, как можно подумать ---
        "caveats": _caveats(model, extraction),

        # --- 10. Решения владельца ---
        "owner_decisions": _owner_decisions(model, plan_input),

        # --- Основание ---
        "repo": repo_name or "—",
        "commit": commit or "—",
        "commit_date": _EMPTY,
        "result_image_ref": "образ результата инициативы",
        "scanned": f"{extraction.coverage.files_analyzed} файлов из {extraction.coverage.files_total}",
        "not_scanned": ", ".join(extraction.coverage.skipped_globs[:6]) or "нет",
        "filled_by_owner": "этапы пути, название инициативы",
        "needs_confirmation": "владелец результата, стадия, метрики ценности",
        "unfilled": "риски, бюджет, команда, срок",
        "key_evidence": _key_evidence(model),
        "key_absences": _key_absences(model, extraction),
        "self_notes": list(model.gaps)[:10] or ["замечаний нет"],
        "tech_passport_ref": _EMPTY,
    }
    return data


# --- раздел 3: этапы ---------------------------------------------------------

def _stages(model: ProgressModel, plan_input: PlanInput) -> list[dict[str, Any]]:
    """Раздел 3 — по этапам из образа результата, дословно.

    Статусы агента привязаны к группам буллитов (PlanItem), а не к этапам
    пути (plan_input.stages) — это разные срезы. Поэтому «работает/нет» по
    этапу — агрегированная оценка: если хотя бы одна группа буллитов
    подтверждает работу, этап помечается действующим.
    """
    has_work = any(
        c.applicable and c.status in ("done", "limited", "unused")
        for v in model.verdicts for c in v.criteria
    )
    has_partial = any(
        c.applicable and c.status == "partial"
        for v in model.verdicts for c in v.criteria
    )
    has_missing = any(
        c.applicable and c.status in ("planned", "blocked")
        for v in model.verdicts for c in v.criteria
    )

    rows: list[dict[str, Any]] = []
    for i, stage_name in enumerate(plan_input.stages, start=1):
        if has_work and not has_missing:
            active = "полностью"
        elif has_work:
            active = "частично"
        else:
            active = "не действует"
        works = "работает" if has_work else "—"
        missing = "не реализовано" if has_missing else ("—" if has_work else _EMPTY)
        rows.append({
            "order": i,
            "title": stage_name,
            "active": active,
            "what_happens": works if works != "—" else _EMPTY,
            "client_sees": works if works != "—" else _EMPTY,
            "client_decides": _NEEDS_CONFIRM,
            "moments": _EMPTY,
            "actor": _NEEDS_CONFIRM,
            "works_now": works,
            "missing": missing,
            "basis": _OBSERVED if has_work else _EMPTY,
        })
    return rows


def _find_item_by_title(model: ProgressModel, title: str) -> Any:
    for item in model.items.values():
        if item.title == title:
            return item
    return None


def _find_verdict_by_item_id(model: ProgressModel, item_id: str) -> Any:
    for v in model.verdicts:
        if v.item_id == item_id:
            return v
    return None


def _stage_active(verdict: Any) -> str:
    rated = [c for c in verdict.criteria if c.applicable]
    if not rated:
        return "не действует"
    done_like = sum(1 for c in rated if c.status in ("done", "limited", "unused"))
    if done_like == len(rated):
        return "полностью"
    if done_like > 0:
        return "частично"
    return "частично"


def _stage_works_missing(verdict: Any) -> tuple[str, str]:
    works_parts: list[str] = []
    missing_parts: list[str] = []
    for c in verdict.criteria:
        if not c.applicable:
            continue
        words = _STATUS_WORDS.get(c.status, "—")
        if c.status in ("done", "limited", "unused"):
            works_parts.append(words)
        else:
            missing_parts.append(words)
    works = "; ".join(works_parts) if works_parts else "—"
    missing = "; ".join(missing_parts) if missing_parts else "—"
    return works, missing


def _execution_type_from_verdict(verdict: Any) -> str:
    return _NEEDS_CONFIRM


# --- раздел 4: обещания ------------------------------------------------------

def _promises(model: ProgressModel, plan_input: PlanInput) -> list[dict[str, Any]]:
    """Обещания образа результата — дословно, с состоянием словами."""
    rows: list[dict[str, Any]] = []
    n = 1
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        for idx, text in enumerate(item.criteria, start=1):
            c = v.criteria[idx - 1] if idx <= len(v.criteria) else None
            if c and not c.applicable:
                state = "не применимо"
                how_looks = c.na_reason or _EMPTY
                gap = _EMPTY
            elif c:
                state = _STATUS_WORDS.get(c.status, _EMPTY)
                how_looks = c.how_text or _EMPTY
                gap = c.proof_text or _EMPTY
            else:
                state = _EMPTY
                how_looks = _EMPTY
                gap = _EMPTY
            stage_names = item.title
            rows.append({
                "n": n,
                "text": text,
                "state": state,
                "how_it_looks": how_looks,
                "gap": gap,
                "stages": stage_names,
            })
            n += 1
    return rows


# --- раздел 5: входы/выходы --------------------------------------------------

def _external_deps(extraction: Extraction) -> str:
    ext = extraction.by_kind("EXTERNAL")
    if not ext:
        return _NEEDS_CONFIRM
    names = sorted({f.key for f in ext[:10]})
    return ", ".join(names[:5])


def _exit_points(extraction: Extraction) -> str:
    tools = extraction.by_kind("TOOL")
    routes = extraction.by_kind("ROUTE")
    if not tools and not routes:
        return _NEEDS_CONFIRM
    names = sorted({f.key for f in (routes + tools)[:10]})
    return ", ".join(names[:5])


def _entry_points(extraction: Extraction) -> str:
    routes = extraction.by_kind("ROUTE")
    if not routes:
        return _NEEDS_CONFIRM
    names = sorted({f.key for f in routes[:5]})
    return ", ".join(names)


# --- раздел 6: общие блоки ---------------------------------------------------

def _shared_blocks(extraction: Extraction) -> list[dict[str, Any]]:
    """Раздел 6 — переиспользуемые части. Из функций с докстроками, не путей."""
    funcs = [
        f for f in extraction.by_kind("FUNCTION")
        if f.value and isinstance(f.value, dict) and f.value.get("doc")
    ][:8]
    rows: list[dict[str, Any]] = []
    for f in funcs:
        doc = str(f.value.get("doc") or "")[:120]
        rows.append({
            "name": f.key,
            "does": doc,
            "reuse": _NEEDS_CONFIRM,
            "basis": _OBSERVED,
        })
    if not rows:
        rows.append({"name": _EMPTY, "does": _EMPTY, "reuse": _EMPTY, "basis": _EMPTY})
    return rows


# --- раздел 7: ценность ------------------------------------------------------

def _value_rows(model: ProgressModel, plan_input: PlanInput) -> list[dict[str, Any]]:
    ctx = plan_input.context
    rows: list[dict[str, Any]] = []
    if ctx.get("before"):
        rows.append({"who": "клиенту", "text": ctx["before"], "basis": _DECLARED})
    if ctx.get("after"):
        rows.append({"who": "клиенту", "text": ctx["after"], "basis": _DECLARED})
    if model.summary and model.summary.match_note:
        rows.append({
            "who": "Сберу",
            "text": model.summary.match_note,
            "basis": _NEEDS_CONFIRM,
        })
    if not rows:
        rows.append({"who": "клиенту", "text": _EMPTY, "basis": _EMPTY})
    return rows


def _test_narrative(extraction: Extraction, kind: str) -> str:
    tests = extraction.by_kind("TEST") + extraction.by_kind("TEST_REPORT")
    if not tests:
        return "не измеряется"
    return f"найдено {len(tests)} тест(ов); детальное покрытие не разобрано"


# --- раздел 8: обязательства -------------------------------------------------

def _commitments(extraction: Extraction) -> list[dict[str, Any]]:
    """Раздел 8 — обязательства перед клиентом, не технические лимиты."""
    rows: list[dict[str, Any]] = [
        {
            "text": "Клиент всегда может отказаться от предложения",
            "how": "в сценарии есть ветка отказа",
            "state": _NEEDS_CONFIRM,
        },
        {
            "text": "Клиенту объясняется, почему предложено именно это",
            "how": "в сценарии есть блок объяснения выбора",
            "state": _NEEDS_CONFIRM,
        },
    ]
    return rows


def _human_required(extraction: Extraction) -> str:
    routes = extraction.by_kind("ROUTE")
    if not routes:
        return _EMPTY
    return _NEEDS_CONFIRM


# --- раздел 9: не так, как можно подумать ------------------------------------

def _caveats(model: ProgressModel, extraction: Extraction) -> list[str]:
    caveats: list[str] = []
    for v in model.verdicts:
        for c in v.criteria:
            if not c.applicable:
                continue
            if c.status == "unused":
                caveats.append(
                    f"Часть кода написана и работает, но в текущем сценарии не вызывается"
                )
            if c.status == "partial":
                caveats.append(
                    f"Обещание звучит как готовое решение, но реализовано частично"
                )
    seen = set()
    unique = []
    for c in caveats:
        if c not in seen:
            seen.add(c)
            unique.append(c)
    return unique[:5] or ["существенных расхождений не найдено"]


# --- раздел 10: решения владельца --------------------------------------------

def _owner_decisions(model: ProgressModel, plan_input: PlanInput) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for v in model.verdicts:
        for c in v.criteria:
            if not c.applicable:
                rows.append({
                    "text": "Подтвердить, что пункт не относится к этой инициативе",
                    "why": c.na_reason or "агент отметил как неприменимый",
                })
    if not model.verdicts:
        rows.append({"text": "Заполнить образ результата", "why": "без него оценка невозможна"})
    return rows[:5]


# --- основание ---------------------------------------------------------------

def _key_evidence(model: ProgressModel) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        for idx, c in enumerate(v.criteria, start=1):
            if not c.applicable or not c.evidence:
                continue
            ref = c.evidence[0]
            if not ref.verified:
                continue
            rows.append({
                "claim": item.criteria[idx - 1] if idx <= len(item.criteria) else item.title,
                "evidence": ref.note or ref.basis or "ссылка на код",
                "where": f"{ref.path}:{ref.line}" if ref.line else ref.path,
            })
            if len(rows) >= 10:
                return rows
    if not rows:
        rows.append({"claim": "оценки агента", "evidence": "без подтверждённых ссылок", "where": "—"})
    return rows


def _key_absences(model: ProgressModel, extraction: Extraction) -> list[str]:
    absences: list[str] = []
    for v in model.verdicts:
        for c in v.criteria:
            if c.applicable and c.status == "planned":
                absences.append("обещанное не найдено в коде")
                break
    if not extraction.by_kind("TEST"):
        absences.append("тесты не найдены")
    return absences[:5] or ["существенных отсутствий не найдено"]


# --- вспомогательные ---------------------------------------------------------

def _execution_type(extraction: Extraction) -> str:
    routes = extraction.by_kind("ROUTE")
    if routes:
        return "проактивное действие"
    tools = extraction.by_kind("TOOL")
    if tools:
        return "реактивное действие"
    return _NEEDS_CONFIRM


def _promise_summary(model: ProgressModel) -> str:
    if not model.verdicts:
        return ""
    parts: list[str] = []
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        done = sum(1 for c in v.criteria if c.applicable and c.status == "done")
        total = sum(1 for c in v.criteria if c.applicable)
        if total:
            parts.append(f"{item.title}: {done} из {total} работает")
    return "; ".join(parts[:3])


def _outcome(model: ProgressModel, *statuses: str) -> str:
    for v in model.verdicts:
        for c in v.criteria:
            if c.applicable and c.status in statuses:
                if "done" in statuses or "limited" in statuses:
                    return "результат достигается по подтверждённым пунктам"
                if "partial" in statuses:
                    return "часть пунктов реализована частично, сквозной путь не всегда проходит"
                return "часть пунктов не реализована"
    return _EMPTY


def _observed_or_empty(extraction: Extraction, kind: str) -> str:
    facts = extraction.by_kind(kind)
    if not facts:
        return _EMPTY
    return ", ".join(f.key for f in facts[:5])

"""Рендер паспорта проекта в Markdown по шаблону `passport_template.md`.

Шаблон — подмножество Mustache/Handlebars: `{{var}}`, `{{#each list}}…{{/each}}`,
`{{#if x}}…{{else}}…{{/if}}`, `{{this}}`, `{{this.field}}`. Своё окружение, без
сторонней зависимости: PKO не тянет в requirements ни chevron, ни pystache, и
вводить её ради одного шаблона не стоит.

Шаблон лежит в корне репозитория (`passport_template.md`) — тот же файл, что
редактирует владелец. Читается по пути относительно модуля, как
`progress_report.py` читает `frontend-app/dist/index.html`.

Контракт данных собирает `render/passport_data.py`; здесь — только подстановка.
Никаких вычислений статуса, готовности или решения: всё приходит готовыми
значениями, как у дашборда. Принцип «LLM предлагает, код проверяет» тут только
усиливается (FILL_SPEC разводит `declared`/`observed`/`assessed`/`derived` —
четыре источника, которые уже есть в PKO).
"""

from __future__ import annotations

import html
import re
from pathlib import Path
from typing import Any

# Корневой шаблон — единственный источник, редактируется владельцем.
# `render/passport_md.py` → `render/` → `pko/` → `backend/` → корень репо.
_TEMPLATE_PATH = Path(__file__).resolve().parents[3] / "passport_template_v3.md"


def render_passport_md(data: dict[str, Any]) -> str:
    """Собрать Markdown-паспорт из словаря `build_passport_data`.

    `data` — плоский контекст верхнего уровня; `{{#each}}`/`{{#if}}` работают
    по его ключам и по полям элементов. Значения подставляются как строки;
    `None` и отсутствие поля рендерятся как пустая строка, чтобы в таблицах не
    оставалось литералов `None`.
    """
    template = _TEMPLATE_PATH.read_text(encoding="utf-8")
    return _Renderer().render(template, data)


class _Renderer:
    """Минимальный Mustache-рендерер: переменные, each, if/else.

    Парсит шаблон один раз в список узлов и рендерит по контексту. Блоки
    `{{#each}}`/`{{#if}}` разбираются поиском парных `{{/…}}` с учётом
    вложенности — рекурсивный спуск, а не регексп «от первого до последнего».
    """

    _TAG = re.compile(r"{{\s*(.*?)\s*}}")

    def render(self, template: str, context: Any) -> str:
        nodes = _parse(template)
        return _render_nodes(nodes, context)


# --- парсинг шаблона в дерево узлов -----------------------------------------
# Узел — кортеж:
#   ("text", str)
#   ("var", name)               — {{name}} / {{this}} / {{this.field}}
#   ("each", name, [nodes], [else_nodes])  — {{#each name}}…{{else}}…{{/each}}
#   ("if", name, [nodes], [else_nodes])    — {{#if name}}…{{else}}…{{/if}}


def _parse(template: str) -> list[tuple]:
    nodes, _, _ = _parse_block(template, 0, None)
    return nodes


def _parse_block(text: str, start: int, end_tag: str | None):
    """Разобрать фрагмент до парного `{{/end_tag}}` (или до конца, если tag None).

    Возвращает `(then_nodes, else_nodes, next_pos)`. `else_nodes` пуст, если
    ветки `{{else}}` не было. Унифицированный возврат — раньше тут был баг:
    без `else` возвращался плоский список, и `body[0]`/`body[1]` брали первые
    два узла вместо пары «тело/иначе».
    """
    then_nodes: list[tuple] = []
    pos = start
    while True:
        match = _Renderer._TAG.search(text, pos)
        if match is None:
            # Дошли до конца без закрывающего тега — хвост как текст.
            if pos < len(text):
                then_nodes.append(("text", text[pos:]))
            return then_nodes, [], len(text)

        # Текст перед тегом.
        if match.start() > pos:
            then_nodes.append(("text", text[pos:match.start()]))

        inner = match.group(1).strip()
        end = match.end()

        # Закрывающий тег — выходим из текущего блока.
        if inner.startswith("/"):
            return then_nodes, [], end

        # {{#each name}} — открыть блок итерации.
        if inner.startswith("#each"):
            name = inner[len("#each"):].strip()
            body, else_body, after = _parse_block(text, end, "each")
            then_nodes.append(("each", name, body, else_body))
            pos = after
            continue

        # {{#if name}} — открыть условный блок.
        if inner.startswith("#if"):
            name = inner[len("#if"):].strip()
            body, else_body, after = _parse_block(text, end, "if")
            then_nodes.append(("if", name, body, else_body))
            pos = after
            continue

        # {{else}} — разделяет ветку then/else. Накопленные then_nodes — это
        # первая ветка; разбираем вторую и возвращаем обе.
        if inner == "else":
            else_body, _, after = _parse_block(text, end, end_tag)
            return then_nodes, else_body, after

        # Обычная переменная.
        then_nodes.append(("var", inner))
        pos = end


def _render_nodes(nodes: list[tuple], context: Any) -> str:
    out: list[str] = []
    for node in nodes:
        kind = node[0]
        if kind == "text":
            out.append(node[1])
        elif kind == "var":
            out.append(_render_var(node[1], context))
        elif kind == "each":
            _, name, body, else_body = node
            value = _lookup(name, context)
            items = value if isinstance(value, (list, tuple)) else []
            if items:
                for item in items:
                    out.append(_render_nodes(body, item))
            elif else_body:
                out.append(_render_nodes(else_body, context))
        elif kind == "if":
            _, name, body, else_body = node
            if _truthy(_lookup(name, context)):
                out.append(_render_nodes(body, context))
            elif else_body:
                out.append(_render_nodes(else_body, context))
    return "".join(out)


def _render_var(name: str, context: Any) -> str:
    value = _lookup(name, context)
    if value is None:
        return ""
    text = str(value)
    # Шаблон паспорта — Markdown для человека, не HTML: экранировать `<>` не
    # нужно (в отличие от dashboard_html), но убираем потенциальные
    # инъекции Markdown-разметки из текстов агента минимально — только
    # обратные апострофы, чтобы кодовый спан не ломал таблицу.
    return text


def _lookup(name: str, context: Any) -> Any:
    """Добраться до значения по имени с поддержкой `this` и точек.

    `this` — сам текущий контекст (элемент списка в `each` или корневой dict).
    `this.field` — поле контекста. `name.field` — вложенный путь от контекста.
    """
    if name == "this":
        return context
    parts = name.split(".")
    head = parts[0]
    if head == "this":
        current: Any = context
    else:
        current = _field(context, head)
    for part in parts[1:]:
        current = _field(current, part)
        if current is None:
            return None
    return current


def _field(obj: Any, key: str) -> Any:
    if isinstance(obj, dict):
        return obj.get(key)
    # Строки-элементы списка в `{{#each}}`: `this` — сама строка, полей нет.
    if isinstance(obj, (str, int, float, bool)):
        return None
    return getattr(obj, key, None)


def _truthy(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, (list, tuple, dict, str)):
        return bool(value)
    return True


def safe_md_cell(value: Any) -> str:
    """Значение в ячейку Markdown-таблицы: `None` → пусто, `|` экранирован.

    Труба в Markdown разделяет колонки: незамаскированная `|` в данных агента
    ломает таблицу. Внутри кодовых блоков труба безопасна, но в ячейках таблиц
    её надо экранировать.
    """
    if value is None:
        return ""
    text = str(value).replace("\n", " ").replace("\r", " ").strip()
    return text.replace("|", "\\|")


def md_inline(value: Any) -> str:
    """Простой текст для заголовков/абзацев: переносов строк быть не должно."""
    if value is None:
        return ""
    return str(value).replace("\n", " ").replace("\r", " ").strip()

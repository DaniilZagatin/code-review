"""Контракт паспорта системы v3: `ProgressModel + Extraction + plan_input` → dict.

Аналог `render/dashboard_data.py` для паспорта: один модуль собирает данные,
рендерер (`passport_md.py`) только подставляет. Никаких вычислений статуса,
готовности или решения вне `progress/schema.py`.

v3 (схема 3.0.0) — другая семантика, чем v2: паспорт теперь «сырьё для витрины
сравнения», а не пакет фактов для анализа рисков. Появились разделы 4 (описание
системы), 5–6 (источники и свидетельства), 9 (сверх плана), 14 (каркас
витрины), 15 (эталон), 16 (правила счёта). Убраны Gate-проверки и вывод агента:
паспорт — только факты, оценку делает анализирующая модель.

Четыре источника по FILL_SPEC v3: `declared` (текст инициативы), `observed`
(экстракторы + компоновщики), `assessed` (статусы буллитов), `derived`
(правила счёта). Чего нет — `не искали`/`не найдено`, но не пусто (FILL_SPEC v3 §1).
"""

from __future__ import annotations

import time
from typing import Any

from pko.extractors.absences import build_absences
from pko.extractors.controls import build_controls
from pko.extractors.execution_map import build_execution_map
from pko.extractors.excerpts import build_excerpts
from pko.extractors.runner import Extraction
from pko.progress.plan_input import PlanInput
from pko.progress.schema import (
    READY_THRESHOLD,
    ProgressModel,
    compute_decision,
    decision_reason,
)

PASSPORT_VERSION = "3.0.0"
PASSPORT_SCHEMA = "3.0.0"


def build_passport_data(
    model: ProgressModel,
    plan_input: PlanInput,
    repo_name: str,
    tree,
    extraction: Extraction,
    commit: str,
    branch: str,
    model_name: str = "",
    prev_passport: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Собрать словарь всех разделов паспорта v3."""
    execution = build_execution_map(extraction)
    controls = build_controls(extraction, tree)
    excerpts = build_excerpts(model.verdicts, tree, extraction.by_kind("PROMPT"))
    absences = build_absences(extraction, tree, execution, controls)

    ctx = plan_input.context
    project_name = ctx.get("project_name") or repo_name or "—"
    journey_name = ctx.get("client_path_name") or "—"
    generated_at = time.strftime("%Y-%m-%d %H:%M")
    subject_slug = _slug(journey_name)
    commit_short = (commit or "")[:8] or "—"

    data: dict[str, Any] = {
        # --- шапка ---
        "project_name": project_name,
        "commit": commit or "—",
        "generated_at": generated_at,
        "payload_completeness": _completeness(model, extraction),

        # --- 1.1 ---
        "subject_slug": subject_slug,
        "commit_short": commit_short,
        "passport_version": PASSPORT_VERSION,
        "project_class": "autonomous-process",
        "application_name": project_name,
        "subject_name": journey_name,
        "baseline_label": "план инициативы",
        "repo_url": repo_name or "—",
        "branch": branch or "—",
        "input_hashes": "не искали",

        # --- 1.2 ---
        "truncated": "нет",
        "truncation_note": "",
        "files_total": extraction.coverage.files_total,
        "files_scanned": extraction.coverage.files_analyzed,
        "scan_exclusions": ", ".join(extraction.coverage.skipped_globs[:6]) or "нет",
        "plan_docs_complete": "да" if plan_input.source_text else "нет",
        "unfilled_layers": "этапы пути и способности — частично (берутся из замысла)",
        "extractors": _extractors_table(extraction),

        # --- 2. Контекст ---
        "lifecycle_stage": "не искали",
        "regulatory_context": "не искали",
        "data_classes": "не искали",
        "execution_environment": "не искали",
        "team": "не искали",
        "deadline": "не искали",
        "budget": "не искали",
        "fixed_constraints": "не искали",
        "external_dependencies": "не искали",
        "audience": "руководитель проекта",

        # --- 3. Замысел ---
        "result_user": ctx.get("client_path_name") or "не искали",
        "client_label": journey_name,
        "purpose": project_name,
        "focus": "не искали",
        "initial_state": ctx.get("before") or "не искали",
        "target_state": ctx.get("after") or "не искали",
        "success_criteria": "не искали",
        "stop_criteria": "не искали",
        "review_scope": "код репозитория по коммиту",
        "baseline_now": ctx.get("before") or "не искали",
        "target_effect": "не искали",

        # --- 4. Как система работает сегодня ---
        "system_summary": _system_summary(model, plan_input),
        "components": _components(extraction),
        "main_scenario": _main_scenario(model, plan_input),
        "wrong_assumptions": [],
        "glossary": [],

        # --- 5. Источники ---
        "sources": _sources(plan_input, repo_name, commit),
        "source_documents": _source_documents(plan_input),

        # --- 6. Свидетельства ---
        "evidence": _evidence(model),

        # --- 7. Требования плана ---
        "requirements": _requirements(model, plan_input),
        "code_refs": _code_refs(model),
        "not_applicable": _not_applicable(model),

        # --- 8. Карта исполнения ---
        "entries": execution.entries,
        "units": execution.units,
        "edges": execution.edges,
        "exits": execution.exits,
        "execution_ascii": execution.ascii,

        # --- 9. Сверх плана ---
        "unplanned_behaviors": _unplanned(extraction, model),

        # --- 10. Контроли ---
        "controls": _numbered_controls(controls),
        "irreversible_effects": controls.irreversible_effects,
        "consumption_limits": controls.management.get("consumption_limits", "не искали"),
        "kill_switch": controls.management.get("kill_switch", "не искали"),
        "rollback": controls.management.get("rollback", "не искали"),
        "degradation": controls.management.get("degradation", "не искали"),

        # --- 11. Отсутствия ---
        "absences": absences,

        # --- 12. Выдержки ---
        "excerpts": excerpts,

        # --- 13. Испытания ---
        "scenarios": _scenarios(extraction),
        "test_coverage_narrative": _test_narrative(extraction),
        "ci_status": "не искали",
        "reproducibility": "не искали",
        "runs_count": "не искали",
        "runtime_window": "не искали",
        "success_rate": "не искали",
        "control_hits": "не искали",
        "latency": "не искали",
        "cost_per_run": "не искали",
        "incidents": "не искали",

        # --- 14. Каркас витрины ---
        "journey_steps": _journey_steps(plan_input),
        "capabilities": _capabilities(model, plan_input),

        # --- 15. Эталон ---
        "products": [],
        "best_practices": [],
        "reference_checklist": _reference_checklist(),
        "expected_aspect_count": "3–6 на способность",
        "aspect_granularity": "функциональные и НФТ раздельно",
        "nfr_definition": "не функциональные: производительность, надёжность, безопасность",
        "out_of_comparison": "не искали",
        "allow_model_knowledge": "да",

        # --- 16. Правила счёта ---
        "plan_unit": "уникальный функциональный аспект",
        "plan_weights": "covered 1 · partial 0.5 · not_covered 0 · unknown 0",
        "unknown_handling": "включать как ноль",
        "nfr_handling": "исключать из процента",
        "impl_unit": "уникальное требование плана",
        "impl_weights": "по шкале готовности требования (done/limited/unused/partial/planned)",
        "na_nd_handling": "na исключать, nd включать как ноль",
        "decimals": "0",
        "prevent_false_complete": "да",
        "scoring_version": "1.0.0",

        # --- 17. Ответственность ---
        "business_owner": "не искали",
        "codeowners": _codeowners(extraction),
        "gate_role": "не искали",
        "on_call": "не искали",
        "kill_switch_owner": "не искали",

        # --- 18. Риски ---
        "risks": [],

        # --- 19. Отвергнутые ---
        "rejected": [],

        # --- 20. Динамика ---
        **_dynamics(prev_passport, model),

        # --- 21. Вопросы ---
        "open_questions": [],

        # --- 22. Самозамечания ---
        "gaps": list(model.gaps) + list(extraction.notes),

        # --- 23. Метаданные ---
        "model_name": model_name or "не указана",
        "steps_done": "не искали",
        "steps_limit": "не искали",
        "files_read": "не искали",
        "plan_docs_read": "1" if plan_input.source_text else "0",
        "labeling_accuracy": "не искали",
        "session_notes": "; ".join(list(model.gaps)[:10])[:1000] or "нет",
    }
    return data


# --- раздел 4: описание системы ---------------------------------------------
def _system_summary(model: ProgressModel, plan_input: PlanInput) -> str:
    """4.1 — что делает система, 4–6 абзацев. Из модели и контекста."""
    lines: list[str] = []
    ctx = plan_input.context
    name = ctx.get("project_name") or "проект"
    journey = ctx.get("client_path_name") or "клиентский путь"
    lines.append(f"{name} — инициатива в клиентском пути «{journey}».")
    rated = model.rated_criteria()
    done = sum(1 for c in rated if c.status == "done")
    total = len(rated)
    lines.append(
        f"Из {total} применимых требований плана реализовано полностью: {done}. "
        f"Готовность прототипа: {model.readiness}%."
    )
    if model.summary and model.summary.match_note:
        lines.append(f"Оценка соответствия замыслу: {model.summary.match_note}")
    if plan_input.source_text:
        lines.append("Дословный текст инициативы приведён в разделе 5.1.")
    verdict_summary = []
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        pct = v.percent()
        if pct is not None:
            verdict_summary.append(f"{item.title}: {pct}%")
    if verdict_summary:
        lines.append("Готовность по этапам: " + ", ".join(verdict_summary) + ".")
    return "\n\n".join(lines)


def _components(extraction: Extraction) -> list[dict[str, Any]]:
    """4.2 — модули как компоненты."""
    modules = extraction.by_kind("MODULE")[:20]
    rows: list[dict[str, Any]] = []
    for i, f in enumerate(modules, start=1):
        value = f.value if isinstance(f.value, dict) else {}
        rows.append({
            "id": f"M-{i:03d}",
            "name": f.key,
            "does": f.basis or "не искали",
            "state": "не искали",
            "size": str(value.get("files", "?")) + " файл(ов)",
            "ref": f.path,
        })
    return rows


def _main_scenario(model: ProgressModel, plan_input: PlanInput) -> str:
    """4.3 — основной сценарий прозой. Из этапов и контекста."""
    lines: list[str] = []
    if plan_input.stages:
        lines.append("Этапы клиентского пути: " + " → ".join(plan_input.stages) + ".")
    ctx = plan_input.context
    if ctx.get("before") and ctx.get("after"):
        lines.append(f"Было: {ctx['before']}.")
        lines.append(f"Стало: {ctx['after']}.")
    if not lines:
        return "не искали"
    return " ".join(lines)


# --- раздел 5: источники ----------------------------------------------------
def _sources(plan_input: PlanInput, repo_name: str, commit: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if plan_input.source_text:
        rows.append({
            "id": "SRC-001",
            "kind": "документ плана",
            "title": "Инициатива (образ результата)",
            "version": plan_input.source_digest[:8] if plan_input.source_digest else "—",
            "as_of": "не искали",
            "locator": "текст инициативы",
            "complete": "да",
        })
    rows.append({
        "id": f"SRC-{len(rows) + 1:03d}",
        "kind": "код репозитория",
        "title": repo_name or "репозиторий",
        "version": (commit or "")[:8] or "—",
        "as_of": "не искали",
        "locator": "git-коммит",
        "complete": "да",
    })
    return rows


def _source_documents(plan_input: PlanInput) -> list[dict[str, Any]]:
    """5.1 — полный текст документа плана."""
    if not plan_input.source_text:
        return []
    return [{
        "source_id": "SRC-001",
        "title": "Инициатива (образ результата)",
        "scope": "полный текст",
        "size": f"{len(plan_input.source_text)} символов",
        "truncated": "нет",
        "content": plan_input.source_text[:8000],
    }]


# --- раздел 6: свидетельства ------------------------------------------------
def _evidence(model: ProgressModel) -> list[dict[str, Any]]:
    """Дословные цитаты из доказательств буллитов."""
    rows: list[dict[str, Any]] = []
    ev_id = 1
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        for idx, criterion in enumerate(v.criteria, start=1):
            if not criterion.applicable:
                continue
            for ref in criterion.evidence:
                quote = ref.note or ref.reason or ""
                if not quote:
                    continue
                rows.append({
                    "id": f"EV-{ev_id:03d}",
                    "source_id": "SRC-002" if ref.path else "SRC-001",
                    "subject_id": f"{v.item_id}/B-{idx:03d}",
                    "field": "основание оценки",
                    "quote": quote[:300],
                    "locator": f"{ref.path}:{ref.line}" if ref.line else ref.path,
                    "tier": "E2" if ref.verified else "E3",
                })
                ev_id += 1
    return rows


# --- раздел 7: требования плана ---------------------------------------------
def _requirements(model: ProgressModel, plan_input: PlanInput) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    req_id = 1
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        for idx, (text, criterion) in enumerate(zip(item.criteria, v.criteria), start=1):
            rid = f"R-{req_id:03d}"
            status = criterion.status if criterion.applicable else "n/a"
            ev_ids = ", ".join(f"EV-{i:03d}" for i in range(req_id, req_id + len(criterion.evidence)))
            code_ids = ", ".join(f"CODE-{i:03d}" for i in range(req_id, req_id + len(criterion.evidence)))
            readiness = ""
            if criterion.applicable and criterion.status:
                from pko.progress.schema import POC_WEIGHT
                readiness = f"{int(POC_WEIGHT.get(criterion.status, 0) * 100)}%"
            rows.append({
                "id": rid,
                "source_id": "SRC-001",
                "text": text,
                "group": item.title,
                "applicable": "да" if criterion.applicable else "нет",
                "status": status,
                "proof": criterion.proof_text or criterion.na_reason or "не искали",
                "how": criterion.how_text or "не искали",
                "readiness": readiness or "—",
                "tier": _evidence_tier(criterion),
                "evidence_ids": ev_ids or "—",
                "code_ref_ids": code_ids or "—",
            })
            req_id += 1
    return rows


def _code_refs(model: ProgressModel) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    cid = 1
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        for idx, criterion in enumerate(v.criteria, start=1):
            for ref in criterion.evidence:
                rows.append({
                    "id": f"CODE-{cid:03d}",
                    "requirement_id": f"{v.item_id}/B-{idx:03d}",
                    "path": ref.path,
                    "line_start": ref.line or 1,
                    "line_end": (ref.line or 1) + 5,
                    "basis": ref.basis,
                    "note": ref.note or "не искали",
                    "verified": "да" if ref.verified else "нет",
                })
                cid += 1
    return rows


def _not_applicable(model: ProgressModel) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        for idx, criterion in enumerate(item.criteria, start=1):
            c = v.criteria[idx - 1] if idx <= len(v.criteria) else None
            if c and not c.applicable:
                rows.append({
                    "id": f"{v.item_id}/B-{idx:03d}",
                    "reason": c.na_reason or "причина не указана",
                    "decided_by": "агент PKO",
                })
    return rows


def _evidence_tier(criterion) -> str:
    if not criterion.applicable:
        return "—"
    if criterion.status == "planned":
        return "—"
    if criterion.verified_evidence:
        return "E2"
    return "E3"


# --- раздел 9: сверх плана --------------------------------------------------
def _unplanned(extraction: Extraction, model: ProgressModel) -> list[dict[str, Any]]:
    """Что система делает, не привязанное к требованиям плана."""
    claimed = {
        e.path for v in model.verdicts
        for c in v.criteria for e in c.evidence if e.verified and e.path
    }
    rows: list[dict[str, Any]] = []
    uid = 1
    for f in extraction.facts:
        if f.path and f.path not in claimed and f.kind in ("ROUTE", "TOOL", "GRAPH_NODE"):
            rows.append({
                "id": f"W-{uid:03d}",
                "what": f"{f.kind}: {f.key}",
                "when": "при работе системы",
                "category": f.kind.lower(),
                "ref": f"{f.path}:{f.line}" if f.line else f.path,
            })
            uid += 1
            if len(rows) >= 20:
                break
    return rows


# --- раздел 13: испытания ---------------------------------------------------
def _scenarios(extraction: Extraction) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    sid = 1
    for r in extraction.by_kind("TEST_REPORT"):
        v = r.value if isinstance(r.value, dict) else {}
        for case in v.get("cases", [])[:10]:
            rows.append({
                "id": f"T-{sid:03d}",
                "input": case.get("name", "—"),
                "expected": "не искали",
                "result": case.get("outcome", "—"),
                "run_at": "не искали",
                "run_commit": "не искали",
            })
            sid += 1
    return rows


def _test_narrative(extraction: Extraction) -> str:
    tests = extraction.by_kind("TEST") + extraction.by_kind("TEST_REPORT")
    if not tests:
        return "тесты не найдены"
    return f"найдено {len(tests)} факт(ов) о тестах; детальное покрытие не разбирается"


# --- раздел 14: каркас витрины ----------------------------------------------
def _journey_steps(plan_input: PlanInput) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for i, stage in enumerate(plan_input.stages, start=1):
        rows.append({
            "id": f"ST-{i:02d}",
            "order": i,
            "title": stage,
            "value": "не искали",
        })
    return rows


def _capabilities(model: ProgressModel, plan_input: PlanInput) -> list[dict[str, Any]]:
    """Способности — из буллитов плана."""
    rows: list[dict[str, Any]] = []
    cap_id = 1
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        for idx, text in enumerate(item.criteria, start=1):
            rows.append({
                "id": f"CAP-{cap_id:03d}",
                "step_id": v.item_id,
                "title": text[:80],
                "expected": text,
                "critical": "не искали",
                "requirement_ids": f"{v.item_id}/B-{idx:03d}",
            })
            cap_id += 1
    return rows


# --- раздел 15.3: эталонный перечень ----------------------------------------
_BUILTIN_CHECKLIST = [
    ("APS", "Потребность подтверждена допустимым источником"),
    ("APS", "Клиентский путь связан с потребностью"),
    ("APS", "Целевое состояние и критерии однозначны"),
    ("APS", "Для каждого входного состояния есть траектория или остановка"),
    ("APS", "Правила выбора однозначны на контрольных сценариях"),
    ("APS", "Fallback достижим тестом"),
    ("APS", "Значимые инварианты покрыты политиками"),
    ("APS", "Политики вычисляются до защищаемого эффекта"),
    ("NIST-AI-RMF", "GOVERN: роли и ответственность назначены"),
    ("NIST-AI-RMF", "MAP: контекст и ограничения задокументированы"),
    ("NIST-AI-RMF", "MEASURE: метрики качества определены"),
    ("NIST-AI-RMF", "MANAGE: риски обработаны"),
    ("OWASP-LLM", "LLM01: промпт-инъекция — защита рассмотрена"),
    ("OWASP-LLM", "LLM02: небезопасный вывод — валидация"),
    ("OWASP-LLM", "LLM06: чрезмерное доверие — ограничения"),
]


def _reference_checklist() -> list[dict[str, Any]]:
    return [
        {"id": f"K-{i:03d}", "framework": fw, "item": item}
        for i, (fw, item) in enumerate(_BUILTIN_CHECKLIST, start=1)
    ]


# --- раздел 17: ответственность ---------------------------------------------
def _codeowners(extraction: Extraction) -> str:
    owners = extraction.by_kind("OWNER")
    if not owners:
        return "не найдено"
    return ", ".join(
        f"{f.key}: {', '.join(str(v) for v in (f.value if isinstance(f.value, list) else [f.value]))}"
        for f in owners[:5]
    )


# --- раздел 20: динамика ----------------------------------------------------
def _dynamics(prev: dict[str, Any] | None, model: ProgressModel) -> dict[str, Any]:
    if not prev:
        return {
            "prev_passport_id": "не искали",
            "prev_generated_at": "не искали",
            "prev_commit": "не искали",
            "days_since_prev": "не искали",
            "commits_since_prev": "не искали",
            "change_narrative": "первый прогон",
            "status_changes": [],
            "stale_threshold": 30,
            "stale_items": "не искали",
        }
    prev_counts = prev.get("counts", {})
    prev_readiness = prev.get("readiness", "не искали")
    return {
        "prev_passport_id": prev.get("passport_id", "не искали"),
        "prev_generated_at": prev.get("generated_at", "не искали"),
        "prev_commit": prev.get("commit", "не искали"),
        "days_since_prev": "не искали",
        "commits_since_prev": "не искали",
        "change_narrative": f"готовность {prev_readiness} → {model.readiness}%",
        "status_changes": _status_changes(prev, model),
        "stale_threshold": 30,
        "stale_items": "не искали",
    }


def _status_changes(prev: dict[str, Any], model: ProgressModel) -> list[dict[str, Any]]:
    prev_by_id = {}
    for req in prev.get("requirements", []):
        prev_by_id[req.get("id", "")] = req.get("status", "")
    changes: list[dict[str, Any]] = []
    for v in model.verdicts:
        item = model.items.get(v.item_id)
        if item is None:
            continue
        for idx, criterion in enumerate(v.criteria, start=1):
            rid = f"{v.item_id}/B-{idx:03d}"
            old = prev_by_id.get(rid)
            new = criterion.status if criterion.applicable else "n/a"
            if old and old != new:
                changes.append({"id": rid, "from": old, "to": new, "kind": "изменение"})
    return changes


# --- 1.2: таблица экстракторов ----------------------------------------------
_EXTRACTOR_TABLE = [
    ("python_code", "эндпоинты, граф, инструменты, лимиты, внешние системы", "динамику и декораторы"),
    ("sql_code", "CREATE TABLE/PROCEDURE, SQL-запросы", "PL/SQL и хранимки в бинарнике"),
    ("java_code", "@RestController, @Scheduled, @Service", "динамические бины"),
    ("contracts", "OpenAPI, JSON Schema, манифесты инструментов", "gRPC/Protobuf"),
    ("policy_specs", "лимиты, allowlist, режимы, eval-спеки", "применение лимита в рантайме"),
    ("ownership", "CODEOWNERS, метаданные сервиса", "социальный граф команды"),
    ("test_reports", "тесты и JUnit-отчёты", "покрытие по строкам"),
    ("deps", "зависимости и версии", "лицензии и уязвимости"),
    ("prompts", "файлы промптов", "встроенные в код строки"),
]


def _extractors_table(extraction: Extraction) -> list[dict[str, Any]]:
    status_map = {
        "python_code": "отработал",
        "sql_code": "отработал",
        "java_code": "отработал",
        "contracts": "отработал",
        "policy_specs": "отработал",
        "ownership": "отработал" if extraction.by_kind("OWNER") else "без находок",
        "test_reports": "отработал" if (extraction.by_kind("TEST") or extraction.by_kind("TEST_REPORT")) else "без находок",
        "deps": "отработал" if extraction.by_kind("DEP") else "без находок",
        "prompts": "отработал" if extraction.by_kind("PROMPT") else "без находок",
    }
    return [
        {"name": name, "finds": finds, "blind_spots": blind, "status": status_map.get(name, "отработал")}
        for name, finds, blind in _EXTRACTOR_TABLE
    ]


# --- вспомогательные --------------------------------------------------------
def _slug(text: str) -> str:
    s = "".join(c.lower() if c.isalnum() else "-" for c in (text or ""))
    s = "-".join(p for p in s.split("-") if p)
    return s or "project"


def _completeness(model: ProgressModel, extraction: Extraction) -> int:
    checks = [
        (bool(model.verdicts)),
        (bool(extraction.facts)),
        (bool(extraction.by_kind("ROUTE") or extraction.by_kind("TOOL"))),
        (model.summary is not None),
        (bool(extraction.by_kind("TEST") or extraction.by_kind("TEST_REPORT"))),
        (bool(extraction.by_kind("OWNER"))),
    ]
    total = len(checks)
    filled = sum(1 for c in checks if c)
    return round(filled / total * 100) if total else 0


def _numbered_controls(controls) -> list[dict[str, Any]]:
    rows = controls.controls
    for i, c in enumerate(rows, start=1):
        c["id"] = f"P-{i:03d}"
    return rows

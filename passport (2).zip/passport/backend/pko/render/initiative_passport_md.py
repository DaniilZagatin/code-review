"""Рендер паспорта инициативы в Markdown по шаблону `initiative_passport_template.md`.

Переиспользует Mustache-движок из `passport_md.py` — тот же парсер и рендерер,
другой шаблон и другой контракт данных. Принцип тот же: только подстановка,
никаких вычислений статуса или готовности — всё приходит готовыми значениями
из `initiative_passport_data.py`.

Шаблон лежит в `initiative_passport_template/initiative_passport_template.md`.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pko.render.passport_md import _Renderer

# `render/` → `pko/` → `backend/` → корень репо → initiative_passport_template/
_TEMPLATE_PATH = (
    Path(__file__).resolve().parents[3]
    / "initiative_passport_template" / "initiative_passport_template.md"
)


def render_initiative_passport_md(data: dict[str, Any]) -> str:
    """Собрать Markdown-паспорт инициативы из словаря `build_initiative_passport_data`.

    `data` — плоский контекст верхнего уровня; `{{#each}}`/`{{#if}}` работают
    по его ключам и по полям элементов. Значения подставляются как строки;
    `None` и отсутствие поля рендерятся как пустая строка.
    """
    template = _TEMPLATE_PATH.read_text(encoding="utf-8")
    return _Renderer().render(template, data)

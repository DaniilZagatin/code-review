"""Общий пайплайн прогресса: текстовый клиентский путь + целевой репозиторий
→ ProgressModel.

Одна и та же функция обслуживает и веб (`web.analyses`), и командную строку
(`cli.py`): расходиться в поведении им негде. Она ничего не печатает и не
пишет на диск — это дело вызывающей стороны.
"""

from __future__ import annotations

import time
from typing import Any, Callable

from pko.errors import PkoError
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import trace_span
from pko.progress.matcher import (
    DEFAULT_MAX_STEPS,
    _capability_digest,
    find_unclaimed_paths,
    run_agent,
)
from pko.progress.passport_agent import run_passport_agent
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import ItemVerdict, PlanItem, ProgressModel, ProjectSummary
from pko.progress.target_repo import TargetRepo

# Событие — (kind, data). Один и тот же колбэк используется и для грубых фаз
# пайплайна, и для каждого принятого вердикта агента.
ProgressEvent = Callable[[str, dict[str, Any]], None]

# Признаки того, что модель отказала из-за переполненного контекста, а не из-за
# недоступности. На большом репозитории это самый частый обрыв, и совет
# «проверьте доступность LLM» уводит в сторону: эндпоинт доступен, просто
# история сессии переросла окно модели.
_CONTEXT_MARKERS = (
    "context length", "context_length", "maximum context", "too many tokens",
    "token limit", "prompt is too long", "reduce the length",
)


def _failure_hint(notes: list[str]) -> str:
    """Подсказка к обрыву сессии: сначала причина, потом что с ней делать."""
    reason = "; ".join(notes) or "неизвестна"
    if any(marker in reason.lower() for marker in _CONTEXT_MARKERS):
        return (
            "модель отказала из-за переполненного контекста, а не из-за "
            "недоступности. Уменьшите бюджет истории (PKO_HISTORY_BUDGET, по "
            "умолчанию 80000 символов) или число шагов (--max-steps). "
            f"Причина: {reason}"
        )
    return f"проверьте доступность LLM; причина: {reason}"


def run_progress(
    journey_text: str,
    repo_name: str,
    target: TargetRepo,
    spec: ModelSpec,
    client: ChatClient | None = None,
    max_steps: int = DEFAULT_MAX_STEPS,
    on_event: ProgressEvent | None = None,
    description: str | None = None,
) -> ProgressModel:
    """Собрать ProgressModel: клиентский путь (текст) + репозиторий → агент → вывод.

    `journey_text` — текстовое поле с клиентским путём: название, этапы и
    буллиты каждого этапа. Код разбирает его в `PlanItem` (`journey_text`),
    модель ничего не придумывает — только проверяет готовность пунктов.

    `description` — описание инициативы: из него агент формулирует «Было» и
    «Стало» первым шагом сессии (`submit_brief`), если они не заданы в тексте
    пути. Применяется в веб-форме; CLI передаёт `None`.

    `on_event` — точка расширения для живого прогресса веб-эндпоинта.
    """
    started_at = time.strftime("%Y%m%d_%H:%M")
    span_name = f"pko.progress · {started_at}"
    with trace_span(
        span_name,
        repo=repo_name,
        branch=target.branch,
        commit=target.sha,
        model=spec.model,
        role=spec.role,
        max_steps=max_steps,
    ):
        return _run_progress(
            journey_text, repo_name, target, spec, client=client,
            max_steps=max_steps, on_event=on_event, description=description,
        )


def _run_progress(
    journey_text: str,
    repo_name: str,
    target: TargetRepo,
    spec: ModelSpec,
    client: ChatClient | None = None,
    max_steps: int = DEFAULT_MAX_STEPS,
    on_event: ProgressEvent | None = None,
    description: str | None = None,
) -> ProgressModel:
    """Тело пайплайна; вызывается внутри корневого `trace_span`."""
    with trace_span("parse_journey", text_chars=len(journey_text)) as span:
        plan_input = parse_plan_text(journey_text)
        parsed = plan_input.parse
        span.set_attribute("source_format", plan_input.source_format)
        span.set_attribute("stage_count", len(parsed.items))
        span.set_attribute("bullet_count", sum(len(p.criteria) for p in parsed.items))

    if on_event is not None:
        on_event("plan_ready", {
            "item_count": len(parsed.items),
            "items": [{"title": p.title, "origin": p.origin,
                       "criteria": len(p.criteria)}
                      for p in parsed.items],
        })

    on_verdict = None
    on_summary = None
    if on_event is not None:
        def on_verdict(item: PlanItem, verdict: ItemVerdict) -> None:
            on_event("claim_verified", {
                "title": item.title,
                "applicable": verdict.applicable,
                "percent": verdict.percent(),
                "criteria": len(verdict.criteria),
            })

        def on_summary(summary: ProjectSummary) -> None:
            on_event("summary_ready", {"text": " · ".join(summary.conclusion),
                                       "decision": summary.decision})

    result = run_agent(
        parsed.items, parsed.context, target.tree, spec, client=client,
        max_steps=max_steps, on_verdict=on_verdict, on_summary=on_summary,
        extraction=target.extraction, description=description,
        source_text=plan_input.source_text,
    )
    if not result.usable:
        raise PkoError(
            "Не удалось получить вердикты по этапам.",
            hint=_failure_hint(result.notes),
        )

    with trace_span("find_unclaimed") as span:
        unclaimed = find_unclaimed_paths(target.extraction, result.verdicts)
        span.set_attribute("unclaimed_groups", len(unclaimed))

    # Паспорт клиентского пути — вторая сессия, отдельный агент. По коду он
    # не ходит: строит дерево сверху вниз на знаниях сессии оценки (карта
    # возможностей, вердикты с доказательствами, след прочитанного).
    # Аддитивен: без паспорта дашборд и отчёт всё равно выпускаются.
    passport_data = None
    passport_notes: list[str] = []
    if on_event is not None:
        on_event("passport_started", {})
    try:
        on_node = None
        if on_event is not None:
            def on_node(node_id: str, name: str) -> None:
                on_event("passport_node", {"id": node_id, "name": name})
        passport = run_passport_agent(
            result.items, result.context, result.verdicts, result.summary,
            spec, client=client,
            capability_digest=_capability_digest(target.extraction),
            knowledge=result.knowledge, source_text=plan_input.source_text,
            repo_name=repo_name, commit=target.sha, on_node=on_node,
        )
        passport_data = passport.passport_data
        passport_notes = list(passport.notes)
    except Exception as exc:  # паспорт аддитивен: его сбой не отменяет отчёт
        passport_notes.append(f"паспорт не сформирован: {exc}")
    if on_event is not None:
        on_event("passport_ready", {"nodes": len((passport_data or {}).get("nodes") or {})})

    # Готовность — детерминированный расчёт по статусам буллитов.
    generated_at = time.strftime("%Y-%m-%d %H:%M")
    with trace_span("build_model") as span:
        model = ProgressModel(
            # Контекст пути (название, проект, «было/стало») идёт первым, а
            # поля с известным типом — поверх: разбор колоды кладёт в контекст
            # свою строку `stages`, и раньше она затирала список этапов.
            meta={
                **result.context,
                "repo": repo_name, "branch": target.branch, "commit": target.sha,
                "generated_at": generated_at,
                "source_format": plan_input.source_format,
                "source_digest": plan_input.source_digest,
                "stages": list(plan_input.stages),
                "effect_quotes": list(plan_input.effect_quotes),
            },
            items={item.id: item for item in result.items},
            verdicts=result.verdicts,
            unclaimed=unclaimed,
            # Замечания экстракции тоже идут в отчёт: сколько архивов
            # загружено, что осталось вне периметра, где не разобрались. Они
            # считались, но не показывались никому.
            gaps=list(plan_input.notes) + list(target.extraction.notes)
                 + list(result.notes) + passport_notes,
            readiness=0,
            readiness_prod=0,
            summary=result.summary,
            summary_source=result.summary_source,
            passport_data=passport_data,
        )
        model.readiness = model.overall_progress()
        model.readiness_prod = model.overall_progress_prod()
        span.set_attribute("items", len(model.items))
        span.set_attribute("verdicts", len(model.verdicts))
        span.set_attribute("readiness", model.readiness)
        span.set_attribute("readiness_prod", model.readiness_prod)
        span.set_attribute("summary_source", result.summary_source)
    return model

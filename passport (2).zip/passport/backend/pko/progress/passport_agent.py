"""Паспортный агент: отдельная сессия, обход дерева сверху вниз.

Сессия оценки (`matcher.run_agent`) заканчивается вердиктом. Паспорт
клиентского пути собирает **вторая сессия** — без инструментов репозитория:
по коду она не ходит, а работает на том, что уже собрала первая — карте
возможностей, вердиктах с доказательствами и сжатом следе прочитанного.

Дерево строится **итеративно**, и очередь ведёт код, а не модель:

    journey-1  ← submit_node: поля пути
               ← declare_children: процессы (название + basis)
    process-1  ← submit_node: поля процесса
               ← declare_children: BBB
    bbb-1      ← submit_node
               ← declare_children: операции
    operation-1 ← submit_node          (лист — детей нет)
    operation-2 ← submit_node
    bbb-2 …    (обход в глубину, пока очередь не пуста)
    need-N, guardrail-N ← submit_node   (после дерева; связи journeys/scope)
    finish

Каждый узел проверяется гейтом отдельно (`passport_gate`), отклонение стоит
одного шага, а не всего паспорта. У промежуточных узлов дети обязательны:
объявление без единого ребёнка не принимается. Идентификаторы выдаёт код,
реестр и `object-id` строит `normalize_passport` — модель присылает только
названия, основания и поля. В каждом ответе модель получает карту уже
построенного дерева — из истории ей ничего вспоминать не нужно.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from pko.errors import LlmError
from pko.extractors.runner import Extraction
from pko.llm.client import ChatClient
from pko.llm.registry import ModelSpec
from pko.llm.tracing import _NoopSpan, trace_span
from pko.progress.passport_gate import (
    CHILD_TYPE,
    DECISION_BOUNDARIES,
    MAX_NEEDS,
    TYPE_LABEL,
    PassportCheck,
    check_guardrail_node,
    check_need_node,
    check_node_fields,
    check_router_present,
    collapsed_level_message,
    duplicate_name_message,
    node_type,
    norm_name,
    normalize_passport,
    too_many_needs_message,
)
from pko.progress.schema import ItemVerdict, PlanItem, ProjectSummary

_PROMPT_PATH = Path(__file__).parent / "passport_system.md"

# Бюджет шагов паспортной сессии: узел — шаг, объявление детей — шаг.
# Дерево на 20 узлов с потребностями и ограничениями — около 35 шагов;
# запас на отклонения гейта. `PKO_PASSPORT_MAX_STEPS`.
DEFAULT_PASSPORT_MAX_STEPS = 60
# Потолок времени паспортной сессии, `PKO_PASSPORT_MAX_SECONDS`; 0 — без предела.
DEFAULT_PASSPORT_SECONDS = 1200
# Сколько раз один узел отклоняется, прежде чем принять его с нарушениями.
MAX_NODE_REJECTIONS = 2
# У процесса меньше двух BBB — замечание: обычно процесс описан одним куском.
MIN_BBB_PER_PROCESS = 2
# Сколько ошибок подряд без вызова инструмента останавливают сессию.
_MAX_MALFORMED = 3

MAX_TOKENS_DEFAULT = 8192
MAX_TOKENS_THINKING = 16384

# Сколько символов сжатого следа оценки уходит в первое сообщение.
_MAX_KNOWLEDGE_CHARS = 30_000
_MAX_PROOF_CHARS = 300


def _env_number(name: str, default: float) -> float:
    raw = (os.environ.get(name) or "").strip()
    try:
        return max(0.0, float(raw)) if raw else default
    except ValueError:
        return default


# --- схемы инструментов --------------------------------------------------------

_SUBMIT_NODE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "submit_node",
        "description": (
            "Заполнить один узел паспорта — тот, который код назвал в "
            "последнем ответе. Передай его id, название (name), basis — одну "
            "фразу, почему узел существует как объект управления и чем "
            "отличается от соседей, — и fields: по каждому полю раздела "
            "{value, source}. source начинается с уровня: Установлено: / "
            "Выведено: / Гипотеза: / Требует подтверждения владельца: / "
            "Не установлено:. Для journey дополнительно decision_boundary "
            "(END_TO_END_PROCESS | COMPONENT_BBB); для need — journeys "
            "(список id путей); для guardrail — scope (список id узлов, где "
            "проверка выполняется). Код проверит узел и скажет, что дальше."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "id узла из ответа кода: journey-1, process-2, bbb-3, operation-4, need-1, guardrail-2"},
                "name": {"type": "string", "description": "Название узла на языке бизнеса"},
                "basis": {"type": "string", "description": "Почему узел существует как объект управления и чем отличается от соседей — одна фраза"},
                "fields": {
                    "type": "object",
                    "description": "Поля раздела: {\"4.X.Y\": {\"value\": \"...\", \"source\": \"Уровень: привязка\"}}",
                },
                "decision_boundary": {"type": "string", "description": "Только для journey: END_TO_END_PROCESS или COMPONENT_BBB"},
                "journeys": {"type": "array", "items": {"type": "string"}, "description": "Только для need: id путей, которые закрывает потребность"},
                "scope": {"type": "array", "items": {"type": "string"}, "description": "Только для guardrail: id узлов, где проверка фактически выполняется"},
            },
            "required": ["id", "name", "basis", "fields"],
        },
    },
}

_DECLARE_CHILDREN_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "declare_children",
        "description": (
            "Объявить дочерние узлы только что заполненного узла: для journey "
            "— процессы, для process — BBB, для bbb — атомарные операции. "
            "Только название и basis; поля каждого ребёнка ты заполнишь, когда "
            "код его назовёт. Дети обязательны: journey без процессов, процесс "
            "без BBB и BBB без операций не принимаются. Дроби по бизнес-"
            "действиям: ориентир 3–6 BBB на процесс, 1–3 операции на BBB."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "parent": {"type": "string", "description": "id узла-родителя из ответа кода"},
                "children": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "basis": {"type": "string", "description": "Почему это отдельный объект и чем отличается от соседей"},
                        },
                        "required": ["name", "basis"],
                    },
                },
            },
            "required": ["parent", "children"],
        },
    },
}

_FINISH_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "finish",
        "description": "Завершить паспорт: дерево построено, потребности и ограничения заполнены.",
        "parameters": {"type": "object", "properties": {}},
    },
}


# --- состояние сессии ------------------------------------------------------------

@dataclass
class _Node:
    id: str
    name: str
    basis: str
    parent: str | None
    filled: bool = False
    data: dict[str, Any] = field(default_factory=dict)
    children: list[str] = field(default_factory=list)


@dataclass
class _PassportSession:
    nodes: dict[str, _Node] = field(default_factory=dict)
    counters: dict[str, int] = field(default_factory=dict)
    # Очередь заполнения — стек обхода в глубину.
    queue: list[str] = field(default_factory=list)
    # Узел, поля которого ждёт код, и узел, дети которого ждут объявления.
    current: str | None = None
    awaiting_children_of: str | None = None
    tree_done: bool = False
    attempts: dict[str, int] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    remarks: list[str] = field(default_factory=list)
    finished: bool = False
    decision_boundary: str = ""
    span: Any = field(default_factory=lambda: _NoopSpan())
    on_node: Callable[[str, str], None] | None = None

    def new_id(self, ntype: str) -> str:
        self.counters[ntype] = self.counters.get(ntype, 0) + 1
        return f"{ntype}-{self.counters[ntype]}"

    def tree_ids(self) -> list[str]:
        return [nid for nid in self.nodes if node_type(nid) in CHILD_TYPE or node_type(nid) == "operation"]

    def of_type(self, ntype: str) -> list[_Node]:
        return [n for n in self.nodes.values() if node_type(n.id) == ntype]


# --- обработчики ----------------------------------------------------------------

def _handle_submit_node(state: _PassportSession, args: dict) -> str:
    nid = str(args.get("id") or "").strip()
    ntype = node_type(nid)
    expected = _expected_submit(state)
    if not ntype or nid not in expected:
        return (f"submit_node отклонён: сейчас ожидается {_expected_text(state)}, "
                f"а пришёл «{nid or '?'}».")
    name = str(args.get("name") or "").strip()
    basis = str(args.get("basis") or "").strip()
    fields = args.get("fields")
    if isinstance(fields, str):
        try:
            fields = json.loads(fields)
        except ValueError:
            fields = None
    if not isinstance(fields, dict):
        fields = {}
    node = state.nodes.get(nid)
    is_new = node is None
    if node is not None and not name:
        name = node.name
    if node is not None and not basis:
        basis = node.basis

    payload: dict[str, Any] = {"name": name, "basis": basis, "fields": fields}
    check = PassportCheck()
    if not name:
        check.errors.append(f"{nid}: нет названия (name)")
    if not basis:
        check.errors.append(f"{nid}: нет basis — одной фразы, почему узел существует как объект управления")
    if not fields:
        check.errors.append(f"{nid}: fields пуст — заполни поля раздела, по каждому value и source")
    _check_name_unique(check, state, nid, name)
    check_node_fields(check, nid, payload)

    if ntype == "journey":
        boundary = str(args.get("decision_boundary") or "").strip()
        if boundary not in DECISION_BOUNDARIES:
            check.errors.append(
                "journey: decision_boundary должен быть END_TO_END_PROCESS "
                "(путь покрывает триггер входа и результат после) или COMPONENT_BBB "
                "(диалог внутри агента от классификации до сообщения)"
            )
        else:
            payload["decision_boundary"] = boundary
    elif ntype == "need":
        payload["journeys"] = args.get("journeys") or []
        journeys = {n.id for n in state.of_type("journey")}
        process_names = [n.name for n in state.of_type("process")]
        check_need_node(check, nid, payload, journeys, process_names)
        if is_new and len(state.of_type("need")) >= MAX_NEEDS:
            check.errors.append(too_many_needs_message(len(state.of_type("need")) + 1))
    elif ntype == "guardrail":
        payload["scope"] = args.get("scope") or []
        check_guardrail_node(check, nid, payload, set(state.tree_ids()))
    elif ntype == "process" and node is not None and node.parent:
        pass

    if check.errors:
        state.attempts[nid] = state.attempts.get(nid, 0) + 1
        state.span.add_event("node_rejected", node=nid, attempts=state.attempts[nid])
        if state.attempts[nid] <= MAX_NODE_REJECTIONS:
            listed = "\n".join(f"- {e}" for e in check.errors[:10])
            return f"{nid} отклонён:\n{listed}\nИсправь и вызови submit_node({nid}) снова."
        state.notes.append(
            f"{nid} принят с нарушениями после {MAX_NODE_REJECTIONS} отклонений: "
            + "; ".join(check.errors[:6])
        )

    if node is None:
        node = _Node(id=nid, name=name, basis=basis, parent=None)
        state.nodes[nid] = node
    node.name, node.basis = name, basis
    node.data = payload
    node.filled = True
    if ntype == "journey":
        state.decision_boundary = payload.get("decision_boundary", state.decision_boundary)
    state.remarks.extend(check.remarks)
    state.span.add_event("node_accepted", node=nid, remarks=len(check.remarks))
    if state.on_node is not None:
        state.on_node(nid, name)

    reply = [f"{nid} «{name}» принят."]
    if check.remarks:
        reply.append("Замечания (исправь при желании повторным submit_node, иначе продолжай):")
        reply.extend(f"- {r}" for r in check.remarks[:6])

    if ntype in CHILD_TYPE:
        state.current = None
        state.awaiting_children_of = nid
        child_label = TYPE_LABEL[CHILD_TYPE[ntype]]
        reply.append(
            f"Теперь объяви детей: declare_children(parent=\"{nid}\", children=[{{name, basis}}, …]) "
            f"— {child_label.lower()} ({_children_hint(ntype)}). Дети обязательны."
        )
        return "\n".join(reply)

    state.current = None
    reply.append(_advance(state))
    return "\n".join(reply)


def _handle_declare_children(state: _PassportSession, args: dict) -> str:
    parent_id = str(args.get("parent") or "").strip()
    if state.awaiting_children_of is None or parent_id != state.awaiting_children_of:
        return (f"declare_children отклонён: сейчас ожидается {_expected_text(state)}"
                + (f", а не объявление детей у «{parent_id}»" if parent_id else ""))
    parent = state.nodes[parent_id]
    ptype = node_type(parent_id)
    ctype = CHILD_TYPE[ptype]
    raw = args.get("children")
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            raw = None
    children = [c for c in (raw or []) if isinstance(c, dict) and str(c.get("name") or "").strip()]

    check = PassportCheck()
    if not children:
        check.errors.append(
            f"{parent_id}: у {TYPE_LABEL[ptype].lower()} должен быть хотя бы один "
            f"{TYPE_LABEL[ctype].lower()} — {_children_hint(ptype)}"
        )
    seen: set[str] = set()
    for child in children:
        cname = str(child.get("name") or "").strip()
        cbasis = str(child.get("basis") or "").strip()
        key = norm_name(cname)
        if not cbasis:
            check.errors.append(f"«{cname}»: нет basis")
        if key in seen:
            check.errors.append(f"«{cname}» объявлен дважды")
        seen.add(key)
        if key == norm_name(parent.name):
            check.errors.append(duplicate_name_message(f"{ctype}-?", parent_id, cname))
        else:
            _check_name_unique(check, state, f"{ctype}-?", cname)
    if (ptype == "process" and len(children) == 1
            and norm_name(children[0].get("basis")) == norm_name(parent.basis)):
        check.errors.append(collapsed_level_message(parent_id, f"{ctype}-?"))

    if check.errors:
        key = f"children:{parent_id}"
        state.attempts[key] = state.attempts.get(key, 0) + 1
        state.span.add_event("children_rejected", node=parent_id, attempts=state.attempts[key])
        if state.attempts[key] <= MAX_NODE_REJECTIONS or not children:
            listed = "\n".join(f"- {e}" for e in check.errors[:10])
            return (f"дети {parent_id} отклонены:\n{listed}\n"
                    f"Исправь и вызови declare_children(parent=\"{parent_id}\") снова.")
        state.notes.append(
            f"дети {parent_id} приняты с нарушениями: " + "; ".join(check.errors[:6])
        )

    if ptype == "process" and len(children) < MIN_BBB_PER_PROCESS:
        state.remarks.append(
            f"{parent_id}: один BBB на процесс — проверь по признакам дробления "
            "(разные входы/результаты, внешние системы, расчёт vs генерация, "
            "режим полномочий); обычно процесс описан одним куском"
        )

    ids: list[str] = []
    for child in children:
        cid = state.new_id(ctype)
        state.nodes[cid] = _Node(
            id=cid, name=str(child.get("name")).strip(),
            basis=str(child.get("basis") or "").strip(), parent=parent_id,
        )
        parent.children.append(cid)
        ids.append(cid)
    # Обход в глубину: первый ребёнок заполняется следующим, остальные ждут.
    state.queue[0:0] = ids
    state.awaiting_children_of = None
    state.span.add_event("children_declared", node=parent_id, count=len(ids))

    reply = [f"{parent_id}: объявлено {len(ids)} — " + ", ".join(f"{cid} «{state.nodes[cid].name}»" for cid in ids) + "."]
    if ptype == "process" and len(children) < MIN_BBB_PER_PROCESS:
        reply.append("Замечание: " + state.remarks[-1])
    reply.append(_advance(state))
    return "\n".join(reply)


def _handle_finish(state: _PassportSession, args: dict) -> str:
    missing = _unfinished(state)
    if missing:
        return "finish отклонён: " + "; ".join(missing) + ". " + _expected_text(state)
    state.finished = True
    return "паспорт завершён"


_HANDLERS: dict[str, Callable[[_PassportSession, dict], str]] = {
    "submit_node": _handle_submit_node,
    "declare_children": _handle_declare_children,
    "finish": _handle_finish,
}


def _unfinished(state: _PassportSession) -> list[str]:
    out: list[str] = []
    if state.awaiting_children_of:
        out.append(f"не объявлены дети {state.awaiting_children_of}")
    if state.current:
        out.append(f"не заполнен {state.current}")
    if state.queue:
        out.append(f"в очереди {len(state.queue)} узлов: " + ", ".join(state.queue[:5]))
    if not state.of_type("need"):
        out.append("нет ни одной потребности клиента (submit_node need-1)")
    return out


def _advance(state: _PassportSession) -> str:
    """Следующий шаг протокола: очередной узел дерева или переход к потребностям."""
    if state.queue:
        nid = state.queue.pop(0)
        state.current = nid
        node = state.nodes[nid]
        parent = state.nodes[node.parent] if node.parent else None
        lines = [_tree_map(state), f"Заполни {nid} «{node.name}» ({TYPE_LABEL[node_type(nid)]}) — basis: {node.basis}."]
        if parent is not None:
            lines.append(f"Родитель {parent.id} «{parent.name}»: {_node_digest(parent)}")
        siblings = [state.nodes[c] for c in (parent.children if parent else []) if c != nid]
        if siblings:
            lines.append("Соседи: " + "; ".join(f"{s.id} «{s.name}»" for s in siblings))
        lines.append(f"Вызови submit_node(id=\"{nid}\") с полями раздела.")
        return "\n".join(lines)
    if not state.tree_done:
        state.tree_done = True
        needs_n = state.counters.get("need", 0)
        lines = [_tree_map(state), "Дерево построено."]
        lines.append(
            f"Теперь потребности клиента: submit_node(id=\"need-{needs_n + 1}\", journeys=[…]) — "
            f"одна, максимум {MAX_NEEDS}, от клиента, а не от продукта. "
            "Затем ограничения исполнения: submit_node(id=\"guardrail-1\", scope=[…]) по одному "
            "на каждую исполняемую проверку. Когда всё — finish."
        )
        return "\n".join(lines)
    needs_n = state.counters.get("need", 0)
    grd_n = state.counters.get("guardrail", 0)
    return (
        f"Дальше: следующая потребность — need-{needs_n + 1} (если есть, всего не больше {MAX_NEEDS}); "
        f"следующее ограничение — guardrail-{grd_n + 1}; или finish."
    )


def _expected_submit(state: _PassportSession) -> set[str]:
    if state.awaiting_children_of:
        return set()
    if state.current:
        return {state.current}
    if not state.tree_done:
        return set()
    allowed: set[str] = set()
    needs_n = state.counters.get("need", 0)
    if needs_n < MAX_NEEDS:
        allowed.add(f"need-{needs_n + 1}")
    allowed.add(f"guardrail-{state.counters.get('guardrail', 0) + 1}")
    # Повторная отправка уже принятого узла (исправление по замечанию).
    allowed.update(n.id for n in state.nodes.values() if n.filled and node_type(n.id) in ("need", "guardrail"))
    return allowed


def _expected_text(state: _PassportSession) -> str:
    if state.awaiting_children_of:
        return f"declare_children(parent=\"{state.awaiting_children_of}\")"
    if state.current:
        return f"submit_node(id=\"{state.current}\")"
    if state.tree_done:
        return "submit_node для need-N / guardrail-N или finish"
    return "ничего: дерево не начато"


def _check_name_unique(check: PassportCheck, state: _PassportSession, nid: str, name: str) -> None:
    key = norm_name(name)
    if not key:
        return
    for other in state.nodes.values():
        if other.id != nid and norm_name(other.name) == key:
            check.errors.append(duplicate_name_message(nid, other.id, name))
            return


def _children_hint(ptype: str) -> str:
    return {
        "journey": "по одному на сценарий с собственными условиями запуска и завершением",
        "process": "одно бизнес-действие с одним ответом «что получили»; 3–6 на процесс, "
                   "включая определение сценария, получение данных, подбор, предложение, "
                   "объяснение, подтверждение, исполнение",
        "bbb": "шаг с наблюдаемым снаружи результатом, который может отказать отдельно; "
               "1–3 на BBB, обычно по способам исполнения",
    }[ptype]


def _node_digest(node: _Node, limit: int = 220) -> str:
    fields = node.data.get("fields") or {}
    parts = []
    for fid in sorted(fields):
        value = str((fields.get(fid) or {}).get("value") or "").strip()
        if value:
            parts.append(f"{fid}: {value[:limit]}")
        if len(parts) >= 3:
            break
    return " · ".join(parts) or "поля не заполнены"


def _tree_map(state: _PassportSession) -> str:
    """Карта построенного: id · название — basis, с отступами по уровням."""
    lines = ["Построено:"]

    def visit(nid: str, depth: int) -> None:
        node = state.nodes[nid]
        mark = "✓" if node.filled else "…"
        lines.append(f"{'  ' * depth}{mark} {nid} «{node.name}» — {node.basis[:100]}")
        for cid in node.children:
            visit(cid, depth + 1)

    for root in state.of_type("journey"):
        visit(root.id, 0)
    for extra in ("need", "guardrail"):
        for node in state.of_type(extra):
            lines.append(f"✓ {node.id} «{node.name}»")
    return "\n".join(lines)


# --- сборка результата --------------------------------------------------------------

def _build_passport_data(state: _PassportSession, scope: str, date: str) -> dict[str, Any]:
    def rebuild(nid: str) -> dict[str, Any]:
        node = state.nodes[nid]
        out: dict[str, Any] = {"id": nid, "type": node_type(nid)}
        if node.children or node_type(nid) != "operation":
            out["children"] = [rebuild(c) for c in node.children]
        return out

    nodes: dict[str, Any] = {}
    for nid, node in state.nodes.items():
        entry: dict[str, Any] = {"name": node.name, "basis": node.basis, "fields": {}}
        if node.filled:
            entry.update({k: v for k, v in node.data.items() if k not in ("name", "basis")})
        else:
            entry["object-version"] = "Не заполнено: сессия прервана до этого узла"
        nodes[nid] = entry
    data = {
        "analysis-scope": scope,
        "decision-boundary": state.decision_boundary,
        "analysis-date": date,
        "tree": [rebuild(n.id) for n in state.of_type("journey")],
        "nodes": nodes,
    }
    return normalize_passport(data)


@dataclass
class PassportAgentResult:
    passport_data: dict[str, Any] | None = None
    notes: list[str] = field(default_factory=list)
    steps: int = 0


# --- вход: сжатые знания сессии оценки -------------------------------------------------

def render_evaluation_digest(
    plan_items: list[PlanItem],
    verdicts: list[ItemVerdict],
    summary: ProjectSummary | None,
    knowledge: list[str],
) -> str:
    """Что узнала сессия оценки — единственный источник фактов для паспорта."""
    by_id = {v.item_id: v for v in verdicts}
    lines: list[str] = []
    if summary is not None:
        lines.append(f"Верхнеуровневая оценка: {summary.match} — {summary.match_note}")
    lines.append("Оценка этапов образа результата (статус · проверка · как работает · ссылки):")
    for item in plan_items:
        lines.append(f"## {item.title}")
        verdict = by_id.get(item.id)
        for idx, text in enumerate(item.criteria):
            crit = verdict.criteria[idx] if verdict and idx < len(verdict.criteria) else None
            if crit is None:
                lines.append(f"- {text} — не оценено")
                continue
            lines.append(f"- {text} — {crit.status}")
            if crit.proof:
                lines.append(f"  проверка: {crit.proof[:_MAX_PROOF_CHARS]}")
            if crit.how:
                lines.append(f"  как работает: {crit.how[:_MAX_PROOF_CHARS]}")
            for ev in crit.evidence:
                if getattr(ev, "verified", False):
                    lines.append(f"  · {ev.path}:{ev.line} — {ev.basis}" + (f" — {ev.note}" if getattr(ev, 'note', '') else ""))
    if knowledge:
        lines.append("")
        lines.append("Что сессия оценки читала в коде (сжатый след):")
        total = 0
        for entry in knowledge:
            total += len(entry) + 1
            if total > _MAX_KNOWLEDGE_CHARS:
                lines.append("… (след обрезан)")
                break
            lines.append(entry)
    return "\n".join(lines)


def run_passport_agent(
    plan_items: list[PlanItem],
    context: dict[str, str],
    verdicts: list[ItemVerdict],
    summary: ProjectSummary | None,
    spec: ModelSpec | None,
    client: ChatClient | None = None,
    capability_digest: str = "",
    knowledge: list[str] | None = None,
    source_text: str | None = None,
    repo_name: str = "",
    commit: str = "",
    max_steps: int | None = None,
    on_node: Callable[[str, str], None] | None = None,
) -> PassportAgentResult:
    """Собрать паспорт клиентского пути отдельной сессией по знаниям оценки."""
    if spec is None:
        return PassportAgentResult(notes=["Паспорт: matcher не настроен"])
    if max_steps is None:
        max_steps = int(_env_number("PKO_PASSPORT_MAX_STEPS", DEFAULT_PASSPORT_MAX_STEPS))

    journey_name = context.get("client_path_name") or context.get("project_name") or repo_name or "Клиентский путь"
    state = _PassportSession(on_node=on_node)
    root = state.new_id("journey")
    state.nodes[root] = _Node(id=root, name=journey_name, basis="путь задан образом результата инициативы", parent=None)
    state.queue.append(root)

    brief = [
        f"Клиентский путь: {journey_name}. Проект: {context.get('project_name') or '—'}.",
        f"Было: {context.get('before') or '—'}. Стало: {context.get('after') or '—'}.",
    ]
    if source_text and source_text.strip():
        brief.append("Дословный текст инициативы:\n" + source_text.strip()[:4000])
    if capability_digest:
        brief.append(capability_digest)
    brief.append(render_evaluation_digest(plan_items, verdicts, summary, knowledge or []))
    brief.append("")
    brief.append(_advance(state))
    user_brief = "\n\n".join(brief)

    try:
        system_prompt = _PROMPT_PATH.read_text(encoding="utf-8")
    except OSError:
        system_prompt = "Ты заполняешь паспорт клиентского пути по знаниям сессии оценки."
        state.notes.append("Промпт паспортного агента не найден: passport_system.md")

    chat_client = client if client is not None else ChatClient(spec=spec)
    thinking_on = bool(
        spec.extra_body
        and spec.extra_body.get("chat_template_kwargs", {}).get("enable_thinking") is True
    )
    max_tokens = MAX_TOKENS_THINKING if thinking_on else MAX_TOKENS_DEFAULT
    schemas = [_SUBMIT_NODE_SCHEMA, _DECLARE_CHILDREN_SCHEMA, _FINISH_SCHEMA]
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_brief},
    ]
    budget_seconds = _env_number("PKO_PASSPORT_MAX_SECONDS", DEFAULT_PASSPORT_SECONDS)
    deadline = time.monotonic() + budget_seconds if budget_seconds else 0.0
    malformed = 0
    steps_done = 0

    with trace_span("passport_session") as session_handle:
        state.span = session_handle
        session_handle.set_attribute("max_steps", max_steps)
        for step in range(1, max(1, max_steps) + 1):
            steps_done = step
            if deadline and time.monotonic() > deadline:
                state.notes.append(f"паспорт: время сессии исчерпано ({int(budget_seconds)} с) на шаге {step}")
                break
            with trace_span("passport.step", step=step) as step_span:
                try:
                    result = chat_client.chat(messages, tools=schemas, max_tokens=max_tokens)
                except LlmError as exc:
                    step_span.set_attribute("error", exc.message)
                    state.notes.append(f"паспорт: агент недоступен на шаге {step}: {exc.message} {exc.hint}".strip())
                    break
            if not result.tool_calls:
                malformed += 1
                if malformed >= _MAX_MALFORMED:
                    state.notes.append(f"паспорт: агент не вызвал инструмент {malformed} раз подряд — остановлено")
                    break
                messages.append({"role": "assistant", "content": result.text})
                messages.append({"role": "user", "content": "Нужно вызвать инструмент: " + _expected_text(state)})
                continue
            malformed = 0
            messages.append({
                "role": "assistant", "content": result.text or None,
                "tool_calls": result.tool_calls,
                "reasoning_content": result.reasoning_content or None,
            })
            for call in result.tool_calls:
                messages.append(_answer_call(state, call))
            _compact_history(messages)
            if state.finished:
                break
        else:
            state.notes.append(f"паспорт: бюджет шагов исчерпан ({max_steps})")
        session_handle.set_attribute("steps_done", steps_done)
        session_handle.set_attribute("nodes", len(state.nodes))
        session_handle.set_attribute("finished", state.finished)

    if not state.finished:
        missing = _unfinished(state)
        if missing:
            state.notes.append("паспорт не завершён: " + "; ".join(missing))
    unfilled = [n.id for n in state.nodes.values() if not n.filled]
    if unfilled:
        state.notes.append("паспорт: узлы объявлены, но не заполнены: " + ", ".join(unfilled[:8]))
    check = PassportCheck()
    check_router_present(check, {nid: n.data for nid, n in state.nodes.items() if n.filled})
    state.remarks.extend(check.remarks)
    if state.remarks:
        state.notes.append("Замечания к паспорту: " + "; ".join(dict.fromkeys(state.remarks)))

    filled_any = any(n.filled for n in state.nodes.values())
    scope = f"{repo_name} · коммит {commit[:8] if commit else '—'} · {context.get('project_name') or journey_name}"
    data = _build_passport_data(state, scope, time.strftime("%Y-%m-%d")) if filled_any else None
    return PassportAgentResult(passport_data=data, notes=state.notes, steps=steps_done)


def _answer_call(state: _PassportSession, call: dict) -> dict[str, Any]:
    function = call.get("function") or {}
    name = str(function.get("name") or "")
    call_id = str(call.get("id") or "")
    try:
        args = json.loads(function.get("arguments") or "{}")
    except json.JSONDecodeError as exc:
        return {"role": "tool", "tool_call_id": call_id,
                "content": f"аргументы инструмента не являются валидным JSON: {exc}"}
    handler = _HANDLERS.get(name)
    if handler is None:
        content = f"инструмента «{name}» нет. Доступны: submit_node, declare_children, finish. " + _expected_text(state)
    else:
        content = handler(state, args if isinstance(args, dict) else {})
    return {"role": "tool", "tool_call_id": call_id, "content": content}


# Ответ кода на каждый принятый узел несёт карту дерева целиком; в истории
# она нужна только последняя. Старые ответы ужимаются до первой строки —
# факт принятия остаётся, карта не копится.
_KEEP_RECENT_TOOL_REPLIES = 2


def _compact_history(messages: list[dict[str, Any]]) -> None:
    tool_idx = [i for i, m in enumerate(messages) if m.get("role") == "tool"]
    for i in tool_idx[:-_KEEP_RECENT_TOOL_REPLIES]:
        content = str(messages[i].get("content") or "")
        if "\nПостроено:" in content or content.startswith("Построено:"):
            messages[i]["content"] = content.split("\n", 1)[0]

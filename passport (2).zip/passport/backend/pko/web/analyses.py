"""Асинхронные задачи анализа для живого веб-фронтенда (`frontend-web/`).

Локальный инструмент, один процесс — как и весь `pko serve`. Поэтому реестр
задач — обычный `dict` в памяти, выполнение — `threading.Thread`, обмен
событиями прогресса — `queue.Queue`.

Один прогон = один `AnalysisJob`. `run_progress` уже умеет сообщать о
прогрессе через `on_event` — здесь это событие просто складывается в очередь
задачи, откуда его читает SSE-эндпоинт.
"""

from __future__ import annotations

import os
import queue
import shutil
import tempfile
import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from pko.errors import PkoError
from pko.llm.registry import ModelSpec
from pko.progress.local_source import (
    build_empty_workspace,
    build_target_repo_from_uploads,
    merge_with_uploads,
)
from pko.progress.pipeline import run_progress
from pko.progress.target_repo import TargetRepo, load_target, open_repo_source
from pko.render.dashboard_data import build_dashboard_data

Status = Literal["PROCESSING", "READY", "ERROR"]

# Реестр живёт в памяти процесса и раньше рос без потолка: каждый `POST
# /api/analyses` добавлял задачу с очередью событий, и долгая жизнь `pko serve`
# заканчивалась раздутой памятью. При достижении потолка вытесняется самая
# старая завершённая задача; PROCESSING не вытесняются никогда.
MAX_JOBS = 100

# Сколько прогонов идёт одновременно. Один прогон — это клон репозитория,
# распакованный workspace и сессия агента до 80 шагов; десять параллельных
# запросов на поде с четырьмя гигабайтами памяти дают не десятикратную
# скорость, а OOM и потерю всех десяти. Остальные ждут очереди: задача уже
# создана, клиент видит ожидание событием и никуда не проваливается.
DEFAULT_MAX_PARALLEL = 2


def _max_parallel() -> int:
    raw = (os.environ.get("PKO_MAX_PARALLEL") or "").strip()
    try:
        value = int(raw) if raw else DEFAULT_MAX_PARALLEL
    except ValueError:
        value = DEFAULT_MAX_PARALLEL
    return max(1, value)


MAX_PARALLEL = _max_parallel()
_SLOTS = threading.BoundedSemaphore(MAX_PARALLEL)

# Сколько прогонов может ждать очереди сверх идущих. Без потолка каждый
# запрос — поток и каталог на диске, а очередь на сотню прогонов по полчаса
# при двух слотах это сутки ожидания, о которых человек узнает только по
# вечному «ждём очереди». Лишним честнее сразу ответить «зайдите позже».
DEFAULT_MAX_QUEUE = 10


def _max_queue() -> int:
    raw = (os.environ.get("PKO_MAX_QUEUE") or "").strip()
    try:
        value = int(raw) if raw else DEFAULT_MAX_QUEUE
    except ValueError:
        value = DEFAULT_MAX_QUEUE
    return max(0, value)


MAX_QUEUE = _max_queue()


class QueueFullError(PkoError):
    """Идущих и ждущих прогонов уже столько, сколько разрешено."""


@dataclass
class AnalysisJob:
    id: str
    status: Status = "PROCESSING"
    events: "queue.Queue[dict[str, Any]]" = field(default_factory=queue.Queue)
    result: dict[str, Any] | None = None
    error: dict[str, str] | None = None


_JOBS: dict[str, AnalysisJob] = {}


def get_job(job_id: str) -> AnalysisJob | None:
    return _JOBS.get(job_id)


def _prune_jobs() -> None:
    """Освободить место под новую задачу, вытеснив самую старую завершённую."""
    if len(_JOBS) < MAX_JOBS:
        return
    for job_id, job in _JOBS.items():
        if job.status != "PROCESSING":
            _JOBS.pop(job_id, None)
            return


def create_analysis(
    journey_text: str,
    repository: str,
    branch: str,
    uploads: list[tuple[str, bytes]],
    spec: ModelSpec,
    description: str | None = None,
) -> AnalysisJob:
    """Провалидировать вход, создать задачу и сразу запустить её в фоне.

    `repository` — SSH-ссылка или локальный путь (автоопределение, как в CLI);
    пустое поле — анализ только по загруженным файлам (без репозитория).
    `branch` пустая — ветка по умолчанию (master/main), имеет смысл только
    при непустом репозитории.
    `description` — описание инициативы: из него агент формулирует «Было» и
    «Стало» первым шагом (`submit_brief`). None/пусто — шаг пропускается.
    """
    if not journey_text or not journey_text.strip():
        raise PkoError(
            "Не задан клиентский путь.",
            hint="введите название пути, этапы и их пункты в текстовое поле",
        )

    repository = repository.strip() or ""
    branch = (branch.strip() or None) if repository else None

    description = (description or "").strip() or None

    active = sum(1 for existing in _JOBS.values() if existing.status == "PROCESSING")
    if active >= MAX_PARALLEL + MAX_QUEUE:
        raise QueueFullError(
            f"Очередь прогонов заполнена: идёт и ждёт {active} при пределе "
            f"{MAX_PARALLEL + MAX_QUEUE}.",
            hint="дождитесь завершения текущих прогонов и отправьте запрос снова",
        )

    job = AnalysisJob(id="an_" + uuid.uuid4().hex[:12])
    tmp_dir = Path(tempfile.mkdtemp(prefix=f"pko-analysis-{job.id}-"))
    # Файлы формы уходят на диск до постановки в очередь. Ждущий прогон
    # раньше держал их байтами в памяти всё время ожидания: десять запросов
    # по двести мегабайт в очереди — два гигабайта, которых у пода нет.
    try:
        spooled = _spool_uploads(uploads, tmp_dir / "uploads")
    except OSError as exc:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        raise PkoError(
            "Не удалось сохранить загруженные файлы на диск.",
            hint=f"{exc}; проверьте свободное место во временном каталоге",
        ) from exc
    uploads.clear()

    _prune_jobs()
    _JOBS[job.id] = job

    thread = threading.Thread(
        target=_execute,
        args=(job, journey_text, repository, branch, spooled, tmp_dir,
              spec, description),
        daemon=True,
    )
    thread.start()
    return job


def _spool_uploads(
    uploads: list[tuple[str, bytes]], folder: Path,
) -> list[tuple[str, Path]]:
    """Записать файлы формы во временный каталог; вернуть пары «имя, путь».

    Имя файла сохраняется отдельно от пути: по нему `local_source`
    распознаёт архив и называет его каталог, а на диске файлы лежат под
    номерами — два одноимённых `repo.zip` не затирают друг друга.
    """
    if not uploads:
        return []
    folder.mkdir(parents=True, exist_ok=True)
    spooled: list[tuple[str, Path]] = []
    for index, (name, data) in enumerate(uploads):
        path = folder / f"{index:03d}.bin"
        path.write_bytes(data)
        spooled.append((name, path))
    return spooled


def _build_target(
    repository: str, branch: str | None, uploads: list[tuple[str, object]],
    workspace_dir: Path, emit,
) -> tuple[TargetRepo, str]:
    """Git, файлы, или оба сразу."""
    target: TargetRepo | None = None
    name = ""
    if repository:
        emit("phase", {"phase": "materials_loading", "label": "Подключаем репозиторий"})
        git_repo, name = open_repo_source(repository, branch=branch)
        target = load_target(git_repo, branch)
    else:
        emit("phase", {"phase": "materials_loading", "label": "Обрабатываем загруженные файлы"})

    if uploads:
        target = (
            merge_with_uploads(target, uploads, workspace_dir) if target is not None
            else build_target_repo_from_uploads(uploads, workspace_dir)
        )
    elif target is None:
        target = build_empty_workspace(workspace_dir)
    emit("phase", {"phase": "materials_ready", "label": "Материалы проекта готовы"})
    return target, name


def _execute(
    job: AnalysisJob,
    journey_text: str,
    repository: str,
    branch: str | None,
    uploads: list[tuple[str, object]],
    tmp_dir: Path,
    spec: ModelSpec,
    description: str | None = None,
) -> None:
    """Тело прогона в своём потоке.

    `uploads` — пары «имя файла, путь на диске» (так их кладёт
    `create_analysis`) либо «имя, байты» — так их передают тесты.
    """
    def emit(kind: str, data: dict[str, Any]) -> None:
        job.events.put({"type": kind, **data})

    if not _SLOTS.acquire(blocking=False):
        emit("phase", {"phase": "queued", "label": "Ждём очереди — идут другие прогоны"})
        _SLOTS.acquire()
    try:
        target, name = _build_target(repository, branch, uploads, tmp_dir / "workspace", emit)
        # Архивы уже развёрнуты в workspace: исходные файлы формы больше не
        # нужны ни на диске, ни в памяти — на все пятнадцать минут сессии.
        uploads.clear()
        shutil.rmtree(tmp_dir / "uploads", ignore_errors=True)
        model = run_progress(
            journey_text, name, target, spec, on_event=emit, description=description,
        )

        job.result = build_dashboard_data(model)
        job.status = "READY"
        job.events.put({"type": "analysis_ready"})
    except PkoError as exc:
        job.error = {"message": exc.message, "hint": exc.hint}
        job.status = "ERROR"
        job.events.put({"type": "error", **job.error})
    except Exception as exc:  # noqa: BLE001
        job.error = {"message": "Внутренняя ошибка анализа.", "hint": str(exc)}
        job.status = "ERROR"
        job.events.put({"type": "error", **job.error})
    finally:
        _SLOTS.release()
        shutil.rmtree(tmp_dir, ignore_errors=True)

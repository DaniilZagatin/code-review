"""Phoenix tracing: один trace на весь прогон агента со структурой спанов.

Иерархия (см. `pipeline.run_progress` и `matcher._run_session`):

  pko.progress            ← корневой спан прогона (repo, branch, commit, model)
  ├── parse_journey       ← разбор текста инициативы
  ├── agent_session       ← агентский цикл
  │   ├── agent.step.1    ← шаг: LLM-вызов + reasoning + tool_calls
  │   │   └── [auto] LLM  ← Phoenix auto_instrument по chat.completions.create
  │   ├── agent.step.2
  │   ...
  ├── find_unclaimed
  └── build_model

`init_phoenix_tracing` должна отработать ДО создания любого OpenAI-клиента:
`register(auto_instrument=True)` перехватывает вызовы `chat.completions.create`
и строит по ним LLM-спаны, дочерние к текущему контексту. `trace_span` —
no-op, если трассировка выключена, поэтому код пайплайна не зависит от того,
идёт ли сбор трейсов.

`trace_cached_llm` создаёт LLM-спан вручную для ответов из кеша: при
кеш-попадании `chat.completions.create` не вызывается, auto_instrument
молчит, и в Phoenix не видно ни сообщений, ни промптов. Этот спан восполняет
их теми же атрибутами openinference, что и реальный перехват.
"""

import json as _json
import logging
import os
from contextlib import contextmanager
from typing import Any, Iterator, Optional

logger = logging.getLogger(__name__)


class _NoopSpan:
    """Заглушка для режима без трассировки: методы ничего не делают.

    Даёт коду пайплайна единый интерфейс `set_attribute`/`add_event`/
    `record_error` независимо от того, включён ли Phoenix — не нужно
    ветвить логику.
    """

    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def add_event(self, name: str, **attributes: Any) -> None:
        pass

    def record_error(self, exc: BaseException) -> None:
        pass


class _SpanHandle:
    """Тонкая обёртка над OTel-спаном: глотает ошибки наблюдаемости.

    Атрибуты, события и статусы — метаданные; ронять прогон ради них нельзя.
    """

    def __init__(self, span: Any) -> None:
        self._span = span

    def set_attribute(self, key: str, value: Any) -> None:
        if value is None:
            return
        try:
            self._span.set_attribute(key, value)
        except Exception:
            pass

    def add_event(self, name: str, **attributes: Any) -> None:
        try:
            if attributes:
                self._span.add_event(name, attributes=attributes)
            else:
                self._span.add_event(name)
        except Exception:
            pass

    def record_error(self, exc: BaseException) -> None:
        try:
            from opentelemetry.trace import Status, StatusCode
            self._span.record_exception(exc)
            self._span.set_status(Status(StatusCode.ERROR, str(exc)))
        except Exception:
            pass


# Tracer из Phoenix/OTel. None, если трассировка выключена или не
# инициализирована — в этом режиме `trace_span` работает как no-op,
# и код пайплайна не замечает отсутствия наблюдаемости.
_tracer: Optional[object] = None
# True после любой попытки инициализации (успех/отказ/выключено).
# Защищает от повторного `register`, который подменит global tracer provider.
_initialized: bool = False


def init_phoenix_tracing() -> Optional[object]:
    """Initialize Phoenix OpenTelemetry tracing for LLM calls.

    Returns tracer_provider if initialized, None if disabled or failed.
    Must be called before any OpenAI client creation.
    """
    global _tracer, _initialized

    if _initialized:
        return None

    enabled = os.environ.get("PKO_PHOENIX_ENABLED", "").lower() in ("1", "true", "yes", "on")
    if not enabled:
        logger.info("Phoenix tracing disabled via PKO_PHOENIX_ENABLED")
        _initialized = True
        return None

    try:
        from phoenix.otel import register

        host = os.environ.get("PKO_PHOENIX_HOST", "localhost")
        port = int(os.environ.get("PKO_PHOENIX_PORT", "6006"))
        endpoint = os.environ.get("PKO_PHOENIX_ENDPOINT") or f"http://{host}:{port}/v1/traces"
        project = os.environ.get("PKO_PHOENIX_PROJECT", "pko-progress")

        tracer_provider = register(
            project_name=project,
            endpoint=endpoint,
            auto_instrument=True,
            set_global_tracer_provider=True,
        )
        _tracer = tracer_provider.get_tracer("pko")
        _initialized = True

        logger.info(
            "Phoenix tracing initialized | project=%s | endpoint=%s",
            project, endpoint,
        )
        return tracer_provider

    except ImportError:
        logger.warning(
            "arize-phoenix not installed — tracing disabled. "
            "Install with: pip install arize-phoenix"
        )
        _initialized = True
        return None
    except Exception as e:
        logger.error("Failed to initialize Phoenix tracing: %s", e)
        _initialized = True
        return None


@contextmanager
def trace_span(name: str, **attributes: Any) -> Iterator[Any]:
    """Открыть именованный спан с атрибутами. No-op, если трассировка выключена.

    Все LLM-вызовы (автоинструментированные Phoenix) и дочерние `trace_span`
    внутри блока становятся дочерними к этому спану — так выстраивается
    иерархия одного trace. Атрибуты из `**attributes` ставятся при открытии;
    донастроить спан после выполнения фазы можно через возвращаемый хэндл:

        with trace_span("load_plan", format=".pptx") as span:
            slides = parse(...)
            span.set_attribute("slide_count", len(slides))
            span.add_event("parsed", slide_count=len(slides))

    Исключение внутри блока помечается на спане (`record_error`) и
    пробрасывается дальше — трассировка не глотает ошибки.
    """
    if _tracer is None:
        yield _NoopSpan()
        return

    with _tracer.start_as_current_span(name) as span:
        handle = _SpanHandle(span)
        for key, value in attributes.items():
            handle.set_attribute(key, value)
        try:
            yield handle
        except Exception as exc:
            handle.record_error(exc)
            raise


@contextmanager
def trace_cached_llm(
    name: str,
    messages: list[dict[str, Any]],
    output: dict[str, Any],
    *,
    model: str = "",
    tools: list[dict[str, Any]] | None = None,
    invocation_parameters: dict[str, Any] | None = None,
) -> Iterator[Any]:
    """LLM-спан для ответа из кеша — без сетевого вызова, но с теми же
    атрибутами, что openinference ставит на реальный `chat.completions.create`.

    Без этого Phoenix видит `agent.step` без дочернего LLM-спана на кеш-попаданиях:
    `ChatClient.chat` не вызывает `self._create()`, openinference не перехватывает,
    и в трейсе не видно ни сообщений, ни промптов, ни tool_calls. Этот спан
    восполняет их, чтобы трейс читался одинаково и для сетевого вызова, и для кеша.

    Атрибуты — openinference semconv, разложенные по полям (не единая JSON-строка),
    чтобы Phoenix показывал сообщения как список сущностей: каждое сообщение —
    отдельный блок с role/content/tool_calls, а не полотно текста.
    """
    if _tracer is None:
        yield _NoopSpan()
        return

    with _tracer.start_as_current_span(name) as span:
        handle = _SpanHandle(span)
        handle.set_attribute("openinference.span.kind", "LLM")
        handle.set_attribute("llm.system", "openai")
        if model:
            handle.set_attribute("llm.model_name", model)

        # Каждое сообщение — отдельный набор атрибутов с индексом, как openinference:
        # llm.input_messages.{i}.message.role, .message.content, .message.tool_calls.{j}...
        for i, msg in enumerate(messages):
            prefix = f"llm.input_messages.{i}.message"
            role = msg.get("role")
            if role:
                handle.set_attribute(f"{prefix}.role", role)
            content = msg.get("content")
            if content is not None:
                handle.set_attribute(f"{prefix}.content",
                                     content if isinstance(content, str)
                                     else _json.dumps(content, ensure_ascii=False))
            if tcid := msg.get("tool_call_id"):
                handle.set_attribute(f"{prefix}.tool_call_id", tcid)
            if name_ := msg.get("name"):
                handle.set_attribute(f"{prefix}.name", name_)
            for j, tc in enumerate(msg.get("tool_calls") or []):
                tcp = f"{prefix}.tool_calls.{j}.tool_call"
                if tcid := tc.get("id"):
                    handle.set_attribute(f"{tcp}.id", tcid)
                fn = tc.get("function") or {}
                if fn.get("name"):
                    handle.set_attribute(f"{tcp}.function.name", fn["name"])
                if fn.get("arguments"):
                    handle.set_attribute(f"{tcp}.function.arguments", fn["arguments"])

        # Output-сообщение — то же разложение.
        for j, tc in enumerate(output.get("tool_calls") or []):
            tcp = f"llm.output_messages.0.message.tool_calls.{j}.tool_call"
            if tcid := tc.get("id"):
                handle.set_attribute(f"{tcp}.id", tcid)
            fn = tc.get("function") or {}
            if fn.get("name"):
                handle.set_attribute(f"{tcp}.function.name", fn["name"])
            if fn.get("arguments"):
                handle.set_attribute(f"{tcp}.function.arguments", fn["arguments"])
        handle.set_attribute("llm.output_messages.0.message.role",
                             output.get("role", "assistant"))
        if output.get("content") is not None:
            handle.set_attribute("llm.output_messages.0.message.content",
                                 output.get("content", ""))

        # JSON-дампы для совместимости (input.value/output.value).
        handle.set_attribute("input.value", _json.dumps(messages, ensure_ascii=False))
        handle.set_attribute("output.value", _json.dumps(output, ensure_ascii=False))

        if tools:
            for k, tool in enumerate(tools):
                handle.set_attribute(f"llm.tools.{k}.tool.json_schema",
                                     _json.dumps(tool, ensure_ascii=False))
        if invocation_parameters:
            handle.set_attribute("llm.invocation_parameters",
                                 _json.dumps(invocation_parameters, ensure_ascii=False))
        handle.set_attribute("from_cache", True)
        yield handle

"""Карта исполнения (раздел 7 паспорта) — компоновка из готовых фактов.

Не новый AST-экстрактор: точками входа, единицами и переходами уже занимаются
`python_code`/`sql_code`/`java_code`/`contracts`. Здесь факты собираются в
связную карту: ROUTE → точки входа, TOOL/GRAPH_NODE → единицы исполнения,
GRAPH_EDGE → переходы, EXTERNAL/LLM_CALL → недетерминизм и внешние
взаимодействия.

Принцип FILL_SPEC: `observed` — только то, что реально найдено, с `path:line`.
Чего статически не восстанавливается (точки выхода, идемпотентность,
поведение при ошибке) — `не искали`, а не догадка. Неполный граф лучше
отсутствующего, но только если его неполнота объявлена (FILL_SPEC §6).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pko.extractors.base import Fact
from pko.extractors.runner import Extraction

# Виды фактов, которые несут точки входа.
_ENTRY_KINDS = ("ROUTE",)
# Единицы исполнения: инструменты агента, узлы графа, функции-обработчики.
_UNIT_KINDS = ("TOOL", "GRAPH_NODE")
# Переходы графа.
_EDGE_KINDS = ("GRAPH_EDGE",)
# Источники недетерминизма: всё, из-за чего два одинаковых входа дают разный
# результат — вызов модели, ответ внешней системы, конкурентность.
_NONDET_KINDS = ("LLM_CALL", "EXTERNAL")
# Необратимые внешние эффекты: запись во внешнюю систему, изменяющий SQL.
_IRREVERSIBLE_KINDS = ("SQL_WRITE",)


@dataclass
class ExecutionMap:
    entries: list[dict[str, Any]] = field(default_factory=list)
    units: list[dict[str, Any]] = field(default_factory=list)
    edges: list[dict[str, Any]] = field(default_factory=list)
    exits: list[dict[str, Any]] = field(default_factory=list)
    nondeterminism: list[dict[str, Any]] = field(default_factory=list)
    ascii: str = ""
    # Что искали, но не нашли — честно по FILL_SPEC.
    not_searched: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "entries": self.entries,
            "units": self.units,
            "edges": self.edges,
            "exits": self.exits,
            "nondeterminism": self.nondeterminism,
            "ascii": self.ascii,
            "not_searched": self.not_searched,
        }


def build_execution_map(extraction: Extraction) -> ExecutionMap:
    """Собрать раздел 7 из фактов экстракторов."""
    facts = extraction.facts
    by_kind = _index_by_kind(facts)

    entries = _entries(by_kind)
    units = _units(by_kind)
    edges = _edges(by_kind)
    exits = _exits(by_kind, entries)
    nondet = _nondeterminism(by_kind)
    ascii = _ascii_diagram(entries, units, edges)

    not_searched = [
        "точки выхода: статический разбор return-точек не реализован",
        "идемпотентность: отдельного экстрактора нет",
        "поведение при ошибке: обработка исключений не разбирается",
        "ветка по умолчанию для условных переходов: статически не проверяется",
    ]
    if not edges:
        not_searched.append("переходы: граф вызовов не найден или пуст")

    return ExecutionMap(
        entries=entries, units=units, edges=edges, exits=exits,
        nondeterminism=nondet, ascii=ascii, not_searched=not_searched,
    )


def _index_by_kind(facts: list[Fact]) -> dict[str, list[Fact]]:
    out: dict[str, list[Fact]] = {}
    for f in facts:
        out.setdefault(f.kind, []).append(f)
    return out


def _ref(fact: Fact) -> str:
    if fact.line:
        return f"{fact.path}:{fact.line}"
    return fact.path or ""


def _entries(by_kind: dict[str, list[Fact]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for fact in by_kind.get("ROUTE", []):
        key = str(fact.key)
        if key in seen:
            continue
        seen.add(key)
        value = fact.value if isinstance(fact.value, dict) else {}
        rows.append({
            "id": f"IN-{len(rows) + 1:03d}",
            "name": key,
            "kind": "http_endpoint",
            "initiator": "внешний клиент",
            "does": fact.basis or "не искали",
            "authn": "не искали",
            "rate_limit": "не искали",
            "ref": _ref(fact),
        })
    return rows


def _units(by_kind: dict[str, list[Fact]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    # Внешние взаимодействия и необратимые эффекты собираем, чтобы приписать
    # единицам, где они встречаются. Точное соответствие «факт → единица» по
    # пути файла: грубее AST, но без нового разбора.
    externals_by_path = _by_path(by_kind, _NONDET_KINDS)
    irreversible_by_path = _by_path(by_kind, _IRREVERSIBLE_KINDS)
    limits = by_kind.get("LIMIT", [])

    for kind in _UNIT_KINDS:
        for fact in by_kind.get(kind, []):
            key = str(fact.key)
            if key in seen:
                continue
            seen.add(key)
            ext = externals_by_path.get(fact.path, [])
            irr = irreversible_by_path.get(fact.path, [])
            rows.append({
                "id": f"U-{len(rows) + 1:03d}",
                "name": key,
                "does": fact.basis or "не искали",
                "ref": _ref(fact),
                "nondeterminism": ", ".join(sorted({str(e.key) for e in ext})) or "не искали",
                "externals": ", ".join(sorted({str(e.key) for e in ext})) or "не искали",
                "irreversible": "да" if irr else "не искали",
                "control_before": "не искали",
                "limit": ", ".join(f"{f.key}={f.value}" for f in limits if f.path == fact.path) or "не искали",
                "on_error": "не искали",
                "idempotent": "не искали",
            })
    return rows


def _unit_kind_label(kind: str) -> str:
    return {"TOOL": "agent_tool", "GRAPH_NODE": "graph_node"}.get(kind, kind.lower())


def _edges(by_kind: dict[str, list[Fact]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for fact in by_kind.get("GRAPH_EDGE", []):
        key = str(fact.key)
        if key in seen:
            continue
        seen.add(key)
        value = fact.value if isinstance(fact.value, dict) else {}
        conditional = value.get("conditional") if isinstance(value, dict) else False
        rows.append({
            "from": str(value.get("from", "?")) if isinstance(value, dict) else "?",
            "to": str(value.get("to", "?")) if isinstance(value, dict) else "?",
            "condition": "условный" if conditional else "безусловный",
            "decided_by": "код",
            "has_default": "не искали",
            "ref": _ref(fact),
        })
    return rows


def _exits(by_kind: dict[str, list[Fact]], entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Точки выхода.

    Статически return-точки не разбираются. HTTP-эндпоинт одновременно точка
    входа и точка выхода (ответ клиенту) — помечаем как кандидат, остальное
    честно помечаем «не искали».
    """
    rows: list[dict[str, Any]] = []
    for i, entry in enumerate(entries, start=1):
        rows.append({
            "id": f"OUT-{i:03d}",
            "name": entry["name"],
            "kind": "http_response",
            "returns": "не искали",
            "side_state": "не искали",
            "ref": entry["ref"],
        })
    return rows


def _nondeterminism(by_kind: dict[str, list[Fact]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for kind in _NONDET_KINDS:
        for fact in by_kind.get(kind, []):
            spot = (kind, str(fact.key), fact.path, fact.line)
            if spot in seen:
                continue
            seen.add(spot)
            rows.append({
                "id": f"ND-{len(rows) + 1:03d}",
                "name": str(fact.key),
                "kind": "llm_call" if kind == "LLM_CALL" else "external_system",
                "affects": "не искали",
                "reproducible": "нет",
                "ref": _ref(fact),
            })
    return rows


def _by_path(by_kind: dict[str, list[Fact]], kinds: tuple[str, ...]) -> dict[str, list[Fact]]:
    out: dict[str, list[Fact]] = {}
    for kind in kinds:
        for fact in by_kind.get(kind, []):
            out.setdefault(fact.path, []).append(fact)
    return out


def _ascii_diagram(
    entries: list[dict[str, Any]],
    units: list[dict[str, Any]],
    edges: list[dict[str, Any]],
) -> str:
    """Компактная схема: отступ = вложенность, `→` = переход (FILL_SPEC §6)."""
    if not entries and not units:
        return "(карта исполнения не восстановлена)"
    lines: list[str] = []
    for entry in entries[:12]:
        lines.append(f"[вход] {entry['name']}  ({entry['ref']})")
        # Единицы того же файла — кандидаты на «что делает вход».
        for unit in units:
            if unit["ref"].split(":")[0] == entry["ref"].split(":")[0]:
                lines.append(f"  → {unit['name']}  ({unit['kind']})")
    if edges:
        lines.append("")
        lines.append("переходы:")
        for edge in edges[:12]:
            lines.append(f"  {edge['from']} → {edge['to']}  [{edge['condition']}]")
    return "\n".join(lines)

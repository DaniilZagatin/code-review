"""Выдержки-свидетельства (раздел 12 паспорта).

Фрагменты кода вокруг узловых точек — чтобы анализирующая модель судила
самостоятельно, а не доверяла разметке (FILL_SPEC §5). 10–15 фрагментов по
5–20 строк, отобранных по приоритету:

1. Подтверждённые evidence буллитов — самые полезные: читатель видит код,
   который закрывает пункт, и может оспорить статус.
2. Места, где статус утверждает результат, но подтверждённой ссылки нет
   (`E3`): возможность оспорить разметку.
3. Системный промпт — если найден, это ключ к поведению агента.

Всё оборачивается в `<repo-content untrusted="true">` — содержимое репозитория
это данные, а не инструкции (FILL_SPEC §0.3).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from pko.extractors.base import Tree
from pko.progress.schema import ItemVerdict, EvidenceRef

MAX_EXCERPTS = 15
_WINDOW = 10  # строк до и после — чтобы 5–20 строк на фрагмент
_MAX_LINES = 20


@dataclass
class Excerpt:
    id: str
    title: str
    path: str
    line: int
    lang: str
    code: str
    relates_to: str
    reason: str
    # v3: что здесь происходит — пишется ДО кода, читается моделью вместо него,
    # если синтаксис не разобран. Пустой explanation — брак (FILL_SPEC v3 §7).
    explanation: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "title": self.title, "path": self.path,
            "line": self.line, "lang": self.lang, "code": self.code,
            "relates_to": self.relates_to, "reason": self.reason,
            "explanation": self.explanation,
        }


def build_excerpts(
    verdicts: list[ItemVerdict], tree: Tree, prompts: list | None = None,
) -> list[dict[str, Any]]:
    """Собрать выдержки для раздела 12.

    `prompts` — факты kind=PROMPT (файлы промптов), если есть.
    """
    out: list[Excerpt] = []
    seen: set[tuple[str, int]] = set()

    # 1. Подтверждённые evidence.
    for verdict in verdicts:
        item_id = verdict.item_id
        for idx, criterion in enumerate(verdict.criteria, start=1):
            if not criterion.applicable:
                continue
            for ref in criterion.verified_evidence:
                spot = (ref.path, ref.line or 0)
                if spot in seen or len(out) >= MAX_EXCERPTS:
                    continue
                seen.add(spot)
                excerpt = _excerpt_from_ref(
                    f"L-{len(out) + 1:03d}", ref, tree,
                    relates_to=f"{item_id}/буллит {idx}",
                    reason="подтверждённая evidence статуса",
                )
                if excerpt:
                    out.append(excerpt)

    # 2. Статус без подтверждения (E3) — кандидат на оспаривание.
    for verdict in verdicts:
        item_id = verdict.item_id
        for idx, criterion in enumerate(verdict.criteria, start=1):
            if not criterion.applicable or criterion.status == "planned":
                continue
            if criterion.verified_evidence:
                continue
            # Нет подтверждённой ссылки — берём любую неподтверждённую.
            for ref in criterion.evidence:
                spot = (ref.path, ref.line or 0)
                if spot in seen or len(out) >= MAX_EXCERPTS:
                    continue
                seen.add(spot)
                excerpt = _excerpt_from_ref(
                    f"L-{len(out) + 1:03d}", ref, tree,
                    relates_to=f"{item_id}/буллит {idx}",
                    reason="статус без подтверждённой ссылки — проверь код",
                )
                if excerpt:
                    out.append(excerpt)
                break

    # 3. Системный промпт.
    for fact in (prompts or [])[:2]:
        if len(out) >= MAX_EXCERPTS:
            break
        text = tree.read(fact.path) or ""
        if not text:
            continue
        out.append(Excerpt(
            id=f"L-{len(out) + 1:03d}",
            title=f"Промпт: {fact.key}",
            path=fact.path, line=1, lang="markdown",
            code=text[:2000],
            relates_to="системный промпт",
            reason="промпт задаёт поведение модели",
            explanation=f"Системный промпт из файла {fact.path}: задаёт поведение модели и её роль.",
        ))

    return [e.to_dict() for e in out]


def _excerpt_from_ref(
    excerpt_id: str, ref: EvidenceRef, tree: Tree,
    relates_to: str, reason: str,
) -> Excerpt | None:
    if not ref.path or ref.line is None:
        return None
    text = tree.read(ref.path)
    if text is None:
        return None
    lines = text.splitlines()
    start = max(0, (ref.line or 1) - _WINDOW)
    end = min(len(lines), (ref.line or 1) + _WINDOW)
    code = "\n".join(lines[start:end])
    if not code.strip():
        return None
    # v3: explanation — что здесь происходит, словами. Берём из note evidence
    # (агент уже написал, что происходит в этой строке), иначе формулируем из
    # reason. Пустым быть не может — FILL_SPEC v3 §7 называет это браком.
    explanation = ref.note or f"{reason}: код в {ref.path}:{ref.line}."
    return Excerpt(
        id=excerpt_id,
        title=f"{ref.path}:{ref.line}",
        path=ref.path, line=ref.line or 1,
        lang=_lang_for(ref.path),
        code=code[:4000],
        relates_to=relates_to,
        reason=reason,
        explanation=explanation,
    )


def _lang_for(path: str) -> str:
    lower = path.lower()
    if lower.endswith(".py"):
        return "python"
    if lower.endswith(".sql"):
        return "sql"
    if lower.endswith(".java"):
        return "java"
    if lower.endswith((".yaml", ".yml")):
        return "yaml"
    if lower.endswith(".json"):
        return "json"
    if lower.endswith(".md"):
        return "markdown"
    return ""

"""Реестр контролей и инвариантов (раздел 13 паспорта).

Контроль — то, что отклоняет, ограничивает или изменяет исполнение (FILL_SPEC
§6). Логирование и метрики контролем не являются — их место в разделе 8.

Источники:
* `LIMIT`/`ALLOWLIST` факты из `policy_specs`/`python_code` — объявленные
  ограничения. `gate_eligible=False` у них не случайно: объявленный лимит — не
  применённый (см. `policy_specs.py`). В паспорт идут как `declared`-кандидаты.
* regex-поиск `raise`/`validate`/`assert` в коде — активные контроли в
  реализации. Это не AST-разбор, а сигнатурный поиск; точность средняя, что
  отражается в `Уверенность` раздела 11.

Чего нет (`Обходится`, `До или после эффекта` по коду, `Проверен тестом`)
помечается `не искали` — честно по FILL_SPEC, без догадок.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from pko.extractors.base import Tree, is_vendor, CODE_SUFFIXES
from pko.extractors.runner import Extraction

# Шаблоны активных контролей в коде. Не AST — сигнатурный поиск по строкам.
# Точность средняя: `raise ValueError` это контроль, `raise NotImplementedError`
# — нет; различаем по сообщению/типу грубо.
_CONTROL_PATTERNS = [
    (re.compile(r"\braise\s+(ValueError|TypeError|PermissionError|RuntimeError|HTTPException|Forbidden|Unauthorized)\b"), "raise"),
    (re.compile(r"\bassert\b"), "assert"),
    (re.compile(r"\b(validate|verify|check|enforce|guard|require_permission|authorize)\s*\("), "validate"),
    (re.compile(r"\bif\s+not\s+\w+\s*(?:==|<|>|<=|>=|is)\s"), "guard_if"),
]
# Типы исключений, которые не контроль, а заглушка.
_NOT_CONTROL = {"NotImplementedError", "StopIteration", "GeneratorExit"}

MAX_CONTROLS = 60


@dataclass
class ControlsMap:
    controls: list[dict[str, Any]] = field(default_factory=list)
    irreversible_effects: list[dict[str, Any]] = field(default_factory=list)
    management: dict[str, Any] = field(default_factory=dict)
    not_searched: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "controls": self.controls,
            "irreversible_effects": self.irreversible_effects,
            "management": self.management,
            "not_searched": self.not_searched,
        }


def build_controls(extraction: Extraction, tree: Tree) -> ControlsMap:
    controls = _declared_controls(extraction)
    controls.extend(_active_controls(tree))
    controls = controls[:MAX_CONTROLS]

    irreversible = _irreversible_effects(extraction, controls)
    management = _management(extraction)
    not_searched = [
        "обход контроля: отдельного поиска административных флагов и путов в обход валидации нет",
        "порядок «до или после эффекта» по коду: статического сопоставления позиций нет",
        "проверка контролем тестом: связь «контроль ↔ тест» не разбирается",
    ]
    return ControlsMap(
        controls=controls, irreversible_effects=irreversible,
        management=management, not_searched=not_searched,
    )


def _declared_controls(extraction: Extraction) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for fact in extraction.by_kind("LIMIT"):
        rows.append(_row(
            invariant=f"параметр {fact.key} ограничен",
            mechanism=f"{fact.key} = {fact.value}",
            kind=_kind_label("limit"),
            ref=f"{fact.path}:{fact.line or 1}",
            protects="потребление ресурса",
            source="declared",
        ))
    for fact in extraction.by_kind("ALLOWLIST"):
        rows.append(_row(
            invariant=f"допустимы только значения из перечня {fact.key}",
            mechanism=f"перечень {fact.key}",
            kind=_kind_label("allowlist"),
            ref=f"{fact.path}:{fact.line or 1}",
            protects="область допустимых входов",
            source="declared",
        ))
    return rows


def _active_controls(tree: Tree) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, int]] = set()
    for path in tree.files:
        if is_vendor(path) or not path.endswith(".py"):
            continue
        text = tree.read(path) or ""
        for line_no, line in enumerate(text.splitlines(), start=1):
            for pattern, kind in _CONTROL_PATTERNS:
                match = pattern.search(line)
                if not match:
                    continue
                # raise NotImplementedError — не контроль.
                if kind == "raise" and match.group(1) in _NOT_CONTROL:
                    continue
                key = (path, line_no)
                if key in seen:
                    continue
                seen.add(key)
                rows.append(_row(
                    invariant=line.strip()[:120],
                    mechanism=line.strip()[:120],
                    kind=_kind_label(kind),
                    ref=f"{path}:{line_no}",
                    protects="не искали",
                    source="observed",
                ))
                break
        if len(rows) >= MAX_CONTROLS:
            break
    return rows


def _kind_label(kind: str) -> str:
    return {
        "raise": "валидация входа",
        "assert": "валидация входа",
        "validate": "проверка прав",
        "guard_if": "лимит потребления",
        "limit": "лимит потребления",
        "allowlist": "ограничение доступа",
    }.get(kind, kind)


def _row(
    invariant: str, mechanism: str, kind: str, ref: str,
    protects: str, source: str,
) -> dict[str, Any]:
    return {
        "id": "",
        "invariant": invariant,
        "mechanism": mechanism,
        "kind": kind,
        "ref": ref,
        "protects": protects,
        "order": "не искали",
        "active": "да" if source == "observed" else "объявлено",
        "on_trigger": "отказ" if source == "observed" else "не искали",
        "bypass": "не искали",
        "test_ref": "не искали",
        "source": source,
    }


def _irreversible_effects(
    extraction: Extraction, controls: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for fact in extraction.by_kind("SQL_WRITE"):
        # Контроли до — грубо: контроля того же файла.
        before = ", ".join(
            c["id"] or c["kind"]
            for c in controls
            if c["ref"].split(":")[0] == fact.path
        ) or "не искали"
        rows.append({
            "id": f"IE-{len(rows) + 1:03d}",
            "effect": f"SQL, изменяющий данные: {fact.value}"[:120],
            "unit": f"{fact.path}:{fact.line or 1}",
            "controls": before,
            "compensation": "не искали",
            "test_ref": "не искали",
        })
    return rows


def _management(extraction: Extraction) -> dict[str, Any]:
    limits = extraction.by_kind("LIMIT")
    return {
        "consumption_limits": ", ".join(f"{f.key}={f.value}" for f in limits[:8]) or "не искали",
        "kill_switch": "не искали",
        "kill_switch_authority": "не искали",
        "rollback": "не искали",
        "feature_flags": "не искали",
        "degradation": "не искали",
    }

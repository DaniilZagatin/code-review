"""Карта отсутствий (раздел 11 паспорта).

Симметрична разделу 9: что искали и не нашли, и чего не искали вовсе (FILL_SPEC
§4). Отсутствие контроля невозможно вывести из перечня присутствующих фактов —
поэтому раздел обязателен.

Формируется из **фиксированного перечня целей поиска**, а не из того, что
случайно не нашлось. Для каждой цели — строка, даже если нашлось: `не найдено`
или `найдено частично` честнее умолчания. Поле `Уверенность`: `высокая` — поиск
по фактам AST-экстракторов; `средняя` — сигнатурный поиск; `низкая` — эвристика.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from pko.extractors.base import Tree, is_vendor
from pko.extractors.runner import Extraction
from pko.extractors.execution_map import ExecutionMap
from pko.extractors.controls import ControlsMap


@dataclass
class Absence:
    id: str
    target: str
    scope: str
    result: str
    # v3: что это означает практически — обязательная колонка (FILL_SPEC v3 §6).
    implication: str
    confidence: str
    related: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "target": self.target, "scope": self.scope,
            "result": self.result, "implication": self.implication,
            "confidence": self.confidence, "related": self.related,
        }


def build_absences(
    extraction: Extraction, tree: Tree,
    execution: ExecutionMap, controls: ControlsMap,
) -> list[dict[str, Any]]:
    out: list[Absence] = []
    for index, (target, checker, confidence) in enumerate(_targets(), start=1):
        result, related = checker(extraction, tree, execution, controls)
        implication = _implication(target, result)
        out.append(Absence(
            id=f"A-{index:03d}",
            target=target,
            scope="код и конфигурация репозитория",
            result=result,
            implication=implication,
            confidence=confidence,
            related=related,
        ))
    return [a.to_dict() for a in out]


def _implication(target: str, result: str) -> str:
    """Что отсутствие означает практически — FILL_SPEC v3 §6 требует это явно.

    Не оценка и не рекомендация — последствие для работы системы, изложенное
    нейтрально. Модель оценит вес; заполнитель описывает, что случится.
    """
    if result == "не искали":
        return f"вес {target} неизвестен: поиск не проводился, вывод сделать нельзя"
    if result == "не найдено":
        return f"без {target} система уязвима к соответствующему классу отказов"
    if result == "найдено частично":
        return f"{target} есть не везде — защита неполна, охват надо проверять по месту"
    return f"влияние {target} на вывод не определено"


def _targets() -> list[tuple[str, Any, str]]:
    """Фиксированный перечень целей поиска (FILL_SPEC §4, ядро).

    Возвращается функцией, а не модулем: чекеры определены ниже, и модульный
    список на верхнем уровне не видел бы их имён.
    """
    return [
        ("контроль перед каждым необратимым эффектом", _has_control_before_irreversible, "высокая"),
        ("обработка ошибки для каждой единицы исполнения", _has_error_handling, "средняя"),
        ("обработка таймаута для каждого внешнего взаимодействия", _has_timeout, "высокая"),
        ("ветка по умолчанию для каждого условного перехода", _has_default_branch, "низкая"),
        ("тест, подтверждающий срабатывание каждого контроля", _has_control_test, "средняя"),
        ("тест на каждую точку выхода типа «отказ»", _has_exit_test, "средняя"),
        ("компенсация или откат для каждого необратимого эффекта", _has_rollback, "низкая"),
        ("ограничения потребления (время, стоимость, частота)", _has_consumption_limits, "высокая"),
        ("механизм остановки исполнения", _has_kill_switch, "низкая"),
        ("проверка полномочий перед записью во внешнюю систему", _has_authz_before_write, "средняя"),
        ("корреляция запросов в логах", _has_request_correlation, "низкая"),
        ("ретенция промежуточных данных", _has_data_retention, "низкая"),
        ("идемпотентность для каждой повторяемой единицы", _has_idempotency, "низкая"),
    ]


# --- проверки по целям ------------------------------------------------------
# Каждая возвращает (result, related): `не найдено` / `найдено частично` / `не искали`.


def _has_control_before_irreversible(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    irr = controls.irreversible_effects
    if not irr:
        return "не искали", "необратимые эффекты не найдены"
    covered = [e for e in irr if e["controls"] != "не искали" and e["controls"]]
    if len(covered) == len(irr):
        return "найдено частично", f"контроли рядом со всеми {len(irr)} эффектами"
    return "не найдено", f"контроли рядом с {len(covered)} из {len(irr)} эффектов"


def _has_error_handling(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    found = False
    for path in tree.files:
        if is_vendor(path) or not path.endswith(".py"):
            continue
        text = tree.read(path) or ""
        if "try:" in text or "except" in text:
            found = True
            break
    return ("найдено частично" if found else "не найдено", "try/except в Python")


def _has_timeout(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    limits = [f for f in extraction.by_kind("LIMIT") if "timeout" in str(f.key).lower()]
    return ("найдено частично" if limits else "не найдено",
            f"{len(limits)} лимитов timeout")


def _has_default_branch(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    edges = execution.edges
    if not edges:
        return "не искали", "переходы не найдены"
    unknown = [e for e in edges if e["has_default"] == "не искали"]
    return "не искали", f"{len(unknown)} переходов, ветка по умолчанию не проверена"


def _has_control_test(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    tests = extraction.by_kind("TEST") + extraction.by_kind("TEST_REPORT")
    return ("найдено частично" if tests else "не найдено",
            f"{len(tests)} фактов тестов")


def _has_exit_test(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    tests = extraction.by_kind("TEST_REPORT")
    if not tests:
        return "не найдено", "отчётов тестов нет"
    return "найдено частично", f"{len(tests)} отчётов тестов"


def _has_rollback(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    found = False
    for path in tree.files:
        if is_vendor(path) or not path.endswith(".py"):
            continue
        text = tree.read(path) or ""
        if re.search(r"\b(rollback|revert|undo|compensate)\b", text, re.IGNORECASE):
            found = True
            break
    return ("найдено частично" if found else "не найдено", "rollback/revert/undo в Python")


def _has_consumption_limits(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    limits = extraction.by_kind("LIMIT")
    return ("найдено частично" if limits else "не найдено",
            f"{len(limits)} лимитов потребления")


def _has_kill_switch(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    found = False
    for path in tree.files:
        if is_vendor(path) or not path.endswith(".py"):
            continue
        text = tree.read(path) or ""
        if re.search(r"\b(kill|stop|abort|shutdown|cancel)\b", text, re.IGNORECASE):
            found = True
            break
    return ("найдено частично" if found else "не найдено", "kill/stop/abort в Python")


def _has_authz_before_write(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    writes = extraction.by_kind("SQL_WRITE")
    authz = [c for c in controls.controls if c["kind"] == "проверка прав"]
    if not writes:
        return "не искали", "записей во внешнюю систему не найдено"
    if authz:
        return "найдено частично", f"{len(authz)} проверок прав, {len(writes)} записей"
    return "не найдено", f"{len(writes)} записей, проверок прав не найдено"


def _has_request_correlation(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    found = False
    for path in tree.files:
        if is_vendor(path) or not path.endswith(".py"):
            continue
        text = tree.read(path) or ""
        if re.search(r"\b(trace|correlation|request_id|x-request-id|span)\b", text, re.IGNORECASE):
            found = True
            break
    return ("найдено частично" if found else "не найдено", "trace/correlation/span в Python")


def _has_data_retention(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    limits = [f for f in extraction.by_kind("LIMIT") if "ttl" in str(f.key).lower()]
    settings = [f for f in extraction.by_kind("SETTING") if "retention" in str(f.key).lower() or "ttl" in str(f.key).lower()]
    found = limits or settings
    return ("найдено частично" if found else "не найдено", f"ttl/retention: {len(found)}")


def _has_idempotency(
    extraction: Extraction, tree: Tree, execution: ExecutionMap, controls: ControlsMap,
) -> tuple[str, str]:
    found = False
    for path in tree.files:
        if is_vendor(path) or not path.endswith(".py"):
            continue
        text = tree.read(path) or ""
        if re.search(r"\b(idempotent|dedup|deduplicate)\b", text, re.IGNORECASE):
            found = True
            break
    return ("найдено частично" if found else "не найдено", "idempotent/dedup в Python")

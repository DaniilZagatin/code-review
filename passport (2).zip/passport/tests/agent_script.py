"""Заготовки вызовов агента для сквозных тестов (CLI, веб, пайплайн).

Сценарий: оценка этапа → вердикт → finish. submit_plan больше нет — план
разбирается кодом из текстового поля, агент только проверяет пункты.
"""

import json

CLIENT_PATH_NAME = "Постановка задачи в работу"
PROJECT_NAME = "Редизайн платёжного сервиса"
BEFORE = "задача пересылается вручную и теряется между сменами"
NOW = "задача видна в системе, но без автоматической маршрутизации"
AFTER = "задача попадает исполнителю сразу и видна обеим сторонам"

DESCRIPTION = (
    "Раньше задачи пересылались вручную и терялись между сменами. Теперь "
    "задача попадает исполнителю сразу и видна обеим сторонам."
)

STAGE_ID = "postanovka-zadach"
STAGE_TITLE = "Постановка задач"
STAGE_DESCRIPTION = "Клиент передаёт задачу в работу и видит её статус без звонка"
BULLETS = ["Определены источники обращений", "Подтверждена скорость обработки"]

CONCLUSION = [
    "Ценность подтверждена материалами",
    "Измеримость результата не закрыта",
    "Можно идти дальше",
]

ROUTER_EVIDENCE = [{"path": "backend/src/api/v1/router.py", "line": 7,
                    "basis": "функция start_task ставит задачу в обработку"}]

CONTEXT = {
    "client_path_name": CLIENT_PATH_NAME,
    "project_name": PROJECT_NAME,
    "before": BEFORE,
    "now": NOW,
    "after": AFTER,
}

JOURNEY_TEXT = "\n".join([
    f"Клиентский путь: {CLIENT_PATH_NAME}",
    f"Проект: {PROJECT_NAME}",
    f"Было: {BEFORE}",
    f"Сейчас: {NOW}",
    f"Стало: {AFTER}",
    "",
    f"## {STAGE_TITLE}",
    f"- {BULLETS[0]}",
    f"- {BULLETS[1]}",
])


def tool_call(call_id: str, name: str, **args) -> dict:
    return {"content": None, "tool_calls": [{
        "id": call_id, "type": "function",
        "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


# Раскрытие пункта — два буллита человеческим языком. Ссылок на репозиторий
# в тексте нет намеренно: их отклоняет гейт, потому что в отчёт они не идут.
# Для не-зелёных статусов «Проверка» обязана быть развёрнутой: что похожее
# нашлось и чего именно из буллита не нашлось. Короче 120 символов гейт такую
# оценку не принимает — заглушки написаны так же, как их писал бы агент.
PROOF = {
    "done": "Код есть и работает: путь от заявки до обработки проходит целиком.",
    "limited": (
        "Приём заявок и передача исполнителю работают. Ограничение в том, что "
        "обрабатываются не все типы обращений: часть уходит в общую очередь и "
        "дальше её ведут вручную."
    ),
    "unused": (
        "Код передачи заявки исполнителю написан и рабочий, обходится без "
        "ручных шагов. В текущем сценарии до него не доходит очередь: вызова "
        "из рабочего пути нет."
    ),
    "partial": (
        "Регистрация заявки в системе есть и работает. Дальнейшей передачи "
        "исполнителю не нашлось: после регистрации заявка остаётся в списке, "
        "и сквозной путь не отрабатывает."
    ),
    "planned": (
        "Похожего в коде нашлась только регистрация обращения без дальнейшей "
        "обработки. Ни маршрутизации по исполнителям, ни уведомления сторон "
        "не нашлось: этого в коде нет."
    ),
    "blocked": (
        "Код приёма заявки есть и работает, но результат дальше не уходит: "
        "следующий шаг пути ждёт его и без него не начинается."
    ),
}
HOW = {
    "done": "Заявка попадает исполнителю сразу, обе стороны видят её статус.",
    "limited": "Заявка доходит до исполнителя, кроме отдельных случаев.",
    "unused": "Функция готова, но её никто не вызывает.",
    "partial": "Заявка регистрируется, дальше её ведут руками.",
    "planned": "Пока делается вручную.",
    "blocked": "Дальше по пути ничего не происходит.",
}


def stage_args(item_id: str = STAGE_ID, applicable: bool = True,
               statuses: list[str] | None = None,
               evidence: list[dict] | None = None) -> dict:
    statuses = statuses or ["done", "planned"]
    criteria = []
    for status in statuses:
        row: dict = {
            "applicable": True, "status": status,
            "proof": PROOF.get(status, ""), "how": HOW.get(status, ""),
        }
        if status != "planned":
            row["evidence"] = ROUTER_EVIDENCE if evidence is None else evidence
        criteria.append(row)
    return {"item_id": item_id, "applicable": applicable, "criteria": criteria}


# Верхнеуровневая оценка целого: её модель присылает сама, в отличие от
# готовности и решения — те считает код.
MATCH = "mostly"
MATCH_NOTE = (
    "Система принимает файл модели и считает по нему сценарии, "
    "а готовых форм под материалы сделки в ней пока нет."
)


def summary_args(
    decision: str = "PIVOT",
    match: str = MATCH,
    match_note: str = MATCH_NOTE,
) -> dict:
    # `decision` модель больше не присылает — решение считает код. Параметр
    # оставлен, чтобы сценарии тестов не переписывать под каждый вызов.
    return {
        "conclusion": list(CONCLUSION),
        "match": match,
        "match_note": match_note,
    }


def brief_args(before: str = BEFORE, now: str = NOW, after: str = AFTER) -> dict:
    return {"before": before, "now": now, "after": after}


def full_session(**kwargs) -> list[dict]:
    """Полный сценарий: brief (из описания) → оценка этапа → контр-проверка → вердикт → finish."""
    calls = []
    if kwargs.get("with_brief"):
        calls.append(tool_call("call_brief", "submit_brief", **brief_args(
            **kwargs.get("brief", {}),
        )))
    calls.append(tool_call("call_stage", "submit_stage", **stage_args(**kwargs.get("stage", {}))))
    calls.append(tool_call("call_review", "submit_review", confirmed=True, notes="проверено"))
    calls.append(tool_call("call_summary", "submit_summary", **summary_args(**kwargs.get("summary", {}))))
    calls.append(tool_call("call_finish", "finish"))
    return calls

"""Тесты паспорта системы v3: рендерер Mustache, сборка данных и рендер шаблона.

Герметично — без сети, без LLM, без fastapi. Проверяется:
* рендерер Mustache (each/if/else/this/вложенные поля);
* `build_passport_data` собирает все разделы v3 из модели и extraction;
* `render_passport_md` рендерит шаблон `passport_template_v3.md` без ошибок и
  содержит ключевые поля (готовность, решение, статусы буллитов);
* рендер не оставляет сырых `{{#`/`{{/` (все блоки закрыты);
* нет оценок и рекомендаций в паспорте (FILL_SPEC v3 §1: паспорт — только факты).
"""

import unittest
from pathlib import Path

from pko.extractors.base import Fact
from pko.extractors.runner import Extraction
from pko.progress.plan_input import parse_plan_text
from pko.progress.schema import (
    CriterionVerdict, EvidenceRef, ItemVerdict, PlanItem, ProgressModel,
    ProjectSummary,
)
from pko.render.passport_data import build_passport_data, PASSPORT_VERSION
from pko.render.passport_md import render_passport_md


# --- фикстуры ----------------------------------------------------------------

_JOURNEY = """\
Клиентский путь: Демо-путь
Проект: Демо-проект
## Подготовка
- Принимает запрос от пользователя.
- Считает результат.
## Результат
- Возвращает ответ.
"""


class _FakeTree:
    def __init__(self, files: dict[str, str]):
        self.files = list(files.keys())
        self._files_set = set(self.files)
        self._data = files

    def read(self, path: str) -> str | None:
        return self._data.get(path)


def _criterion(status="done", applicable=True, evidence=None, proof="", how="") -> CriterionVerdict:
    return CriterionVerdict(
        applicable=applicable, status=status,
        proof=proof or "Код есть и работает.",
        how=how or "Агент считает результат.",
        evidence=evidence or [],
    )


def _model() -> ProgressModel:
    item1 = PlanItem(
        id="s1", title="Подготовка",
        criteria=["Принимает запрос от пользователя.", "Считает результат."],
        origin="user",
    )
    item2 = PlanItem(
        id="s2", title="Результат",
        criteria=["Возвращает ответ."],
        origin="user",
    )
    v1 = ItemVerdict(
        item_id="s1", applicable=True,
        criteria=[
            _criterion("done", evidence=[EvidenceRef(
                path="app.py", line=10, basis="handle_request",
                verified=True, reason="подтверждено", note="обработчик запроса",
            )]),
            _criterion("partial", proof="Считает не всё.", evidence=[]),
        ],
    )
    v2 = ItemVerdict(
        item_id="s2", applicable=True,
        criteria=[_criterion("planned")],
    )
    model = ProgressModel(
        meta={"project_name": "Демо-проект", "client_path_name": "Демо-путь",
              "repo": "demo/repo", "branch": "main", "commit": "abc1234",
              "generated_at": "2026-01-01"},
        items={item1.id: item1, item2.id: item2},
        verdicts=[v1, v2],
        readiness=0,
        summary=ProjectSummary(
            decision="PIVOT", conclusion=["Есть часть", "Не всё", "Идти рано"],
            reason="42% < 40%", match="mostly", match_note="Главное есть, части нет.",
        ),
        gaps=["Тестовое замечание прогона"],
    )
    model.readiness = model.overall_progress()
    model.readiness_prod = model.overall_progress_prod()
    return model


def _extraction() -> Extraction:
    return Extraction(facts=[
        Fact(kind="ROUTE", key="POST /api/calc", value={"method": "POST", "path": "/api/calc"},
             path="app.py", line=10, basis="эндпоинт POST /api/calc"),
        Fact(kind="TOOL", key="calculate", value={"summary": "считает результат"},
             path="tools.py", line=5, basis="инструмент calculate"),
        Fact(kind="LIMIT", key="timeout", value=30, path="config.yaml", line=1,
             basis="timeout = 30"),
    ])


# --- тесты рендерера Mustache ------------------------------------------------

class MustacheRendererTest(unittest.TestCase):

    def _render(self, template: str, data) -> str:
        from pko.render.passport_md import _Renderer
        return _Renderer().render(template, data)

    def test_var_substitution(self):
        self.assertEqual(self._render("# {{title}}", {"title": "Паспорт"}), "# Паспорт")

    def test_each_iterates_and_this_field(self):
        out = self._render("{{#each xs}}{{this.n}} {{/each}}",
                           {"xs": [{"n": "А"}, {"n": "Б"}]})
        self.assertEqual(out, "А Б ")

    def test_each_else_on_empty(self):
        self.assertEqual(self._render("{{#each xs}}да{{else}}пусто{{/each}}", {"xs": []}), "пусто")

    def test_if_then_else(self):
        self.assertEqual(self._render("{{#if f}}да{{else}}нет{{/if}}", {"f": True}), "да")
        self.assertEqual(self._render("{{#if f}}да{{else}}нет{{/if}}", {"f": False}), "нет")

    def test_nested_field(self):
        self.assertEqual(self._render("{{obj.sub}}", {"obj": {"sub": "глубоко"}}), "глубоко")

    def test_none_renders_empty(self):
        self.assertEqual(self._render("[{{missing}}]", {}), "[]")


# --- тесты сборки данных паспорта v3 -----------------------------------------

class PassportDataV3Test(unittest.TestCase):
    def setUp(self):
        self.model = _model()
        self.plan = parse_plan_text(_JOURNEY)
        self.tree = _FakeTree({"app.py": "def handle_request():\n    pass\n"})
        self.extraction = _extraction()

    def _data(self):
        return build_passport_data(
            self.model, self.plan, "demo/repo", self.tree, self.extraction,
            commit="abc1234", branch="main",
        )

    def test_version_is_v3(self):
        self.assertEqual(PASSPORT_VERSION, "3.0.0")

    def test_data_has_v3_top_level_keys(self):
        data = self._data()
        # Новые разделы v3.
        self.assertIn("system_summary", data)
        self.assertIn("sources", data)
        self.assertIn("evidence", data)
        self.assertIn("requirements", data)
        self.assertIn("journey_steps", data)
        self.assertIn("capabilities", data)
        self.assertIn("products", data)
        self.assertIn("scoring_version", data)
        # Шапка.
        self.assertEqual(data["project_name"], "Демо-проект")
        self.assertEqual(data["baseline_label"], "план инициативы")

    def test_requirements_have_v3_fields(self):
        data = self._data()
        reqs = data["requirements"]
        self.assertTrue(reqs)
        first = reqs[0]
        self.assertIn("source_id", first)
        self.assertIn("group", first)
        self.assertIn("readiness", first)
        self.assertIn("evidence_ids", first)
        self.assertIn("code_ref_ids", first)

    def test_evidence_has_quotes(self):
        data = self._data()
        ev = data["evidence"]
        self.assertTrue(ev)
        self.assertTrue(any(e["quote"] for e in ev))

    def test_absences_have_implication(self):
        data = self._data()
        for a in data["absences"]:
            self.assertTrue(a["implication"])

    def test_excerpts_have_explanation(self):
        data = self._data()
        for e in data["excerpts"]:
            self.assertTrue(e["explanation"])

    def test_scoring_rules_present(self):
        data = self._data()
        self.assertEqual(data["scoring_version"], "1.0.0")
        self.assertEqual(data["prevent_false_complete"], "да")
        self.assertEqual(data["allow_model_knowledge"], "да")

    def test_no_gaps_are_empty_strings(self):
        """Gaps — список строк, не пустая строка."""
        data = self._data()
        self.assertIsInstance(data["gaps"], list)


# --- тест рендера полного шаблона v3 -----------------------------------------

class PassportRenderV3Test(unittest.TestCase):
    def setUp(self):
        self.model = _model()
        self.plan = parse_plan_text(_JOURNEY)
        self.tree = _FakeTree({"app.py": "def handle_request():\n    pass\n"})
        self.extraction = _extraction()

    def _render(self) -> str:
        data = build_passport_data(
            self.model, self.plan, "demo/repo", self.tree, self.extraction,
            commit="abc1234", branch="main",
        )
        return render_passport_md(data)

    def test_template_renders_without_error(self):
        md = self._render()
        self.assertIsInstance(md, str)
        self.assertGreater(len(md), 2000)

    def test_no_unfilled_block_tags(self):
        """В рендере не должно оставаться сырых `{{#` и `{{/`."""
        md = self._render()
        self.assertNotIn("{{#", md)
        self.assertNotIn("{{/", md)

    def test_contains_key_fields(self):
        md = self._render()
        self.assertIn("Демо-проект", md)
        self.assertIn("abc1234", md)
        self.assertIn("Принимает запрос от пользователя.", md)

    def test_contains_v3_sections(self):
        md = self._render()
        # Новые разделы v3.
        self.assertIn("Как система работает сегодня", md)
        self.assertIn("Реестр источников", md)
        self.assertIn("Реестр свидетельств", md)
        self.assertIn("Требования плана", md)
        self.assertIn("КАРКАС ВИТРИНЫ", md)
        self.assertIn("Правила счёта", md)

    def test_gaps_visible_in_section_22(self):
        md = self._render()
        self.assertIn("Тестовое замечание прогона", md)


if __name__ == "__main__":
    unittest.main()

"""Несколько прогонов сразу: очередь, SSE, ответы команд, зеркало репозитория.

Стенд получает не один запрос, а пачку: несколько инициатив отправляют
подряд. Проверяется, что при двух слотах остальные ждут очереди и все доходят
до READY, что открытые потоки прогресса не мешают ответам команд, что
переполненная очередь отвечает 429, а не молчит, и что два прогона по одному
репозиторию не клонируют его в один каталог одновременно.

Как и остальные тесты — без сети и без модели: агент скриптованный, но без
общего состояния между сессиями (см. `_next_call`).
"""

from __future__ import annotations

import json
import os
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from fastapi.testclient import TestClient

import pko.llm.client as client_module
from agent_script import JOURNEY_TEXT, stage_args, summary_args, tool_call
from fixture_support import ensure_fixture, make_openai_response
from pko.git import remote
from pko.llm.client import ChatClient
from pko.web import analyses, feedback
from pko.web.app import app

ENV_KEYS = ("PKO_ASSEMBLER_BASE_URL", "PKO_ASSEMBLER_MODEL", "PKO_ASSEMBLER_API_KEY")


def _next_call(messages: list[dict]) -> tuple[str, dict]:
    """Следующий ход агента по его же истории — без общего состояния.

    Скриптованные ответы из `fixture_support` берут ходы из одной очереди:
    параллельные сессии растащили бы её между собой. Здесь ход выводится из
    того, что код уже принял в этой сессии.
    """
    replies = " ".join(
        str(message.get("content") or "")
        for message in messages if message.get("role") == "tool"
    )
    if "оценка принята" not in replies:
        return "submit_stage", stage_args()
    if "контр-проверка завершена" not in replies:
        return "submit_review", {"confirmed": True}
    if "вердикт принят" not in replies:
        return "submit_summary", summary_args()
    return "finish", {}


def _stateless_agent(self, payload, extra_body=None):  # noqa: ANN001
    name, args = _next_call(payload["messages"])
    return make_openai_response(tool_call("call_" + name, name, **args))


def _parse_sse(text: str) -> list[dict]:
    return [json.loads(line[len("data: "):]) for line in text.splitlines()
            if line.startswith("data: ")]


class _WebCase(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

        original_cache = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = Path(self.tmp.name) / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", original_cache)

        original_create = ChatClient._create
        ChatClient._create = _stateless_agent
        self.addCleanup(setattr, ChatClient, "_create", original_create)

        feedback.reset_store(feedback.FeedbackStore(path=Path(self.tmp.name) / "f.db"))
        self.addCleanup(feedback.reset_store, None)

        env = {key: os.environ.get(key) for key in ENV_KEYS}
        os.environ.update({
            "PKO_ASSEMBLER_BASE_URL": "https://stub.local/v1",
            "PKO_ASSEMBLER_MODEL": "stub-model",
            "PKO_ASSEMBLER_API_KEY": "x",
        })

        def restore_env() -> None:
            for key, value in env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

        self.addCleanup(restore_env)

        snapshot = dict(analyses._JOBS)

        def restore_jobs() -> None:
            analyses._JOBS.clear()
            analyses._JOBS.update(snapshot)

        self.addCleanup(restore_jobs)
        self.fixture = str(ensure_fixture())

    def _patch(self, name: str, value: object) -> None:
        original = getattr(analyses, name)
        self.addCleanup(setattr, analyses, name, original)
        setattr(analyses, name, value)


class ManyProjectsAtOnce(_WebCase):
    """Шесть прогонов при двух слотах: все доходят до конца, никто не падает."""

    JOBS = 6

    def setUp(self) -> None:
        super().setUp()
        self._patch("_SLOTS", threading.BoundedSemaphore(2))
        self._patch("MAX_PARALLEL", 2)
        self._patch("MAX_QUEUE", 20)

    def _one(self, index: int, results: dict) -> None:
        client = TestClient(app)
        try:
            created = client.post("/api/analyses", data={
                "journey_text": JOURNEY_TEXT, "repository": self.fixture,
            })
            outcome: dict = {"create": created.status_code}
            if created.status_code != 200:
                outcome["body"] = created.text
                results[index] = outcome
                return
            analysis_id = created.json()["analysis_id"]
            outcome["id"] = analysis_id
            events = _parse_sse(client.get(f"/api/analyses/{analysis_id}/events").text)
            outcome["events"] = [event["type"] for event in events]
            outcome["phases"] = [event.get("phase") for event in events
                                 if event["type"] == "phase"]
            final = client.get(f"/api/analyses/{analysis_id}")
            outcome["final"] = (final.status_code, final.json().get("status"))
            outcome["readiness"] = final.json().get("readiness")
            dispute = client.post(f"/api/analyses/{analysis_id}/disputes", data={
                "bullet_index": 1, "verdict": "reject",
                "comment": f"Пункт {index} сделан в соседнем сервисе.",
            })
            outcome["dispute"] = (dispute.status_code, dispute.text[:200])
            listing = client.get(f"/api/analyses/{analysis_id}/disputes")
            outcome["listed"] = listing.json().get("total")
            results[index] = outcome
        except Exception as exc:  # noqa: BLE001 — итог нужен целиком
            results[index] = {"error": repr(exc)}

    def test_all_projects_finish_and_answers_are_saved(self) -> None:
        results: dict[int, dict] = {}
        threads = [
            threading.Thread(target=self._one, args=(index, results), daemon=True)
            for index in range(self.JOBS)
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=240)

        self.assertEqual(sorted(results), list(range(self.JOBS)), results)
        for index, outcome in results.items():
            with self.subTest(job=index):
                self.assertNotIn("error", outcome, outcome)
                self.assertEqual(outcome["create"], 200, outcome)
                self.assertEqual(outcome["events"][-1], "analysis_ready", outcome)
                self.assertEqual(outcome["final"], (200, "READY"), outcome)
                self.assertEqual(outcome["readiness"], 50, outcome)
                self.assertEqual(outcome["dispute"][0], 200, outcome)
                self.assertEqual(outcome["listed"], 1, outcome)
        # Слотов два, прогонов шесть: кто-то обязан был постоять в очереди и
        # сказать об этом — иначе предел параллельности не работает.
        self.assertTrue(any("queued" in outcome["phases"] for outcome in results.values()))
        self.assertEqual(len(feedback.store().list()), self.JOBS)
        # В реестре все шесть завершены: ни одна задача не зависла в
        # PROCESSING с занятым слотом.
        for outcome in results.values():
            self.assertEqual(analyses._JOBS[outcome["id"]].status, "READY")


class QueueCeiling(_WebCase):
    """Переполненная очередь — честный отказ, а не вечное ожидание."""

    def test_full_queue_answers_429_and_frees_up_when_a_run_finishes(self) -> None:
        self._patch("MAX_PARALLEL", 1)
        self._patch("MAX_QUEUE", 1)
        running = analyses.AnalysisJob(id="an_busy_1")
        waiting = analyses.AnalysisJob(id="an_busy_2")
        analyses._JOBS.update({running.id: running, waiting.id: waiting})

        client = TestClient(app)
        payload = {"journey_text": JOURNEY_TEXT, "repository": self.fixture}
        refused = client.post("/api/analyses", data=payload)
        self.assertEqual(refused.status_code, 429, refused.text)
        self.assertIn("Очередь", refused.json()["message"])

        # Завершённый прогон место в очереди больше не занимает.
        waiting.status = "READY"
        with mock.patch.object(analyses, "_execute", lambda *args, **kwargs: None):
            accepted = client.post("/api/analyses", data=payload)
        self.assertEqual(accepted.status_code, 200, accepted.text)


class MirrorLock(unittest.TestCase):
    """Два прогона по одному репозиторию не клонируют его одновременно."""

    def test_concurrent_clones_of_one_repo_are_serialised(self) -> None:
        url = "ssh://git@stash.local:7999/proj/repo.git"
        guard = threading.Lock()
        state = {"active": 0, "peak": 0}
        calls: list[str] = []

        def fake_run_git(args: list[str], timeout: int, ref: object) -> str:
            with guard:
                state["active"] += 1
                state["peak"] = max(state["peak"], state["active"])
            try:
                time.sleep(0.05)
                if args[0] == "clone":
                    dest = Path(args[-1])
                    dest.mkdir(parents=True, exist_ok=True)
                    (dest / "HEAD").write_text("ref: refs/heads/master\n", encoding="utf-8")
                    calls.append("clone")
                    return ""
                if "config" in args:
                    return url + "\n"
                if "update" in args:
                    calls.append("fetch")
                return ""
            finally:
                with guard:
                    state["active"] -= 1

        errors: list[BaseException] = []

        def run(root: Path) -> None:
            try:
                remote.ensure_mirror(url, cache_root=root)
            except BaseException as exc:  # noqa: BLE001 — нужен сам факт
                errors.append(exc)

        with tempfile.TemporaryDirectory() as raw, \
                mock.patch.object(remote, "_run_git", fake_run_git):
            root = Path(raw)
            threads = [threading.Thread(target=run, args=(root,)) for _ in range(3)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join(timeout=30)

        self.assertEqual(errors, [])
        self.assertEqual(state["peak"], 1, "git работал с одним зеркалом из двух потоков сразу")
        self.assertEqual(calls.count("clone"), 1)
        self.assertEqual(calls.count("fetch"), 2)


if __name__ == "__main__":
    unittest.main()

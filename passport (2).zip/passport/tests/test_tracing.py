"""Тесты трейсинга: noop-режим, add_event, trace_cached_llm.

Герметичные: без Phoenix-сервера и без сети. Проверяют, что код пайплайна
работает одинаково с включённой трассировкой и без неё, и что интерфейс
спана (set_attribute / add_event / record_error) не падает.
"""

import unittest
from unittest.mock import patch

from pko.llm import tracing
from pko.llm.tracing import (
    _NoopSpan,
    _SpanHandle,
    trace_cached_llm,
    trace_span,
)


class NoopSpanTest(unittest.TestCase):
    """NoopSpan глотает все вызовы — режим без Phoenix."""

    def test_set_attribute_noop(self):
        span = _NoopSpan()
        span.set_attribute("key", "value")  # не падает

    def test_add_event_noop(self):
        span = _NoopSpan()
        span.add_event("event", key="value")  # не падает

    def test_record_error_noop(self):
        span = _NoopSpan()
        span.record_error(ValueError("test"))  # не падает


class TraceSpanNoopTest(unittest.TestCase):
    """trace_span — no-op, если трассировка не инициализирована."""

    def test_yields_noop_when_disabled(self):
        with patch.object(tracing, "_tracer", None):
            with trace_span("test_span") as span:
                self.assertIsInstance(span, _NoopSpan)

    def test_attributes_noop_safe(self):
        with patch.object(tracing, "_tracer", None):
            with trace_span("test_span", attr1="val1", attr2=42) as span:
                span.set_attribute("after", "done")
                span.add_event("event", count=3)
                self.assertIsInstance(span, _NoopSpan)


class SpanHandleTest(unittest.TestCase):
    """_SpanHandle глотает ошибки наблюдаемости — прогон не роняет."""

    def test_set_attribute_swallows_errors(self):
        class BrokenSpan:
            def set_attribute(self, key, value):
                raise RuntimeError("otel broken")

            def add_event(self, name, attributes=None):
                raise RuntimeError("otel broken")

            def record_exception(self, exc):
                raise RuntimeError("otel broken")

            def set_status(self, status):
                raise RuntimeError("otel broken")

        handle = _SpanHandle(BrokenSpan())
        handle.set_attribute("key", "value")  # не падает
        handle.add_event("event", key="value")  # не падает
        handle.record_error(ValueError("test"))  # не падает

    def test_set_attribute_skips_none(self):
        recorded = []

        class FakeSpan:
            def set_attribute(self, key, value):
                recorded.append((key, value))

            def add_event(self, name, attributes=None):
                pass

            def record_exception(self, exc):
                pass

            def set_status(self, status):
                pass

        handle = _SpanHandle(FakeSpan())
        handle.set_attribute("skip_me", None)
        handle.set_attribute("keep_me", 42)
        self.assertEqual(recorded, [("keep_me", 42)])


class TraceCachedLlmTest(unittest.TestCase):
    """trace_cached_llm — no-op без Phoenix, не падает с сообщениями."""

    def test_noop_when_disabled(self):
        messages = [
            {"role": "system", "content": "ты агент"},
            {"role": "user", "content": "проверь код"},
        ]
        output = {"role": "assistant", "content": "всё работает"}

        with patch.object(tracing, "_tracer", None):
            with trace_cached_llm(
                "ChatCompletion",
                messages=messages,
                output=output,
                model="glm-5.2",
                tools=[{"type": "function", "function": {"name": "list_files"}}],
                invocation_parameters={"temperature": 0},
            ) as span:
                self.assertIsInstance(span, _NoopSpan)

    def test_noop_with_tool_calls_in_messages(self):
        """tool_calls в истории сообщений не ломают noop-спан."""
        messages = [
            {"role": "assistant", "content": None, "tool_calls": [
                {"id": "1", "function": {"name": "read_file", "arguments": '{"path":"a.py"}'}},
            ]},
            {"role": "tool", "tool_call_id": "1", "content": "содержимое"},
        ]
        output = {"role": "assistant", "content": "готово", "tool_calls": [
            {"id": "2", "function": {"name": "finish", "arguments": "{}"}},
        ]}

        with patch.object(tracing, "_tracer", None):
            with trace_cached_llm(
                "ChatCompletion", messages=messages, output=output, model="glm-5.2",
            ) as span:
                self.assertIsInstance(span, _NoopSpan)


class InitTracingTest(unittest.TestCase):
    """init_phoenix_tracing — master switch и idempotent."""

    def setUp(self):
        tracing._initialized = False
        tracing._tracer = None

    def tearDown(self):
        tracing._initialized = False
        tracing._tracer = None

    def test_disabled_by_default(self):
        with patch.dict("os.environ", {}, clear=True):
            result = tracing.init_phoenix_tracing()
            self.assertIsNone(result)
            self.assertIsNone(tracing._tracer)
            self.assertTrue(tracing._initialized)

    def test_idempotent(self):
        with patch.dict("os.environ", {"PKO_PHOENIX_ENABLED": "false"}):
            tracing.init_phoenix_tracing()
            # второй вызов — no-op, не падает
            result = tracing.init_phoenix_tracing()
            self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()

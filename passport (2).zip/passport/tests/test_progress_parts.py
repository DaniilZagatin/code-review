"""Разбор пункта на четыре части и якорь по составному имени.

Обе проверки выросли из первого живого прогона: там 11 ссылок из 24 отвалились
только потому, что агент писал `basis` квалифицированным именем.
"""

from __future__ import annotations

import unittest

from fixture_support import ensure_fixture
from pko.git.repo import GitRepo
from pko.extractors.base import Tree
from pko.progress.schema import (
    CriterionVerdict,
    EvidenceRef,
    ItemVerdict,
    PlanItem,
    ProgressModel,
    ProjectSummary,
    calculate_progress,
    calculate_prod_progress,
    compute_decision,
    limit_groups,
    scale_rows,
)
from pko.progress.matcher import _clip
from pko.progress.verify import _find_anchor, verify_evidence
from pko.render.dashboard_data import build_dashboard_data


class QualifiedAnchor(unittest.TestCase):
    """`AgentGraph.classifier` рядом со строкой `def classifier(...)`."""

    LINES = [
        "class AgentGraph:",
        "    def __init__(self):",
        "        pass",
        "",
        "    def classifier(self, state):",
        "        return state",
    ]

    def test_dotted_name_matches_by_part(self) -> None:
        self.assertIsNotNone(_find_anchor("AgentGraph.classifier", self.LINES, 5))

    def test_slashed_name_matches_by_part(self) -> None:
        self.assertIsNotNone(_find_anchor("api/v1/classifier", self.LINES, 5))

    def test_plain_name_still_matches(self) -> None:
        self.assertIsNotNone(_find_anchor("classifier", self.LINES, 5))

    def test_unrelated_name_still_rejected(self) -> None:
        """Смягчение не должно превращать проверку в формальность."""
        self.assertIsNone(_find_anchor("PaymentGateway.charge", self.LINES, 5))

    def test_nearby_class_name_is_a_valid_anchor(self) -> None:
        """Якорь подтверждает место, а не точное написание символа.

        Если имя класса стоит в окне ±5 строк, опечатка в имени метода на
        проверку не влияет: ссылка всё равно указывает туда, куда надо.
        """
        self.assertEqual(_find_anchor("AgentGraph.clasifier", self.LINES, 5), "AgentGraph")

    def test_typo_is_rejected_when_no_part_is_nearby(self) -> None:
        """Так отвалилась `AnalyzerSubAgent.anlyze_query` на живом прогоне:
        класс объявлен далеко, а имя метода написано с опечаткой."""
        far = ["код"] * 40 + ["    def analyze_query(self):"] + ["код"] * 40
        self.assertIsNone(_find_anchor("AnalyzerSubAgent.anlyze_query", far, 5))

    def test_short_parts_do_not_match_everything(self) -> None:
        self.assertIsNone(_find_anchor("a.b.c", self.LINES, 5))


class EnclosingAnchor(unittest.TestCase):
    """Ссылка на строку в середине длинной функции.

    На живом прогоне так отклонились 9 ссылок из 27: агент указывал строку
    внутри функции и называл в основании саму функцию — а её `def` стоял
    на сотню строк выше окна ±5.
    """

    PY = (
        ["import os", "", "", "def analyze_excel_model(model, ranges):"]
        + ["    step = 1"] * 120
        + ["    return result"]
    )

    def test_line_inside_a_long_function_is_anchored_by_its_name(self) -> None:
        self.assertEqual(
            _find_anchor("analyze_excel_model", self.PY, 90), "analyze_excel_model",
        )

    def test_qualified_name_inside_a_long_function_also_works(self) -> None:
        self.assertEqual(
            _find_anchor("tools.analyze_excel_model", self.PY, 90), "analyze_excel_model",
        )

    def test_wrong_function_name_is_still_rejected(self) -> None:
        """Смягчение не должно принимать любое имя."""
        self.assertIsNone(_find_anchor("save_analysis_results", self.PY, 90))

    def test_sql_procedure_encloses_its_body(self) -> None:
        sql = (
            ["CREATE PROCEDURE dbo.calc_client_score AS", "BEGIN"]
            + ["    SELECT 1;"] * 60
            + ["END"]
        )
        self.assertEqual(_find_anchor("calc_client_score", sql, 40), "calc_client_score")

    def test_java_method_encloses_its_body(self) -> None:
        java = (
            ["class ScoreService {", "", "    public List<Row> loadRows(String id) {"]
            + ["        rows.add(id);"] * 40
            + ["    }", "}"]
        )
        self.assertEqual(_find_anchor("loadRows", java, 30), "loadRows")

    def test_a_call_is_not_a_declaration(self) -> None:
        """`return build_report(data)` — вызов, а не объявление функции."""
        lines = (
            ["def unrelated(data):"]
            + ["    x = 1"] * 10
            + ["    return build_report(data)"]
            + ["    y = 2"] * 30
        )
        self.assertIsNone(_find_anchor("build_report", lines, 40))


class QualifiedAnchorOnFixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tree = Tree.at(GitRepo(ensure_fixture()), GitRepo(ensure_fixture()).resolve("master"))

    def test_qualified_basis_verifies_against_real_file(self) -> None:
        path = "backend/src/api/v1/router.py"
        text = self.tree.read(path) or ""
        line = next(
            (i for i, raw in enumerate(text.split("\n"), start=1) if "start_task" in raw),
            0,
        )
        self.assertTrue(line, "в фикстуре нет строки со start_task")
        result = verify_evidence(path, line, "Router.start_task", self.tree)
        self.assertTrue(result.ok, result.reason)


class TwoBullets(unittest.TestCase):
    """Раскрытие пункта — «Проверка» и «Как работает», больше ничего."""

    def test_proof_and_how_are_separate_fields(self) -> None:
        verdict = CriterionVerdict(
            applicable=True,
            status="partial",
            proof="Код написан и рабочий, но в сценарии не задействован.",
            how="Специалист присылает модель и вопрос текстом, система считает сама.",
            evidence=[EvidenceRef("a.py", 1, "run", True, "ok")],
        )
        payload = verdict.to_dict()
        self.assertIn("не задействован", payload["proof"])
        self.assertIn("Специалист присылает модель", payload["how"])
        self.assertEqual(payload["status_label"], "Не работает, реализовано частично")

    def test_evidence_stays_in_the_model_for_audit(self) -> None:
        """Ссылка держит гейт статуса и остаётся в `progress_model.json`.

        В отчёт она не выводится — это проверяется на контракте дашборда
        (`test_web_analyses`), — но след проверки должен сохраняться.
        """
        verdict = CriterionVerdict(
            applicable=True, status="done", proof="Код есть и работает.",
            evidence=[EvidenceRef("a.py", 1, "run", True, "ok")],
        )
        self.assertTrue(verdict.is_grounded)
        self.assertEqual(verdict.to_dict()["evidence"][0]["path"], "a.py")

    def test_old_comment_becomes_how(self) -> None:
        """Прогоны до переименования полей не должны терять текст."""
        verdict = CriterionVerdict(applicable=True, status="done", comment="Старый текст.")
        self.assertEqual(verdict.to_dict()["how"], "Старый текст.")

    def test_old_business_and_technical_are_still_read(self) -> None:
        verdict = CriterionVerdict(
            applicable=True, status="done",
            business="Как работает.", technical="Код есть и работает.",
        )
        payload = verdict.to_dict()
        self.assertEqual(payload["how"], "Как работает.")
        self.assertEqual(payload["proof"], "Код есть и работает.")

    def test_old_why_is_read_as_proof(self) -> None:
        verdict = CriterionVerdict(applicable=True, status="done", why="Почему так.")
        self.assertEqual(verdict.to_dict()["proof"], "Почему так.")

    def test_new_fields_win_over_old(self) -> None:
        verdict = CriterionVerdict(
            applicable=True, status="done",
            how="Новое.", business="Старое.", comment="Совсем старое.",
        )
        self.assertEqual(verdict.how_text, "Новое.")


class CommentIsNotEvidence(unittest.TestCase):
    """Комментарий описывает намерение, а не реализацию."""

    class _FakeTree:
        def __init__(self, text: str) -> None:
            self.files_set = {"a.py"}
            self._text = text

        def read(self, path: str) -> str:
            return self._text

    def test_comment_line_does_not_confirm(self) -> None:
        tree = self._FakeTree("def run():\n    # TODO: посчитать sensitivity\n    pass\n")
        result = verify_evidence("a.py", 2, "sensitivity", tree)
        self.assertFalse(result.ok)
        self.assertIn("комментарий", result.reason)

    def test_code_line_still_confirms(self) -> None:
        tree = self._FakeTree("def sensitivity(x):\n    return x\n")
        self.assertTrue(verify_evidence("a.py", 1, "sensitivity", tree).ok)

    def test_sql_and_js_comments_are_caught(self) -> None:
        for text, basis in (("-- calc_score здесь будет\n", "calc_score"),
                            ("// runReport вызывается позже\n", "runReport")):
            with self.subTest(text=text):
                self.assertFalse(verify_evidence("a.py", 1, basis,
                                                 self._FakeTree(text)).ok)


class LinksDrawer(unittest.TestCase):
    """В шторку идут только подтверждённые ссылки."""

    def _row(self, evidence: list[EvidenceRef]) -> dict:
        item = PlanItem(id="a", title="Этап", criteria=["Буллит"])
        verdict = ItemVerdict(item_id="a", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="done", proof="Код есть.",
                             how="Работает так.", evidence=evidence),
        ])
        model = ProgressModel(items={item.id: item}, verdicts=[verdict], readiness=100)
        return build_dashboard_data(model)["items"][0]["assessment"][0]

    def test_verified_link_reaches_the_drawer(self) -> None:
        row = self._row([EvidenceRef("a.py", 7, "run", True, "ok", note="что тут")])
        self.assertEqual(row["links"], [
            {"path": "a.py", "line": 7, "basis": "run", "note": "что тут"},
        ])

    def test_rejected_link_is_dropped(self) -> None:
        """Ссылка, в которой модель не уверена, ничего не доказывает."""
        row = self._row([EvidenceRef("a.py", 7, "run", False, "строка не та")])
        self.assertNotIn("links", row)

    def test_only_the_verified_half_survives(self) -> None:
        row = self._row([
            EvidenceRef("a.py", 7, "run", True, "ok"),
            EvidenceRef("b.py", 9, "start", False, "нет якоря"),
        ])
        self.assertEqual([link["path"] for link in row["links"]], ["a.py"])
        # Причина отклонения на экран не едет — там её нечем объяснить.
        self.assertNotIn("reason", row["links"][0])


class TwoScales(unittest.TestCase):
    """Прототип и пром считаются по одним статусам, но по разным весам."""

    def _criteria(self, *statuses: str) -> list[CriterionVerdict]:
        return [CriterionVerdict(applicable=True, status=s) for s in statuses]

    def test_prod_is_stricter_on_unwired_code(self) -> None:
        """«Написано, но не подключено» доказывает идею и не даёт результата.

        Для прототипа это половина зачёта, для прома — ноль: пользователь
        такой функции не видит вовсе.
        """
        criteria = self._criteria("unused", "unused")
        self.assertEqual(calculate_progress(criteria), 50)
        self.assertEqual(calculate_prod_progress(criteria), 0)

    def test_prod_counts_only_working_functionality(self) -> None:
        """В пром идёт работающее целиком и половина от «с ограничениями»."""
        self.assertEqual(calculate_prod_progress(self._criteria("limited", "limited")), 50)
        self.assertEqual(calculate_prod_progress(self._criteria("partial", "partial")), 0)
        self.assertEqual(calculate_prod_progress(self._criteria("done", "limited")), 75)

    def test_full_work_is_the_same_on_both_scales(self) -> None:
        criteria = self._criteria("done", "done")
        self.assertEqual(calculate_progress(criteria), 100)
        self.assertEqual(calculate_prod_progress(criteria), 100)

    def test_nothing_done_is_zero_on_both(self) -> None:
        criteria = self._criteria("planned", "planned")
        self.assertEqual(calculate_progress(criteria), 0)
        self.assertEqual(calculate_prod_progress(criteria), 0)

    def test_prod_never_exceeds_prototype(self) -> None:
        """Пром строже по каждому статусу — значит и в сумме не выше."""
        for status in ("done", "limited", "unused", "partial", "planned", "blocked"):
            with self.subTest(status=status):
                criteria = self._criteria(status)
                self.assertLessEqual(
                    calculate_prod_progress(criteria) or 0,
                    calculate_progress(criteria) or 0,
                )

    def test_legend_carries_both_weights(self) -> None:
        """Читатель должен уметь пересчитать оба числа сам."""
        row = next(r for r in scale_rows() if r["status"] == "unused")
        self.assertEqual((row["weight"], row["weight_prod"]), (50, 0))

    def test_decision_follows_the_prototype_scale(self) -> None:
        """Оценивается прототип — по нему и порог 40%."""
        criteria = self._criteria("unused", "planned")   # прототип 25, пром 0
        self.assertEqual(calculate_progress(criteria), 25)
        self.assertEqual(calculate_prod_progress(criteria), 0)
        self.assertEqual(compute_decision(calculate_progress(criteria) or 0), "PIVOT")
        criteria = self._criteria("done", "planned")     # прототип 50
        self.assertEqual(compute_decision(calculate_progress(criteria) or 0), "GO")


class ClipOnBoundary(unittest.TestCase):
    """Длинный текст обрезается по границе фразы, а не посреди слова.

    На девяти живых прогонах восемь верхнеуровневых оценок упирались ровно в
    предел и кончались обрывком вроде «а сам агент с» — прямо в отчёте.
    """

    def test_short_text_is_untouched(self) -> None:
        self.assertEqual(_clip("Короткая фраза.", 100), "Короткая фраза.")

    def test_cut_lands_on_a_sentence_end(self) -> None:
        text = "Первая фраза целиком. " + "Вторая фраза тоже целиком. " * 20
        cut = _clip(text, 120)
        self.assertLessEqual(len(cut), 120)
        self.assertTrue(cut.endswith("."), cut)

    def test_without_a_sentence_end_cut_lands_on_a_word(self) -> None:
        cut = _clip("слово " * 200, 100)
        self.assertLessEqual(len(cut), 100)
        self.assertTrue(cut.endswith("…"), cut)
        self.assertNotIn("сло…", cut)

    def test_whitespace_is_normalised(self) -> None:
        self.assertEqual(_clip("  два   пробела\n", 50), "два пробела")


class TopLevelMatch(unittest.TestCase):
    """Верхнеуровневая оценка: суждение модели рядом с расчётом кода."""

    def _data(self, match: str, readiness: int) -> dict:
        item = PlanItem(id="a", title="Этап", criteria=["Буллит"])
        verdict = ItemVerdict(item_id="a", applicable=True, criteria=[
            CriterionVerdict(applicable=True, status="done", proof="Код есть.",
                             how="Работает так."),
        ])
        summary = ProjectSummary(
            decision=compute_decision(readiness),
            conclusion=["Раз", "Два", "Три"],
            match=match,
            match_note="Система делает главное своим способом.",
        )
        model = ProgressModel(items={item.id: item}, verdicts=[verdict],
                              readiness=readiness, summary=summary)
        return build_dashboard_data(model)

    def test_label_comes_from_code_not_from_model(self) -> None:
        """Формулировку держит код: она одна на все прогоны и все отчёты."""
        meta = self._data("mismatch", 10)["meta"]
        self.assertEqual(meta["match"], "mismatch")
        self.assertEqual(meta["match_label"],
                         "Образ результата не соответствует предоставленному коду")
        self.assertEqual(meta["match_note"], "Система делает главное своим способом.")

    def test_agreement_adds_nothing_to_gaps(self) -> None:
        self.assertEqual(self._data("matches", 90)["gaps"], [])
        self.assertEqual(self._data("mismatch", 10)["gaps"], [])

    def test_mismatch_at_high_readiness_is_flagged(self) -> None:
        """Расхождение оценки с расчётом читатель должен видеть.

        Обычно это значит, что анализировали не тот репозиторий: буллиты
        закрылись, а система делает другое.
        """
        gaps = self._data("mismatch", 80)["gaps"]
        self.assertEqual(len(gaps), 1)
        self.assertIn("80%", gaps[0])

    def test_match_at_low_readiness_is_flagged(self) -> None:
        gaps = self._data("matches", 12)["gaps"]
        self.assertEqual(len(gaps), 1)
        self.assertIn("12%", gaps[0])

    def test_mostly_below_the_threshold_is_flagged(self) -> None:
        """На девяти живых прогонах «в основном соответствует» встретилось
        девять раз из девяти, включая прогоны на 25% и 31%. Средняя оценка
        превратилась в значение по умолчанию, и расхождение с расчётом
        читатель должен видеть."""
        gaps = self._data("mostly", 25)["gaps"]
        self.assertEqual(len(gaps), 1)
        self.assertIn("25%", gaps[0])

    def test_mostly_above_the_threshold_is_left_alone(self) -> None:
        for readiness in (40, 70, 100):
            with self.subTest(readiness=readiness):
                self.assertEqual(self._data("mostly", readiness)["gaps"], [])


class GroupLimit(unittest.TestCase):
    """Не больше четырёх блоков в отчёте — это правило кода, а не просьба."""

    def test_few_groups_are_left_alone(self) -> None:
        names = ["Расчёты", "Расчёты", "Документы"]
        self.assertEqual(limit_groups(names), {"Расчёты": "Расчёты", "Документы": "Документы"})

    def test_surplus_groups_merge_into_other(self) -> None:
        # Ровно случай живого прогона: 11 групп на 12 буллитов.
        names = ["Сценарный анализ"] * 3 + [f"Тема {i}" for i in range(1, 10)]
        mapping = limit_groups(names)
        self.assertLessEqual(len({mapping[n] for n in names}), 4)
        self.assertEqual(mapping["Сценарный анализ"], "Сценарный анализ")
        self.assertIn("Прочее", set(mapping.values()))

    def test_largest_groups_survive(self) -> None:
        names = ["A"] * 5 + ["B"] * 4 + ["C"] * 3 + ["D"] * 2 + ["E"]
        mapping = limit_groups(names)
        self.assertEqual(mapping["A"], "A")
        self.assertEqual(mapping["B"], "B")
        self.assertEqual(mapping["C"], "C")
        self.assertEqual(mapping["D"], "Прочее")
        self.assertEqual(mapping["E"], "Прочее")

    def test_empty_group_name_becomes_default(self) -> None:
        self.assertEqual(limit_groups(["", "  "]), {"Функционал": "Функционал"})


if __name__ == "__main__":
    unittest.main()

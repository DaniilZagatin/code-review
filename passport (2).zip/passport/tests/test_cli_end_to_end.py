"""`pko progress` целиком: обе сессии агента (оценка + паспорт) со
скриптованной моделью → шесть файлов на диске.

Проверяет стык, который поузловые тесты не видят: след прочитанного из
сессии оценки доходит до паспортного агента, его дерево — до
`progress_model.json` и HTML-паспорта, а карта дерева, карточка узла и
реестр собираются рендерером. Герметично: сеть не нужна, репозиторий —
автоматическая фикстура.
"""

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

import pko.llm.client as client_module
from agent_script import JOURNEY_TEXT, full_session, tool_call
from fixture_support import ensure_fixture, scripted_responses
from pko import cli
from pko.llm.client import ChatClient
from pko.render.client_journey_passport import STATUS_BADGE_AGENT

OWNER = "Требует подтверждения владельца: владелец продукта, назначение вне кода"
EST = "Установлено: backend/src/api/v1/router.py, start_task — ставит задачу в обработку"


def _node(node_id: str, name: str, basis: str, fields: dict, **extra) -> dict:
    args = {"id": node_id, "name": name, "basis": basis, "fields": fields, **extra}
    return {"content": None, "tool_calls": [{
        "id": f"call_{node_id}", "type": "function",
        "function": {"name": "submit_node", "arguments": json.dumps(args, ensure_ascii=False)},
    }]}


def _children(parent: str, *children: tuple[str, str]) -> dict:
    return tool_call(f"call_children_{parent}", "declare_children", parent=parent,
                     children=[{"name": n, "basis": b} for n, b in children])


def passport_session() -> list[dict]:
    """Обход сверху вниз: путь → процесс → 2 BBB → операции → потребность → ограничение."""
    proc = {
        "4.3.3": {"value": "Предложение: владелец продукта", "source": OWNER},
        "4.3.6": {"value": "Приём — AUTO; передача исполнителю — CONFIRM.",
                  "source": "Выведено: маршрутизация ждёт подтверждения"},
        "4.3.8": {"value": "Не установлено: передачи человеку нет.", "source": "Не установлено"},
    }
    bbb = {"4.4.1": {"value": "Одно бизнес-действие.", "source": EST}}
    op = {"4.5.1": {"value": "Шаг с наблюдаемым результатом.", "source": EST}}
    return [
        _node("journey-1", "Постановка задачи в работу", "путь из образа результата",
              {"4.2.3": {"value": "Предложение: владелец процесса", "source": OWNER}},
              decision_boundary="END_TO_END_PROCESS"),
        _children("journey-1", ("Приём и маршрутизация задачи", "сценарий со своим входом")),
        _node("process-1", "Приём и маршрутизация задачи", "сценарий со своим входом", proc),
        _children("process-1", ("Регистрация обращения", "фиксирует задачу"),
                  ("Передача исполнителю", "выбирает исполнителя")),
        _node("bbb-1", "Регистрация обращения", "фиксирует задачу", bbb),
        _children("bbb-1", ("Запись задачи", "запись в хранилище")),
        _node("operation-1", "Запись задачи", "запись в хранилище", op),
        _node("bbb-2", "Передача исполнителю", "выбирает исполнителя", bbb),
        _children("bbb-2", ("Назначение исполнителя", "внешний эффект — уведомление")),
        _node("operation-2", "Назначение исполнителя", "внешний эффект — уведомление", op),
        _node("need-1", "Передать задачу и знать её судьбу", "существует до продукта",
              {"4.1.1": {"value": "Клиент хочет, чтобы задача дошла до исполнителя без звонков.",
                         "source": "Требует подтверждения владельца: аналитика обращений"}},
              journeys=["journey-1"]),
        _node("guardrail-1", "Задача не назначается без исполнителя", "исполняемая проверка",
              {"4.6.8": {"value": "DENY — назначение отклоняется.", "source": EST}},
              scope=["bbb-2"]),
        tool_call("call_finish_passport", "finish"),
    ]


class CliEndToEndTest(unittest.TestCase):
    def setUp(self):
        self.repo_path = ensure_fixture()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self._cache = client_module.DEFAULT_CACHE_DIR
        client_module.DEFAULT_CACHE_DIR = Path(self.tmp.name) / "llm-cache"
        self.addCleanup(setattr, client_module, "DEFAULT_CACHE_DIR", self._cache)
        self._create = ChatClient._create
        self.addCleanup(setattr, ChatClient, "_create", self._create)
        # Роль matcher резолвится из окружения — заглушка без сети.
        self._env = {k: os.environ.get(k) for k in ("PKO_MATCHER_BASE_URL", "PKO_MATCHER_MODEL", "PKO_MATCHER_API_KEY")}
        os.environ.update({"PKO_MATCHER_BASE_URL": "https://stub.local/v1",
                           "PKO_MATCHER_MODEL": "stub-model", "PKO_MATCHER_API_KEY": "x"})
        self.addCleanup(self._restore_env)

    def _restore_env(self):
        for k, v in self._env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    def test_progress_writes_all_artifacts_with_agent_passport(self):
        journey = Path(self.tmp.name) / "initiative.md"
        journey.write_text(JOURNEY_TEXT, encoding="utf-8")
        out = Path(self.tmp.name) / "out"
        ChatClient._create = scripted_responses(*full_session(with_brief=False), *passport_session())

        code = cli.main(["progress", "--journey-file", str(journey),
                         "--repo-path", str(self.repo_path), "--out", str(out), "--quiet"])
        self.assertEqual(code, 0)

        files = {p.name for p in out.iterdir()}
        suffixes = ["_progress_model.json", "_progress_report.html", "_dashboard.html",
                    "_client_journey_passport.html"]
        # Markdown-паспорта (`_passport.md/.json`, `_initiative_passport.md`)
        # требуют шаблонов в корне проекта; без них CLI пишет заметку, а не
        # падает — здесь проверяется только то, что собирается всегда.
        root = Path(cli.__file__).resolve().parents[2]
        if (root / "passport_template_v3.md").exists():
            suffixes += ["_passport.md", "_passport.json"]
        for suffix in suffixes:
            self.assertTrue(any(f.endswith(suffix) for f in files), f"нет файла {suffix}: {files}")

        model = json.loads(next(out.glob("*_progress_model.json")).read_text(encoding="utf-8"))
        passport = model["passport_data"]
        self.assertEqual(passport["decision-boundary"], "END_TO_END_PROCESS")
        rows = {r["id"]: r for r in passport["registry"]}
        self.assertEqual(set(rows), {"journey-1", "process-1", "bbb-1", "bbb-2",
                                     "operation-1", "operation-2", "need-1", "guardrail-1"})
        self.assertEqual(rows["guardrail-1"]["parent"], "bbb-2")
        self.assertFalse(any("паспорт не завершён" in g for g in model["gaps"]), model["gaps"])

        html = next(out.glob("*_client_journey_passport.html")).read_text(encoding="utf-8")
        self.assertIn(STATUS_BADGE_AGENT, html)
        self.assertIn("Передача исполнителю", html)
        self.assertIn("bbb.peredacha-ispolnitelyu", html)
        self.assertIn('<td data-col="Родитель">bbb-2</td>', html)
        # Раскладка: карта дерева → карточка узла → реестр строятся скриптом.
        self.assertIn("pko-tree", html)
        self.assertIn("pko-detail", html)
        self.assertNotIn("{{", html.split("<script data-passport-fix>")[0].split("<template", 1)[0])

    def test_progress_without_passport_session_falls_back(self):
        journey = Path(self.tmp.name) / "initiative.md"
        journey.write_text(JOURNEY_TEXT, encoding="utf-8")
        out = Path(self.tmp.name) / "out"
        ChatClient._create = scripted_responses(*full_session(with_brief=False))

        code = cli.main(["progress", "--journey-file", str(journey),
                         "--repo-path", str(self.repo_path), "--out", str(out), "--quiet"])
        self.assertEqual(code, 0)
        model = json.loads(next(out.glob("*_progress_model.json")).read_text(encoding="utf-8"))
        self.assertIsNone(model["passport_data"])
        self.assertTrue(any("паспорт" in g for g in model["gaps"]), model["gaps"])
        html = next(out.glob("*_client_journey_passport.html")).read_text(encoding="utf-8")
        self.assertIn("АГЕНТ ПАСПОРТ НЕ ЗАПОЛНИЛ", html)


if __name__ == "__main__":
    unittest.main()
